'use strict';
// =====================================================================
//  Сундуки: редкость, мимики, ключи, реликвии и оформление под главы
// =====================================================================

// Редкость сундука: сколько всего внутри
const CHEST_TIERS = {
  wood: { name: 'Деревянный сундук', gems: 6, shards: 2, heart: 0.4, magnet: 0.2, super: 0, key: 0.05 },
  silver: { name: 'Серебряный сундук', gems: 10, shards: 5, heart: 1, magnet: 0.5, super: 20, key: 0.2 },
  gold: { name: 'Золотой сундук', gems: 12, shards: 8, heart: 1, magnet: 1, super: 30, key: 0 },
};
const TIER_TRIM = { wood: '#b07a40', silver: '#dfe8f2', gold: '#ffd25a' };

// Реликвии: носить можно три, переходят из главы в главу
const RELICS = {
  phoenix: { ic: '🪶', name: 'Перо феникса', ds: 'Один раз за главу воскрешает с половиной здоровья' },
  horseshoe: { ic: '🧲', name: 'Подкова-магнит', ds: 'Радиус сбора ×3' },
  mirror: { ic: '🪞', name: 'Кривое зеркальце', ds: 'Каждый восьмой удар по тебе проходит мимо' },
  hourglass: { ic: '⏳', name: 'Песочные часы', ds: 'Супер-удар копится на 40% быстрее' },
  collar: { ic: '🔱', name: 'Колючий ошейник', ds: 'Враги, касаясь тебя, получают урон' },
  clover: { ic: '🍀', name: 'Четырёхлистник', ds: '+10% крит, в сундуках в 1,5 раза больше осколков' },
  boots: { ic: '👢', name: 'Сапоги-скороходы', ds: '+15% скорость, рывок перезаряжается на 25% быстрее' },
  heartstone: { ic: '💗', name: 'Сердце-камень', ds: '+25% здоровья, сердечки лечат в 1,5 раза сильнее' },
  fang: { ic: '🦷', name: 'Клык вампира', ds: 'Каждый побеждённый враг лечит 1% здоровья' },
  storm: { ic: '⚡', name: 'Грозовая банка', ds: 'Каждые 2,5 с молния бьёт ближайшего врага' },
  compass: { ic: '🧭', name: 'Компас кладоискателя', ds: 'Тайные сундуки рядом видны на мини-карте, мимики выдают себя' },
  crown: { ic: '👑', name: 'Дерзкая корона', ds: '+25% урона, но получаешь на 15% больше' },
  guard: { ic: '🛡️', name: 'Щит стража', ds: 'Раз в 10 с полностью блокирует удар' },
};

// Мимик: сундук, который кусается
ENEMIES.mimic = { name: 'Мимик', hp: 140, spd: 105, dmg: 20, r: 17, xp: 6, ai: 'charger', col: '#a0623a', sprite: 'mimic' };

// Оформление сундуков по главам
const CHEST_THEME = {
  1: { body: '#8b5530', lid: '#a0643a', dark: '#3a1f0f' },
  2: { body: '#2a1a4a', lid: '#3a2466', dark: '#12081e', neon: '#3ff0ff' },
  3: { body: '#123a30', lid: '#1a4a3c', dark: '#06140f', glitch: true },
  4: { body: '#3a2a4a', lid: '#4a3a5a', dark: '#140e1e', toy: true },
  5: { body: '#c8944a', lid: '#d8a85a', dark: '#6a4420', picnic: true },
};

function drawChestSprite(c, x, y, tier, open, chn, t, o = {}) {
  const th = CHEST_THEME[chn] || CHEST_THEME[1], trim = TIER_TRIM[tier] || TIER_TRIM.wood;
  shadow(c, x, y + 14, 18, 5);
  if (!open) {
    const g = Math.sin(t * 4 + x) * 0.5 + 0.5;
    const glow = tier === 'gold' ? '255,210,90' : tier === 'silver' ? '210,230,255' : '255,200,120';
    c.fillStyle = `rgba(${glow},${(tier === 'wood' ? 0.1 : 0.2) + g * 0.18})`; c.beginPath(); c.arc(x, y, tier === 'gold' ? 34 : 28, 0, TAU); c.fill();
    if (tier !== 'wood' && Math.random() < 0.1) { c.fillStyle = tier === 'gold' ? '#fff3b0' : '#ffffff'; star(c, x + rnd(-20, 20), y + rnd(-22, 8), 2.5, t, 4); c.fill(); }
  }
  c.save(); c.translate(x, y);
  if (o.twitch) c.rotate(Math.sin(t * 40) * 0.08);
  if (th.picnic) {
    c.fillStyle = th.body; c.strokeStyle = th.dark; c.lineWidth = 2;
    c.beginPath(); c.moveTo(-17, -6); c.lineTo(17, -6); c.lineTo(13, 14); c.lineTo(-13, 14); c.closePath(); c.fill(); c.stroke();
    c.strokeStyle = 'rgba(0,0,0,0.25)'; c.lineWidth = 1;
    for (let k = -2; k <= 12; k += 4) { c.beginPath(); c.moveTo(-16, k); c.lineTo(16, k); c.stroke(); }
    if (!open) for (let i = 0; i < 6; i++) for (let j = 0; j < 2; j++) { c.fillStyle = (i + j) % 2 ? '#e53935' : '#ffffff'; c.fillRect(-15 + i * 5, -12 + j * 5, 5, 5); }
    c.strokeStyle = th.dark; c.lineWidth = 3; c.beginPath(); c.arc(0, -6, 13, Math.PI, TAU); c.stroke();
  } else if (th.toy) {
    c.fillStyle = th.body; c.strokeStyle = th.dark; c.lineWidth = 2; c.fillRect(-16, -10, 32, 24); c.strokeRect(-16, -10, 32, 24);
    for (const [px, py, col] of [[-9, 4, '#ff6a6a'], [0, 8, '#6ac8ff'], [9, 2, '#ffd25a']]) { c.fillStyle = col; c.globalAlpha = 0.55; c.beginPath(); c.arc(px, py, 3, 0, TAU); c.fill(); c.globalAlpha = 1; }
    c.fillStyle = th.lid;
    if (!open) c.fillRect(-17, -15, 34, 7);
    else { c.save(); c.translate(-17, -10); c.rotate(-0.9); c.fillRect(0, -7, 34, 7); c.restore(); }
  } else {
    c.fillStyle = th.body; c.strokeStyle = th.dark; c.lineWidth = 2;
    c.fillRect(-16, -10, 32, 24); c.strokeRect(-16, -10, 32, 24);
    if (open) { c.fillStyle = th.dark; c.fillRect(-14, -10, 28, 6); c.fillStyle = th.lid; c.fillRect(-16, -26, 32, 10); }
    else { c.fillStyle = th.lid; c.fillRect(-16, -14, 32, 8); }
    if (th.neon) { c.strokeStyle = th.neon; c.lineWidth = 1.5; c.strokeRect(-14, -8, 28, 20); }
    if (th.glitch && Math.random() < 0.08) { c.fillStyle = 'rgba(63,240,160,0.6)'; c.fillRect(-18 + Math.random() * 6, -6 + Math.random() * 12, 36, 2); }
  }
  c.fillStyle = trim; c.fillRect(-16, -2, 32, 3);
  if (!open) {
    if (tier === 'gold') {
      c.fillStyle = '#ffd25a'; c.strokeStyle = '#8a6a10'; c.lineWidth = 1.5; roundRect(c, -5, -6, 10, 10, 2); c.fill(); c.stroke();
      c.strokeStyle = '#ffd25a'; c.lineWidth = 2; c.beginPath(); c.arc(0, -6, 3.5, Math.PI, TAU); c.stroke();
      c.fillStyle = '#5a3a00'; c.fillRect(-1, -3, 2, 4);
    } else { c.fillStyle = trim; c.fillRect(-3, -5, 6, 8); }
    if (o.eyes) { c.fillStyle = '#ff2a2a'; c.fillRect(-11, -9, 3, 2); c.fillRect(8, -9, 3, 2); }
  }
  c.restore();
}

ESPR.mimic = (c, e) => {
  const th = CHEST_THEME[e.chn] || CHEST_THEME[1];
  const open = 0.3 + Math.abs(Math.sin(e.t * 8)) * 0.6;
  c.fillStyle = '#5a0a0a'; c.beginPath(); c.ellipse(0, -2, 14, 3 + 8 * open, 0, 0, TAU); c.fill();
  c.fillStyle = th.body; c.strokeStyle = th.dark; c.lineWidth = 2; c.fillRect(-16, -2, 32, 16); c.strokeRect(-16, -2, 32, 16);
  c.fillStyle = '#ffffff';
  for (let k = 0; k < 6; k++) { c.beginPath(); c.moveTo(-14 + k * 5, -2); c.lineTo(-11.5 + k * 5, -7); c.lineTo(-9 + k * 5, -2); c.fill(); }
  c.save(); c.translate(-16, -2); c.rotate(-open * 0.8);
  c.fillStyle = th.lid; c.fillRect(0, -10, 32, 10);
  c.fillStyle = '#ffffff'; for (let k = 0; k < 6; k++) { c.beginPath(); c.moveTo(3 + k * 5, 0); c.lineTo(5.5 + k * 5, 5); c.lineTo(8 + k * 5, 0); c.fill(); }
  c.fillStyle = '#ff2a2a'; c.beginPath(); c.arc(9, -5, 2.4, 0, TAU); c.arc(22, -5, 2.4, 0, TAU); c.fill();
  c.restore();
  c.fillStyle = '#ff5b8a'; c.beginPath(); c.ellipse(4, 3 + open * 3, 7, 3, 0.3, 0, TAU); c.fill();
  c.fillStyle = '#ffd25a'; c.fillRect(-16, 6, 32, 2);
};
