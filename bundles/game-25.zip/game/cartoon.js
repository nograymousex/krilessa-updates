'use strict';
// =====================================================================
//  Мультяшный фильтр: превращает фотографию в "мультик" прямо на
//  телефоне при запуске игры. Никаких серверов – всё считается локально.
//  Шаги: увеличение глаз -> сглаживание (фильтр Кувахары) ->
//  постеризация цветов -> чернильные контуры (XDoG) -> блики в глазах.
// =====================================================================
const Cartoon = (() => {
  // Профили фото: где глаза и лицо (в долях ширины/высоты кадра)
  const PROFILES = {
    ryzhova: {
      src: 'ryzhova.jpg', bulge: 0.3, blush: true,
      eyes: [{ x: 428 / 960, y: 437 / 1280 }, { x: 664 / 960, y: 466 / 1280 }],
      face: { x: 0.565, y: 0.43, r: 0.36 },
    },
    zyama: {
      src: 'zyama.jpg', bulge: 0.38, blush: false,
      eyes: [{ x: 0.401, y: 0.459 }, { x: 0.648, y: 0.462 }],
      face: { x: 0.51, y: 0.44, r: 0.47 },
    },
  };

  function makeCanvas(w, h) {
    const c = document.createElement('canvas');
    c.width = w; c.height = h;
    return c;
  }

  function loadImage(src) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = reject;
      img.src = src;
    });
  }

  // "Линза": увеличивает область вокруг точки (большие мультяшные глаза)
  function bulge(src, W, H, cx, cy, R, s) {
    const out = new Uint8ClampedArray(src);
    const x0 = Math.max(0, Math.floor(cx - R)), x1 = Math.min(W - 1, Math.ceil(cx + R));
    const y0 = Math.max(0, Math.floor(cy - R)), y1 = Math.min(H - 1, Math.ceil(cy + R));
    for (let y = y0; y <= y1; y++) {
      for (let x = x0; x <= x1; x++) {
        const dx = x - cx, dy = y - cy;
        const r = Math.sqrt(dx * dx + dy * dy);
        if (r >= R) continue;
        const t = r / R;
        const f = (1 - s) + s * t * t;
        const sx = Math.min(W - 1.001, Math.max(0, cx + dx * f));
        const sy = Math.min(H - 1.001, Math.max(0, cy + dy * f));
        const ix = sx | 0, iy = sy | 0, fx = sx - ix, fy = sy - iy;
        const i00 = (iy * W + ix) * 4, i10 = i00 + 4, i01 = i00 + W * 4, i11 = i01 + 4;
        const o = (y * W + x) * 4;
        for (let c = 0; c < 3; c++) {
          const a = src[i00 + c] * (1 - fx) + src[i10 + c] * fx;
          const b = src[i01 + c] * (1 - fx) + src[i11 + c] * fx;
          out[o + c] = a * (1 - fy) + b * fy;
        }
      }
    }
    return out;
  }

  // Фильтр Кувахары через таблицы сумм: плоские "мазки" с чёткими краями
  function kuwahara(src, W, H, r) {
    const W1 = W + 1, N = W1 * (H + 1);
    const sR = new Float64Array(N), sG = new Float64Array(N), sB = new Float64Array(N);
    const sL = new Float64Array(N), sL2 = new Float64Array(N);
    for (let y = 0; y < H; y++) {
      let aR = 0, aG = 0, aB = 0, aL = 0, aL2 = 0;
      for (let x = 0; x < W; x++) {
        const i = (y * W + x) * 4;
        const R = src[i], G = src[i + 1], B = src[i + 2];
        const L = 0.299 * R + 0.587 * G + 0.114 * B;
        aR += R; aG += G; aB += B; aL += L; aL2 += L * L;
        const j = (y + 1) * W1 + (x + 1);
        sR[j] = sR[j - W1] + aR; sG[j] = sG[j - W1] + aG; sB[j] = sB[j - W1] + aB;
        sL[j] = sL[j - W1] + aL; sL2[j] = sL2[j - W1] + aL2;
      }
    }
    const rect = (a, xa, ya, xb, yb) =>
      a[(yb + 1) * W1 + xb + 1] - a[ya * W1 + xb + 1] - a[(yb + 1) * W1 + xa] + a[ya * W1 + xa];
    const out = new Uint8ClampedArray(W * H * 4);
    for (let y = 0; y < H; y++) {
      for (let x = 0; x < W; x++) {
        let best = Infinity, bxa = 0, bya = 0, bxb = 0, byb = 0, bn = 1;
        for (let q = 0; q < 4; q++) {
          const xa = (q & 1) ? x : Math.max(0, x - r);
          const xb = (q & 1) ? Math.min(W - 1, x + r) : x;
          const ya = (q & 2) ? y : Math.max(0, y - r);
          const yb = (q & 2) ? Math.min(H - 1, y + r) : y;
          const n = (xb - xa + 1) * (yb - ya + 1);
          const m = rect(sL, xa, ya, xb, yb) / n;
          const v = rect(sL2, xa, ya, xb, yb) / n - m * m;
          if (v < best) { best = v; bxa = xa; bya = ya; bxb = xb; byb = yb; bn = n; }
        }
        const o = (y * W + x) * 4;
        out[o] = rect(sR, bxa, bya, bxb, byb) / bn;
        out[o + 1] = rect(sG, bxa, bya, bxb, byb) / bn;
        out[o + 2] = rect(sB, bxa, bya, bxb, byb) / bn;
        out[o + 3] = 255;
      }
    }
    return out;
  }

  function luminance(src, W, H) {
    const L = new Float32Array(W * H);
    for (let i = 0, j = 0; j < L.length; i += 4, j++) {
      L[j] = 0.299 * src[i] + 0.587 * src[i + 1] + 0.114 * src[i + 2];
    }
    return L;
  }

  function gauss(ch, W, H, sigma) {
    const rad = Math.max(1, Math.ceil(sigma * 3));
    const k = new Float32Array(rad * 2 + 1);
    let sum = 0;
    for (let i = -rad; i <= rad; i++) { k[i + rad] = Math.exp(-(i * i) / (2 * sigma * sigma)); sum += k[i + rad]; }
    for (let i = 0; i < k.length; i++) k[i] /= sum;
    const tmp = new Float32Array(W * H), out = new Float32Array(W * H);
    for (let y = 0; y < H; y++) {
      const row = y * W;
      for (let x = 0; x < W; x++) {
        let a = 0;
        for (let i = -rad; i <= rad; i++) {
          const xx = x + i < 0 ? 0 : (x + i >= W ? W - 1 : x + i);
          a += ch[row + xx] * k[i + rad];
        }
        tmp[row + x] = a;
      }
    }
    for (let y = 0; y < H; y++) {
      for (let x = 0; x < W; x++) {
        let a = 0;
        for (let i = -rad; i <= rad; i++) {
          const yy = y + i < 0 ? 0 : (y + i >= H ? H - 1 : y + i);
          a += tmp[yy * W + x] * k[i + rad];
        }
        out[y * W + x] = a;
      }
    }
    return out;
  }

  // Контуры: разность гауссиан (XDoG) -> мягкие чернильные линии 0..1
  function inkLines(L, W, H, sigma, thrLo, thrHi) {
    const g1 = gauss(L, W, H, sigma);
    const g2 = gauss(L, W, H, sigma * 1.6);
    const line = new Float32Array(W * H);
    for (let i = 0; i < line.length; i++) {
      const d = g2[i] - g1[i]; // >0 там, где пиксель темнее окрестности
      line[i] = d <= thrLo ? 0 : d >= thrHi ? 1 : (d - thrLo) / (thrHi - thrLo);
    }
    return line;
  }

  function blurRGB(src, W, H, sigma) {
    const n = W * H, out = new Uint8ClampedArray(src.length);
    for (let c = 0; c < 3; c++) {
      const ch = new Float32Array(n);
      for (let j = 0; j < n; j++) ch[j] = src[j * 4 + c];
      const b = gauss(ch, W, H, sigma);
      for (let j = 0; j < n; j++) out[j * 4 + c] = b[j];
    }
    for (let j = 0; j < n; j++) out[j * 4 + 3] = 255;
    return out;
  }

  function posterize(src, W, H, levels, sat) {
    const out = new Uint8ClampedArray(src.length);
    const w = 0.2;
    for (let i = 0; i < src.length; i += 4) {
      let R = src[i], G = src[i + 1], B = src[i + 2];
      const L = 0.299 * R + 0.587 * G + 0.114 * B;
      const q = (L / 255) * levels;
      const base = Math.floor(q), f = q - base;
      const step = f < 0.5 - w ? 0 : f > 0.5 + w ? 1 : (f - (0.5 - w)) / (2 * w);
      const qL = Math.min(255, ((base + step) / levels) * 255 * 0.92 + 22);
      const ratio = (qL + 6) / (L + 6);
      R *= ratio; G *= ratio; B *= ratio;
      const gray = (R + G + B) / 3;
      out[i] = gray + (R - gray) * sat;
      out[i + 1] = gray + (G - gray) * sat;
      out[i + 2] = gray + (B - gray) * sat;
      out[i + 3] = 255;
    }
    return out;
  }

  // Главная функция. Возвращает { photo, cartoon, face } – два canvas одного размера.
  async function make(profileName, W = 480, H = 640) {
    const prof = PROFILES[profileName];
    const EYES = prof.eyes;
    const img = await loadImage(prof.src);
    const photo = makeCanvas(W, H);
    const pctx = photo.getContext('2d');
    pctx.drawImage(img, 0, 0, W, H);
    let px = pctx.getImageData(0, 0, W, H).data;

    // 1) большие глаза
    const R = W * 0.105;
    if (prof.bulge) for (const e of EYES) px = bulge(px, W, H, e.x * W, e.y * H, R, prof.bulge);
    // 2) сглаживание "мазками" (два прохода)
    let sm = kuwahara(px, W, H, 3);
    sm = kuwahara(sm, W, H, 2);
    // 3) контуры
    const lines = inkLines(luminance(sm, W, H), W, H, 1.25, 1.8, 6);
    // 4) плоские цвета
    const flat = blurRGB(posterize(sm, W, H, 5, 1.3), W, H, 0.9);
    // 5) соединяем
    const cartoon = makeCanvas(W, H);
    const cctx = cartoon.getContext('2d');
    const outImg = cctx.createImageData(W, H);
    const o = outImg.data;
    for (let i = 0, j = 0; i < o.length; i += 4, j++) {
      const k = 1 - Math.min(1, lines[j]) * (prof.ink !== undefined ? prof.ink : 0.88);
      o[i] = flat[i] * k; o[i + 1] = flat[i + 1] * k; o[i + 2] = flat[i + 2] * k; o[i + 3] = 255;
    }
    cctx.putImageData(outImg, 0, 0);
    // 6) мультяшные блики в глазах
    if (!prof.noShine) for (const e of EYES) {
      const ex = e.x * W, ey = e.y * H;
      cctx.fillStyle = 'rgba(255,255,255,0.95)';
      cctx.beginPath(); cctx.ellipse(ex - W * 0.012, ey - H * 0.011, W * 0.011, W * 0.009, -0.5, 0, Math.PI * 2); cctx.fill();
      cctx.beginPath(); cctx.arc(ex + W * 0.012, ey + H * 0.006, W * 0.005, 0, Math.PI * 2); cctx.fill();
    }
    // лёгкий румянец
    if (prof.blush) {
    cctx.save();
    cctx.globalCompositeOperation = 'multiply';
    for (const e of EYES) {
      const g = cctx.createRadialGradient(e.x * W, e.y * H + H * 0.085, 0, e.x * W, e.y * H + H * 0.085, W * 0.07);
      g.addColorStop(0, 'rgba(255,150,150,0.55)');
      g.addColorStop(1, 'rgba(255,150,150,0)');
      cctx.fillStyle = g;
      cctx.fillRect(0, 0, W, H);
    }
    cctx.restore();
    }
    return { photo, cartoon, face: prof.face };
  }

  // Круглый "аватар" лица из мультяшной картинки
  function avatar(cartoon, size, face = PROFILES.ryzhova.face) {
    const c = makeCanvas(size, size);
    const x = c.getContext('2d');
    const W = cartoon.width, H = cartoon.height;
    // лицо: центр между глазами, чуть ниже
    const cx = W * face.x, cy = H * face.y, r = W * face.r;
    x.save();
    x.beginPath(); x.arc(size / 2, size / 2, size / 2, 0, Math.PI * 2); x.clip();
    x.drawImage(cartoon, cx - r, cy - r, r * 2, r * 2, 0, 0, size, size);
    x.restore();
    return c;
  }

  return { make, avatar, makeCanvas, PROFILES };
})();
