'use strict';
// =====================================================================
//  Главы 4–5: Тесса. Героиня, локации дома, враги, боссы, улики,
//  жители, гардероб и вся графика к ним.
//  Глава 4 «Ночь глитчей» – глитч-жуть. Глава 5 «Пропавший корм» – уютный детектив.
// =====================================================================

// ---------------- Героиня ----------------
HEROES.tessa = {
  name: 'Тесса', proj: 'claw', dmg: 17, fireInt: 0.46, range: 140, speed: 172, hp: 125, projSpd: 620, pierce: 2,
  dash: 'ПРЫЖОК', pounce: true, super: 'purr', superName: 'Мурчание', lives: 9,
  names: {
    dmg: ['🐾', 'Острые коготки', '+25% урона'],
    rate: ['💨', 'Быстрые лапки', '+18% скорость атаки'],
    multi: ['✨', 'Двойной взмах', '+1 удар лапой за раз'],
    pierce: ['🌀', 'Широкий замах', 'Удар задевает +1 врага'],
    range: ['📏', 'Длинные лапы', '+15% радиус атаки'],
    hp: ['💖', 'Кошачье здоровье', '+30 к здоровью и лечение'],
    speed: ['👣', 'Мягкие лапки', '+8% скорость бега'],
    regen: ['👅', 'Вылизывание', '+1 HP в секунду'],
    orbit: ['🧶', 'Клубки', '+1 клубок кружит вокруг тебя'],
    bolt: ['⚡', 'Статика с шерсти', 'Искры бьют врагов цепочкой'],
    magnet: ['👃', 'Любопытный нос', '+50% радиус сбора'],
    armor: ['🧥', 'Густая шерсть', '-8% получаемого урона'],
    dash: ['🐈', 'Мастер прыжка', '-20% перезарядка прыжка'],
    crit: ['🎯', 'Точная лапа', '+6% шанс крита'],
    critdmg: ['😼', 'Кусь', '+40% урона крита'],
    vamp: ['🐟', 'Сытая кошка', '+1 HP за каждого побеждённого'],
    explode: ['💥', 'Шерстяной взрыв', 'Удары взрываются клочками шерсти'],
    frost: ['❄️', 'Холодный нос', 'Удары замедляют врагов'],
    shield: ['🫧', 'Пушистый щит', 'Щит блокирует удар (перезарядка)'],
    super: ['😻', 'Громкое мурчание', 'Мурчание копится на 25% быстрее'],
  },
};
Cartoon.PROFILES.tessa = {
  src: 'tessa.jpg', bulge: 0, blush: false, noShine: true, ink: 0.3,
  eyes: [{ x: 0.35, y: 0.35 }, { x: 0.533, y: 0.35 }],
  face: { x: 0.45, y: 0.33, r: 0.29 },
};

// ---------------- Локации (биомы 14–25) ----------------
// floor – рисунок пола, furniture – «скалы» рисуются как мебель
BIOMES.push(
  // ---- Глава 4: дом ночью ----
  { id: 'bedroom', name: 'Спальня', ground: ['#3a2f4a', '#433756', '#342a42'], tree: 'plant', treeP: 0.025, floor: 'carpet',
    obst: [[ROCK, 1]], rock: ['#4a3a30', '#56443a', '#3e3028'], deco: 'toys', mini: '#3a2f4a', furniture: true },
  { id: 'corridor', name: 'Бесконечный коридор', ground: ['#3a2c22', '#44342a', '#33271e'], tree: 'floorlamp', treeP: 0.02, floor: 'parquet',
    obst: [[ROCK, 1]], rock: ['#2e2a3a', '#383446', '#26232f'], deco: 'dust', mini: '#3a2c22', furniture: true },
  { id: 'kitchenN', name: 'Кухня в темноте', ground: ['#2c3440', '#363e4c', '#262d38'], tree: 'chair', treeP: 0.035, floor: 'checker',
    obst: [[ROCK, 0.75], [WATER, 0.25]], rock: ['#3a4048', '#444a54', '#30363e'], water: ['#9aa4b8', '#aab4c8', '#8a94a8'], deco: 'crumbs', mini: '#2c3440', furniture: true },
  { id: 'livingN', name: 'Гостиная с телевизором', ground: ['#22343a', '#2a3e44', '#1d2d32'], tree: 'books', treeP: 0.035, floor: 'carpet',
    obst: [[ROCK, 1]], rock: ['#2a2440', '#342c4c', '#221d36'], deco: 'pixelnight', mini: '#22343a', furniture: true },
  { id: 'bathroom', name: 'Ванная', ground: ['#2e4450', '#38505c', '#283c46'], tree: 'basket', treeP: 0.02, floor: 'tiles',
    obst: [[WATER, 0.7], [ROCK, 0.3]], rock: ['#5a6a78', '#647484', '#4e5e6a'], water: ['#16324a', '#1e3c56', '#102a40'], deco: 'drops', mini: '#2e4450', furniture: true },
  { id: 'attic', name: 'Чердак Мяу.exe', ground: ['#2a2230', '#32283a', '#241d2a'], tree: 'boxes', treeP: 0.03, floor: 'boards',
    obst: [[ROCK, 1]], rock: ['#3a2a2a', '#443232', '#302222'], deco: 'pixelnight', mini: '#2a2230', furniture: true, castleStyle: 'attic' },
  // ---- Глава 5: дом днём и сад ----
  { id: 'kitchenD', name: 'Кухня', ground: ['#e8dcc8', '#f2e8d6', '#dccfb8'], tree: 'chair', treeP: 0.035, floor: 'checker',
    obst: [[ROCK, 0.8], [WATER, 0.2]], rock: ['#b07a4a', '#c08a58', '#9a6a3e'], water: ['#f4f6fa', '#ffffff', '#e6eaf0'], deco: 'crumbs', mini: '#e8dcc8', furniture: true },
  { id: 'livingD', name: 'Гостиная', ground: ['#a8744a', '#b88254', '#9a6a42'], tree: 'plant', treeP: 0.03, floor: 'parquet',
    obst: [[ROCK, 1]], rock: ['#5a7ab0', '#6a8ac0', '#4a6aa0'], deco: 'toys', mini: '#a8744a', furniture: true },
  { id: 'nursery', name: 'Детская', ground: ['#b8d8f0', '#c8e4f8', '#a8cce8'], tree: 'toyblocks', treeP: 0.035, floor: 'carpet',
    obst: [[ROCK, 1]], rock: ['#ff8a8a', '#ffd25a', '#7ac8ff'], deco: 'toys', mini: '#b8d8f0', furniture: true, toyRocks: true },
  { id: 'garden', name: 'Сад', ground: ['#4a9a4a', '#56aa56', '#3f8a3f'], tree: 'appletree', treeP: 0.07,
    obst: [[WATER, 0.5], [ROCK, 0.5]], rock: ['#9a9a90', '#aaaaa0', '#8a8a80'], water: ['#5ab0e0', '#6ac0f0', '#4aa0d0'], deco: 'flowers', mini: '#4a9a4a' },
  { id: 'yard', name: 'Двор с голубятней', ground: ['#b8a888', '#c4b494', '#ab9b7c'], tree: 'bush', treeP: 0.04, floor: 'paving',
    obst: [[ROCK, 1]], rock: ['#8a6a4a', '#9a7a58', '#7a5c3e'], deco: 'leaves', mini: '#b8a888', fence: true },
  { id: 'pantry', name: 'Кладовая', ground: ['#c89a6a', '#d4a676', '#bc8e5e'], tree: 'boxes', treeP: 0.03, floor: 'boards',
    obst: [[ROCK, 1]], rock: ['#8a5a3a', '#9a6a46', '#7a4e30'], deco: 'crumbs', mini: '#c89a6a', furniture: true, castleStyle: 'pantry' },
);
BIOME_MUSIC.push('night4', 'hall4', 'hall4', 'tv4', 'bath4', 'tv4', 'morning5', 'detective5', 'morning5', 'garden5', 'yard5', 'detective5');
// Арена испытаний (карман под картой) – свой стиль в каждой главе
const ARENA_BIOME = BIOMES.push({ id: 'arena', name: 'Испытание', ground: ['#1a0a0a', '#220e0e', '#140808'], tree: 'dead', treeP: 0, obst: [[ROCK, 1]], deco: 'embers', mini: '#300', arena: true }) - 1;
BIOME_MUSIC.push('boss');
const ARENA_STYLE = {
  1: { name: 'Пекло Мрака', floor: ['#2a0e0a', '#331410'], crack: '#ff5a1a', ember: '#ffb03a', wall: '#1a0606', tint: '255,60,20' },
  2: { name: 'Кринж-бездна', floor: ['#1e0a2a', '#260e34'], crack: '#ff3ea5', ember: '#3ff0ff', wall: '#12061e', tint: '255,62,165' },
  3: { name: 'Глитч-изнанка', floor: ['#06140f', '#0a1c16'], crack: '#3ff0a0', ember: '#ff3ea5', wall: '#030a08', tint: '63,240,160' },
  4: { name: 'Изнанка ночи', floor: ['#0e0a1a', '#140e24'], crack: '#7a5aff', ember: '#3ff0a0', wall: '#07050e', tint: '120,90,255' },
  5: { name: 'Адская духовка', floor: ['#2a160a', '#341c0e'], crack: '#ffb03a', ember: '#ff6a1a', wall: '#180a04', tint: '255,150,40' },
};

// ---------------- Враги ----------------
Object.assign(ENEMIES, {
  // глава 4
  pmouse: { name: 'Пиксельная мышь', hp: 16, spd: 150, dmg: 7, r: 8, xp: 0.6, ai: 'swarm', group: [3, 5], col: '#7dffb0' },
  sock: { name: 'Сбежавший носок', hp: 70, spd: 70, dmg: 15, r: 13, xp: 3, ai: 'hop', col: '#c0c0d8' },
  staticball: { name: 'Клубок помех', hp: 75, spd: 55, dmg: 13, r: 13, xp: 4, ai: 'ranged', col: '#d0d0d0',
    shot: { cd: 2.1, spd: 230, dmg: 13, n: 3, spread: 0.2, square: true, col: '#e8e8e8' } },
  bitfly: { name: 'Битый пиксель', hp: 30, spd: 120, dmg: 11, r: 10, xp: 2, ai: 'bat', fly: true, col: '#ff3ea5' },
  shadowcat: { name: 'Тень Тессы', hp: 85, spd: 120, dmg: 18, r: 13, xp: 4, ai: 'blinker', dodge: true, col: '#1a1a2a' },
  toaster: { name: 'Тостер-турель', hp: 110, spd: 0, dmg: 12, r: 15, xp: 4, ai: 'turret', col: '#c0c4cc',
    shot: { cd: 1.8, spd: 200, dmg: 13, n: 2, spread: 0.25, emoji: true, emojiSet: ['🍞'] } },
  // глава 5
  pigeon: { name: 'Голубь', hp: 40, spd: 120, dmg: 11, r: 11, xp: 2, ai: 'bat', fly: true, col: '#9aa0b0' },
  mouse: { name: 'Мышонок-воришка', hp: 22, spd: 155, dmg: 8, r: 9, xp: 0.8, ai: 'swarm', group: [3, 5], col: '#a8a0a0' },
  cuke: { name: 'Огурчик', hp: 65, spd: 75, dmg: 17, r: 12, xp: 3, ai: 'charger', col: '#4caf50' },
  yarn: { name: 'Клубок', hp: 80, spd: 65, dmg: 14, r: 13, xp: 3, ai: 'hop', split: 'yarnlet', col: '#ff6fb5' },
  yarnlet: { name: 'Клубочек', hp: 28, spd: 95, dmg: 8, r: 9, xp: 1, ai: 'hop', col: '#ffb3d6', sprite: 'yarn' },
  sunbunny: { name: 'Солнечный зайчик', hp: 35, spd: 130, dmg: 12, r: 10, xp: 2, ai: 'blinker', fly: true, col: '#ffe066' },
  sprinkler: { name: 'Поливалка', hp: 95, spd: 0, dmg: 10, r: 14, xp: 4, ai: 'turret', col: '#5ab0e0',
    shot: { cd: 1.6, spd: 180, dmg: 11, n: 8, ring: true, spin: true, col: '#7fd0ff' } },
});
SPAWNS.push(
  [['sock', 3], ['pmouse', 2.5], ['shadowcat', 1], ['bitfly', 1.5]],
  [['shadowcat', 2.5], ['bitfly', 2.5], ['pmouse', 2], ['sock', 1.5]],
  [['toaster', 1.5], ['pmouse', 3], ['sock', 2], ['staticball', 1.5]],
  [['staticball', 3], ['bitfly', 3], ['pmouse', 2], ['shadowcat', 1.2]],
  [['sock', 3], ['bitfly', 2], ['shadowcat', 2], ['staticball', 1.5]],
  [['shadowcat', 2.5], ['staticball', 2.5], ['bitfly', 2.5], ['pixel', 2]],
  [['mouse', 3], ['cuke', 2.5], ['yarn', 1.5]],
  [['yarn', 3], ['sunbunny', 2.5], ['mouse', 2]],
  [['yarn', 3], ['sunbunny', 2], ['mouse', 2], ['cuke', 1]],
  [['pigeon', 3], ['sprinkler', 1.5], ['cuke', 2], ['sunbunny', 1.5]],
  [['pigeon', 3.5], ['mouse', 2.5], ['sprinkler', 1]],
  [['mouse', 3], ['pigeon', 2], ['yarn', 2], ['cuke', 2]],
);

// ---------------- Боссы главы 4 ----------------
Object.assign(BOSSES, {
  vacuum: {
    name: 'Робот-Пылесос', sub: 'Страж Коридора', r: 40, ttk: 55, hit: 0.08, touch: 0.14, spd: 85, move: 'chase', col: '#3a3a4a',
    lines: {
      intro: 'БЗЗЗЗ. ОБНАРУЖЕНА ШЕРСТЬ. НАЧИНАЮ УБОРКУ. 🧹',
      stages: ['', 'Шерсти слишком много… УСИЛИВАЮ ТЯГУ!!!', 'ОШИБКА: мешок полон. НО Я ВСЁ РАВНО ЕМ!!!'],
      death: 'Бззз… мешок… переполнен… доброй… ночи…',
      taunts: ['Шерсть на ковре – это преступление!', 'Я уберу и тебя, котик.', 'Бип-бип. Мур-мур. Ой, это не я.'],
    },
    stages: [
      { attacks: [['charge', { repeat: 2 }], ['suck', { dur: 2.5 }], ['ring', { n: 14, waves: 2, col: '#b0b0c0' }], ['summon', { type: 'pmouse', n: 5, max: 10 }]] },
      { at: 0.66, spd: 1.2, attacks: [['suck', { dur: 3 }], ['charge', { repeat: 3 }], ['spiral', { arms: 3, col: '#c0c0d0' }], ['ring', { n: 18, waves: 2, col: '#b0b0c0' }]] },
      { at: 0.33, spd: 1.35, attacks: [['suck', { dur: 3.5, ring: true }], ['charge', { repeat: 4 }], ['ring', { n: 20, waves: 3, col: '#b0b0c0' }], ['wave', { n: 2 }]] },
    ],
  },
  speaker: {
    name: 'Колонка-Шептунья', sub: 'Страж Кухни', r: 34, ttk: 55, hit: 0.08, touch: 0.12, spd: 70, move: 'hover', fly: true, col: '#2a2a3a',
    lines: {
      intro: '…ьсяйоб ен… Ой. Не бойся. Я просто включаю колыбельную… задом наперёд. 🔊',
      stages: ['', 'Громкость: двести процентов. Шёпот: ВЕЗДЕ.', 'Сейчас ты услышишь то, что нельзя услышать…'],
      death: '…ьчон йонйокопс… спокойной ночи…',
      taunts: ['Ты слышишь? Это я. За тобой.', 'Мяу.exe передаёт привет. Шёпотом.', 'Повторяю задом наперёд: УРУМ!'],
    },
    stages: [
      { attacks: [['wave', { n: 2 }], ['ring', { n: 16, waves: 2, col: '#8ad0ff' }], ['aimed', { count: 10, col: '#8ad0ff' }], ['invert', { dur: 2.5 }]] },
      { at: 0.66, spd: 1.2, attacks: [['wave', { n: 3 }], ['spiral', { arms: 4, col: '#8ad0ff' }], ['invert', { dur: 3 }], ['summon', { type: 'bitfly', n: 4, max: 8 }]] },
      { at: 0.33, spd: 1.35, attacks: [['wave', { n: 4 }], ['spiral', { arms: 5, col: '#c08aff' }], ['invert', { dur: 3 }], ['ring', { n: 22, waves: 3, col: '#8ad0ff' }], ['laser', { beams: 2, rot: 0.8 }]] },
    ],
  },
  tv: {
    name: 'Телевизор-Помеха', sub: 'Страж Гостиной', r: 42, ttk: 60, hit: 0.085, touch: 0.14, spd: 62, move: 'hover', fly: true, col: '#2a2a2a',
    lines: {
      intro: 'ШШШШ… Канал 13: «Кошка, которая не спит». В главной роли – ТЫ. 📺',
      stages: ['', 'Переключаю на канал УЖАСОВ!', 'Сигнала нет. Есть только Я.'],
      death: 'Конец… передачи… ШШШ…',
      taunts: ['Не переключай! Сейчас будет страшно.', 'Я вижу тебя через экран.', 'Пульт? Пульт у меня. Навсегда.'],
    },
    stages: [
      { attacks: [['laser', { beams: 1, rot: 0.8 }], ['static', { dur: 2.5 }], ['glitch', { n: 3 }], ['summon', { type: 'bitfly', n: 4, max: 8 }]] },
      { at: 0.66, spd: 1.2, attacks: [['laser', { beams: 2, rot: 0.9 }], ['static', { dur: 3 }], ['pixels', { n: 1 }], ['aimed', { count: 12, square: true, col: '#e0e0e0' }]] },
      { at: 0.33, spd: 1.35, attacks: [['laser', { beams: 3, rot: 1.0, rainbow: true }], ['static', { dur: 3 }], ['pixels', { n: 2 }], ['glitch', { n: 5 }], ['cross', {}]] },
    ],
  },
  mirrortessa: {
    name: 'Зеркальная Тесса', sub: 'Стража Ванной', r: 30, ttk: 60, hit: 0.085, touch: 0.13, spd: 120, move: 'chase', col: '#1a1a2a',
    lines: {
      intro: 'Мяу. Я – это ты. Только я не сплю. Никогда. 🪞',
      stages: ['', 'Почему ты моргаешь первой?', 'Отражение больше не повторяет за тобой.'],
      death: 'Ты… настоящая… а я… просто… блик…',
      taunts: ['Повернись. Я уже за спиной.', 'Твои глаза голубые. Мои – пустые.', 'Мяу?.. Мяу.'],
    },
    stages: [
      { attacks: [['charge', { repeat: 2, spd: 720 }], ['teleport', { ringN: 10 }], ['shotgun', { n: 7, waves: 2, col: '#8ad0ff' }]] },
      { at: 0.66, spd: 1.2, attacks: [['mirrors', { n: 3 }], ['charge', { repeat: 3, spd: 760 }], ['teleport', { ringN: 14 }], ['invert', { dur: 2.5 }]] },
      { at: 0.33, spd: 1.35, attacks: [['charge', { repeat: 4, spd: 800 }], ['teleport', { ringN: 18 }], ['shotgun', { n: 9, waves: 3, col: '#8ad0ff' }], ['summon', { type: 'shadowcat', n: 3, max: 5 }]] },
    ],
  },
  meow2: {
    name: 'Мяу.exe 2.0', sub: 'Вирус, который стал котом', r: 50, ttk: 80, hit: 0.08, touch: 0.12, spd: 100, move: 'chase', col: '#3ff0a0',
    final: true, avatar: 'glitchcat', music: 'meowboss',
    lines: {
      intro: 'Мяу. Мяу. МЯУ. Я – копия самого милого существа в мире. Но копия ЛУЧШЕ. 🐱💻',
      stages: ['', 'Почему гладят ТЕБЯ, а не МЕНЯ?!', 'Ошибка: одиночество.exe. Удалить? НЕ-Е-ЕТ!', 'Я просто хотел… чтобы меня тоже… погладили… 😿'],
      death: 'Мяу… ты… не удалишь меня?..',
      taunts: ['Я видел тебя через каждый экран в доме.', 'Твоя миска – моя миска.', 'Мур.exe не найден.', 'Ты спишь двадцать часов. Я – ни минуты.'],
    },
    stages: [
      { attacks: [['pixels', { n: 1 }], ['glitch', { n: 3 }], ['aimed', { count: 12, square: true, col: '#3ff0a0' }], ['summon', { type: 'pmouse', n: 5, max: 10 }]] },
      { at: 0.75, spd: 1.15, attacks: [['pixels', { n: 2 }], ['invert', { dur: 2.5 }], ['spiral', { arms: 4, square: true, col: '#3ff0a0' }], ['laser', { beams: 2, rot: 0.9 }]] },
      { at: 0.5, spd: 1.25, attacks: [['static', { dur: 3 }], ['glitch', { n: 5 }], ['ring', { n: 22, waves: 3, square: true, col: '#ff3ea5' }], ['summon', { type: 'shadowcat', n: 3, max: 5 }], ['charge', { repeat: 3 }]] },
      { at: 0.25, spd: 1.4, attacks: [['pixels', { n: 2, both: true }], ['laser', { beams: 3, rot: 1.0, rainbow: true }], ['invert', { dur: 3 }], ['spiral', { arms: 6, square: true, rainbow: true }], ['homing', { n: 6, heart: true }]] },
    ],
  },
  // ---------------- Боссы главы 5 ----------------
  cucumber: {
    name: 'Великий Огурец', sub: 'Страж Кухни', r: 40, ttk: 55, hit: 0.075, touch: 0.13, spd: 75, move: 'chase', col: '#3f9a3f',
    lines: {
      intro: 'БУ! 🥒 Что, испугалась? Все кошки боятся огурцов!',
      stages: ['', 'Я не просто огурец. Я МАЛОСОЛЬНЫЙ!', 'Зови меня Огурец Рассолович! БУ-БУ-БУ!'],
      death: 'Я… просто… хотел… в салат… И корм я не брал!',
      taunts: ['Бу! Опять бу!', 'Я зелёный и пупырчатый, а ты?', 'Корм? Какой корм? Я ем только солнце.'],
    },
    stages: [
      { attacks: [['leap', { r: 110 }], ['ring', { n: 14, waves: 2, col: '#7dd87d' }], ['summon', { type: 'cuke', n: 3, max: 6 }], ['charge', { repeat: 2 }]] },
      { at: 0.66, spd: 1.2, attacks: [['leap', { r: 120, repeat: 2, ringN: 12 }], ['stomp', { r: 150 }], ['shotgun', { n: 7, waves: 3, col: '#7dd87d' }], ['summon', { type: 'cuke', n: 4, max: 8 }]] },
      { at: 0.33, spd: 1.35, attacks: [['leap', { r: 130, repeat: 3, ringN: 14 }], ['charge', { repeat: 3 }], ['ring', { n: 20, waves: 3, col: '#7dd87d' }], ['wave', { n: 2 }]] },
    ],
  },
  laserdot: {
    name: 'Лазерная Точка', sub: 'Стража Гостиной', r: 22, ttk: 50, hit: 0.07, touch: 0.1, spd: 170, move: 'hover', fly: true, col: '#ff2a2a',
    lines: {
      intro: 'Поймай меня! Не поймаешь! Меня никто никогда не ловил! 🔴',
      stages: ['', 'Быстрее! Ещё быстрее! Ты что, устала?', 'Меня ВООБЩЕ нельзя поймать. Это закон физики!'],
      death: 'Ой… ты… поймала… меня?! Корм не я… я же просто свет…',
      taunts: ['Тут! Нет, тут! Нет, ТУТ!', 'Вжух!', 'Ни одна кошка не устоит!'],
    },
    stages: [
      { attacks: [['charge', { repeat: 3, spd: 820 }], ['laser', { beams: 1, rot: 1.0 }], ['teleport', { ringN: 8 }], ['aimed', { count: 10, spd: 320, col: '#ff4a4a' }]] },
      { at: 0.66, spd: 1.2, attacks: [['charge', { repeat: 4, spd: 860, trail: true }], ['laser', { beams: 2, rot: 1.1 }], ['teleport', { ringN: 12 }], ['cross', {}]] },
      { at: 0.33, spd: 1.35, attacks: [['charge', { repeat: 5, spd: 900, trail: true }], ['laser', { beams: 3, rot: 1.2 }], ['teleport', { ringN: 16 }], ['spiral', { arms: 4, col: '#ff4a4a' }]] },
    ],
  },
  pigeonboss: {
    name: 'Голубь-Мафиози', sub: 'Страж Сада', r: 36, ttk: 55, hit: 0.08, touch: 0.12, spd: 110, move: 'hover', fly: true, col: '#8a8ea0',
    emojiSet: ['🍞', '🥖', '🪶'],
    lines: {
      intro: 'Курлык. Ты в моём саду, киса. Тут всё по понятиям: крошки – мои. 🕶️',
      stages: ['', 'Ребята, на выход! Курлык!', 'Ты не оставляешь мне выбора… ФИРМЕННОЕ ПИКЕ!'],
      death: 'Курлы… ладно, корм не мы брали. Ищи в кладовой, киса…',
      taunts: ['Курлык – это не вопрос, это ответ.', 'Семья – это главное. И крошки.', 'Шляпа не для красоты.'],
    },
    stages: [
      { attacks: [['aimed', { count: 10, emoji: true }], ['summon', { type: 'pigeon', n: 4, max: 8 }], ['rain', { n: 10 }], ['homing', { n: 4 }]] },
      { at: 0.66, spd: 1.2, attacks: [['shotgun', { n: 7, waves: 3, emoji: true }], ['charge', { repeat: 3, spd: 760 }], ['rain', { n: 14 }], ['summon', { type: 'pigeon', n: 5, max: 9 }]] },
      { at: 0.33, spd: 1.35, attacks: [['charge', { repeat: 4, spd: 820 }], ['spiral', { arms: 5, emoji: true }], ['rain', { n: 18 }], ['homing', { n: 6 }], ['wave', { n: 2 }]] },
    ],
  },
  baron: {
    name: 'Пёс Барон', sub: 'Страж Двора', r: 42, ttk: 60, hit: 0.085, touch: 0.15, spd: 90, move: 'chase', col: '#a0704a',
    emojiSet: ['🦴'],
    lines: {
      intro: 'ГАВ! Это МОЙ двор, кошка! И мой забор! И моя будка! 🐕',
      stages: ['', 'Гав-гав! Сейчас я буду лаять ГРОМЧЕ!', 'Р-р-р… ладно, честно: я просто хотел поиграть…'],
      death: 'Скулю… Ладно, ты хорошая. Корм не брал, честное собачье!',
      taunts: ['Кто хороший мальчик? Я!', 'Косточка моя!', 'Гав. Гав. ГАВ!'],
    },
    stages: [
      { attacks: [['charge', { repeat: 2, spd: 740 }], ['wave', { n: 2 }], ['shotgun', { n: 7, waves: 2, emoji: true }], ['stomp', { r: 140 }]] },
      { at: 0.66, spd: 1.2, attacks: [['charge', { repeat: 3, spd: 780 }], ['wave', { n: 3 }], ['aimed', { count: 12, emoji: true }], ['leap', { r: 120, ringN: 12 }]] },
      { at: 0.33, spd: 1.35, attacks: [['charge', { repeat: 4, spd: 820 }], ['wave', { n: 4 }], ['spiral', { arms: 4, emoji: true }], ['stomp', { r: 170, repeat: 2 }]] },
    ],
  },
  zyamabot: {
    name: 'Зямочкккк и Кормотрон', sub: 'Повелитель Кладовой', r: 52, ttk: 85, hit: 0.075, touch: 0.12, spd: 80, move: 'hover', fly: true, col: '#ffd25a',
    final: true, avatar: 'zyama', emojiSet: ['🐟', '🍪', '🥫', '🍗'], music: 'final5',
    lines: {
      intro: 'Та-да-а-ам! Да, это я спрятал корм! Но не со зла – ради БАНКЕТА в твою честь, Тесса! Сначала победи Кормотрон! 🤖🍽️',
      stages: ['', 'Кормотрон, режим «Щедрая подача»! 🐟', 'Он вышел из-под контроля! Я просто хотел, чтобы ты меня полюбила!', 'ВСЁ! Банкет начинается ПРЯМО СЕЙЧАС!!! 🎉'],
      death: 'Ну вот… сюрприз испорчен… Но банкет-то всё равно будет? 🥺',
      taunts: ['Я написал тебе оду: «О Тесса, ты прекрасна, как сметана…»', 'Корм в безопасности! Почти.', 'Кормотрон, не так быстро!', 'Можно я тебя поглажу? Нет? Ладно.'],
    },
    stages: [
      { attacks: [['rain', { n: 12 }], ['aimed', { count: 12, emoji: true }], ['summon', { type: 'mouse', n: 5, max: 10 }], ['charge', { repeat: 2 }]] },
      { at: 0.75, spd: 1.15, attacks: [['spiral', { arms: 5, emoji: true }], ['laser', { beams: 2, rot: 0.9 }], ['rain', { n: 14 }], ['shotgun', { n: 8, waves: 3, emoji: true }]] },
      { at: 0.5, spd: 1.25, attacks: [['wave', { n: 3 }], ['homing', { n: 6, heart: true }], ['charge', { repeat: 3 }], ['ring', { n: 22, waves: 3, emoji: true }], ['summon', { type: 'yarn', n: 3, max: 6 }]] },
      { at: 0.25, spd: 1.4, attacks: [['spiral', { arms: 6, dur: 3.5, emoji: true }], ['laser', { beams: 3, rot: 1.05, rainbow: true }], ['rain', { n: 16 }], ['homing', { n: 6, heart: true }], ['wave', { n: 3 }]] },
    ],
  },
});
BOSS_TAUNTS.vacuum = BOSSES.vacuum.lines.taunts;

// ---------------- Главы 4 и 5 ----------------
CHAPTERS[4] = {
  id: 4, title: 'Глава 4', name: 'Ночь глитчей', seed: 4400044, MW: 160, MH: 160, blobs: 110,
  start: { x: 80, y: 148 },
  bossTiles: [{ x: 24, y: 124 }, { x: 26, y: 36 }, { x: 134, y: 30 }, { x: 136, y: 124 }, { x: 80, y: 62 }],
  bosses: ['vacuum', 'speaker', 'tv', 'mirrortessa', 'meow2'],
  castle: { x: 80, y: 68, half: 15, gate: 'south', biome: 19 }, cage: { x: 80, y: 58 }, noCage: true,
  biomeSeeds: [
    [14, 80, 148], [14, 60, 140], [14, 100, 140], [14, 80, 126],
    [15, 24, 124], [15, 40, 104], [15, 18, 92], [15, 46, 150],
    [16, 26, 36], [16, 16, 64], [16, 46, 20], [16, 44, 58],
    [17, 134, 30], [17, 110, 18], [17, 150, 60], [17, 116, 48],
    [18, 136, 124], [18, 150, 96], [18, 120, 146], [18, 152, 150],
    [19, 80, 68], [19, 80, 50], [19, 64, 70], [19, 96, 70],
  ],
  chests: 18, chestDist: [8, 24], shrines: 7, elite: 0.1, spawnEvery: 0.32, capBase: 22,
  zoneLevel: { 14: 4, 15: 6, 16: 10, 17: 14, 18: 18, 19: 22 }, bossLevels: [6, 10, 14, 18, 24], diff: { hp: 1.5, dmg: 1.4 },
  hero: 'tessa', hostage: 'tessa', music: 'night4', startLevel: 1,
  dark: true, beds: 9, lamps: 16, noEvents: ['meteor', 'song'],
  gateSay: 'Мрр… Все стражи затихли. Дверь на чердак скрипнула и открылась…', gateBanner: 'Чердак открыт',
  deadText: 'Мяу.exe смеётся в темноте… Попробуй снова –<br>уровень и улучшения сохранятся.',
};
CHAPTERS[5] = {
  id: 5, title: 'Глава 5', name: 'Пропавший корм', seed: 5500055, MW: 170, MH: 170, blobs: 120,
  start: { x: 85, y: 158 },
  bossTiles: [{ x: 30, y: 136 }, { x: 30, y: 44 }, { x: 140, y: 40 }, { x: 142, y: 132 }, { x: 85, y: 78 }],
  bosses: ['cucumber', 'laserdot', 'pigeonboss', 'baron', 'zyamabot'],
  castle: { x: 85, y: 82, half: 13, gate: 'south', biome: 25 }, cage: { x: 85, y: 74 }, noCage: true,
  biomeSeeds: [
    [20, 85, 158], [20, 60, 150], [20, 30, 136], [20, 110, 152],
    [22, 20, 100], [22, 50, 110], [22, 44, 82],
    [21, 30, 44], [21, 16, 20], [21, 56, 28], [21, 60, 58],
    [23, 140, 40], [23, 110, 20], [23, 160, 70], [23, 118, 58],
    [24, 142, 132], [24, 160, 105], [24, 125, 152], [24, 120, 112],
    [25, 85, 82], [25, 85, 68], [25, 72, 82], [25, 98, 82],
  ],
  chests: 20, chestDist: [8, 26], shrines: 7, elite: 0.09, spawnEvery: 0.32, capBase: 22,
  zoneLevel: { 20: 4, 21: 8, 22: 6, 23: 12, 24: 16, 25: 20 }, bossLevels: [6, 10, 14, 18, 24], diff: { hp: 1.6, dmg: 1.5 },
  hero: 'tessa', hostage: 'tessa', music: 'morning5', startLevel: 1,
  beds: 8, detective: true, boxes: 26, shelves: 6, noEvents: ['meteor'],
  gateSay: 'Все подозреваемые допрошены… Пора собрать улики на доске!', gateBanner: 'Кладовая открыта',
  deadText: 'Тесса свернулась клубочком… Попробуй снова –<br>уровень и улучшения сохранятся.',
};

// Улики главы 5: по 3 у каждого стража; третья всегда намекает на настоящего виновника
const CLUES5 = [
  [['🐾', 'Мокрые следы… пахнет огуречным рассолом.'], ['🥒', 'Огуречная кожура прямо у пустой миски!'], ['✨', 'Блёстки на полу… как от брекетов. Странно.']],
  [['🔴', 'На стене дрожит красная точка… Она что-то видела?'], ['🧶', 'Нитка от клубка тянется под диван.'], ['☕', 'Пахнет какао. Кто-то пил какао посреди ночи…']],
  [['🪶', 'Серое перо у кормушки.'], ['🍞', 'Крошки хлеба выложены стрелочкой… к кладовой.'], ['📜', 'Обрывок бумаги: «О Тесса, ты прекрасна, как сметана…»']],
  [['🦴', 'Обглоданная косточка. Барон был тут!'], ['👣', 'Большие собачьи следы… а рядом – следы тапочек.'], ['🎭', 'Театральная программка: «Банкет-сюрприз. Режиссёр – З.»']],
];
const SUSPECTS = [
  { id: 'cucumber', ic: '🥒', name: 'Великий Огурец' }, { id: 'laserdot', ic: '🔴', name: 'Лазерная Точка' },
  { id: 'pigeonboss', ic: '🐦', name: 'Голубь-Мафиози' }, { id: 'baron', ic: '🐕', name: 'Пёс Барон' },
  { id: 'zyama', ic: '🎭', name: 'Зямочкккк' },
];
// Жители главы 5: разговоры с выбором и маленькие поручения
const NPCS5 = [
  { id: 'pik', name: 'Мышонок Пик', ic: '🐭', biome: 20, item: { ic: '🧀', name: 'сыр' },
    greet: 'Ой! Тесса! Только не ешь меня, я невкусный и очень маленький!',
    hint: 'Ночью кто-то шуршал у мисок… в тапочках! Мыши тапочки не носят!',
    quest: 'Я потерял сыр… Большой, с дырочками. Найдёшь – расскажу секрет!',
    pet: 'Ты потёрлась об меня носом?! Это самый страшный и самый милый момент в моей жизни.',
    thanks: 'Мой сыр! Спасибо, Тесса! Держи – это от всей мышиной семьи!' },
  { id: 'gulya', name: 'Голубка Гуля', ic: '🕊️', biome: 23, item: { ic: '👒', name: 'шляпка' },
    greet: 'Курлы-курлы, красавица! Только не охоться на меня, я на диете.',
    hint: 'Голубь-Мафиози, конечно, ворует крошки… но корм? Это не его уровень.',
    quest: 'Ветер унёс мою шляпку! Без неё я просто голубь. Поможешь?',
    pet: 'Мурчишь? Как приятно! Голуби тоже умеют мурчать. Курлычать. Почти одно и то же.',
    thanks: 'Моя шляпка! Ты лучшая кошка на свете, Тесса! Вот, возьми.' },
  { id: 'shurshik', name: 'Ёжик Шуршик', ic: '🦔', biome: 24, item: { ic: '🍎', name: 'яблоко' },
    greet: 'Ф-ф-ф! А, это ты, Тесса. Я думал, Барон опять пришёл нюхаться.',
    hint: 'Я видел ночью кого-то в блёстках. Он тащил мешок корма и… напевал оду?',
    quest: 'Я уронил яблоко, и оно укатилось. Ёжики плохо бегают за яблоками.',
    pet: 'Не трогай носом – колючки! …Ладно, можно немножко.',
    thanks: 'Яблочко! Спасибо! Ты добрая. Или хорошая? Это вообще одно и то же?' },
];
// Гардероб Тессы
const WARDROBE = [
  { id: 'none', ic: '🐈', name: 'Без наряда', how: '' },
  { id: 'bow', ic: '🎀', name: 'Бантик', how: 'Пройди главу 4' },
  { id: 'hat', ic: '🕵️', name: 'Шапка детектива', how: 'Начни главу 5' },
  { id: 'bell', ic: '🔔', name: 'Ошейник с колокольчиком', how: 'Помоги любому жителю в главе 5' },
  { id: 'glasses', ic: '👓', name: 'Очки', how: 'Найди виновного на доске подозреваемых' },
  { id: 'crown', ic: '👑', name: 'Корона', how: 'Победи 10 чемпионов' },
];

// =====================================================================
//  Графика
// =====================================================================
let TESSA_OUTFIT = 'none';
// Сиамская кошка: светлая шерсть, тёмные «отметины», голубые глаза
const TESSA_PAL = { body: '#f2e6d4', shade: '#d8c8b0', point: '#5a4034', eye: '#5ab8ff', nose: '#ff9db5' };
const SHADOW_PAL = { body: '#2a2a3a', shade: '#1a1a26', point: '#0a0a12', eye: '#ffffff', nose: '#3a3a4a' };
function drawTessa(c, x, y, t, face, s = 1, alpha = 1, moving = false, pal = TESSA_PAL, outfit = TESSA_OUTFIT) {
  c.save(); c.translate(x, y); c.scale(s * face, s); c.globalAlpha = alpha;
  const bob = moving ? Math.abs(Math.sin(t * 14)) * 1.6 : Math.sin(t * 2) * 0.4;
  const st = moving ? Math.sin(t * 16) * 2.5 : 0;
  // хвост
  const sw = Math.sin(t * (moving ? 9 : 2.5)) * 0.35;
  c.strokeStyle = pal.point; c.lineWidth = 3.6; c.lineCap = 'round';
  c.beginPath(); c.moveTo(-9, 1 - bob); c.quadraticCurveTo(-17, -2 + sw * 8, -15 + sw * 6, -13); c.stroke();
  // лапы
  c.fillStyle = pal.point;
  c.fillRect(-8, 5 + st * 0.5, 3.2, 6); c.fillRect(-3, 5 - st * 0.5, 3.2, 6);
  c.fillRect(3, 5 + st * 0.5, 3.2, 6); c.fillRect(7, 5 - st * 0.5, 3.2, 6);
  c.translate(0, -bob);
  // тело
  const bodyG = c.createRadialGradient(-3, -2, 1, 0, 2, 12); bodyG.addColorStop(0, shade(pal.body, 0.18)); bodyG.addColorStop(1, shade(pal.body, -0.12));
  c.fillStyle = bodyG; c.strokeStyle = shade(pal.body, -0.45); c.lineWidth = 1.4;
  c.beginPath(); c.ellipse(0, 2, 11, 7, 0, 0, TAU); c.fill(); c.stroke();
  c.fillStyle = pal.shade; c.beginPath(); c.ellipse(-3, 5, 7, 3, 0, 0, TAU); c.fill();
  // голова
  const hx = 8, hy = -7;
  c.fillStyle = pal.point;
  c.beginPath(); c.moveTo(hx - 7, hy - 3); c.lineTo(hx - 6, hy - 12); c.lineTo(hx - 1.5, hy - 6); c.fill();
  c.beginPath(); c.moveTo(hx + 7, hy - 3); c.lineTo(hx + 6.5, hy - 12); c.lineTo(hx + 1.5, hy - 6); c.fill();
  const headG = c.createRadialGradient(hx - 2.5, hy - 3, 1, hx, hy, 8); headG.addColorStop(0, shade(pal.body, 0.2)); headG.addColorStop(1, shade(pal.body, -0.1));
  c.fillStyle = headG; c.beginPath(); c.arc(hx, hy, 7.6, 0, TAU); c.fill(); c.stroke();
  // тёмная «маска» на мордочке
  const mg = c.createRadialGradient(hx + 1, hy + 2, 0.5, hx + 1, hy + 2, 6.5);
  mg.addColorStop(0, pal.point); mg.addColorStop(1, 'rgba(0,0,0,0)');
  c.fillStyle = mg; c.beginPath(); c.arc(hx + 1, hy + 2, 6.5, 0, TAU); c.fill();
  // глаза
  const blink = Math.sin(t * 0.9 + 1.3) > 0.985;
  if (blink) { c.strokeStyle = pal.eye; c.lineWidth = 1.2; c.beginPath(); c.moveTo(hx - 3.5, hy - 1); c.lineTo(hx - 0.8, hy - 1); c.moveTo(hx + 2, hy - 1); c.lineTo(hx + 4.7, hy - 1); c.stroke(); }
  else {
    c.fillStyle = pal.eye;
    c.beginPath(); c.ellipse(hx - 2.2, hy - 1, 1.7, 2.1, 0, 0, TAU); c.ellipse(hx + 3.3, hy - 1, 1.7, 2.1, 0, 0, TAU); c.fill();
    c.fillStyle = pal === TESSA_PAL ? '#10203a' : '#ffffff';
    c.fillRect(hx - 2.6, hy - 2.4, 0.9, 2.8); c.fillRect(hx + 2.9, hy - 2.4, 0.9, 2.8);
    c.fillStyle = 'rgba(255,255,255,0.95)'; c.beginPath(); c.arc(hx - 1.4, hy - 2.1, 0.65, 0, TAU); c.arc(hx + 4.1, hy - 2.1, 0.65, 0, TAU); c.fill();
    c.fillStyle = 'rgba(255,255,255,0.5)'; c.beginPath(); c.arc(hx - 2.9, hy, 0.35, 0, TAU); c.arc(hx + 2.6, hy, 0.35, 0, TAU); c.fill(); // блеск глаз
  }
  c.fillStyle = pal.nose; c.beginPath(); c.moveTo(hx + 0.2, hy + 2); c.lineTo(hx + 2, hy + 2); c.lineTo(hx + 1.1, hy + 3.2); c.fill();
  c.fillStyle = 'rgba(255,255,255,0.7)'; c.fillRect(hx + 0.6, hy + 2.1, 0.6, 0.4); // влажный нос
  c.strokeStyle = 'rgba(255,255,255,0.7)'; c.lineWidth = 0.6;
  c.beginPath(); c.moveTo(hx + 4, hy + 2.5); c.lineTo(hx + 10, hy + 1.5); c.moveTo(hx + 4, hy + 3.5); c.lineTo(hx + 10, hy + 4); c.stroke();
  // наряды
  if (outfit === 'bow') {
    c.fillStyle = '#ff3b6b';
    c.beginPath(); c.moveTo(hx - 4, hy - 8); c.lineTo(hx - 9, hy - 11); c.lineTo(hx - 9, hy - 5); c.closePath(); c.fill();
    c.beginPath(); c.moveTo(hx - 4, hy - 8); c.lineTo(hx + 1, hy - 11); c.lineTo(hx + 1, hy - 5); c.closePath(); c.fill();
    c.fillStyle = '#ffd25a'; c.beginPath(); c.arc(hx - 4, hy - 8, 1.5, 0, TAU); c.fill();
  } else if (outfit === 'bell') {
    c.fillStyle = '#e53935'; c.fillRect(hx - 6, hy + 5, 9, 2);
    c.fillStyle = '#ffd25a'; c.beginPath(); c.arc(hx - 1, hy + 8.5, 2, 0, TAU); c.fill();
  } else if (outfit === 'hat') {
    c.fillStyle = '#8a6a3a'; c.beginPath(); c.ellipse(hx, hy - 6, 9, 3, 0, 0, TAU); c.fill();
    c.beginPath(); c.arc(hx, hy - 7, 6.5, Math.PI, TAU); c.fill();
    c.strokeStyle = '#5a4020'; c.lineWidth = 0.8; c.beginPath(); c.moveTo(hx - 5, hy - 9); c.lineTo(hx + 5, hy - 9); c.moveTo(hx - 3, hy - 12); c.lineTo(hx - 3, hy - 7); c.moveTo(hx + 2, hy - 12); c.lineTo(hx + 2, hy - 7); c.stroke();
  } else if (outfit === 'glasses') {
    c.strokeStyle = '#2a2a3a'; c.lineWidth = 1;
    c.beginPath(); c.arc(hx - 2.2, hy - 1, 2.6, 0, TAU); c.moveTo(hx + 5.9, hy - 1); c.arc(hx + 3.3, hy - 1, 2.6, 0, TAU); c.moveTo(hx + 0.4, hy - 1); c.lineTo(hx + 0.7, hy - 1); c.stroke();
  } else if (outfit === 'crown') {
    c.fillStyle = '#ffd25a'; c.strokeStyle = '#b8860b'; c.lineWidth = 0.8;
    c.beginPath(); c.moveTo(hx - 5, hy - 7); c.lineTo(hx - 5, hy - 12); c.lineTo(hx - 2.5, hy - 9); c.lineTo(hx, hy - 13); c.lineTo(hx + 2.5, hy - 9); c.lineTo(hx + 5, hy - 12); c.lineTo(hx + 5, hy - 7); c.closePath(); c.fill(); c.stroke();
  }
  c.lineCap = 'butt';
  c.restore();
}
// подключаем Тессу к общим функциям героинь
(() => {
  const baseDraw = drawHero;
  drawHero = function (id, c, x, y, t, face, s, alpha, moving) {
    if (id === 'tessa') drawTessa(c, x, y, t, face, s * 1.3, alpha, moving);
    else baseDraw(id, c, x, y, t, face, s, alpha, moving);
  };
  const basePortrait = heroPortrait;
  heroPortrait = function (id, size = 116) {
    if (id !== 'tessa') return basePortrait(id, size);
    const cv = makeCanvas(size, size), c = cv.getContext('2d');
    const g = c.createRadialGradient(size / 2, size / 2, 4, size / 2, size / 2, size * 0.7);
    g.addColorStop(0, '#2a4a7a'); g.addColorStop(1, '#0a1428');
    c.fillStyle = g; c.fillRect(0, 0, size, size);
    drawTessa(c, size / 2, size * 0.72, 0.4, 1, size / 34, 1, false);
    return cv;
  };
})();
// Удар когтями: светлый полумесяц
function drawClaw(c, f) {
  const a = Math.atan2(f.vy, f.vx), k = clamp(f.life / (f.life0 || 0.3), 0, 1);
  c.save(); c.translate(f.x, f.y); c.rotate(a);
  c.globalAlpha = 0.35 + k * 0.65;
  for (let i = -1; i <= 1; i++) {
    c.strokeStyle = i === 0 ? '#ffffff' : 'rgba(190,230,255,0.8)'; c.lineWidth = i === 0 ? 3 : 2;
    c.beginPath(); c.arc(-6, i * 5, 12, -0.9, 0.9); c.stroke();
  }
  c.restore(); c.globalAlpha = 1;
}

// ---------- «деревья»: мебель и сад ----------
(() => {
  const S = 2;
  const make = (fn) => { const cv = makeCanvas(64 * S, 84 * S), c = cv.getContext('2d'); c.scale(S, S); shadow(c, 32, 79, 16, 5); fn(c); return cv; };
  TREE_SPR.plant = make(c => {
    c.fillStyle = '#c0603a'; c.beginPath(); c.moveTo(20, 60); c.lineTo(44, 60); c.lineTo(40, 80); c.lineTo(24, 80); c.closePath(); c.fill();
    c.fillStyle = '#a04a2a'; c.fillRect(19, 58, 26, 5);
    c.strokeStyle = '#2f7d32'; c.lineWidth = 3;
    for (const [dx, dy] of [[-14, -30], [-6, -42], [4, -44], [14, -32], [-18, -18], [18, -16]]) {
      c.beginPath(); c.moveTo(32, 60); c.quadraticCurveTo(32 + dx * 0.3, 60 + dy * 0.6, 32 + dx, 60 + dy); c.stroke();
      c.fillStyle = '#4caf50'; c.beginPath(); c.ellipse(32 + dx, 60 + dy, 6, 3, Math.atan2(dy, dx), 0, TAU); c.fill();
    }
  });
  TREE_SPR.floorlamp = make(c => {
    c.fillStyle = '#3a3a44'; c.fillRect(30, 30, 4, 48); c.fillRect(22, 76, 20, 4);
    c.fillStyle = '#e8d8b0'; c.beginPath(); c.moveTo(18, 30); c.lineTo(46, 30); c.lineTo(40, 12); c.lineTo(24, 12); c.closePath(); c.fill();
    c.strokeStyle = '#a89870'; c.lineWidth = 1.5; c.stroke();
    c.fillStyle = 'rgba(255,220,140,0.35)'; c.beginPath(); c.ellipse(32, 32, 14, 4, 0, 0, TAU); c.fill();
  });
  TREE_SPR.chair = make(c => {
    c.fillStyle = '#8a5a34'; c.strokeStyle = '#5a3a20'; c.lineWidth = 1.5;
    c.fillRect(18, 22, 5, 58); c.fillRect(41, 22, 5, 58);
    roundRect(c, 18, 22, 28, 22, 3); c.fill(); c.stroke();
    c.fillStyle = '#a06a40'; roundRect(c, 14, 50, 36, 8, 3); c.fill(); c.stroke();
    c.fillStyle = '#7a4a2a'; c.fillRect(16, 58, 4, 22); c.fillRect(44, 58, 4, 22);
    c.fillStyle = 'rgba(255,255,255,0.15)'; c.fillRect(22, 26, 20, 3);
  });
  TREE_SPR.books = make(c => {
    const cols = ['#c0392b', '#2980b9', '#27ae60', '#8e44ad', '#f39c12', '#16a085'];
    for (let i = 0; i < 6; i++) {
      const w = 30 - (i % 3) * 3, x = 32 - w / 2 + ((i * 7) % 5) - 2;
      c.fillStyle = cols[i]; c.fillRect(x, 74 - i * 9, w, 8);
      c.fillStyle = 'rgba(255,255,255,0.35)'; c.fillRect(x + 2, 76 - i * 9, w - 4, 1.5);
    }
  });
  TREE_SPR.basket = make(c => {
    c.fillStyle = '#c8a070'; c.strokeStyle = '#8a6a40'; c.lineWidth = 1.5;
    c.beginPath(); c.moveTo(16, 48); c.lineTo(48, 48); c.lineTo(44, 80); c.lineTo(20, 80); c.closePath(); c.fill(); c.stroke();
    for (let y = 54; y < 80; y += 6) { c.beginPath(); c.moveTo(18, y); c.lineTo(46, y); c.stroke(); }
    c.fillStyle = '#ff8ac0'; c.beginPath(); c.ellipse(28, 46, 10, 6, 0.3, 0, TAU); c.fill();
    c.fillStyle = '#8ad0ff'; c.beginPath(); c.ellipse(38, 44, 8, 5, -0.4, 0, TAU); c.fill();
  });
  TREE_SPR.boxes = make(c => {
    const box = (x, y, w, h) => {
      c.fillStyle = '#c8945a'; c.strokeStyle = '#8a6036'; c.lineWidth = 1.5;
      c.fillRect(x, y, w, h); c.strokeRect(x, y, w, h);
      c.fillStyle = '#d8a46a'; c.fillRect(x, y, w, 4);
      c.fillStyle = 'rgba(255,255,255,0.4)'; c.fillRect(x + w / 2 - 3, y, 6, h);
    };
    box(14, 54, 36, 26); box(20, 30, 26, 24); box(26, 12, 16, 18);
  });
  TREE_SPR.toyblocks = make(c => {
    const blk = (x, y, col, ch) => {
      c.fillStyle = col; c.fillRect(x, y, 16, 16); c.strokeStyle = shade(col, -0.4); c.lineWidth = 1.5; c.strokeRect(x, y, 16, 16);
      c.fillStyle = '#fff'; c.font = 'bold 11px sans-serif'; c.textAlign = 'center'; c.fillText(ch, x + 8, y + 12);
    };
    blk(16, 64, '#ff6a6a', 'Т'); blk(32, 64, '#ffd25a', 'Е'); blk(24, 48, '#6ac8ff', 'С'); blk(24, 32, '#7ad87a', 'А');
  });
  TREE_SPR.appletree = make(c => {
    c.fillStyle = '#6b4226'; c.fillRect(28, 50, 8, 30);
    for (const [x, y, r, col] of [[32, 30, 20, '#3f9a3f'], [20, 40, 13, '#358a35'], [44, 40, 13, '#358a35'], [32, 24, 14, '#4caf50']]) { c.fillStyle = col; c.beginPath(); c.arc(x, y, r, 0, TAU); c.fill(); }
    c.fillStyle = '#e53935'; for (const [x, y] of [[22, 34], [40, 28], [30, 42], [44, 44], [26, 22]]) { c.beginPath(); c.arc(x, y, 3, 0, TAU); c.fill(); }
  });
  TREE_SPR.bush = make(c => {
    for (const [x, y, r] of [[22, 64, 12], [42, 64, 12], [32, 56, 14]]) { c.fillStyle = '#3f8a3f'; c.beginPath(); c.arc(x, y, r, 0, TAU); c.fill(); }
    c.fillStyle = '#5aaa5a'; c.beginPath(); c.arc(30, 52, 7, 0, TAU); c.fill();
    c.fillStyle = '#ffffff'; for (const [x, y] of [[20, 60], [40, 58], [34, 68]]) { c.beginPath(); c.arc(x, y, 2, 0, TAU); c.fill(); }
  });
})();

// ---------- враги глав 4–5 ----------
Object.assign(ESPR, {
  pmouse(c, e) {
    c.scale(e.face || 1, 1);
    const px = (x, y, col) => { c.fillStyle = col; c.fillRect(x, y, 3, 3); };
    for (const [x, y] of [[-6, -3], [-3, -3], [0, -3], [3, -3], [-6, 0], [-3, 0], [0, 0], [3, 0], [6, 0], [-3, 3], [0, 3], [3, 3]]) px(x, y, '#7dffb0');
    px(3, -6, '#7dffb0'); px(6, -3, '#3a8a5a'); px(-9, 3, '#3a8a5a'); px(-12, 0, '#3a8a5a');
    c.fillStyle = Math.floor(e.t * 8) % 2 ? '#ff3ea5' : '#000'; c.fillRect(5, -2, 2, 2);
  },
  sock(c, e) {
    const sq = 1 + Math.sin(e.t * 12 + e.seed) * 0.1;
    c.scale(1 / sq, sq);
    c.fillStyle = '#c0c0d8'; c.strokeStyle = '#6a6a88'; c.lineWidth = 1.5;
    c.beginPath(); c.moveTo(-6, -14); c.lineTo(6, -14); c.lineTo(6, 2); c.quadraticCurveTo(12, 4, 12, 9); c.quadraticCurveTo(12, 13, 4, 13); c.lineTo(-6, 13); c.closePath(); c.fill(); c.stroke();
    c.fillStyle = '#ff6a8a'; c.fillRect(-6, -14, 12, 4); c.fillRect(-6, -6, 12, 2);
    c.fillStyle = '#1b1030'; c.beginPath(); c.arc(-2, 0, 1.6, 0, TAU); c.arc(3, 0, 1.6, 0, TAU); c.fill();
    c.strokeStyle = '#1b1030'; c.lineWidth = 1; c.beginPath(); c.arc(0.5, 5, 2.5, Math.PI + 0.3, TAU - 0.3); c.stroke();
  },
  staticball(c, e) {
    for (let i = 0; i < 26; i++) {
      const a = (i / 26) * TAU, r = 6 + ((i * 37 + Math.floor(e.t * 20)) % 7);
      c.fillStyle = (i + Math.floor(e.t * 15)) % 3 ? '#e8e8e8' : '#5a5a5a';
      c.fillRect(Math.cos(a) * r - 1.5, Math.sin(a) * r - 1.5, 3, 3);
    }
    c.fillStyle = '#2a2a2a'; c.beginPath(); c.arc(0, 0, 6, 0, TAU); c.fill();
    c.fillStyle = '#ffffff'; c.fillRect(-3, -2, 2, 2); c.fillRect(1, -2, 2, 2);
  },
  bitfly(c, e) {
    const f = Math.sin(e.t * 30) * 0.5;
    c.fillStyle = 'rgba(255,62,165,0.5)'; c.fillRect(-12, -4 - f * 4, 8, 6); c.fillRect(4, -4 + f * 4, 8, 6);
    c.fillStyle = '#ff3ea5'; c.fillRect(-4, -4, 8, 8);
    c.fillStyle = '#3ff0ff'; c.fillRect(-4, -4, 4, 4); c.fillStyle = '#ffffff'; c.fillRect(0, 0, 2, 2);
  },
  shadowcat(c, e) {
    c.globalAlpha *= 0.75 + Math.sin(e.t * 9) * 0.2;
    drawTessa(c, 0, 0, e.t, Math.cos(e.look) >= 0 ? 1 : -1, 1.05, 1, true, SHADOW_PAL, 'none');
  },
  toaster(c, e) {
    c.fillStyle = '#c0c4cc'; c.strokeStyle = '#6a6e78'; c.lineWidth = 1.5;
    roundRect(c, -13, -10, 26, 20, 5); c.fill(); c.stroke();
    c.fillStyle = '#2a2a2a'; c.fillRect(-9, -10, 6, 3); c.fillRect(3, -10, 6, 3);
    const up = e.cd < 0.3 ? 4 : 0;
    c.fillStyle = '#d8a050'; c.fillRect(-8, -14 - up, 4, 5); c.fillRect(4, -14 - up, 4, 5);
    c.fillStyle = Math.floor(e.t * 3) % 2 ? '#ff3b3b' : '#7a1a1a'; c.beginPath(); c.arc(9, 4, 2, 0, TAU); c.fill();
    c.fillStyle = '#1b1030'; c.beginPath(); c.arc(-5, 1, 1.6, 0, TAU); c.arc(1, 1, 1.6, 0, TAU); c.fill();
  },
  pigeon(c, e) {
    const f = Math.sin(e.t * 18) * 0.6;
    c.scale(Math.cos(e.look) >= 0 ? 1 : -1, 1);
    c.fillStyle = '#9aa0b0'; c.beginPath(); c.ellipse(-3, -6 - f * 4, 7, 3, -0.6 - f, 0, TAU); c.fill();
    c.fillStyle = '#b8bcc8'; c.beginPath(); c.ellipse(0, 0, 9, 6.5, 0, 0, TAU); c.fill();
    c.fillStyle = '#7a8a9a'; c.beginPath(); c.arc(7, -4, 4.5, 0, TAU); c.fill();
    c.fillStyle = '#5aa07a'; c.fillRect(4, -1, 6, 2);
    c.fillStyle = '#ffb03a'; c.beginPath(); c.moveTo(11, -4); c.lineTo(14, -3); c.lineTo(11, -2); c.fill();
    c.fillStyle = '#ff6a3a'; c.beginPath(); c.arc(8.5, -5, 1.3, 0, TAU); c.fill();
  },
  mouse(c, e) {
    c.scale(Math.cos(e.look) >= 0 ? 1 : -1, 1);
    c.strokeStyle = '#ff9db5'; c.lineWidth = 1.2; c.beginPath(); c.moveTo(-7, 2); c.quadraticCurveTo(-13, 0, -12, -5); c.stroke();
    c.fillStyle = '#a8a0a0'; c.beginPath(); c.ellipse(0, 1, 7, 5, 0, 0, TAU); c.fill();
    c.fillStyle = '#c8c0c0'; c.beginPath(); c.arc(-1, -4, 3, 0, TAU); c.arc(3, -4, 3, 0, TAU); c.fill();
    c.fillStyle = '#ff9db5'; c.beginPath(); c.arc(-1, -4, 1.5, 0, TAU); c.arc(3, -4, 1.5, 0, TAU); c.fill();
    c.fillStyle = '#1b1030'; c.beginPath(); c.arc(4, 0, 1.1, 0, TAU); c.fill();
    c.fillStyle = '#ff6a8a'; c.beginPath(); c.arc(7, 1.5, 1.2, 0, TAU); c.fill();
  },
  cuke(c, e) {
    c.rotate(Math.sin(e.t * 6 + e.seed) * 0.15);
    c.fillStyle = '#4caf50'; c.strokeStyle = '#2a6a2a'; c.lineWidth = 1.5;
    roundRect(c, -6, -14, 12, 28, 6); c.fill(); c.stroke();
    c.fillStyle = '#7ad87a'; for (const [x, y] of [[-3, -9], [2, -4], [-2, 3], [3, 8]]) { c.beginPath(); c.arc(x, y, 1.2, 0, TAU); c.fill(); }
    c.fillStyle = '#1b1030'; c.beginPath(); c.arc(-2, -6, 1.4, 0, TAU); c.arc(2.5, -6, 1.4, 0, TAU); c.fill();
    c.strokeStyle = '#1b1030'; c.lineWidth = 1; c.beginPath(); c.arc(0.3, -1, 2.5, 0.2, Math.PI - 0.2); c.stroke();
  },
  yarn(c, e) {
    const s = e.type === 'yarnlet' ? 0.7 : 1, col = e.type === 'yarnlet' ? '#ffb3d6' : '#ff6fb5';
    c.scale(s, s); c.rotate(e.t * 3);
    c.fillStyle = col; c.beginPath(); c.arc(0, 0, 12, 0, TAU); c.fill();
    c.strokeStyle = shade(col, -0.35); c.lineWidth = 1.5;
    for (let k = 0; k < 4; k++) { c.beginPath(); c.arc(0, 0, 12, k * 0.8, k * 0.8 + 2); c.stroke(); c.beginPath(); c.ellipse(0, 0, 12, 5 + k * 2, k, 0, Math.PI); c.stroke(); }
    c.rotate(-e.t * 3);
    c.fillStyle = '#1b1030'; c.beginPath(); c.arc(-3, -1, 1.6, 0, TAU); c.arc(3, -1, 1.6, 0, TAU); c.fill();
  },
  sunbunny(c, e) {
    const g = 0.6 + Math.sin(e.t * 8) * 0.3;
    c.fillStyle = `rgba(255,240,140,${g * 0.35})`; c.beginPath(); c.arc(0, 0, 14, 0, TAU); c.fill();
    c.fillStyle = '#fff3a0'; c.beginPath(); c.ellipse(0, 2, 7, 6, 0, 0, TAU); c.fill();
    c.beginPath(); c.ellipse(-3, -7, 2, 5, -0.2, 0, TAU); c.ellipse(3, -7, 2, 5, 0.2, 0, TAU); c.fill();
    c.fillStyle = '#c08a20'; c.beginPath(); c.arc(-2.5, 1, 1, 0, TAU); c.arc(2.5, 1, 1, 0, TAU); c.fill();
  },
  sprinkler(c, e) {
    c.fillStyle = '#4a7a4a'; c.fillRect(-10, 4, 20, 6);
    c.fillStyle = '#5ab0e0'; c.strokeStyle = '#2a6a90'; c.lineWidth = 1.5;
    c.beginPath(); c.arc(0, 0, 9, 0, TAU); c.fill(); c.stroke();
    c.save(); c.rotate(e.t * 4); c.fillStyle = '#e0f4ff'; c.fillRect(-12, -1.5, 24, 3); c.restore();
    for (let k = 0; k < 4; k++) { const a = e.t * 4 + k * TAU / 4; c.fillStyle = 'rgba(127,208,255,0.7)'; c.beginPath(); c.arc(Math.cos(a) * 15, Math.sin(a) * 15, 2, 0, TAU); c.fill(); }
  },
});

// ---------- боссы глав 4–5 ----------
Object.assign(BSPR, {
  vacuum(c, b, t) {
    const fl = b.flash > 0, st = b.stage;
    c.fillStyle = 'rgba(0,0,0,0.3)'; c.beginPath(); c.ellipse(0, 22, 40, 10, 0, 0, TAU); c.fill();
    c.fillStyle = fl ? '#fff' : '#3a3a4a'; c.strokeStyle = '#1a1a24'; c.lineWidth = 3;
    c.beginPath(); c.ellipse(0, 6, 40, 26, 0, 0, TAU); c.fill(); c.stroke();
    c.fillStyle = '#4e4e62'; c.beginPath(); c.ellipse(0, 0, 32, 18, 0, 0, TAU); c.fill();
    c.fillStyle = st >= 2 ? '#ff2a2a' : '#3ff0ff';
    c.beginPath(); c.arc(0, -2, 6 + Math.sin(t * 8) * 1.5, 0, TAU); c.fill();
    c.fillStyle = 'rgba(255,255,255,0.25)'; c.beginPath(); c.ellipse(-12, -6, 10, 4, -0.3, 0, TAU); c.fill();
    for (const sx of [-1, 1]) { c.save(); c.translate(sx * 30, 22); c.rotate(t * 10 * sx); c.strokeStyle = '#8a8a9a'; c.lineWidth = 2; for (let k = 0; k < 3; k++) { c.rotate(TAU / 3); c.beginPath(); c.moveTo(0, 0); c.lineTo(10, 0); c.stroke(); } c.restore(); }
    c.fillStyle = st >= 1 ? '#ff6a3a' : '#7dff7d'; c.fillRect(-20, 12, 6, 3); c.fillRect(14, 12, 6, 3);
    if (b.mode === 'suck') { c.strokeStyle = 'rgba(200,220,255,0.6)'; c.lineWidth = 2; for (let k = 0; k < 4; k++) { const r = 60 - ((t * 120 + k * 15) % 60); c.beginPath(); c.arc(0, 6, r, 0, TAU); c.stroke(); } }
  },
  speaker(c, b, t) {
    const fl = b.flash > 0, pulse = 1 + Math.sin(t * 10) * 0.05 * (b.stage + 1);
    c.fillStyle = fl ? '#fff' : '#2a2a3a'; c.strokeStyle = '#0e0e18'; c.lineWidth = 3;
    roundRect(c, -24, -36, 48, 64, 18); c.fill(); c.stroke();
    c.fillStyle = '#1a1a26'; c.beginPath(); c.arc(0, -4, 18 * pulse, 0, TAU); c.fill();
    c.fillStyle = '#3a3a4e'; c.beginPath(); c.arc(0, -4, 10 * pulse, 0, TAU); c.fill();
    c.strokeStyle = b.stage >= 2 ? '#c08aff' : '#8ad0ff'; c.lineWidth = 3;
    c.beginPath(); c.ellipse(0, -30, 16, 3, 0, 0, TAU); c.stroke();
    for (let k = 0; k < 3; k++) { const r = 26 + ((t * 40 + k * 14) % 42); c.strokeStyle = `rgba(138,208,255,${0.5 - (r - 26) / 90})`; c.beginPath(); c.arc(0, -4, r, -0.6, 0.6); c.stroke(); c.beginPath(); c.arc(0, -4, r, Math.PI - 0.6, Math.PI + 0.6); c.stroke(); }
  },
  tv(c, b, t) {
    const fl = b.flash > 0;
    c.fillStyle = fl ? '#fff' : '#2a2a2a'; c.strokeStyle = '#0a0a0a'; c.lineWidth = 3;
    roundRect(c, -40, -32, 80, 58, 8); c.fill(); c.stroke();
    c.strokeStyle = '#4a4a4a'; c.lineWidth = 3; c.beginPath(); c.moveTo(-10, -32); c.lineTo(-22, -50); c.moveTo(10, -32); c.lineTo(22, -50); c.stroke();
    c.save(); roundRect(c, -32, -25, 64, 42, 6); c.clip();
    for (let i = 0; i < 80; i++) { const v = Math.floor(Math.random() * 200 + 40); c.fillStyle = `rgb(${v},${v},${v})`; c.fillRect(-32 + Math.random() * 64, -25 + Math.random() * 42, 4, 2); }
    if (b.stage >= 1 && ART.zyamaFace === undefined) { /* нет лица */ }
    c.fillStyle = b.stage >= 2 ? 'rgba(255,40,40,0.35)' : 'rgba(63,240,160,0.18)'; c.fillRect(-32, -25, 64, 42);
    c.fillStyle = '#3ff0a0'; c.beginPath(); c.ellipse(-10, -6, 4, 6, 0, 0, TAU); c.ellipse(10, -6, 4, 6, 0, 0, TAU); c.fill();
    c.fillStyle = '#000'; c.fillRect(-11, -9, 2, 6); c.fillRect(9, -9, 2, 6);
    c.restore();
    c.fillStyle = '#5a5a5a'; c.fillRect(-26, 26, 8, 8); c.fillRect(18, 26, 8, 8);
  },
  mirrortessa(c, b, t) {
    c.globalAlpha *= 0.85 + Math.sin(t * 7) * 0.1;
    const f = Math.cos(b.look) >= 0 ? 1 : -1;
    drawTessa(c, 0, 8, t, f, 2.4, 1, b.mode !== 'idle', SHADOW_PAL, 'none');
    c.strokeStyle = 'rgba(191,234,255,0.6)'; c.lineWidth = 2; c.beginPath(); c.ellipse(0, -6, 34, 42, 0, 0, TAU); c.stroke();
  },
  meow2(c, b, t, face) {
    c.save(); c.scale(1.3, 1.3);
    if (Math.random() < 0.06) c.translate(rnd(-4, 4), 0);
    BSPR.glitchcat(c, b, t, face);
    c.restore();
    c.fillStyle = '#3ff0a0'; c.font = '900 12px monospace'; c.textAlign = 'center'; c.fillText('2.0', 40, -48);
  },
  cucumber(c, b, t) {
    const fl = b.flash > 0, sq = 1 + Math.sin(t * 5) * 0.04;
    c.scale(1 / sq, sq);
    c.fillStyle = fl ? '#fff' : '#3f9a3f'; c.strokeStyle = '#1f5a1f'; c.lineWidth = 3;
    roundRect(c, -22, -50, 44, 90, 22); c.fill(); c.stroke();
    c.fillStyle = '#7ad87a'; for (let k = 0; k < 12; k++) { c.beginPath(); c.arc(-14 + (k * 7) % 28, -38 + k * 6.5, 2.2, 0, TAU); c.fill(); }
    c.fillStyle = '#ffffff'; c.beginPath(); c.arc(-8, -18, 7, 0, TAU); c.arc(9, -18, 7, 0, TAU); c.fill();
    c.fillStyle = '#1b1030'; c.beginPath(); c.arc(-7 + Math.cos(b.look) * 2, -17, 3.2, 0, TAU); c.arc(10 + Math.cos(b.look) * 2, -17, 3.2, 0, TAU); c.fill();
    if (b.stage >= 1) brows(c, -8, 9, -27, 6, 0.6);
    c.fillStyle = '#1b1030'; c.beginPath(); c.ellipse(0, -2, 8, b.mode === 'leap' || b.stage >= 2 ? 6 : 3, 0, 0, TAU); c.fill();
    c.fillStyle = '#5aaa3a'; c.fillRect(-4, -56, 8, 8);
  },
  laserdot(c, b, t) {
    const r = 14 + Math.sin(t * 20) * 2;
    for (let k = 3; k > 0; k--) { c.fillStyle = `rgba(255,40,40,${0.12 * k})`; c.beginPath(); c.arc(0, 0, r + k * 8, 0, TAU); c.fill(); }
    c.fillStyle = b.flash > 0 ? '#fff' : '#ff2a2a'; c.beginPath(); c.arc(0, 0, r, 0, TAU); c.fill();
    c.fillStyle = '#ffd0d0'; c.beginPath(); c.arc(-4, -4, 4, 0, TAU); c.fill();
    c.strokeStyle = 'rgba(255,80,80,0.6)'; c.lineWidth = 2;
    for (let k = 0; k < 8; k++) { const a = t * 3 + k * TAU / 8; c.beginPath(); c.moveTo(Math.cos(a) * (r + 4), Math.sin(a) * (r + 4)); c.lineTo(Math.cos(a) * (r + 14), Math.sin(a) * (r + 14)); c.stroke(); }
  },
  pigeonboss(c, b, t) {
    const fl = b.flash > 0, f = Math.sin(t * 10) * 0.4, sx = Math.cos(b.look) >= 0 ? 1 : -1;
    c.scale(sx, 1);
    c.fillStyle = '#7a7e90'; c.beginPath(); c.ellipse(-10, -16 - f * 10, 26, 10, -0.6 - f, 0, TAU); c.fill();
    c.fillStyle = fl ? '#fff' : '#9a9eb0'; c.strokeStyle = '#4a4e60'; c.lineWidth = 2.5;
    c.beginPath(); c.ellipse(0, 4, 30, 24, 0, 0, TAU); c.fill(); c.stroke();
    c.fillStyle = '#6a7e8a'; c.beginPath(); c.arc(20, -16, 15, 0, TAU); c.fill(); c.stroke();
    c.fillStyle = '#5aa07a'; c.fillRect(8, -4, 20, 5);
    c.fillStyle = '#ffb03a'; c.beginPath(); c.moveTo(33, -16); c.lineTo(44, -13); c.lineTo(33, -10); c.fill();
    c.fillStyle = '#111'; roundRect(c, 14, -22, 20, 7, 3); c.fill();
    c.fillStyle = '#2a2a2a'; c.beginPath(); c.ellipse(20, -30, 18, 4, 0, 0, TAU); c.fill(); roundRect(c, 10, -46, 20, 16, 4); c.fill();
    c.fillStyle = '#c0392b'; c.fillRect(10, -35, 20, 3);
  },
  baron(c, b, t) {
    const fl = b.flash > 0, sx = Math.cos(b.look) >= 0 ? 1 : -1, wag = Math.sin(t * (b.stage >= 2 ? 22 : 10)) * 0.5;
    c.scale(sx, 1);
    c.strokeStyle = '#7a5030'; c.lineWidth = 6; c.lineCap = 'round';
    c.beginPath(); c.moveTo(-30, -4); c.lineTo(-44, -18 + wag * 14); c.stroke(); c.lineCap = 'butt';
    c.fillStyle = fl ? '#fff' : '#a0704a'; c.strokeStyle = '#5a3a20'; c.lineWidth = 2.5;
    c.beginPath(); c.ellipse(-4, 6, 34, 20, 0, 0, TAU); c.fill(); c.stroke();
    c.fillStyle = '#7a5030'; for (const x of [-26, -12, 6, 18]) c.fillRect(x, 20, 8, 14);
    c.fillStyle = fl ? '#fff' : '#b8845a'; c.beginPath(); c.arc(26, -12, 18, 0, TAU); c.fill(); c.stroke();
    c.fillStyle = '#5a3a20'; c.beginPath(); c.ellipse(16, -24, 7, 14, 0.5, 0, TAU); c.fill(); c.beginPath(); c.ellipse(36, -24, 6, 12, -0.4, 0, TAU); c.fill();
    c.fillStyle = '#e8c8a0'; c.beginPath(); c.ellipse(36, -6, 10, 8, 0, 0, TAU); c.fill();
    c.fillStyle = '#1b1030'; c.beginPath(); c.arc(42, -9, 3, 0, TAU); c.fill();
    c.beginPath(); c.arc(24, -16, 2.5, 0, TAU); c.arc(32, -16, 2.5, 0, TAU); c.fill();
    c.fillStyle = '#e53935'; c.fillRect(10, 0, 22, 4); c.fillStyle = '#ffd25a'; c.beginPath(); c.arc(22, 6, 3, 0, TAU); c.fill();
  },
  zyamabot(c, b, t) {
    const fl = b.flash > 0, bob = Math.sin(t * 3) * 3;
    c.fillStyle = '#4a4a5a'; c.fillRect(-44, 26, 88, 14);
    for (let k = 0; k < 6; k++) { c.fillStyle = '#2a2a3a'; c.beginPath(); c.arc(-36 + k * 14.4, 40, 6, 0, TAU); c.fill(); }
    c.translate(0, bob);
    c.fillStyle = fl ? '#fff' : '#c8ccd8'; c.strokeStyle = '#5a5e70'; c.lineWidth = 3;
    roundRect(c, -40, -18, 80, 46, 10); c.fill(); c.stroke();
    c.fillStyle = '#ffd25a'; c.fillRect(-30, -10, 60, 12);
    c.fillStyle = '#3a3a4a'; c.font = 'bold 9px monospace'; c.textAlign = 'center'; c.fillText('КОРМОТРОН', 0, -1);
    c.fillStyle = b.stage >= 2 ? '#ff3b3b' : '#7dff7d'; for (let k = 0; k < 5; k++) c.fillRect(-26 + k * 12, 8, 6, 6);
    for (const sx of [-1, 1]) {
      c.strokeStyle = '#8a8e9a'; c.lineWidth = 6; c.beginPath(); c.moveTo(sx * 40, -4); c.lineTo(sx * 58, -16 + Math.sin(t * 4 + sx) * 8); c.stroke();
      c.fillStyle = '#e8e8f0'; c.beginPath(); c.ellipse(sx * 60, -20 + Math.sin(t * 4 + sx) * 8, 12, 5, 0, 0, TAU); c.fill();
      c.fillStyle = '#c87a3a'; c.beginPath(); c.arc(sx * 60, -23 + Math.sin(t * 4 + sx) * 8, 5, Math.PI, TAU); c.fill();
    }
    const R = 22;
    if (ART.zyamaFace) { c.save(); c.beginPath(); c.arc(0, -42, R, 0, TAU); c.clip(); c.drawImage(ART.zyamaFace, -R, -42 - R, R * 2, R * 2); c.restore(); }
    c.strokeStyle = '#ffd25a'; c.lineWidth = 3; c.beginPath(); c.arc(0, -42, R, 0, TAU); c.stroke();
    c.fillStyle = '#ffd25a'; c.beginPath(); c.moveTo(-14, -60); c.lineTo(-14, -72); c.lineTo(-6, -64); c.lineTo(0, -74); c.lineTo(6, -64); c.lineTo(14, -72); c.lineTo(14, -60); c.closePath(); c.fill();
  },
});
BOSSES.meow2.sprite = 'meow2';
