'use strict';
// =====================================================================
//  Глава 6 «Мрак: новый сезон» – зимняя тёмная сказка.
//  Крилесса и Рыжовая вместе (смена на ходу), лёд, метель, костры.
// =====================================================================

// ---------------- Локации (биомы 27–32) ----------------
SPAWNS.push(null); // 26 – арена испытаний, свои враги
BIOMES.push(
  { id: 'snowforest', name: 'Заснеженный лес', ground: ['#e8f0f8', '#f4f8fc', '#d8e4f0'], tree: 'pine', treeP: 0.12,
    obst: [[ROCK, 0.6], [ICE, 0.4]], rock: ['#a8d0e8', '#c0e0f4', '#90c0dc'], deco: 'snow', mini: '#e8f0f8', meltable: true },
  { id: 'frozenlake', name: 'Замёрзшее озеро', ground: ['#cfe6f4', '#dcedf8', '#c2dcee'], tree: 'pine', treeP: 0.02,
    obst: [[ICE, 0.8], [ROCK, 0.2]], rock: ['#a8d0e8', '#c0e0f4', '#90c0dc'], deco: 'snow', mini: '#c8e2f2', meltable: true },
  { id: 'ginger', name: 'Пряничная деревня', ground: ['#f0e4d8', '#f8eee4', '#e6d6c6'], tree: 'gingerhouse', treeP: 0.05,
    obst: [[ROCK, 1]], rock: ['#b06a3a', '#c07a48', '#9a5a30'], deco: 'sprinkles', mini: '#e8d6c4' },
  { id: 'pass', name: 'Метельный перевал', ground: ['#c8d4e0', '#d4dee8', '#bccad6'], tree: 'pine', treeP: 0.05,
    obst: [[ROCK, 0.8], [ICE, 0.2]], rock: ['#8a9aac', '#9aaabc', '#7a8a9c'], deco: 'snow', mini: '#c8d4e0' },
  { id: 'aurora', name: 'Северное сияние', ground: ['#1a2a4a', '#22345a', '#14223e'], tree: 'crystal', treeP: 0.04,
    obst: [[ICE, 0.6], [ROCK, 0.4]], rock: ['#6a8aca', '#7a9ada', '#5a7aba'], deco: 'sky', mini: '#1a2a4a', meltable: true },
  { id: 'icecastle', name: 'Ледяной замок Мрака', ground: ['#a8c8e8', '#b8d4ee', '#98bcde'], tree: 'pine', treeP: 0.02,
    obst: [[ROCK, 1]], rock: ['#7aa8d8', '#8ab8e8', '#6a98c8'], deco: 'snow', mini: '#a8c8e8', castleStyle: 'ice', meltable: true },
  { id: 'crystalcave', name: 'Хрустальные пещеры', ground: ['#1c1830', '#241e3c', '#16122a'], tree: 'crystal', treeP: 0.09,
    obst: [[ROCK, 1]], rock: ['#3a3458', '#4a426a', '#2e2848'], deco: 'gems', mini: '#2a2440', cave: true },
);
BIOME_MUSIC.push('winter6', 'snow', 'ginger6', 'blizzard6', 'aurora6', 'dark', 'crystal');

// ---------------- Враги ----------------
Object.assign(ENEMIES, {
  snowling: { name: 'Снеговичок', hp: 80, spd: 70, dmg: 15, r: 13, xp: 3, ai: 'hop', col: '#ffffff' },
  icebat: { name: 'Ледяная мышь', hp: 34, spd: 125, dmg: 11, r: 10, xp: 2, ai: 'bat', fly: true, dodge: true, col: '#9ad8f8' },
  wolfpup: { name: 'Волчонок метели', hp: 45, spd: 120, dmg: 12, r: 11, xp: 2, ai: 'chase', pack: true, group: [2, 3], col: '#c8d4e0' },
  ginger: { name: 'Пряничный человечек', hp: 60, spd: 95, dmg: 16, r: 12, xp: 3, ai: 'charger', col: '#c87a3a' },
  frostwisp: { name: 'Ледяной огонёк', hp: 40, spd: 60, dmg: 9, r: 11, xp: 3, ai: 'ranged', fly: true, col: '#bfeaff',
    shot: { cd: 2.2, spd: 190, dmg: 12, n: 3, spread: 0.25, col: '#bfeaff' } },
  icegolem: { name: 'Ледяной голем', hp: 170, spd: 48, dmg: 22, r: 17, xp: 5, ai: 'shield', col: '#a8d0e8' },
  shardling: { name: 'Осколыш', hp: 55, spd: 105, dmg: 14, r: 12, xp: 3, ai: 'chase', group: [2, 3], col: '#c77dff' },
  pike: { name: 'Щука-мимик', hp: 150, spd: 125, dmg: 20, r: 16, xp: 8, ai: 'charger', col: '#5a8a9a' },
  snowleopard: { name: 'Снежный барс', hp: 260, spd: 150, dmg: 24, r: 17, xp: 14, ai: 'charger', col: '#e8eef4' },
});
SPAWNS.push(
  [['snowling', 3], ['wolfpup', 1], ['icebat', 2], ['frostwisp', 1]],
  [['icebat', 3], ['frostwisp', 2.5], ['snowling', 2], ['icegolem', 1]],
  [['ginger', 3.5], ['snowling', 2], ['icebat', 1.5]],
  [['wolfpup', 2], ['icegolem', 1.5], ['frostwisp', 2], ['snowling', 1.5]],
  [['frostwisp', 3], ['icebat', 2.5], ['icegolem', 1.5], ['wolfpup', 1.5]],
  [['icegolem', 2], ['frostwisp', 2.5], ['shade', 2], ['icebat', 2]],
  [['shardling', 3], ['icebat', 2.5], ['frostwisp', 2], ['icegolem', 1]],
);

// ---------------- Боссы ----------------
Object.assign(BOSSES, {
  snowgiant: {
    name: 'Снеговик-Великан', sub: 'Страж Заснеженного леса', r: 46, ttk: 60, hit: 0.085, touch: 0.15, spd: 70, move: 'chase', col: '#ffffff',
    emojiSet: ['❄️', '⛄'],
    lines: {
      intro: 'Ха-ха-хо! Новый сезон – новые сугробы! Я слеплю из тебя снежного ангела! ⛄',
      stages: ['', 'Морковка дрожит от злости! БОЛЬШОЙ КОМ!', 'Я таю… от ЯРОСТИ!'],
      death: 'Я… просто… лужа… до весны…',
      taunts: ['Снежок в лицо – это любовь!', 'Мрак обещал мне вечную зиму!', 'Нос-морковка – мой главный козырь!'],
    },
    stages: [
      { attacks: [['stomp', { r: 150 }], ['shotgun', { n: 7, waves: 2, emoji: true }], ['summon', { type: 'snowling', n: 3, max: 6 }], ['leap', { r: 120 }]] },
      { at: 0.66, spd: 1.2, attacks: [['leap', { r: 130, repeat: 2, ringN: 12 }], ['ring', { n: 18, waves: 3, emoji: true }], ['rain', { n: 10, fx: 'icicle' }], ['charge', { repeat: 2 }]] },
      { at: 0.33, spd: 1.35, attacks: [['leap', { r: 140, repeat: 3, ringN: 16 }], ['stomp', { r: 170, repeat: 2 }], ['spiral', { arms: 4, emoji: true }], ['wave', { n: 2 }]] },
    ],
  },
  icequeen: {
    name: 'Ледяная Королева', sub: 'Стража Замёрзшего озера', r: 38, ttk: 60, hit: 0.085, touch: 0.13, spd: 90, move: 'hover', fly: true, col: '#bfeaff',
    lines: {
      intro: 'Я – самая преданная фанатка Мрака! Его плащ… его чёлка… его ГРУСТНЫЕ СТИХИ! ❄️👑',
      stages: ['', 'Он подписал мне сосульку! Не смей её трогать!', '«Отпусти и забудь», – сказал Мрак. А я не отпущу!'],
      death: 'Передайте Мраку… что я… растаяла от его стихов…',
      taunts: ['Холод – это стиль!', 'Мрак – гений. Остальные – оттепель.', 'Твой огонь меня не растопит!'],
    },
    stages: [
      { attacks: [['laser', { beams: 1, rot: 0.8 }], ['rain', { n: 10, fx: 'icicle' }], ['spiral', { arms: 3, col: '#bfeaff' }], ['summon', { type: 'icebat', n: 4, max: 8 }]] },
      { at: 0.66, spd: 1.2, attacks: [['laser', { beams: 2, rot: 0.9 }], ['cross', {}], ['rain', { n: 14, fx: 'icicle' }], ['mirrors', { n: 3 }]] },
      { at: 0.33, spd: 1.35, attacks: [['laser', { beams: 3, rot: 1.0 }], ['spiral', { arms: 5, col: '#bfeaff' }], ['rain', { n: 16, fx: 'icicle' }], ['homing', { n: 6 }], ['teleport', { ringN: 14 }]] },
    ],
  },
  blizzardwolf: {
    name: 'Волк-Метель', sub: 'Страж Метельного перевала', r: 40, ttk: 60, hit: 0.09, touch: 0.15, spd: 120, move: 'chase', col: '#c8d4e0',
    lines: {
      intro: 'Ауууу! В метели меня не видно. А я вижу ВСЁ. 🐺❄️',
      stages: ['', 'Стая, ко мне! Охота началась!', 'Буран внутри меня! АУУУУ!'],
      death: 'Ауу… метель… стихает…',
      taunts: ['Я пахну морозом и победой.', 'Слышишь вой? Это я. Опять.', 'Догони, если сможешь!'],
    },
    stages: [
      { attacks: [['charge', { repeat: 2, spd: 780 }], ['blizzard', { dur: 3 }], ['summon', { type: 'wolfpup', n: 3, max: 6 }], ['shotgun', { n: 7, waves: 2, col: '#e0f0ff' }]] },
      { at: 0.66, spd: 1.2, attacks: [['charge', { repeat: 3, spd: 820 }], ['teleport', { ringN: 12 }], ['blizzard', { dur: 3.5 }], ['wave', { n: 2 }]] },
      { at: 0.33, spd: 1.35, attacks: [['charge', { repeat: 4, spd: 860, trail: true }], ['blizzard', { dur: 4 }], ['teleport', { ringN: 16 }], ['summon', { type: 'wolfpup', n: 4, max: 8 }], ['ring', { n: 20, waves: 3, col: '#e0f0ff' }]] },
    ],
  },
  icedragon: {
    name: 'Сосулечный Дракон', sub: 'Страж Северного сияния', r: 48, ttk: 65, hit: 0.09, touch: 0.14, spd: 100, move: 'hover', fly: true, col: '#7fd8ff',
    lines: {
      intro: 'Я сплю на ледяных сокровищах тысячу лет. И ты меня разбудила. 🐉',
      stages: ['', 'Сияние – это моё дыхание!', 'Небо горит холодом!'],
      death: 'Хрусь… я… просто… большая сосулька…',
      taunts: ['Ледяное дыхание – освежает!', 'Мрак платит мне снежинками.', 'Северное сияние – мой ночник.'],
    },
    stages: [
      { attacks: [['laser', { beams: 1, rot: 0.9, mouth: true }], ['rain', { n: 10, fx: 'icicle' }], ['homing', { n: 4 }], ['charge', { repeat: 2 }]] },
      { at: 0.66, spd: 1.2, attacks: [['laser', { beams: 2, rot: 1.0, mouth: true, rainbow: true }], ['rain', { n: 14, fx: 'icicle' }], ['spiral', { arms: 4, rainbow: true }], ['wave', { n: 2 }]] },
      { at: 0.33, spd: 1.35, attacks: [['laser', { beams: 3, rot: 1.1, mouth: true, rainbow: true }], ['blizzard', { dur: 3 }], ['rain', { n: 18, fx: 'icicle' }], ['spiral', { arms: 6, rainbow: true }], ['homing', { n: 6 }]] },
    ],
  },
  mrak2: {
    name: 'Мрак 2.0', sub: 'Повелитель Новой Зимы', r: 46, ttk: 90, hit: 0.085, touch: 0.13, spd: 90, move: 'hover', fly: true, col: '#2a1240',
    final: true, avatar: 'mrak', music: 'mrakboss', sprite: 'mrak2',
    lines: {
      intro: 'Я же говорил: это был не конец, а финал СЕЗОНА. Встречайте новый сезон. Вечная зима. 🖤❄️',
      stages: ['', 'Тесса? Мне нужна одна из её девяти жизней. Всего одна!', 'Холод внутри меня… это не я его сделал… Кто-то заморозил меня самого!', 'Если не я – то кто?! ВСЁ ПОКРЫТЬ ЛЬДОМ!!!'],
      death: 'Тепло… я… вспомнил… какое оно… Спасибо… и берегитесь… того, кто прячется в тишине…',
      taunts: ['Мои новые стихи ещё грустнее. Хочешь послушать?', 'Чёлка на оба глаза – и на оба сезона.', 'Лето отменяется.', 'Вам холодно? Мне – всегда.'],
    },
    stages: [
      { attacks: [['spiral', { arms: 4 }], ['teleport', { ringN: 12 }], ['rain', { n: 10, fx: 'icicle' }], ['summon', { type: 'frostwisp', n: 3, max: 6 }]] },
      { at: 0.75, spd: 1.15, attacks: [['laser', { beams: 2, rot: 0.9 }], ['blizzard', { dur: 3 }], ['homing', { n: 5 }], ['cross', {}]] },
      { at: 0.5, spd: 1.25, attacks: [['spiral', { arms: 6, dur: 3.5 }], ['laser', { beams: 3, rot: 1.0 }], ['rain', { n: 16, fx: 'icicle' }], ['summon', { type: 'icegolem', n: 2, max: 3 }], ['wave', { n: 3 }]] },
      { at: 0.25, spd: 1.4, attacks: [['blizzard', { dur: 4 }], ['laser', { beams: 4, rot: 1.1 }], ['spiral', { arms: 7, dur: 4 }], ['homing', { n: 7 }], ['rain', { n: 18, fx: 'icicle' }], ['cross', {}]] },
    ],
  },
});

// ---------------- Глава 6 ----------------
CHAPTERS[6] = {
  id: 6, title: 'Глава 6', name: 'Мрак: новый сезон', seed: 6600066, MW: 230, MH: 230, blobs: 220,
  start: { x: 115, y: 216 },
  bossTiles: [{ x: 41, y: 179 }, { x: 46, y: 60 }, { x: 189, y: 54 }, { x: 192, y: 173 }, { x: 115, y: 106 }],
  bosses: ['snowgiant', 'icequeen', 'blizzardwolf', 'icedragon', 'mrak2'],
  castle: { x: 115, y: 108, half: 16, gate: 'south', biome: 32 }, cage: { x: 115, y: 95 }, noCage: true,
  biomeSeeds: [
    [27, 115, 216], [27, 74, 203], [27, 41, 179], [27, 156, 210],
    [29, 30, 130], [29, 68, 143], [29, 54, 103],
    [28, 46, 60], [28, 20, 27], [28, 81, 34], [28, 76, 76],
    [30, 189, 54], [30, 216, 95], [30, 162, 78],
    [31, 192, 173], [31, 216, 135], [31, 169, 203], [31, 160, 149],
    [32, 115, 108], [32, 115, 89], [32, 97, 108], [32, 133, 108],
    [33, 112, 26], [33, 92, 20], [33, 134, 34], [33, 112, 50],
  ],
  chests: 30, chestDist: [8, 30], shrines: 10, elite: 0.1, spawnEvery: 0.3, capBase: 22,
  zoneLevel: { 27: 4, 28: 8, 29: 6, 33: 11, 30: 12, 31: 16, 32: 20 }, bossLevels: [6, 10, 14, 18, 24], diff: { hp: 1.7, dmg: 1.55 },
  hero: 'krilessa', team: ['krilessa', 'ryzhovaya'], hostage: 'tessa', music: 'winter6', startLevel: 1,
  fires: 16, slippery: true, iceSpeed: 1.6, weathers: ['blizzard', 'starfall', 'frost'], icedChests: 0.5,
  glades: 4, holes: 5, ovens: 3, drifts: 26,
  // ледяные реки-горки: на льду быстро и скользко
  slides: [[[100, 212], [52, 166]], [[24, 150], [26, 82]], [[58, 76], [172, 72]], [[208, 70], [206, 158]], [[182, 196], [138, 140]]],
  gateSay: 'Мяу! Я слышу вас! Ворота ледяного замка открылись – я в главной башне!', gateBanner: 'Ледяной замок открыт',
  deadText: 'Крилесса и Рыжовая замёрзли… Попробуй снова –<br>уровень и улучшения сохранятся.',
};
ARENA_STYLE[6] = { name: 'Ледяная бездна', floor: ['#0e1a2a', '#122236'], crack: '#7fd8ff', ember: '#ffffff', wall: '#06101c', tint: '120,200,255' };
CHEST_THEME[6] = { body: '#a8d8f0', lid: '#c8ecff', dark: '#4a7a9a', ice: true };

// ---------------- Графика ----------------
(() => {
  const S = 2;
  const make = (fn) => { const cv = makeCanvas(64 * S, 84 * S), c = cv.getContext('2d'); c.scale(S, S); shadow(c, 32, 79, 16, 5); fn(c); return cv; };
  TREE_SPR.gingerhouse = make(c => {
    c.fillStyle = '#b06a3a'; c.strokeStyle = '#6a3a1a'; c.lineWidth = 2;
    c.fillRect(14, 46, 36, 32); c.strokeRect(14, 46, 36, 32);
    c.fillStyle = '#ffffff'; c.beginPath(); c.moveTo(8, 48); c.lineTo(32, 24); c.lineTo(56, 48); c.closePath(); c.fill();
    c.fillStyle = '#c07a48'; c.beginPath(); c.moveTo(11, 48); c.lineTo(32, 28); c.lineTo(53, 48); c.closePath(); c.fill();
    c.strokeStyle = '#ffffff'; c.lineWidth = 2.5; c.beginPath(); for (let k = 0; k < 5; k++) { c.moveTo(14 + k * 9, 46); c.quadraticCurveTo(18 + k * 9, 52, 22 + k * 9, 46); } c.stroke();
    c.fillStyle = '#6a3a1a'; c.fillRect(27, 60, 10, 18);
    c.fillStyle = '#ffd25a'; c.fillRect(17, 55, 7, 7); c.fillRect(40, 55, 7, 7);
    for (const [x, y, col] of [[20, 70, '#e53935'], [44, 70, '#43a047'], [32, 40, '#ff6fb5']]) { c.fillStyle = col; c.beginPath(); c.arc(x, y, 2.5, 0, TAU); c.fill(); }
  });
})();

Object.assign(ESPR, {
  snowling(c, e) {
    const sq = 1 + Math.sin(e.t * 10 + e.seed) * 0.08;
    c.scale(1 / sq, sq);
    c.fillStyle = '#ffffff'; c.strokeStyle = '#a8c0d8'; c.lineWidth = 1.5;
    c.beginPath(); c.arc(0, 5, 10, 0, TAU); c.fill(); c.stroke();
    c.beginPath(); c.arc(0, -8, 7, 0, TAU); c.fill(); c.stroke();
    c.fillStyle = '#1b1030'; c.beginPath(); c.arc(-2.5, -9, 1.3, 0, TAU); c.arc(2.5, -9, 1.3, 0, TAU); c.fill();
    c.fillStyle = '#ff8a2a'; c.beginPath(); c.moveTo(0, -7); c.lineTo(7, -6); c.lineTo(0, -5); c.fill();
    c.fillStyle = '#1b1030'; c.fillRect(-1, 2, 2, 2); c.fillRect(-1, 7, 2, 2);
    c.strokeStyle = '#6a4024'; c.lineWidth = 1.5; c.beginPath(); c.moveTo(-9, 3); c.lineTo(-15, -3); c.moveTo(9, 3); c.lineTo(15, -3); c.stroke();
  },
  icebat(c, e) {
    const f = Math.sin(e.t * 22) * 0.6;
    c.fillStyle = '#9ad8f8';
    c.beginPath(); c.moveTo(0, 0); c.lineTo(-14, -6 - f * 6); c.lineTo(-9, 2); c.lineTo(-5, -1); c.closePath(); c.fill();
    c.beginPath(); c.moveTo(0, 0); c.lineTo(14, -6 - f * 6); c.lineTo(9, 2); c.lineTo(5, -1); c.closePath(); c.fill();
    c.fillStyle = '#d8f2ff'; c.beginPath(); c.ellipse(0, 0, 5, 6, 0, 0, TAU); c.fill();
    c.fillStyle = '#1b6a9a'; c.beginPath(); c.arc(-2, -1, 1, 0, TAU); c.arc(2, -1, 1, 0, TAU); c.fill();
  },
  wolfpup(c, e) {
    c.scale(Math.cos(e.look) >= 0 ? 1 : -1, 1);
    const st = Math.sin(e.t * 18) * 2;
    c.fillStyle = '#8a9aac'; c.fillRect(-7, 4 + st * 0.3, 3, 5); c.fillRect(4, 4 - st * 0.3, 3, 5);
    c.fillStyle = '#c8d4e0'; c.beginPath(); c.ellipse(-1, 1, 10, 6, 0, 0, TAU); c.fill();
    c.beginPath(); c.arc(8, -3, 5.5, 0, TAU); c.fill();
    c.fillStyle = '#8a9aac'; c.beginPath(); c.moveTo(5, -7); c.lineTo(6, -12); c.lineTo(9, -7); c.fill(); c.beginPath(); c.moveTo(9, -7); c.lineTo(11, -11); c.lineTo(12, -6); c.fill();
    c.fillStyle = '#1b1030'; c.beginPath(); c.arc(10, -4, 1.2, 0, TAU); c.fill(); c.fillRect(13, -3, 1.5, 1.5);
    c.strokeStyle = '#c8d4e0'; c.lineWidth = 3; c.lineCap = 'round'; c.beginPath(); c.moveTo(-10, 0); c.quadraticCurveTo(-15, -4, -14, -9); c.stroke(); c.lineCap = 'butt';
  },
  ginger(c, e) {
    c.rotate(Math.sin(e.t * 9 + e.seed) * 0.15);
    c.fillStyle = '#c87a3a'; c.strokeStyle = '#ffffff'; c.lineWidth = 1.5;
    c.beginPath(); c.arc(0, -9, 6, 0, TAU); c.fill(); c.stroke();
    c.beginPath(); c.moveTo(-5, -3); c.lineTo(5, -3); c.lineTo(6, 6); c.lineTo(9, 13); c.lineTo(3, 13); c.lineTo(0, 7); c.lineTo(-3, 13); c.lineTo(-9, 13); c.lineTo(-6, 6); c.closePath(); c.fill(); c.stroke();
    c.beginPath(); c.moveTo(-5, -2); c.lineTo(-12, 3); c.moveTo(5, -2); c.lineTo(12, 3); c.stroke();
    c.fillStyle = '#ffffff'; c.beginPath(); c.arc(-2, -10, 1, 0, TAU); c.arc(2, -10, 1, 0, TAU); c.fill();
    c.fillStyle = '#e53935'; c.beginPath(); c.arc(0, 1, 1.5, 0, TAU); c.arc(0, 5, 1.5, 0, TAU); c.fill();
  },
  frostwisp(c, e) {
    const g = 0.6 + Math.sin(e.t * 6) * 0.3;
    c.fillStyle = `rgba(191,234,255,${g * 0.35})`; c.beginPath(); c.arc(0, 0, 14, 0, TAU); c.fill();
    for (let k = 0; k < 6; k++) { const a = e.t * 2 + k * TAU / 6; c.strokeStyle = '#ffffff'; c.lineWidth = 1.5; c.beginPath(); c.moveTo(0, 0); c.lineTo(Math.cos(a) * 9, Math.sin(a) * 9); c.stroke(); }
    c.fillStyle = '#e0f6ff'; c.beginPath(); c.arc(0, 0, 5, 0, TAU); c.fill();
    c.fillStyle = '#1b6a9a'; c.beginPath(); c.arc(-1.8, -0.5, 1, 0, TAU); c.arc(1.8, -0.5, 1, 0, TAU); c.fill();
  },
  icegolem(c, e) {
    c.fillStyle = '#a8d0e8'; c.strokeStyle = '#4a7a9a'; c.lineWidth = 2;
    c.beginPath(); c.moveTo(-14, 14); c.lineTo(-16, -4); c.lineTo(-8, -16); c.lineTo(8, -16); c.lineTo(16, -4); c.lineTo(14, 14); c.closePath(); c.fill(); c.stroke();
    c.fillStyle = 'rgba(255,255,255,0.5)'; c.beginPath(); c.moveTo(-8, -14); c.lineTo(-2, -14); c.lineTo(-10, 4); c.lineTo(-13, 0); c.closePath(); c.fill();
    c.fillStyle = '#1b6a9a'; c.fillRect(-7, -6, 4, 3); c.fillRect(3, -6, 4, 3);
  },
});
Object.assign(ESPR, {
  shardling(c, e) {
    const g = 0.5 + Math.sin(e.t * 7 + e.seed) * 0.3;
    c.fillStyle = `rgba(199,125,255,${g * 0.35})`; c.beginPath(); c.arc(0, 0, 15, 0, TAU); c.fill();
    c.strokeStyle = '#6a3a9a'; c.lineWidth = 2;
    for (let k = 0; k < 3; k++) { const st = Math.sin(e.t * 16 + k) * 2; c.beginPath(); c.moveTo(-4, 2 + k * 3); c.lineTo(-12, 6 + k * 3 + st); c.moveTo(4, 2 + k * 3); c.lineTo(12, 6 + k * 3 - st); c.stroke(); }
    c.fillStyle = '#c77dff'; c.strokeStyle = '#ffffff'; c.lineWidth = 1.2;
    c.beginPath(); c.moveTo(0, -14); c.lineTo(7, -2); c.lineTo(4, 9); c.lineTo(-4, 9); c.lineTo(-7, -2); c.closePath(); c.fill(); c.stroke();
    c.fillStyle = '#5be3ff'; c.beginPath(); c.moveTo(-6, -6); c.lineTo(-11, -14); c.lineTo(-3, -9); c.fill(); c.beginPath(); c.moveTo(6, -6); c.lineTo(11, -14); c.lineTo(3, -9); c.fill();
    c.fillStyle = '#ffffff'; c.fillRect(-3.5, -3, 2.5, 2.5); c.fillRect(1, -3, 2.5, 2.5);
  },
  pike(c, e) {
    c.scale(Math.cos(e.look) >= 0 ? 1 : -1, 1);
    const open = 0.3 + Math.abs(Math.sin(e.t * 9)) * 0.7;
    c.fillStyle = '#5a8a9a'; c.strokeStyle = '#2a4a5a'; c.lineWidth = 2;
    c.beginPath(); c.ellipse(-2, 0, 16, 8, 0, 0, TAU); c.fill(); c.stroke();
    c.beginPath(); c.moveTo(-16, 0); c.lineTo(-24, -7); c.lineTo(-24, 7); c.closePath(); c.fill(); c.stroke();
    c.fillStyle = '#c8e0e8'; c.beginPath(); c.ellipse(0, 3, 11, 4, 0, 0, TAU); c.fill();
    c.fillStyle = '#7a1a1a'; c.beginPath(); c.moveTo(13, 0); c.lineTo(22, -5 * open); c.lineTo(22, 5 * open); c.closePath(); c.fill();
    c.fillStyle = '#ffffff'; for (let k = 0; k < 3; k++) { c.fillRect(15 + k * 2.5, -3 * open, 1.5, 2); c.fillRect(15 + k * 2.5, 3 * open - 2, 1.5, 2); }
    c.fillStyle = '#ffd25a'; c.beginPath(); c.arc(9, -3, 2.2, 0, TAU); c.fill(); c.fillStyle = '#000'; c.fillRect(9, -4, 1.2, 2);
    c.fillStyle = '#ff2a2a'; c.fillRect(-6, -9, 8, 2);
  },
  snowleopard(c, e) {
    c.scale(Math.cos(e.look) >= 0 ? 1 : -1, 1);
    const st = Math.sin(e.t * 16) * 3;
    c.fillStyle = '#c8d0d8'; for (const [x, s] of [[-12, st], [-5, -st], [6, st], [12, -st]]) c.fillRect(x, 6 + s * 0.3, 3.5, 8);
    c.fillStyle = '#eef2f6'; c.strokeStyle = '#8a96a4'; c.lineWidth = 1.5;
    c.beginPath(); c.ellipse(0, 2, 16, 8, 0, 0, TAU); c.fill(); c.stroke();
    c.beginPath(); c.arc(15, -5, 7, 0, TAU); c.fill(); c.stroke();
    c.fillStyle = '#5a6470'; for (const [x, y] of [[-8, 0], [-2, -3], [4, 1], [-10, 5], [8, -2], [0, 5]]) { c.beginPath(); c.arc(x, y, 1.6, 0, TAU); c.fill(); }
    c.beginPath(); c.moveTo(12, -11); c.lineTo(13, -15); c.lineTo(16, -11); c.fill();
    c.fillStyle = '#7fd8ff'; c.beginPath(); c.arc(17, -6, 1.6, 0, TAU); c.fill();
    c.strokeStyle = '#eef2f6'; c.lineWidth = 4; c.lineCap = 'round'; c.beginPath(); c.moveTo(-15, 0); c.quadraticCurveTo(-26, -2, -24, -12); c.stroke(); c.lineCap = 'butt';
  },
});
Object.assign(BSPR, {
  snowgiant(c, b, t) {
    const fl = b.flash > 0, sq = 1 + Math.sin(t * 4) * 0.03;
    c.scale(1 / sq, sq);
    const col = fl ? '#ffffff' : '#f4f8fc';
    c.fillStyle = col; c.strokeStyle = '#a8c0d8'; c.lineWidth = 3;
    c.beginPath(); c.arc(0, 18, 30, 0, TAU); c.fill(); c.stroke();
    c.beginPath(); c.arc(0, -18, 22, 0, TAU); c.fill(); c.stroke();
    c.fillStyle = '#2a2a3a'; c.fillRect(-16, -44, 32, 6); c.fillRect(-11, -62, 22, 18);
    c.fillStyle = '#e53935'; c.fillRect(-11, -50, 22, 4);
    c.fillStyle = '#1b1030'; c.beginPath(); c.arc(-8, -22, 3.5, 0, TAU); c.arc(8, -22, 3.5, 0, TAU); c.fill();
    if (b.stage >= 1) brows(c, -8, 8, -29, 6, 0.6);
    c.fillStyle = '#ff8a2a'; c.beginPath(); c.moveTo(0, -16); c.lineTo(22 + b.stage * 4, -13); c.lineTo(0, -10); c.fill();
    c.fillStyle = '#1b1030'; for (const y of [6, 18, 30]) { c.beginPath(); c.arc(0, y, 3, 0, TAU); c.fill(); }
    c.strokeStyle = '#6a4024'; c.lineWidth = 4; c.beginPath(); c.moveTo(-26, 8); c.lineTo(-48, -10 + Math.sin(t * 5) * 6); c.moveTo(26, 8); c.lineTo(48, -10 - Math.sin(t * 5) * 6); c.stroke();
    c.fillStyle = '#e53935'; c.fillRect(-20, -4, 40, 6); c.fillRect(10, -4, 6, 18);
  },
  icequeen(c, b, t) {
    const fl = b.flash > 0;
    c.fillStyle = 'rgba(191,234,255,0.25)'; c.beginPath(); c.arc(0, -4, 50 + Math.sin(t * 3) * 4, 0, TAU); c.fill();
    c.fillStyle = fl ? '#ffffff' : '#9ad8f8'; c.strokeStyle = '#4a7a9a'; c.lineWidth = 2.5;
    c.beginPath(); c.moveTo(-26, 34); c.lineTo(-12, -6); c.lineTo(12, -6); c.lineTo(26, 34); c.closePath(); c.fill(); c.stroke();
    c.fillStyle = '#e8f6ff'; c.beginPath(); c.arc(0, -18, 14, 0, TAU); c.fill(); c.stroke();
    c.fillStyle = '#ffffff'; c.beginPath(); c.moveTo(-14, -26); c.quadraticCurveTo(-24, 0, -18, 20); c.lineTo(-12, 0); c.closePath(); c.fill();
    c.beginPath(); c.moveTo(14, -26); c.quadraticCurveTo(24, 0, 18, 20); c.lineTo(12, 0); c.closePath(); c.fill();
    c.fillStyle = '#7fd8ff';
    c.beginPath(); c.moveTo(-14, -30); c.lineTo(-10, -46); c.lineTo(-5, -32); c.lineTo(0, -50); c.lineTo(5, -32); c.lineTo(10, -46); c.lineTo(14, -30); c.closePath(); c.fill();
    c.fillStyle = '#1b6a9a'; c.beginPath(); c.ellipse(-5, -19, 2, 3, 0, 0, TAU); c.ellipse(5, -19, 2, 3, 0, 0, TAU); c.fill();
    c.strokeStyle = '#4a7a9a'; c.lineWidth = 1.5; c.beginPath(); c.arc(0, -12, 4, 0.2, Math.PI - 0.2); c.stroke();
    for (let k = 0; k < 6; k++) { const a = t * 1.5 + k * TAU / 6; c.fillStyle = '#ffffff'; star(c, Math.cos(a) * 40, -4 + Math.sin(a) * 40, 3, t, 6); c.fill(); }
  },
  blizzardwolf(c, b, t) {
    const fl = b.flash > 0, sx = Math.cos(b.look) >= 0 ? 1 : -1;
    c.scale(sx, 1);
    c.globalAlpha *= b.mode === 'blizzard' ? 0.35 + Math.sin(t * 12) * 0.15 : 1;
    const st = Math.sin(t * 14) * 4;
    c.fillStyle = '#7a8a9c'; for (const [x, s] of [[-24, st], [-12, -st], [8, st], [20, -st]]) c.fillRect(x, 12 + s * 0.3, 7, 16);
    c.fillStyle = fl ? '#ffffff' : '#c8d4e0'; c.strokeStyle = '#6a7a8c'; c.lineWidth = 2.5;
    c.beginPath(); c.ellipse(-2, 4, 34, 18, 0, 0, TAU); c.fill(); c.stroke();
    c.beginPath(); c.arc(30, -10, 16, 0, TAU); c.fill(); c.stroke();
    c.beginPath(); c.moveTo(38, -8); c.lineTo(52, -4); c.lineTo(38, 2); c.closePath(); c.fill(); c.stroke();
    c.fillStyle = '#6a7a8c'; c.beginPath(); c.moveTo(22, -22); c.lineTo(24, -36); c.lineTo(30, -24); c.fill(); c.beginPath(); c.moveTo(32, -24); c.lineTo(38, -36); c.lineTo(40, -22); c.fill();
    c.fillStyle = b.stage >= 2 ? '#ff3b3b' : '#4dc8ff'; c.beginPath(); c.arc(34, -12, 3, 0, TAU); c.fill();
    c.fillStyle = '#1b1030'; c.beginPath(); c.arc(52, -3, 2.5, 0, TAU); c.fill();
    c.strokeStyle = '#c8d4e0'; c.lineWidth = 8; c.lineCap = 'round'; c.beginPath(); c.moveTo(-34, 0); c.quadraticCurveTo(-48, -10, -46, -26 + Math.sin(t * 6) * 4); c.stroke(); c.lineCap = 'butt';
    if (Math.random() < 0.5) { c.fillStyle = 'rgba(255,255,255,0.8)'; c.fillRect(rnd(-50, 50), rnd(-40, 30), 3, 3); }
  },
  icedragon(c, b, t) {
    const fl = b.flash > 0, wing = Math.sin(t * 6) * 0.4;
    for (const s of [-1, 1]) {
      c.save(); c.scale(s, 1); c.rotate(-0.3 + wing);
      c.fillStyle = 'rgba(127,216,255,0.6)'; c.strokeStyle = '#4a9ad0'; c.lineWidth = 2;
      c.beginPath(); c.moveTo(10, -6); c.lineTo(58, -34); c.lineTo(50, -6); c.lineTo(62, 8); c.lineTo(20, 8); c.closePath(); c.fill(); c.stroke();
      c.restore();
    }
    c.fillStyle = fl ? '#ffffff' : '#7fd8ff'; c.strokeStyle = '#2a6a9a'; c.lineWidth = 2.5;
    c.beginPath(); c.ellipse(0, 8, 22, 28, 0, 0, TAU); c.fill(); c.stroke();
    c.fillStyle = '#d8f2ff'; c.beginPath(); c.ellipse(0, 14, 12, 18, 0, 0, TAU); c.fill();
    c.fillStyle = fl ? '#ffffff' : '#7fd8ff'; c.beginPath(); c.ellipse(0, -28, 16, 13, 0, 0, TAU); c.fill(); c.stroke();
    c.fillStyle = '#ffffff'; for (const x of [-10, -3, 4, 11]) { c.beginPath(); c.moveTo(x - 3, -38); c.lineTo(x, -50); c.lineTo(x + 3, -38); c.fill(); }
    c.fillStyle = b.stage >= 2 ? '#ff3ea5' : '#1b6a9a'; c.beginPath(); c.ellipse(-6, -30, 3, 4, 0, 0, TAU); c.ellipse(6, -30, 3, 4, 0, 0, TAU); c.fill();
    c.fillStyle = '#2a6a9a'; c.fillRect(-6, -21, 12, 3);
  },
  mrak2(c, b, t, face) {
    c.save(); c.scale(1.35, 1.35);
    BSPR.mrak(c, b, t, face);
    c.restore();
    const cg = c.createLinearGradient(-18, -76, 18, -52); cg.addColorStop(0, '#ffffff'); cg.addColorStop(0.45, '#bfeaff'); cg.addColorStop(1, '#5aa8d8');
    c.fillStyle = cg; c.strokeStyle = '#4a7a9a'; c.lineWidth = 1.5;
    c.beginPath(); c.moveTo(-18, -52); c.lineTo(-12, -70); c.lineTo(-6, -56); c.lineTo(0, -76); c.lineTo(6, -56); c.lineTo(12, -70); c.lineTo(18, -52); c.closePath(); c.fill(); c.stroke();
    const gl = Math.max(0, Math.sin(t * 1.7)) ** 8; // блик бегает по ледяной короне
    if (gl > 0.05) { c.fillStyle = `rgba(255,255,255,${gl})`; star(c, -12 + (t * 20 % 24), -62, 3 + gl * 3, t, 4); c.fill(); }
    for (let k = 0; k < 8; k++) { const a = t * 1.2 + k * TAU / 8; c.fillStyle = 'rgba(255,255,255,0.85)'; star(c, Math.cos(a) * 56, -10 + Math.sin(a) * 56, 2.5, t, 6); c.fill(); }
  },
});
