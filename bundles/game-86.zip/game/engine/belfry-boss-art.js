'use strict';

// Each figure is drawn in joint space. Feet follow distance travelled and hands follow the attack clock.
(() => {
  const ink='#263437', shade='#405253', brass='#b68752', gold='#e5c489', ice='#c4eee2';
  const shapes=new Map();
  const fittings=new Image();
  fittings.src='art/belfry-parts.webp';
  function fitting(c,id,x,y,w,h) {
    if (!fittings.naturalWidth) return false;
    const cell=fittings.naturalWidth/3;
    c.drawImage(fittings,(id%3)*cell,Math.floor(id/3)*cell,cell,cell,x,y,w,h);
    return true;
  }
  const swatches=new Map();
  const samples={chainWarden:[0,.34,.39],sluiceHeron:[1,.56,.45],siltCartographer:[2,.29,.35],
    spillHound:[3,.37,.53],mistKeeper:[4,.43,.43],hollowBell:[5,.48,.56]};
  let surface;
  function material(c,kind) {
    if (!fittings.naturalWidth) return null;
    if (!swatches.has(kind)) {
      const [id,u,v]=samples[kind],cell=fittings.naturalWidth/3,cv=makeCanvas(24,24),g=cv.getContext('2d');
      const x=(id%3+u)*cell,y=(Math.floor(id/3)+v)*cell;
      for (const sx of [-1,1]) for(const sy of [-1,1]) {
        g.save();g.translate(12,12);g.scale(sx,sy);g.drawImage(fittings,x,y,32,32,0,0,12,12);g.restore();
      }
      swatches.set(kind,c.createPattern(cv,'repeat'));
    }
    return swatches.get(kind);
  }
  function shape(c,d,fill,outline=ink,width=1.4) {
    let p=shapes.get(d); if(!p){p=new Path2D(d);shapes.set(d,p);}
    if(fill){
      c.fillStyle=fill;c.fill(p);
      if(surface && typeof fill!=='string'){c.save();c.globalAlpha*=.38;c.fillStyle=surface;c.fill(p);c.restore();}
    }
    if(outline){c.lineWidth=width;c.strokeStyle=outline;c.stroke(p);}
  }
  function wash(c,top,bottom,y=-32,h=62) {
    const g=c.createLinearGradient(-9,y,9,y+h);
    g.addColorStop(0,top);g.addColorStop(1,bottom);return g;
  }
  function oval(c,x,y,rx,ry,col,outline,angle=0) {
    c.beginPath();c.ellipse(x,y,rx,ry,angle,0,TAU);c.fillStyle=col;c.fill();
    if(outline){c.lineWidth=1.3;c.strokeStyle=outline;c.stroke();}
  }
  function line(c,x,y,xx,yy,col,w=1.5) {
    c.beginPath();c.moveTo(x,y);c.lineTo(xx,yy);c.strokeStyle=col;c.lineWidth=w;c.stroke();
  }
  function at(c,x,y,r,draw) {
    c.save();c.translate(x,y);c.rotate(r);draw();c.restore();
  }
  function limb(c,x,y,kx,ky,fx,fy,col,w) {
    for(const [color,width] of [[ink,w+2.8],[col,w]]) {
      c.beginPath();c.moveTo(x,y);c.lineTo(kx,ky);c.lineTo(fx,fy);c.strokeStyle=color;c.lineWidth=width;c.stroke();
    }
    if (surface && w>=4) {c.save();c.globalAlpha*=.47;c.strokeStyle=surface;c.lineWidth=w*.85;c.stroke();c.restore();}
    line(c,x-1,y-1,kx-1,ky-1,'#e6dbc285',Math.max(1,w*.21));
    if(w>=4) {
      const rim=w*.35;
      oval(c,kx,ky,rim,rim,ink);oval(c,kx-.35,ky-.55,rim*.71,rim*.71,col);
      line(c,kx-w*.18,ky-1,kx+w*.12,ky-1.3,'#ead0a2',.65);
    }
  }
  function lantern(c,x,y,swing,size) {
    at(c,x,y,swing,()=>{
      c.scale(size,size);line(c,0,0,0,10,brass,1.6);
      shape(c,'M0 9 L6 14 L4 24 L0 27 L-5 23 L-6 14 Z',wash(c,'#fff1af','#f1ab46',13,12),'#394942');
      shape(c,'M-7 14 L-4 10 L3 10 L7 14 Z M-5 24 L4 24 L0 28 Z',brass,ink,1);
      line(c,-2,15,-1,23,'#fff6c9',2);
    });
  }
  function warden(c,v) {
    const swing=Math.sin(v.step)*v.walk, tension=v.force;
    for(const side of [-1,1]){
      const x=side*13, heel=x+side*swing*8, lift=Math.max(0,-side*swing)*7;
      limb(c,x,7,x-side*swing*4,20-lift,heel,33-lift,side<0?'#576661':'#8d8972',11);
      oval(c,heel+2,34-lift,10,4.2,side<0?'#505c58':'#84735b',ink);
      oval(c,x-side*swing*4,20-lift,5.7,4.3,brass,ink);
    }
    c.translate(0,-Math.abs(swing)*1.8+v.breath);
    limb(c,-18,-15,-28,-4-swing*4,-26,8-swing*7,'#777d6b',8);
    shape(c,'M-21 -26 Q-2 -35 18 -24 L24 -3 L15 15 Q0 20 -17 12 L-23 -3 Z',wash(c,'#a38d69','#455c5b'));
    shape(c,'M-21 -18 Q-9 -25 15 -20 L17 -7 Q2 -2 -19 -6 Z',wash(c,'#d8b57b','#9a744c'));
    for(const x of [-16,-7,3,13]) oval(c,x,-12,1.8,1.7,gold);
    shape(c,'M-19 5 Q-1 10 20 3 L18 9 Q0 15 -18 10 Z','#594c40');
    oval(c,4,8,4,3,brass,ink);
    shape(c,'M-15 -2 Q-2 2 12 -3 M-15 1 Q-3 5 11 0',null,'#a0aaa0',1);
    shape(c,'M-13 -23 L-16 -9 L-12 3 M11 -21 L14 -8 L13 1',null,'#72553f',2);
    for(const x of [-14,12]){oval(c,x,-8,2.4,2.4,brass,ink);oval(c,x-.5,-8.7,.85,.7,gold);}
    if (!fitting(c,0,-20,-53,41,44)) {
      oval(c,0,-30,16,16.5,wash(c,'#efc789','#836c4b',-48,37),ink);
      oval(c,4,-31,10.1,9.8,'#334e51','#f1cca0');
      for(const x of [-1,3.6,8]) line(c,x,-38,x+1,-23,brass,1.6);
      line(c,-4,-31,12,-31,'#c8ad79',1.6);
      shape(c,'M-16 -38 Q-6 -53 8 -45',null,'#f3deb4',2);
    }
    at(c,17,-17,-.2-swing*.18-tension*1.25,()=>{
      limb(c,0,0,10,9,12,21,'#89917d',9);
      oval(c,0,0,10,7,brass,ink);oval(c,12,21,5,5.2,'#675c49',ink);
      const sway=.3*Math.sin(v.time*2.8)+tension*.75;
      at(c,12,22,sway,()=>{
        for(let n=0;n<5;n++) {
          const x=Math.sin(n*.52+v.time*2)*n*.45;
          oval(c,x,n*4.1,n%2?1.45:2.6,3.5,'#435957',gold);
        }
        at(c,Math.sin(2+v.time*2)*1.8,21,-sway*.7,()=>{
          shape(c,'M-1 -4 L2 -4 L2 5 Q7 5 9 0 L8 9 Q1 14 -8 8 L-10 1 Q-5 6 -1 6 Z',wash(c,'#d3bb89','#657775',-4,20));
        });
      });
    });
  }
  function heron(c,v) {
    const gait=Math.sin(v.step)*v.walk, strike=v.force, flap=.28*Math.sin(v.time*2.6)+strike*.88;
    for(const side of [-1,1]){
      const x=side*5, lift=Math.max(0,side*gait)*11;
      limb(c,x,3,x-5-side*gait*7,20-lift,x+side*gait*11,36-lift,side<0?'#7a7568':'#ae9263',2.9);
      for(const spread of [-3,0,4]) line(c,x+side*gait*11,36-lift,x+side*gait*11+6,36-lift+spread*.45,brass,1.4);
    }
    c.translate(0,v.breath-Math.abs(gait)*2);
    shape(c,'M-29 7 Q-16 -19 8 -16 Q24 -14 13 1 Q3 14 -15 11 L-30 17 L-22 7 Z',wash(c,'#b2d1cc','#526c76',-20,37));
    at(c,-2,-10,-flap*.6,()=>{
      shape(c,'M5 0 Q-5 -20 -34 -18 Q-26 -10 -29 -5 L-42 10 Q-20 11 2 2 Z','#6c8892');
      for(let i=0;i<5;i++) at(c,-2,-2,.12*i-flap*.48,()=>{
        shape(c,'M2 0 Q-7 -8 -30 0 L-38 4 Q-15 6 2 2 Z',i%2?'#94b7bd':'#668895',ink,.9);
        line(c,-4,0,-29,2,'#c9dbcf',.8);
      });
      at(c,2,-2,-.16-flap*.18,()=>fitting(c,1,-41,-13,45,35));
    });
    at(c,9,-8,.05+strike*.53,()=>{
      shape(c,'M-5 8 Q12 1 1 -9 Q-12 -19 1 -32 Q9 -38 17 -33 L16 -27 Q7 -29 5 -23 Q2 -18 9 -12 Q22 -1 6 10 Z',wash(c,'#e8e4c9','#859c9c',-33,42));
      shape(c,'M0 -30 L-12 -34 L4 -35 L-6 -41 L12 -35 L15 -29 Z','#647983',ink,.85);
      shape(c,'M4 -26 Q-1 -21 4 -15 M7 -13 Q12 -5 6 0 M1 -8 Q8 -2 2 5',null,'#758981',.86);
      shape(c,'M2 -25 Q-2 -18 2 -15 M6 -9 Q11 -3 4 4',null,'#e8e4cc',1);
      oval(c,12,-30,7.6,5.7,'#bcd1c3',ink);
      shape(c,'M17 -32 L38 -28 L17 -27 Z','#dda964');line(c,19,-29,33,-28,'#775e43',1);
      oval(c,14,-31,2.2,2.1,'#f5cf78');oval(c,14.7,-31,1.1,1.2,ink);
    });
  }
  function cartographer(c,v) {
    const stride=v.step, raise=v.force;
    for(const side of [-1,1]) for(let i=0;i<3;i++){
      const swing=Math.sin(stride+i*2.1+side)*v.walk, x=side*(11+i*6),lift=Math.max(0,swing)*5;
      limb(c,side*10,3+i*3,x+side*6,-1+i*5-lift,x+side*(8+swing*5),18+i*4-lift,i%2?'#9a7860':'#ab8c64',4);
    }
    c.translate(0,v.breath-Math.abs(Math.sin(stride)*v.walk)*1.4);
    shape(c,'M-23 8 Q-28 -4 -20 -16 Q-12 -27 3 -27 Q23 -26 27 -9 L23 13 Q0 23 -23 8 Z',wash(c,'#b9b094','#677875'));
    oval(c,-3,-11,19,16,'#927c57',ink,-.18);oval(c,-3,-12,16,13,'#294f56','#d5b987',-.18);
    const carved=fitting(c,2,-29,-37,53,51);
    at(c,carved?4:-3,carved?-8:-12,0,()=>{
      if(!carved) for(let n=0;n<12;n++){const a=n*TAU/12;line(c,Math.cos(a)*11,Math.sin(a)*9,Math.cos(a)*14,Math.sin(a)*11,gold,n%3?.8:1.8);}
      at(c,0,0,v.time*.42+raise*1.4+v.stage*.5,()=>{
        shape(c,'M0 -12 L3 1 L0 0 L-3 1 Z','#efb079',null);shape(c,'M0 12 L3 -1 L0 0 L-3 -1 Z','#c3d6cb',null);
      });oval(c,0,0,2.2,2,gold);
    });
    for(const side of [-1,1]){
      const x=side*13;line(c,x,5,x+side*2,-1,'#726c4d',3);oval(c,x+side*2,-2,2.4,2.6,gold,ink);
      at(c,side*19,6,-side*(.25+raise*.8+Math.sin(stride+side)*v.walk*.16),()=>{
        c.scale(side,1);limb(c,0,0,8,5,15,1,'#927457',4.5);
        shape(c,'M10 0 Q13 -12 25 -10 L21 -4 L16 -1 L22 -1 L28 -5 Q25 6 16 7 Q9 6 10 0 Z',wash(c,'#dfb780','#9b6e51',-10,17));
      });
    }
  }
  function hound(c,v) {
    const pace=v.step, thrust=v.force, crouch=thrust*(v.charging?0:4);
    for(const i of [0,1,2,3]){
      const near=i%2,fore=i>1,x=fore?17:-17,cy=Math.sin(pace+(near?0:Math.PI)+(fore?Math.PI*.8:0))*v.walk;
      const lift=Math.max(0,cy)*9;
      limb(c,x+(near?0:4),3+crouch,x+(fore?-3:8)+cy*9,17-lift,x+(fore?2:-5)+cy*14,29-lift,
        near?'#a37f5d':'#5c6259',near?5.1:4.4);
      oval(c,x+(fore?4:-3)+cy*14,29-lift,4.7,2,near?brass:shade,ink);
    }
    c.translate(0,crouch+v.breath-Math.abs(Math.sin(pace)*v.walk)*2);
    at(c,-21,-2,.2*Math.sin(v.time*3)+v.walk*Math.cos(pace)*.25,()=>{
      shape(c,'M2 -3 Q-15 -5 -19 -18 Q-22 -23 -26 -20 Q-23 -2 -8 3 L2 7 Z','#886e54');
      shape(c,'M-19 -12 L-26 -19 L-27 -27 Q-18 -24 -14 -14 Z','#bb9963');
    });
    shape(c,'M-27 -1 Q-20 -17 -5 -11 Q13 -22 25 -10 Q26 4 15 10 L-6 7 Q-16 13 -25 6 Z',wash(c,'#c39463','#686b59',-15,28));
    for(let n=0;n<5;n++) at(c,-13+n*5,-7-n*.65,-.22,()=>{
      shape(c,'M0 -1 Q5 -5 8 -1 L3 9 L0 10 Z',wash(c,'#d3b18a','#826f56',-4,14),'#695640',.8);
      oval(c,3,0,.85,.9,gold);line(c,2.3,4.4,1.4,7.8,'#c2a57d',.65);
    });
    at(c,18,-7,-.12-thrust*.22,()=>{
      if (fitting(c,3,-9,-32,48,46)) return;
      shape(c,'M-5 2 L0 -13 L-2 -24 L10 -16 L14 -27 L18 -14 L24 -8 L37 -7 L34 -1 L20 3 L11 10 L0 13 Z',wash(c,'#d8a771','#796d57',-24,38));
      shape(c,'M13 -24 L15 -16 L11 -16 Z','#604e43',null);
      shape(c,'M18 -11 L29 -8 L18 -6 Z','#494438',null);oval(c,21,-8.3,1.7,1.1,'#ffe5a1');
      shape(c,'M21 1 L34 -2 L32 5 L22 6 Z','#4b453e');line(c,24,1,24.5,4,'#f2ddb0',1.6);oval(c,34,-6,3.5,2.2,ink);
    });
  }
  function keeper(c,v) {
    const swing=Math.sin(v.step)*v.walk, sway=Math.sin(v.time*2)*.09, cast=v.force;
    for(const s of [-1,1]) limb(c,s*5,6,s*8-s*swing*5,22,s*11+s*swing*7,35-Math.max(0,-s*swing)*6,'#726f59',4.2);
    c.translate(0,v.breath);
    at(c,-2,0,sway+swing*.065,()=>{
      shape(c,'M-8 -26 Q-15 -17 -16 0 L-24 22 L-15 17 L-10 25 L-4 17 L1 25 L7 17 L16 22 L12 0 L11 -20 Z',wash(c,'#79958a','#344e50'));
      shape(c,'M-6 -19 Q-11 2 -16 17 M0 -19 Q-1 0 -4 14 M5 -17 Q5 -3 10 13',null,'#b3b69a',1.3);
      shape(c,'M-9 -18 Q1 -10 12 -18 M-11 -15 Q1 -6 12 -15',null,'#c7b786',1);
      for(const [x,y] of [[-8,-12],[-3,-10],[3,-10],[8,-12]]) oval(c,x,y,1.1,1.6,brass);
      if (fitting(c,4,-18,-60,37,50)) return;
      shape(c,'M-12 -24 Q-12 -42 -1 -45 Q11 -45 14 -25 L5 -13 L-4 -13 Z',wash(c,'#c2c6a8','#698a7f',-44,30));
      shape(c,'M-6 -26 Q0 -39 9 -28 L6 -21 L0 -17 Z','#364c4c');oval(c,5,-26,1.4,1.9,'#f3ce83');
      for(const side of [-1,1]) at(c,side*6,-40,side*.12,()=>{
        c.scale(side,1);
        shape(c,'M0 3 Q4 -4 6 -13 L6 -19 M5 -9 Q12 -10 14 -17 M4 -5 Q10 -3 14 -8',null,brass,2.2);
      });
    });
    at(c,7,-19,-.23-swing*.15-cast*.65,()=>{
      limb(c,0,0,11,8,16,3,'#8c947f',5);
      at(c,17,4,.25+swing*.07,()=>{
        line(c,0,-27,0,46,'#675c47',3.4);shape(c,'M0 -22 Q6 -35 15 -25 Q17 -21 13 -20',null,gold,2);
        lantern(c,13,-21,.22*Math.sin(v.time*2.7)+cast*.63,1);
      });
    });
    lantern(c,-13,0,sway*2-swing*.22,.53);
  }
  function bell(c,v) {
    const swing=Math.sin(v.step)*v.walk, open=v.force+.13*Math.sin(v.time*2), phase=v.stage;
    c.translate(0,v.breath*1.6-Math.abs(swing)*2);
    for(const side of [-1,1]) at(c,side*9,-19,-side*(.3+open*.44),()=>{
      c.scale(side,1);
      for(let i=0;i<3;i++) at(c,0,0,.19*i,()=>{
        shape(c,'M0 6 Q4 -18 38 -30 Q33 -7 11 4 L1 9 Z',i%2?'#6c8b8f':'#9caaa0','#4d6567',1.1);
        shape(c,'M3 5 Q16 -12 35 -26 M14 -5 Q20 -4 24 -7',null,'#e2c489',.8);
      });
    });
    if (!fitting(c,5,-33,-20,67,56)) {
      const skirt=wash(c,'#cca76f','#626c66',-16,52);
      shape(c,'M-13 -17 Q-20 -10 -19 2 Q-20 17 -32 27 Q-16 37 1 34 Q21 37 33 27 Q19 17 17 0 Q17 -12 11 -17 Z',skirt);
      for(const x of [-14,-7,2,10]) at(c,x,-6,-x*.012,()=>shape(c,'M0 0 Q-3 13 -4 31',null,'#dfc087',1.1));
      oval(c,0,27,31,6.7,'#4c5654',gold);
    }
    at(c,0,20,.4*Math.sin(v.time*2.8)+open*.48,()=>{line(c,0,0,0,13,brass,2.5);oval(c,0,15,4.6,4.8,gold,ink);});
    shape(c,'M-9 -39 Q0 -46 10 -38 L14 -26 Q10 -15 0 -12 Q-13 -15 -15 -26 Z',wash(c,'#a8b4a3','#51686b',-40,32));
    shape(c,'M-8 -31 Q0 -42 8 -30 Q11 -24 1 -18 Q-6 -21 -8 -31 Z','#31484e');
    shape(c,'M-11 -41 L-13 -49 L-6 -45 L-2 -54 L4 -46 L11 -50 L10 -40 Q0 -37 -11 -41 Z',wash(c,'#edcf8f','#9a764f',-52,13));
    shape(c,'M-11 -34 Q-12 -23 -4 -16 M9 -35 Q14 -26 6 -18',null,'#cfbb8d',1.4);
    for(const [x,y] of [[-12,-31],[-8,-21],[8,-21],[11,-29]])oval(c,x,y,1,1.6,gold);
    if(phase>=2) shape(c,'M-4 -35 L0 -29 L-3 -25 L3 -20',null,'#f0d59e',1.6);
    for(const side of [-1,1]){
      const handY=-1-open*side*9, hx=side*(20+open*5);
      limb(c,side*10,-14,side*21,-17+side*swing*3,hx,handY,'#86968b',4.3);
      oval(c,hx,handY,3.3,3.1,gold);line(c,hx,handY,hx-side*7,23,'#c0a574',1);
    }
  }
  const bodies={chainWarden:warden,sluiceHeron:heron,siltCartographer:cartographer,spillHound:hound,mistKeeper:keeper,hollowBell:bell};
  // All six poses, including outstretched wings and the anchor, fit in this local square.
  const poseSize = 160;
  const hitCanvas = makeCanvas(1, 1);
  const hitCtx = hitCanvas.getContext('2d');
  function drawHitPose(c, body, pose, flash) {
    const transform = c.getTransform();
    const pixels = Math.max(1, Math.ceil(poseSize * Math.hypot(transform.a, transform.b)));
    if (pixels > hitCanvas.width) {
      hitCanvas.width = hitCanvas.height = Math.ceil(pixels / 64) * 64;
    }
    hitCtx.clearRect(0, 0, pixels, pixels);
    hitCtx.save();
    hitCtx.setTransform(pixels / poseSize, 0, 0, pixels / poseSize, pixels / 2, pixels / 2);
    hitCtx.lineCap = hitCtx.lineJoin = 'round';
    body(hitCtx, pose);
    hitCtx.restore();

    // Tint the finished silhouette once. Canvas filters on individual strokes stall mobile rendering.
    hitCtx.save();
    hitCtx.globalCompositeOperation = 'source-atop';
    hitCtx.globalAlpha = .52 * Math.min(1, flash / .06);
    hitCtx.fillStyle = '#fff0cf';
    hitCtx.fillRect(0, 0, pixels, pixels);
    hitCtx.restore();
    c.drawImage(hitCanvas, 0, 0, pixels, pixels, -poseSize / 2, -poseSize / 2, poseSize, poseSize);
  }
  for(const [kind,body] of Object.entries(bodies)){
    BSPR[kind]=(c,b,t)=>{
      const time=t||0, active=b.mode && b.mode!=='idle' && b.mode!=='trans';
      const beat=(b.mode==='tidalRun' && b.sub===2) ? 1 : Math.max(0,Math.sin(Math.min(1,Math.max(0,b.t||0))*Math.PI));
      const force=active ? .20+.8*beat : 0;
      c.save();c.lineJoin='round';c.lineCap='round';c.imageSmoothingEnabled=true;
      const scale=BOSSES[kind].r/34; c.scale((Math.cos(b.look||0)<0?-1:1)*scale,scale);
      surface=material(c,kind);
      const pose={time,step:b.stride||0,walk:b.walk||0,breath:Math.sin(time*2.2)*1.2,force,stage:b.stage||0,charging:b.charging};
      if (b.flash > 0) drawHitPose(c, body, pose, b.flash);
      else body(c, pose);
      c.restore();
    };
  }
})();
