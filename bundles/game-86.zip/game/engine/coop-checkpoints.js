'use strict';

const CoopCheckpoints = (() => {
  const key = 'krilessa_coop',
    personal = 'krilessa_coop_me';
  const modes = ['story', 'defense', 'rush'];
  const mode = (ch) => (typeof ch === 'number' ? 'story' : ch);
  const slot = (ch) => key + '_' + mode(ch);
  const load = (k) => GameStorage.readRecord(k);
  const copy = (x) => JSON.parse(JSON.stringify(x));
  function list() {
    const found = [load(key), ...modes.map((m) => load(slot(m)))].filter(
      (s) => s && s.id && Number.isFinite(s.seed),
    );
    return found.map(s => s.ch === 8 ? Belfry.migrate(s) : s)
      .sort((a, b) => (b.at || 0) - (a.at || 0))
      .filter((s, i, a) => a.findIndex((v) => v.id === s.id) === i);
  }
  function mine() {
    return {
      id: NET.coopId,
      level: P.level,
      xp: P.xp,
      up: { ...P.up },
      bonus: { ...P.bonus },
      shards: P.shards,
      hp: Math.ceil(P.hp),
      sp: P.sp,
      pending: G.pendingLv,
      hero: P.hero,
    };
  }
  function story() {
    return {
      holes: World.holes.map((h) => +h.spent),
      defeated: G.defeated.slice(),
      ml: [...G.melted],
      cp: G.activeBoss || G.activeShrine || P.down ? { ...G.cp } : { x: P.x, y: P.y },
      chests: World.chests.map((c) => +(c.open && (!c.mimic || c.mimicDone))),
      pl: World.pearls.map((p) => +p.got),
      fl: World.fires.map((f) => +f.lit),
      keys: G.keys,
      kills: G.kills,
      time: G.time,
      clues: World.clues.map((p) => +p.found),
      npcs: World.npcs.map((n) => n.state),
      qi: World.qitems.map((i) => +i.active + 2 * +i.taken),
      dr: World.drifts.map((d) => +d.done),
      gl: World.glades.map((g) => +g.done),
      shrines: World.shrines.map((s) => +(s.state === 'done')),
      acc: G.accused,
      calm: { ...G.calm },
      bestCombo: G.bestCombo,
      used: [G.phoenixUsed, G.secondUsed],
    };
  }
  function capture() {
    const base = {
      v: 2,
      id: NET.coopId,
      ch: NET.ch,
      seed: NET.seed,
      layout: World.revision,
      diff: NET.diff,
      mut: Challenges.mutIds(),
    };
    if (NET.ch === 'defense') {
      const a = G.abyss;
      if (!a || a.done || a.calledEarly || a.wave !== a.passed) return NET.checkpoint;
      const snap = Defense.defSnap();
      // Soldiers respawn through the host simulation. Guests also use this snapshot between waves.
      snap[6] = [];
      snap[8] = 0;
      snap[12] = [];
      return {
        ...base,
        map: a.map,
        defense: snap,
        waveSeed: a.seed,
        pool: a.pool,
        elapsed: a.t,
        repaired: a.repairedWave,
        leaks: a.leaks,
        built: a.built,
        kills: G.kills,
        time: G.time,
        owners: NET.roster.map((r) => [r.id, r.name]),
        factory: G.td.fac ? { crate: G.td.fac.crate, work: G.td.fac.work } : null,
      };
    }
    if (NET.ch === 'rush') {
      const r = G.rush;
      if (!r || r.done || r.idx >= r.total) return NET.checkpoint;
      return {
        ...base,
        pool: NET.rush,
        round: r.idx,
        elapsed: r.t,
        links: r.links,
        time: G.time,
        kills: G.kills,
      };
    }
    return Object.assign(base, story());
  }
  function storeWorld(world) {
    if (!world || world.id !== NET.coopId) return false;
    // A wave restarts from its invitation to build, including each player's build at that point.
    const inWave = NET.ch === 'defense' && G.abyss && (G.abyss.wave !== G.abyss.passed || G.abyss.done);
    const previous = inWave && load(slot(NET.ch));
    const me =
      previous &&
      previous.mine &&
      previous.id === world.id &&
      previous.defense &&
      previous.defense[4] === world.defense[4]
        ? previous.mine
        : mine();
    const record = { ...world, ...me, mine: me, at: Date.now() };
    // Keep the world separate from a device's private build when forwarding it.
    if (!GameStorage.write(slot(NET.ch), record)) return false;
    GameStorage.write(key, record);
    GameStorage.write(personal, me);
    return true;
  }
  function accept(world) {
    if (
      !NET.on ||
      NET.completed ||
      !G.netRun ||
      !world ||
      world.id !== NET.coopId ||
      world.ch !== NET.ch
    )
      return false;
    NET.checkpoint = world;
    return storeWorld(world);
  }
  function clear() {
    if (!NET.coopId) return;
    for (const k of [slot(NET.ch), key, personal])
      if ((load(k) || {}).id === NET.coopId) GameStorage.remove(k);
    NET.checkpoint = null;
    NET.completed = true;
  }
  function save() {
    if (!NET.on || !G.netRun || !NET.coopId || NET.loading || NET.completed || !NET.started)
      return false;
    if (
      (typeof NET.ch === 'number' && Session.bosses.length && G.defeated[Session.bosses.length - 1]) ||
      (G.rush && G.rush.idx >= G.rush.total)
    ) {
      if (NET.host) NetT.send(-1, { t: 'saveDone', cid: NET.coopId });
      clear();
      return false;
    }
    if (!NET.host) return storeWorld(NET.checkpoint);
    const world = capture();
    if (!world) return false;
    NET.checkpoint = copy(world);
    const ok = storeWorld(NET.checkpoint);
    NetT.send(-1, { t: 'saveWorld', cid: NET.coopId, world: NET.checkpoint });
    return ok;
  }
  function strip(record) {
    if (!record) return null;
    const { mine, level, xp, up, bonus, shards, hp, sp, pending, hero, at, ...world } = record;
    return world.ch === 8 ? Belfry.migrate(world) : world;
  }
  function restore(w) {
    if (!w) return;
    G.kills = w.kills || 0;
    G.time = w.time || 0;
    if (w.ch === 'defense' && w.defense) {
      const dz = copy(w.defense),
        owners = new Map(w.owners || []);
      for (const tower of dz[5]) {
        const owner = NET.roster.find((r) => r.name === owners.get(tower[6]));
        tower[6] = owner ? owner.id : 1;
      }
      Defense.defNetApply(dz);
      const a = G.abyss;
      Object.assign(a, {
        seed: w.waveSeed,
        pool: w.pool || a.pool,
        t: w.elapsed || 0,
        repairedWave: w.repaired,
        leaks: w.leaks || 0,
        built: w.built || 0,
      });
      if (w.factory && G.td.fac) Object.assign(G.td.fac, w.factory);
      if (NET.host) {
        a.q = [];
        a.next = Defense.tdMakeWave(a.wave + 1);
        for (const spot of G.td.spots)
          if (spot.tw) {
            spot.tw.paid = a.wave;
            if (spot.tw.k === 'cats') Defense.tdMakeUnits(spot.tw);
          }
      }
      return;
    }
    if (w.ch === 'rush' && G.rush) {
      Object.assign(G.rush, { idx: w.round || 0, t: w.elapsed || 0, links: w.links || 0, wait: 2.5 });
      for (const b of Session.bosses)
        if (b.id < G.rush.idx) {
          b.hp = 0;
          b.state = 'dead';
          G.defeated[b.id] = true;
        }
      return;
    }
    Saves.coopApplyWorld({
      df: w.defeated || w.df,
      ml: w.ml,
      cp: w.cp,
      ch: w.chests || (Array.isArray(w.ch) ? w.ch : []),
      pl: w.pl,
      fl: w.fl,
    });
    World.holes.forEach((h, i) => {
      h.spent = !!(w.holes || [])[i];
    });
    G.keys = w.keys || 0;
    G.bestCombo = w.bestCombo || 0;
    G.calm = w.calm || {};
    G.clues5 = [0, 0, 0, 0];
    World.clues.forEach((p, i) => {
      p.found = !!(w.clues || [])[i];
      if (p.found) G.clues5[p.i]++;
    });
    World.npcs.forEach((p, i) => {
      p.state = (w.npcs || [])[i] || 'new';
    });
    World.qitems.forEach((p, i) => {
      const v = (w.qi || [])[i];
      p.active = !!(v & 1);
      p.taken = !!(v & 2);
    });
    World.drifts.forEach((p, i) => {
      if ((w.dr || [])[i]) {
        p.done = true;
        p.hp = 0;
      }
    });
    World.glades.forEach((p, i) => {
      p.done = !!(w.gl || [])[i];
      if (p.ring.some((k) => World.tiles[k] !== ROCK)) p.seen = p.open = true;
    });
    World.shrines.forEach((s, i) => {
      if ((w.shrines || [])[i]) s.state = 'done';
    });
    G.accused = !!w.acc;
    G.boardPending = !!(World.CFG.detective && World.gateOpen && !G.accused);
    [G.phoenixUsed, G.secondUsed] = w.used || [false, false];
  }
  function localBuild(id) {
    return [load(slot(NET.ch)), load(key), load(personal)].find((s) => s && s.id === id);
  }
  function manual() {
    if (NET.client) NetT.send(0, { t: 'saveReq', cid: NET.coopId });
    const ok = save();
    const message = ok ? 'Сохранено на этом устройстве' : 'Не удалось записать сохранение';
    $('coopSaveStatus').textContent = message;
    RunStats.toast(message);
  }
  return { save, accept, restore, clear, strip, list, localBuild, manual };
})();
