'use strict';

const Chapters = (() => {
  // ------------------------------------------------------------------
  //  Запуск глав
  // ------------------------------------------------------------------
  function loadChapter(n, seed, revision) {
    Viewport.setZoomFactor(n === 8 ? .85 : 1);
    World.generateWorld(n, seed, revision);
    document.body.dataset.chapter = n;
  }
  function resetRun() {
    G.healReadout=null; StarTrail.reset(); G.cam.leadX=G.cam.leadY=0; G.cam.framing=1; Viewport.setFraming(1);
    G.time = 0; G.kills = 0; G.defeated = World.CFG.bosses.map(() => false);
    G.cp = { x: World.tc(World.START.x), y: World.tc(World.START.y) };
    G.enemies = []; G.feathers = []; G.ebullets = []; G.hazards = []; G.pickups = []; G.parts = []; G.texts = []; G.bolts = []; G.rings = []; G.beams = [];
    G.shake = 0; G.hurtFlash = 0; G.activeBoss = null; G.pendingLv = 0; G.spawnT = 2; G.gateMsgT = 0; G.lowHpT = 0; G.calm = {}; G.bossHeartT = 12; G.champ = null; G.champT = 150;
    G.invertT = 0; G.staticT = 0; G.clues5 = [0, 0, 0, 0]; G.clueMsgT = 0; G.revealT = 0; G.hidden = null; G.hideT = 0; G.jump = null; G.pet = null;
    G.clearSight = false; G.boardPending = false; G.nearNpc = null; G.eyes = null; G.eyesT = 10; G.glitchT = 30; G.glitchFx = 0; G.flickT = -5; G.flickGap = 8; G.accused = false;
    P.z = 0; P.napT = 0; P.pounce = false; P.lives = 0; P.down = false; P.revT = 0;
    G.abyss = null; G.core = null; G.td = null; G.daily = null; G.mut = null; G.mutEarned = undefined; G.bossHurt = false;
    G.keys = 0; G.phoenixUsed = false; G.secondUsed = false; G.relicPending = false; G.guardT = 0; G.hintT = 0; G.mmHintT = 0; G.freePicks = 0;
    G.team = null; G.teamSave = null; G.tessaAlly = null; G.blizzardT = 0; G.blizA = 0; G.blizT = 55; G.melted = []; G.meltHits = {}; G.crackHits = {}; G.iceSaid = false; G.nearFire = null;
    for (const f of World.fires) f.lit = false;
    P.ivx = 0; P.ivy = 0; P.discoT = undefined;
    G.wxId = null; G.wxT = 0; G.lastWx = null; G.falling = []; G.chill = 0; G.cookieT = 0; G.caveA = 0; G.caveSaid = false; G.curSaid = false; G.onCurrent = false; G.fishing = null; G.baking = null;
    for (const d of World.drifts) { d.hp = 3; d.done = false; }
    for (const g of World.glades) { g.open = false; g.done = false; g.seen = false; }
    for (const o of World.holes.concat(World.ovens)) { o.cd = 0; o.prog = 0; o.spent=false; o.angler=null; }
    for (const ch of World.chests) { ch.mimicDone = false; ch.seen = false; }
    for (const bd of World.beds) { bd.cd = 0; bd.nap = 0; }
    for (const q of World.clues) q.found = false;
    for (const n of World.npcs) n.state = 'new';
    for (const it of World.qitems) { it.active = false; it.taken = false; }
    for (const s of World.shelves) { s.cd = 0; s.inside = false; }
    G.cutscene = null; G.victoryShown = false; G.cageOpen = 0; G.combo = 0; G.comboT = 0; G.bestCombo = 0; G.activeShrine = null;
    P.level = 1; P.xp = 0; P.xpNext = Actors.xpFor(1); P.up = {}; P.bonus = {}; P.shards = 0; P.maxHp = 100; P.hp = 100;
    P.inv = 0; P.dashT = 0; P.dashCd = 0; P.fireT = 0; P.boltT = 1; P.face = 1; P.slowT = 0; P.shieldT = 0; P.vx = 0; P.vy = 0;
    P.hero = World.CFG.hero; P.sp = 0; P.stormT = 0; G.pzones = []; G.novas = []; G.scaleCache = {};
    if (G.ev) Encounters.endEvent();
    G.ev = null; G.evT = EVENT_EVERY; G.lowHpSaid = false; G.finalFinal = null; G.rush = null; G.trueWin = false; G.st = null; G.zm = null;
    Story.trickTimers.forEach(clearTimeout); Story.trickTimers = [];
    for (const c of World.chests) c.open = false;
    for (const s of World.shrines) s.state = 'idle';
    World.gateOpen = false;
    Terrain.resetFog();
    Screens.Dialog.clear();
  }
  function beginPlay() {
    G.inMenu = false;
    const prof = Saves.loadProfile();
    G.tal = Object.assign({}, prof.talents || {});
    G.relicLv = Object.assign({}, prof.relicLv || {});
    try { G.myAura = Achievements.myLook(prof).au; } catch (e) { G.myAura = 'none'; }
    G.relics = (prof.relics || []).filter(id => RELICS[id]).slice(0, Actors.relicMax());
    G.diffId = (prof.settings && prof.settings.diff) || 'normal'; G.diff = DIFFS[G.diffId] || DIFFS.normal;
    G.evT = EVENT_EVERY * G.diff.event * (Seasons.weekEv('fest') ? 0.5 : 1);
    if (Seasons.weekEv('champ')) G.champT = Math.min(G.champT, 75);
    P.maxHp = 100; Actors.computeStats(); P.hp = P.maxHp;
    Expedition.initTeam(G.teamSave); G.teamSave = null;
    P.lives = World.CFG.rush || World.CFG.abyss ? 0 : HEROES[P.hero].lives || 0;
    if (World.CHN === 5) { const ch4 = prof.ch4Choice; G.pet = ch4 === 'kind' ? { x: P.x, y: P.y, fireT: 1 } : null; G.clearSight = ch4 === 'good'; }
    P.x = G.cp.x; P.y = G.cp.y; World.ensureWalkable(P);
    if (World.CFG.tessaStart) G.tessaAlly = { x: P.x + 34, y: P.y + 8, fireT: 1.2, face: 1 };
    Bosses.makeBosses();
    Terrain.revealFog(P.x, P.y, 12);
    $('dashBtn').querySelector('span').textContent = HEROES[P.hero].dash;
    Screens.setState('play');
    if (!G.st) G.st = RunStats.newRunStats();
    else if (!String(G.st.diff).split('→').includes(G.diffId)) G.st.diff += '→' + G.diffId; // сложность меняли по ходу
    Sound.init(); Encounters.biomeMusic(true);
    if (!World.CFG.rush) setTimeout(() => MenuActions.rotHintMaybe(), 1600);
  }
  // Если герой слабее стартового уровня главы – автонабор + последние улучшения на выбор
  function newChapter(n, seed, revision) {
    loadChapter(n, seed || 1 + Math.floor(Math.random() * 2e9), revision); resetRun();
    if (G.mutNext) { G.mut = {}; for (const id of G.mutNext) if (Challenges.MUT_BY[id]) G.mut[id] = true; }
    if (G.dailyNext && !NET.on) G.daily = G.dailyNext;
    G.mutNext = null; G.dailyNext = null;
    StarTrail.start();
    if (NET.on) P.hero = NET.hero; // вместе каждая играет своей героиней
    else if (!G.daily) GameStorage.remove(Saves.saveKey(n)); // испытание дня не трогает сохранение главы
    // прокачка своя в каждой главе: всегда с 1 уровня. Навсегда остаются реликвии и таланты
    beginPlay();
    { const pr = Saves.loadProfile(); if (HUD.MM_STYLE !== 'classic' && (pr.mmHintN || 0) < 3) { G.mmHintT = 6; pr.mmHintN = (pr.mmHintN || 0) + 1; Saves.saveProfile(pr); } }
    const tStart = Actors.talent('start');
    if (tStart) { G.pendingLv += tStart; G.freePicks = tStart; }
    if (Actors.talent('super')) P.sp = 25 * Actors.talent('super');
    if (n === 1) {
      G.hintT = 6;
      Screens.showBanner('Спаси Рыжовую!', 'Победи трёх стражей и открой Тёмный замок');
      Screens.say('Крилесса! Колдун Мрак запер меня в Тёмном замке!', 4);
      Screens.say('Победи трёх стражей – тогда ворота откроются. Иди по стрелке!', 4.5);
      Screens.say('Убивай врагов – копи СУПЕР-удар (кнопка над рывком)!', 4);
    } else if (n === 2) {
      Screens.showBanner('Глава 2', 'Кринж-Цитадель');
      Screens.say('Крилесса! Зямочкккк утащил меня в свою Кринж-Цитадель! Тут везде его портреты и диско-шары!!!', 5);
      Screens.say('Победи четырёх стражей: Кактуса, Пчелу, Голема и Паука. Враги здесь подстраиваются под твою силу!', 6);
    } else if (n === 3) {
      Screens.showBanner('Глава 3', 'Рыжовая спешит на помощь');
      Screens.say('Рыжовая! Это я, Крилесса! Зямочкккк запер меня в Зеркальном дворце!', 5);
      Screens.say('Победи четырёх стражей Зямоверса. Огонь в твоих волосах – твоё оружие! 🔥', 5);
      Screens.say('Твоя ВСПЫШКА переносит сквозь врагов и оставляет огненный след. СУПЕР – огненная волна!', 6);
    } else if (n === 4) {
      Screens.showBanner('Глава 4', 'Ночь глитчей');
      Screens.say('Мрр… Три часа ночи. Почему мигает свет? И кто шепчет в колонке?..', 5);
      Screens.say('Я царапаю сама. ПРЫЖОК – прыжок-кусь, СУПЕР – мурчание: лечит и оглушает.', 6);
      Screens.say('У кошки девять жизней 🐾. А на лежанке можно вздремнуть – станет легче.', 5.5);
      Screens.say('Тёплый свет ламп пугает глитчей. Держись поближе к свету…', 4.5);
    } else if (n === 5) {
      HouseChapter.unlockOutfit('hat');
      Screens.showBanner('Глава 5', 'Пропавший корм');
      Screens.say('Миска пуста. ВСЕ миски пусты. Это дело для детектива Тессы. 🕵️', 5);
      Screens.say('У каждого подозреваемого спрятано три улики – найди их, и он не отвертится.', 5.5);
      Screens.say('Полки 🐾 – кошачьи короткие пути. В коробке 📦 меня никто не найдёт.', 5);
      const ch4 = Saves.loadProfile().ch4Choice;
      if (ch4 === 'kind') Screens.say('Мяу.exe теперь мой маленький пиксельный котик. Он помогает искать улики!', 5);
      else if (ch4 === 'good') Screens.say('После ночи с глитчами я вижу яснее: все улики видны на мини-карте.', 5);
    } else if (n === 6) {
      Screens.showBanner('Глава 6', 'Мрак: новый сезон');
      Screens.say('Крилесса! Рыжовая! Я в ледяной клетке на вершине замка… Тут так холодно! 🥶', 5);
      Screens.say('Победите четырёх стражей зимы – тогда ворота Ледяного замка откроются.', 5);
      Screens.say('Вы теперь вдвоём! Кнопка 🔄 меняет героиню. Пока одна бьётся – вторая отдыхает.', 6);
      Screens.say('Костры 🔥 греют и лечат. Огонь Рыжовой растапливает лёд и сугробы – за ними прячутся сокровища!', 5.5);
      Screens.say('По ледяным рекам можно мчаться с ветерком – но тормозить на льду трудно! ⛸️', 4.5);
    } else if(n===8) {
      Screens.showBanner('Третий звон', 'Открой пять шлюзов, чтобы спуститься за Варей');
      if (!NET.client) for (const [dx,dy,kind] of [[-3,-2,'crab'],[4,-2,'bat'],[1,-4,'slime']])
        Enemies.spawnEnemy(kind,World.tc(World.START.x+dx),World.tc(World.START.y+dy),B8,{instant:true,E:1});
      Saves.saveGame();
    } else if (n === 7) {
      Screens.showBanner('Глава 7', 'Крилевая бездна');
      Screens.say('Буль! Мы под водой! Тесса с нами – в пузыре-шлеме, и она тоже стреляет. 🫧', 5);
      Screens.say('Криль украл все слова любви и спрятал в жемчужины 💗. Собери все 12!', 5.5);
      Screens.say('Синие течения несут быстро – прыгай в них, чтобы мчаться по карте. 🌊', 5);
      Screens.say('Четыре стража бездны охраняют путь к Крилевому замку. А на дне кто-то ОЧЕНЬ ругается…', 5.5);
    }
    if (G.pendingLv > 0) Screens.openLevelUp();
  }
  function continueChapter(n) {
    const s = Saves.loadSave(n);
    if (!s || (s.v || 0) < 5) { newChapter(n); return; }
    loadChapter(n, s.seed, s.layout || 0); resetRun();
    if (s.mut && s.mut.length) { G.mut = {}; for (const id of s.mut) if (Challenges.MUT_BY[id]) G.mut[id] = true; }
    StarTrail.start(s.starTrail);
    P.sp = s.sp || 0;
    G.defeated = World.CFG.bosses.map((_, i) => !!(s.defeated && s.defeated[i]));
    World.restoreBridge();
    G.kills = s.kills || 0; G.time = s.time || 0; G.cp = s.cp || G.cp; G.bestCombo = s.bestCombo || 0;
    P.level = s.level || 1; P.xp = s.xp || 0; P.xpNext = Actors.xpFor(P.level); P.up = s.up || {}; P.bonus = s.bonus || {}; P.shards = s.shards || 0;
    (s.chests || []).forEach((o, i) => { if (World.chests[i]) { World.chests[i].open = !!o; if (o && World.chests[i].mimic) World.chests[i].mimicDone = true; } });
    (s.cs || []).forEach((o, i) => { if (World.chests[i]) World.chests[i].seen = !!o; });
    G.keys = s.keys || 0; G.phoenixUsed = !!s.ph; G.secondUsed = !!s.sw;
    (s.shrines || []).forEach((o, i) => { if (World.shrines[i] && o) World.shrines[i].state = 'done'; });
    G.st = s.st || null; G.lowHpSaid = !!s.lowHp; G.calm = s.calm || {};
    (s.clues || []).forEach((f, i) => { if (World.clues[i] && f) { World.clues[i].found = true; G.clues5[World.clues[i].i]++; } });
    (s.npcs || []).forEach((st, i) => { if (World.npcs[i]) World.npcs[i].state = st; });
    (s.qi || []).forEach((v, i) => { if (World.qitems[i]) { World.qitems[i].active = !!(v & 1); World.qitems[i].taken = !!(v & 2); } });
    (s.ml || []).forEach(i => Expedition.meltTile(i, false));
    (s.fl || []).forEach((v, i) => { if (World.fires[i]) World.fires[i].lit = !!v; });
    World.holes.forEach((h,i)=>{h.spent=!!(s.holes || [])[i];});
    (s.dr || []).forEach((v, i) => { if (World.drifts[i] && v) { World.drifts[i].done = true; World.drifts[i].hp = 0; } });
    (s.gl || []).forEach((v, i) => { if (World.glades[i] && v) World.glades[i].done = true; });
    (s.pl || []).forEach((v, i) => { if (World.pearls[i] && v) World.pearls[i].got = true; });
    for (const g of World.glades) if (g.ring.some(i => World.tiles[i] !== ROCK)) { g.open = true; g.seen = true; }
    if (s.tm && World.CFG.team && World.CFG.team.includes(s.tm.h)) P.hero = s.tm.h;
    G.teamSave = s.tm || null;
    beginPlay();
    World.gateOpen = Bosses.guardiansDone() >= Bosses.guardiansCount();
    G.accused = !!s.acc;
    if (World.CFG.detective && World.gateOpen && !G.accused) G.boardPending = true;
    // старые сохранения: локации уже побеждённых стражей сразу усмирены
    Session.bosses.forEach((b, i) => { if (G.defeated[i] && b.calmBiome >= 0 && G.calm[b.calmBiome] === undefined) G.calm[b.calmBiome] = 0; });
    Screens.say(World.gateOpen ? (n===8 ? World.CFG.gateSay : 'Ворота открыты! Скорее в замок!') : `С возвращением! Стражей побеждено: ${Bosses.guardiansDone()}/${Bosses.guardiansCount()}.`);
  }
  function chapterOpen(n, prof = Saves.loadProfile()) {
    return GameLoop.DEBUG || !!prof.admin || n === 1 || !!prof['ch' + (n - 1) + 'Done'];
  }
  function startChapter(n) {
    if (!chapterOpen(n)) { RunStats.toast(`🔒 Сначала пройди главу ${n - 1}`); return; }
    { const pr = Saves.loadProfile(); pr.lastCh = n; Saves.saveProfile(pr); } // для стартового экрана
    if (Saves.loadSave(n)) { continueChapter(n); return; }
    if (n === 1) { newChapter(1); return; }
    const intro = () => Intro.start('ch' + n, () => newChapter(n));
    // загадки глав 4 и 7 – прямо в начале главы (в первый раз), а не только по кнопке
    const pr = Saves.loadProfile();
    if (n === 4 && !pr.ch4Done) Story.openTeaser(intro);
    else if (n === 7 && !pr.ch7Done) Story.openKrillTeaser(intro);
    else intro();
  }
  const startChapter2 = () => startChapter(2);

  return {
    loadChapter, resetRun, beginPlay, newChapter, continueChapter, chapterOpen, startChapter,
    startChapter2,
  };
})();
