'use strict';

const BelfryArt = (() => {
  const art = {};
  function picture(name) {
    if (!art[name]) {
      art[name] = new Image();
      art[name].src = 'art/bell-' + name + '.webp';
    }
    return art[name];
  }
  function preload(scenes) { for (const shot of scenes) picture(shot.art); }
  function drawScene(c,w,h,sc,t) {
    const img=picture(sc.art), wide=w>h*1.18;
    c.fillStyle='#112021'; c.fillRect(0,0,w,h);
    if (!img.naturalWidth) return;
    const bw=wide?w*.60:w, bh=wide?h:h*.79;
    const drift=window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 0 : Math.min(1,t/6);
    const scale=Math.max(bw/img.width,bh/img.height)*(1+.03*drift);
    const dw=img.width*scale,dh=img.height*scale;
    const [fx,fy]=sc.focus;
    c.save();c.beginPath();c.rect(0,0,bw,bh);c.clip();
    c.drawImage(img,(bw-dw)*fx,(bh-dh)*fy,dw,dh);
    c.restore();
    const blend=wide?c.createLinearGradient(bw*.78,0,bw,0):c.createLinearGradient(0,bh*.78,0,bh);
    blend.addColorStop(0,'rgba(17,32,33,0)');blend.addColorStop(1,'#112021');
    if (wide){c.fillStyle=blend;c.fillRect(bw*.78,0,bw*.22+1,h);}
    else {c.fillStyle=blend;c.fillRect(0,bh*.78,w,bh*.22+1);}
  }
  // Water recedes to the lower ring after each sluice. The brass tide marks stay on the stone.
  function basin(c, vis) {
    const x = World.tc(World.CASTLE.x), y = World.tc(World.CASTLE.y);
    const radius = (World.CASTLE.half - .8) * World.T;
    if (!vis(x, y, radius + World.T * 2)) return;
    const count=Bosses.guardiansCount(), closed=count-Bosses.guardiansDone();
    c.save();
    c.translate(x,y);
    for (const frac of [.38,.65,.94]) {
      c.beginPath(); c.arc(0,0,radius*frac,0,TAU);
      c.strokeStyle = '#b8aa837d'; c.lineWidth = 3; c.stroke();
    }
    if (closed > 0) {
      const r = radius * (.15+.81*closed/count);
      const water = c.createRadialGradient(0,0,3,0,0,r);
      water.addColorStop(0,'#163c52ed'); water.addColorStop(.85,'#315c6be8'); water.addColorStop(1,'#79a9a9dc');
      c.fillStyle = water; c.beginPath(); c.arc(0,0,r,0,TAU); c.fill();
      c.lineWidth = 2; c.strokeStyle = '#c9e4de8a';
      for(let i=0;i<5;i++){
        const f = (i+.5)/5;
        c.beginPath(); c.ellipse(Math.sin(i*9)*r*.18,(f-.5)*r, r*(.15+f*.26),3+Math.sin(G.time*1.3+i),0,.12,2.85); c.stroke();
      }
    } else {
      c.strokeStyle='#ab9369'; c.lineWidth=3;
      for(let i=0;i<12;i++){
        const a=i*TAU/12; c.beginPath(); c.moveTo(Math.cos(a)*radius*.88, Math.sin(a)*radius*.88);
        c.lineTo(Math.cos(a)*radius*.94,Math.sin(a)*radius*.94);c.stroke();
      }
    }
    c.translate(0, World.CASTLE.half * World.T);
    const w=World.T*1.5;
    for(const side of [-1,1]){
      const x=side*(w+6); c.fillStyle='#364d54'; c.fillRect(x-6,-22,12,40);
      c.fillStyle='#d2b280'; c.fillRect(x-7,-24,14,6);
    }
    if(!World.gateOpen){
      c.fillStyle='#3f5559'; c.fillRect(-w,-18,w*2,9); c.fillRect(-w,3,w*2,7);
      for(let i=-3;i<=3;i++){ c.fillStyle='#b89968'; c.fillRect(i*w/3-2,-21,5,32); }
    }
    c.restore();
  }
  return { preload, drawScene, basin };
})();
