'use strict';

const Belfry = {
  revision: 3,
  scenes: {
    ch8: {end: 18, scenes: [
      {at:0, art:'empty', focus:[.52,.53], music:'belfry', speaker:'Рыжовая', text:'Криля, ты тоже слышала? Посмотри. Внутри только петля.'},
      {at:5.8, art:'answer', focus:[.50,.54], sfx:'toll', speaker:'Из воды, голосом Рыжовой', text:'Криля, мне руку прижало. Сунь ладонь под доски.'},
      {at:11.8, art:'sleeve', focus:[.47,.44], speaker:'Крилесса', text:'Я уже слышала её. Тогда она звала голосом мамы. Мама в тот день была дома.'}
    ]},
    end8: {end: 20, scenes: [
      {at:0, art:'handover', focus:[.50,.53], music:'belfry', speaker:'Звонарка', text:'Я звонила каждую весну. Ты хоть раз меня слышала?'},
      {at:6, art:'confession', focus:[.49,.43], speaker:'Крилесса', text:'Каждую. Мама спрашивала, что там звенит. Я говорила, лёд трескается.'},
      {at:13, art:'shore', focus:[.48,.49], text:'У берега Рыжовая спрашивает, как её звать. Девушка в воде впервые отвечает своим голосом. «Можно, я сама придумаю?»'}
    ]}
  },
  migrate(slot) {
    if (!slot || slot.layout === this.revision) return slot;
    const {kitchen, cp, df, defeated, ...rest} = slot;
    const flags = Array(6).fill(false);
    if (slot.layout !== 2) {
      const {cs, chests, shrines, ...carry} = rest;
      return {...carry, layout:this.revision, defeated:flags};
    }
    const old = defeated || df || [];
    flags[0] = !!old[0]; flags[1] = !!old[1];
    const moved = {...rest, layout:this.revision, defeated:flags};
    if (cp && (flags[0] || flags[1])) {
      const index = flags[0] && (!flags[1] || Math.abs(cp.x-World.tc(30)) <= Math.abs(cp.x-World.tc(91))) ? 0 : 1;
      const [x,y] = BELFRY_MAP.bosses[index];
      moved.cp = {x:World.tc(x),y:World.tc(y)};
    }
    return moved;
  }
};

const B8 = registerBiomes(
  {id:'dam', name:'Старая дамба', ground:['#627c62','#6f876b','#566f5c'], tree:'willow', treeP:.075,
    path:['#aa9776','#b4a281','#9a876e'], rock:['#5b7070','#738782','#496469'], deco:'flowers',
    mini:'#68866f', obst:[[ROCK,1]], music:'belfry', spawns:[['slime',3],['crab',1],['bat',2]]},
  {id:'sluice', name:'Медные шлюзы', ground:['#667879','#758581','#5a6b70'], tree:'burnt', treeP:.045,
    path:['#ac987d','#baa889','#9b8976'], rock:['#536467','#6c7e78','#455763'], deco:'boards',
    mini:'#768780', obst:[[ROCK,1]], music:'belfry', spawns:[['crab',2],['eel',2],['bat',1.5]]},
  {id:'bellcourt', name:'Чаша колокола', ground:['#566675','#607381','#4b5c68'], tree:'willow', treeP:.035,
    path:['#a49885','#b6ab90','#968d80'], rock:['#536472','#728581','#445563'], deco:'drops',
    mini:'#647b83', obst:[[ROCK,1]], music:'belfry', spawns:[['wisp',2],['crab',2],['bat',1]]},
  {id:'saltarchive', name:'Соляные отмели', ground:['#96a58b','#a1ab92','#849781'], tree:'willow',treeP:.04,
    path:['#c4b696','#cbbfa3','#b7a88b'],rock:['#718080','#90978b','#5b6e72'],deco:'drops',
    mini:'#a7ac89',obst:[[ROCK,1]],music:'belfry',spawns:[['crab',3],['wisp',2],['eel',1]]},
  {id:'spillway', name:'Водосброс', ground:['#7b775e','#838064','#696f59'],tree:'burnt',treeP:.05,
    path:['#b3986f','#bfa57b','#a58b68'],rock:['#6b6861','#898779','#525d5d'],deco:'boards',
    mini:'#968356',obst:[[ROCK,1]],music:'belfry',spawns:[['bat',2],['crab',2],['slime',1]]},
  {id:'fogquay',name:'Туманные причалы',ground:['#647e78','#748a83','#5c7677'],tree:'willow',treeP:.085,
    path:['#a49b83','#b5ac91','#938e7c'],rock:['#536f72','#78928c','#49636b'],deco:'flowers',
    mini:'#73978f',obst:[[ROCK,1]],music:'belfry',spawns:[['wisp',3],['bat',2],['eel',1]]}
);

const BELFRY_MAP = {
  name:'Берега Третьего звона', size:[252,184], start:[122,157],
  castle:[133,85,12,'south',B8+2], cage:[133,82],
  bosses:[[67,131],[181,135],[43,76],[107,36],[200,68],[133,85]],
  seeds:[[B8,122,157],[B8,96,112],[B8+1,67,131],[B8,181,135],[B8+3,43,76],[B8+3,68,51],
    [B8+4,107,36],[B8+4,151,38],[B8+5,200,68],[B8+5,196,105],[B8+2,133,85]],
  radius:8.5,
  paths:[
    [[122,157],[103,154],[85,144],[67,131],[52,120],[42,103],[43,76],[46,59],[61,49],[77,54],[91,45],[107,36]],
    [[107,36],[123,27],[139,30],[152,42],[166,44],[182,37],[196,45],[206,57],[200,68],[213,85],[211,101],[199,118],[181,135]],
    [[181,135],[170,148],[155,147],[138,158],[122,157]],
    [[55,115],[69,111],[77,103],[91,103],[105,103],[118,113],[128,108],[133,100]],
    [[122,157],[128,143],[117,131],[118,113]],
    [[128,108],[143,116],[155,108],[161,103],[169,103],[181,103],[199,118]],
    [[43,76],[57,73],[69,81],[82,78],[85,64],[77,54]],
    [[152,42],[154,58],[166,71],[181,75],[200,68]],
    [[67,131],[74,143],[71,154],[56,157]], [[181,135],[194,145],[209,140]]
  ],
  pockets:[[122,155,20,12],[67,131,19,15],[181,135,20,14],[43,76,16,20],[107,36,23,15],
    [200,68,19,18],[118,113,15,12],[67,52,15,12],[160,47,15,11],[55,157,11,7],[210,140,10,8]],
  spans:[[91,103,0],[169,103,1]],
  labels:[['Старая дамба',122,165],['Паромная слобода',63,141],['Тростниковый затон',178,146],['Соляные отмели',47,88],
    ['Водосброс',107,46],['Туманные причалы',200,79],['Чаша колокола',133,79]],
  marks:[['moorings',113,153],['capstan',69,129],['reedNest',180,133],['moorings',179,130],['compassStone',44,70],['sluiceWheel',104,32],
    ['lights',195,64],['lights',205,87],['compassStone',56,155],['span',91,103],['span',169,103],['moorings',130,104]]
};

const bellBoss = {belfry:true, music:'sluices', openingAttack:true};
Object.assign(BOSSES, {
  chainWarden: {...bellBoss, name:'Цепной паромщик',sub:'Паромная слобода',r:36,ttk:59,hit:.121,touch:.149,spd:107,move:'chase',col:'#dba965',rewardIndex:0,
    lines:{intro:'Двое на берегу. А кто тогда в лодке?',stages:['','Якорь заел. Отойди от цепи.','Держись за сваи!'],death:'Я опущу мост. Идите вдоль каната.'},
    stages:[{name:'Швартов',attacks:[['chainSweep'],['stomp',{r:110}]]},
      {at:.68,name:'Срыв якоря',spd:1.15,attacks:[['tidalRun',{fx:'sluiceChain',passes:1}],['chainSweep']]},
      {at:.32,name:'Свободная цепь',spd:1.26,attacks:[['tideSpokes',{fx:'sluiceChain',arms:4,rounds:2}],['tidalRun',{fx:'sluiceChain',passes:2}],['chainSweep']]}]},
  sluiceHeron: {...bellBoss,name:'Цапля шлюзов',sub:'Тростниковый затон',r:35,ttk:60,hit:.118,touch:.145,spd:120,move:'hover',fly:true,col:'#9ae1d8',rewardIndex:1,
    lines:{intro:'Тише. У меня под крылом птенец.',stages:['','Я тебя и под водой вижу.','К гнезду не подходи.'],death:'Слышишь? Пискнул. Живой.'},
    stages:[{name:'Мелководье',attacks:[['heronWake'],['leap',{r:75}]]},
      {at:.68,name:'Пикирование',spd:1.12,attacks:[['tidalRun',{fx:'heronWake',leap:true}],['heronWake']]},
      {at:.32,name:'Обратный взмах',spd:1.23,attacks:[['tidalRun',{fx:'heronWake',leap:true,passes:2}],['heronWake'],['ring',{n:12,waves:2,col:'#a5e3de'}]]}]},
  siltCartographer: {...bellBoss,name:'Картограф отмели',sub:'Соляные отмели',r:40,ttk:62,hit:.118,touch:.15,spd:91,move:'hover',col:'#e0b871',rewardIndex:3,
    lines:{intro:'Я нанёс на карту каждый дом. Покажи, где она жила.',stages:['','Вот ваша пристань. А вот ступени под ней.','Я всё ждал, что кто-нибудь за ней придёт.'],death:'У меня остался её ключ. Возьми.'},
    stages:[{name:'Роза ветров',attacks:[['tideSpokes',{fx:'saltInk',arms:4}],['stomp',{r:105}]]},
      {at:.68,name:'Соляные острова',spd:1.12,attacks:[['shoals'],['tideSpokes',{fx:'saltInk',arms:5}]]},
      {at:.32,name:'Сбитый компас',spd:1.22,attacks:[['tideSpokes',{fx:'saltInk',arms:5,rounds:2}],['shoals',{rounds:3}]]}]},
  spillHound: {...bellBoss,name:'Гончая водосброса',sub:'Верхний водосброс',r:34,ttk:61,hit:.122,touch:.154,spd:153,move:'chase',col:'#e99a65',rewardIndex:4,
    lines:{intro:null,stages:[],death:null},
    stages:[{name:'След',attacks:[['tidalRun',{fx:'rustRun'}],['leap',{r:75}]]},
      {at:.68,name:'Двойной гон',spd:1.14,attacks:[['tidalRun',{fx:'rustRun',passes:2}],['stomp',{r:115}]]},
      {at:.32,name:'Через поток',spd:1.27,attacks:[['tidalRun',{fx:'rustRun',passes:3,leap:true}],['leap',{r:95}]]}]},
  mistKeeper: {...bellBoss,name:'Фонарщица тумана',sub:'Туманные причалы',r:37,ttk:66,hit:.121,touch:.15,spd:100,move:'hover',col:'#a6eac9',rewardIndex:5,
    lines:{intro:'Я оставляла ей свет. Каждую ночь.',stages:['','В тот раз из воды вышла только одна.','Скажи ей сама, Криля. Она ждала тебя.'],death:'Возьми мой фонарь. Внизу ступенька сломана.'},
    stages:[{name:'Створные огни',attacks:[['lanternWeave'],['aimed',{n:3,col:'#b5efd2'}]]},
      {at:.68,name:'Поворот линзы',spd:1.12,attacks:[['lanternWeave',{rounds:2}],['shoals',{rounds:1}]]},
      {at:.32,name:'Перекрёстный свет',spd:1.22,attacks:[['lanternWeave',{rounds:3}],['tideSpokes',{fx:'wickLight',arms:4,rounds:2}]]}]},
  hollowBell: {...bellBoss,name:'Безликая звонарка',sub:'На дне чаши',r:43,ttk:76,hit:.125,touch:.155,spd:112,move:'hover',col:'#e6c584',music:'thirdBell',rewardIndex:2,
    lines:{intro:'Ты всё ещё держишь её за руку, Криля?',stages:['','Я звала, пока у меня был свой голос.','Посмотри на меня. Хоть теперь.','Скажи ей, кого ты оставила в воде.'],death:'Посиди со мной, пока светает.'},
    stages:[{name:'Первый звон',attacks:[['thirdToll'],['shotgun',{n:5}]]},
      {at:.76,name:'Отзвук',spd:1.10,attacks:[['heronWake'],['thirdToll']]},
      {at:.50,name:'Разбитая бронза',spd:1.2,attacks:[['tideSpokes',{fx:'bellEcho',arms:5,rounds:2}],['thirdToll']]},
      {at:.24,name:'Свой голос',spd:1.29,attacks:[['thirdToll',{repeat:true}],['lanternWeave',{rounds:2}],['tidalRun',{fx:'bellEcho',leap:true}]]}]}
});

const bellTile = ([x,y]) => ({x,y});
CHAPTERS[8] = {
  id:8,title:'Глава 8',name:'Третий звон',seed:8800088,MW:BELFRY_MAP.size[0],MH:BELFRY_MAP.size[1],blobs:0,
  start:bellTile(BELFRY_MAP.start),castle:{...bellTile(BELFRY_MAP.castle),half:12,gate:'south',biome:B8+2},cage:bellTile(BELFRY_MAP.cage),
  biomeSeeds:BELFRY_MAP.seeds,bosses:['chainWarden','sluiceHeron','siltCartographer','spillHound','mistKeeper','hollowBell'],
  bossTiles:BELFRY_MAP.bosses.map(bellTile),bossLevels:[8,10,13,16,19,24],
  zoneLevel:{[B8]:3,[B8+1]:6,[B8+2]:18,[B8+3]:9,[B8+4]:12,[B8+5]:15},chests:36,chestDist:[3,16],shrines:9,
  spawnEvery:.50,capBase:15,elite:.065,diff:{hp:1.55,dmg:1.34},hero:'ryzhovaya',startLevel:1,noCage:true,music:'belfry',
  gateSay:'Вода сошла. В чаше видны ступени.',gateBanner:'Спуск к Звонарке',deadText:'Рыжовая приходит в себя у воды.'
};
ARENA_STYLE[8]={name:'Дно водохранилища',floor:['#44575d','#4a6264'],crack:'#a29a7d',ember:'#d6bf85',wall:'#283b46',tint:'125,173,175'};
CHEST_THEME[8]={body:'#675549',lid:'#a38b64',dark:'#344346'};
