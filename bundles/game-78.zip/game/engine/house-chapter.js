'use strict';

const HouseChapter = (() => {
  // ------------------------------------------------------------------
  //  Главы Тессы: жизни, прыжок, лежанки, улики, жители, полки, коробки
  // ------------------------------------------------------------------
  function loseLife() {
    P.lives--; P.hp = Math.round(P.maxHp * 0.35); P.inv = 2.2;
    for (const bl of G.ebullets) if ((bl.x - P.x) ** 2 + (bl.y - P.y) ** 2 < 200 * 200) bl.life = 0;
    Effects.burst(P.x, P.y, 30, '#bfeaff', 220); Effects.shockRing(P.x, P.y, '#bfeaff', 180);
    if (P.up.c4life) G.novas.push({ x: P.x, y: P.y, r: 10, max: 320, hit: new Set(), k: 2.5 * P.up.c4life, life: true });
    Screens.showBanner(`🐾 Осталось жизней: ${P.lives}`, P.lives <= 2 ? 'Найди лежанку – там можно вздремнуть' : 'Кошки так просто не сдаются');
    Sound.sfx.meow(); G.shake = 10;
    if (G.st) G.st.livesLost = (G.st.livesLost || 0) + 1;
  }
  function pounceHit() {
    const R = 80;
    for (const e of G.enemies) {
      if (e.dead || e.spawnT > 0) continue;
      const d = Math.hypot(e.x - P.x, e.y - P.y) || 1;
      if (d < R + e.r) { Enemies.damageEnemy(e, Actors.rollHit(P.dmg * 1.8), (e.x - P.x) / d * 260, (e.y - P.y) / d * 260, false); e.slowT = Math.max(e.slowT || 0, 1); }
    }
    const b = G.activeBoss;
    if (b && b.state === 'fight' && Math.hypot(b.x - P.x, b.y - P.y) < R + b.r) Bosses.damageBoss(b, Actors.rollHit(P.dmg * 1.8));
    G.rings.push({ x: P.x, y: P.y, r: 8, max: R, col: '#ffd0f0', t: 0 }); Effects.burst(P.x, P.y, 12, '#fff0f8', 160); G.shake = Math.max(G.shake, 4);
  }
  function napOn(bd) {
    bd.nap = 0; bd.cd = 75;
    P.hp = P.maxHp; if (P.lives) P.lives = Math.min(HEROES[P.hero].lives || 9, P.lives + 1); P.napT = 60;
    G.cp = { x: bd.x, y: bd.y + 30 };
    Screens.showBanner('💤 Тесса вздремнула', 'Здоровье полное, +1 жизнь, +20% урона на минуту');
    Sound.sfx.nap(); Effects.burst(bd.x, bd.y, 20, '#ffe0a0', 120);
    Saves.saveGame();
  }
  function updateHouse(dt) {
    if (G.invertT > 0) G.invertT -= dt;
    if (G.staticT > 0) G.staticT -= dt;
    if (G.clueMsgT > 0) G.clueMsgT -= dt;
    if (G.revealT > 0) G.revealT -= dt;
    for (const bd of World.beds) {
      if (bd.cd > 0) { bd.cd -= dt; continue; }
      const near = Math.hypot(P.x - bd.x, P.y - bd.y) < 34 && !G.activeBoss && !G.activeShrine;
      if (near && !P.moving) { bd.nap += dt; if (bd.nap >= 1.4) napOn(bd); } else bd.nap = 0;
    }
    for (const l of World.lamps) {
      if (Math.abs(l.x - P.x) > 700 || Math.abs(l.y - P.y) > 700) continue;
      for (const e of G.enemies) if (!e.dead && (e.x - l.x) ** 2 + (e.y - l.y) ** 2 < 150 * 150) e.lit = 0.2;
    }
    if (World.CFG.dark) {
      G.flickT -= dt; if (G.flickT < -G.flickGap) { G.flickT = 0.6; G.flickGap = rnd(6, 14); if (Math.random() < 0.4) Sound.sfx.staticNoise(); }
      G.eyesT -= dt;
      if (!G.eyes && G.eyesT <= 0 && !G.activeBoss) {
        G.eyesT = rnd(14, 24); const a = rnd(0, TAU), r = rnd(280, 380);
        G.eyes = { x: P.x + Math.cos(a) * r, y: P.y + Math.sin(a) * r, t: 0, dur: 2.8 }; Sound.sfx.whisper();
      }
      if (G.eyes) { G.eyes.t += dt; if (Math.hypot(G.eyes.x - P.x, G.eyes.y - P.y) < 160) G.eyes.dur = Math.min(G.eyes.dur, G.eyes.t + 0.2); if (G.eyes.t > G.eyes.dur) G.eyes = null; }
      G.glitchT -= dt; if (G.glitchT <= 0) { G.glitchT = rnd(25, 45); G.glitchFx = 0.35; Sound.sfx.staticNoise(); }
      if (G.glitchFx > 0) G.glitchFx -= dt;
    }
    for (const q of World.clues) {
      if (NET.client) break; // улики считает хозяйка – у гостьи они придут в снимке
      if (q.found || !Multiplayer.netNear(q.x, q.y, 30)) continue;
      q.found = true; G.clues5[q.i] = (G.clues5[q.i] || 0) + 1;
      const [ic, txt] = CLUES5[q.i][q.k];
      Sound.sfx.clue(); Effects.burst(q.x, q.y, 16, '#ffd25a', 140); Effects.floatText(q.x, q.y - 24, `${ic} улика ${G.clues5[q.i]}/3`, '#ffd25a', true);
      Screens.say(`${ic} ${txt}`, 4.2); if (NET.host) NetT.send(-1, { t: 'say', text: `${ic} ${txt}`, d: 4.2 });
      if (G.st) G.st.clues = (G.st.clues || 0) + 1;
      if (G.clues5[q.i] >= 3) { const nm = BOSSES[World.CFG.bosses[q.i]].name; setTimeout(() => { if (Session.state === 'play') Screens.showBanner('🔎 Подозреваемый найден!', nm + ' ждёт допроса'); }, 1200); }
      Saves.saveGame();
    }
    let nearN = null;
    if (!NET.client) for (const n of World.npcs) if (Math.hypot(n.x - P.x, n.y - P.y) < 56) nearN = n; // с жителями говорит хозяйка
    G.nearNpc = nearN;
    for (const it of World.qitems) {
      if (NET.client) break;
      if (!it.active || it.taken || Math.hypot(it.x - P.x, it.y - P.y) > 30) continue;
      it.taken = true; const def = NPCS5[it.ni];
      Sound.sfx.chest(); Effects.burst(it.x, it.y, 16, '#ffd25a', 140);
      Screens.showBanner(`${def.item.ic} Нашла: ${def.item.name}!`, `Отнеси – ${def.name} ждёт`);
      Saves.saveGame();
    }
    if (G.jump) {
      const J = G.jump; J.t += dt; const k = Math.min(1, J.t / J.dur);
      P.x = lerp(J.sx, J.tx, k); P.y = lerp(J.sy, J.ty, k); P.z = Math.sin(k * Math.PI) * 70; P.inv = Math.max(P.inv, 0.15);
      if (k >= 1) { G.jump = null; P.z = 0; Effects.burst(P.x, P.y, 12, '#c8945a', 120); Terrain.revealFog(P.x, P.y, 12); }
    } else {
      for (const s of World.shelves) {
        if (s.cd > 0) s.cd -= dt;
        const inside = Math.hypot(s.x - P.x, s.y - P.y) < 22;
        if (inside && !s.inside && s.cd <= 0 && !G.activeBoss) {
          const o = World.shelves[s.to]; s.cd = o.cd = 1.5; o.inside = true;
          G.jump = { sx: P.x, sy: P.y, tx: o.x, ty: o.y, t: 0, dur: 0.8 };
          Sound.sfx.pounce(); Effects.floatText(P.x, P.y - 30, 'прыг!', '#ffd25a');
          if (G.st) G.st.jumps = (G.st.jumps || 0) + 1;
        }
        s.inside = inside;
      }
    }
    if (World.boxes.length) {
      const bx = !G.activeBoss && !G.activeShrine && !P.moving && World.boxes.find(o => Math.hypot(o.x - P.x, o.y - P.y) < 20);
      G.hideT = bx ? (G.hideT || 0) + dt : 0;
      const was = G.hidden; G.hidden = G.hideT > 0.25 ? bx : null;
      if (G.hidden && !was) { Effects.floatText(P.x, P.y - 30, 'спряталась 📦', '#ffd25a'); Sound.sfx.click(); }
      if (G.hidden) P.hp = Math.min(P.maxHp, P.hp + P.maxHp * 0.03 * dt);
    }
    if (G.pet) {
      const A = G.pet;
      A.x = lerp(A.x, P.x - 26 * P.face, Math.min(1, dt * 5)); A.y = lerp(A.y, P.y - 20, Math.min(1, dt * 5)); A.fireT -= dt;
      if (A.fireT <= 0) {
        const tg = G.hidden ? null : Hero.nearestTarget(280);
        if (tg) { A.fireT = 0.7; const a = Math.atan2(tg.y - (tg.z || 0) - A.y, tg.x - A.x); G.feathers.push({ x: A.x, y: A.y, vx: Math.cos(a) * 420, vy: Math.sin(a) * 420, dmg: P.dmg * 0.45, pierce: 0, life: 0.9, hit: [], kind: 'pixel', ally: true }); }
        else A.fireT = 0.25;
      }
    }
    if (G.boardPending && Session.state === 'play' && !Screens.Dialog.talking && !G.activeBoss && !NET.client) { G.boardPending = false; openBoard(); }
  }
  // объекты дома на земле
  function drawHouseGround(c, vis) {
    for (const s of World.shelves) if (vis(s.x, s.y, 40)) {
      c.fillStyle = 'rgba(0,0,0,0.25)'; c.beginPath(); c.ellipse(s.x, s.y + 14, 22, 5, 0, 0, TAU); c.fill();
      c.fillStyle = '#6a4024'; c.fillRect(s.x - 16, s.y + 4, 4, 10); c.fillRect(s.x + 12, s.y + 4, 4, 10);
      c.fillStyle = '#9a6a40'; c.strokeStyle = '#5a3a20'; c.lineWidth = 2; roundRect(c, s.x - 20, s.y - 6, 40, 12, 3); c.fill(); c.stroke();
      if (s.cd <= 0) { c.font = '14px Krilessa Icons, sans-serif'; c.textAlign = 'center'; c.globalAlpha = 0.6 + Math.sin(G.time * 5) * 0.3; c.fillText('🐾', s.x, s.y - 12); c.globalAlpha = 1; }
    }
    for (const bd of World.beds) if (vis(bd.x, bd.y, 40)) {
      c.fillStyle = 'rgba(0,0,0,0.3)'; c.beginPath(); c.ellipse(bd.x, bd.y + 10, 26, 8, 0, 0, TAU); c.fill();
      c.fillStyle = bd.cd > 0 ? '#7a6a7a' : '#c86a8a'; c.beginPath(); c.ellipse(bd.x, bd.y + 2, 26, 14, 0, 0, TAU); c.fill();
      c.fillStyle = bd.cd > 0 ? '#b0a0b0' : '#ffd0e0'; c.beginPath(); c.ellipse(bd.x, bd.y, 19, 9, 0, 0, TAU); c.fill();
      c.fillStyle = 'rgba(255,255,255,0.4)'; c.beginPath(); c.ellipse(bd.x - 6, bd.y - 3, 7, 3, -0.3, 0, TAU); c.fill();
      if (bd.nap > 0) { c.strokeStyle = '#ffe080'; c.lineWidth = 3; c.beginPath(); c.arc(bd.x, bd.y - 26, 10, -Math.PI / 2, -Math.PI / 2 + TAU * bd.nap / 1.4); c.stroke(); }
      if (bd.cd <= 0) { c.font = 'bold 10px Krilessa Icons, sans-serif'; c.textAlign = 'center'; c.fillStyle = '#ffe0f0'; c.fillText(bd.nap > 0 ? '💤' : 'ЛЕЖАНКА', bd.x, bd.y - 20); }
    }
    for (const l of World.lamps) if (vis(l.x, l.y, 40)) {
      c.fillStyle = '#5a4a3a'; c.fillRect(l.x - 7, l.y + 4, 14, 4); c.fillRect(l.x - 1.5, l.y - 12, 3, 16);
      c.fillStyle = '#ffd890'; c.beginPath(); c.moveTo(l.x - 10, l.y - 10); c.lineTo(l.x + 10, l.y - 10); c.lineTo(l.x + 6, l.y - 22); c.lineTo(l.x - 6, l.y - 22); c.closePath(); c.fill();
    }
    for (const q of World.clues) if (!q.found && vis(q.x, q.y, 30)) {
      const bob = Math.sin(G.time * 3 + q.k) * 3;
      c.fillStyle = `rgba(255,220,90,${0.25 + Math.sin(G.time * 4 + q.k) * 0.15})`; c.beginPath(); c.arc(q.x, q.y, 16, 0, TAU); c.fill();
      const spr = emojiSprite(CLUES5[q.i][q.k][0], 18); c.drawImage(spr, q.x - spr.width / 4, q.y - 10 + bob - spr.height / 4, spr.width / 2, spr.height / 2);
      c.fillStyle = '#ffd25a'; star(c, q.x + 10, q.y - 16 + bob, 3, G.time, 4); c.fill();
    }
    for (const it of World.qitems) if (it.active && !it.taken && vis(it.x, it.y, 30)) {
      const def = NPCS5[it.ni], spr = emojiSprite(def.item.ic, 20), bob = Math.sin(G.time * 3) * 3;
      c.fillStyle = 'rgba(255,255,255,0.3)'; c.beginPath(); c.arc(it.x, it.y, 14, 0, TAU); c.fill();
      c.drawImage(spr, it.x - spr.width / 4, it.y - 8 + bob - spr.height / 4, spr.width / 2, spr.height / 2);
    }
    for (const n of World.npcs) if (vis(n.x, n.y, 40)) {
      shadow(c, n.x, n.y + 10, 12, 4);
      const spr = emojiSprite(n.def.ic, 26), hop = Math.abs(Math.sin(G.time * 2 + n.ni)) * 3;
      c.drawImage(spr, n.x - spr.width / 4, n.y - 8 - hop - spr.height / 4, spr.width / 2, spr.height / 2);
      c.font = 'bold 10px Krilessa Icons, sans-serif'; c.textAlign = 'center'; c.fillStyle = '#000'; c.fillText(n.def.name, n.x + 1, n.y - 29); c.fillStyle = '#ffffff'; c.fillText(n.def.name, n.x, n.y - 30);
      const it = World.qitems[n.ni], mark = n.state === 'done' ? '' : it.taken ? '🎁' : n.state === 'new' ? '💬' : '';
      if (mark) { c.font = '14px Krilessa Icons, sans-serif'; c.fillText(mark, n.x + 16, n.y - 22 - Math.abs(Math.sin(G.time * 3)) * 3); }
    }
    for (const bx of World.boxes) if (vis(bx.x, bx.y, 40) && bx !== G.hidden) drawBox(c, bx, false);
  }
  function drawBox(c, bx, peek) {
    c.fillStyle = 'rgba(0,0,0,0.25)'; c.beginPath(); c.ellipse(bx.x, bx.y + 10, 20, 6, 0, 0, TAU); c.fill();
    if (peek) {
      c.fillStyle = '#5a4034';
      c.beginPath(); c.moveTo(bx.x - 9, bx.y - 11); c.lineTo(bx.x - 6, bx.y - 22); c.lineTo(bx.x - 2, bx.y - 11); c.fill();
      c.beginPath(); c.moveTo(bx.x + 2, bx.y - 11); c.lineTo(bx.x + 6, bx.y - 22); c.lineTo(bx.x + 9, bx.y - 11); c.fill();
    }
    c.fillStyle = '#c8945a'; c.strokeStyle = '#8a6036'; c.lineWidth = 2;
    c.fillRect(bx.x - 16, bx.y - 12, 32, 22); c.strokeRect(bx.x - 16, bx.y - 12, 32, 22);
    c.fillStyle = 'rgba(255,255,255,0.35)'; c.fillRect(bx.x - 3, bx.y - 12, 6, 22);
    if (peek) { c.fillStyle = '#5ab8ff'; c.fillRect(bx.x - 7, bx.y - 9, 3, 2); c.fillRect(bx.x + 4, bx.y - 9, 3, 2); }
    c.fillStyle = '#d8a46a';
    c.beginPath(); c.moveTo(bx.x - 16, bx.y - 12); c.lineTo(bx.x - 24, bx.y - 18); c.lineTo(bx.x - 8, bx.y - 18); c.lineTo(bx.x, bx.y - 12); c.fill();
    c.beginPath(); c.moveTo(bx.x + 16, bx.y - 12); c.lineTo(bx.x + 24, bx.y - 18); c.lineTo(bx.x + 8, bx.y - 18); c.lineTo(bx.x, bx.y - 12); c.fill();
  }
  function drawPet(c) {
    const A = G.pet, y0 = A.y + Math.sin(G.time * 4) * 2;
    c.fillStyle = 'rgba(63,240,160,0.25)'; c.beginPath(); c.arc(A.x, y0, 12, 0, TAU); c.fill();
    const px = (x, y, col) => { c.fillStyle = col; c.fillRect(A.x + x * 2.4, y0 + y * 2.4, 2.4, 2.4); };
    for (const [x, y] of [[-3, -4], [3, -4], [-3, -3], [-2, -3], [-1, -3], [0, -3], [1, -3], [2, -3], [3, -3], [-3, -2], [-2, -2], [0, -2], [2, -2], [3, -2],
      [-3, -1], [-2, -1], [-1, -1], [0, -1], [1, -1], [2, -1], [3, -1], [-2, 0], [-1, 0], [0, 0], [1, 0], [2, 0], [-2, 1], [2, 1]]) px(x, y, '#3ff0a0');
    px(-1, -2, '#0a2a1a'); px(1, -2, '#0a2a1a');
  }
  // темнота главы 4: свет только вокруг Тессы, ламп и лежанок
  let darkCv = null;
  function drawDarkness(c) {
    if (!darkCv) darkCv = makeCanvas(1, 1);
    const w = Math.ceil(Viewport.VW / 2), h = Math.ceil(Viewport.VH / 2);
    if (darkCv.width !== w || darkCv.height !== h) { darkCv.width = w; darkCv.height = h; }
    const d = darkCv.getContext('2d');
    d.globalCompositeOperation = 'source-over'; d.clearRect(0, 0, w, h);
    const fl = G.flickT > 0 && Math.random() < 0.5 ? 0.08 : 0;
    d.fillStyle = Terrain.paperOn ? `rgba(30,32,78,${0.68 + fl})` : `rgba(4,3,14,${0.88 + fl})`; d.fillRect(0, 0, w, h); // 1.0: ночная сказка – синие чернила вместо черноты
    d.globalCompositeOperation = 'destination-out';
    const toS = (x, y) => [((x - G.cam.x) * Viewport.ZOOM + Viewport.VW / 2) / 2, ((y - G.cam.y) * Viewport.ZOOM + Viewport.VH / 2) / 2];
    const hole = (x, y, r, k = 1) => {
      const [sx, sy] = toS(x, y), rr = r * Viewport.ZOOM / 2;
      if (sx < -rr || sy < -rr || sx > w + rr || sy > h + rr) return;
      const g = d.createRadialGradient(sx, sy, rr * 0.35, sx, sy, rr);
      g.addColorStop(0, `rgba(0,0,0,${k})`); g.addColorStop(1, 'rgba(0,0,0,0)');
      d.fillStyle = g; d.beginPath(); d.arc(sx, sy, rr, 0, TAU); d.fill();
    };
    hole(P.x, P.y, (G.activeBoss ? 340 : 245) * Math.pow(1 + 0.2, Actors.lv('c4lamp')));
    for (const l of World.lamps) hole(l.x, l.y, 165, 0.85 + Math.sin(G.time * 7 + l.ph) * 0.05);
    for (const b of World.beds) hole(b.x, b.y, 150, 0.8);
    const ab = G.activeBoss; if (ab) hole(ab.x, ab.y, 130, 0.65);
    d.globalCompositeOperation = 'source-over';
    c.save(); c.setTransform(Viewport.DPR, 0, 0, Viewport.DPR, 0, 0); c.imageSmoothingEnabled = true;
    c.drawImage(darkCv, 0, 0, Viewport.VW, Viewport.VH);
    c.globalCompositeOperation = 'lighter';
    if (Terrain.paperOn) { // фонарик героини: тёплый круг света, как от свечи в книжке, и пылинки в нём
      const [sx, sy] = toS(P.x, P.y - 10), X = sx * 2, Y = sy * 2, R = (G.activeBoss ? 300 : 220) * Math.pow(1 + 0.2, Actors.lv('c4lamp')) * Viewport.ZOOM, fk = 1 + Math.sin(G.time * 9) * 0.03;
      const g = c.createRadialGradient(X, Y, 6, X, Y, R * fk); g.addColorStop(0, 'rgba(255,214,140,0.30)'); g.addColorStop(0.55, 'rgba(255,180,100,0.12)'); g.addColorStop(1, 'rgba(255,170,90,0)');
      c.fillStyle = g; c.fillRect(X - R, Y - R, R * 2, R * 2);
      for (let i = 0; i < 14; i++) { const a = hash2(i, 31) * TAU + G.time * (0.15 + hash2(31, i) * 0.2), rr = R * (0.15 + hash2(i, 32) * 0.55); c.fillStyle = `rgba(255,236,190,${0.25 + 0.35 * Math.abs(Math.sin(G.time * 1.7 + i))})`; c.fillRect(X + Math.cos(a) * rr, Y + Math.sin(a) * rr * 0.8, 1.6, 1.6); }
    }
    for (const l of World.lamps) {
      const [sx, sy] = toS(l.x, l.y), X = sx * 2, Y = sy * 2, R = 150 * Viewport.ZOOM;
      if (X < -R || Y < -R || X > Viewport.VW + R || Y > Viewport.VH + R) continue;
      const g = c.createRadialGradient(X, Y, 4, X, Y, R); g.addColorStop(0, 'rgba(255,170,80,0.22)'); g.addColorStop(1, 'rgba(255,170,80,0)');
      c.fillStyle = g; c.fillRect(X - R, Y - R, R * 2, R * 2);
    }
    c.globalCompositeOperation = 'source-over';
    for (const e of G.enemies) {
      if (e.dead || e.spawnT > 0) continue;
      const [sx, sy] = toS(e.x, e.y), X = sx * 2, Y = sy * 2;
      if (X < 0 || Y < 0 || X > Viewport.VW || Y > Viewport.VH || Math.sin(e.t * 2 + e.seed * 7) > 0.96) continue;
      c.fillStyle = e.type === 'shadowcat' ? '#ffffff' : '#ff3b3b'; c.fillRect(X - 4, Y - 7, 2.5, 2.5); c.fillRect(X + 2, Y - 7, 2.5, 2.5);
    }
    if (G.eyes) {
      const [sx, sy] = toS(G.eyes.x, G.eyes.y), X = sx * 2, Y = sy * 2;
      const a = clamp(G.eyes.t / 0.5, 0, 1) * clamp((G.eyes.dur - G.eyes.t) / 0.4, 0, 1), blinkE = Math.sin(G.eyes.t * 5) > 0.93 ? 0.15 : 1;
      c.globalAlpha = a; c.shadowColor = '#3ff0a0'; c.shadowBlur = 14; c.fillStyle = '#3ff0a0';
      c.beginPath(); c.ellipse(X - 12, Y, 6, 3.5 * blinkE, 0, 0, TAU); c.ellipse(X + 12, Y, 6, 3.5 * blinkE, 0, 0, TAU); c.fill();
      c.shadowBlur = 0; c.fillStyle = '#000'; c.fillRect(X - 13, Y - 3 * blinkE, 2, 6 * blinkE); c.fillRect(X + 11, Y - 3 * blinkE, 2, 6 * blinkE);
      c.globalAlpha = 1;
    }
    c.restore();
  }
  // экранные эффекты: помехи, перевёрнутое управление, глитч
  function drawHouseFx(c) {
    if (G.wxId === 'frost' && G.chill > 0.2) {
      const a = clamp(G.chill / 2.5, 0, 1) * 0.55;
      const g = c.createRadialGradient(Viewport.VW / 2, Viewport.VH / 2, Math.min(Viewport.VW, Viewport.VH) * 0.28, Viewport.VW / 2, Viewport.VH / 2, Math.max(Viewport.VW, Viewport.VH) * 0.7);
      g.addColorStop(0, 'rgba(150,210,255,0)'); g.addColorStop(1, `rgba(190,230,255,${a})`); c.fillStyle = g; c.fillRect(0, 0, Viewport.VW, Viewport.VH);
      if (G.chill > 0.8) { c.font = '900 15px Krilessa Icons, sans-serif'; c.textAlign = 'center'; c.fillStyle = '#000'; c.fillText('🥶 Замерзаешь! Двигайся', Viewport.VW / 2 + 1, Viewport.VH * 0.7 + 1); c.fillStyle = '#d8f2ff'; c.fillText('🥶 Замерзаешь! Двигайся', Viewport.VW / 2, Viewport.VH * 0.7); }
    }
    if (G.activeShrine && P.y > World.PLAY_H * World.T) {
      const st = ARENA_STYLE[World.CHN] || ARENA_STYLE[1], a = 0.32 + Math.sin(G.time * 3) * 0.06;
      const g = c.createRadialGradient(Viewport.VW / 2, Viewport.VH / 2, Math.min(Viewport.VW, Viewport.VH) * 0.3, Viewport.VW / 2, Viewport.VH / 2, Math.max(Viewport.VW, Viewport.VH) * 0.72);
      g.addColorStop(0, `rgba(${st.tint},0)`); g.addColorStop(1, `rgba(${st.tint},${a})`);
      c.fillStyle = g; c.fillRect(0, 0, Viewport.VW, Viewport.VH);
    }
    if (G.staticT > 0) {
      const a = Math.min(1, G.staticT) * 0.35;
      for (let i = 0; i < 160; i++) { const v = Math.random() * 255 | 0; c.fillStyle = `rgba(${v},${v},${v},${a})`; c.fillRect(Math.random() * Viewport.VW, Math.random() * Viewport.VH, rnd(6, 30), 2); }
    }
    if (G.invertT > 0) {
      c.fillStyle = `rgba(140,60,255,${0.12 + Math.sin(G.time * 10) * 0.05})`; c.fillRect(0, 0, Viewport.VW, Viewport.VH);
      c.font = '900 15px Krilessa Icons, sans-serif'; c.textAlign = 'center'; c.fillStyle = '#e0c8ff'; c.fillText('🔄 управление перевёрнуто', Viewport.VW / 2, Viewport.VH * 0.7);
    }
    if (G.glitchFx > 0) {
      c.save(); c.setTransform(1, 0, 0, 1, 0, 0);
      for (let i = 0; i < 6; i++) { const y = Math.random() * Viewport.canvas.height, hh = rnd(6, 30) * Viewport.DPR, dx = rnd(-30, 30) * Viewport.DPR; c.drawImage(Viewport.canvas, 0, y, Viewport.canvas.width, hh, dx, y, Viewport.canvas.width, hh); }
      c.restore();
      c.fillStyle = 'rgba(63,240,160,0.08)'; c.fillRect(0, 0, Viewport.VW, Viewport.VH);
    }
    if (G.hidden) { c.font = 'bold 13px Krilessa Icons, sans-serif'; c.textAlign = 'center'; c.fillStyle = '#000'; c.fillText('📦 Тессу не видно · она лечится', Viewport.VW / 2 + 1, Viewport.VH * 0.66 + 1); c.fillStyle = '#ffd25a'; c.fillText('📦 Тессу не видно · она лечится', Viewport.VW / 2, Viewport.VH * 0.66); }
  }

  // ------------------------------------------------------------------
  //  Финал главы 4: хорошая или добрая?
  // ------------------------------------------------------------------
  function openChoice(fromMenu) { G.choiceFromMenu = !!fromMenu; Screens.setState('choice'); Sound.music('night4'); }
  function finishCh4(ch) {
    if (NET.host && G.netRun) NetT.send(-1, { t: 'c4', ch });
    const prof = Saves.loadProfile(); prof.ch4Choice = ch; prof.ch4Seen = prof.ch4Seen || {}; prof.ch4Seen[ch] = 1; Saves.saveProfile(prof);
    unlockOutfit('bow');
    // игру закрыли на экране выбора – спрашиваем ещё раз из меню, без экрана победы
    if (G.choiceFromMenu) { G.choiceFromMenu = false; AdventureMenu.openMenu(); RunStats.toast(ch === 'kind' ? '💗 Добрая кошка. Мяу.exe приручён' : '🛡️ Хорошая кошка. Дом спасён'); return; }
    if (ch === 'kind') Sound.sfx.purr(); else Sound.sfx.win();
    Screens.showVictory(ch);
  }
  // ------------------------------------------------------------------
  //  Глава 5: доска подозреваемых
  // ------------------------------------------------------------------
  function openBoard() {
    Screens.setState('board'); G.accused = false;
    const list = $('boardClues'); list.innerHTML = '';
    for (const q of World.clues) if (q.found) { const [ic, txt] = CLUES5[q.i][q.k]; const el = document.createElement('div'); el.className = 'bclue'; el.textContent = `${ic} ${txt}`; list.appendChild(el); }
    const sus = $('boardSus'); sus.innerHTML = '';
    for (const s of SUSPECTS) {
      const el = document.createElement('button'); el.className = 'bsus'; el.innerHTML = `<span>${s.ic}</span>${s.name}`;
      el.addEventListener('click', () => { Sound.sfx.click(); accuse(s); }); sus.appendChild(el);
    }
    $('boardResult').innerHTML = ''; $('boardGo').classList.add('hidden');
    Sound.sfx.magic();
  }
  function accuse(s) {
    if (G.accused) return; G.accused = true;
    const ok = s.id === 'zyama', prof = Saves.loadProfile(); prof.ch5Accuse = s.id; Saves.saveProfile(prof);
    G.boardPending = false; Saves.saveGame();
    const wrong = { baron: 'Барон обиженно гавкнул.', cucumber: 'Огурец покраснел. Насколько огурцы умеют.', laserdot: 'Точка смущённо замигала.', pigeonboss: 'Голубь поправил шляпу: «Курлык, не мы».' };
    $('boardResult').innerHTML = ok ? '🎯 Точно! Блёстки, какао, ода и программка «Режиссёр – З.»… Это <b>Зямочкккк</b>!<br>Награда: улучшение, осколки и очки детектива 👓'
      : `🤔 ${s.name}? ${wrong[s.id] || ''}<br>Но все улики всё равно ведут в кладовую…`;
    for (const el of document.querySelectorAll('.bsus')) el.disabled = true;
    if (ok) { Sound.sfx.win(); for (let i = 0; i < 8; i++) Effects.dropShard(P.x + rnd(-40, 40), P.y + rnd(-40, 40)); G.pendingLv++; unlockOutfit('glasses'); } else Sound.sfx.hurt();
    $('boardGo').classList.remove('hidden');
  }
  // ------------------------------------------------------------------
  //  Глава 5: разговоры с жителями
  // ------------------------------------------------------------------
  function npcButtons(list) {
    const box = $('npcChoices'); box.innerHTML = '';
    for (const [label, fn] of list) { const el = document.createElement('button'); el.className = 'btn alt'; el.textContent = label; el.addEventListener('click', () => { Sound.sfx.click(); fn(); }); box.appendChild(el); }
  }
  function openNpc(n) {
    if (!n) return;
    G.talkN = n; Screens.setState('npc');
    $('npcIc').textContent = n.def.ic; $('npcName').textContent = n.def.name;
    npcPage(n.state === 'done' ? 'Спасибо ещё раз, Тесса! Заходи в гости. 💛' : n.def.greet);
  }
  function npcPage(text) {
    const n = G.talkN, it = World.qitems[n.ni], def = n.def;
    $('npcText').textContent = text;
    const opts = [];
    if (it.taken && n.state !== 'done') opts.push([`🎁 Вот: ${def.item.ic} ${def.item.name}!`, () => { n.state = 'done'; npcReward(n); npcPage(def.thanks); }]);
    opts.push(['🔎 Кто взял корм?', () => { G.revealT = 120; npcPage(def.hint + '\n\n(Ближайшие улики теперь мигают на мини-карте)'); }]);
    if (n.state === 'new') opts.push(['🤝 Тебе нужна помощь?', () => npcQuest(n)]);
    opts.push(['😽 Потереться носом', () => { P.hp = Math.min(P.maxHp, P.hp + P.maxHp * 0.15); Sound.sfx.purr(); npcPage(def.pet); }]);
    opts.push(['👋 Пока!', () => Screens.setState('play')]);
    npcButtons(opts);
  }
  function npcQuest(n) {
    const def = n.def;
    $('npcText').textContent = def.quest;
    npcButtons([
      ['Найду! 🐾', () => { n.state = 'quest'; World.qitems[n.ni].active = true; Screens.setState('play'); Screens.showBanner(`${def.item.ic} Поручение`, `Найди: ${def.item.name} – отмечено на мини-карте`); Saves.saveGame(); }],
      ['Потом', () => npcPage(def.greet)],
    ]);
  }
  function npcReward(n) {
    Sound.sfx.chest();
    for (let i = 0; i < 6; i++) Effects.dropShard(P.x + rnd(-40, 40), P.y + rnd(-40, 40));
    Effects.dropPickup(P.x, P.y + 40, 'heart'); Hero.addSuper(25);
    unlockOutfit('bell');
    if (G.st) G.st.quests = (G.st.quests || 0) + 1;
    Saves.saveGame();
  }
  // ------------------------------------------------------------------
  //  Гардероб Тессы
  // ------------------------------------------------------------------
  function unlockOutfit(id) {
    const prof = Saves.loadProfile(); prof.wardrobe = prof.wardrobe || { own: {}, on: 'none' };
    if (prof.wardrobe.own[id]) return;
    prof.wardrobe.own[id] = 1;
    if (!prof.wardrobe.on || prof.wardrobe.on === 'none') { prof.wardrobe.on = id; TESSA_OUTFIT = id; }
    Saves.saveProfile(prof);
    const w = WARDROBE.find(x => x.id === id);
    if (w) RunStats.toast(`🎀 Новый наряд для Тессы: ${w.ic} ${w.name}!`);
  }
  let wardBack = 'menu';
  function openWardrobe() { wardBack = Session.state === 'wardrobe' ? wardBack : Session.state; Screens.setState('wardrobe'); renderWardrobe(); }
  function renderWardrobe() {
    const prof = Saves.loadProfile(), wd = prof.wardrobe || { own: {}, on: 'none' };
    const box = $('wardList'); box.innerHTML = '';
    for (const w of WARDROBE) {
      const own = w.id === 'none' || GameLoop.DEBUG || wd.own[w.id], on = (wd.on || 'none') === w.id;
      const el = document.createElement('button'); el.className = 'ward' + (on ? ' on' : '') + (own ? '' : ' lock');
      el.innerHTML = `<span>${own ? w.ic : '🔒'}</span><b>${w.name}</b><i>${own ? (on ? 'надето' : 'надеть') : w.how}</i>`;
      el.addEventListener('click', () => {
        Sound.sfx.click();
        if (!own) { RunStats.toast('🔒 ' + w.how); return; }
        const p2 = Saves.loadProfile(); p2.wardrobe = p2.wardrobe || { own: {}, on: 'none' }; p2.wardrobe.on = w.id; Saves.saveProfile(p2);
        TESSA_OUTFIT = w.id; renderWardrobe();
      });
      box.appendChild(el);
    }
    const cv = $('wardPreview'), c2 = cv.getContext('2d'); c2.clearRect(0, 0, 200, 200);
    const g = c2.createRadialGradient(100, 100, 10, 100, 100, 100); g.addColorStop(0, '#3a5a9a'); g.addColorStop(1, '#0a1428');
    c2.fillStyle = g; c2.beginPath(); c2.arc(100, 100, 98, 0, TAU); c2.fill();
    drawTessa(c2, 92, 140, 0.4, 1, 4.6, 1, false);
  }

  return {
    loseLife, pounceHit, updateHouse, drawHouseGround, drawBox, drawPet, drawDarkness,
    drawHouseFx, openChoice, finishCh4, openBoard, openNpc, unlockOutfit, openWardrobe,
    get wardBack() { return wardBack; },
  };
})();
