'use strict';

const MenuActions = (() => {
  const kb = v => v >= 1048576 ? (v / 1048576).toFixed(1) + ' МБ' : Math.max(1, Math.round(v / 1024)) + ' КБ';
  function showUpdate() {
    const box = $('updBox'), u = G.update;
    if (!u || u.hiddenByUser || !['found', 'progress', 'ready', 'apk', 'loading', 'perm', 'installer', 'error'].includes(u.type)) { box.classList.add('hidden'); return; }
    const ic = $('updIc'), bar = $('updBar'), fill = $('updFill'), btns = box.querySelector('.updBtns');
    const quote = u.title ? `«${u.title}»` : '';
    let title = '', text = '', icon = '🔄', anim = 'spin', go = '', later = false, pct = -1;
    if (u.type === 'found' || u.type === 'progress') {
      title = `Обновление v${u.version}`;
      pct = u.total > 0 ? Math.min(100, Math.round(u.done / u.total * 100)) : -1;
      text = (quote ? quote + ' · ' : '') + (pct >= 0 ? `скачиваю ${pct}% · ${kb(u.done)} из ${kb(u.total)}` : 'скачиваю…');
    } else if (u.type === 'ready') {
      title = `Обновление v${u.version} готово!`; text = quote || 'Перезапусти – и играй в новой версии'; icon = '✨'; anim = 'bounce'; go = 'Перезапустить'; later = true; pct = 100;
    } else if (u.type === 'apk') {
      title = `Новая версия приложения v${u.version}`; text = (quote ? quote + ' · ' : '') + 'нужна переустановка, это быстро'; icon = '📦'; anim = 'bounce'; go = 'Скачать и установить'; later = true;
    } else if (u.type === 'loading') {
      title = 'Скачиваю приложение'; icon = '⬇️'; anim = 'bounce';
      pct = u.total > 0 ? Math.min(100, Math.round(u.done / u.total * 100)) : -1;
      text = pct >= 0 ? `${pct}% · ${kb(u.done)} из ${kb(u.total)}` : 'подожди немного…';
    } else if (u.type === 'perm') {
      title = 'Нужно разрешение'; text = 'Разреши установку приложений для Крилессы, вернись и нажми ещё раз'; icon = '🔐'; anim = ''; go = 'Установить';
    } else if (u.type === 'installer') {
      title = 'Почти готово'; text = 'Подтверди установку в окне Android'; icon = '📦'; anim = 'bounce'; go = 'Открыть ещё раз';
    } else {
      title = 'Не получилось скачать'; text = 'Проверь интернет и попробуй ещё раз'; icon = '⚠️'; anim = ''; go = 'Ещё раз'; later = true;
    }
    ic.textContent = icon; ic.className = anim;
    $('updTitle').textContent = title; $('updText').textContent = text;
    bar.classList.toggle('hidden', pct === -1 && !['found', 'progress', 'loading'].includes(u.type));
    bar.classList.toggle('indet', pct < 0);
    if (pct >= 0) fill.style.width = pct + '%';
    $('updGo').textContent = go; $('updGo').classList.toggle('hidden', !go); $('updLater').classList.toggle('hidden', !later);
    btns.classList.toggle('hidden', !go && !later);
    box.classList.remove('hidden');
  }
  window.krUpdate = u => {
    if (!u || !u.type) return;
    const prev = G.update;
    if (u.type === 'fail') { G.update = null; showUpdate(); if (prev) RunStats.toast('⚠️ Обновление не скачалось – попробую в следующий раз'); return; }
    if (['found', 'progress', 'ready', 'apk', 'loading'].includes(u.type)) G.update = Object.assign({ base: u.type === 'loading' ? 'apk' : undefined }, prev && u.type === 'loading' ? { version: prev.version, title: prev.title } : {}, u);
    else if (prev) G.update = Object.assign({}, prev, { type: u.type, base: prev.base || prev.type });
    showUpdate();
    // в игре не мешаем – только короткая подсказка
    if (!['menu', 'chapSheet', 'splash', 'whatsnew'].includes(Session.state)) {
      if (u.type === 'found' && !(prev && prev.type === 'found')) RunStats.toast(`⬇️ Скачивается обновление v${u.version}…`);
      if (u.type === 'ready' && !(prev && prev.type === 'ready')) RunStats.toast(`✨ Обновление v${u.version} готово – перезапусти в меню`);
      if (u.type === 'apk' && !(prev && prev.type === 'apk')) RunStats.toast(`📦 Вышла новая версия приложения v${u.version}`);
    }
  };
  function updateSoundButtons() {
    const t = 'Звук: ' + (Sound.isEnabled() ? 'вкл' : 'выкл');
    $('btnSound').textContent = t; $('btnSound2').textContent = t;
  }
  const onTap = (id, fn) => $(id).addEventListener('click', () => { Sound.init(); Sound.sfx.click(); fn(); });
  const introOpen = n => { const pr = Saves.loadProfile(); return GameLoop.DEBUG || !!pr.admin || !!pr['ch' + n + 'Done']; };
  for (const button of document.querySelectorAll('#intros button[id^="btnIntro"]')) {
    const chapter = Number(button.id.slice('btnIntro'.length)) || 1;
    onTap(button.id, () => {
      if (introOpen(chapter)) Intro.start('ch' + chapter, AdventureMenu.openMenu);
      else RunStats.toast(`🔒 Интро ${chapter} откроется после главы ${chapter}`);
    });
  }
  onTap('btnTalents', Achievements.openTalents);
  // стартовый экран
  onTap('spMap', () => {
    if (!AdventureMenu.SP.firstJourney) {
      AdventureMenu.openMenu();
      return;
    }
    Intro.start('ch1', () => {
      const profile = Saves.loadProfile();
      profile.seenPrologue = true;
      Saves.saveProfile(profile);
      AdventureMenu.openMenu();
    });
  });
  $('splashCv').addEventListener('pointerdown', e => { // тап по героине – прыжок с сердечками
    Sound.init();
    const r = $('splashCv').getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top;
    for (const id of AdventureMenu.SP.heroes) {
      const p = AdventureMenu.SP.heroX && AdventureMenu.SP.heroX[id]; if (!p || Math.abs(x - p[0]) > 50 || Math.abs(y - p[1]) > 80) continue;
      if (AdventureMenu.SP.jump[id] > 0) continue;
      AdventureMenu.SP.jump[id] = 1; Achievements.life('toss'); Achievements.lifeSoon();
      for (let k = 0; k < 6; k++) AdventureMenu.SP.hearts.push({ x: p[0] + rnd(-24, 24), y: p[1] - 20, t: -k * 0.08, col: pick(['#ff5b8a', '#ff9ad8', '#ffd25a']) });
      if (id === 'tessa' && Sound.sfx.meow) Sound.sfx.meow(); else Sound.sfx.blink();
    }
  });
  onTap('updGo', () => {
    const A = window.KrilessaAndroid, u = G.update; if (!A || !u) return;
    const kind = u.base || u.type;
    if (kind === 'ready') {
      $('updOverlay').classList.remove('hidden'); Sound.sfx.superReady();
      setTimeout(() => { if (A.applyUpdate) A.applyUpdate(); }, 900);
      setTimeout(() => $('updOverlay').classList.add('hidden'), 6000);
    } else if (A.installApk) A.installApk();
  });
  onTap('updLater', () => { if (G.update) G.update.hiddenByUser = true; showUpdate(); RunStats.toast('Хорошо! Обновление включится само при следующем запуске'); });
  // главный экран: карточка главы, панель, настройки
  onTap('shClose', AdventureMenu.closeSheet);
  $('shBack').addEventListener('click', AdventureMenu.closeSheet);
  onTap('shPlay', () => {
    if (AdventureMenu.sheetCh === 'rush') { const pr = Saves.loadProfile(); if (GameLoop.DEBUG || pr.admin || pr.ch1Done) Challenges.startRush(); else RunStats.toast('🔒 Босс-раш откроется после главы 1'); return; }
    if (!Chapters.chapterOpen(AdventureMenu.sheetCh)) { RunStats.toast(`🔒 Сначала пройди главу ${AdventureMenu.sheetCh - 1}`); return; }
    Chapters.startChapter(AdventureMenu.sheetCh);
  });
  onTap('shNew', () => { const n = AdventureMenu.sheetCh; GameStorage.remove(Saves.saveKey(n)); Chapters.startChapter(n); });
  onTap('shIntro', () => { const n = AdventureMenu.sheetCh; Intro.start('ch' + n, AdventureMenu.openMenu); });
  onTap('chapRush', () => AdventureMenu.openChapterSheet('rush'));
  onTap('mStars', Achievements.openTalents);
  onTap('btnGear', () => Screens.setState('settings'));
  onTap('setBack', AdventureMenu.openMenu);
  const volLabel = () => { $('btnVol').textContent = '✨ Объёмная графика: ' + (Renderer.volOn ? 'вкл' : 'выкл'); };
  // ---------- настройка джойстика: режим, размер, место (перетаскиванием) ----------
  const joyLabel = () => { const t = '🕹️ Джойстик: ' + (Controls.JOY.fixed ? 'закреплён' : 'плавающий'); $('btnJoy').textContent = t; $('btnJoy2').textContent = t; };
  let joyBack = 'settings';
  function saveJoy() { const pr = Saves.loadProfile(); pr.settings = pr.settings || {}; pr.settings.joy = { fixed: Controls.JOY.fixed, x: +Controls.JOY.x.toFixed(3), y: +Controls.JOY.y.toFixed(3), k: Controls.JOY.k }; Saves.saveProfile(pr); joyLabel(); }
  function joyEditPaint() {
    const el = $('jeStick'), r = Controls.JOY_R;
    el.style.width = el.style.height = r * 2 + 'px'; el.style.left = (Controls.JOY.x * Viewport.VW - r) + 'px'; el.style.top = (Controls.JOY.y * Viewport.VH - r) + 'px';
    el.querySelector('i').style.width = el.querySelector('i').style.height = 48 * Controls.JOY.k + 'px';
    el.classList.toggle('float', !Controls.JOY.fixed);
    for (const b of document.querySelectorAll('#jeMode button')) b.classList.toggle('on', (b.dataset.m === 'fixed') === Controls.JOY.fixed);
    for (const b of document.querySelectorAll('#jeSize button')) b.classList.toggle('on', +b.dataset.k === Controls.JOY.k);
    $('jeHint').textContent = Controls.JOY.fixed ? 'Перетащи круг туда, где удобно держать палец' : 'Плавающий – появляется там, где коснёшься. Круг показывает размер';
  }
  function openJoyEdit() { joyBack = Session.state; Screens.setState('joyedit'); joyEditPaint(); }
  function closeJoyEdit() { saveJoy(); Screens.setState(joyBack); }
  (() => {
    const el = $('jeStick'); let drag = null;
    el.addEventListener('pointerdown', e => { e.preventDefault(); drag = { id: e.pointerId, dx: e.clientX - Controls.JOY.x * Viewport.VW, dy: e.clientY - Controls.JOY.y * Viewport.VH }; try { el.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ } el.classList.add('drag'); if (!Controls.JOY.fixed) { Controls.JOY.fixed = true; } joyEditPaint(); });
    el.addEventListener('pointermove', e => {
      if (!drag || e.pointerId !== drag.id) return;
      const r = Controls.JOY_R + 6;
      Controls.JOY.x = clamp(e.clientX - drag.dx, r, Viewport.VW - r) / Viewport.VW; Controls.JOY.y = clamp(e.clientY - drag.dy, Viewport.VH * 0.3, Viewport.VH - r) / Viewport.VH; joyEditPaint();
    });
    const end = e => { if (drag && e.pointerId === drag.id) { drag = null; el.classList.remove('drag'); saveJoy(); } };
    el.addEventListener('pointerup', end); el.addEventListener('pointercancel', end);
    for (const b of document.querySelectorAll('#jeMode button')) b.addEventListener('click', () => { Sound.sfx.click(); Controls.JOY.fixed = b.dataset.m === 'fixed'; joyEditPaint(); saveJoy(); });
    for (const b of document.querySelectorAll('#jeSize button')) b.addEventListener('click', () => { Sound.sfx.click(); Controls.JOY.k = +b.dataset.k; Controls.JOY_R = 55 * Controls.JOY.k; joyEditPaint(); saveJoy(); });
  })();
  onTap('btnJoy', openJoyEdit); onTap('btnJoy2', openJoyEdit);
  onTap('jeDone', closeJoyEdit);
  onTap('jeReset', () => { Controls.applyJoy({ fixed: Controls.JOY.fixed }); joyEditPaint(); saveJoy(); });
  const miniLabel = () => { $('btnMini').textContent = '🗺️ Мини-карта: ' + (HUD.MM_STYLE === 'classic' ? 'классика' : HUD.MM_STYLE === 'paper' ? 'листок' : 'неон'); };
  onTap('btnMini', () => {
    HUD.MM_STYLE = HUD.MM_STYLE === 'paper' ? 'neon' : HUD.MM_STYLE === 'neon' ? 'classic' : 'paper'; const pr = Saves.loadProfile(); pr.settings = pr.settings || {}; pr.settings.mini = HUD.MM_STYLE; pr.settings.miniV = 2; Saves.saveProfile(pr); miniLabel();
    RunStats.toast(HUD.MM_STYLE === 'classic' ? 'Классическая мини-карта – вся карта целиком' : HUD.MM_STYLE === 'paper' ? 'Мини-карта на листочке – местность вокруг и цели по краю 📜' : 'Неоновая мини-карта – местность вокруг и цели по краю ✨');
  });
  const styleLabel = () => { $('btnStyle').textContent = '🎨 Стиль: ' + (Terrain.paperOn ? 'акварель' : 'классика'); };
  onTap('btnStyle', () => {
    const pr = Saves.loadProfile(); pr.settings = pr.settings || {}; pr.settings.style = Terrain.paperOn ? 'classic' : 'paper';
    if (pr.settings.miniV !== 2) pr.settings.mini = pr.settings.style === 'paper' ? 'paper' : 'neon';
    Saves.saveProfile(pr); RunStats.toast(pr.settings.style === 'paper' ? 'Книжная акварель – перезапускаю…' : 'Классический стиль – перезапускаю…');
    setTimeout(() => location.reload(), 700);
  });
  onTap('btnVol', () => {
    Renderer.volOn = !Renderer.volOn; const pr = Saves.loadProfile(); pr.settings = pr.settings || {}; pr.settings.vol = Renderer.volOn; Saves.saveProfile(pr); volLabel();
    RunStats.toast(Renderer.volOn ? 'Объём включён ✨' : 'Объём выключен – так быстрее на слабых телефонах');
  });
  // ---------- режим админа: 5 касаний по номеру версии в меню ----------
  const ADMIN_HASH = 'xa5467';
  const passHash = str => { let x = 5381; for (const ch of str) x = ((x * 33) ^ ch.codePointAt(0)) >>> 0; return x.toString(36); };
  let verTaps = 0, verT = 0;
  $('menu').querySelector('.version').addEventListener('click', () => {
    const now = performance.now(); verTaps = now - verT < 1500 ? verTaps + 1 : 1; verT = now;
    if (verTaps >= 5) { verTaps = 0; openAdmin(); }
  });
  function openAdmin() {
    const on = !!Saves.loadProfile().admin;
    $('adminHint').className = 'hint';
    $('adminHint').textContent = on ? 'Режим админа включён ✅ Все главы, интро и босс-раш открыты' : 'Введи пароль – откроются все главы, интро и босс-раш';
    $('adminPass').classList.toggle('hidden', on); $('adminPass').value = '';
    $('adminOk').textContent = on ? 'Выключить' : 'Войти';
    Screens.setState('admin');
    if (!on) setTimeout(() => $('adminPass').focus(), 50);
  }
  function adminSubmit() {
    const pr = Saves.loadProfile();
    if (pr.admin) { delete pr.admin; LOOK_ALL = false; Saves.saveProfile(pr); RunStats.toast('🔒 Режим админа выключен'); AdventureMenu.openMenu(); return; }
    if (passHash($('adminPass').value.trim().toLowerCase()) !== ADMIN_HASH) {
      $('adminHint').className = 'hint bad'; $('adminHint').textContent = 'Неверный пароль'; $('adminPass').value = ''; Sound.sfx.hurt(); return;
    }
    pr.admin = true; LOOK_ALL = true; Saves.saveProfile(pr); Sound.sfx.superReady();
    RunStats.toast('🔓 Открыты все главы, интро и босс-раш'); AdventureMenu.openMenu();
  }
  onTap('adminOk', adminSubmit);
  onTap('adminBack', AdventureMenu.openMenu);
  $('adminPass').addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); adminSubmit(); } });
  onTap('talBack', AdventureMenu.openMenu);
  onTap('talReset', () => {
    const pr = Saves.loadProfile(); if (!talentSpent(pr.talents || {})) return;
    pr.talents = {};
    if ((pr.relics || []).length > 3) { pr.relics = pr.relics.slice(0, 3); RunStats.toast('🎒 Четвёртый карман пуст – последняя реликвия убрана'); }
    Saves.saveProfile(pr); Achievements.renderTalents();
  });
  onTap('rushHero', () => {
    const pr = Saves.loadProfile(); pr.settings = pr.settings || {};
    const list = ['krilessa', 'ryzhovaya'].concat(pr.ch4Done || GameLoop.DEBUG || pr.admin ? ['tessa'] : []);
    pr.settings.rushHero = list[(list.indexOf(pr.settings.rushHero || 'krilessa') + 1) % list.length]; Saves.saveProfile(pr); AdventureMenu.openChapterSheet('rush');
  });
  // ---------- ориентация экрана (в приложении 0.20+; в браузере экран и так поворачивается) ----------
  const ORIENT = { auto: '🔄 поворачивается', portrait: '📱 вертикально', landscape: '📺 горизонтально' };
  const orientBridge = () => { const A = window.KrilessaAndroid; return A && A.setOrientation ? A : null; };
  function orientMode() { const A = orientBridge(); try { return A ? A.orientation() || 'auto' : 'auto'; } catch (e) { return 'auto'; } }
  function orientLabel() { $('btnOrient').textContent = 'Экран: ' + ORIENT[orientMode()]; }
  onTap('btnOrient', () => {
    const A = orientBridge();
    if (!A) { RunStats.toast(window.KrilessaAndroid ? '📲 Поворот экрана появится после обновления приложения (APK)' : '🔄 В браузере экран поворачивается сам'); return; }
    const order = ['auto', 'landscape', 'portrait'], next = order[(order.indexOf(orientMode()) + 1) % order.length];
    try { A.setOrientation(next); } catch (e) { /* ignore */ }
    setTimeout(orientLabel, 60); $('btnOrient').textContent = 'Экран: ' + ORIENT[next];
    RunStats.toast(next === 'auto' ? '🔄 Экран поворачивается вместе с телефоном' : next === 'landscape' ? '📺 Всегда горизонтально' : '📱 Всегда вертикально');
  });
  // подсказка в начале главы: игру можно перевернуть (пока игрок сам ни разу не играл лёжа)
  let rotHintT = 0;
  function rotHintMaybe(tries = 0) {
    if (Session.state !== 'play') { if (tries < 12 && (Session.state === 'levelup' || Session.state === 'relic' || Session.state === 'pause')) setTimeout(() => rotHintMaybe(tries + 1), 1200); return; } // сначала выбор улучшения
    const pr = Saves.loadProfile();
    if (pr.rotSeen || Viewport.VW > Viewport.VH || orientMode() !== 'auto') return;
    if (window.KrilessaAndroid && !orientBridge()) return; // старое приложение – экран заперт вертикально
    const el = $('rotHint'); el.classList.remove('hidden', 'out');
    clearTimeout(rotHintT); rotHintT = setTimeout(rotHintHide, 4200);
  }
  function rotHintHide() { const el = $('rotHint'); if (el.classList.contains('hidden') || el.classList.contains('out')) return; el.classList.add('out'); clearTimeout(rotHintT); rotHintT = setTimeout(() => el.classList.add('hidden'), 420); }
  $('rotHint').addEventListener('pointerdown', ev => { ev.stopPropagation(); rotHintHide(); });
  window.addEventListener('resize', () => {
    if (Viewport.VW <= Viewport.VH || Session.state !== 'play') return;
    rotHintHide();
    const pr = Saves.loadProfile(); if (!pr.rotSeen) { pr.rotSeen = true; Saves.saveProfile(pr); }
  });
  // ---------- уведомления «Вышла новая версия» (только в приложении 0.11+) ----------
  function notifyLabel(st) {
    const A = window.KrilessaAndroid, bt = $('btnNotify');
    if (!A || !A.notifyState) { bt.classList.add('hidden'); return; }
    try { st = st || A.notifyState(); } catch (e) { st = 'off'; }
    bt.classList.remove('hidden');
    bt.textContent = '🔔 Уведомления: ' + (st === 'on' ? 'вкл' : st === 'blocked' ? 'запрещены' : 'выкл');
  }
  window.krNotify = st => notifyLabel(st);
  onTap('btnNotify', () => {
    const A = window.KrilessaAndroid; if (!A || !A.setNotify) return;
    const st = A.notifyState();
    A.setNotify(st !== 'on');
    if (st === 'on') RunStats.toast('🔕 Уведомления о новых версиях выключены');
    else if (st === 'blocked') RunStats.toast('Разреши уведомления для Крилессы в настройках Android');
  });
  // ---------- кнопка сложности: у кринж-хардкора – налитые кровью «глаза» и кровь, которая капает на кнопки ниже ----------
  const DIFF_IC = { easy: '🍵', normal: '⚔️', hard: '😈' };
  function veinsSvg(w, h, base) { // красные прожилки, как на воспалённых белках глаз: от краёв к середине
    const out = [];
    const grow = (x, y, a, len, wd, depth, delay) => {
      let d = `M${x.toFixed(1)} ${y.toFixed(1)}`;
      for (let s = 0; s < len; s += 5) {
        a += rnd(-0.55, 0.55);
        x += Math.cos(a) * 5; y += Math.sin(a) * 5;
        if (y < 2 || y > h - 2) { a = -a; y = clamp(y, 2, h - 2); }
        d += ` L${x.toFixed(1)} ${y.toFixed(1)}`;
        if (depth < 2 && Math.random() < 0.17) grow(x, y, a + rnd(0.5, 1.1) * (Math.random() < 0.5 ? -1 : 1), len * rnd(0.3, 0.55), wd * 0.6, depth + 1, delay + (s / len) * 0.5);
      }
      out.push(`<path d="${d}" pathLength="1" stroke-width="${wd.toFixed(2)}" style="animation-delay:${(Math.max(0, base) + delay).toFixed(2)}s"/>`);
    };
    for (let i = 0; i < 4; i++) grow(0, rnd(6, h - 6), rnd(-0.5, 0.5), rnd(40, 85), 1.7, 0, rnd(0, 0.25));
    for (let i = 0; i < 4; i++) grow(w, rnd(6, h - 6), Math.PI + rnd(-0.5, 0.5), rnd(40, 85), 1.7, 0, rnd(0, 0.25));
    for (let i = 0; i < 3; i++) grow(rnd(w * 0.2, w * 0.8), h, -Math.PI / 2 + rnd(-0.6, 0.6), rnd(12, 24), 1.1, 1, rnd(0.2, 0.5));
    return `<svg class="veins${base >= 0 ? ' grow' : ''}" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none">${out.join('')}</svg>`;
  }
  function paintDiff(anim) {
    const id = (Saves.loadProfile().settings || {}).diff || 'normal', bt = $('btnDiff');
    bt.querySelector('.dfTx').textContent = `${DIFF_IC[id] || ''} Сложность: ${(DIFFS[id] || DIFFS.normal).name}`;
    bt.classList.remove('dEasy', 'dNormal', 'dHard', 'filling');
    bt.classList.add({ easy: 'dEasy', normal: 'dNormal', hard: 'dHard' }[id] || 'dNormal');
    clearTimeout(paintDiff.t);
    if (id === 'hard') {
      bt.querySelector('.dfVeins').innerHTML = veinsSvg(bt.offsetWidth || 300, bt.offsetHeight || 48, anim ? 0.55 : -1);
      if (anim) { void bt.offsetWidth; bt.classList.add('filling'); paintDiff.t = setTimeout(() => bt.classList.remove('filling'), 950); }
    } else bt.querySelector('.dfVeins').innerHTML = '';
    Blood.reset(id === 'hard' && Session.state === 'settings', anim ? 0.8 : 0);
  }
  const Blood = (() => { // подтёки с низа кнопки, капли и пятна на кнопках ниже
    const BL = '#8e0612';
    let on = false, raf = 0, last = 0, t = 0, drips = [], drops = [], stains = [], bits = [], band = [];
    const clear = () => { const c = $('bloodCv'); c.getContext('2d').clearRect(0, 0, c.width, c.height); };
    function reset(enable, delay) {
      on = enable; drips = []; drops = []; stains = []; bits = []; t = -delay;
      clear();
      if (!on) { cancelAnimationFrame(raf); raf = 0; return; }
      const w = $('btnDiff').offsetWidth || 300, n = 8, longs = new Set();
      while (longs.size < 2) longs.add(Math.floor(rnd(0, n)));
      for (let i = 0; i < n; i++) drips.push({ x: 18 + (w - 36) * (i + rnd(0.15, 0.85)) / n, w: rnd(3.5, 7.5), len: longs.has(i) ? rnd(120, 230) : rnd(10, 70),
        cur: 0, d: rnd(0, 0.7), sp: rnd(0.6, 1.2), drop: rnd(0.8, 3), bulb: 1 });
      band = Array.from({ length: 16 }, (_, i) => ({ x: 12 + (w - 24) * i / 15, r: rnd(2.5, 6) }));
      if (!raf) { last = performance.now(); raf = requestAnimationFrame(loop); }
    }
    function drip(g, x, y0, w, len, bulb) {
      g.fillStyle = BL;
      g.beginPath(); g.moveTo(x - w / 2 - 3, y0); g.quadraticCurveTo(x - w / 2, y0 + 1, x - w / 2, y0 + 5);
      g.lineTo(x - w * 0.4, y0 + len); g.lineTo(x + w * 0.4, y0 + len); g.lineTo(x + w / 2, y0 + 5);
      g.quadraticCurveTo(x + w / 2, y0 + 1, x + w / 2 + 3, y0); g.closePath(); g.fill();
      const r = w * 0.62 * bulb;
      if (r > 0.5) { g.beginPath(); g.arc(x, y0 + len, r, 0, TAU); g.fill(); }
      g.fillStyle = 'rgba(255,120,130,.4)'; if (len > 8) g.fillRect(x - w * 0.28, y0 + 4, Math.max(1, w * 0.16), len - 6);
      if (r > 1.5) { g.fillStyle = 'rgba(255,255,255,.45)'; g.beginPath(); g.arc(x - r * 0.35, y0 + len - r * 0.3, r * 0.28, 0, TAU); g.fill(); }
    }
    function loop(now) {
      if (!on || Session.state !== 'settings') { raf = 0; clear(); return; }
      raf = requestAnimationFrame(loop);
      const dt = Math.min(0.05, (now - last) / 1000); last = now; t += dt;
      const c = $('bloodCv'), g = c.getContext('2d'), dpr = Math.min(window.devicePixelRatio || 1, 2);
      const W = c.clientWidth, H = c.clientHeight;
      if (c.width !== Math.round(W * dpr) || c.height !== Math.round(H * dpr)) { c.width = Math.round(W * dpr); c.height = Math.round(H * dpr); }
      g.setTransform(dpr, 0, 0, dpr, 0, 0); g.clearRect(0, 0, W, H);
      if (t < 0) return; // кровь ещё заливает кнопку
      const cr = c.getBoundingClientRect(), br = $('btnDiff').getBoundingClientRect();
      const bx = br.left - cr.left, by = br.bottom - cr.top + 3; // низ «бортика» кнопки
      const tg = [...document.querySelectorAll('#settings .btn')].filter(b => b.id !== 'btnDiff').map(b => { const r = b.getBoundingClientRect(); return { l: r.left - cr.left, t: r.top - cr.top, r: r.right - cr.left }; });
      // кровь стекла через край
      g.fillStyle = BL; const k = Math.min(1, t * 2.5);
      g.fillRect(bx + 12, by - 5, (br.width - 24) * k, 5);
      for (const s of band) if (s.x <= (br.width - 12) * k + 12) { g.beginPath(); g.arc(bx + s.x, by - 1, s.r, 0, Math.PI); g.fill(); }
      for (const d of drips) {
        if (t < d.d) continue;
        d.cur = Math.min(d.len, d.cur + dt * d.sp * (14 + (d.len - d.cur) * 0.9));
        d.bulb = Math.min(1, d.bulb + dt * 0.8);
        if (d.cur >= d.len * 0.9 && (d.drop -= dt) <= 0) { // капля сорвалась
          drops.push({ x: bx + d.x, y: by + d.cur + d.w * 0.6, vy: 30, r: d.w * 0.6 });
          d.bulb = 0.25; d.drop = rnd(1.4, 4);
        }
        drip(g, bx + d.x, by, d.w, d.cur, d.bulb);
      }
      for (const p of drops) {
        const py = p.y; p.vy += 1100 * dt; p.y += p.vy * dt;
        for (let i = 0; i < tg.length; i++) {
          const T = tg[i];
          if (p.x > T.l + 6 && p.x < T.r - 6 && py < T.t + 3 && p.y >= T.t + 3) { // шлёп! пятно на кнопке
            const blobs = Array.from({ length: 3 + Math.floor(rnd(0, 4)) }, () => ({ ox: rnd(-7, 7), oy: rnd(-2, 4), r: rnd(1.5, 4.5) }));
            stains.push({ i, dx: p.x - T.l, dy: rnd(1, 7), blobs, len: 0, max: rnd(3, 20), w: rnd(2.5, 4.5) });
            if (stains.length > 36) stains.shift();
            for (let q = 0; q < 5; q++) bits.push({ x: p.x, y: T.t + 3, vx: rnd(-120, 120), vy: rnd(-170, -70), life: rnd(0.25, 0.45) });
            p.dead = true; break;
          }
        }
        if (p.y > H + 20) p.dead = true;
        if (!p.dead) { g.fillStyle = BL; g.beginPath(); g.ellipse(p.x, p.y, p.r, p.r * 1.35, 0, 0, TAU); g.fill(); }
      }
      drops = drops.filter(p => !p.dead);
      for (const s of stains) {
        const T = tg[s.i]; if (!T) continue;
        const x = T.l + s.dx, y = T.t + s.dy;
        s.len = Math.min(s.max, s.len + dt * 6);
        g.fillStyle = BL; for (const b of s.blobs) { g.beginPath(); g.arc(x + b.ox, y + b.oy, b.r, 0, TAU); g.fill(); }
        drip(g, x, y, s.w, s.len, 1);
      }
      for (const b of bits) { b.life -= dt; b.vy += 900 * dt; b.x += b.vx * dt; b.y += b.vy * dt; if (b.life > 0) { g.fillStyle = BL; g.beginPath(); g.arc(b.x, b.y, 1.6, 0, TAU); g.fill(); } }
      bits = bits.filter(b => b.life > 0);
    }
    function resume() { // те же подтёки и пятна, что были до ухода с экрана
      if (!on || !drips.length) return false;
      if (!raf) { last = performance.now(); raf = requestAnimationFrame(loop); }
      return true;
    }
    return { reset, resume };
  })();
  onTap('btnDiff', () => {
    const pr = Saves.loadProfile(); pr.settings = pr.settings || {};
    const order = ['easy', 'normal', 'hard'], cur = pr.settings.diff || 'normal';
    pr.settings.diff = order[(order.indexOf(cur) + 1) % 3]; Saves.saveProfile(pr);
    paintDiff(true);
    RunStats.toast(pr.settings.diff === 'hard' ? 'Кринж-хардкор: враги злее, элита чаще 😈' : pr.settings.diff === 'easy' ? 'Лёгкий режим: можно расслабиться 🍵' : 'Нормальная сложность');
  });
  for (const id of ['btnStats', 'btnStats2', 'btnStats3', 'btnStats4']) onTap(id, RunStats.openStats);
  onTap('statsShare', () => RunStats.shareText(RunStats.buildReport()));
  onTap('statsCopy', () => RunStats.copyText(RunStats.buildReport()));
  onTap('statsBack', () => { if (RunStats.statsBack === 'menu') AdventureMenu.openMenu(); else Screens.setState(RunStats.statsBack); });
  onTap('btnWhatsNew', () => Story.openWhatsNew(null));
  onTap('wnClose', Story.closeWhatsNew);
  onTap('ch4Riddle', Story.openTeaser);
  onTap('relicMelt', () => { for (let i = 0; i < 12; i++) Effects.dropShard(P.x + rnd(-40, 40), P.y + rnd(-40, 40)); Screens.setState('play'); RunStats.toast('💎 Реликвия переплавлена в 12 осколков'); });
  onTap('mapClose', () => Screens.setState('play'));
  ChapterMap.initMapGestures(onTap);
  $('mapCanvas').addEventListener('click', () => Screens.setState('play'));
  onTap('btnIntros', () => Screens.setState('intros'));
  onTap('btnMP', Multiplayer.openMP);
  onTap('btnStarAtlas', StarAtlas.open);
  onTap('atlasBack', AdventureMenu.openMenu);
  onTap('atlasTravel', StarAtlas.travel);
  onTap('btnModes', Collection.openModes); onTap('btnColl', Collection.openColl);
  onTap('modesBack', AdventureMenu.openMenu); onTap('collBack', AdventureMenu.openMenu);
  onTap('mdDefGo', () => Defense.startDefense());
  onTap('mdAbyssGo', () => Challenges.startAbyss(Challenges.abyssCkLoad())); onTap('mdAbyssNew', () => Challenges.startAbyss()); onTap('mdDailyGo', Challenges.startDaily);
  onTap('mdHero', () => { const pr = Saves.loadProfile(); pr.settings = pr.settings || {}; const list = ['krilessa', 'ryzhovaya'].concat(pr.ch4Done || GameLoop.DEBUG || pr.admin ? ['tessa'] : []);
    pr.settings.rushHero = list[(list.indexOf(Challenges.rushHeroPick(pr)) + 1) % list.length]; Saves.saveProfile(pr); Collection.openModes(); });
  onTap('btnAch', () => { Achievements.lifeFlush(); Achievements.achCat = 'all'; Achievements.renderAch(); Screens.setState('ach'); }); onTap('achBack', Collection.openColl);
  // слава: доска почёта и образ
  let lookBack = 'coll';
  function lookDone() { cancelAnimationFrame(Achievements.lookRaf); if (lookBack === 'menu') AdventureMenu.openMenu(); else Collection.openColl(); }
  onTap('btnHall', () => Achievements.openHall('rec'));
  onTap('btnRelics', () => { Collection.relicsFrom = 'coll'; Collection.openRelics(); }); onTap('relicsBack', () => Collection.relicsLeave());
  onTap('btnHome', () => HomeScreen.openHome('coll')); onTap('mHome', () => HomeScreen.openHome('menu'));
  onTap('homeBack', () => { cancelAnimationFrame(HomeScreen.HOME.raf); if (HomeScreen.HOME.back === 'menu') AdventureMenu.openMenu(); else Collection.openColl(); });
  onTap('homeEditBtn', () => { HomeScreen.HOME.edit = !HomeScreen.HOME.edit; $('homeEdit').classList.toggle('hidden', !HomeScreen.HOME.edit); $('homeEditBtn').textContent = HomeScreen.HOME.edit ? '✓ Готово' : '✏️ Обставить'; if (HomeScreen.HOME.edit) HomeScreen.renderHomeEdit(); });
  for (const k of ['furn', 'pets', 'wall']) onTap('heT_' + k, () => { HomeScreen.HOME.tab = k; HomeScreen.renderHomeEdit(); });
  $('homeCv').addEventListener('pointerdown', HomeScreen.homeTap);
  onTap('seasonBar', () => { if (!Seasons.SEASON_OFF) Seasons.openSeason(); });
  onTap('seasonBack', AdventureMenu.openMenu);
  onTap('btnLook', () => { lookBack = 'coll'; Achievements.openLook(); });
  onTap('mEmb', () => { lookBack = 'menu'; Achievements.openLook(); });
  onTap('mRank', () => Achievements.openHall('rec'));
  onTap('hallBack', Collection.openColl);
  onTap('lookBack', lookDone);
  for (const [id, tab] of [['hlTabR', 'rec'], ['hlTabF', 'fr']]) {
    onTap(id, () => {
      Achievements.hallTab = tab;
      Sound.sfx.click();
      Achievements.renderHall();
    });
  }
  for (const k of ['em', 'fr', 'ti', 'au']) onTap('lkT_' + k, () => { Achievements.lookTab = k; Sound.sfx.click(); Achievements.renderLook(); });
  $('lkName').addEventListener('change', () => {
    const pr = Saves.loadProfile(), v = ($('lkName').value || '').trim().slice(0, 14);
    pr.mp = Object.assign({ hero: 'krilessa' }, pr.mp || {}, { name: v || HEROES.krilessa.name }); Saves.saveProfile(pr); Achievements.renderLook();
  });
  onTap('hlShare', () => {
    const code = Achievements.cardCode(Achievements.myCard());
    $('hlCode').value = code;
    try { if (window.KrilessaAndroid && window.KrilessaAndroid.share) { window.KrilessaAndroid.share('Моя карточка в Крилессе 🏅 Добавь меня на доску почёта:\n' + code); return; } } catch (e) { /* ignore */ }
    RunStats.fallbackCopy(code); RunStats.toast('📋 Код карточки скопирован – отправь подруге');
  });
  onTap('hlAdd', () => {
    const c = Achievements.readCode($('hlCode').value);
    if (!c) { RunStats.toast('Код не подошёл 🤔 Скопируй его целиком, начиная с KR1-'); Sound.sfx.block(); return; }
    if (c.id === Saves.loadProfile().pid) { RunStats.toast('Это твоя карточка 😄'); return; }
    Achievements.addFriends([c]); $('hlCode').value = ''; RunStats.toast(`🎉 ${c.nm} теперь на доске почёта!`); Sound.sfx.superReady(); Achievements.renderHall();
  });
  onTap('btnBook', () => Collection.openBook('e')); onTap('bookBack', () => Collection.bookLeave());
  for (const tab of ['e', 'b', 'v']) {
    onTap('bookTab' + tab.toUpperCase(), () => {
      Collection.bookTab = tab;
      Collection.renderBook();
    });
  }
  onTap('bkClose', () => $('bkDetail').classList.add('hidden'));
  onTap('shMut', () => Challenges.openMuts(AdventureMenu.sheetCh)); onTap('mutGo', Challenges.mutGo); onTap('mutBack', () => { if (Challenges.mutNet) { Screens.setState('mp'); Multiplayer.mpRender(); } else AdventureMenu.openChapterSheet(Challenges.mutCh); });
  onTap('btnVib', () => { const pr = Saves.loadProfile(); pr.settings = pr.settings || {}; Challenges.vibOn = !((pr.settings.vib !== false)); pr.settings.vib = Challenges.vibOn; Saves.saveProfile(pr); Challenges.vibLabel(); if (Challenges.vibOn) Challenges.buzz(60); });
  onTap('mpHostBtn', Multiplayer.mpHost);
  onTap('mpJoinBtn', Multiplayer.mpScan);
  onTap('mpGo', Multiplayer.mpGo);
  onTap('mpMut', () => { if (NET.host && !NET.started && typeof NET.ch === 'number') Challenges.openMuts(NET.ch, true); });
  onTap('mpResume', () => { // продолжить сохранённую игру вместе (выбор, начинает «Готовы» / «Начать»)
    const sv = Saves.coopLoad(Saves.COOP_KEY); if (!NET.host || !sv || !CHAPTERS[sv.ch]) return;
    if (NET.resume) { NET.resume = null; } else { NET.resume = sv; NET.ch = sv.ch; RunStats.toast('💾 Продолжим сохранённую игру – жмите «Готова»'); }
    for (const m of NET.peers.values()) m.rd = false; NET.rdy = false;
    Multiplayer.mpRender(); Multiplayer.mpLobbyBroadcast();
  });
  onTap('mpReady', Multiplayer.mpToggleReady);
  onTap('mpBack', mpBack);
  onTap('mpIpGo', () => { const ip = ($('mpIp').value || '').trim(); if (!/^\d{1,3}(\.\d{1,3}){3}$/.test(ip)) { RunStats.toast('Адрес вида 192.168.1.5'); return; } Multiplayer.mpName(); Multiplayer.mpJoin(ip, 0); });
  $('mpName').addEventListener('change', () => { Multiplayer.mpName(); if (NET.client) { NET.card = Achievements.myCard(); NetT.send(0, { t: 'me', name: NET.name, hero: NET.hero, cd: NET.card }); } if (NET.host) Multiplayer.mpLobbyBroadcast(); });
  function mpBack() {
    if (NET.host || NET.client || NET.scanning) { Multiplayer.mpLeave(); NET.scanning = false; Multiplayer.mpRender(); if (Session.state === 'mp') return; }
    AdventureMenu.openMenu();
  }
  onTap('introsBack', () => Screens.setState('menu'));
  onTap('choiceGood', () => HouseChapter.finishCh4('good'));
  onTap('choiceKind', () => HouseChapter.finishCh4('kind'));
  onTap('boardGo', () => { Screens.setState('play'); if (G.pendingLv > 0) Screens.openLevelUp(); });
  onTap('npcBtn', () => HouseChapter.openNpc(G.nearNpc));
  onTap('btnWardrobe', HouseChapter.openWardrobe);
  onTap('wardBack', () => { if (HouseChapter.wardBack === 'menu') AdventureMenu.openMenu(); else Screens.setState(HouseChapter.wardBack); });
  onTap('portalBtn', Encounters.openPortals);
  onTap('portalBack', () => Screens.setState('play'));
  onTap('teaserBack', Story.closeTeaser);
  onTap('krillBack', Story.closeKrill);
  $('krillCanvas').addEventListener('pointerdown', e => {
    Sound.init();
    const r = $('krillCanvas').getBoundingClientRect(), x = (e.clientX - r.left) / r.width * 480, y = (e.clientY - r.top) / r.height * 640;
    Story.KT.tap = { x, y, t: 0.35 }; Achievements.life('krillTap'); Achievements.lifeSoon();
    Story.KT.pops.push({ x, y, t: 0, text: pick(Story.KRILL_SAY) });
    for (let k = 0; k < 6; k++) Story.KT.bubbles.push({ x: x + rnd(-20, 20), y: y + rnd(-10, 10), r: rnd(2, 5), v: rnd(60, 120) });
    Sound.sfx.shard();
  });
  $('teaserCanvas').addEventListener('pointerdown', () => { Sound.init(); Sound.sfx.meow(); Story.teaserGlow = 1; });
  onTap('zmPlay', () => Story.zmReact('Браво мне! БРАВО! Но спектакль ещё не окончен! 😈', true));
  onTap('zmLike', () => Story.zmReact('Роза?! Мне?! ...Спасибо, зайка. Но тебя это не спасёт! 🌹😈', true));
  onTap('zmDonate', () => Story.zmReact('ПОМИДОР?! В мою лучшую корону?! Ну всё!!! 🍅😤', true));
  $('zmExit').addEventListener('pointerdown', e => {
    e.preventDefault(); Sound.init(); Sound.sfx.click();
    if (!G.zm) return;
    G.zm.tries++;
    const el = $('zmExit');
    el.style.transform = `translate(${rnd(-110, 110)}px, ${rnd(-140, 60)}px) rotate(${rnd(-25, 25)}deg)`;
    el.textContent = ['✖ Выйти', 'Куда?! 😏', 'Не-не-не!', 'Выхода нет 😈'][Math.min(3, G.zm.tries)];
    if (G.zm.tries >= 3) { Story.zmReact('Из театра не уходят посреди спектакля! Второй акт! 😈', true); Achievements.lifeMax('escape', 1); }
  });
  // пасхалка: потыкай портрет в меню
  let portraitTaps = 0;
  $('menuPortrait').addEventListener('click', () => {
    portraitTaps++;
    if (portraitTaps % 7 === 0) {
      const c = $('menuPortrait').getContext('2d');
      if (Session.IMG.zyama) c.drawImage(Session.IMG.zyama.cartoon, 0, 0, 240, 320);
      Sound.init(); Sound.sfx.roar();
      RunStats.toast('Зямочкккк: Эй! Не трогай её! Я ей, между прочим, стих посвятил! 😤');
      Achievements.lifeMax('poke', 1); Achievements.lifeSoon();
      setTimeout(AdventureMenu.drawMenuPortrait, 2200);
    }
  });
  function toggleSound() {
    Sound.setEnabled(!Sound.isEnabled());
    updateSoundButtons();
  }
  onTap('btnSound', toggleSound);
  onTap('btnSound2', toggleSound);
  function saveAndOpenMenu() {
    Saves.saveGame();
    AdventureMenu.openMenu();
  }
  onTap('btnResume', Screens.resumeGame);
  onTap('btnToMenu', saveAndOpenMenu);
  onTap('btnRetry', Screens.respawn);
  onTap('btnDeadMenu', saveAndOpenMenu);
  onTap('btnVictoryMenu', AdventureMenu.openMenu);
  onTap('victoryNext', () => {
    if (NET.on && G.netRun) { if (NET.host && CHAPTERS[World.CHN + 1]) { NET.ch = World.CHN + 1; Multiplayer.mpGo(); } else if (NET.client) RunStats.toast('Следующую главу запустит хозяйка 🏠'); return; } // вместе: следующую главу запускает хозяйка
    Chapters.startChapter(World.CHN + 1);
  });
  for (const el of document.querySelectorAll('.version')) el.textContent = 'v' + VERSION;

  window.krBack = () => {
    if (Session.state === 'mp') { mpBack(); return 'handled'; }
    if (Session.state === 'book' && !$('bkDetail').classList.contains('hidden')) { $('bkDetail').classList.add('hidden'); return 'handled'; }
    if (Session.state === 'book' && Collection.bookBack === 'home') { Collection.bookLeave(); return 'handled'; }
    if (Session.state === 'relics') { Collection.relicsLeave(); return 'handled'; }
    if (Session.state === 'home') { if (HomeScreen.HOME.edit) { $('homeEditBtn').click(); return 'handled'; } $('homeBack').click(); return 'handled'; }
    if (Session.state === 'ach' || Session.state === 'book' || Session.state === 'hall') { Collection.openColl(); return 'handled'; }
    if (Session.state === 'look') { lookDone(); return 'handled'; }
    if (Session.state === 'season') { AdventureMenu.openMenu(); return 'handled'; }
    if (Session.state === 'modes' || Session.state === 'coll' || Session.state === 'starAtlas') { AdventureMenu.openMenu(); return 'handled'; }
    if (Session.state === 'muts') { AdventureMenu.openChapterSheet(Challenges.mutCh); return 'handled'; }
    if (Session.state === 'stats') { if (RunStats.statsBack === 'menu') AdventureMenu.openMenu(); else Screens.setState(RunStats.statsBack); return 'handled'; }
    if (Session.state === 'whatsnew') { Story.closeWhatsNew(); return 'handled'; }
    if (Session.state === 'teaser') { Story.closeTeaser(); return 'handled'; }
    if (Session.state === 'krill') { Story.closeKrill(); return 'handled'; }
    if (Session.state === 'choice' || Session.state === 'relic') return 'handled';
    if (Session.state === 'mapscr') { Screens.setState('play'); return 'handled'; }
    if (Session.state === 'intros') { Screens.setState('menu'); return 'handled'; }
    if (Session.state === 'talents' || Session.state === 'admin') { AdventureMenu.openMenu(); return 'handled'; }
    if (Session.state === 'joyedit') { closeJoyEdit(); return 'handled'; }
    if (Session.state === 'chapSheet' || Session.state === 'settings') { AdventureMenu.openMenu(); return 'handled'; }
    if (Session.state === 'board') { if (G.accused) { Screens.setState('play'); if (G.pendingLv > 0) Screens.openLevelUp(); } return 'handled'; }
    if (Session.state === 'npc') { Screens.setState('play'); return 'handled'; }
    if (Session.state === 'wardrobe') { if (HouseChapter.wardBack === 'menu') AdventureMenu.openMenu(); else Screens.setState(HouseChapter.wardBack); return 'handled'; }
    if (Session.state === 'portal') { Screens.setState('play'); return 'handled'; }
    if (Session.state === 'zmenu') { Story.zmReact('Кнопка «Назад» тоже моя! Сидеть и смотреть! 😈', true); Achievements.lifeMax('escape', 1); return 'handled'; }
    if (Session.state === 'victory' && $('victoryButtons').classList.contains('hidden')) return 'handled';
    if (Session.state === 'play') { Screens.pauseGame(); return 'handled'; }
    if (Session.state === 'pause') { Screens.resumeGame(); return 'handled'; }
    if (Session.state === 'levelup') return 'handled';
    if (Session.state === 'intro') { Intro.skip(); return 'handled'; }
    if (Session.state === 'dead' || Session.state === 'victory') { AdventureMenu.openMenu(); return 'handled'; }
    return 'exit';
  };
  function pauseApp() {
    if (Session.state === 'play') Screens.pauseGame();
    Sound.suspend();
    if (GameLoop.inRun()) GameLoop.liveWrite(true);
  }
  function resumeApp() {
    Sound.resume();
    if (GameLoop.inRun()) GameLoop.liveWrite(false);
  }
  window.krPause = pauseApp;
  window.krResume = resumeApp;
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) pauseApp();
    else resumeApp();
  });

  return {
    showUpdate, updateSoundButtons, volLabel, joyLabel, miniLabel, styleLabel,
    orientLabel, rotHintMaybe, rotHintHide, notifyLabel, paintDiff, Blood,
  };
})();
