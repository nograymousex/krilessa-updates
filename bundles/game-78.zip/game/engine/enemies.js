'use strict';

const Enemies = (() => {
  // ------------------------------------------------------------------
  //  Враги
  // ------------------------------------------------------------------
  const SLIME_COL = { 0: '#63d65a', 1: '#8fae3a', 2: '#8fd8ff', 3: '#b05bd6', 4: '#7dff9a', 7: '#a98bff' };
  const BAT_COL = { 0: '#6b4a8f', 1: '#4a6b3a', 2: '#5a7fa8', 3: '#3a2050', 4: '#8a5aa8', 7: '#4a3a8f' };
  function spawnEnemy(type, x, y, biome, opts = {}) {
    const d = ENEMIES[type];
    const E = opts.E || Actors.zoneE(biome);
    const sc = opts.sc || (G.td ? Defense.tdScale(E) : Actors.mobScale(E)); // в обороне и свита стражей живёт по правилам обороны
    const elite = !!opts.elite;
    const affix = elite ? pick(AFFIXES).id : null;
    let col = d.col;
    if (type === 'slime' && SLIME_COL[biome]) col = SLIME_COL[biome];
    if (type === 'bat' && BAT_COL[biome]) col = BAT_COL[biome];
    const calm = opts.minion ? 0 : Encounters.calmOf(biome);
    const hp = d.hp * sc.hp * (elite ? 3 : 1) * (1 - calm);
    const e = {
      type, def: d, sprite: d.sprite || type, x, y, r: d.r * (elite ? 1.35 : 1),
      hp, maxHp: hp, dmg: d.dmg * sc.dmg * (elite ? 1.4 : 1) * (affix === 'frenzied' ? 1.2 : 1) * (1 - calm),
      spd: d.spd * rnd(0.9, 1.1) * (elite ? 1.08 : 1) * (affix === 'fast' ? 1.45 : 1), xp: d.xp * sc.xp * (elite ? 5 : 1), fly: !!d.fly,
      t: 0, seed: Math.random() * 10, flash: 0, kx: 0, ky: 0, orbCd: 0, cd: rnd(0.8, 2.2), jt: rnd(0.3, 1.5), jd: 0, jx: 0, jy: 0,
      wind: 0, fuse: 0, charge: 0, burst: 0, burstT: 0, blink: 0, bx: 0, by: 0, healing: 0, healTargets: [],
      face: 1, look: 0, dead: false, flank: rnd(-1, 1) * (d.pack ? 1.3 : d.ai === 'swarm' ? 1.2 : 0.8),
      steerT: 0, steerDir: 1, stuckT: 0, dodgeCd: rnd(0, 1), slowT: 0, spawnT: opts.instant ? 0 : 0.45, elite,
      col, shieldAng: 0, biome, minion: !!opts.minion, small: type === 'mummini', vx: 0, vy: 0, dashAng: 0,
      shrine: opts.shrine || null, haz: null, exploded: false, E, affix, dr: affix === 'armored' ? 0.5 : 0,
      cdMul: affix === 'frenzied' ? 0.6 : 1, buffT: 0, burnT: 0, burnDps: 0, burnTick: 0, owner: opts.owner || null, sumT: rnd(1, 3),
      bossPart: opts.bossPart || null,
    };
    if (G.mut) { if (G.mut.ng) { e.hp *= 1.6; e.maxHp *= 1.6; e.dmg *= 1.6; } if (G.mut.fast) e.spd *= 1.3; }
    G.enemies.push(e);
    return e;
  }
  function seek(e, ux, uy, d, mul = 1) {
    const f = e.flank * mul * clamp((d - 90) / 220, 0, 1);
    const c = Math.cos(f), s = Math.sin(f);
    return [ux * c - uy * s, ux * s + uy * c];
  }
  // снаряды мобов летят недалеко и рассеиваются (раньше – до 6 секунд, через полкарты)
  const MOB_SHOT_RANGE = 480, MOB_RING_RANGE = 380, SHOT_FADE = 0.3;
  function fireShot(e) {
    const s = e.def.shot;
    const dmg = s.dmg * (e.dmg / e.def.dmg);
    if (s.kind === 'bolt') {
      const tt = 0.6;
      const Q = Session.AIM || P; Bosses.hazardCircle(Q.x + (Q.vx || 0) * tt, Q.y + (Q.vy || 0) * tt, 44, 0.7, dmg, 'bolt');
    } else if (s.ring) {
      const off = s.spin ? e.t * 2 : e.t;
      for (let k = 0; k < s.n; k++) Bosses.ebullet(e.x, e.y, k / s.n * TAU + off, s.spd, dmg, s.col || '#ff3ea5', 8, { emoji: s.emoji, square: s.square, life: MOB_RING_RANGE / s.spd });
    } else {
      const a = Physics.leadAngle(e.x, e.y, s.spd);
      for (let k = 0; k < s.n; k++) Bosses.ebullet(e.x, e.y, a + (k - (s.n - 1) / 2) * (s.spread || 0), s.spd, dmg, s.col || '#ffffff', s.emoji ? 9 : 6, { life: MOB_SHOT_RANGE / s.spd, emoji: s.emoji, emojiSet: s.emojiSet, square: s.square });
    }
    Sound.sfx.enemyShot();
  }
  function tryDodge(e) {
    for (const f of G.feathers) {
      const rx = e.x - f.x, ry = e.y - f.y;
      if (rx * rx + ry * ry > 95 * 95) continue;
      const sp = Math.hypot(f.vx, f.vy) || 1, vx = f.vx / sp, vy = f.vy / sp;
      const along = rx * vx + ry * vy, cross = rx * vy - ry * vx;
      if (along > 0 && Math.abs(cross) < e.r + 10) {
        const s = cross >= 0 ? 1 : -1;
        e.kx += -vy * s * 330; e.ky += vx * s * 330;
        e.dodgeCd = e.elite ? 0.9 : 1.6;
        Effects.part(e.x, e.y, 0, 0, 0.3, 4, 'rgba(255,255,255,0.7)');
        return;
      }
    }
  }
  // сколько стрелков стреляют разом: в главах – по номеру главы, в обороне – трое (в Бездне и раше стрелки молчат, как и раньше)
  function shotCap() { return typeof World.CHN === 'number' ? 2 + World.CHN : G.core ? 3 : -1; }
  function updateEnemy(e, dt) {
    const Q = Session.AIM || P; // цель моба
    e.t += dt;
    if (e.flash > 0) e.flash -= dt;
    if (e.orbCd > 0) e.orbCd -= dt;
    if (e.slowT > 0) e.slowT -= dt;
    if (e.dodgeCd > 0) e.dodgeCd -= dt;
    if (e.healing > 0) e.healing -= dt;
    if (e.buffT > 0) e.buffT -= dt;
    if (e.spawnT > 0) { e.spawnT -= dt; return; }
    if (e.burnT > 0) {
      e.burnT -= dt; e.burnTick -= dt;
      if (e.burnTick <= 0) {
        e.burnTick = 0.4; e.hp -= e.burnDps * 0.4 * (1 - e.dr);
        if (Math.random() < 0.5) Effects.part(e.x + rnd(-6, 6), e.y - 6, rnd(-20, 20), rnd(-60, -30), 0.4, 3, '#ff8a2a');
        if (e.hp <= 0) { killEnemy(e); return; }
      }
    }
    if (e.affix === 'vampiric' && e.hp < e.maxHp) e.hp = Math.min(e.maxHp, e.hp + e.maxHp * 0.02 * dt);
    const def = e.def;
    const dx = Q.x - e.x, dy = Q.y - e.y, d = Math.hypot(dx, dy) || 1;
    const ux = dx / d, uy = dy / d;
    e.look = Math.atan2(dy, dx);
    let mx = 0, my = 0, spd = e.spd * (e.slowT > 0 ? 0.55 : 1);
    const evId = G.ev ? G.ev.def.id : null;
    if (evId === 'song' && !e.minion) { e.kx *= 0.9; e.ky *= 0.9; return; } // концерт: замерли и танцуют
    if (G.hidden && !e.minion) { const a = e.seed * 3 + e.t * 0.6; Physics.moveEntity(e, Math.cos(a) * spd * 0.3 * dt, Math.sin(a) * spd * 0.3 * dt); return; } // Тесса в коробке
    if (e.lit > 0) { e.lit -= dt; spd *= 0.6; } // тёплый свет лампы глитчам не нравится
    if (evId === 'rage') spd *= 1.25;
    if (e.thief) { // золотой воришка убегает зигзагом и обходит стены
      spd = P.speed * 0.8 * (e.slowT > 0 ? 0.6 : 1);
      const w = Math.sin(e.t * 2.2 + e.seed * 5) * 0.75;
      let fx = -ux - uy * w, fy = -uy + ux * w; const L = Math.hypot(fx, fy) || 1; fx /= L; fy /= L;
      for (let k = 0; k < 4 && !Physics.walkable(e.x + fx * 34, e.y + fy * 34, false); k++) { const s2 = e.seed > 0.5 ? 1 : -1; [fx, fy] = [-fy * s2, fx * s2]; }
      mx = fx; my = fy;
      if (Math.random() < dt * 8) Effects.part(e.x + rnd(-8, 8), e.y - 6, rnd(-20, 20), rnd(-50, -20), 0.5, 3, '#ffd25a');
    } else switch (def.ai) {
      case 'chase': [mx, my] = seek(e, ux, uy, d); spd *= 0.82; if (def.pack && d < 170) spd *= 1.2; break; // догоняющие – помедленнее, от них можно оторваться
      case 'hop': [mx, my] = seek(e, ux, uy, d); spd *= 1.8 * Math.max(0, Math.sin(e.t * 6 + e.seed)); break;
      case 'bat': { const w = Math.sin(e.t * 5 + e.seed) * 0.9; const [sx, sy] = seek(e, ux, uy, d); mx = sx - sy * w; my = sy + sx * w; break; }
      case 'swarm': if (d < 130) { mx = ux; my = uy; spd *= 1.15; } else [mx, my] = seek(e, ux, uy, d, 1.6); break;
      case 'jump':
        e.jt -= dt;
        if (e.wind > 0) { e.wind -= dt; if (e.wind <= 0) { e.jd = 0.35; const a = Physics.leadAngle(e.x, e.y, 300, 0.5); e.jx = Math.cos(a); e.jy = Math.sin(a); } }
        else if (e.jd > 0) { e.jd -= dt; mx = e.jx; my = e.jy; spd = 300; }
        else if (e.jt <= 0 && d < 500) { e.jt = rnd(1.2, 1.8); e.wind = 0.35; }
        else if (G.core && d >= 500) { [mx, my] = seek(e, ux, uy, d); spd *= 0.7; } // в обороне издалека подходят пешком
        break;
      case 'ranged': case 'turret': {
        if (def.ai === 'ranged') {
          if (d > 230) { [mx, my] = seek(e, ux, uy, d); } else if (d < 105) { mx = -ux; my = -uy; }
          else { const s = Math.sin(e.seed) > 0 ? 1 : -1; mx = -uy * s; my = ux * s; spd *= 0.6; }
        }
        e.cd -= dt;
        if (e.burst > 0) { e.burstT -= dt; if (e.burstT <= 0) { fireShot(e); e.burst--; e.burstT = 0.16; } }
        else if (e.charge > 0) { e.charge -= dt; spd *= 0.3; if (e.charge <= 0) { fireShot(e); if (def.shot.burst) { e.burst = def.shot.burst - 1; e.burstT = 0.16; } } }
        else if (e.cd <= 0 && d < 430) {
          if (G.shooters < shotCap()) { e.charge = 0.38; e.cd = def.shot.cd * rnd(0.85, 1.15) * e.cdMul; G.shooters++; }
          else e.cd = 0.3;
        }
        break;
      }
      case 'summoner': {
        e.cd -= dt; e.sumT -= dt;
        if (e.charge > 0) { e.charge -= dt; if (e.charge <= 0) fireShot(e); }
        else if (e.cd <= 0 && d < 430 && G.shooters < shotCap()) { e.charge = 0.4; e.cd = def.shot.cd * e.cdMul; G.shooters++; }
        if (e.sumT <= 0) {
          e.sumT = 5;
          const mine = G.enemies.filter(o => o.owner === e && !o.dead).length;
          for (let k = 0; k < 2 && mine + k < 6; k++) { const s = spawnEnemy(def.summons, e.x + rnd(-24, 24), e.y + rnd(-24, 24), e.biome, { owner: e, E: e.E }); s.xp *= 0.3; }
        }
        break;
      }
      case 'buffer': {
        if (d < 260) { mx = -ux; my = -uy; }
        let cxs = 0, cys = 0, n = 0;
        for (const o of G.enemies) { if (o === e || o.dead) continue; const dd = (o.x - e.x) ** 2 + (o.y - e.y) ** 2; if (dd < 400 * 400) { cxs += o.x; cys += o.y; n++; } }
        if (n) { const tx = cxs / n - e.x, ty = cys / n - e.y, tl = Math.hypot(tx, ty) || 1; if (tl > 90) { mx += tx / tl * 0.7; my += ty / tl * 0.7; } }
        else if (G.core) [mx, my] = seek(e, ux, uy, d); // в обороне одинокая поддержка тоже идёт к кристаллу
        e.cd -= dt;
        if (e.cd <= 0) {
          e.cd = 3.5; e.healTargets = [];
          for (const o of G.enemies) {
            if (o === e || o.dead) continue;
            if ((o.x - e.x) ** 2 + (o.y - e.y) ** 2 < 200 * 200) { o.buffT = 3; e.healTargets.push(o); }
          }
          if (e.healTargets.length) e.healing = 0.5;
        }
        break;
      }
      case 'healer': {
        if (d < 260) { mx = -ux; my = -uy; }
        let cxs = 0, cys = 0, n = 0;
        for (const o of G.enemies) { if (o === e || o.dead || o.def.ai === 'healer') continue; const dd = (o.x - e.x) ** 2 + (o.y - e.y) ** 2; if (dd < 400 * 400) { cxs += o.x; cys += o.y; n++; } }
        if (n) { const tx = cxs / n - e.x, ty = cys / n - e.y, tl = Math.hypot(tx, ty) || 1; if (tl > 90) { mx += tx / tl * 0.7; my += ty / tl * 0.7; } }
        else if (G.core) [mx, my] = seek(e, ux, uy, d); // в обороне одинокая поддержка тоже идёт к кристаллу
        e.cd -= dt;
        if (e.cd <= 0) {
          e.cd = 3.2; e.healTargets = [];
          for (const o of G.enemies) {
            if (o === e || o.dead || o.hp >= o.maxHp) continue;
            if ((o.x - e.x) ** 2 + (o.y - e.y) ** 2 < 190 * 190) { o.hp = Math.min(o.maxHp, o.hp + o.maxHp * 0.3); e.healTargets.push(o); Effects.floatText(o.x, o.y - o.r - 8, '+', '#7dff9a'); }
          }
          if (e.healTargets.length) e.healing = 0.5;
        }
        break;
      }
      case 'shield':
        e.shieldAng += clamp(angDiff(e.shieldAng, e.look), -2.1 * dt, 2.1 * dt);
        [mx, my] = seek(e, ux, uy, d, 0.5);
        break;
      case 'exploder':
        if (e.fuse > 0) { e.fuse -= dt; if (e.fuse <= 0) { e.exploded = true; killEnemy(e); } }
        else { [mx, my] = seek(e, ux, uy, d); if (d < 72) { e.fuse = 0.65; e.haz = Bosses.hazardCircle(e.x, e.y, 88, 0.65, e.dmg, 'boom'); Sound.sfx.fuse(); } }
        break;
      case 'charger':
        if (e.wind > 0) { e.wind -= dt; if (e.wind <= 0) e.jd = 0.42; }
        else if (e.jd > 0) { e.jd -= dt; mx = Math.cos(e.dashAng); my = Math.sin(e.dashAng); spd = 490; if (e.jd <= 0) e.cd = rnd(1.2, 2); }
        else {
          e.cd -= dt;
          [mx, my] = seek(e, ux, uy, d);
          if (d < 290 && e.cd <= 0) { e.wind = 0.55; e.dashAng = Physics.leadAngle(e.x, e.y, 490, 0.5); mx = 0; my = 0; }
        }
        break;
      case 'bouncer': {
        if (!e.vx && !e.vy) { const a = e.look + rnd(-0.6, 0.6); e.vx = Math.cos(a); e.vy = Math.sin(a); }
        const cur = Math.atan2(e.vy, e.vx), na = cur + clamp(angDiff(cur, e.look), -1.3 * dt, 1.3 * dt);
        e.vx = Math.cos(na); e.vy = Math.sin(na);
        const ox = e.x, oy = e.y, stx = e.vx * spd * dt, sty = e.vy * spd * dt;
        Physics.moveEntity(e, stx, sty);
        if (Math.abs(e.x - ox) < Math.abs(stx) * 0.5) e.vx = -e.vx;
        if (Math.abs(e.y - oy) < Math.abs(sty) * 0.5) e.vy = -e.vy;
        spd = 0;
        break;
      }
      case 'blinker':
        if (e.blink > 0) {
          e.blink -= dt; spd = 0;
          if (e.blink <= 0) { e.x = e.bx; e.y = e.by; Effects.burst(e.x, e.y, 14, '#ff5bf0', 160); e.kx = ux * 220; e.ky = uy * 220; }
        } else {
          [mx, my] = seek(e, ux, uy, d);
          e.cd -= dt;
          if (e.cd <= 0 && d > 150 && d < 480) {
            const base = Math.hypot(Q.vx, Q.vy) > 20 ? Math.atan2(Q.vy, Q.vx) : rnd(0, TAU);
            for (let k = 0; k < 6; k++) {
              const a = base + rnd(-0.9, 0.9), x = Q.x + Math.cos(a) * 95, y = Q.y + Math.sin(a) * 95;
              if (Physics.walkable(x, y, e.fly)) { e.bx = x; e.by = y; e.blink = 0.55; Bosses.hazardCircle(x, y, 26, 0.55, 0, 'dark'); break; }
            }
            e.cd = rnd(3, 4.5);
          }
        }
        break;
    }
    if (def.dodge && e.dodgeCd <= 0) tryDodge(e);
    // обход препятствий
    if (e.steerT > 0) {
      e.steerT -= dt;
      const a = e.steerDir * 1.25, c = Math.cos(a), s = Math.sin(a);
      const nx = mx * c - my * s, ny = mx * s + my * c; mx = nx; my = ny;
    }
    if (Math.abs(mx) > 0.1) e.face = mx > 0 ? 1 : -1;
    const ex = e.x, ey = e.y;
    const want = Math.hypot(mx, my) * spd * dt;
    Physics.moveEntity(e, (mx * spd + e.kx) * dt, (my * spd + e.ky) * dt);
    if (!e.fly && want > 0.6) {
      const moved = Math.hypot(e.x - ex, e.y - ey);
      if (moved < want * 0.3) { e.stuckT += dt; if (e.stuckT > 0.2) { e.steerT = 0.7; e.steerDir = Math.random() < 0.5 ? -1 : 1; e.stuckT = 0; } }
      else e.stuckT = 0;
    }
    const kd = Math.pow(0.002, dt); e.kx *= kd; e.ky *= kd;
    const dP = Q === P ? d : Math.hypot(P.x - e.x, P.y - e.y); // касание считаем по себе: по подругам бьёт их телефон
    if (dP < e.r + P.r - 2 && e.blink <= 0 && e.fuse <= 0 && !e.thief) {
      const wasInv = P.inv > 0 || P.dashT > 0;
      Hero.hurtPlayer(e.jd > 0 && def.ai === 'charger' ? e.dmg * 1.5 : e.dmg, e.x, e.y);
      if (!wasInv && e.affix === 'vampiric') e.hp = Math.min(e.maxHp, e.hp + e.dmg * 2);
    }
    if (d > 1600 && !e.shrine && !e.champion && !e.mimicOf) e.dead = true;
  }
  function updateEnemies(dt) {
    const list = G.enemies;
    G.shooters = 0;
    for (const e of list) if (!e.dead && (e.charge > 0 || e.burst > 0)) G.shooters++;
    for (const e of list) if (!e.dead) {
      Session.AIM = NET.host ? Multiplayer.netAim(e.x, e.y) : P;
      if (G.td && Defense.tdEnemyTick(e, dt)) continue; // в обороне враги идут по дороге; отвлеклась на героиню – дальше своим умом
      updateEnemy(e, dt);
    }
    Session.AIM = P;
    for (let i = 0; i < list.length; i++) {
      const a = list[i]; if (a.dead || a.spawnT > 0) continue;
      for (let j = i + 1; j < list.length; j++) {
        const b = list[j]; if (b.dead || b.spawnT > 0) continue;
        const dx = b.x - a.x, dy = b.y - a.y, rr = a.r + b.r;
        const d2 = dx * dx + dy * dy;
        if (d2 < rr * rr && d2 > 0.01) {
          const d = Math.sqrt(d2), push = (rr - d) * 0.5, nx = dx / d, ny = dy / d;
          if (a.def.ai !== 'turret') { a.x -= nx * push; a.y -= ny * push; }
          if (b.def.ai !== 'turret') { b.x += nx * push; b.y += ny * push; }
        }
      }
    }
    if (G.td) for (const e of list) { // в обороне враги не сходят с дороги, даже когда толкаются у котов или стоят во льду
      if (e.dead || e.ln === undefined || e.ag || e.back || e.px === undefined) continue;
      const dx = e.x - e.px, dy = e.y - e.py, d = Math.hypot(dx, dy);
      if (d > 26) { e.x = e.px + dx / d * 26; e.y = e.py + dy / d * 26; }
    }
    G.enemies = list.filter(e => !e.dead);
  }
  function killEnemy(e, silent) {
    if (e.dead) return;
    e.dead = true;
    if (e.haz && !e.exploded) { e.haz.cancel = true; if (NET.host && e.haz.nid) NET.hzCancel.push(e.haz.nid); }
    Effects.burst(e.x, e.y, e.elite ? 30 : 12, e.type === 'snowman' ? '#ffffff' : e.col.startsWith('#') ? e.col : '#c77dff', 170);
    if (e.exploded) { Effects.burst(e.x, e.y, 30, '#ff8a2a', 260); Sound.sfx.boom(); G.shake = Math.max(G.shake, 8); }
    if (e.shrine) e.shrine.left--;
    if (e.bossPart) Bosses.bossPartDestroyed(e.bossPart);
    if (e.affix === 'volatile' && !silent) Bosses.hazardCircle(e.x, e.y, 95, 0.55, e.dmg * 1.3, 'boom');
    else if (G.mut && G.mut.boom && !silent && !e.minion && !e.bossPart) Bosses.hazardCircle(e.x, e.y, 80, 0.6, e.dmg, 'boom');
    if (e.def.puddle && !silent) G.hazards.push({ kind: 'zone', x: e.x, y: e.y, r: 52, t: 0, delay: 0.2, dur: 4, dot: e.dmg * 0.3, fx: 'toxic' });
    if (NET.host && e.nid) NET.killed.push([e.nid]);
    if (silent || e.def.noDrop) return;
    G.kills++;
    if (G.td && G.abyss && !G.abyss.done) {
      G.abyss.coins += Math.round((1.5 + e.def.xp * 1.2) * (e.champion ? 8 : e.elite ? 3 : 1) * (Defense.tdTwist('gold') ? 2 : 1)); // монетки на стройку – общие
      for (const sp of G.td.spots) { const tw = sp.tw; if (!tw || tw.k !== 'bank' || tw.lvl < 4) continue; const S = tdStat(tw.def, tw.lvl, tw.sp); if (S.luck && (e.x - tw.x) ** 2 + (e.y - tw.y) ** 2 < S.rng * S.rng) { G.abyss.coins += S.luck; tw.pop = { v: S.luck, t: 0.8 }; } } // счастливая монетка
    }
    const byMate = Defense.TD_HIT ? -1 : NET.host ? NET.hitBy : 0; // добила подруга – супер и вампиризм ей; добила башня (−1) – никому
    if (byMate > 0) Multiplayer.netEvent(byMate, ['k', e.elite ? 1 : 0, e.type]); else { if (!byMate) Hero.addSuper(e.elite ? 8 : 2.2); Achievements.life('kills'); if (e.elite) Achievements.life('elites'); Collection.bookKill('e', e.type); }
    if (!byMate && e.slowT > 0 && Actors.lv('evBlizzard')) { // ледяная буря: осколки во все стороны
      for (let k = 0; k < 6; k++) { const a = k * TAU / 6 + Math.random() * 0.4; G.feathers.push({ x: e.x, y: e.y, vx: Math.cos(a) * 430, vy: Math.sin(a) * 430, dmg: P.dmg * 0.6, pierce: 1, life: 0.45, life0: 0.45, hit: [e], kind: P.proj }); }
      Effects.burst(e.x, e.y, 14, '#bfeaff', 170);
    }
    Challenges.dailyAdd(e.elite ? 50 : 10);
    if (G.st) { G.st.kills++; if (e.elite) G.st.elites++; G.st.byType[e.type] = (G.st.byType[e.type] || 0) + 1; }
    Sound.sfx.die();
    Effects.dropGem(e.x, e.y, e.xp * (1 + Math.min(G.combo, 100) / 100) / Multiplayer.netXpDiv()); // вместе мобов больше – опыт с них делим
    if (!Defense.TD_HIT) { G.combo++; G.comboT = 2.6; G.bestCombo = Math.max(G.bestCombo, G.combo); } // комбо – только за свои победы, башни не в счёт
    if (!byMate && P.vamp && P.hp < P.maxHp) P.hp = Math.min(P.maxHp, P.hp + P.vamp);
    const luck = Math.pow(1 + 0.15, Actors.talent('luck'));
    const nShards = G.td ? (e.elite && Math.random() < 0.5 ? 1 : 0) : e.elite ? 3 : (Math.random() < SHARD_CHANCE * luck * (G.ev && G.ev.def.id === 'gold' ? 2 : G.ev && G.ev.def.id === 'rage' ? 1.5 : 1) ? 1 : 0);
    for (let i = 0; i < nShards * (Seasons.weekEv('gold') ? 2 : 1); i++) Effects.dropShard(e.x, e.y);
    if (e.elite && !e.champion && Math.random() < 0.007) Effects.dropPickup(e.x - 12, e.y, 'key'); // ключи редкие – золотой сундук должен быть наградой
    if (e.mimicOf) Encounters.mimicKilled(e);
    if (e.thief) Encounters.thiefCaught(e);
    if (G.ev && G.ev.def.id === 'horde' && !e.minion) G.ev.kills++;
    if (e.gladeBeast || e.pikeLoot) {
      Effects.dropPickup(e.x + 14, e.y, 'heart'); for (let k = 0; k < (e.gladeBeast ? 6 : 3); k++) Effects.dropShard(e.x, e.y);
      if (e.gladeBeast) { Effects.dropPickup(e.x - 14, e.y, 'key'); Effects.floatText(e.x, e.y - 40, '🐆 Барс повержен!', '#ffd25a', true); }
    }
    if (!byMate && Encounters.hasRelic('fang') && P.hp < P.maxHp) P.hp = Math.min(P.maxHp, P.hp + P.maxHp * 0.005 * (1 + Encounters.relicLv('fang')));
    const r = Math.random();
    // чем меньше здоровья, тем чаще падают сердечки
    if (e.elite || r < (0.03 + 0.05 * clamp(1 - P.hp / P.maxHp, 0, 1) + 0.04 * Actors.lv('c1petal')) * luck) Effects.dropPickup(e.x + 10, e.y, 'heart');
    else if (r > 0.993) Effects.dropPickup(e.x + 10, e.y, 'magnet');
    Encounters.calmKill(e.biome);
    if (e.champion) {
      G.champ = null; if (G.st) G.st.champs = (G.st.champs || 0) + 1; if (!byMate) { Achievements.life('champs'); if (Seasons.weekEv('champ')) Achievements.life('spts', 15); } Challenges.dailyAdd(300);
      { const pr = Saves.loadProfile(); pr.champsTotal = (pr.champsTotal || 0) + 1; Saves.saveProfile(pr); if (pr.champsTotal >= 10) HouseChapter.unlockOutfit('crown'); }
      Screens.showBanner('👑 Чемпион повержен!', 'Награда: улучшение, осколки и сердечко');
      Sound.sfx.chest(); Effects.burst(e.x, e.y, 40, '#ffd25a', 260);
      for (let i = 0; i < 6; i++) Effects.dropShard(e.x + rnd(-30, 30), e.y + rnd(-30, 30));
      Effects.dropPickup(e.x, e.y + 20, 'heart'); if (Math.random() < 0.35) Effects.dropPickup(e.x - 24, e.y + 20, 'key');
      G.pendingLv++; Screens.openLevelUp();
      if (NET.host) for (const m of NET.peers.values()) Multiplayer.netEvent(m.id, ['lvl', 1]); // награда за чемпиона – всем
    }
    if (e.def.split) for (let k = 0; k < 2; k++) {
      const s = spawnEnemy(e.def.split, e.x + rnd(-10, 10), e.y + rnd(-10, 10), e.biome, { instant: true, E: e.E });
      s.kx = rnd(-200, 200); s.ky = rnd(-200, 200); s.shrine = e.shrine;
      if (e.shrine) e.shrine.left++;
    }
  }
  function damageEnemy(e, hit, kx, ky, fromFeather) {
    if (e.dead || e.spawnT > 0) return false;
    if (!NET.hitBy && e.slowT > 0 && Actors.lv('evBlizzard')) hit = { v: hit.v * 1.3, crit: hit.crit }; // ледяная буря
    if (NET.client) { // попадание гостьи: хозяин посчитает урон, тут – только вспышка и цифра
      if (!e.nid) return false;
      if (G.td && G.abyss) hit = { v: hit.v * (G.abyss.heroK || 1), crit: hit.crit }; // в обороне прокачка гостьи тоже уравнивается – у неё самой
      NET.hits.push([e.nid, Math.round(hit.v), hit.crit ? 1 : 0, Math.round(kx || 0), Math.round(ky || 0), P.frost && fromFeather ? +(1.2 + 0.4 * P.frost).toFixed(1) : 0]);
      e.flash = 0.1; e.hp = Math.max(1, e.hp - hit.v * (1 - (e.dr || 0)));
      Effects.dmgText(e.x + rnd(-6, 6), e.y - e.r - 6, hit.v * (1 - (e.dr || 0)), '#fff', hit.crit);
      if (G.st) G.st.dmgDealt += hit.v;
      Sound.sfx.hit();
      return true;
    }
    const shield = !Defense.TD_HIT && Defense.tdPortal(e); // у входа враги под защитой портала
    if (shield && (G.portalSaid || 0) < G.time) { G.portalSaid = G.time + 2.5; Effects.floatText(e.x, e.y - e.r - 14, '🌀 портал защищает', '#e0a0ff'); }
    const v = hit.v * (1 - e.dr) * (e.buffT > 0 ? 0.6 : 1) * (shield ? 0.25 : 1) * (G.td && G.abyss && e.ln !== undefined && !Defense.TD_HIT && !NET.hitBy ? (G.abyss.heroK || 1) : 1);
    e.hp -= v; e.flash = 0.1;
    if (G.st) G.st.dmgDealt += Math.min(v, e.hp + v);
    if (e.def.ai !== 'turret') { e.kx += kx; e.ky += ky; }
    if (P.frost && fromFeather) e.slowT = 1.2 + 0.4 * P.frost;
    Effects.dmgText(e.x + rnd(-6, 6), e.y - e.r - 6, v, e.dr || e.buffT > 0 ? '#b8c4d8' : '#fff', hit.crit);
    Sound.sfx.hit();
    if (e.hp <= 0) killEnemy(e);
    return true;
  }

  return {
    spawnEnemy, SHOT_FADE, fireShot, updateEnemies, killEnemy, damageEnemy,
  };
})();
