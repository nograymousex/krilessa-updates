'use strict';

const Terrain = (() => {
  // ------------------------------------------------------------------
  //  Отрисовка карты чанками
  // ------------------------------------------------------------------
  const PAL = {
    [PATH]: ['#7a5236', '#855b3c', '#6c482f'], [STONE]: ['#8a8a8e', '#98989c', '#7c7c80'],
    [WATER]: ['#8fcbe8', '#a2d7f0', '#82bfdc'], [ROCK]: ['#a4a4a8', '#b2b2b6', '#96969a'],
    [WALL]: ['#4e4262', '#584b6e', '#433856'], [LAVA]: ['#e0521b', '#f57a24', '#c8410f'],
    [FLOOR]: ['#4b4458', '#554d63', '#433d50'], [ICE]: ['#bfe5f4', '#d4f0fb', '#aed8ea'],
  };
  const PATH_BY_BIOME = { 5: ['#c9a466', '#d2ae70', '#bd9858'], 6: ['#5a4038', '#644840', '#4e3830'], 7: ['#4a4a6e', '#545478', '#404062'], 8: ['#3a2a5a', '#443266', '#30224c'] };
  const CHUNK = 16, CHPX = CHUNK * World.T;
  const chunkCache = new Map();

  function tilePal(t, b) {
    if (World.isGround(t)) return BIOMES[t].ground;
    const bi = BIOMES[b];
    if (t === WATER && bi.water) return bi.water;
    if (t === ROCK && bi.rock) return bi.rock;
    if (t === PATH && bi.path) return bi.path;
    if (t === PATH && PATH_BY_BIOME[b]) return PATH_BY_BIOME[b];
    if (t === STONE && bi.mirror) return ['#e4e4f6', '#f2f2ff', '#d6d6ec'];
    if (t === GATE) return PAL[FLOOR];
    return PAL[t];
  }
  function drawTile(c, tx, ty, ox, oy) {
    const i = ty * World.MW + tx, t = World.tiles[i], b = World.biomeMap[i], bi = BIOMES[b];
    const neon = bi.neon;
    if ((t === FLOOR || t === GATE) && neon) {
      c.fillStyle = (tx + ty) % 2 ? '#22143e' : '#2a1a4c'; c.fillRect(ox, oy, World.T, World.T);
      c.strokeStyle = 'rgba(63,240,255,0.25)'; c.lineWidth = 1; c.strokeRect(ox + 0.5, oy + 0.5, World.T - 1, World.T - 1);
      return;
    }
    if (t === WALL && neon) {
      c.fillStyle = '#1e1236'; c.fillRect(ox, oy, World.T, World.T);
      c.fillStyle = '#ff3ea5'; c.fillRect(ox, oy, World.T, 3);
      c.fillStyle = 'rgba(255,62,165,0.3)'; c.fillRect(ox, oy + 3, World.T, 3);
      if (World.tileAt(tx, ty + 1) !== WALL) { c.fillStyle = '#120a22'; c.fillRect(ox, oy + World.T - 12, World.T, 12); c.fillStyle = '#3ff0ff'; c.fillRect(ox, oy + World.T - 13, World.T, 2); }
      return;
    }
    if (bi.arena) {
      const st = ARENA_STYLE[World.CHN] || ARENA_STYLE[1];
      if (t === FLOOR) {
        c.fillStyle = (tx + ty) % 2 ? st.floor[0] : st.floor[1]; c.fillRect(ox, oy, World.T, World.T);
        const h = hash2(tx * 5 + 3, ty * 7 + 1);
        if (h < 0.45) { c.strokeStyle = st.crack; c.lineWidth = 2; c.beginPath(); c.moveTo(ox + h * World.T, oy); c.lineTo(ox + World.T * 0.5, oy + World.T * (0.3 + h)); c.lineTo(ox + World.T * (1 - h), oy + World.T); c.stroke(); }
        if (h > 0.85) { c.fillStyle = st.ember; c.beginPath(); c.arc(ox + 20, oy + 20, 3, 0, TAU); c.fill(); }
        return;
      }
      const nearFloor = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [-1, -1], [1, -1], [-1, 1]].some(([dx, dy]) => World.tileAt(tx + dx, ty + dy) === FLOOR);
      if (!nearFloor) { c.fillStyle = '#040208'; c.fillRect(ox, oy, World.T, World.T); if (hash2(tx, ty) < 0.04) { c.fillStyle = st.ember; c.fillRect(ox + 18, oy + 18, 2, 2); } return; }
      c.fillStyle = st.wall; c.fillRect(ox, oy, World.T, World.T);
      c.fillStyle = 'rgba(0,0,0,0.3)'; for (let k = 0; k < 4; k++) c.fillRect(ox, oy + k * 10, World.T, 2);
      if (World.tileAt(tx, ty + 1) === FLOOR) { c.fillStyle = st.crack; c.fillRect(ox, oy + World.T - 4, World.T, 3); }
      return;
    }
    if (bi.castleStyle === 'ice' && (t === FLOOR || t === GATE)) {
      c.fillStyle = (tx + ty) % 2 ? '#cfe8f8' : '#bcdcf2'; c.fillRect(ox, oy, World.T, World.T);
      c.fillStyle = 'rgba(255,255,255,0.45)'; c.beginPath(); c.moveTo(ox + 4, oy + World.T - 6); c.lineTo(ox + 12, oy + World.T - 6); c.lineTo(ox + World.T - 6, oy + 6); c.lineTo(ox + World.T - 14, oy + 6); c.fill();
      c.strokeStyle = 'rgba(90,150,200,0.35)'; c.lineWidth = 1; c.strokeRect(ox + 0.5, oy + 0.5, World.T - 1, World.T - 1);
      if (hash2(tx, ty) < 0.07) { c.fillStyle = '#ffffff'; star(c, ox + 20, oy + 20, 3, 0, 6); c.fill(); }
      return;
    }
    if (bi.castleStyle === 'ice' && t === WALL) {
      c.fillStyle = '#7aa8d8'; c.fillRect(ox, oy, World.T, World.T);
      c.fillStyle = 'rgba(255,255,255,0.35)'; c.fillRect(ox + 5, oy + 6, 5, 22); c.fillRect(ox + 22, oy + 4, 3, 14);
      c.fillStyle = '#e8f8ff'; c.fillRect(ox, oy, World.T, 3);
      if (World.tileAt(tx, ty + 1) !== WALL) {
        c.fillStyle = '#3a6a9a'; c.fillRect(ox, oy + World.T - 12, World.T, 12);
        c.fillStyle = '#bfeaff'; for (let k = 0; k < 4; k++) { c.beginPath(); c.moveTo(ox + k * 10 + 2, oy + World.T - 12); c.lineTo(ox + k * 10 + 8, oy + World.T - 12); c.lineTo(ox + k * 10 + 5, oy + World.T - 3 - (k % 2) * 4); c.fill(); }
      }
      return;
    }
    if (bi.castleStyle === 'coral' && (t === FLOOR || t === GATE)) { // перламутровый пол цитадели
      const g = c.createLinearGradient(ox, oy, ox + World.T, oy + World.T); g.addColorStop(0, (tx + ty) % 2 ? '#f6d8e4' : '#ecc8d8'); g.addColorStop(1, (tx + ty) % 2 ? '#e8c0d4' : '#dcb4ca');
      c.fillStyle = g; c.fillRect(ox, oy, World.T, World.T);
      c.strokeStyle = 'rgba(200,120,160,0.35)'; c.lineWidth = 1; c.strokeRect(ox + 0.5, oy + 0.5, World.T - 1, World.T - 1);
      if (hash2(tx, ty) < 0.12) { const cx = ox + 20, cy = oy + 22; c.strokeStyle = 'rgba(255,255,255,0.7)'; c.lineWidth = 1.2; for (let r = -6; r <= 6; r += 3) { c.beginPath(); c.moveTo(cx, cy + 4); c.lineTo(cx + r, cy - 5); c.stroke(); } }
      return;
    }
    if (bi.castleStyle === 'coral' && t === WALL) { // стены из коралла с ракушками
      c.fillStyle = '#d0607e'; c.fillRect(ox, oy, World.T, World.T);
      c.fillStyle = '#e8809a'; for (let k = 0; k < 4; k++) { c.beginPath(); c.arc(ox + 6 + hash2(tx * 3 + k, ty) * 28, oy + 6 + hash2(tx, ty * 3 + k) * 22, 4 + hash2(k, tx + ty) * 3, 0, TAU); c.fill(); }
      c.fillStyle = '#ffb4c4'; c.fillRect(ox, oy, World.T, 3);
      if (World.tileAt(tx, ty + 1) !== WALL) {
        c.fillStyle = '#8a2a48'; c.fillRect(ox, oy + World.T - 12, World.T, 12);
        c.fillStyle = '#ffd0dc'; for (let k = 0; k < 3; k++) { c.beginPath(); c.ellipse(ox + 7 + k * 13, oy + World.T - 6, 4, 3, 0, 0, TAU); c.fill(); }
      }
      return;
    }
    if (bi.castleStyle && (t === FLOOR || t === GATE)) {
      const night = bi.castleStyle === 'attic';
      for (let k = 0; k < 4; k++) { c.fillStyle = night ? ((k + tx) % 2 ? '#2a2230' : '#241d2a') : ((k + tx) % 2 ? '#d4a676' : '#c89a6a'); c.fillRect(ox, oy + k * 10, World.T, 9); }
      c.fillStyle = 'rgba(0,0,0,0.3)'; c.fillRect(ox + ((tx * 13 + ty * 7) % 4) * 10, oy, 1.5, World.T);
      if (night && hash2(tx, ty) < 0.08) { c.fillStyle = '#3ff0a0'; c.fillRect(ox + 10 + hash2(ty, tx) * 20, oy + 14, 3, 3); }
      return;
    }
    if (bi.castleStyle && t === WALL) {
      const night = bi.castleStyle === 'attic';
      c.fillStyle = night ? '#3a2a24' : '#8a5a3a'; c.fillRect(ox, oy, World.T, World.T);
      c.fillStyle = 'rgba(0,0,0,0.25)'; for (let k = 0; k < 4; k++) c.fillRect(ox, oy + k * 10, World.T, 2);
      if (World.tileAt(tx, ty + 1) !== WALL) { c.fillStyle = night ? '#1a1210' : '#5a3a20'; c.fillRect(ox, oy + World.T - 12, World.T, 12); c.fillStyle = night ? '#3ff0a0' : '#ffd25a'; c.fillRect(ox, oy + World.T - 13, World.T, 2); }
      return;
    }
    if (bi.mirror && (t === FLOOR || t === GATE)) {
      c.fillStyle = (tx + ty) % 2 ? '#dcdcf2' : '#c8c8e4'; c.fillRect(ox, oy, World.T, World.T);
      c.fillStyle = 'rgba(255,255,255,0.45)'; c.beginPath(); c.moveTo(ox + 4, oy + World.T - 4); c.lineTo(ox + 14, oy + World.T - 4); c.lineTo(ox + World.T - 4, oy + 4); c.lineTo(ox + World.T - 14, oy + 4); c.fill();
      c.strokeStyle = 'rgba(120,120,170,0.35)'; c.lineWidth = 1; c.strokeRect(ox + 0.5, oy + 0.5, World.T - 1, World.T - 1);
      return;
    }
    if (bi.mirror && t === WALL) {
      c.fillStyle = '#9a9abc'; c.fillRect(ox, oy, World.T, World.T);
      c.fillStyle = '#ffffff'; c.fillRect(ox, oy, World.T, 3);
      c.fillStyle = 'rgba(255,255,255,0.35)'; c.fillRect(ox + 6, oy + 8, 4, 20);
      if (World.tileAt(tx, ty + 1) !== WALL) { c.fillStyle = '#5a5a7a'; c.fillRect(ox, oy + World.T - 12, World.T, 12); c.fillStyle = '#bfeaff'; c.fillRect(ox, oy + World.T - 13, World.T, 2); }
      return;
    }
    if (bi.rainbow && t === PATH) {
      for (let k = 0; k < 4; k++) { c.fillStyle = RAINBOW[(tx + ty + k) % 7]; c.fillRect(ox, oy + k * 10, World.T, 10); }
      c.fillStyle = 'rgba(255,255,255,0.35)'; c.fillRect(ox, oy, World.T, World.T);
      return;
    }
    const pal = tilePal(t, b);
    // вода, камни, лава, лёд и дорожки – со скруглёнными краями поверх земли
    const organic = t === PATH || t === WATER || t === LAVA || t === ICE || (t === STONE && !bi.mirror) || (t === ROCK && !bi.furniture && !bi.fence);
    let ex = null;
    if (organic) {
      c.save();
      ex = tileShape(c, ox, oy, tx, ty, sameGroup(t), t === PATH || t === STONE ? 11 : 15);
      c.fillStyle = pal[0]; c.fill(); c.clip();
      if (Woodland.supports(bi) && (t === PATH || t === ROCK)) {
        if (t === PATH) Woodland.path(c, tx, ty, ox, oy, bi, ex);
        else Woodland.rock(c, tx, ty, ox, oy, bi, ex);
        c.restore();
        return;
      }
    } else if (!World.isGround(t)) { c.fillStyle = pal[0]; c.fillRect(ox, oy, World.T, World.T); }
    if (!World.isGround(t) && !(t === ROCK && (bi.furniture || bi.fence))) for (let k = 0; k < 9; k++) {
      const h1 = hash2(tx * 31 + k * 7, ty * 17 + k * 13), h2 = hash2(tx * 11 + k * 29, ty * 41 + k * 3);
      c.fillStyle = pal[1 + (k & 1)];
      if (organic) { c.beginPath(); c.arc(ox + 2 + Math.floor(h1 * 9) * 4, oy + 2 + Math.floor(h2 * 9) * 4, 2.2, 0, TAU); c.fill(); }
      else c.fillRect(ox + Math.floor(h1 * 9) * 4, oy + Math.floor(h2 * 9) * 4, 4, 4);
    }
    const below = World.tileAt(tx, ty + 1), above = World.tileAt(tx, ty - 1);
    const hr = hash2(tx * 7 + 3, ty * 5 + 1);
    if (t === FLOOR || t === GATE) {
      c.strokeStyle = 'rgba(0,0,0,0.25)'; c.lineWidth = 2; c.strokeRect(ox + 1, oy + 1, World.T - 2, World.T - 2);
    } else if (t === WALL) {
      c.fillStyle = 'rgba(0,0,0,0.25)';
      for (let r = 0; r < 4; r++) { c.fillRect(ox, oy + r * 10, World.T, 2); c.fillRect(ox + ((r & 1) ? 6 : 26), oy + r * 10, 2, 10); }
      if (below !== WALL) { c.fillStyle = '#2c2238'; c.fillRect(ox, oy + World.T - 12, World.T, 12); c.fillStyle = '#7a6a94'; c.fillRect(ox, oy, World.T, 3); }
    } else if (t === ROCK && (bi.furniture || bi.fence)) {
      drawFurniture(c, bi, pal, ox, oy, below, above, hr);
    } else if (t === ROCK) {
      c.fillStyle = 'rgba(255,255,255,0.18)'; c.fillRect(ox + 4, oy + 6, 10, 3);
      if (below !== ROCK) { c.fillStyle = shade(pal[0], -0.3); c.fillRect(ox, oy + World.T - 12, World.T, 12); c.fillStyle = 'rgba(0,0,0,0.25)'; c.fillRect(ox, oy + World.T - 4, World.T, 4); }
      if (above !== ROCK) { c.fillStyle = 'rgba(255,255,255,0.3)'; c.fillRect(ox, oy, World.T, 3); }
      if (b === 7 && hr < 0.4) { c.fillStyle = 'rgba(91,227,255,0.6)'; c.fillRect(ox + 14, oy + 10, 4, 10); }
      if (bi.candy) { c.fillStyle = 'rgba(255,111,181,0.7)'; for (let k = -2; k < 4; k++) { c.beginPath(); c.moveTo(ox + k * 14, oy + World.T); c.lineTo(ox + k * 14 + 7, oy + World.T); c.lineTo(ox + k * 14 + 7 + World.T, oy); c.lineTo(ox + k * 14 + World.T, oy); c.fill(); } }
      if (bi.mirror) { c.fillStyle = 'rgba(255,255,255,0.6)'; c.beginPath(); c.moveTo(ox + 6, oy + 26); c.lineTo(ox + 12, oy + 26); c.lineTo(ox + 26, oy + 6); c.lineTo(ox + 20, oy + 6); c.fill(); }
      if (b === 9 && hr < 0.5) { c.fillStyle = '#ff3ea5'; c.fillRect(ox + 4, oy + 12, 30, 3); c.fillStyle = '#3ff0ff'; c.fillRect(ox + 8, oy + 16, 26, 2); }
      if (b === 12) { c.fillStyle = ['#c0392b', '#2980b9', '#f1c40f'][Math.floor(hr * 3)]; c.fillRect(ox + 8 + hr * 14, oy + 10, 8, 5); }
      if (neon && hr < 0.5) { c.fillStyle = '#ff3ea5'; c.fillRect(ox + 6, oy + 14, 28, 2); }
    } else if (t === WATER) {
      c.fillStyle = 'rgba(255,255,255,0.35)';
      if (hr < 0.5) c.fillRect(ox + 8 + Math.floor(hr * 30), oy + 14, 10, 2);
      if (above !== WATER) { c.fillStyle = 'rgba(0,30,60,0.35)'; c.fillRect(ox, oy, World.T, 6); }
      if (b === 11) { c.fillStyle = '#ffffff'; c.fillRect(ox + Math.floor(hr * 30), oy + Math.floor(hash2(ty, tx) * 30), 2, 2); c.fillRect(ox + Math.floor(hash2(tx, 7) * 34), oy + Math.floor(hash2(9, ty) * 34), 1, 1); }
      if (b === 12 && hr < 0.6) { c.fillStyle = 'rgba(220,255,180,0.8)'; c.beginPath(); c.arc(ox + 8 + hr * 24, oy + 12 + hr * 14, 3, 0, TAU); c.fill(); }
      if (b === 9) { c.fillStyle = 'rgba(63,240,160,0.55)'; c.fillRect(ox + 6 + Math.floor(hr * 20), oy + 8, 2, 6); c.fillRect(ox + 20, oy + 22 + Math.floor(hr * 8), 5, 2); }
    } else if (t === LAVA) {
      c.fillStyle = '#ffd23a';
      for (let k = 0; k < 3; k++) {
        const hh = hash2(tx * 3 + k, ty * 9 + k);
        c.fillRect(ox + Math.floor(hh * 8) * 4, oy + Math.floor(hash2(ty + k, tx * 2) * 8) * 4, 6, 4);
      }
      if (above !== LAVA) { c.fillStyle = 'rgba(60,0,0,0.4)'; c.fillRect(ox, oy, World.T, 6); }
    } else if (t === ICE) {
      c.strokeStyle = 'rgba(255,255,255,0.7)'; c.lineWidth = 2;
      c.beginPath(); c.moveTo(ox + 6 + hr * 10, oy + 30); c.lineTo(ox + 22 + hr * 10, oy + 14); c.stroke();
    } else if (World.isGround(t)) {
      if (!Woodland.supports(bi) || bi.deco === 'reeds') drawDeco(c, bi.deco, tx, ty, ox, oy);
      if (above === ROCK || above === WALL) { c.fillStyle = 'rgba(0,0,0,0.3)'; c.fillRect(ox, oy, World.T, 7); }
    }
    if (organic) {
      // кромка: пена у воды, тень у дорожки
      const wet = t === WATER || t === LAVA || t === ICE;
      c.fillStyle = wet ? 'rgba(255,255,255,0.22)' : t === ROCK ? 'rgba(0,0,0,0.12)' : 'rgba(0,0,0,0.1)';
      const bw = wet ? 3 : 2;
      if (!ex.n) c.fillRect(ox, oy, World.T, bw); if (!ex.s) c.fillRect(ox, oy + World.T - bw, World.T, bw);
      if (!ex.w) c.fillRect(ox, oy, bw, World.T); if (!ex.e) c.fillRect(ox + World.T - bw, oy, bw, World.T);
      c.restore();
    }
  }
  // ---- поверхность: земля в два слоя (основа + мягкие пятна), формы со скруглёнными краями ----
  function drawGroundBase(c, tx, ty, ox, oy) {
    const i = ty * World.MW + tx, t = World.tiles[i], bi = BIOMES[World.isGround(t) ? t : World.biomeMap[i]];
    if (t === FLOOR || t === WALL || t === GATE) return;
    if (!bi.floor && Woodland.supports(bi)) {
      Woodland.ground(c, tx, ty, ox, oy, bi);
      return;
    }
    const pal = bi.ground;
    c.fillStyle = pal[0]; c.fillRect(ox, oy, World.T, World.T);
    if (bi.floor) { drawFloor(c, bi.floor, pal, tx, ty, ox, oy); return; }
    for (let k = 0; k < 14; k++) {
      const h1 = hash2(tx * 31 + k * 7, ty * 17 + k * 13), h2 = hash2(tx * 11 + k * 29, ty * 41 + k * 3), s = 2 + Math.floor(hash2(tx + k * 5, ty * 3 + k) * 3);
      c.fillStyle = pal[1 + (k & 1)];
      c.fillRect(ox + Math.floor(h1 * 19) * 2, oy + Math.floor(h2 * 19) * 2, s, s);
    }
  }
  function drawGroundDetail(c, tx, ty, ox, oy) {
    if (!World.inMap(tx, ty)) return;
    const i = ty * World.MW + tx, t = World.tiles[i], bi = BIOMES[World.isGround(t) ? t : World.biomeMap[i]];
    if (t === FLOOR || t === WALL || t === GATE || bi.floor || Woodland.supports(bi)) return;
    const pal = bi.ground, h1 = hash2(tx * 3 + 11, ty * 7 + 5), h2 = hash2(tx * 13 + 1, ty * 5 + 3), h3 = hash2(tx + 17, ty * 19 + 2);
    c.globalAlpha = 0.45;
    c.fillStyle = h1 < 0.5 ? pal[1] : pal[2];
    c.beginPath(); c.ellipse(ox + h2 * World.T, oy + h3 * World.T, 9 + h1 * 13, 6 + h3 * 9, h2 * 3, 0, TAU); c.fill();
    if (h3 > 0.55) { c.fillStyle = shade(pal[0], h2 > 0.5 ? 0.1 : -0.1); c.beginPath(); c.arc(ox + h1 * World.T, oy + h2 * World.T, 7 + h3 * 9, 0, TAU); c.fill(); }
    c.globalAlpha = 1;
    if (bi.deco === 'grass' || bi.deco === 'flowers' || bi.deco === 'reeds' || bi.deco === 'glitch' || bi.deco === 'leaves') {
      c.strokeStyle = shade(pal[0], -0.28); c.lineWidth = 1.5;
      for (let k = 0; k < 3; k++) {
        const x = ox + hash2(tx * 7 + k, ty * 3 + 1) * World.T, y = oy + hash2(ty * 7 + k, tx * 5 + 2) * World.T;
        c.beginPath(); c.moveTo(x, y + 4); c.lineTo(x - 2.5, y - 2); c.moveTo(x, y + 4); c.lineTo(x + 2, y - 3); c.stroke();
      }
    }
  }
  const sameGroup = t => (t === PATH || t === STONE) ? (u => u === PATH || u === STONE || u === GATE || u === FLOOR)
    : t === ROCK ? (u => u === ROCK || u === WALL) : (u => u === t);
  function tileShape(c, ox, oy, tx, ty, test, r) {
    const n = test(World.tileAt(tx, ty - 1)), s = test(World.tileAt(tx, ty + 1)), w = test(World.tileAt(tx - 1, ty)), e = test(World.tileAt(tx + 1, ty));
    const tl = !n && !w ? r : 0, tr = !n && !e ? r : 0, br = !s && !e ? r : 0, bl = !s && !w ? r : 0;
    c.beginPath();
    c.moveTo(ox + tl, oy);
    c.lineTo(ox + World.T - tr, oy); if (tr) c.quadraticCurveTo(ox + World.T, oy, ox + World.T, oy + tr);
    c.lineTo(ox + World.T, oy + World.T - br); if (br) c.quadraticCurveTo(ox + World.T, oy + World.T, ox + World.T - br, oy + World.T);
    c.lineTo(ox + bl, oy + World.T); if (bl) c.quadraticCurveTo(ox, oy + World.T, ox, oy + World.T - bl);
    c.lineTo(ox, oy + tl); if (tl) c.quadraticCurveTo(ox, oy, ox + tl, oy);
    c.closePath();
    return { n, s, w, e };
  }

  function drawFloor(c, kind, pal, tx, ty, ox, oy) {
    c.save(); c.beginPath(); c.rect(ox, oy, World.T, World.T); c.clip();
    switch (kind) {
      case 'parquet':
        if ((tx + ty) % 2) { c.fillStyle = pal[1]; c.fillRect(ox, oy, World.T, World.T / 2 - 1); c.fillStyle = pal[2]; c.fillRect(ox, oy + World.T / 2, World.T, World.T / 2 - 1); }
        else { c.fillStyle = pal[2]; c.fillRect(ox, oy, World.T / 2 - 1, World.T); c.fillStyle = pal[1]; c.fillRect(ox + World.T / 2, oy, World.T / 2 - 1, World.T); }
        c.fillStyle = 'rgba(0,0,0,0.18)'; c.fillRect(ox, oy + World.T - 1, World.T, 1); c.fillRect(ox + World.T - 1, oy, 1, World.T);
        break;
      case 'boards':
        for (let k = 0; k < 4; k++) { c.fillStyle = pal[(k + tx) % 2 ? 1 : 2]; c.fillRect(ox, oy + k * 10, World.T, 9); }
        c.fillStyle = 'rgba(0,0,0,0.25)'; c.fillRect(ox + ((tx * 13 + ty * 7) % 4) * 10, oy, 1.5, World.T);
        break;
      case 'checker':
        c.fillStyle = (tx + ty) % 2 ? pal[1] : shade(pal[0], -0.12); c.fillRect(ox, oy, World.T, World.T);
        c.fillStyle = 'rgba(255,255,255,0.12)'; c.fillRect(ox + 2, oy + 2, World.T - 4, 3);
        break;
      case 'tiles':
        for (let k = 0; k < 2; k++) for (let m = 0; m < 2; m++) { c.fillStyle = (k + m + tx + ty) % 2 ? pal[1] : pal[2]; c.fillRect(ox + k * 20 + 1, oy + m * 20 + 1, 18, 18); }
        break;
      case 'carpet':
        for (let k = 0; k < 6; k++) { c.fillStyle = pal[1 + (k & 1)]; c.fillRect(ox + Math.floor(hash2(tx * 5 + k, ty * 3 + k) * 18) * 2, oy + Math.floor(hash2(ty + k, tx * 2 + k) * 18) * 2, 3, 3); }
        if ((tx * 3 + ty * 5) % 7 === 0) { c.fillStyle = shade(pal[0], 0.15); c.beginPath(); c.arc(ox + 20, oy + 20, 6, 0, TAU); c.fill(); }
        break;
      case 'paving': {
        const off = ty % 2 ? 10 : 0;
        for (let k = -1; k < 3; k++) { c.fillStyle = pal[(k + tx + ty + 8) % 2 ? 1 : 2]; c.fillRect(ox + k * 20 + off + 1, oy + 1, 18, 18); c.fillRect(ox + k * 20 + 11 - off, oy + 21, 18, 18); }
        break;
      }
    }
    c.restore();
  }
  function drawFurniture(c, bi, pal, ox, oy, below, above, hr) {
    if (bi.fence) {
      c.fillStyle = shade(pal[0], -0.25); c.fillRect(ox, oy, World.T, World.T);
      for (let k = 0; k < 4; k++) { c.fillStyle = pal[1]; c.fillRect(ox + k * 10 + 1, oy + 4, 8, World.T - 4); c.beginPath(); c.moveTo(ox + k * 10 + 1, oy + 4); c.lineTo(ox + k * 10 + 5, oy); c.lineTo(ox + k * 10 + 9, oy + 4); c.fill(); }
      c.fillStyle = 'rgba(0,0,0,0.25)'; c.fillRect(ox, oy + 12, World.T, 3); c.fillRect(ox, oy + 28, World.T, 3);
      return;
    }
    if (bi.toyRocks) {
      const col = pal[Math.floor(hr * 3)];
      c.fillStyle = col; c.fillRect(ox + 1, oy + 1, World.T - 2, World.T - 2); c.strokeStyle = shade(col, -0.35); c.lineWidth = 2; c.strokeRect(ox + 2, oy + 2, World.T - 4, World.T - 4);
      c.fillStyle = 'rgba(255,255,255,0.85)'; c.font = 'bold 18px Krilessa Icons, sans-serif'; c.textAlign = 'center'; c.fillText('АБВГДЕЖЗ'[Math.floor(hr * 8)], ox + World.T / 2, oy + World.T / 2 + 6);
      return;
    }
    if (above !== ROCK) { c.fillStyle = shade(pal[0], 0.25); c.fillRect(ox, oy, World.T, 6); }
    c.strokeStyle = 'rgba(0,0,0,0.35)'; c.lineWidth = 1.5; c.strokeRect(ox + 4, oy + 9, World.T - 8, 12); c.strokeRect(ox + 4, oy + 24, World.T - 8, 12);
    c.fillStyle = '#d8c080'; c.fillRect(ox + World.T / 2 - 3, oy + 14, 6, 2); c.fillRect(ox + World.T / 2 - 3, oy + 29, 6, 2);
    if (below !== ROCK) { c.fillStyle = shade(pal[0], -0.35); c.fillRect(ox, oy + World.T - 6, World.T, 6); }
  }
  function drawDeco(c, deco, tx, ty, ox, oy) {
    const d = hash2(tx * 13 + 5, ty * 19 + 7), e = hash2(tx * 3 + 1, ty * 7 + 2);
    const px = ox + 6 + Math.floor(e * 24), py = oy + 8 + Math.floor((d * 997) % 22);
    switch (deco) {
      case 'grass':
        if (d < 0.12) { c.fillStyle = ['#ff8fb1', '#ffe066', '#b8a6ff'][Math.floor(d * 1000) % 3]; c.fillRect(px, py, 4, 4); }
        else if (d < 0.35) { c.fillStyle = '#2f5a35'; c.fillRect(px, py, 2, 6); c.fillRect(px + 4, py + 2, 2, 4); }
        break;
      case 'reeds':
        if (d < 0.18) { c.fillStyle = '#5c6e2e'; c.fillRect(px, oy + 8, 2, 14); c.fillStyle = '#7a4a2a'; c.fillRect(px - 1, oy + 6, 4, 6); }
        break;
      case 'snow':
        if (d < 0.15) { c.fillStyle = '#ffffff'; c.fillRect(px, py, 3, 3); }
        break;
      case 'bones':
        if (d < 0.08) { c.fillStyle = '#b26bff'; c.fillRect(px, oy + 16, 6, 4); c.fillStyle = '#d9d0e6'; c.fillRect(px + 2, oy + 20, 2, 4); }
        else if (d < 0.14) { c.fillStyle = '#d8d0c0'; c.fillRect(ox + 10, oy + 20, 10, 3); c.fillRect(ox + 9, oy + 19, 3, 5); c.fillRect(ox + 19, oy + 19, 3, 5); }
        break;
      case 'flowers':
        if (d < 0.35) {
          const col = ['#ff6fb5', '#ffe04a', '#ffffff', '#b18cff', '#ff8a3a'][Math.floor(d * 1000) % 5];
          c.fillStyle = col; c.fillRect(px - 2, py, 2, 2); c.fillRect(px + 2, py, 2, 2); c.fillRect(px, py - 2, 2, 2); c.fillRect(px, py + 2, 2, 2);
          c.fillStyle = '#ffd23a'; c.fillRect(px, py, 2, 2);
        } else if (d < 0.5) { c.fillStyle = '#5aa04a'; c.fillRect(px, py, 2, 6); }
        break;
      case 'desert':
        if (d < 0.1) { c.fillStyle = '#b89a5a'; c.fillRect(px, py, 6, 4); }
        else if (d < 0.13) { c.fillStyle = '#f0e8d8'; c.fillRect(px, py, 8, 6); c.fillStyle = '#3a2a1a'; c.fillRect(px + 1, py + 2, 2, 2); c.fillRect(px + 5, py + 2, 2, 2); }
        else if (d < 0.3) { c.fillStyle = 'rgba(160,120,60,0.35)'; c.fillRect(px, py, 12, 2); }
        break;
      case 'embers':
        if (d < 0.14) { c.fillStyle = '#ff8a2a'; c.fillRect(px, py, 3, 3); c.fillStyle = 'rgba(255,138,42,0.3)'; c.fillRect(px - 2, py - 2, 7, 7); }
        else if (d < 0.3) { c.fillStyle = '#1e1414'; c.fillRect(px, py, 10, 2); c.fillRect(px + 8, py, 2, 6); }
        break;
      case 'gems':
        if (d < 0.14) { c.fillStyle = ['#5be3ff', '#c77dff', '#ff6fb5'][Math.floor(d * 1000) % 3]; c.beginPath(); c.moveTo(px, py - 4); c.lineTo(px + 3, py); c.lineTo(px, py + 4); c.lineTo(px - 3, py); c.fill(); }
        break;
      case 'glitch':
        if (d < 0.16) { c.fillStyle = 'rgba(255,62,165,0.6)'; c.fillRect(px, py, 6, 2); c.fillStyle = 'rgba(63,240,255,0.6)'; c.fillRect(px + 2, py + 2, 6, 2); }
        else if (d < 0.26) { c.fillStyle = '#3ff0a0'; c.fillRect(px, py, 3, 3); }
        break;
      case 'sprinkles':
        if (d < 0.4) { for (let k = 0; k < 3; k++) { c.fillStyle = RAINBOW[(Math.floor(d * 100) + k) % 7]; c.fillRect(px + k * 5 - 5, py + (k % 2) * 6, 4, 2); } }
        break;
      case 'sky':
        if (d < 0.08) { c.fillStyle = '#ffe04a'; star(c, px, py, 3); c.fill(); }
        else if (d < 0.25) { c.fillStyle = 'rgba(255,255,255,0.8)'; c.beginPath(); c.arc(px, py, 5, 0, TAU); c.arc(px + 6, py, 4, 0, TAU); c.fill(); }
        break;
      case 'trash':
        if (d < 0.1) { c.fillStyle = '#c0392b'; c.fillRect(px, py, 4, 7); c.fillStyle = '#ddd'; c.fillRect(px, py, 4, 2); }
        else if (d < 0.18) { c.fillStyle = 'rgba(46,204,113,0.7)'; c.fillRect(px, py, 3, 8); }
        else if (d < 0.26) { c.fillStyle = 'rgba(120,255,80,0.25)'; c.beginPath(); c.arc(px, py, 6, 0, TAU); c.fill(); }
        break;
      case 'mirror':
        if (d < 0.1) { c.fillStyle = '#ffffff'; star(c, px, py, 3, 0, 4); c.fill(); }
        else if (d < 0.2) { c.fillStyle = 'rgba(255,255,255,0.5)'; c.fillRect(px, py, 10, 1); }
        break;
      case 'toys':
        if (d < 0.05) { c.fillStyle = ['#ff6a6a', '#6ac8ff', '#ffd25a'][Math.floor(d * 1000) % 3]; c.beginPath(); c.arc(px, py, 3, 0, TAU); c.fill(); }
        else if (d < 0.08) { c.fillStyle = '#ffffff'; c.fillRect(px, py, 4, 4); }
        break;
      case 'dust':
        if (d < 0.12) { c.fillStyle = 'rgba(200,200,220,0.25)'; c.beginPath(); c.arc(px, py, 4, 0, TAU); c.fill(); }
        break;
      case 'crumbs':
        if (d < 0.14) { c.fillStyle = '#c8a060'; c.fillRect(px, py, 2, 2); c.fillRect(px + 4, py + 2, 2, 2); }
        break;
      case 'pixelnight':
        if (d < 0.06) { c.fillStyle = 'rgba(63,240,160,0.5)'; c.fillRect(px, py, 3, 3); }
        else if (d < 0.09) { c.fillStyle = 'rgba(255,62,165,0.4)'; c.fillRect(px, py, 3, 3); }
        break;
      case 'drops':
        if (d < 0.12) { c.fillStyle = 'rgba(160,220,255,0.45)'; c.beginPath(); c.ellipse(px, py, 3, 2, 0, 0, TAU); c.fill(); }
        break;
      case 'leaves':
        if (d < 0.12) { c.fillStyle = ['#d88a3a', '#c8a03a', '#a05a2a'][Math.floor(d * 1000) % 3]; c.beginPath(); c.ellipse(px, py, 4, 2, d * 20, 0, TAU); c.fill(); }
        break;
      case 'neon':
        if ((tx + ty) % 4 === 0) { c.fillStyle = 'rgba(63,240,255,0.18)'; c.fillRect(ox, oy, World.T, 1); }
        if ((tx * 3 + ty) % 5 === 0) { c.fillStyle = 'rgba(255,62,165,0.18)'; c.fillRect(ox, oy, 1, World.T); }
        if (d < 0.05) { c.fillStyle = '#ffe04a'; star(c, px, py, 3); c.fill(); }
        break;
    }
  }
  // Кусок карты рисуется в три прохода. Заранее (до того как он попадёт на экран) его строим
  // понемногу – по несколько миллисекунд за кадр, поэтому при беге и в меню нет рывков.
  let chunkJob = null;
  const CH2 = CHUNK * CHUNK, CHB = (CHUNK + 2) * (CHUNK + 2);
  // ---- края карты: у каждой главы свои (лес, занавес, зеркала, обои, ели) ----
  const EDGE_BY_CH = { 1: 'forest', 2: 'curtain', 3: 'mirror', 4: 'nightwall', 5: 'daywall', 6: 'firs', 7: 'reef' };
  const EDGE_MINI = { forest: '#1d4a22', curtain: '#7a0a1e', mirror: '#b8c8e8', nightwall: '#262c52', daywall: '#e8d4ae', firs: '#2a5a48', reef: '#1a4a5a' };
  const edgeStyle = () => EDGE_BY_CH[World.CHN] || null;
  // клетка рамки: 0 – внутреннее кольцо (у самой карты), 1 – внешнее; сторона – куда смотрит рамка
  function edgeInfo(tx, ty) {
    if (tx < 0 || ty < 0 || tx >= World.MW || ty >= World.PLAY_H) return null;
    const dl = tx, dr = World.MW - 1 - tx, dt = ty, db = World.PLAY_H - 1 - ty, m = Math.min(dl, dr, dt, db);
    if (m > 1) return null;
    const side = dt === m ? 't' : db === m ? 'b' : dl === m ? 'l' : 'r';
    return { depth: 1 - m, side };
  }
  const FOREST_GREENS = ['#245c28', '#2b6a2e', '#1f5223', '#2f7432'];
  function drawEdge(c, st, tx, ty, ox, oy) {
    const e = edgeInfo(tx, ty); if (!e) return;
    const d = e.depth, horiz = e.side === 't' || e.side === 'b';
    // внутренняя граница (сторона клетки, что смотрит в карту)
    const inner = d === 0;
    const h = k => hash2(tx * 13 + k * 7, ty * 29 + k * 11);
    if (st === 'forest') { // густой лес: кроны внахлёст, к краю темнее
      c.fillStyle = d ? '#10291a' : '#163a1e'; c.fillRect(ox, oy, World.T, World.T);
      for (let k = 0; k < 3; k++) {
        const cx = ox + 20 + (h(k) - 0.5) * 26, cy = oy + 20 + (h(k + 5) - 0.5) * 26, r = 15 + h(k + 9) * 10;
        const col = FOREST_GREENS[Math.floor(h(k + 13) * 4)], dk = -0.28 * d;
        c.fillStyle = 'rgba(0,0,0,0.3)'; c.beginPath(); c.arc(cx + 3, cy + 5, r, 0, TAU); c.fill();
        c.fillStyle = shade(col, dk); c.beginPath(); c.arc(cx, cy, r, 0, TAU); c.fill();
        c.fillStyle = shade('#3f8f3e', dk); c.beginPath(); c.arc(cx - r * 0.3, cy - r * 0.32, r * 0.55, 0, TAU); c.fill();
        c.fillStyle = shade('#5bb055', dk * 1.5); c.beginPath(); c.arc(cx - r * 0.42, cy - r * 0.45, r * 0.2, 0, TAU); c.fill();
      }
      return;
    }
    if (st === 'firs') { // заснеженные ели, у карты – сугроб
      c.fillStyle = d ? '#c8dcec' : '#e2eef8'; c.fillRect(ox, oy, World.T, World.T);
      for (let k = 0; k < 2; k++) {
        const cx = ox + 10 + k * 20 + (h(k) - 0.5) * 10, by = oy + 34 + (h(k + 3) - 0.5) * 10, w = 13 + h(k + 6) * 6, dk = -0.3 * d;
        c.fillStyle = 'rgba(40,70,110,0.25)'; c.beginPath(); c.ellipse(cx + 4, by + 2, w * 0.9, 5, 0, 0, TAU); c.fill();
        for (let tier = 0; tier < 3; tier++) {
          const ty0 = by - tier * 11, ww = w * (1 - tier * 0.25);
          c.fillStyle = shade('#1e4a3a', dk + tier * 0.05); c.beginPath(); c.moveTo(cx - ww, ty0); c.lineTo(cx + ww, ty0); c.lineTo(cx, ty0 - 17); c.closePath(); c.fill();
          c.fillStyle = '#f4faff'; c.beginPath(); c.moveTo(cx - ww * 0.55, ty0 - 7); c.lineTo(cx + ww * 0.4, ty0 - 8); c.lineTo(cx, ty0 - 17); c.closePath(); c.fill();
        }
      }
      if (inner) { // сугроб вдоль края карты
        c.fillStyle = '#f6fbff';
        for (let k = 0; k < 3; k++) {
          const along = 6 + k * 14 + h(k + 20) * 6, r = 8 + h(k + 23) * 5;
          const [px, py] = e.side === 't' ? [ox + along, oy + World.T] : e.side === 'b' ? [ox + along, oy] : e.side === 'l' ? [ox + World.T, oy + along] : [ox, oy + along];
          c.beginPath(); c.arc(px, py, r, 0, TAU); c.fill();
        }
      }
      return;
    }
    if (st === 'reef') { // подводная скала: кораллы, водоросли, пузыри
      c.fillStyle = d ? '#0e2a38' : '#16384a'; c.fillRect(ox, oy, World.T, World.T);
      for (let k = 0; k < 3; k++) { const cx = ox + 20 + (h(k) - 0.5) * 26, cy = oy + 20 + (h(k + 4) - 0.5) * 26, r = 9 + h(k + 8) * 8;
        c.fillStyle = shade(['#1e4a5a', '#24566a', '#1a4050'][k], -0.25 * d); c.beginPath(); c.arc(cx, cy, r, 0, TAU); c.fill(); }
      if (h(20) < 0.45) { const x = ox + 8 + h(21) * 24, y = oy + 34; const col = ['#ff7a96', '#ffb04a', '#c8a0ff'][Math.floor(h(22) * 3)];
        c.strokeStyle = shade(col, -0.2 * d); c.lineWidth = 2.5; c.lineCap = 'round';
        c.beginPath(); c.moveTo(x, y); c.lineTo(x - 4, y - 10); c.lineTo(x - 7, y - 16); c.moveTo(x - 4, y - 10); c.lineTo(x + 2, y - 17); c.moveTo(x, y); c.lineTo(x + 5, y - 9); c.stroke(); c.lineCap = 'butt'; }
      else if (h(23) < 0.5) { const x = ox + 10 + h(24) * 20; c.strokeStyle = shade('#3a8a3a', -0.3 * d); c.lineWidth = 3; c.beginPath(); c.moveTo(x, oy + 38); c.bezierCurveTo(x - 6, oy + 26, x + 6, oy + 14, x, oy + 2); c.stroke(); }
      if (inner && h(30) < 0.3) { c.fillStyle = 'rgba(220,250,255,0.55)'; for (let k = 0; k < 3; k++) { c.beginPath(); c.arc(ox + 12 + h(31 + k) * 16, oy + 8 + k * 10, 1.5 + k * 0.7, 0, TAU); c.fill(); } }
      return;
    }
    if (st === 'curtain') { // бархатный занавес с золотой бахромой – Кринж-Цитадель как сцена
      const along0 = horiz ? tx * World.T : ty * World.T;
      for (let i = 0; i < World.T; i += 4) {
        const v = (Math.sin((along0 + i) * TAU / 22) + 1) / 2, dk = -0.25 * d;
        c.fillStyle = shade(v > 0.66 ? '#c8203c' : v > 0.33 ? '#9a1430' : '#6a0a1e', dk);
        if (horiz) c.fillRect(ox + i, oy, 4, World.T); else c.fillRect(ox, oy + i, World.T, 4);
      }
      if (inner) {
        c.fillStyle = '#ffcf4a';
        const [rx, ry, rw, rh] = e.side === 't' ? [ox, oy + World.T - 6, World.T, 4] : e.side === 'b' ? [ox, oy + 2, World.T, 4] : e.side === 'l' ? [ox + World.T - 6, oy, 4, World.T] : [ox + 2, oy, 4, World.T];
        c.fillRect(rx, ry, rw, rh);
        c.fillStyle = '#e8a82a';
        for (let i = 4; i < World.T; i += 8) { // кисточки
          if (e.side === 't') c.fillRect(ox + i, oy + World.T - 3, 3, 6); else if (e.side === 'b') c.fillRect(ox + i, oy - 2, 3, 5);
          else if (e.side === 'l') c.fillRect(ox + World.T - 3, oy + i, 6, 3); else c.fillRect(ox - 2, oy + i, 5, 3);
        }
      }
      if (h(31) < 0.18) { c.fillStyle = 'rgba(255,240,180,0.9)'; star(c, ox + 8 + h(32) * 24, oy + 8 + h(33) * 24, 3, 0, 4); c.fill(); }
      return;
    }
    if (st === 'mirror') { // стена зеркал в золотых рамах
      const g = c.createLinearGradient(ox, oy, ox + World.T, oy + World.T);
      g.addColorStop(0, d ? '#8a9cc4' : '#c8d8f4'); g.addColorStop(0.5, d ? '#a8b8dc' : '#eef4ff'); g.addColorStop(1, d ? '#7a8cb8' : '#b8c8ea');
      c.fillStyle = g; c.fillRect(ox, oy, World.T, World.T);
      c.fillStyle = 'rgba(255,170,210,0.18)'; c.fillRect(ox + 4, oy + 22, World.T - 8, 12);
      c.fillStyle = 'rgba(255,255,255,0.7)'; c.beginPath(); c.moveTo(ox + 6, oy + 30); c.lineTo(ox + 11, oy + 30); c.lineTo(ox + 30, oy + 9); c.lineTo(ox + 25, oy + 9); c.fill();
      c.fillStyle = 'rgba(255,255,255,0.45)'; c.fillRect(ox + 26 + h(1) * 6, oy + 14, 2, 14);
      c.strokeStyle = d ? '#b8902a' : '#e8c050'; c.lineWidth = 3; c.strokeRect(ox + 1.5, oy + 1.5, World.T - 3, World.T - 3);
      if (inner) {
        c.fillStyle = '#ffd25a';
        if (e.side === 't') c.fillRect(ox, oy + World.T - 5, World.T, 5); else if (e.side === 'b') c.fillRect(ox, oy, World.T, 5);
        else if (e.side === 'l') c.fillRect(ox + World.T - 5, oy, 5, World.T); else c.fillRect(ox, oy, 5, World.T);
      }
      return;
    }
    if (st === 'nightwall' || st === 'daywall') { // стены дома: обои и плинтус
      const night = st === 'nightwall';
      c.fillStyle = night ? (d ? '#161a34' : '#1e2446') : (d ? '#e2cfa6' : '#f2e2c0'); c.fillRect(ox, oy, World.T, World.T);
      c.fillStyle = night ? 'rgba(120,140,220,0.18)' : 'rgba(210,120,120,0.22)';
      for (let i = 4; i < World.T; i += 13) { if (horiz) c.fillRect(ox + i, oy, 5, World.T); else c.fillRect(ox, oy + i, World.T, 5); }
      c.fillStyle = night ? 'rgba(200,210,255,0.35)' : 'rgba(120,170,110,0.5)';
      for (let k = 0; k < 2; k++) { c.beginPath(); c.arc(ox + 10 + k * 20, oy + 10 + h(k) * 20, night ? 1.5 : 2.4, 0, TAU); c.fill(); }
      if (night && h(40) < 0.12) { // глитч в обоях
        c.fillStyle = '#ff3ea5'; c.fillRect(ox + h(41) * 26, oy + h(42) * 26, 10, 4);
        c.fillStyle = '#3ff0ff'; c.fillRect(ox + h(43) * 26, oy + h(44) * 26, 7, 3);
      }
      if (inner) { // плинтус
        const bc = night ? '#3a4070' : '#8a5a32', hl = night ? '#5a62a0' : '#b07a48';
        const [rx, ry, rw, rh, hx, hy, hw, hh] = e.side === 't' ? [ox, oy + World.T - 8, World.T, 8, ox, oy + World.T - 8, World.T, 2] : e.side === 'b' ? [ox, oy, World.T, 8, ox, oy + 6, World.T, 2]
          : e.side === 'l' ? [ox + World.T - 8, oy, 8, World.T, ox + World.T - 8, oy, 2, World.T] : [ox, oy, 8, World.T, ox + 6, oy, 2, World.T];
        c.fillStyle = bc; c.fillRect(rx, ry, rw, rh); c.fillStyle = hl; c.fillRect(hx, hy, hw, hh);
        if (!night && e.side === 't' && h(50) < 0.08) { // розетка
          c.fillStyle = '#fafafa'; c.fillRect(ox + 14, oy + 12, 12, 14); c.fillStyle = '#555'; c.fillRect(ox + 17, oy + 17, 2, 4); c.fillRect(ox + 21, oy + 17, 2, 4);
        }
      }
    }
  }
  function newChunkJob(cx, cy) {
    const cv = makeCanvas(CHPX, CHPX);
    return { key: cx + ',' + cy, cx, cy, cv, c: cv.getContext('2d'), pass: 0, i: 0 };
  }
  function runChunkJob(j, budgetMs) {
    const t0 = budgetMs === Infinity ? 0 : performance.now(), c = j.c, bx = j.cx * CHUNK, by = j.cy * CHUNK;
    const est = edgeStyle();
    while (j.pass < 4) {
      if (j.pass === 0) {
        const tx = j.i % CHUNK, ty = (j.i / CHUNK) | 0;
        if (World.inMap(bx + tx, by + ty)) drawGroundBase(c, bx + tx, by + ty, tx * World.T, ty * World.T);
        if (++j.i >= CH2) { j.pass = 1; j.i = 0; }
      } else if (j.pass === 1) {
        // мягкие пятна заходят на соседние клетки, поэтому рисуем и рамку вокруг куска – без швов
        const tx = (j.i % (CHUNK + 2)) - 1, ty = ((j.i / (CHUNK + 2)) | 0) - 1;
        drawGroundDetail(c, bx + tx, by + ty, tx * World.T, ty * World.T);
        if (++j.i >= CHB) { j.pass = 2; j.i = 0; }
      } else if (j.pass === 2) {
        const tx = j.i % CHUNK, ty = (j.i / CHUNK) | 0;
        if (World.inMap(bx + tx, by + ty)) drawTile(c, bx + tx, by + ty, tx * World.T, ty * World.T);
        if (++j.i >= CH2) { j.pass = 3; j.i = 0; }
      } else {
        // края карты: кроны и сугробы заходят на соседние клетки – рисуем и рамку вокруг куска
        if (!est || (bx > 2 && by > 2 && bx + CHUNK < World.MW - 3 && by + CHUNK < World.PLAY_H - 3)) { j.pass = 4; break; }
        const tx = (j.i % (CHUNK + 2)) - 1, ty = ((j.i / (CHUNK + 2)) | 0) - 1;
        drawEdge(c, est, bx + tx, by + ty, tx * World.T, ty * World.T);
        if (++j.i >= CHB) j.pass = 4;
      }
      if (budgetMs !== Infinity && (j.i & 7) === 0 && performance.now() - t0 > budgetMs) return false;
    }
    paperWash(j.cv);
    chunkCache.set(j.key, j.cv);
    if (chunkCache.size > 42) chunkCache.delete(chunkCache.keys().next().value);
    return true;
  }
  // 1.0: земля и деревья – светлая акварель на бумаге (смешиваем с цветом бумаги один раз при запекании)
  let paperOn = false; const PAPER_COL = '#f3e4c4';
  function paperWash(cv, a) {
    if (!paperOn) return; const c = cv.getContext('2d');
    c.save(); c.setTransform(1, 0, 0, 1, 0, 0); c.globalCompositeOperation = 'source-atop'; c.globalAlpha = a || G.paperMix || 0.22; c.fillStyle = PAPER_COL; c.fillRect(0, 0, cv.width, cv.height); c.restore();
  }
  // палитры биомов светлеют до «акварели»: оттенок тот же, светлее и мягче
  function paperCol(hex, kind) {
    const m = /^#([0-9a-f]{6})$/i.exec(hex); if (!m) return hex;
    const n = parseInt(m[1], 16); let r = (n >> 16) / 255, g = ((n >> 8) & 255) / 255, b = (n & 255) / 255;
    const mx = Math.max(r, g, b), mn = Math.min(r, g, b); let h = 0, sat = 0; const l = (mx + mn) / 2, d = mx - mn;
    if (d) { sat = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn); h = mx === r ? (g - b) / d + (g < b ? 6 : 0) : mx === g ? (b - r) / d + 2 : (r - g) / d + 4; h /= 6; }
    const L2 = Math.max(l, (kind === 'water' ? 0.56 : 0.6) + l * 0.3), S2 = Math.min(0.62, sat * 0.85 + 0.1);
    if (kind !== 'water' && h > 0.22 && h < 0.45) h = h - (h - 0.22) * 0.35; // зелень чуть теплее, как в пробнике
    const q = L2 < 0.5 ? L2 * (1 + S2) : L2 + S2 - L2 * S2, p = 2 * L2 - q;
    const f = t => { t = (t + 1) % 1; return t < 1 / 6 ? p + (q - p) * 6 * t : t < 0.5 ? q : t < 2 / 3 ? p + (q - p) * (2 / 3 - t) * 6 : p; };
    return '#' + [f(h + 1 / 3), f(h), f(h - 1 / 3)].map(v => Math.round(v * 255).toString(16).padStart(2, '0')).join('');
  }
  let biomesPapered = false;
  function paperBiomes() {
    if (biomesPapered || !paperOn) return; biomesPapered = true;
    for (const bi of BIOMES) for (const k of ['ground', 'path', 'water', 'rock']) if (Array.isArray(bi[k])) bi[k] = bi[k].map(c => paperCol(c, k));
    for (const k in PATH_BY_BIOME) PATH_BY_BIOME[k] = PATH_BY_BIOME[k].map(c => paperCol(c, 'path'));
    for (const t of [PATH, WATER, ROCK, STONE]) if (Array.isArray(PAL[t])) PAL[t] = PAL[t].map(c => paperCol(c, t === WATER ? 'water' : 'path'));
  }
  // чернильный контур вокруг готового спрайта: силуэт чернилами со сдвигом во все стороны, сверху – сам спрайт
  function inkOutline(cv, w) {
    const W2 = cv.width, H2 = cv.height, o = document.createElement('canvas'); o.width = W2; o.height = H2; const oc = o.getContext('2d');
    for (let k = 0; k < 8; k++) { const a = k * Math.PI / 4; oc.drawImage(cv, Math.round(Math.cos(a) * w), Math.round(Math.sin(a) * w)); }
    oc.globalCompositeOperation = 'source-in'; oc.fillStyle = 'rgba(75,46,30,.92)'; oc.fillRect(0, 0, W2, H2);
    oc.globalCompositeOperation = 'source-over'; oc.drawImage(cv, 0, 0);
    const c = cv.getContext('2d'); c.save(); c.setTransform(1, 0, 0, 1, 0, 0); c.clearRect(0, 0, W2, H2); c.drawImage(o, 0, 0); c.restore();
  }
  let treesWashed = false;
  function getChunk(cx, cy) {
    if (!treesWashed && paperOn) { treesWashed = true; for (const k in TREE_SPR) if (TREE_SPR[k] && TREE_SPR[k].getContext) { inkOutline(TREE_SPR[k], 2.2); paperWash(TREE_SPR[k], 0.26); } }
    const key = cx + ',' + cy;
    let ch = chunkCache.get(key);
    if (ch) { chunkCache.delete(key); chunkCache.set(key, ch); return ch; }
    // нужен прямо сейчас: достраиваем начатый или строим целиком
    const j = chunkJob && chunkJob.key === key ? chunkJob : newChunkJob(cx, cy);
    if (j === chunkJob) chunkJob = null;
    runChunkJob(j, Infinity);
    return j.cv;
  }

  // мини-карта и туман
  let miniBase = makeCanvas(1, 1), fog = makeCanvas(1, 1);
  function rebuildMap() {
    chunkCache.clear();
    chunkJob = null;
    buildMinimap();
  }

  function buildMinimap() {
    miniBase = makeCanvas(World.MW, World.PLAY_H); fog = makeCanvas(World.MW, World.PLAY_H);
    const c = miniBase.getContext('2d');
    const MINI = { [PATH]: '#9a6b45', [STONE]: '#a0a0a4', [WALL]: '#6a5a86', [GATE]: '#ffcf4a', [LAVA]: '#ff6a22', [FLOOR]: '#5a5268', [ICE]: '#c8eefb' };
    for (let ty = 0; ty < World.PLAY_H; ty++) for (let tx = 0; tx < World.MW; tx++) {
      const t = World.tiles[ty * World.MW + tx], b = World.biomeMap[ty * World.MW + tx];
      let col;
      if (World.isGround(t)) col = BIOMES[t].mini;
      else if (t === WATER) col = (BIOMES[b].water || ['#8fcbe8'])[0];
      else if (t === ROCK) col = shade((BIOMES[b].rock || ['#a4a4a8'])[0], 0.2);
      else col = MINI[t];
      if (EDGE_MINI[edgeStyle()] && edgeInfo(tx, ty)) col = EDGE_MINI[edgeStyle()];
      if (paperOn) { let pc = MINI_PAPER.get(col); if (!pc) { pc = paperCol(col, t === WATER ? 'water' : 'ground'); MINI_PAPER.set(col, pc); } col = pc; }
      c.fillStyle = col; c.fillRect(tx, ty, 1, 1);
    }
    World.trees.forEach((tr, k) => { const tx = Math.floor(tr.x / World.T), ty = Math.floor(tr.y / World.T); if (World.treeGrid[ty * World.MW + tx] === k + 1) { c.fillStyle = 'rgba(0,0,0,0.25)'; c.fillRect(tx, ty, 1, 1); } });
    for (const sc of World.secrets) if (!sc.open) { c.fillStyle = shade((BIOMES[World.biomeMap[sc.i]].rock || ['#a4a4a8'])[0], 0.2); c.fillRect(sc.cx - 1, sc.cy - 1, 3, 3); }
    resetFog();
    HUD.MM2.neon = null; HUD.MM2.sign = null; // мини-карта 2.0 перерисует основу под новую главу
  }
  const MINI_PAPER = new Map();
  function resetFog() { const c = fog.getContext('2d'); c.globalCompositeOperation = 'source-over'; c.fillStyle = paperOn ? '#efe0bf' : '#0d0a16'; c.fillRect(0, 0, World.MW, World.MH); }
  function revealFog(x, y, r) {
    const c = fog.getContext('2d');
    c.globalCompositeOperation = 'destination-out';
    const g = c.createRadialGradient(x / World.T, y / World.T, r * 0.6, x / World.T, y / World.T, r);
    g.addColorStop(0, 'rgba(0,0,0,1)'); g.addColorStop(1, 'rgba(0,0,0,0)');
    c.fillStyle = g; c.beginPath(); c.arc(x / World.T, y / World.T, r, 0, TAU); c.fill();
    c.globalCompositeOperation = 'source-over';
  }

  return {
    CHUNK, CHPX, chunkCache, newChunkJob, runChunkJob, paperBiomes, getChunk, rebuildMap,
    resetFog, revealFog, paperCol,
    get chunkJob() { return chunkJob; },
    set chunkJob(value) { chunkJob = value; },
    get paperOn() { return paperOn; },
    set paperOn(value) { paperOn = value; },
    get miniBase() { return miniBase; },
    get fog() { return fog; },
  };
})();
