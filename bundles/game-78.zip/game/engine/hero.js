'use strict';

const Hero = (() => {
  // ------------------------------------------------------------------
  //  Игрок
  // ------------------------------------------------------------------
  function hurtPlayer(dmg, sx, sy) {
    if (P.down || P.inv > 0 || P.dashT > 0 || Session.state !== 'play' || G.cutscene) return;
    if (P.shieldLv && P.shieldT <= 0) {
      P.shieldT = P.shieldCd; P.inv = 0.5;
      Effects.floatText(P.x, P.y - 36, 'БЛОК!', '#7fe8ff', true); Effects.shockRing(P.x, P.y, '#7fe8ff', 70); Sound.sfx.block();
      if (Actors.lv('evAegis')) { G.novas.push({ x: P.x, y: P.y, r: 10, max: 230, hit: new Set(), k: 3, star: true }); Effects.shockRing(P.x, P.y, '#9ad8ff', 230); }
      return;
    }
    if (Encounters.hasRelic('guard') && (G.guardT || 0) <= 0) { G.guardT = 12 - 2 * Encounters.relicLv('guard'); P.inv = 0.5; Effects.floatText(P.x, P.y - 36, '🛡️ БЛОК!', '#ffd25a', true); Effects.shockRing(P.x, P.y, '#ffd25a', 70); Sound.sfx.block(); return; }
    if (Encounters.hasRelic('mirror') && Math.random() < 0.08 + 0.045 * Encounters.relicLv('mirror')) { P.inv = 0.3; Effects.floatText(P.x, P.y - 36, '🪞 мимо!', '#bfeaff', true); return; }
    if (dmg > 0 && StarTrail.absorb()) return;
    const d = dmg * (1 - P.armor) * (G.ev && G.ev.def.id === 'rage' ? 1.3 : 1) * (Encounters.hasRelic('crown') ? 1.15 : 1);
    P.hp -= d; P.inv = 0.6; Challenges.buzz(d > P.maxHp * 0.15 ? 70 : 35);
    if (G.activeBoss) G.bossHurt = true;
    if (G.st) G.st.dmgTaken += d; G.shake = Math.max(G.shake, 7); G.hurtFlash = 0.35;
    Effects.dmgText(P.x, P.y - 30, d, '#ff5b5b');
    Sound.sfx.hurt();
    if (sx !== undefined) { const a = Math.atan2(P.y - sy, P.x - sx); Physics.moveEntity(P, Math.cos(a) * 14, Math.sin(a) * 14); }
    G.combo = 0;
    if (P.hp <= 0) {
      if (G.team && Expedition.teamCatch()) { /* вторая героиня в строю */ }
      else if (Encounters.hasRelic('phoenix') && !G.phoenixUsed) {
        G.phoenixUsed = true; P.hp = Math.round(P.maxHp * (0.25 + 0.25 * Encounters.relicLv('phoenix'))); P.inv = Encounters.relicLv('phoenix') >= 3 ? 3.5 : 2.5;
        Screens.showBanner('🪶 Перо феникса!', 'Ты возродилась из пепла'); Effects.burst(P.x, P.y, 40, '#ff8a2a', 260); Sound.sfx.magic();
      } else if (Actors.talent('second') && !G.secondUsed) {
        G.secondUsed = true; P.hp = Math.round(P.maxHp * (0.25 + 0.15 * Math.min(3, Actors.talent('second')))); P.inv = 2.5;
        Screens.showBanner('🕊️ Второе дыхание!', 'Звёзды не дали тебе упасть'); Effects.burst(P.x, P.y, 40, '#bfeaff', 260); Sound.sfx.magic(); Challenges.buzz(120);
      } else if (G.td) Defense.defDown(); // в обороне героиня отдохнёт у кристалла и вернётся
      else if (P.lives > 1 && !World.CFG.rush) HouseChapter.loseLife(); else if (NET.on && G.netRun) Multiplayer.netDown(); else { P.hp = 0; Screens.playerDied(); }
    }
    else if (P.hp < P.maxHp * 0.3 && !G.lowHpSaid) { G.lowHpSaid = true; Screens.say('Осторожно! Собирай сердечки, чтобы подлечиться!'); }
  }
  function gainXp(v) {
    if (G.ev && G.ev.def.id === 'gold') v *= 2; else if (G.ev && G.ev.def.id === 'rage') v *= 1.5;
    v *= Math.pow(1 + 0.08, Actors.talent('xp'));
    if (Seasons.weekEv('xp')) v *= 1.3;
    P.xp += v;
    while (P.xp >= P.xpNext) { P.xp -= P.xpNext; P.level++; P.xpNext = Actors.xpFor(P.level); G.pendingLv++; }
    if (G.pendingLv > 0 && Session.state === 'play' && !G.cutscene) Screens.openLevelUp();
  }
  function tryDash() {
    if (Session.state !== 'play' || P.dashCd > 0 || G.cutscene) return;
    let dx = Controls.input.mx, dy = Controls.input.my;
    if (G.invertT > 0) { dx = -dx; dy = -dy; }
    if (Math.hypot(dx, dy) < 0.1) { dx = P.face; dy = 0; }
    const m = Math.hypot(dx, dy); dx /= m; dy /= m;
    P.dashCd = P.dashCdMax;
    if (G.st) G.st.dashes++;
    if (P.up.c3glitch) P.inv = Math.max(P.inv, 0.2 + 0.3 * P.up.c3glitch);
    if (HEROES[P.hero].blink) {
      const sx = P.x, sy = P.y;
      for (let k = 0; k < 15; k++) {
        const nx = P.x + dx * 10, ny = P.y + dy * 10;
        if (World.isSolidTile(Math.floor(nx / World.T), Math.floor(ny / World.T), false)) break;
        P.x = nx; P.y = ny;
      }
      Physics.collide(P);
      P.inv = Math.max(P.inv, 0.35);
      for (let k = 0; k <= 3; k++) G.pzones.push({ x: lerp(sx, P.x, k / 3), y: lerp(sy, P.y, k / 3), r: 30, t: 0, dur: 1.6, tick: 0, dmg: P.dmg * (Actors.lv('evComet') ? 1.6 : 0.8) });
      Effects.burst(sx, sy, 14, '#ff8a2a', 160); Effects.burst(P.x, P.y, 18, '#ffd23a', 200);
      Sound.sfx.blink();
    } else {
      P.dashX = dx; P.dashY = dy; P.dashT = 0.2;
      if (HEROES[P.hero].pounce) { P.pounce = true; Sound.sfx.pounce(); } else Sound.sfx.dash();
    }
  }
  function addSuper(v) {
    if (P.sp >= 100 || G.cutscene) return;
    P.sp = Math.min(100, P.sp + v * (P.superGain || 1));
    if (P.sp >= 100) { Sound.sfx.superReady(); Effects.floatText(P.x, P.y - 46, 'СУПЕР ГОТОВ!', '#ffd25a', true); }
  }
  function trySuper() {
    if (Session.state !== 'play' || P.sp < 100 || G.cutscene) return;
    P.sp = 0; Challenges.buzz(80); Achievements.life('supers');
    if (G.st) G.st.supers++;
    for (const bl of G.ebullets) if ((bl.x - P.x) ** 2 + (bl.y - P.y) ** 2 < 220 * 220) bl.life = 0;
    const H = HEROES[P.hero];
    if (G.team) {
      Screens.showBanner('ДРУЖБА-СУПЕР!', 'Перьевой ураган + Огненная ярость');
      P.stormT = 2.6; P.stormE = 0; G.novas.push({ x: P.x, y: P.y, r: 10, max: 470, hit: new Set() });
      P.inv = Math.max(P.inv, 1.4); Sound.sfx.magic(); Sound.sfx.nova(); G.shake = 14;
      return;
    }
    Screens.showBanner(H.superName + '!', '');
    if (H.super === 'storm') { P.stormT = 2.6; P.stormE = 0; P.inv = Math.max(P.inv, 1.3); Sound.sfx.magic(); Sound.sfx.dash(); }
    else if (H.super === 'purr') {
      const heal = Math.round(P.maxHp * 0.25); P.hp = Math.min(P.maxHp, P.hp + heal); Effects.floatText(P.x, P.y - 40, '+' + heal, '#7dff7d', true);
      G.novas.push({ x: P.x, y: P.y, r: 10, max: 420, hit: new Set(), purr: true }); P.inv = Math.max(P.inv, 1.1); Sound.sfx.purr();
    }
    else { G.novas.push({ x: P.x, y: P.y, r: 10, max: 470, hit: new Set() }); P.inv = Math.max(P.inv, 1.1); Sound.sfx.nova(); }
    G.shake = 14;
    if (Actors.lv('evNova')) G.evNovaT = 1.4; // сверхновая – в конце супера
  }
  // периодические эволюции: грозовой вихрь, метеориты, сверхновая
  function evoTick(dt) {
    if (G.bloodT > 0) G.bloodT -= dt;
    if (Actors.lv('evStorm') && P.orbit) {
      G.evStormT = (G.evStormT || 0) - dt;
      if (G.evStormT <= 0) {
        G.evStormT = 1.2; let any = false;
        for (let k = 0; k < Math.min(P.orbit, 6); k++) {
          const a = P.orbA + (k / P.orbit) * TAU, ox2 = P.x + Math.cos(a) * 62, oy2 = P.y + Math.sin(a) * 62;
          let best = null, bd = 190 * 190;
          for (const e of G.enemies) { if (e.dead || e.spawnT > 0) continue; const d = (e.x - ox2) ** 2 + (e.y - oy2) ** 2; if (d < bd) { bd = d; best = e; } }
          const bb = G.activeBoss; if (!best && bb && bb.state === 'fight' && !bb.inv && (bb.x - ox2) ** 2 + (bb.y - oy2) ** 2 < (190 + bb.r) ** 2) best = bb;
          if (best) { any = true; G.bolts.push({ pts: [[ox2, oy2], [best.x, best.y - (best.z || 0)]], t: 0.18, col: '190,230,255' }); hitAny(best, Actors.rollHit(P.dmg * 1.1), 0, 0, false); }
        }
        if (any) Sound.sfx.bolt();
      }
    }
    if (Actors.lv('evMeteor')) {
      G.evMetT = (G.evMetT === undefined ? 2 : G.evMetT) - dt;
      if (G.evMetT <= 0) {
        G.evMetT = 4;
        const cands = G.enemies.filter(e => !e.dead && e.spawnT <= 0 && (e.x - P.x) ** 2 + (e.y - P.y) ** 2 < (P.range * 1.3) ** 2);
        if (G.activeBoss && G.activeBoss.state === 'fight' && !G.activeBoss.inv) cands.push(G.activeBoss);
        for (let k = 0; k < 3 && cands.length; k++) { const t = cands.splice(Math.floor(Math.random() * cands.length), 1)[0]; Effects.starfall(t.x, t.y - (t.z || 0), 2.5, '#ff9a3a', '☄️'); }
      }
    }
    if (G.evNovaT > 0) {
      G.evNovaT -= dt;
      if (G.evNovaT <= 0) { G.novas.push({ x: P.x, y: P.y, r: 10, max: 380, hit: new Set(), k: 6, star: true }); Effects.shockRing(P.x, P.y, '#fff3a0', 380); Effects.burst(P.x, P.y, 40, '#fff3a0', 300); Sound.sfx.nova(); G.shake = Math.max(G.shake, 12); }
    }
  }
  function nearestTarget(range) {
    let best = null, bd = range * range;
    for (const e of G.enemies) {
      if (e.dead || e.spawnT > 0) continue;
      let d = (e.x - P.x) ** 2 + (e.y - P.y) ** 2;
      if (d > range * range) continue;
      if (e.def.ai === 'healer') d *= 0.6; // лекарей бьём первыми
      if (d < bd) { bd = d; best = e; }
    }
    const b = G.activeBoss;
    if (b && b.state === 'fight' && b.alpha > 0.3 && b.z < 30 && !b.inv && !b.shield) {
      const d = (b.x - P.x) ** 2 + (b.y - P.y) ** 2;
      if (d < (range + b.r) ** 2 && (!best || bd > 85 * 85 || d < bd * 2.5)) best = b;
    }
    return best;
  }
  function hitAny(tg, hit, kx, ky, fromFeather) {
    if (tg.kind) return Bosses.damageBoss(tg, hit);
    return Enemies.damageEnemy(tg, hit, kx, ky, fromFeather);
  }
  function onProjHit(f, tg) {
    if (f.kind === 'fire') {
      const R = P.splash || 38;
      for (const e of G.enemies) {
        if (e === tg || e.dead || e.spawnT > 0) continue;
        if ((e.x - f.x) ** 2 + (e.y - f.y) ** 2 < (R + e.r) ** 2) Enemies.damageEnemy(e, { v: f.dmg * 0.5, crit: false }, 0, 0, false);
      }
      G.rings.push({ x: f.x, y: f.y, r: 6, max: R, col: '#ff8a2a', t: 0 });
      Effects.burst(f.x, f.y, 6, '#ffb03a', 120);
      if (tg && !tg.dead) { tg.burnT = 2; tg.burnDps = Math.max(tg.burnDps || 0, f.dmg * (P.burn || 0.35)); tg.burnTick = tg.burnTick || 0.4; }
    } else if (P.explode) featherExplode(f.x, f.y, f.dmg, tg && !tg.kind ? tg : null);
  }
  function featherExplode(x, y, dmg, skip) {
    const R = 40 + 12 * P.explode;
    for (const e of G.enemies) {
      if (e === skip || e.dead || e.spawnT > 0) continue;
      if ((e.x - x) ** 2 + (e.y - y) ** 2 < (R + e.r) ** 2) Enemies.damageEnemy(e, { v: dmg * 0.35, crit: false }, 0, 0, false);
    }
    G.rings.push({ x, y, r: 6, max: R, col: '#ffb03a', t: 0 });
  }

  function updatePlayer(dt) {
    P.t += dt;
    if (Session.state === 'dying') return;
    if (P.inv > 0) P.inv -= dt;
    if (P.dashCd > 0) P.dashCd -= dt;
    if (P.slowT > 0) P.slowT -= dt;
    if (P.shieldLv && P.shieldT > 0) P.shieldT -= dt;
    if (P.down) { P.moving = false; P.vx = 0; P.vy = 0; return; } // без сил – ждём, пока поднимут
    if (P.regen && P.hp < P.maxHp) P.hp = Math.min(P.maxHp, P.hp + P.regen * dt);
    let mx = Controls.input.mx, my = Controls.input.my;
    if (G.invertT > 0) { mx = -mx; my = -my; }
    if (P.napT > 0) P.napT -= dt;
    const m = Math.hypot(mx, my);
    if (m > 1) { mx /= m; my /= m; }
    P.moving = m > 0.08;
    const ox = P.x, oy = P.y;
    const spd = P.speed * (P.slowT > 0 ? 0.55 : 1) * (G.blizzardT > 0 && !G.nearFire && !Actors.lv('c6warm') ? 0.9 : 1);
    const onIce = World.CFG.slippery && World.tileAt(Math.floor(P.x / World.T), Math.floor(P.y / World.T)) === ICE;
    if (P.dashT > 0) {
      P.dashT -= dt;
      Physics.moveEntity(P, P.dashX * P.speed * 3.3 * dt, P.dashY * P.speed * 3.3 * dt);
      P.ivx = P.dashX * P.speed * 1.3; P.ivy = P.dashY * P.speed * 1.3;
      Effects.part(P.x + rnd(-6, 6), P.y + rnd(-10, 6), 0, 0, 0.35, 5, 'rgba(160,225,255,0.8)');
      if (Math.abs(P.dashX) > 0.2) P.face = P.dashX > 0 ? 1 : -1;
      if (P.dashT <= 0 && P.pounce) { P.pounce = false; HouseChapter.pounceHit(); }
      if (Actors.lv('evComet')) { G.cometT = (G.cometT || 0) - dt; if (G.cometT <= 0) { G.cometT = 0.04; G.pzones.push({ x: P.x, y: P.y, r: 28, t: 0, dur: 1.4, tick: 0, dmg: P.dmg * 0.9 }); } }
    } else if (onIce) {
      // лёд: разгон и торможение с инерцией
      const k = Math.min(1, dt * 2.4);
      const isp = World.CFG.iceSpeed || 1.15;
      P.ivx = (P.ivx || 0) + ((P.moving ? mx * spd * isp : 0) - (P.ivx || 0)) * k;
      P.ivy = (P.ivy || 0) + ((P.moving ? my * spd * isp : 0) - (P.ivy || 0)) * k;
      Physics.moveEntity(P, P.ivx * dt, P.ivy * dt);
      if (dt > 0) { P.ivx = (P.x - ox) / dt; P.ivy = (P.y - oy) / dt; }
      if (P.moving && Math.abs(mx) > 0.15) P.face = mx > 0 ? 1 : -1;
      if (Math.hypot(P.ivx, P.ivy) > 70 && Math.random() < 0.3) Effects.part(P.x + rnd(-6, 6), P.y + 10, -P.ivx * 0.1, -10, 0.4, 3, 'rgba(230,248,255,0.9)');
    } else if (P.moving) {
      Physics.moveEntity(P, mx * spd * dt, my * spd * dt);
      if (Math.abs(mx) > 0.15) P.face = mx > 0 ? 1 : -1;
      P.ivx = mx * spd; P.ivy = my * spd;
    } else { P.ivx = 0; P.ivy = 0; }
    if (dt > 0) { P.vx = lerp(P.vx, (P.x - ox) / dt, 0.3); P.vy = lerp(P.vy, (P.y - oy) / dt, 0.3); }
    // супер Крилессы: перьевой ураган
    if (P.stormT > 0) {
      P.stormT -= dt; P.stormE -= dt;
      if (P.stormE <= 0) {
        P.stormE = 0.07;
        for (let k = 0; k < 5; k++) {
          const a = P.t * 4 + (k / 5) * TAU;
          G.feathers.push({ x: P.x, y: P.y - 8, vx: Math.cos(a) * 520, vy: Math.sin(a) * 520, dmg: P.dmg * 0.9, pierce: 2, life: 0.9, hit: [], kind: 'feather' });
        }
      }
    }
    // перья
    P.fireT -= dt;
    if (P.fireT <= 0 && !G.hidden && !G.jump) {
      P.volley = (P.volley || 0) + 1;
      let tg = nearestTarget(P.range);
      // каждый второй залп – в босса, даже если вокруг толпа миньонов
      const bb = G.activeBoss;
      if (bb && P.volley % 2 === 0 && bb.state === 'fight' && !bb.inv && !bb.shield && bb.alpha > 0.3 && bb.z < 30 &&
        (bb.x - P.x) ** 2 + (bb.y - P.y) ** 2 < (P.range + bb.r) ** 2) tg = bb;
      if (!tg && World.CFG.icedChests && (P.proj === 'fire' || Actors.lv('c6ice'))) tg = Expedition.iceTarget();
      if (!tg && World.secrets.length) tg = Expedition.crackTarget();
      if (tg) {
        const base = Math.atan2(tg.y - (tg.z || 0) - P.y, tg.x - P.x);
        for (let i = 0; i < P.shots; i++) {
          const a = base + (i - (P.shots - 1) / 2) * 0.16;
          const life = (P.range / P.projSpd) * 1.35;
          G.feathers.push({ x: P.x, y: P.y - 8, vx: Math.cos(a) * P.projSpd, vy: Math.sin(a) * P.projSpd, dmg: P.dmg, pierce: P.pierce, life, life0: life, hit: [], kind: P.proj });
        }
        if (P.up.c3twin && Math.random() < 0.1 * P.up.c3twin) {
          const life = (P.range / P.projSpd) * 1.35;
          for (let i = 0; i < P.shots; i++) {
            const a = base + (i - (P.shots - 1) / 2) * 0.16 + 0.09;
            G.feathers.push({ x: P.x, y: P.y - 8, vx: Math.cos(a) * P.projSpd, vy: Math.sin(a) * P.projSpd, dmg: P.dmg, pierce: P.pierce, life, life0: life, hit: [], kind: P.proj, twin: true });
          }
        }
        if (P.proj === 'fire') Sound.sfx.fireball(); else if (P.proj === 'claw') Sound.sfx.claw(); else Sound.sfx.shoot();
        if (Actors.lv('evHurricane') && P.volley % 6 === 0) { // ураган: кольцо снарядов
          const life = (P.range / P.projSpd) * 1.1;
          for (let k = 0; k < 16; k++) { const a = k * TAU / 16; G.feathers.push({ x: P.x, y: P.y - 8, vx: Math.cos(a) * P.projSpd, vy: Math.sin(a) * P.projSpd, dmg: P.dmg * 0.7, pierce: P.pierce, life, life0: life, hit: [], kind: P.proj }); }
        }
        if (Actors.talent('starfall') && P.volley % [12, 10, 8][Math.min(3, Actors.talent('starfall')) - 1] === 0) Effects.starfall(tg.x, tg.y - (tg.z || 0));
        P.fireT = P.fireInt;
      } else P.fireT = 0.1;
    }
    if (P.up.c2disco) {
      P.discoT = (P.discoT === undefined ? 6 : P.discoT) - dt;
      if (P.discoT <= 0 && !G.cutscene) { P.discoT = 6; G.novas.push({ x: P.x, y: P.y, r: 10, max: 150 + 25 * P.up.c2disco, hit: new Set(), k: 0.8 * P.up.c2disco, disco: true }); }
    }
    // вихрь
    if (P.orbit) {
      P.orbA += dt * 3.2;
      for (let k = 0; k < P.orbit; k++) {
        const a = P.orbA + (k / P.orbit) * TAU, ox2 = P.x + Math.cos(a) * 62, oy2 = P.y + Math.sin(a) * 62;
        for (const e of G.enemies) {
          if (e.dead || e.orbCd > 0 || e.spawnT > 0) continue;
          if ((e.x - ox2) ** 2 + (e.y - oy2) ** 2 < (e.r + 10) ** 2) { e.orbCd = 0.35; Enemies.damageEnemy(e, Actors.rollHit(P.dmg * 0.7), Math.cos(a) * 120, Math.sin(a) * 120, false); }
        }
        const b = G.activeBoss;
        if (b && (b.x - ox2) ** 2 + (b.y - oy2) ** 2 < (b.r + 10) ** 2 && b.orbCd <= 0) { b.orbCd = 0.3; Bosses.damageBoss(b, Actors.rollHit(P.dmg * 0.7)); }
      }
    }
    // молния
    if (P.bolt) {
      P.boltT -= dt;
      if (P.boltT <= 0) {
        P.boltT = Math.max(1.0, 2.8 - P.bolt * 0.28);
        const cands = G.enemies.filter(e => !e.dead && e.spawnT <= 0 && (e.x - P.x) ** 2 + (e.y - P.y) ** 2 < (P.range * 1.3) ** 2);
        if (G.activeBoss && G.activeBoss.state === 'fight' && !G.activeBoss.inv) cands.push(G.activeBoss);
        if (cands.length) {
          let cur = pick(cands); const pts = [[P.x, P.y - 20]]; const used = new Set();
          for (let k = 0; k <= P.bolt; k++) {
            if (!cur) break;
            used.add(cur); pts.push([cur.x, cur.y]);
            hitAny(cur, Actors.rollHit(P.dmg * 1.6), 0, 0, false);
            let nb = null, nd = 160 * 160;
            for (const e of cands) { if (used.has(e) || e.dead) continue; const d = (e.x - cur.x) ** 2 + (e.y - cur.y) ** 2; if (d < nd) { nd = d; nb = e; } }
            cur = nb;
          }
          G.bolts.push({ pts, t: 0.25 });
          Sound.sfx.bolt();
        }
      }
    }
    evoTick(dt);
  }

  return {
    hurtPlayer, gainXp, tryDash, addSuper, trySuper, evoTick, nearestTarget, hitAny, onProjHit,
    updatePlayer,
  };
})();
