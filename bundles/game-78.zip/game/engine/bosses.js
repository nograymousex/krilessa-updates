'use strict';

const Bosses = (() => {
  // ------------------------------------------------------------------
  //  Боссы
  // ------------------------------------------------------------------
  function makeBosses() {
    Session.bosses = World.CFG.bosses.map((kind, i) => {
      const d = BOSSES[kind];
      const hx = World.tc(World.CFG.bossTiles[i].x), hy = World.tc(World.CFG.bossTiles[i].y);
      return {
        id: i, kind, def: d, name: d.name, sub: d.sub, r: d.r, maxHp: 1, hp: 1, spd: d.spd, dmg: 0, cdmg: 0,
        E: World.CFG.bossLevels[i], level: World.CFG.bossLevels[i], aggro: 1, shield: false, stunT: 0, burnT: 0, burnDps: 0, burnTick: 0,
        fly: !!d.fly, move: d.move, hx, hy, x: hx, y: hy, state: G.defeated[i] ? 'dead' : 'sleep', mode: 'idle', t: 0,
        flash: 0, z: 0, last: null, stage: 0, sub: 0, cnt: 0, anim: Math.random() * 5, alpha: 1, ang: 0, tx: 0, ty: 0,
        sx: 0, sy: 0, dist: 0, charging: false, dur: 0, inv: false, final: i === World.CFG.bosses.length - 1, look: 0, p: null,
        speedMul: 1, tauntT: 9, orbCd: 0, bubble: null,
        calmBiome: i < World.CFG.bosses.length - 1 ? World.biomeMap[World.CFG.bossTiles[i].y * World.MW + World.CFG.bossTiles[i].x] : -1,
      };
    });
  }
  const guardiansCount = () => Session.bosses.length - 1;
  const guardiansDone = () => G.defeated.slice(0, guardiansCount()).filter(Boolean).length;
  function startBossFight(b) {
    Actors.bossStats(b); G.bossHurt = false;
    if (Actors.talent('brave') && !World.CFG.rush && !World.CFG.abyss) { P.inv = Math.max(P.inv, 3); Effects.floatText(P.x, P.y - 40, '🫧 Храбрый вход', '#bfeaff', true); }
    b.mpX = Multiplayer.netCoop() ? 3 : 1; // вместе – втрое крепче
    if (b.mpX > 1) { b.maxHp *= b.mpX; b.hp = b.maxHp; }
    if (G.st && !G.st.cur) G.st.cur = { k: b.kind, n: b.name, pl: P.level, bl: b.level, t0: G.st.time, d: 0, h: 0, df: G.diffId };
    b.state = 'fight'; b.mode = 'idle'; b.t = 1.5; b.stage = 0; b.speedMul = b.aggro; G.activeBoss = b;
    // обычные мобы разбегаются – на арене только босс и его свита
    if (!G.core) for (const e of G.enemies) if (!e.minion && !e.shrine && !e.bossPart && Math.hypot(e.x - b.x, e.y - b.y) < 800) { e.dead = true; Effects.burst(e.x, e.y, 6, '#c9b3ff', 90); }
    G.bossHeartT = (Encounters.HEART_EVERY[G.diffId] || 12) * 0.8;
    b.shield = false; b.stunT = 0; b.burnT = 0;
    Screens.showBanner(b.name, `${b.sub} · ур. ${b.level}`);
    Sound.sfx.roar(); Sound.music(World.CFG.abyss && G.abyss && G.abyss.mus ? Challenges.abyssBossTrack() : b.def.music ? b.def.music : b.def.immortal ? 'ultimate' : b.def.final ? (World.CHN === 3 ? 'final2' : 'final') : 'boss');
    if (G.ev) Encounters.endEvent();
    Screens.speak(b.kind, b.def.lines.intro);
    G.shake = 10;
  }
  function resetBoss(b) {
    b.state = 'sleep'; b.hp = b.maxHp; b.x = b.hx; b.y = b.hy; b.z = 0; b.alpha = 1; b.stage = 0; b.speedMul = 1;
    b.mode = 'idle'; b.charging = false; b.inv = false; b.shield = false; b.stunT = 0; b.burnT = 0;
    if (G.activeBoss === b) { G.activeBoss = null; Encounters.biomeMusic(true); }
    G.hazards.length = 0; G.ebullets.length = 0; G.beams.length = 0;
    for (const e of G.enemies) if (e.minion) e.dead = true;
  }
  function startStage(b, i) {
    b.stage = i; b.mode = 'trans'; b.t = 2.3; b.inv = true; b.charging = false; b.z = 0; b.alpha = 1;
    if (i > 0) Encounters.dropHeartNear(100, 200);
    b.speedMul = (b.def.stages[i].spd || 1) * b.aggro; b.stunT = 0;
    G.ebullets.length = 0; G.hazards.length = 0; G.beams.length = 0;
    Effects.shockRing(b.x, b.y, '#ffffff', 320);
    const d = Math.hypot(P.x - b.x, P.y - b.y);
    if (d < 230) { const a = Math.atan2(P.y - b.y, P.x - b.x); Physics.moveEntity(P, Math.cos(a) * (230 - d), Math.sin(a) * (230 - d)); }
    Screens.showBanner(`СТАДИЯ ${i + 1}`, b.name);
    Screens.speak(b.kind, b.def.lines.stages[i]);
    if (b.final && i >= 2 && World.CFG.team) Expedition.freeTessa();
    Sound.sfx.stage(); G.shake = 16;
  }
  function endAttack(b, rest) { b.mode = 'idle'; b.t = rest / b.speedMul; b.sub = 0; b.cnt = 0; b.charging = false; b.z = 0; b.alpha = 1; }
  function nextAttack(b) {
    const list = b.def.stages[b.stage].attacks;
    let a, guard = 0;
    do { a = pick(list); } while ((a[0] === b.last || (a[0] === 'mirrors' && b.shield)) && guard++ < 12 && list.length > 1);
    if (a[0] === 'mirrors' && b.shield) a = ['ring', { n: 16, waves: 2 }];
    b.last = a[0]; b.mode = a[0]; b.p = a[1] || {}; b.sub = 0; b.t = 0; b.cnt = 0;
  }
  function bossMove(b, dt) {
    const spd = b.spd * b.speedMul;
    const dx = Session.AIM.x - b.x, dy = Session.AIM.y - b.y, d = Math.hypot(dx, dy) || 1;
    let mx, my;
    if (b.move === 'hover') {
      const want = 150;
      mx = (-dy / d) + (dx / d) * (d - want) / 100; my = (dx / d) + (dy / d) * (d - want) / 100;
    } else { mx = dx / d; my = dy / d; if (d < b.r + Session.AIM.r + 6) { mx = 0; my = 0; } }
    const hd = Math.hypot(b.x - b.hx, b.y - b.hy);
    if (hd > 340) { mx = (b.hx - b.x) / hd; my = (b.hy - b.y) / hd; }
    const m = Math.hypot(mx, my);
    if (m > 0.01) Physics.moveEntity(b, (mx / m) * spd * dt, (my / m) * spd * dt);
  }
  function ebullet(x, y, a, spd, dmg, col, r = 7, o = {}) {
    if (G.ebullets.length > 260 || (G.ebullets.length > 170 && Math.random() < 0.4)) return;
    G.ebullets.push({ x, y, vx: Math.cos(a) * spd, vy: Math.sin(a) * spd, spd, dmg, col, r, homing: o.homing || 0,
      life: o.life || 3.6, emoji: o.emoji ? pick(o.emojiSet || (G.activeBoss && G.activeBoss.def.emojiSet) || ZYAMA_EMOJI) : (o.heart ? '❤️' : null), slow: !!o.slow,
      square: !!o.square, saw: !!o.saw, bounce: !!o.bounce, missile: !!o.missile, hx: o.hx, hy: o.hy, rot: 0 });
  }
  function shotPuff(b, n) {
    if (b.saw || G.parts.length > Effects.partMax()) return;
    for (let k = 0; k < n; k++) { const a = Math.random() * TAU, v = rnd(20, 60); Effects.part(b.x, b.y, Math.cos(a) * v + b.vx * 0.15, Math.sin(a) * v + b.vy * 0.15, rnd(0.25, 0.45), b.r * 0.6, b.col || '#ffffff'); }
  }
  function bdmg(b, k = 1) { return b.dmg * k * (1 + 0.1 * b.stage); }
  function bossRing(b, n, spd, dmg, col, off = 0, o = {}) {
    for (let i = 0; i < n; i++) ebullet(b.x, b.y - b.z, off + (i / n) * TAU, spd, dmg, col, 7, o);
    Sound.sfx.enemyShot();
  }
  function hazardCircle(x, y, r, delay, dmg, fx) { const h = { kind: 'circle', x, y, r, t: 0, delay, dmg, fx, done: false }; G.hazards.push(h); return h; }
  function hazardLine(x, y, ang, len, w, delay, dmg, fx) { const h = { kind: 'line', x, y, ang, len, w, t: 0, delay, dmg, fx, done: false }; G.hazards.push(h); return h; }
  function minionCount(type) { let n = 0; for (const e of G.enemies) if (e.type === type && e.minion && !e.dead) n++; return n; }
  function summon(b, type, n, max = 6) {
    n = Math.max(1, Math.round(n * 0.85)); max = Math.max(2, Math.round(max * 0.8));
    const biome = World.biomeMap[Math.floor(b.hy / World.T) * World.MW + Math.floor(b.hx / World.T)];
    for (let i = 0; i < n; i++) {
      if (minionCount(type) >= max) break;
      const a = rnd(0, TAU), x = b.x + Math.cos(a) * (b.r + 34), y = b.y + Math.sin(a) * (b.r + 34);
      if (!Physics.walkable(x, y, ENEMIES[type].fly)) continue;
      const e = Enemies.spawnEnemy(type, x, y, biome, { minion: true, E: b.E }); e.xp *= 0.3;
    }
    Sound.sfx.magic();
  }
  const ATK = {
    ring(b, dt, p) {
      if (b.t <= 0) {
        bossRing(b, p.n || 14, (p.spd || 150), bdmg(b), p.col || '#d7ff7a', b.cnt * 0.22, { square: p.square });
        b.cnt++; b.t = (p.gap || 0.45) / b.speedMul; if (b.cnt >= (p.waves || 3)) endAttack(b, 1.2);
      }
    },
    emoji(b, dt, p) {
      if (b.t <= 0) {
        bossRing(b, p.n || 14, 170, bdmg(b), '#ff3ea5', b.cnt * 0.25, { emoji: true });
        b.cnt++; b.t = 0.5 / b.speedMul; if (b.cnt >= (p.waves || 3)) endAttack(b, 1.2);
      }
    },
    spiral(b, dt, p) {
      if (b.sub === 0) { b.sub = 1; b.dur = p.dur || 2.6; b.t = 0; }
      b.dur -= dt;
      if (b.t <= 0) {
        const arms = p.arms || 3;
        for (let k = 0; k < arms; k++) ebullet(b.x, b.y - b.z, b.anim * 1.7 + (k / arms) * TAU, p.spd || 150, bdmg(b), p.rainbow ? RAINBOW[(b.cnt++) % 7] : (p.col || '#c77dff'), 7, { emoji: p.emoji, square: p.square });
        b.t = p.rate || 0.11; Sound.sfx.enemyShot();
      }
      if (b.dur <= 0) endAttack(b, 1.0);
    },
    aimed(b, dt, p) {
      if (b.t <= 0) {
        const spd = p.spd || 270;
        ebullet(b.x, b.y - b.z, Physics.leadAngle(b.x, b.y, spd) + rnd(-(p.spread || 0.22), p.spread || 0.22), spd, bdmg(b), p.col || '#ffffff', p.r || 9, { square: p.square, emoji: p.emoji });
        Sound.sfx.enemyShot(); b.cnt++; b.t = (p.rate || 0.16) / b.speedMul; if (b.cnt >= (p.count || 10)) endAttack(b, 1.1);
      }
    },
    shotgun(b, dt, p) {
      if (b.t <= 0) {
        const n = p.n || 5, a = Physics.leadAngle(b.x, b.y, 200);
        for (let k = 0; k < n; k++) ebullet(b.x, b.y - b.z, a + (k - (n - 1) / 2) * 0.17, 200, bdmg(b), p.col || '#7dffb0', 8, { emoji: p.emoji, emojiSet: p.emojiSet });
        Sound.sfx.enemyShot(); b.cnt++; b.t = 0.5 / b.speedMul; if (b.cnt >= (p.waves || 3)) endAttack(b, 1.2);
      }
    },
    stomp(b, dt, p) {
      if (b.sub === 0) { hazardCircle(b.x, b.y, (p.r || 140) + b.cnt * 25, 0.9 / Math.sqrt(b.speedMul), bdmg(b, 1.7), 'stomp'); b.sub = 1; b.t = 1.05 / Math.sqrt(b.speedMul); }
      else if (b.t <= 0) { b.cnt++; if (b.cnt < (p.repeat || 1)) b.sub = 0; else endAttack(b, 1.0); }
    },
    leap(b, dt, p) {
      if (b.sub === 0) {
        let tx = Session.AIM.x + (Session.AIM.vx || 0) * 0.4, ty = Session.AIM.y + (Session.AIM.vy || 0) * 0.4; const hd = Math.hypot(tx - b.hx, ty - b.hy);
        if (hd > 330) { tx = b.hx + (tx - b.hx) / hd * 330; ty = b.hy + (ty - b.hy) / hd * 330; }
        b.tx = tx; b.ty = ty; b.sx = b.x; b.sy = b.y; b.dur = 0.95 / Math.sqrt(b.speedMul);
        hazardCircle(tx, ty, p.r || 100, b.dur, bdmg(b, 1.8), 'stomp'); b.sub = 1; b.t = b.dur;
      } else if (b.sub === 1) {
        const k = 1 - clamp(b.t / b.dur, 0, 1);
        b.x = lerp(b.sx, b.tx, k); b.y = lerp(b.sy, b.ty, k); b.z = Math.sin(k * Math.PI) * 130;
        if (b.t <= 0) { b.z = 0; b.x = b.tx; b.y = b.ty; Physics.collide(b); bossRing(b, p.ringN || 12, 175, bdmg(b), '#7dffb0'); G.shake = 12; b.sub = 2; b.t = 0.5; }
      } else if (b.t <= 0) { b.cnt++; if (b.cnt < (p.repeat || 1)) b.sub = 0; else endAttack(b, 1.0); }
    },
    lash(b, dt, p) {
      if (b.sub === 0) {
        const base = Math.atan2(Session.AIM.y - b.y, Session.AIM.x - b.x), fan = p.fan || 1;
        for (let k = 0; k < fan; k++) hazardLine(b.x, b.y, base + (k - (fan - 1) / 2) * 0.4, 380, 34, 0.7, bdmg(b, 1.5), 'tongue');
        b.sub = 1; b.t = 1.0;
      } else if (b.t <= 0) { b.cnt++; if (b.cnt < (p.repeat || 1)) b.sub = 0; else endAttack(b, 0.9); }
    },
    charge(b, dt, p) {
      const spd = p.spd || 640;
      if (b.sub === 0) { b.ang = Physics.leadAngle(b.x, b.y, spd, 0.4); b.trailD = 0; hazardLine(b.x, b.y, b.ang, 560, 76, 0.75, 0, 'charge'); b.sub = 1; b.t = 0.75; }
      else if (b.sub === 1) { if (b.t <= 0) { b.sub = 2; b.dist = 0; b.charging = true; Sound.sfx.roar(); } }
      else if (b.sub === 2) {
        const step = spd * dt, ox = b.x, oy = b.y;
        Physics.moveEntity(b, Math.cos(b.ang) * step, Math.sin(b.ang) * step);
        const moved = Math.hypot(b.x - ox, b.y - oy);
        b.dist += step;
        if (p.trail && b.dist - (b.trailD || 0) > 40) { b.trailD = b.dist; G.hazards.push({ kind: 'zone', x: b.x, y: b.y, r: 30, t: 0, delay: 0.15, dur: 2.4, dot: bdmg(b, 0.45), fx: 'rainbow' }); }
        if (Math.random() < 0.6) Effects.part(b.x + rnd(-20, 20), b.y + 30, rnd(-40, 40), rnd(-60, -10), 0.5, 4, p.trail ? pick(RAINBOW) : '#ffffff');
        if (moved < step * 0.5 || b.dist >= 560 || Math.hypot(b.x - b.hx, b.y - b.hy) > 430) {
          b.charging = false; b.sub = 3; b.t = 0.6; G.shake = 10; Sound.sfx.boom(); Effects.burst(b.x, b.y, 18, '#e6f4ff', 200);
          if (p.ringN) bossRing(b, p.ringN, 180, bdmg(b), '#ffffff');
        }
      } else if (b.t <= 0) { b.cnt++; if (b.cnt < (p.repeat || 2)) b.sub = 0; else endAttack(b, 1.0); }
    },
    rain(b, dt, p) {
      if (b.t <= 0) {
        const a = rnd(0, TAU), d = b.cnt === 0 ? 0 : rnd(0, 150);
        hazardCircle(Session.AIM.x + (Session.AIM.vx || 0) * 0.5 + Math.cos(a) * d, Session.AIM.y + (Session.AIM.vy || 0) * 0.5 + Math.sin(a) * d, p.r || 58, 0.9, bdmg(b, 1.3), p.fx || 'rain');
        b.cnt++; b.t = (p.rate || 0.26) / b.speedMul; if (b.cnt >= (p.n || 8)) endAttack(b, 1.1);
      }
    },
    summon(b, dt, p) { summon(b, p.type, p.n || 2, p.max || 6); endAttack(b, 1.4); },
    laser(b, dt, p) {
      if (b.sub === 0) {
        const n = p.beams || 2, base = Math.atan2(Session.AIM.y - b.y, Session.AIM.x - b.x), dir = Math.random() < 0.5 ? -1 : 1;
        const dur = p.dur || 3.2;
        for (let k = 0; k < n; k++) G.beams.push({ b, ang: base + (k / n) * TAU + (n === 1 ? 0 : 0.4), rot: (p.rot || 0.8) * dir, len: 560, w: 24, t: 0, warm: 0.9, dur, dmg: bdmg(b, 1.1), mouth: !!p.mouth, rainbow: !!p.rainbow });
        b.sub = 1; b.t = 0.9 + dur; Sound.sfx.laser();
      } else { bossMove(b, dt * 0.25); if (b.t <= 0) endAttack(b, 1.0); }
    },
    cross(b, dt, p) {
      if (b.sub === 0) { for (let k = 0; k < 4; k++) hazardLine(b.x, b.y, k * Math.PI / 2, 700, 44, 0.9, bdmg(b, 1.5), 'beam'); b.sub = 1; b.t = 1.0; }
      else if (b.sub === 1) { if (b.t <= 0) { for (let k = 0; k < 4; k++) hazardLine(b.x, b.y, Math.PI / 4 + k * Math.PI / 2, 700, 44, 0.9, bdmg(b, 1.5), 'beam'); b.sub = 2; b.t = 1.1; } }
      else if (b.t <= 0) endAttack(b, 1.0);
    },
    // волна: кольцо с проходами. Сначала зелёные дорожки показывают, где пройти, потом идёт кольцо
    wave(b, dt, p) {
      if (b.t > 0) return;
      if (b.sub === 0) {
        const nG = p.gaps || (b.cnt % 2 ? 2 : 3), side = Math.random() < 0.5 ? -1 : 1;
        const base = b.cnt === 0 ? Math.atan2(Session.AIM.y - b.y, Session.AIM.x - b.x) + side * rnd(0.6, 1.0) : b.waveBase + side * rnd(0.7, 1.2);
        b.waveBase = base; b.waveGaps = Array.from({ length: nG }, (_, i) => base + i * TAU / nG);
        const warn = Math.max(0.55, 0.8 / b.speedMul);
        b.waveX = b.x; b.waveY = b.y; // кольцо пойдёт ровно оттуда, где показаны дорожки
        G.hazards.push({ kind: 'wavewarn', x: b.x, y: b.y, gaps: b.waveGaps, half: Simulation.WAVE_GAP, t: 0, delay: warn - 0.3, dur: warn });
        Sound.sfx.fuse(); b.sub = 1; b.t = warn;
        if (!G.waveTip) { G.waveTip = true; Effects.floatText(Session.AIM.x, Session.AIM.y - 50, '🟢 Беги в зелёный проход!', '#9dffc0', true); }
        return;
      }
      G.hazards.push({ kind: 'wave', x: b.waveX, y: b.waveY, r: 14, spd: p.spd || 230, thick: 24, max: 760, dmg: bdmg(b, 1.4), t: 0, hit: false, gaps: b.waveGaps, half: Simulation.WAVE_GAP });
      Sound.sfx.boom(); G.shake = 6;
      b.cnt++; b.sub = 0;
      if (b.cnt >= (p.n || 2)) endAttack(b, 1.3); else b.t = 0.45 / b.speedMul;
    },
    suck(b, dt, p) {
      if (b.sub === 0) { b.sub = 1; b.dur = p.dur || 2.5; Sound.sfx.laser(); }
      b.dur -= dt;
      const d = Math.hypot(b.x - Session.AIM.x, b.y - Session.AIM.y) || 1;
      if (Session.AIM === P && P.dashT <= 0 && d > b.r) Physics.moveEntity(P, (b.x - Session.AIM.x) / d * 150 * dt, (b.y - Session.AIM.y) / d * 150 * dt);
      if (Math.random() < 0.7) { const a = rnd(0, TAU), r = rnd(120, 260); Effects.part(b.x + Math.cos(a) * r, b.y + Math.sin(a) * r, -Math.cos(a) * 280, -Math.sin(a) * 280, 0.6, 4, '#c8d0e0'); }
      if (b.dur <= 0) { if (p.ring) bossRing(b, 18, 170, bdmg(b), '#b0b0c0'); endAttack(b, 1.1); }
    },
    invert(b, dt, p) {
      if (Session.AIM && Session.AIM !== P && Session.AIM.id) Multiplayer.netEvent(Session.AIM.id, ['inv', p.dur || 2.5]); // заклятие – той, в кого целится босс
      else { G.invertT = p.dur || 2.5; Screens.showBanner('🔄 ПЕРЕВЁРНУТО', 'Управление шиворот-навыворот!'); }
      Sound.sfx.whisper(); G.shake = 6;
      bossRing(b, 12, 150, bdmg(b), '#c08aff');
      endAttack(b, 1.2);
    },
    static(b, dt, p) {
      if (b.sub === 0) { b.sub = 1; b.dur = p.dur || 2.5; if (Session.AIM && Session.AIM !== P && Session.AIM.id) Multiplayer.netEvent(Session.AIM.id, ['stat', b.dur]); else G.staticT = b.dur; Sound.sfx.staticNoise(); }
      b.dur -= dt; b.t -= dt;
      if (b.t <= 0) { b.t = 0.45 / b.speedMul; const a = Math.atan2(Session.AIM.y - b.y, Session.AIM.x - b.x); for (let k = -1; k <= 1; k++) ebullet(b.x, b.y - b.z, a + k * 0.25, 230, bdmg(b), '#e8e8e8', 7, { square: true }); }
      if (b.dur <= 0) endAttack(b, 1.1);
    },
    blizzard(b, dt, p) {
      if (b.sub === 0) { b.sub = 1; b.dur = p.dur || 3; b.t = 0.4; G.blizzardT = Math.max(G.blizzardT || 0, b.dur + 1); Sound.sfx.whisper(); Effects.floatText(b.x, b.y - b.r - 20, '❄️ МЕТЕЛЬ', '#e8f8ff', true); }
      b.dur -= dt; bossMove(b, dt * 0.6);
      if (b.t <= 0) {
        b.t = 0.75 / b.speedMul; const a = Math.atan2(Session.AIM.y - b.y, Session.AIM.x - b.x);
        for (let k = -2; k <= 2; k++) ebullet(b.x, b.y - b.z, a + k * 0.24, 200, bdmg(b), '#e8f8ff', 7);
        Sound.sfx.enemyShot();
      }
      if (b.dur <= 0) endAttack(b, 1.0);
    },
    homing(b, dt, p) {
      const n = p.n || 4;
      for (let k = 0; k < n; k++) ebullet(b.x, b.y - b.z, (k / n) * TAU + b.anim, 125, bdmg(b, 1.2), p.heart ? '#ff3b6b' : '#ff5bf0', 10, { homing: 1.8, life: 5.5, heart: p.heart });
      Sound.sfx.enemyShot(); endAttack(b, 1.6);
    },
    teleport(b, dt, p) {
      if (b.sub === 0) { b.sub = 1; b.t = 0.45; }
      else if (b.sub === 1) {
        b.alpha = clamp(b.t / 0.45, 0, 1);
        if (b.t <= 0) {
          let tx = b.x, ty = b.y;
          for (let k = 0; k < 14; k++) {
            const a = rnd(0, TAU), x = Session.AIM.x + Math.cos(a) * 170, y = Session.AIM.y + Math.sin(a) * 170;
            if (Physics.walkable(x, y, true) && Math.hypot(x - b.hx, y - b.hy) < 380) { tx = x; ty = y; break; }
          }
          b.tx = tx; b.ty = ty; hazardCircle(tx, ty, 80, 0.6, bdmg(b, 1.2), 'dark'); b.sub = 2; b.t = 0.6;
        }
      } else if (b.sub === 2) {
        if (b.t <= 0) { b.x = b.tx; b.y = b.ty; b.alpha = 1; bossRing(b, p.ringN || 14, 175, bdmg(b), '#c77dff', 0, { emoji: b.kind === 'zyama' }); Effects.burst(b.x, b.y, 24, '#c77dff', 220); b.sub = 3; b.t = 0.5; }
      } else if (b.t <= 0) endAttack(b, 0.9);
    },
    mines(b, dt, p) {
      if (b.sub === 0) {
        const n = p.n || 12;
        for (let k = 0; k < n; k++) hazardCircle(Session.AIM.x + rnd(-260, 260), Session.AIM.y + rnd(-260, 260), 52, 1.0 + k * 0.07, bdmg(b, 1.3), 'crystal');
        b.sub = 1; b.t = 1.0 + n * 0.07 + 0.4;
      } else if (b.t <= 0) endAttack(b, 1.0);
    },
    clones(b, dt, p) {
      const n = p.n || 3;
      for (let k = 0; k < n; k++) {
        const a = (k / n) * TAU + rnd(-0.3, 0.3), x = b.hx + Math.cos(a) * 230, y = b.hy + Math.sin(a) * 230;
        if (!Physics.walkable(x, y, true)) continue;
        const e = Enemies.spawnEnemy('zclone', x, y, World.CASTLE.biome, { minion: true, E: b.E });
        e.hp = e.maxHp = b.maxHp / (b.mpX || 1) * 0.035; e.dmg = bdmg(b);
      }
      Screens.speak(b.kind, 'Знакомьтесь – мои клоны! Каждый из них тоже Зямочкккк! 👯');
      Sound.sfx.magic(); endAttack(b, 1.5);
    },
    web(b, dt, p) {
      if (b.t <= 0) {
        const n = p.n || 5, a = Physics.leadAngle(b.x, b.y, 210);
        for (let k = 0; k < n; k++) ebullet(b.x, b.y - b.z, a + (k - (n - 1) / 2) * 0.22, 210, bdmg(b, 0.8), '#e8e0ff', 10, { slow: true });
        Sound.sfx.enemyShot(); b.cnt++; b.t = 0.6; if (b.cnt >= (p.waves || 1)) endAttack(b, 1.0);
      }
    },
    honey(b, dt, p) {
      for (let k = 0; k < (p.n || 4); k++) G.hazards.push({ kind: 'zone', x: Session.AIM.x + rnd(-190, 190), y: Session.AIM.y + rnd(-190, 190), r: 72, t: 0, delay: 0.5, dur: 6, slow: true, fx: p.fx || 'honey' });
      endAttack(b, 1.0);
    },
    cream(b, dt, p) { ATK.honey(b, dt, Object.assign({ fx: 'cream' }, p)); },
    // --- Глава 3 ---
    glitch(b, dt, p) {
      if (b.t <= 0) {
        hazardCircle(b.x, b.y, 70, 0.6, bdmg(b, 1.3), 'glitch');
        let tx = b.x, ty = b.y;
        for (let k = 0; k < 12; k++) {
          const a = rnd(0, TAU), r = rnd(120, 200), x = Session.AIM.x + Math.cos(a) * r, y = Session.AIM.y + Math.sin(a) * r;
          if (Physics.walkable(x, y, b.fly) && Math.hypot(x - b.hx, y - b.hy) < 380) { tx = x; ty = y; break; }
        }
        Effects.burst(b.x, b.y, 16, '#ff3ea5', 180);
        b.x = tx; b.y = ty; Physics.collide(b);
        Effects.burst(b.x, b.y, 16, '#3ff0a0', 180);
        bossRing(b, 8, 170, bdmg(b), '#3ff0a0', rnd(0, 1), { square: true });
        Sound.sfx.blink();
        b.cnt++; b.t = 0.55 / b.speedMul; if (b.cnt >= (p.n || 3)) endAttack(b, 1.0);
      }
    },
    pixels(b, dt, p) {
      if (b.t <= 0) {
        const vertical = p.both ? b.cnt % 2 === 1 : false;
        const gap = Math.floor(rnd(-4, 5));
        for (let k = -9; k <= 9; k++) {
          if (Math.abs(k - gap) <= 1) continue;
          if (!vertical) ebullet(Session.AIM.x + k * 40, Session.AIM.y - 380, Math.PI / 2, 190, bdmg(b), '#3ff0a0', 9, { square: true, life: 4.5 });
          else ebullet(Session.AIM.x - 380, Session.AIM.y + k * 40, 0, 190, bdmg(b), '#ff3ea5', 9, { square: true, life: 4.5 });
        }
        Sound.sfx.enemyShot();
        b.cnt++; b.t = 1.0 / b.speedMul; if (b.cnt >= (p.n || 1) * (p.both ? 2 : 1)) endAttack(b, 1.0);
      }
    },
    sprinkles(b, dt, p) {
      if (b.sub === 0) { b.sub = 1; b.dur = p.dur || 2; b.t = 0; }
      b.dur -= dt;
      if (b.t <= 0) {
        const a = Math.atan2(Session.AIM.y - b.y, Session.AIM.x - b.x);
        for (let k = 0; k < 2; k++) ebullet(b.x, b.y - b.z, a + rnd(-0.9, 0.9), rnd(160, 260), bdmg(b, 0.8), pick(RAINBOW), 5);
        b.t = 0.05; if (Math.random() < 0.3) Sound.sfx.enemyShot();
      }
      if (b.dur <= 0) endAttack(b, 1.0);
    },
    lightning(b, dt, p) {
      if (b.t <= 0) {
        const a = rnd(0, TAU), d = b.cnt === 0 ? 0 : rnd(0, 160);
        hazardCircle(Session.AIM.x + (Session.AIM.vx || 0) * 0.6 + Math.cos(a) * d, Session.AIM.y + (Session.AIM.vy || 0) * 0.6 + Math.sin(a) * d, 50, 0.75, bdmg(b, 1.4), 'bolt');
        b.cnt++; b.t = (p.rate || 0.22) / b.speedMul; if (b.cnt >= (p.n || 8)) endAttack(b, 1.1);
      }
    },
    saws(b, dt, p) {
      const n = p.n || 2, a0 = Math.atan2(Session.AIM.y - b.y, Session.AIM.x - b.x);
      for (let k = 0; k < n; k++) ebullet(b.x, b.y, a0 + (k - (n - 1) / 2) * 0.5, 240, bdmg(b, 1.2), '#c0c0c0', 13, { saw: true, bounce: true, life: 7, hx: b.hx, hy: b.hy });
      Sound.sfx.enemyShot(); endAttack(b, 1.2);
    },
    missiles(b, dt, p) {
      const n = p.n || 4;
      for (let k = 0; k < n; k++) ebullet(b.x, b.y - 20, -Math.PI / 2 + (k - (n - 1) / 2) * 0.45, 175, bdmg(b, 1.2), '#ff6a22', 9, { homing: 2.6, life: 4.5, missile: true });
      Sound.sfx.enemyShot(); endAttack(b, 1.4);
    },
    comments(b, dt, p) {
      if (b.t <= 0) {
        const a = Physics.leadAngle(b.x, b.y, 220);
        for (let k = 0; k < 5; k++) ebullet(b.x, b.y, a + (k - 2) * 0.2, 220, bdmg(b), '#ffffff', 9, { emoji: true, emojiSet: ['💬', '🤬', '💢', '🙄'] });
        Sound.sfx.enemyShot(); b.cnt++; b.t = 0.45 / b.speedMul; if (b.cnt >= (p.waves || 3)) endAttack(b, 1.1);
      }
    },
    toxic(b, dt, p) {
      for (let k = 0; k < (p.n || 4); k++) G.hazards.push({ kind: 'zone', x: Session.AIM.x + rnd(-200, 200), y: Session.AIM.y + rnd(-200, 200), r: 62, t: 0, delay: 0.6, dur: 5, dot: bdmg(b, 0.35), fx: 'toxic' });
      endAttack(b, 1.0);
    },
    mirrors(b, dt, p) {
      const n = p.n || 4;
      let made = 0;
      for (let k = 0; k < n * 3 && made < n; k++) {
        const a = (made / n) * TAU + rnd(-0.3, 0.3), r = rnd(150, 190), x = Session.AIM.x + Math.cos(a) * r, y = Session.AIM.y + Math.sin(a) * r;
        if (!Physics.walkable(x, y, true) || Math.hypot(x - b.hx, y - b.hy) > 420) continue;
        const e = Enemies.spawnEnemy('zmirror', x, y, World.CASTLE.biome, { minion: true, E: b.E, bossPart: b });
        e.hp = e.maxHp = b.maxHp / (b.mpX || 1) * 0.035; e.dmg = bdmg(b); made++;
      }
      if (made) { b.shield = true; b.shieldT = 22; Screens.speak(b.kind, 'Пока зеркала целы – я НЕУЯЗВИМ! Разбей их, если сможешь! 🪞'); Sound.sfx.magic(); }
      endAttack(b, 1.2);
    },
    erupt(b, dt, p) {
      if (b.t <= 0) {
        hazardCircle(Session.AIM.x + rnd(-210, 210), Session.AIM.y + rnd(-210, 210), 62, 0.9, bdmg(b, 1.4), 'erupt');
        b.cnt++; b.t = 0.17 / b.speedMul; if (b.cnt >= (p.n || 8)) endAttack(b, 1.2);
      }
    },
  };

  function updateBoss(b, dt) {
    Session.AIM = NET.host ? Multiplayer.netAim(b.x, b.y) : P;
    if (b.state === 'dead') return;
    if (b.bubble) { b.bubble.t -= dt; if (b.bubble.t <= 0) b.bubble = null; }
    b.anim += dt; if (b.flash > 0) b.flash -= dt; if (b.orbCd > 0) b.orbCd -= dt;
    b.look = Math.atan2(Session.AIM.y - b.y, Session.AIM.x - b.x);
    const WK = NET.host ? Multiplayer.netAim(b.hx, b.hy) : P, dHome = Math.hypot(WK.x - b.hx, WK.y - b.hy); // будит любая героиня
    if (b.state === 'sleep') {
      if (World.CFG.abyss) return; // в Бездне стража будит волна
      if (World.CFG.rush) {
        if (b.id === G.rush.idx && G.rush.wait <= 0 && !G.rush.done && !G.activeBoss) {
          // в раше босс выходит рядом с героиней, а не в дальнем углу арены
          const nx = Session.AIM.x, ny = Session.AIM.y - 300;
          if (Physics.walkable(nx, ny, b.fly)) { b.hx = b.x = nx; b.hy = b.y = ny; }
          startBossFight(b);
        }
        return;
      }
      if (b.def.immortal) return;
      const clueOk = !World.CFG.detective || b.final || (G.clues5[b.id] || 0) >= 3;
      if (!clueOk && dHome < 330 && G.clueMsgT <= 0) { G.clueMsgT = 3; Effects.floatText(b.x, b.y - b.r - 20, `🔎 Сначала найди улики: ${G.clues5[b.id] || 0}/3`, '#ffd25a', true); }
      const can = (!b.final || (World.gateOpen && (Physics.playerInCastle() || Multiplayer.netMateInCastle()))) && clueOk;
      if (can && dHome < 330 && !G.activeBoss) startBossFight(b);
      return;
    }
    if (dHome > 1000 && !World.CFG.rush && !G.td) { resetBoss(b); return; } // в обороне страж идёт к кристаллу сам, где бы ни была героиня
    const stages = b.def.stages;
    if (b.mode !== 'trans' && b.stage < stages.length - 1 && b.hp <= b.maxHp * stages[b.stage + 1].at) startStage(b, b.stage + 1);
    if (b.burnT > 0) {
      b.burnT -= dt; b.burnTick -= dt;
      if (b.burnTick <= 0) { b.burnTick = 0.4; damageBoss(b, { v: b.burnDps * 0.4, crit: false }, true); if (b.state !== 'fight') return; }
    }
    if (b.shield) {
      b.shieldT -= dt;
      if (b.shieldT <= 0) { for (const o of G.enemies) if (o.bossPart === b) Enemies.killEnemy(o, true); bossPartDestroyed(b); b.stunT = 1.2; }
    }
    if (b.stunT > 0) {
      b.stunT -= dt;
      if (Math.random() < 0.3) Effects.part(b.x + rnd(-b.r, b.r), b.y - b.r - 10, 0, -30, 0.6, 4, '#ffe04a');
      return;
    }
    b.t -= dt;
    if (b.mode === 'trans') {
      if (Math.random() < 0.5) Effects.part(b.x + rnd(-b.r, b.r), b.y + rnd(-b.r, b.r), rnd(-40, 40), rnd(-120, -40), 0.7, 5, pick(['#ffffff', '#ffd25a', '#ff3ea5']));
      if (b.t <= 0) { b.inv = false; endAttack(b, 0.6); }
    } else if (b.mode === 'idle') { bossMove(b, dt); if (b.t <= 0) nextAttack(b); }
    else ATK[b.mode](b, dt, b.p);
    if (b.def.lines.taunts && b.mode !== 'trans') {
      b.tauntT -= dt;
      if (b.tauntT <= 0) { b.tauntT = rnd(9, 14); b.bubble = { text: pick(b.def.lines.taunts), t: 3.6 }; }
    }
    if (b.z < 10 && b.alpha > 0.5) {
      const d = Math.hypot(P.x - b.x, P.y - b.y); // по подругам бьёт их телефон
      if (!P.down && d < b.r + P.r - 4) Hero.hurtPlayer(b.charging ? b.cdmg * 1.6 : b.cdmg, b.x, b.y);
    }
  }
  function damageBoss(b, hit, dot, remote) {
    if (b.state !== 'fight' || b.alpha < 0.3 || b.z > 30) return false;
    if (NET.client && !b.inv && !b.shield && !b.def.immortal) {
      const v = hit.v * (b.stunT > 0 ? 1.5 : 1) * Math.pow(1 + 0.12, Actors.lv('c1guard')) * Math.pow(1 + 0.08, Actors.talent('boss')) * (G.td && G.abyss && !Defense.TD_HIT ? P.oldKb || 1 : 1); // в обороне стражу – прежний урон героини (башни – как есть)
      NET.bhits.push([Session.bosses.indexOf(b), Math.round(v), hit.crit ? 1 : 0, dot ? 1 : 0]);
      if (!dot) b.flash = 0.08; Hero.addSuper(v / Math.max(1, b.maxHp / (b.mpX || 1)) * 150);
      if (!dot) Effects.dmgText(b.x + rnd(-15, 15), b.y - b.r - 10, v, '#ffd25a', hit.crit);
      if (G.st) G.st.dmgDealt += v;
      return true;
    }
    if (b.inv) { if (Math.random() < 0.08) Effects.floatText(b.x, b.y - b.r - 14, 'неуязвим', '#aaaaaa'); return false; }
    if (b.shield) { if (Math.random() < 0.06) Effects.floatText(b.x, b.y - b.r - 14, 'зеркальный щит!', '#bfeaff'); return false; }
    if (b.def.immortal) { if (Math.random() < 0.08) Effects.floatText(b.x + rnd(-20, 20), b.y - b.r - 14, '∞', '#ff3ea5', true); Hero.addSuper(0.3); return false; }
    const v = remote ? hit.v : hit.v * (b.stunT > 0 ? 1.5 : 1) * Math.pow(1 + 0.12, Actors.lv('c1guard')) * Math.pow(1 + 0.08, Actors.talent('boss')) * (G.td && G.abyss && !Defense.TD_HIT ? P.oldKb || 1 : 1); // в обороне стражу – прежний урон героини (башни – как есть)
    if (G.st && !remote) G.st.dmgDealt += v;
    b.hp -= v; if (!dot) b.flash = 0.08;
    if (!remote) Hero.addSuper(v / (b.maxHp / (b.mpX || 1)) * 150);
    if (dot) { if (Math.random() < 0.4) Effects.floatText(b.x + rnd(-20, 20), b.y - b.r, String(Math.round(v)), '#ff8a2a'); }
    else Effects.dmgText(b.x + rnd(-15, 15), b.y - b.r - 10, v, '#ffd25a', hit.crit);
    if (b.hp <= 0) bossDefeated(b);
    return true;
  }
  function bossPartDestroyed(b) {
    if (!b.shield) return;
    const left = b.shieldT > 0 && G.enemies.some(o => o.bossPart === b && !o.dead);
    if (left) return;
    b.shield = false; b.stunT = 2.8;
    Screens.showBanner('Щит разбит!', 'Бей, пока он оглушён!');
    Sound.sfx.glass(); G.shake = 12; Effects.burst(b.x, b.y, 40, '#bfeaff', 300);
    Screens.speak(b.kind, 'Мои зеркала!!! Это был эксклюзивный декор! 😱');
  }
  // звезда – за каждого босса, один раз навсегда
  function awardStar(b) {
    if (typeof World.CHN !== 'number') return;
    const prof = Saves.loadProfile(); prof.starsGot = prof.starsGot || {};
    const key = World.CHN + ':' + b.id;
    if (prof.starsGot[key]) return;
    prof.starsGot[key] = 1; prof.stars = Object.keys(prof.starsGot).length; Saves.saveProfile(prof);
    setTimeout(() => { Effects.floatText(P.x, P.y - 64, '⭐ +1 звезда для талантов!', '#ffd25a', true); Sound.sfx.superReady(); }, 1400);
    if (G.st) G.st.stars = (G.st.stars || 0) + 1;
  }
  function bossDefeated(b) {
    if (G.st && G.st.cur) { const c = G.st.cur; G.st.bosses.push({ k: c.k, n: c.n, pl: c.pl, bl: c.bl, t: Math.round(G.st.time - c.t0), d: c.d, h: c.h || 0, df: c.df || G.diffId }); G.st.cur = null; }
    b.state = 'dead'; b.hp = 0; G.defeated[b.id] = true; G.activeBoss = null; G.invertT = 0; G.staticT = 0;
    G.hazards.length = 0; G.ebullets.length = 0; G.beams.length = 0;
    for (const e of G.enemies) if (e.minion) Enemies.killEnemy(e, true);
    Effects.burst(b.x, b.y, 80, '#ffd25a', 400); Effects.burst(b.x, b.y, 50, '#ff7a2f', 280); Effects.shockRing(b.x, b.y, '#ffd25a', 400);
    G.shake = 20; Sound.sfx.boom(); Sound.sfx.win(); Challenges.buzz(160);
    Screens.speak(b.kind, b.def.lines.death, 4);
    Achievements.life('bosses'); Collection.bookKill('b', b.kind); if (!G.bossHurt) Achievements.life('noHit'); Challenges.dailyAdd(500);
    if (!P.down && P.hp > 0 && P.hp < P.maxHp * 0.05) Achievements.lifeMax('clutch', 1);
    if (b.final && !G.bossHurt && G.diffId === 'hard' && typeof World.CHN === 'number' && World.CHN >= 5 && !World.CFG.rush && !World.CFG.abyss) Achievements.lifeMax('untouch', 1);
    const nG = 24, gemV = Actors.xpFor(b.E) * 3.2 * xpGap(P.level, b.E) / nG * (G.td ? 0.12 : 1); // в обороне опыт идёт от волн, страж не должен разом поднимать на десяток уровней
    for (let i = 0; i < nG; i++) Effects.dropGem(b.x + rnd(-70, 70), b.y + rnd(-70, 70), gemV);
    for (let i = 0; i < 8 + b.id * 2; i++) Effects.dropShard(b.x + rnd(-60, 60), b.y + rnd(-60, 60));
    Effects.dropPickup(b.x + 30, b.y, 'heart'); Effects.dropPickup(b.x - 30, b.y, 'heart'); Effects.dropPickup(b.x, b.y + 30, 'magnet'); if (!b.final && !World.CFG.rush && !World.CFG.abyss) Effects.dropPickup(b.x - 50, b.y + 20, 'key');
    G.cp = { x: b.hx, y: b.hy };
    if (World.CFG.abyss) { Challenges.abyssBossDown(b); return; }
    if (World.CFG.rush) { Challenges.rushBossDown(b); return; }
    awardStar(b);
    if (!b.final && Actors.talent('heal')) {
      P.hp = P.maxHp; if (G.team) for (const id of G.team.list) { G.team.f[id] = 1; G.team.ko[id] = false; }
      Effects.floatText(P.x, P.y - 70, '🩹 Передышка: здоровье полное', '#7dff9a', true);
    }
    if (!b.final && b.calmBiome >= 0 && G.calm[b.calmBiome] === undefined) {
      G.calm[b.calmBiome] = 0;
      setTimeout(() => { if (Session.state === 'play' && !G.activeBoss) Screens.showBanner('🕊️ Усмирение I', 'Враги тут слабее на 10%. Охоться здесь – до −30% и награды'); }, 5000);
    }
    if (!b.final) {
      setTimeout(() => { if (Session.state === 'play') Screens.showBanner('Страж повержен!', b.name); }, 300);
      const done = guardiansDone(), total = guardiansCount();
      if (done >= total && !World.gateOpen) {
        World.gateOpen = true;
        Screens.say(World.CHN === 1 ? 'Все стражи побеждены! Ворота замка открыты – спаси меня!' : World.CFG.gateSay || 'Все стражи пали! Ворота Кринж-Цитадели открыты! Скорее!!!');
        setTimeout(() => { if (Session.state === 'play') { Screens.showBanner('Ворота открыты!', World.CHN === 1 ? 'Тёмный замок ждёт' : World.CFG.gateBanner || 'Кринж-Цитадель ждёт'); Sound.sfx.gate(); } }, 3000);
        if (World.CFG.detective) G.boardPending = true;
      } else Screens.say(`Осталось стражей: ${total - done}. Иди по стрелке!`);
      Encounters.biomeMusic(true);
      Saves.saveGame();
    } else Story.startVictoryCutscene();
  }

  return {
    makeBosses, guardiansCount, guardiansDone, startBossFight, resetBoss, ebullet, shotPuff,
    hazardCircle, updateBoss, damageBoss, bossPartDestroyed, awardStar,
  };
})();
