'use strict';

const Viewport = (() => {
  // ------------------------------------------------------------------
  //  Экран
  // ------------------------------------------------------------------
  const canvas = $('game');
  const ctx = canvas.getContext('2d');
  let VW = 0, VH = 0, DPR = 1, ZOOM = 1, SAFE_TOP = 0, ZK = 1; // ZK – обзор: в обороне камера отъезжает
  const safeProbe = document.createElement('div');
  safeProbe.style.cssText = 'position:fixed;top:0;left:0;height:0;padding-top:env(safe-area-inset-top,0px);visibility:hidden';
  document.body.appendChild(safeProbe);
  function resize() {
    DPR = Math.min(window.devicePixelRatio || 1, 2);
    VW = window.innerWidth; VH = window.innerHeight;
    canvas.width = Math.round(VW * DPR); canvas.height = Math.round(VH * DPR);
    canvas.style.width = VW + 'px'; canvas.style.height = VH + 'px';
    ZOOM = clamp(Math.min(VW, VH) / 370, 0.85, 2) * ZK;
    SAFE_TOP = parseFloat(getComputedStyle(safeProbe).paddingTop) || 0;
  }
  function setZoomFactor(factor) {
    if (ZK === factor) return;
    ZK = factor;
    resize();
  }
  window.addEventListener('resize', resize);
  resize();

  return {
    canvas, ctx, setZoomFactor,
    get VW() { return VW; },
    get VH() { return VH; },
    get DPR() { return DPR; },
    get ZOOM() { return ZOOM; },
    get SAFE_TOP() { return SAFE_TOP; },
  };
})();
