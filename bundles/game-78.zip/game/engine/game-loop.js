'use strict';

const GameLoop = (() => {
  // ------------------------------------------------------------------
  //  Отладка (?debug)
  // ------------------------------------------------------------------
  const DEBUG = /[?&]debug/.test(location.search);
  function teleport(i) {
    const b = Session.bosses[i];
    if (b.final) {
      for (let k = 0; k < Session.bosses.length - 1; k++) { G.defeated[k] = true; Session.bosses[k].state = 'dead'; }
      World.gateOpen = true; P.x = b.hx; P.y = b.hy + 220;
    } else { P.x = b.hx - 200; P.y = b.hy; }
  }
  function debugKey(code) {
    const m = code.match(/^Digit([1-5])$/);
    if (m && Session.bosses[+m[1] - 1]) teleport(+m[1] - 1);
    if (code === 'KeyK' && G.activeBoss) { G.activeBoss.inv = false; Bosses.damageBoss(G.activeBoss, { v: G.activeBoss.hp + 1, crit: false }); }
    if (code === 'KeyJ' && G.activeBoss) { const b = G.activeBoss; const st = b.def.stages[b.stage + 1]; if (st) b.hp = b.maxHp * st.at - 1; }
    if (code === 'KeyL') Hero.gainXp(P.xpNext);
    if (code === 'KeyG') P.inv = 9999;
  }

  // ------------------------------------------------------------------
  //  Главный цикл
  // ------------------------------------------------------------------
  const pausedWorldScreens = new Set(['menu', 'victory', 'dead', 'intro', 'splash', 'mp']);
  const ownCanvasScreens = new Set(['intro', 'teaser', 'splash', 'krill']);
  let lastT = performance.now();

  function updateFrame(now, dt) {
    try {
      Multiplayer.netTick(dt);
    } catch (e) {
      console.error(e);
    }

    // Вместе мир продолжает жить под экраном выбора улучшений.
    const coopActive = NET.on && G.netRun;
    const netLive = coopActive && !pausedWorldScreens.has(Session.state);
    if (inRun()) liveTick(dt);
    if (coopActive && Session.state === 'play' && now - (G.coopT || 0) > 15000) {
      G.coopT = now;
      Saves.coopSave();
    }
    // Игрок вернулся с экрана выбора улучшения во время общей паузы.
    if (NET.on && NET.paused && Session.state === 'play') Screens.pauseGame(false, NET.pauseBy);
    if (NET.on && NET.paused) return;
    if (Session.state !== 'play' && Session.state !== 'dying' && !netLive) return;

    try {
      Controls.pollKeys();
      if (Session.state === 'play' && Screens.Dialog.talking && !NET.on) Screens.Dialog.update(dt);
      else Simulation.update(dt);
    } catch (e) {
      logErr(e, 'update');
    }
  }

  function renderFrame(now) {
    const screen = Session.state;
    if (ownCanvasScreens.has(screen) || !World.tiles) return;
    // За окнами меню фон движется с частотой около 30 кадров/с.
    const background = G.inMenu && screen !== 'play' && screen !== 'dying';
    if (background && now - (G.bgT || 0) <= 30) return;

    try {
      if (background) {
        G.bgT = now;
        Session.state = 'menu';
        Simulation.updateCamera();
      }
      Viewport.ctx.setTransform(1, 0, 0, 1, 0, 0);
      Renderer.renderWorld();
      HUD.paperPass();
    } catch (e) {
      logErr(e, 'render');
      if (Viewport.ctx.reset) Viewport.ctx.reset();
    } finally {
      Session.state = screen;
    }
    if (background) return;
    try {
      HUD.renderHUD();
    } catch (e) {
      logErr(e, 'hud');
      if (Viewport.ctx.reset) Viewport.ctx.reset();
    }
  }

  function loop(now) {
    const dt = Math.min(0.05, (now - lastT) / 1000);
    lastT = now;
    updateFrame(now, dt);
    renderFrame(now);
    requestAnimationFrame(loop);
  }

  // журнал ошибок: последние 8 разных – попадают в «Статистику», чтобы их можно было прислать
  const ERR_KEY = 'krilessa_errlog', errSeen = new Set();
  function logErr(e, where) {
    try {
      if (where !== 'bg' && where !== 'crash' && where !== 'android') console.error(e); // записи чёрного ящика – не ошибки страницы
      const msg = String((e && e.message) || e).slice(0, 160), key = where + '|' + msg;
      if (errSeen.has(key)) return; errSeen.add(key);
      const stack = String((e && e.stack) || '').split('\n').slice(1, 3).map(x => x.trim().replace(/https?:\/\/[^/]+\/(assets\/game\/)?/g, '')).join(' < ');
      const L = GameStorage.readList(ERR_KEY);
      L.unshift({ at: Date.now(), v: VERSION, w: where, st: Session.state, ch: World.CHN, m: msg, s: stack.slice(0, 220) });
      GameStorage.write(ERR_KEY, L.slice(0, 8));
    } catch (x) { /* ignore */ }
  }
  // подсказка после запуска: ждёт, пока на экране меню и не висит другая подсказка
  function bootToast(msg, tries = 5) {
    setTimeout(() => {
      const calm = ['splash', 'menu', 'whatsnew'].includes(Session.state), busy = !$('toast').classList.contains('hidden');
      if (calm && !busy) RunStats.toast(msg); else if (tries > 0) bootToast(msg, tries - 1);
    }, tries === 5 ? 2500 : 2200);
  }
  const errLog = () => GameStorage.readList(ERR_KEY);
  // чёрный ящик: пока идёт забег, раз в 5 с запоминаем, где мы и сколько всего вокруг.
  // Если приложение закроется посреди боя, при следующем запуске это попадёт в журнал сбоев
  const LIVE_KEY = 'krilessa_live';
  let liveT = 0;
  function liveWrite(bg) {
    try {
      const mem = performance.memory ? Math.round(performance.memory.usedJSHeapSize / 1048576) : 0;
      GameStorage.write(LIVE_KEY, { at: Date.now(), v: VERSION, ch: G.td ? 'def' : World.CHN, st: Session.state, w: G.abyss ? G.abyss.wave : 0, lv: P.level, en: G.enemies.length, pt: G.parts.length,
        b: G.activeBoss ? G.activeBoss.kind : '', mb: mem, t: Math.round((G.abyss && G.abyss.t) || (G.st && G.st.time) || 0), net: NET.on ? 1 : 0, bg: !!bg });
    } catch (e) { /* ignore */ }
  }
  function liveTick(dt) { liveT -= dt; if (liveT <= 0) { liveT = 5; liveWrite(false); } }
  const liveClear = () => GameStorage.remove(LIVE_KEY);
  const inRun = () => !G.inMenu && !!G.st;
  // запуск: прошлый раз игра закрылась посреди забега?
  function liveCheck() {
    const m = GameStorage.readRecord(LIVE_KEY);
    liveClear();
    if (!m || !m.at) return null;
    const where = m.ch === 'def' ? `оборона, волна ${m.w}` : m.ch === 'abyss' ? `Бездна, волна ${m.w}` : m.ch === 'rush' ? 'босс-раш' : `глава ${m.ch}`;
    logErr(`${m.bg ? 'Игра закрыта, пока была свёрнута' : 'Игра закрылась посреди боя'}: ${where}${m.b ? ', бой с ' + m.b : ''} · экран ${m.st} · ур. ${m.lv} · врагов ${m.en} · частиц ${m.pt}` +
      `${m.mb ? ' · память ' + m.mb + ' МБ' : ''}${m.net ? ' · вместе' : ''} · ${RunStats.fmtT(m.t)} от начала · v${m.v}`, m.bg ? 'bg' : 'crash');
    return m;
  }
  window.addEventListener('error', e => logErr(e.error || e.message, 'win'));
  window.addEventListener('unhandledrejection', e => logErr(e.reason, 'promise'));

  return {
    DEBUG, teleport, debugKey, loop, logErr, bootToast, errLog, liveWrite, liveClear, inRun,
    liveCheck,
  };
})();
