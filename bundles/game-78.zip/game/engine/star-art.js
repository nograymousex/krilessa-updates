'use strict';

const StarArt = (() => {
  const ink = '#19203e', turquoise = '#81eddf', gold = '#ffd783';
  const groundSprites = [];
  const nodeTitles = ['Звезда 1/3', 'Звезда 2/3', 'Звезда 3/3'];
  let bloom;
  let collection = null, impact = null;

  // Узкие грани розы ветров читаются и на каменном диске, и на мини-карте.
  const rose = new Path2D();
  const bright = new Path2D();
  for (let i = 0; i < 8; i++) {
    const angle = i * Math.PI / 4 - Math.PI / 2;
    const outer = i % 2 ? 0.53 : i % 4 ? 0.79 : 1;
    const x = Math.cos(angle) * outer, y = Math.sin(angle) * outer;
    const nx = Math.cos(angle + Math.PI / 8) * 0.23, ny = Math.sin(angle + Math.PI / 8) * 0.23;
    if (!i) rose.moveTo(x, y); else rose.lineTo(x, y);
    rose.lineTo(nx, ny);
    bright.moveTo(0, 0); bright.lineTo(x, y); bright.lineTo(nx, ny); bright.closePath();
  }
  rose.closePath();

  function roseAt(c, x, y, radius, face, glint) {
    c.save();
    c.translate(x, y); c.scale(radius, radius);
    c.fillStyle = face; c.fill(rose);
    c.fillStyle = glint; c.fill(bright);
    c.restore();
  }

  function circle(c, x, y, radius) {
    c.beginPath(); c.arc(x, y, radius, 0, TAU);
  }

  function halo(c, x, y, w, h, alpha) {
    if (!bloom) {
      bloom = makeCanvas(128, 128);
      const b = bloom.getContext('2d');
      const g = b.createRadialGradient(64, 64, 0, 64, 64, 64);
      g.addColorStop(0, '#ebfffa'); g.addColorStop(0.13, '#b4fff0');
      g.addColorStop(0.34, 'rgba(85,228,214,.58)');
      g.addColorStop(0.68, 'rgba(94,102,220,.26)'); g.addColorStop(1, 'rgba(80,74,200,0)');
      b.fillStyle = g; b.fillRect(0, 0, 128, 128);
    }
    c.save(); c.globalAlpha *= alpha;
    c.drawImage(bloom, x - w / 2, y - h / 2, w, h); c.restore();
  }

  // Латунное кольцо, градусы и насечки запекаем один раз для каждого состояния.
  function groundSprite(state) {
    if (groundSprites[state]) return groundSprites[state];
    const cv = makeCanvas(200, 156), c = cv.getContext('2d');
    c.translate(100, 81); c.scale(2, 1.02);
    halo(c, 0, 0, 100, 110, state === 1 ? 0.86 : 0.36);
    c.fillStyle = 'rgba(16,17,33,.43)'; circle(c, 0, 5, 31); c.fill();
    c.fillStyle = '#59445a'; circle(c, 0, 2.3, 30); c.fill();
    const enamel = c.createLinearGradient(-16, -23, 18, 24);
    enamel.addColorStop(0, '#4a5678'); enamel.addColorStop(0.45, '#283657'); enamel.addColorStop(1, '#181f39');
    c.fillStyle = enamel; circle(c, 0, 0, 29.5); c.fill();
    c.strokeStyle = state === 0 ? '#818da4' : gold; c.lineWidth = 1.4; c.stroke();
    circle(c, 0, 0, 25); c.lineWidth = 0.7; c.stroke();
    c.strokeStyle = state === 0 ? '#82969b' : '#a8e6db';
    for (let i = 0; i < 24; i++) {
      const a = i * TAU / 24, r = i % 3 === 0 ? 22 : 24;
      c.beginPath(); c.moveTo(Math.cos(a) * r, Math.sin(a) * r);
      c.lineTo(Math.cos(a) * 27.5, Math.sin(a) * 27.5); c.stroke();
    }
    roseAt(c, 0, 0, 19, state === 2 ? '#d9a052' : '#536683', state === 2 ? gold : '#7e99aa');
    groundSprites[state] = cv;
    return cv;
  }

  function ground(c, trail, vis, time) {
    for (let i = 0; i < trail.stars.length; i++) {
      const node = trail.stars[i];
      if (!vis(node.x, node.y, 120)) continue;
      const state = i < trail.collected ? 2 : i === trail.collected ? 1 : 0;
      c.drawImage(groundSprite(state), node.x - 50, node.y - 40.5, 100, 78);
    }
    const next = trail.stars[trail.collected];
    if (!next || G.activeBoss || G.cutscene || G.hidden) return;
    const dx = next.x - P.x, dy = next.y - P.y, length = Math.hypot(dx, dy);
    if (length < 74) return;
    // След на земле намеренно короткий: он указывает азимут и не закрывает противников.
    c.save();
    const reach = Math.min(length - 30, 152);
    const phase = (time * 0.53) % 1;
    for (let i = 0; i < 4; i++) {
      const t = (i + phase) / 4, d = 34 + t * (reach - 34);
      c.globalAlpha = Math.sin(t * Math.PI) * 0.84;
      roseAt(c, P.x + dx * d / length, P.y + 5 + dy * d / length, 2.9 + t * 1.7, '#418a95', '#e2fff3');
    }
    c.restore();
  }

  function beacons(c, trail, vis, time) {
    for (let i = 0; i < trail.stars.length; i++) {
      const node = trail.stars[i], x = node.x, y = node.y;
      if (!vis(x, y, 110)) continue;
      const active = i === trail.collected, done = i < trail.collected;
      const t = time + i * 2.1, bob = Math.sin(t * 2.5);
      const cy = y - (active ? 32 + bob * 3 : done ? 10 : 16 + bob);
      c.save();
      if (active) {
        halo(c, x, y - 28, 152, 135, 0.58 + bob * 0.09);
        c.strokeStyle = 'rgba(167,253,240,.64)'; c.lineWidth = 1.1;
        c.beginPath(); c.ellipse(x, cy, 22, 7.5, -0.45, 0, TAU); c.stroke();
        c.beginPath(); c.ellipse(x, cy, 18, 12, 0.7, 0.15, Math.PI * 1.08); c.stroke();
        for (let j = 0; j < 5; j++) {
          const ph = (t * 0.47 + j / 5) % 1;
          const sx = x + Math.cos(t * 1.1 + j * 2.4) * (7 + ph * 8);
          c.globalAlpha = Math.sin(ph * Math.PI) * 0.85;
          roseAt(c, sx, y - 9 - ph * 53, 2.3, turquoise, '#ffffe9');
        }
      }
      c.globalAlpha = done ? 0.82 : 1;
      const size = active ? 19.5 : done ? 7 : 11;
      roseAt(c, x, cy, size + 1.8, ink, ink);
      roseAt(c, x, cy, size, active || done ? '#e9a443' : '#637992', active || done ? '#fff3ba' : '#b0cfcb');
      if (active) {
        const a = t * 1.7;
        roseAt(c, x + Math.cos(a) * 19, cy + Math.sin(a) * 8 - Math.cos(a) * 7, 3.5, turquoise, '#fffbd7');
        if (!G.activeBoss && vis(x, cy, -12)) {
          const halfView = Viewport.VW / Viewport.ZOOM / 2;
          const side = x < P.x ? -1 : 1;
          const labelX = clamp(x + side * 53, G.cam.x - halfView + 36, G.cam.x + halfView - 36);
          c.fillStyle = 'rgba(25,32,62,.92)';
          roundRect(c, labelX - 32, cy + 1, 64, 14, 7); c.fill();
          c.fillStyle = '#fff1cb'; c.font = 'bold 10px Krilessa Icons, sans-serif';
          c.textAlign = 'center'; c.textBaseline = 'middle';
          c.fillText(nodeTitles[i], labelX, cy + 8);
        }
      }
      c.restore();
    }
    if (collection && collection.trail === trail) drawFlash(c, collection, time, false);
  }

  function drawFlash(c, flash, time, shield) {
    const t = (time - flash.at) / (shield ? 0.73 : 0.98);
    if (t < 0 || t >= 1) return;
    c.save();
    const r = 12 + Math.sqrt(t) * (shield ? 43 : 35);
    const x = shield ? P.x : flash.x, y = shield ? P.y - 12 : flash.y - 17;
    c.globalAlpha = (1 - t) * 0.88;
    halo(c, x, y, r * 2.8, r * 2.7, (1 - t) * 0.7);
    c.strokeStyle = shield ? turquoise : gold; c.lineWidth = 2.1 * (1 - t) + 0.5;
    for (let i = 0; i < 8; i++) {
      const a = i * TAU / 8 + 0.2 + t * 0.23;
      c.beginPath(); c.arc(x, y, r, a, a + (1 - t) * 0.43); c.stroke();
      roseAt(c, x + Math.cos(a) * (r + t * 10), y + Math.sin(a) * (r + t * 10),
        4.5 * (1 - t) + 1, shield ? turquoise : gold, '#fffbe6');
    }
    c.restore();
  }

  function shield(c, trail, x, y, time, front) {
    if (trail.shield) {
      c.save(); c.translate(x, y - 10); c.rotate(-0.28);
      if (!front) halo(c, 0, 0, 83, 75, 0.22);
      const start = front ? 0 : Math.PI;
      c.strokeStyle = front ? 'rgba(255,222,145,.86)' : 'rgba(126,233,224,.78)';
      c.lineWidth = front ? 1.6 : 1.1;
      c.beginPath(); c.ellipse(0, 0, 28, 12, 0, start, start + Math.PI); c.stroke();
      for (let i = 0; i < 3; i++) {
        const a = time * 1.8 + i * TAU / 3;
        if ((Math.sin(a) >= 0) !== front) continue;
        const sx = Math.cos(a) * 28, sy = Math.sin(a) * 12;
        roseAt(c, sx, sy, 6.4, ink, ink);
        roseAt(c, sx, sy, 5.1, i === 0 ? gold : turquoise, '#ffffdf');
      }
      c.restore();
    }
    if (front && impact && impact.trail === trail) drawFlash(c, impact, time, true);
  }

  function mapMark(c, x, y, radius, active, done) {
    c.save();
    c.fillStyle = ink; c.strokeStyle = active ? gold : done ? turquoise : '#91a0bf';
    c.lineWidth = active ? 1.55 : 0.9;
    circle(c, x, y, radius); c.fill(); c.stroke();
    roseAt(c, x, y, radius * 0.83, active ? '#eba139' : done ? '#62bdb7' : '#8596ac', active ? '#fff2aa' : done ? '#cbfff0' : '#bccbd6');
    c.restore();
  }

  function collected(x, y) { collection = { trail: StarTrail.view(), x, y, at: G.time }; }
  function shieldHit() { impact = { trail: StarTrail.view(), at: G.time }; }
  return { ground, beacons, shield, mapMark, collected, shieldHit };
})();
