'use strict';

const StarTrail = (() => {
  const COUNT = 3;
  const ROUTE_LENGTH = 32;
  const directions = [[0, -1], [-1, 0], [1, 0], [0, 1]];
  let trail = null;
  let recorded = false;

  // Находим короткий путь по соседним проходимым клеткам в сторону первого стража.
  // Используем исходную карту с закрытыми воротами, до восстановления растаявшего льда.
  function placeStars() {
    const reserved = new Set();
    for (const group of [World.chests, World.shrines, World.shelves, World.boxes, World.beds,
      World.lamps, World.npcs, World.clues, World.qitems, World.drifts, World.fires,
      World.holes, World.ovens, World.pearls]) {
      for (const object of group) reserved.add(Math.floor(object.y / World.T) * World.MW + Math.floor(object.x / World.T));
    }
    const start = World.START, guardian = World.CFG.bossTiles[0];
    const origin = { x: start.x, y: start.y, depth: 0, road: 0, parent: null };
    const queue = [origin], seen = new Map([[start.y * World.MW + start.x, origin]]);
    let best = origin, bestScore = Infinity;
    for (let i = 0; i < queue.length; i++) {
      const node = queue[i];
      const score = Math.hypot(node.x - guardian.x, node.y - guardian.y) - node.road;
      if (node.depth > best.depth || (node.depth === best.depth && score < bestScore)) {
        best = node;
        bestScore = score;
      }
      if (node.depth === ROUTE_LENGTH) continue;
      for (const [dx, dy] of directions) {
        const x = node.x + dx, y = node.y + dy;
        if (!World.inMap(x, y) || y >= World.PLAY_H) continue;
        const key = y * World.MW + x;
        const existing = seen.get(key), depth = node.depth + 1;
        if ((existing && existing.depth < depth) || reserved.has(key) || World.treeGrid[key]) continue;
        const tile = World.tileAt(x, y);
        if (tile === FLOOR || tile === GATE || World.isSolidTile(x, y, false)) continue;
        // На равноценных пеших маршрутах предпочитаем дорогу, которую проложил генератор этой главы.
        const road = node.road + (tile === PATH || tile === STONE ? 1 : 0);
        if (!existing) {
          const next = { x, y, parent: node, depth, road };
          seen.set(key, next);
          queue.push(next);
        } else if (road > existing.road) {
          existing.road = road;
          existing.parent = node;
        }
      }
    }
    const route = [];
    for (let node = best; node.parent; node = node.parent) route.push(node);
    route.reverse();
    if (route.length < COUNT) return [];
    // Обычно это 4, 17 и 32 пеших шага от старта. Поддерживаем и короткие маршруты.
    const first = Math.min(3, Math.floor(route.length / 6));
    return [first, Math.floor(route.length / 2), route.length - 1].map(i => ({
      x: World.tc(route[i].x), y: World.tc(route[i].y),
    }));
  }

  function reset() { trail = null; recorded = false; }

  function syncProfile() {
    if (!trail || trail.collected < COUNT || recorded) return;
    const profile = Saves.loadProfile();
    if (!profile.atlas || typeof profile.atlas !== 'object' || Array.isArray(profile.atlas)) profile.atlas = {};
    if (profile.atlas[World.CHN] === true) {
      recorded = true;
    } else {
      profile.atlas[World.CHN] = true;
      recorded = Saves.saveProfile(profile);
    }
  }

  function start(saved) {
    reset();
    if (NET.on || G.daily || (G.mut && Object.keys(G.mut).length) || !Session.CH_NUMS.includes(World.CHN)) return;
    const stars = placeStars();
    if (stars.length !== COUNT) return;
    const step = saved && saved.collected;
    const collected = Number.isInteger(step) && step >= 0 && step <= COUNT ? step : 0;
    trail = { stars, collected, shield: collected === COUNT && saved.shield === true };
    // Если игру закрыли между записью слота и записью профиля, восстанавливаем созвездие.
    if (collected === COUNT) syncProfile();
  }

  function view() { return G.inMenu || NET.on ? null : trail; }

  function snapshot() {
    return trail ? { collected: trail.collected, shield: trail.shield } : null;
  }

  function update() {
    if (!view() || trail.collected === COUNT || Session.state !== 'play' || P.down || G.jump || G.hidden || G.activeShrine) return;
    const star = trail.stars[trail.collected];
    if (Math.hypot(P.x - star.x, P.y - star.y) > P.r + 18) return;
    trail.collected++;
    trail.shield = trail.collected === COUNT;
    Saves.saveGame();
    if (trail.shield) syncProfile();
    StarArt.collected(star.x, star.y);
    Sound.sfx.atlasStar(trail.collected);
    if (trail.shield) {
      RunStats.toast('Созвездие в атласе! Звёздный щит поглотит один удар.');
    } else {
      Effects.floatText(star.x, star.y - 24, '✦ ' + trail.collected + ' / ' + COUNT, '#ffe5a2', true);
    }
  }

  function absorb() {
    if (!trail || !trail.shield || NET.on) return false;
    trail.shield = false;
    P.inv = 0.5;
    Saves.saveGame();
    StarArt.shieldHit();
    Effects.floatText(P.x, P.y - 36, 'Звёздный щит!', '#ffe5a2', true);
    Sound.sfx.atlasShieldBreak();
    return true;
  }

  return { reset, start, update, absorb, view, snapshot, syncProfile };
})();
