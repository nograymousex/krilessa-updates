'use strict';

// Текстуры открытых зелёных локаций. Всё запекается до отрисовки готового чанка.
const Woodland = (() => {
  const paints = {
    forest: { ground: '#375c48', light: '#829753', moss: '#54784e', deep: '#234759', soil: '#ab8259', stone: '#86938a', blossom: '#eee0ae' },
    swamp: { ground: '#4b5b3d', light: '#92964f', moss: '#667845', deep: '#334f47', soil: '#97805d', stone: '#8a8a73', blossom: '#b9a8c2' },
    meadow: { ground: '#4b733e', light: '#acb760', moss: '#769854', deep: '#41643c', soil: '#ba9460', stone: '#969786', blossom: '#f8c5a3' },
    garden: { ground: '#54805a', light: '#a5b465', moss: '#729452', deep: '#366954', soil: '#b09365', stone: '#959c8c', blossom: '#f0d3dc' },
  };
  const sheetTiles = 6, sheetSize = World.T * sheetTiles;
  const sheets = new Map();
  const roads = new Map();

  const paperColors = new Map();
  function color(hex, paper) {
    if (!paper) return hex;
    if (!paperColors.has(hex)) paperColors.set(hex, Terrain.paperCol(hex, 'ground'));
    return paperColors.get(hex);
  }

  // При заходе пятна за границу листа повторяем тот же мазок с противоположной стороны.
  function eachPatch(count, salt, draw) {
    const step = sheetSize / count;
    for (let y = -1; y <= count; y++) for (let x = -1; x <= count; x++) {
      const ix = (x + count) % count, iy = (y + count) % count;
      const rng = mulberry32(salt + ix * 137 + iy * 413);
      draw((x + rng()) * step, (y + rng()) * step, rng);
    }
  }

  function fern(c, x, y, size, angle) {
    c.save(); c.translate(x, y); c.scale(size, size); c.rotate(angle);
    c.beginPath(); c.moveTo(0, 1); c.quadraticCurveTo(2, -5, 7, -10);
    c.strokeStyle = 'rgba(36,67,47,.8)'; c.lineWidth = 0.8; c.stroke();
    for (let i = 0; i < 4; i++) {
      const dx = i * 1.3, dy = -i * 2, leaf = 4.8 - i * 0.9;
      c.fillStyle = i % 2 ? '#92a663' : '#76945c';
      c.beginPath(); c.moveTo(dx, dy); c.quadraticCurveTo(dx - leaf, dy - 1, dx - leaf, dy - 4.5);
      c.quadraticCurveTo(dx, dy - 3, dx, dy); c.fill();
      c.fillStyle = i % 2 ? '#76945c' : '#536f49';
      c.beginPath(); c.moveTo(dx, dy); c.quadraticCurveTo(dx + 2, dy - 3, dx + leaf + 1, dy - 1);
      c.quadraticCurveTo(dx + leaf - 1, dy + 1, dx, dy); c.fill();
    }
    c.restore();
  }

  function meadowSheet(paint, paper) {
    const cv = makeCanvas(sheetSize, sheetSize), c = cv.getContext('2d');
    c.fillStyle = color(paint.ground, paper); c.fillRect(0, 0, sheetSize, sheetSize);
    const light = color(paint.light, paper), moss = color(paint.moss, paper), deep = color(paint.deep, paper);
    // Замкнутые мягкие полосы света соединяют несколько тайлов в одну полянку.
    eachPatch(5, 32, (x, y, r) => {
      c.save(); c.translate(x, y); c.rotate(r() * 1.2 - 0.6); c.scale(1, 0.52 + r() * 0.44);
      const radius = 21 + r() * 24, tint = r() < 0.54 ? moss : r() < 0.64 ? light : deep;
      const g = c.createRadialGradient(0, 0, 1, 0, 0, radius);
      g.addColorStop(0, tint + 'ed'); g.addColorStop(0.56, tint + '86'); g.addColorStop(1, tint + '00');
      c.fillStyle = g; c.fillRect(-radius, -radius, radius * 2, radius * 2); c.restore();
    });
    eachPatch(12, 93, (x, y, r) => {
      c.strokeStyle = r() < 0.5 ? 'rgba(211,224,160,.24)' : 'rgba(27,59,46,.29)';
      c.lineWidth = 0.95; c.lineCap = 'round';
      const width = 2 + r() * 5;
      c.beginPath(); c.moveTo(x, y); c.quadraticCurveTo(x + width * 0.44, y + 0.7, x + width, y - 0.7); c.stroke();
      if (r() > 0.72) {
        const height = 2.4 + r() * 3;
        c.strokeStyle = 'rgba(206,219,150,.5)';
        c.beginPath(); c.moveTo(x + 2, y); c.quadraticCurveTo(x + 1, y - height, x - 0.4, y - height);
        c.moveTo(x + 2, y); c.lineTo(x + 4.2, y - height * 0.7); c.stroke();
      }
    });
    eachPatch(5, 157, (x, y, r) => {
      if (r() < 0.58) { fern(c, x, y, 0.6 + r() * 0.6, r() - 0.5); return; }
      if (r() < 0.5) {
        c.fillStyle = color(paint.blossom, paper);
        for (let i = 0; i < 3; i++) {
          const dx = x + r() * 7, dy = y + r() * 4;
          c.fillRect(dx, dy, 1.8, 1.5); c.fillRect(dx + 1, dy - 1.2, 1.3, 1.3);
        }
      }
    });
    return cv;
  }

  function roadSheet(paint, paper) {
    const cv = makeCanvas(sheetSize, sheetSize), c = cv.getContext('2d');
    c.fillStyle = color(paint.soil, paper); c.fillRect(0, 0, sheetSize, sheetSize);
    eachPatch(6, 29, (x, y, r) => {
      c.save(); c.translate(x, y); c.rotate(-0.25); c.scale(1, 0.48);
      const radius = 20 + r() * 23, tint = r() < 0.56 ? '#edc68f' : '#6d594e';
      const g = c.createRadialGradient(0, 0, 0, 0, 0, radius);
      g.addColorStop(0, tint + '67'); g.addColorStop(1, tint + '00');
      c.fillStyle = g; c.fillRect(-radius, -radius, radius * 2, radius * 2); c.restore();
    });
    eachPatch(11, 171, (x, y, r) => {
      const w = 2 + r() * 9, bend = r() * 2;
      c.strokeStyle = 'rgba(84,61,49,.27)'; c.lineWidth = 0.85;
      c.beginPath(); c.moveTo(x, y); c.quadraticCurveTo(x + w / 2, y + bend, x + w, y - 1); c.stroke();
      if (r() < 0.62) {
        c.strokeStyle = 'rgba(251,228,181,.38)'; c.beginPath(); c.moveTo(x + 1, y + 1.2);
        c.quadraticCurveTo(x + w / 2, y + bend + 1.2, x + w - 1, y + 0.3); c.stroke();
      } else {
        c.fillStyle = 'rgba(83,67,59,.45)'; c.beginPath(); c.ellipse(x + w, y + 3, 2.6, 1.3, -0.25, 0, TAU); c.fill();
        c.fillStyle = '#d0b790'; c.fillRect(x + w - 1, y + 1.5, 1.9, 1);
      }
    });
    return cv;
  }

  function stamp(c, tx, ty, ox, oy, id, road) {
    const cache = road ? roads : sheets;
    const key = Terrain.paperOn ? id + '-paper' : id;
    let sheet = cache.get(key);
    if (!sheet) {
      sheet = road ? roadSheet(paints[id], Terrain.paperOn) : meadowSheet(paints[id], Terrain.paperOn);
      cache.set(key, sheet);
    }
    const t = World.T;
    c.drawImage(sheet, (tx % sheetTiles) * t, (ty % sheetTiles) * t, t, t, ox, oy, t, t);
  }

  function verge(c, x, y, angle, seed, paint) {
    const t = World.T;
    c.save(); c.translate(x, y); c.rotate(angle);
    const depth = 3 + seed * 2;
    c.fillStyle = color(paint.moss, Terrain.paperOn);
    c.beginPath(); c.moveTo(0, -1); c.lineTo(t, -1); c.lineTo(t, 1.6);
    c.quadraticCurveTo(t * 0.78, 1, t * 0.68, depth);
    c.quadraticCurveTo(t * 0.38, depth + 1.4, t * 0.3, 2.3);
    c.quadraticCurveTo(t * 0.16, 0.7, 0, 1.6); c.closePath(); c.fill();
    c.strokeStyle = 'rgba(68,61,42,.55)'; c.lineWidth = 0.85;
    c.beginPath(); c.moveTo(t * 0.25, 3.3); c.quadraticCurveTo(t * 0.49, depth + 3, t * 0.71, depth + 0.8); c.stroke();
    c.strokeStyle = 'rgba(221,211,131,.79)'; c.beginPath();
    for (let i = 0; i < 3; i++) {
      const px = 5 + (seed * 23 + i * 9) % 29;
      c.moveTo(px, 1); c.lineTo(px + 1.5, 3 + (i % 2)); c.lineTo(px + 2.5, 1);
    }
    c.stroke(); c.restore();
  }

  function path(c, tx, ty, ox, oy, bi, edges) {
    stamp(c, tx, ty, ox, oy, bi.id, true);
    const t = World.T, seed = hash2(tx * 3, ty + 6), paint = paints[bi.id];
    if (!edges.n) verge(c, ox, oy, 0, seed, paint);
    if (!edges.e) verge(c, ox + t, oy, Math.PI / 2, seed, paint);
    if (!edges.s) verge(c, ox + t, oy + t, Math.PI, seed, paint);
    if (!edges.w) verge(c, ox, oy + t, -Math.PI / 2, seed, paint);
  }

  function rock(c, tx, ty, ox, oy, bi, edges) {
    const t = World.T, h = hash2(tx, ty), cx = Math.round(15 + h * 9), cy = Math.round(16 + hash2(ty, tx) * 6);
    c.save(); c.translate(ox, oy);
    c.fillStyle = color(paints[bi.id].stone, Terrain.paperOn); c.fillRect(0, 0, t, t);
    // Раскол и скошенная грань видны внутри прежнего силуэта препятствия.
    c.fillStyle = 'rgba(232,228,191,.33)';
    c.beginPath(); c.moveTo(0, 2); c.lineTo(t, 0); c.lineTo(t - 4, 6); c.lineTo(cx, cy); c.lineTo(3, cy + 3); c.fill();
    c.fillStyle = 'rgba(53,68,72,.32)'; c.beginPath(); c.moveTo(cx, cy); c.lineTo(t, 8);
    c.lineTo(t, t); c.lineTo(cx + 7, t); c.lineTo(cx - 3, cy + 6); c.fill();
    c.strokeStyle = 'rgba(52,69,66,.52)'; c.lineWidth = 1;
    c.beginPath(); c.moveTo(cx + 6, cy - 3); c.lineTo(cx, cy); c.lineTo(cx - 3, cy + 6);
    c.moveTo(cx, cy); c.lineTo(cx - 7, cy + 1); c.stroke();
    if (!edges.s) {
      c.fillStyle = 'rgba(48,57,58,.44)'; c.beginPath(); c.moveTo(0, t - 8); c.lineTo(cx, t - 5);
      c.lineTo(t, t - 10); c.lineTo(t, t); c.lineTo(0, t); c.fill();
    }
    if (!edges.n || h > 0.66) {
      c.fillStyle = 'rgba(104,136,81,.85)'; c.beginPath(); c.ellipse(9 + h * 9, 6, 7.5, 2.4, -0.28, 0, TAU); c.fill();
      c.fillStyle = 'rgba(205,206,142,.83)'; c.fillRect(8 + h * 9, 4, 2.4, 1.4);
    }
    c.restore();
  }

  return { supports: bi => !!paints[bi.id], ground: (c, tx, ty, ox, oy, bi) => stamp(c, tx, ty, ox, oy, bi.id, false), path, rock };
})();
