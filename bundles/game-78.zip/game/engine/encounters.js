'use strict';

const Encounters = (() => {
  // ------------------------------------------------------------------
  //  Испытания: карманная «инфернальная» арена под картой
  // ------------------------------------------------------------------
  function enterTrial(s) {
    const st = ARENA_STYLE[World.CHN] || ARENA_STYLE[1];
    s.state = 'active'; G.activeShrine = s; s.left = 0; G.trialT = 0;
    G.trialRet = { x: s.x, y: s.y + 60 };
    Effects.burst(P.x, P.y, 30, `rgb(${st.tint})`, 240);
    P.x = World.ARENA.x; P.y = World.ARENA.y; P.vx = 0; P.vy = 0; P.dashT = 0; P.inv = Math.max(P.inv, 1.2);
    G.ebullets.length = 0; G.hazards.length = 0; G.beams.length = 0;
    const coop = Multiplayer.netCoop();
    const n = Math.min(64, Math.round((10 + World.CHN * 5 + Math.floor(P.level / 4)) * (coop ? 1 + 0.5 * Multiplayer.netLiveMates() : 1))); // вместе – врагов больше
    for (let i = 0; i < n * 4 && s.left < n; i++) {
      const a = rnd(0, TAU), r = rnd(200, 360), x = World.ARENA.x + Math.cos(a) * r, y = World.ARENA.y + Math.sin(a) * r;
      const type = weighted(SPAWNS[s.biome]);
      if (!Physics.walkable(x, y, ENEMIES[type].fly)) continue;
      Enemies.spawnEnemy(type, x, y, s.biome, { shrine: s, elite: s.left === 0 || Math.random() < World.CFG.elite * 2 * G.diff.elite });
      s.left++;
    }
    Screens.showBanner('⛩ ' + st.name, coop ? 'Все на арену! Победите всех – и вернётесь с наградой' : 'Победи всех – и вернёшься с наградой');
    if (coop) NetT.send(-1, { t: 'tr', si: World.shrines.indexOf(s), x: Math.round(World.ARENA.x), y: Math.round(World.ARENA.y), rx: Math.round(G.trialRet.x), ry: Math.round(G.trialRet.y), a: st.name });
    Sound.sfx.roar(); Sound.sfx.blink(); G.shake = 10; Sound.music('boss');
    Effects.shockRing(P.x, P.y, `rgb(${st.tint})`, 300);
  }
  function leaveArena() {
    Effects.burst(P.x, P.y, 24, '#ffffff', 200);
    // добыча из арены отправляется вместе с героиней
    const dx = G.trialRet.x - P.x, dy = G.trialRet.y - P.y;
    for (const p of G.pickups) if (p.y > World.PLAY_H * World.T) { p.x += dx; p.y += dy; p.pull = true; }
    P.x = G.trialRet.x; P.y = G.trialRet.y; World.ensureWalkable(P); P.inv = Math.max(P.inv, 1);
    G.ebullets.length = 0; G.hazards.length = 0; G.beams.length = 0;
    Terrain.revealFog(P.x, P.y, 12); biomeMusic(true); Sound.sfx.blink();
    Effects.burst(P.x, P.y, 30, '#5be3ff', 240);
  }
  function completeTrial(s) {
    s.state = 'done'; G.activeShrine = null; Achievements.life('trials'); Challenges.dailyAdd(300);
    if (NET.host && G.netRun) NetT.send(-1, { t: 'trx', ok: 1, x: Math.round(G.trialRet.x), y: Math.round(G.trialRet.y) });
    if (G.st) G.st.shrines++;
    Sound.sfx.win();
    leaveArena();
    Screens.showBanner('Испытание пройдено!', 'Награда: улучшение и осколки');
    for (let i = 0; i < 6; i++) Effects.dropShard(P.x + rnd(-40, 40), P.y + rnd(-40, 40));
    Effects.dropPickup(P.x, P.y + 40, 'heart');
    Hero.addSuper(30);
    G.pendingLv++; Screens.openLevelUp();
    Saves.saveGame();
  }
  function failTrial(s) {
    s.state = 'idle'; G.activeShrine = null;
    if (NET.host && G.netRun) NetT.send(-1, { t: 'trx', ok: 0, x: Math.round(G.trialRet.x), y: Math.round(G.trialRet.y) });
    for (const e of G.enemies) if (e.shrine === s) e.dead = true;
    leaveArena();
    Effects.floatText(P.x, P.y - 40, 'Испытание провалено', '#ff8a8a', true);
  }
  function drawArenaExit(c) {
    if (!World.ARENA || !G.activeShrine) return;
    const ex = World.ARENA.exit, g = 0.5 + Math.sin(G.time * 4) * 0.3;
    c.fillStyle = `rgba(150,220,255,${0.15 + g * 0.15})`; c.beginPath(); c.arc(ex.x, ex.y, 26, 0, TAU); c.fill();
    c.strokeStyle = `rgba(190,240,255,${0.5 + g * 0.4})`; c.lineWidth = 3; c.beginPath(); c.arc(ex.x, ex.y, 22, 0, TAU); c.stroke();
    c.font = 'bold 10px Krilessa Icons, sans-serif'; c.textAlign = 'center'; c.fillStyle = '#bfeaff'; c.fillText('ВЫХОД (провал)', ex.x, ex.y - 32);
  }


  // ------------------------------------------------------------------
  //  Сундуки, мимики, ключи и реликвии
  // ------------------------------------------------------------------
  function hasRelic(id) { return !!(G.relics && G.relics.includes(id)); }
  const relicLv = id => (hasRelic(id) ? Math.min(3, (G.relicLv && G.relicLv[id]) || 1) : 0);
  function chestReward(c, mult, by) {
    const R = CHEST_TIERS[c.tier] || CHEST_TIERS.wood, zl = Actors.zoneE(c.biome), v = Actors.xpFor(zl) / 14 * xpGap(P.level, zl);
    const luck = hasRelic('clover') ? 1.25 + 0.25 * relicLv('clover') : 1;
    for (let i = 0; i < R.gems * mult; i++) Effects.dropGem(c.x + rnd(-30, 30), c.y + rnd(-30, 30), v);
    for (let i = 0; i < Math.round(R.shards * mult * luck * (Seasons.weekEv('gold') ? 2 : 1)); i++) Effects.dropShard(c.x, c.y);
    if (Math.random() < R.heart) Effects.dropPickup(c.x, c.y + 26, 'heart');
    if (Math.random() < R.magnet) Effects.dropPickup(c.x + 20, c.y + 20, 'magnet');
    if (R.super) { if (by) Multiplayer.netEvent(by.id, ['sp', Math.round(R.super * mult)]); else Hero.addSuper(R.super * mult); }
    if (Math.random() < R.key * mult) Effects.dropPickup(c.x - 20, c.y + 20, 'key');
  }
  function openChest(c, by) {
    if (c.tier === 'gold') {
      if ((G.keys || 0) <= 0) {
        if ((G.keyMsgT || 0) <= 0) { G.keyMsgT = 2.5; Effects.floatText(c.x, c.y - 30, '🔒 Нужен ключ 🔑', '#ffd25a', true); Sound.sfx.block(); if (by) Multiplayer.netEvent(by.id, ['txt', '🔒 Нужен ключ 🔑 (ключи общие)']); }
        return;
      }
      G.keys--; Effects.floatText(c.x, c.y - 34, '🔑 −1', '#ffd25a', true);
    }
    if (!c.mimic && c.tier !== 'gold' && !c.glade && Seasons.weekEv('mimic') && Math.random() < 0.33) c.mimic = true; // нашествие мимиков
    c.open = true; Challenges.buzz(30);
    if (!by) { Achievements.life('chests'); Challenges.dailyAdd(60); }
    if (c.mimic) { wakeMimic(c); return; }
    if (G.st) G.st.chests++;
    Sound.sfx.chest(); Effects.burst(c.x, c.y, 30, c.tier === 'gold' ? '#ffd25a' : c.tier === 'silver' ? '#e0eaff' : '#d8a060', 220);
    chestReward(c, 1, by);
    if (!by && Math.random() < (c.secret ? 0.3 : c.tier === 'gold' ? 0.25 : c.tier === 'silver' ? 0.05 : 0)) setTimeout(() => HomeScreen.furnDrop(c.x, c.y), 600); // находка для домика
    if (!by && Actors.talent('golden') && Math.random() < 0.15 + 0.1 * Math.min(3, Actors.talent('golden'))) {
      chestReward(c, 1); Effects.floatText(c.x, c.y - 44, '💰 Золотая жила: ×2!', '#ffd25a', true); Effects.burst(c.x, c.y, 24, '#ffd25a', 200);
    }
    if (c.tier === 'gold') { if (by) Multiplayer.netEvent(by.id, ['relic']); else G.relicPending = true; } // реликвию выбирает та, кто открыла
    Saves.saveGame();
  }
  function wakeMimic(c) {
    const e = Enemies.spawnEnemy('mimic', c.x, c.y, c.biome, { instant: true });
    e.mimicOf = c; e.chn = World.CHN; e.hp = e.maxHp = e.maxHp * (c.tier === 'silver' ? 5 : 4); e.dmg *= 1.15;
    Multiplayer.netBan('😱 Это мимик!', 'Победи его – награда будет двойной');
    Sound.sfx.roar(); G.shake = 10; Effects.burst(c.x, c.y, 24, '#a0623a', 200);
  }
  function mimicKilled(e) {
    const c = e.mimicOf; c.mimicDone = true; Achievements.life('mimics'); if (Seasons.weekEv('mimic')) Achievements.life('spts', 10);
    if (!NET.hitBy && Math.random() < 0.15) setTimeout(() => HomeScreen.furnDrop(e.x, e.y), 600);
    chestReward(c, 2);
    if (Math.random() < 0.25) Effects.dropPickup(e.x, e.y + 20, 'key');
    Screens.showBanner('Мимик побеждён!', 'Двойная награда'); Sound.sfx.chest();
    if (G.st) { G.st.mimics = (G.st.mimics || 0) + 1; G.st.chests++; }
    Saves.saveGame();
  }
  function updateRelics(dt) {
    if (G.guardT > 0) G.guardT -= dt;
    if (G.keyMsgT > 0) G.keyMsgT -= dt;
    if (G.relicPending && Session.state === 'play' && !Screens.Dialog.talking) { G.relicPending = false; openRelicChoice(); return; }
    if (hasRelic('collar')) {
      G.thornT = (G.thornT || 0) - dt;
      if (G.thornT <= 0) {
        G.thornT = 0.5;
        for (const e of G.enemies) if (!e.dead && e.spawnT <= 0 && Math.hypot(e.x - P.x, e.y - P.y) < P.r + e.r + 6) Enemies.damageEnemy(e, { v: P.dmg * (0.75 + 0.75 * relicLv('collar')), crit: false }, 0, 0, false);
      }
    }
    if (hasRelic('storm')) {
      G.stormRT = (G.stormRT === undefined ? 2.5 : G.stormRT) - dt;
      if (G.stormRT <= 0) {
        G.stormRT = 3 - 0.5 * relicLv('storm');
        const tg = Hero.nearestTarget(320);
        if (tg) { G.bolts.push({ pts: [[P.x, P.y - 30], [tg.x, tg.y - (tg.z || 0)]], t: 0.25, col: '190,230,255' }); Hero.hitAny(tg, Actors.rollHit(P.dmg * 3), 0, 0, false); Sound.sfx.bolt(); }
      }
    }
  }
  function openRelicChoice() {
    const owned = G.relics || [], lvs = Saves.loadProfile().relicLv || {};
    const pool = Object.keys(RELICS).filter(id => (lvs[id] || 0) < 3); // новые – и свои, которые ещё можно прокачать
    const opts = [];
    while (opts.length < 3 && pool.length) opts.push(pool.splice(Math.floor(Math.random() * pool.length), 1)[0]);
    if (!opts.length) { for (let i = 0; i < 12; i++) Effects.dropShard(P.x + rnd(-40, 40), P.y + rnd(-40, 40)); return; }
    const box = $('relicCards'); box.innerHTML = '';
    opts.forEach((id, i) => {
      const r = RELICS[id], el = document.createElement('button'), L = lvs[id] || 0;
      el.className = 'card' + (L ? ' rlUp' : ''); el.style.animationDelay = (i * 0.07) + 's';
      const tag = L ? `<div class="lv">⬆️ Уровень ${L} → ${L + 1}${owned.includes(id) ? ' · надета' : ' · из коллекции'}</div>` : '<div class="lv">✨ Новая</div>';
      el.innerHTML = `<div class="ic">${r.ic}</div><div><div class="nm">${r.name}</div><div class="ds">${relicDs(id, L + 1)}</div>${tag}</div>`;
      el.addEventListener('click', () => { Sound.sfx.click(); pickRelic(id); });
      box.appendChild(el);
    });
    $('relicSwap').classList.add('hidden');
    $('relicHint').textContent = `Выбери реликвию · носить можно ${Actors.relicMax()}, сейчас ${owned.length}`;
    Screens.setState('relic'); Sound.sfx.chest();
  }
  function pickRelic(id) {
    const pr = Saves.loadProfile(); pr.relicLv = pr.relicLv || {}; pr.relicSeen = pr.relicSeen || {};
    const L = Math.min(3, (pr.relicLv[id] || 0) + 1); pr.relicLv[id] = L; pr.relicSeen[id] = 1; Saves.saveProfile(pr);
    G.relicLv = Object.assign({}, pr.relicLv);
    if (L >= 3) Achievements.life('relicMax');
    if ((G.relics || []).includes(id)) { // прокачали надетую
      Actors.computeStats(); Screens.setState('play');
      Screens.showBanner(`${RELICS[id].ic} ${RELICS[id].name} · ур. ${L}`, relicDs(id, L)); Sound.sfx.magic();
      return;
    }
    if ((G.relics || []).length < Actors.relicMax()) { addRelic(id); return; }
    $('relicHint').textContent = `${RELICS[id].ic} ${RELICS[id].name} – что заменить?`;
    const box = $('relicOwned'); box.innerHTML = '';
    for (const old of G.relics) {
      const r = RELICS[old], el = document.createElement('button');
      el.className = 'btn alt'; el.textContent = `${r.ic} ${r.name}`;
      el.addEventListener('click', () => { Sound.sfx.click(); G.relics = G.relics.filter(x => x !== old); addRelic(id); });
      box.appendChild(el);
    }
    const keep = document.createElement('button'); keep.className = 'btn gray'; keep.textContent = '🎒 Оставить в коллекции';
    keep.addEventListener('click', () => { Sound.sfx.click(); Screens.setState('play'); Screens.showBanner(`${RELICS[id].ic} ${RELICS[id].name} – в коллекции`, 'Надеть можно в меню: «Коллекция» → «Реликвии»'); });
    box.appendChild(keep);
    $('relicSwap').classList.remove('hidden');
  }
  function addRelic(id) {
    G.relics = (G.relics || []).concat(id).slice(-Actors.relicMax());
    const prof = Saves.loadProfile(); prof.relics = G.relics; prof.relicSeen = prof.relicSeen || {}; prof.relicSeen[id] = 1;
    prof.relicLv = prof.relicLv || {}; if (!prof.relicLv[id]) prof.relicLv[id] = 1; G.relicLv = Object.assign({}, prof.relicLv); Saves.saveProfile(prof);
    Actors.computeStats(); Screens.setState('play');
    Screens.showBanner(`${RELICS[id].ic} ${RELICS[id].name}` + (relicLv(id) > 1 ? ` · ур. ${relicLv(id)}` : ''), relicDs(id, relicLv(id))); Sound.sfx.magic();
    if (G.st) G.st.relics = (G.st.relics || 0) + 1;
  }

  // ------------------------------------------------------------------
  //  Сердечки в бою с боссом и «усмирённые» локации
  // ------------------------------------------------------------------
  const HEART_EVERY = { easy: 11, normal: 18, hard: 22 };
  function dropHeartNear(r0, r1) {
    for (let k = 0; k < 12; k++) {
      const a = rnd(0, TAU), r = rnd(r0, r1), x = P.x + Math.cos(a) * r, y = P.y + Math.sin(a) * r;
      if (!Physics.walkable(x, y, false)) continue;
      Effects.dropPickup(x, y, 'heart'); Effects.burst(x, y, 10, '#ff5b8a', 120); return;
    }
    Effects.dropPickup(P.x + rnd(-30, 30), P.y + 50, 'heart');
  }
  function updateBossHearts(dt) {
    const b = G.activeBoss;
    if (!b || b.state !== 'fight') return;
    G.bossHeartT -= dt * (P.hp < P.maxHp * 0.35 ? 2 : 1);
    if (G.bossHeartT > 0) return;
    G.bossHeartT = HEART_EVERY[G.diffId] || 12;
    dropHeartNear(130, 250);
  }
  // Усмирение: после победы над стражем его локация слабеет ступенями I–V.
  // Ступень растёт за убийства в этой локации, за каждую – награда.
  const CALM_STEPS = [0, 120, 350, 700, 1200], CALM_PCT = [0.10, 0.15, 0.20, 0.25, 0.30], ROMAN = ['I', 'II', 'III', 'IV', 'V'];
  const calmStage = biome => { const n = G.calm[biome] || 0; let s = 0; while (s < 4 && n >= CALM_STEPS[s + 1]) s++; return s; };
  const calmOf = biome => (G.calm && G.calm[biome] !== undefined) ? CALM_PCT[calmStage(biome)] : 0;
  function calmKill(biome) {
    if (!G.calm || G.calm[biome] === undefined || G.calm[biome] >= CALM_STEPS[4]) return;
    const before = calmStage(biome);
    G.calm[biome]++;
    const st = calmStage(biome);
    if (st <= before) return;
    Screens.showBanner(`🕊️ Усмирение ${ROMAN[st]}`, `${BIOMES[biome].name}: враги слабее на ${Math.round(CALM_PCT[st] * 100)}%`);
    Sound.sfx.chest();
    for (let i = 0; i < [0, 4, 6, 8, 12][st]; i++) Effects.dropShard(P.x + rnd(-40, 40), P.y + rnd(-40, 40));
    Effects.dropPickup(P.x, P.y + 40, 'heart');
    if (G.st) G.st.calmUps = (G.st.calmUps || 0) + 1;
    if (st >= 3) { G.pendingLv++; Screens.openLevelUp(); }
  }

  // ------------------------------------------------------------------
  //  Чемпионы: сильные бродячие мобы с наградой
  // ------------------------------------------------------------------
  function updateChampions(dt) {
    if (G.champ && (G.champ.dead || !G.enemies.includes(G.champ))) G.champ = null;
    if (G.champ) { if (Math.hypot(G.champ.x - P.x, G.champ.y - P.y) > 3200) { G.champ.dead = true; G.champ = null; } return; }
    if (World.CFG.rush || World.CFG.abyss || G.finalFinal || G.activeBoss || G.activeShrine || Physics.playerInCastle()) return;
    G.champT -= dt;
    if (G.champT > 0) return;
    G.champT = rnd(150, 210) * (Seasons.weekEv('champ') ? 0.5 : 1);
    spawnChampion();
  }
  function spawnChampion() {
    const biome = curBiome();
    const types = (SPAWNS[biome] || []).map(s => s[0]).filter(t => !ENEMIES[t].group && ENEMIES[t].ai !== 'exploder' && ENEMIES[t].ai !== 'swarm');
    if (!types.length) return;
    for (let k = 0; k < 20; k++) {
      const a = rnd(0, TAU), r = rnd(450, 750), x = P.x + Math.cos(a) * r, y = P.y + Math.sin(a) * r;
      const type = pick(types), tx = Math.floor(x / World.T), ty = Math.floor(y / World.T);
      if (!World.inMap(tx, ty) || World.tiles[ty * World.MW + tx] === FLOOR || !Physics.walkable(x, y, ENEMIES[type].fly)) continue;
      const e = Enemies.spawnEnemy(type, x, y, biome, { elite: true, instant: true });
      e.champion = true; e.hp = e.maxHp = e.maxHp * 6; e.dmg *= 1.2; e.r *= 1.2; e.xp *= 3; e.name = ENEMIES[type].name;
      G.champ = e;
      Screens.showBanner('👑 Чемпион!', `${e.name} бродит рядом – ищи корону на карте`);
      Sound.sfx.roar();
      return;
    }
  }

  // ------------------------------------------------------------------
  //  Порталы между пройденными алтарями
  // ------------------------------------------------------------------
  const portalHere = () => World.shrines.find(s => s.state === 'done' && Math.hypot(P.x - s.x, P.y - s.y) < 60);
  function openPortals() {
    const here = portalHere();
    if (!here) return;
    const dests = World.shrines.filter(s => s.state === 'done' && s !== here).map(s => ({ ic: '⛩', nm: 'Алтарь · ' + BIOMES[s.biome].name, x: s.x, y: s.y + 56 }));
    dests.push({ ic: '🏠', nm: 'Начало пути', x: World.tc(World.START.x), y: World.tc(World.START.y) });
    if (World.gateOpen) dests.push({ ic: '🏰', nm: 'Ворота замка', x: World.tc(World.GATE_FRONT.x), y: World.tc(World.GATE_FRONT.y) + 20 });
    for (const d of dests) d.dist = Math.round(Math.hypot(d.x - P.x, d.y - P.y) / World.PX_PER_M);
    dests.sort((a, b) => a.dist - b.dist);
    const list = $('portalList'); list.innerHTML = '';
    for (const d of dests) {
      const el = document.createElement('button'); el.className = 'btn alt';
      el.innerHTML = `${d.ic} ${d.nm} <small>· ${d.dist} м</small>`;
      el.addEventListener('click', () => { Sound.sfx.click(); portalTo(d); });
      list.appendChild(el);
    }
    Screens.setState('portal'); Sound.sfx.magic();
  }
  function portalTo(d) {
    Effects.burst(P.x, P.y, 30, '#c77dff', 220);
    P.x = d.x; P.y = d.y; P.inv = 1.2; P.vx = 0; P.vy = 0; P.dashT = 0;
    Terrain.revealFog(P.x, P.y, 12);
    if (!NET.client) for (const e of G.enemies) if (!e.minion && !e.champion && Math.hypot(e.x - P.x, e.y - P.y) < 260) e.dead = true;
    Effects.burst(P.x, P.y, 40, '#c77dff', 260); Effects.shockRing(P.x, P.y, '#c77dff', 200);
    Sound.sfx.blink(); Screens.setState('play'); biomeMusic(true);
  }

  // ------------------------------------------------------------------
  //  Музыка локаций
  // ------------------------------------------------------------------
  function curBiome() {
    if (Physics.playerInCastle()) return World.CASTLE.biome;
    return World.biomeMap[clamp(Math.floor(P.y / World.T), 0, World.MH - 1) * World.MW + clamp(Math.floor(P.x / World.T), 0, World.MW - 1)];
  }
  function biomeMusic(now) {
    const want = World.CFG.abyss && G.abyss && G.abyss.track ? G.abyss.track : World.CFG.rush ? 'boss' : (BIOME_MUSIC[curBiome()] || World.CFG.music);
    if (now) { G.musWant = want; G.musHold = 0; Sound.music(want); }
    return want;
  }
  function updateMusic(dt) {
    if (G.activeBoss || G.cutscene || G.finalFinal || Session.state !== 'play') return;
    G.musT -= dt; if (G.musT > 0) return; G.musT = 0.5;
    const want = biomeMusic(false);
    if (want !== G.musWant) { G.musWant = want; G.musHold = 0; return; }
    G.musHold += 0.5;
    if (G.musHold >= 1.5 && Sound.current() !== want) Sound.music(want);
  }

  // ------------------------------------------------------------------
  //  События на карте (раз в ~3 минуты)
  // ------------------------------------------------------------------
  function pickEvent() {
    const pool = EVENTS.filter(e => e.id !== G.lastEv && (e.id !== 'song' || World.CHN >= 2) && !(World.CFG.noEvents || []).includes(e.id));
    return weighted(pool.map(e => [e, e.w * (e.id === 'hearts' && P.hp < P.maxHp * 0.5 ? 2.5 : 1)]));
  }
  // свободное место в кольце вокруг героини, до которого можно дойти пешком (для клада и воришки):
  // обход клеток от героини – остров за водой или комната за стеной не подойдут
  function eventSpot(r0, r1) {
    const ptx = Math.floor(P.x / World.T), pty = Math.floor(P.y / World.T), R = Math.ceil(r1 / World.T) + 2;
    const free = (x, y) => World.inMap(x, y) && y < World.PLAY_H - 2 && x > 2 && y > 2 && x < World.MW - 3 && !World.isSolidTile(x, y, false) && Physics.walkable(World.tc(x), World.tc(y), false);
    const seen = new Set([ptx * 4096 + pty]), q = [[ptx, pty]], cands = [];
    for (let qi = 0; qi < q.length; qi++) {
      const [x, y] = q[qi];
      for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const nx = x + dx, ny = y + dy, k = nx * 4096 + ny;
        if (seen.has(k) || Math.abs(nx - ptx) > R || Math.abs(ny - pty) > R) continue;
        seen.add(k);
        if (!free(nx, ny)) continue;
        q.push([nx, ny]);
        const d = Math.hypot(World.tc(nx) - P.x, World.tc(ny) - P.y);
        if (d >= r0 && d <= r1 && free(nx + 1, ny) && free(nx - 1, ny) && free(nx, ny + 1) && free(nx, ny - 1)) cands.push([nx, ny]);
      }
    }
    if (!cands.length) return null;
    const [tx, ty] = pick(cands);
    return { x: World.tc(tx) + rnd(-8, 8), y: World.tc(ty) + rnd(-8, 8) };
  }
  function startEvent(forceId) {
    let def = (forceId && EVENTS.find(e => e.id === forceId)) || G.nextEv || pickEvent();
    G.nextEv = null;
    // воришке и кладу нужно место рядом – нет места, берём другое событие
    let spot = null;
    if (def.id === 'thief' || def.id === 'treasure') {
      spot = def.id === 'thief' ? eventSpot(240, 340) : eventSpot(420, 700);
      if (!spot) { def = EVENTS.find(e => e.id === 'gold'); }
    }
    G.ev = { def, t: 0, k: 0, kills: 0 }; G.lastEv = def.id;
    G.evT = rnd(EVENT_GAP[0], EVENT_GAP[1]) * G.diff.event * (Seasons.weekEv('fest') ? 0.5 : 1);
    Multiplayer.netBan(def.ic + ' ' + def.name, def.desc);
    Sound.sfx.event(); G.shake = Math.max(G.shake, 6);
    if (G.st) G.st.events[def.id] = (G.st.events[def.id] || 0) + 1;
    if (def.id === 'thief') {
      const biome = World.biomeMap[Math.floor(spot.y / World.T) * World.MW + Math.floor(spot.x / World.T)];
      const types = (SPAWNS[biome] || []).filter(([t]) => !ENEMIES[t].fly && ENEMIES[t].ai !== 'turret');
      const type = types.length ? weighted(types) : (SPAWNS[biome] ? weighted(SPAWNS[biome]) : Object.keys(ENEMIES)[0]);
      const e = Enemies.spawnEnemy(type, spot.x, spot.y, biome, { instant: true });
      e.thief = true; e.hp = e.maxHp = e.maxHp * 2.5; e.xp *= 3; e.dmg = 0;
      G.ev.thief = e;
      Effects.burst(e.x, e.y, 24, '#ffd25a', 220);
    }
    if (def.id === 'treasure') { G.ev.tx = spot.x; G.ev.ty = spot.y; }
    if (def.id === 'horde') G.ev.goal = Math.round(16 + World.CHN * 2 + Math.min(10, P.level * 0.25));
    if (def.id === 'song') {
      G.ev.line = Math.floor(Math.random() * SONG_TEXTS.length); G.ev.lineT = 2.6;
      $('songText').textContent = SONG_TEXTS[G.ev.line];
      const ac = $('songAvatar').getContext('2d'); ac.clearRect(0, 0, 96, 96);
      if (ART.zyamaFace) ac.drawImage(ART.zyamaFace, 0, 0, 96, 96);
      $('songBanner').classList.remove('hidden');
    }
  }
  // награда за событие: россыпь опыта и осколков, иногда ключ
  function eventLoot(x, y, tier, mult = 1) {
    Challenges.dailyAdd(150);
    chestReward({ x, y, tier, biome: curBiome() }, mult);
    if (tier === 'gold') G.relicPending = true;
    Sound.sfx.chest(); Effects.burst(x, y, 34, '#ffd25a', 240); G.shake = Math.max(G.shake, 6);
    if (G.st) G.st.evWins = (G.st.evWins || 0) + 1;
  }
  function endEvent(result) {
    const ev = G.ev; if (!ev) return;
    if (ev.def.id === 'song') $('songBanner').classList.add('hidden');
    if (ev.def.id === 'thief' && ev.thief && !ev.thief.dead && result !== 'win') { // убежал
      const e = ev.thief; Effects.burst(e.x, e.y, 20, '#ffd25a', 200); e.dead = true;
      Effects.floatText(e.x, e.y - 30, '💨 Воришка сбежал…', '#ffe9a0', true);
    }
    if (ev.def.id === 'treasure' && result !== 'win') Effects.floatText(P.x, P.y - 60, '🧭 Клад ушёл под землю…', '#ffe9a0', true);
    if (ev.def.id === 'horde' && result !== 'win' && result !== 'quiet') Effects.floatText(P.x, P.y - 60, `👹 Осада закончилась: ${ev.kills}/${ev.goal}`, '#d8c0ff', true);
    G.ev = null;
  }
  function thiefCaught(e) { // воришка пойман
    if (!G.ev || G.ev.thief !== e) return;
    Multiplayer.netBan('💰 Воришка пойман!', 'Мешок с добычей твой');
    eventLoot(e.x, e.y, Math.random() < 0.25 ? 'gold' : 'silver');
    endEvent('win');
  }
  function updateEvents(dt) {
    if (World.CFG.rush || World.CFG.abyss || G.cutscene || G.finalFinal) { if (G.ev) endEvent('quiet'); return; }
    if (G.ev) {
      const ev = G.ev; ev.t += dt; ev.k -= dt;
      const EA = NET.host ? Multiplayer.netAnchor() : P; // звёзды и сердечки падают то у одной, то у другой
      if (ev.def.id === 'meteor' && ev.k <= 0) { // звёзды падают вокруг (без прицела на бегу), на месте – осколок
        ev.k = 0.42;
        const a = rnd(0, TAU), r = rnd(50, 300);
        const h = Bosses.hazardCircle(EA.x + Math.cos(a) * r, EA.y + Math.sin(a) * r, 56, 1.25, P.maxHp * 0.08, 'meteor'); h.star = true;
      }
      if (ev.def.id === 'hearts' && ev.k <= 0) { ev.k = 0.55; const a = rnd(0, TAU), r = rnd(60, 240); Effects.dropPickup(EA.x + Math.cos(a) * r, EA.y + Math.sin(a) * r, 'heart'); }
      if (ev.def.id === 'song') {
        const left = Math.ceil(ev.def.dur - ev.t); $('songLeft').textContent = left > 0 ? `Песня кончится через ${left}…` : '';
        ev.lineT -= dt;
        if (ev.lineT <= 0) { ev.lineT = 2.6; ev.line = (ev.line + 1) % SONG_TEXTS.length; $('songText').textContent = SONG_TEXTS[ev.line]; }
        if (Math.random() < dt * 6) Effects.floatText(P.x + rnd(-160, 160), P.y + rnd(-200, 40), pick(['♪', '♫', '🎵']), '#ff8ad8', true);
      }
      if (ev.def.id === 'thief' && ev.thief && ev.thief.dead) { Effects.floatText(P.x, P.y - 60, '💨 Воришка сбежал…', '#ffe9a0', true); endEvent(); return; } // убежал далеко
      if (ev.def.id === 'treasure' && Multiplayer.netNear(ev.tx, ev.ty, 44)) {
        Multiplayer.netBan('🧭 Клад найден!', 'Сундук с сокровищами');
        eventLoot(ev.tx, ev.ty, Math.random() < 0.2 ? 'gold' : 'silver');
        endEvent('win'); return;
      }
      if (ev.def.id === 'horde' && ev.kills >= ev.goal) {
        Multiplayer.netBan('👹 Осада отбита!', 'Лечение и награда');
        P.hp = Math.min(P.maxHp, P.hp + P.maxHp * 0.3); Effects.floatText(P.x, P.y - 40, '+30% ❤️', '#7dff9a', true);
        if (NET.host) for (const m of NET.peers.values()) Multiplayer.netEvent(m.id, ['hl']);
        eventLoot(P.x, P.y + 30, 'silver');
        endEvent('win'); return;
      }
      if (ev.t >= ev.def.dur) endEvent();
      return;
    }
    if (G.activeBoss || G.activeShrine) { G.evT = Math.max(G.evT, 25); G.nextEv = null; return; } // после боя – передышка
    G.evT -= dt;
    if (G.evT <= 8 && !G.nextEv) G.nextEv = pickEvent(); // заранее знаем, что будет – пишем на плашке
    if (G.evT <= 0) startEvent();
  }

  return {
    enterTrial, completeTrial, failTrial, drawArenaExit, hasRelic, relicLv, openChest,
    mimicKilled, updateRelics, openRelicChoice, pickRelic, HEART_EVERY, dropHeartNear,
    updateBossHearts, CALM_STEPS, ROMAN, calmStage, calmOf, calmKill, updateChampions,
    portalHere, openPortals, curBiome, biomeMusic, updateMusic, startEvent, eventLoot, endEvent,
    thiefCaught, updateEvents,
  };
})();
