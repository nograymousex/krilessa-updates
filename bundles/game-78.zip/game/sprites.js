'use strict';
// =====================================================================
//  Графика: деревья, героиня, враги, боссы, снаряды.
//  Всё рисуется кодом (вектор), без картинок – кроме мультяшных лиц.
// =====================================================================
const ART = { ryzhovaSmall: null, zyamaFace: null, zyamaSmall: null };

// ---------- помощники ----------
let PAPER_ART = true; // 1.0: книжная рисовка (чернильный контур, мягкие краски)
function circ(c, x, y, r) { c.moveTo(x + r, y); c.arc(x, y, r, 0, TAU); }
function glossGrad(c, x, y, r, col) {
  const g = c.createRadialGradient(x - r * 0.35, y - r * 0.45, Math.max(1, r * 0.12), x, y, r * 1.15);
  if (PAPER_ART) { g.addColorStop(0, shade(col, 0.22)); g.addColorStop(0.6, col); g.addColorStop(1, shade(col, -0.24)); return g; }
  g.addColorStop(0, shade(col, 0.5)); g.addColorStop(0.55, col); g.addColorStop(1, shade(col, -0.4));
  return g;
}
function blob(c, x, y, rx, ry, col, lw = 2) {
  if (PAPER_ART) { // заливка с мягкой тенью справа-снизу и чернильный контур
    const p = new Path2D(); p.ellipse(x, y, rx, ry, 0, 0, TAU);
    c.fillStyle = shade(col, -0.26); c.fill(p);
    c.save(); c.clip(p); c.fillStyle = col; c.beginPath(); c.ellipse(x - rx * 0.12, y - ry * 0.16, rx, ry, 0, 0, TAU); c.fill(); c.restore();
    if (lw) { c.lineWidth = lw * 0.7; c.strokeStyle = '#4b2e1e'; c.stroke(p); }
    return;
  }
  c.fillStyle = glossGrad(c, x, y, Math.max(rx, ry), col);
  c.beginPath(); c.ellipse(x, y, rx, ry, 0, 0, TAU); c.fill();
  if (lw) { c.lineWidth = lw; c.strokeStyle = 'rgba(20,8,30,0.75)'; c.stroke(); }
}
function gloss(c, x, y, rx, ry, a = 0.45) {
  c.fillStyle = `rgba(255,255,255,${a})`; c.beginPath(); c.ellipse(x, y, rx, ry, -0.5, 0, TAU); c.fill();
}
// Глаза, которые смотрят на героиню
function lookEyes(c, x1, x2, y, r, ang, white = '#ffffff', pupil = '#1b1030') {
  if (PAPER_ART && pupil === '#1b1030') pupil = '#2a1810';
  const ox = Math.cos(ang) * r * 0.36, oy = Math.sin(ang) * r * 0.36;
  c.fillStyle = white; c.beginPath(); circ(c, x1, y, r); circ(c, x2, y, r); c.fill();
  c.fillStyle = pupil; c.beginPath(); circ(c, x1 + ox, y + oy, r * 0.56); circ(c, x2 + ox, y + oy, r * 0.56); c.fill();
  c.fillStyle = '#ffffff'; c.beginPath(); circ(c, x1 + ox - r * 0.2, y + oy - r * 0.25, r * 0.2); circ(c, x2 + ox - r * 0.2, y + oy - r * 0.25, r * 0.2); c.fill();
}
function brows(c, x1, x2, y, w, angry = 0.35, col = '#1b1030') {
  c.strokeStyle = col; c.lineWidth = 2; c.lineCap = 'round';
  c.beginPath(); c.moveTo(x1 - w, y - w * angry); c.lineTo(x1 + w, y + w * angry);
  c.moveTo(x2 + w, y - w * angry); c.lineTo(x2 - w, y + w * angry); c.stroke();
  c.lineCap = 'butt';
}
function shadow(c, x, y, rx, ry) {
  c.fillStyle = PAPER_ART ? 'rgba(70,45,20,0.24)' : 'rgba(0,0,0,0.3)'; c.beginPath(); c.ellipse(x, y, rx, ry, 0, 0, TAU); c.fill();
}

// ---------- снаряды (кэш спрайтов) ----------
const _bulletCache = new Map();
function bulletSprite(col, r) {
  const key = col + '|' + r;
  let cv = _bulletCache.get(key);
  if (cv) return cv;
  const s = Math.ceil(r * 2) * 2 + 4, h = s / 2;
  cv = makeCanvas(s * 2, s * 2);
  const c = cv.getContext('2d'); c.scale(2, 2);
  const g = c.createRadialGradient(h, h, r * 0.3, h, h, h);
  g.addColorStop(0, col); g.addColorStop(0.5, col); g.addColorStop(1, 'rgba(0,0,0,0)');
  c.globalAlpha = 0.45; c.fillStyle = g; c.fillRect(0, 0, s, s);
  c.globalAlpha = 1; c.fillStyle = col; c.beginPath(); c.arc(h, h, r, 0, TAU); c.fill();
  c.strokeStyle = 'rgba(0,0,0,0.45)'; c.lineWidth = 1.2; c.stroke();
  c.fillStyle = 'rgba(255,255,255,0.85)'; c.beginPath(); c.arc(h - r * 0.3, h - r * 0.3, r * 0.38, 0, TAU); c.fill();
  _bulletCache.set(key, cv);
  return cv;
}
const _emojiCache = new Map();
function emojiSprite(ch, size) {
  const key = ch + size;
  let cv = _emojiCache.get(key);
  if (cv) return cv;
  const s = Math.ceil(size * 1.5);
  cv = makeCanvas(s * 2, s * 2);
  const c = cv.getContext('2d'); c.scale(2, 2);
  c.font = `${size}px Krilessa Icons, sans-serif`;
  c.textAlign = 'center'; c.textBaseline = 'middle';
  c.fillText(ch, s / 2, s / 2 + size * 0.06);
  _emojiCache.set(key, cv);
  return cv;
}
const ZYAMA_EMOJI = ['😂', '💅', '🤡', '😎', '❤️', '🌹', '🔥', '🎤', '🗿', '😭', '🎭', '✨'];

// ---------- деревья ----------
const TREE_SPR = {};
function makeTreeSprite(draw, shadowRx = 16, shadowRy = 5) {
  const scale = 2;
  const canvas = makeCanvas(64 * scale, 84 * scale);
  const ctx = canvas.getContext('2d');
  ctx.scale(scale, scale);
  shadow(ctx, 32, 79, shadowRx, shadowRy);
  draw(ctx);
  return canvas;
}

(() => {
  // Каждая крона и её мелкие листья рисуются один раз в холст 64 × 84.
  const branchCluster = new Path2D('M-1,0 C-7,3 -14,2 -15,-2 Q-19,-3 -15,-7 Q-17,-11 -11,-11 Q-11,-16 -5,-14 Q-3,-19 2,-15 Q8,-18 10,-13 Q16,-13 15,-8 Q20,-7 17,-3 Q19,1 13,2 Q11,6 6,4 Q2,7 -1,4Z');
  const clusterLight = new Path2D('M-14,-6 Q-14,-11 -9,-10 Q-9,-14 -4,-12 Q-2,-17 2,-14 Q7,-16 9,-12 Q13,-12 14,-8 Q9,-10 7,-6 Q5,-8 1,-5 Q-1,-7 -5,-4 Q-10,-7 -14,-4Z');
  const leaf = new Path2D('M0,0 Q-1,-3 3,-4 Q4,-1 0,0Z');

  function fillTreePath(c, path, fill, outline, width = 1) {
    c.fillStyle = fill; c.fill(path);
    if (outline) { c.lineWidth = width; c.strokeStyle = outline; c.stroke(path); }
  }
  function canopy(c, x, y, sx, sy, shade, lit, fleck) {
    c.save(); c.translate(x, y); c.scale(sx, sy);
    fillTreePath(c, branchCluster, shade, shade);
    fillTreePath(c, clusterLight, lit);
    c.fillStyle = fleck;
    for (const [lx, ly, a] of [[-11,-8,-0.4],[-6,-11,0.65],[2,-12,0.15],[5,-5,1.0],[12,-7,0.35],[-6,-3,0.5]]) {
      c.save(); c.translate(lx, ly); c.rotate(a); c.scale(0.83, 0.66); c.fill(leaf); c.restore();
    }
    c.restore();
  }
  function bark(c, silhouette, ridges, cut, shade, light) {
    fillTreePath(c, new Path2D(silhouette), shade, cut, 1.05);
    c.strokeStyle = light; c.lineWidth = 1.5; c.lineCap = 'round';
    c.stroke(new Path2D(ridges));
  }

  TREE_SPR.oak = makeTreeSprite(c => {
    bark(c, 'M16,79 Q28,75 26,65 L24,51 Q19,43 10,40 L11,37 Q20,40 25,44 L26,29 L30,34 L29,47 Q34,41 40,36 L48,31 L49,34 Q41,39 35,47 L46,44 L49,46 Q39,48 36,54 Q32,64 36,73 Q38,76 46,79 L36,78 L33,80 L29,77 L24,80Z',
      'M21,77 Q31,73 29,62 M29,57 Q26,52 28,47 M30,52 Q34,45 38,42 M34,72 Q32,67 33,62',
      '#4c4035', '#856340', '#c29a61');
    c.strokeStyle = '#553f36'; c.lineWidth = 1;
    c.stroke(new Path2D('M30,69 Q24,64 30,61 Q33,63 30,66 M33,76 L37,78'));
    for (const [x,y,sx,sy] of [[19,44,.83,.79],[42,44,.91,.82],[31,48,.75,.62]])
      canopy(c,x,y,sx,sy,'#325e50','#4b7955','#79985d');
    for (const [x,y,sx,sy] of [[34,26,.98,.94],[17,33,.78,.83],[45,35,.83,.83],[28,37,.85,.83]])
      canopy(c,x,y,sx,sy,'#477956','#7b9f62','#adc078');
    canopy(c,29,23,.73,.7,'#689159','#9eaf64','#d1c787');
    // Два жёлудя под нависающей веткой.
    for (const [x,y] of [[16,46],[19,48]]) {
      c.fillStyle = '#cc9d58'; c.beginPath(); c.ellipse(x,y,1.25,1.8,-0.3,0,TAU); c.fill();
      c.fillStyle = '#64533c'; c.fillRect(x-1.4,y-1.1,2.6,1.1);
    }
  });

  TREE_SPR.blossom = makeTreeSprite(c => {
    bark(c, 'M20,79 Q31,73 28,65 Q27,60 30,55 Q24,52 19,43 L8,41 L8,39 L19,41 L17,33 L19,32 Q23,46 31,49 Q35,42 39,36 L36,27 L38,27 L42,33 L52,24 L54,26 Q47,33 44,39 L54,39 L55,41 Q46,40 41,44 Q32,52 33,58 Q31,64 35,72 L41,78 L35,77 L31,80 L29,77Z',
      'M25,77 Q33,73 31,65 Q29,60 32,55 M32,51 Q37,44 41,40 M22,44 Q25,49 28,50',
      '#513d46','#86645d','#c19679');
    const dark = '#ad6876', petal = '#e098a0', sun = '#f8cbc0';
    for (const [x,y,sx,sy] of [[17,39,.79,.61],[40,39,.75,.64],[48,26,.72,.60],[30,29,.83,.68]])
      canopy(c,x,y,sx,sy,dark,petal,'#f1b4af');
    for (const [x,y,sx,sy] of [[23,28,.79,.73],[37,20,.86,.67],[12,40,.48,.47],[47,34,.6,.53]])
      canopy(c,x,y,sx,sy,petal,sun,'#fff1d9');
    for (const [x,y,s] of [[9,37,.9],[17,30,1],[24,23,.95],[30,29,.7],[35,16,1],[43,18,.78],[47,31,.9],[50,26,.7],[17,39,.68]]) {
      c.save(); c.translate(x,y); c.scale(s,s); c.fillStyle='#fff1db';
      for(let i=0;i<5;i++) { c.beginPath(); c.ellipse(0,-1.3,.8,1.3,0,0,TAU); c.fill(); c.rotate(TAU/5); }
      c.fillStyle='#dd975f'; c.beginPath(); circ(c,0,0,.65); c.fill(); c.restore();
    }
  });

  TREE_SPR.willow = makeTreeSprite(c => {
    bark(c, 'M16,79 Q26,76 25,67 Q23,59 29,50 L19,42 L12,31 L15,30 Q21,41 31,45 L33,32 L38,28 Q34,42 35,48 Q41,44 47,36 L51,36 Q46,44 37,53 Q28,64 33,72 Q35,76 47,79 L37,78 L32,80 L28,78 L23,80Z',
      'M20,78 Q29,74 27,66 Q26,61 29,57 M30,70 Q28,62 32,56 M31,53 Q33,48 31,45',
      '#45473b','#71674d','#b9a275');
    const frond = new Path2D('M0,0 C1,6 -3,14 -1,23 Q-3,20 -3,15 C-5,17 -4,19 -5,19 Q-5,13 -2,8 Q-5,12 -5,12 Q-4,5 0,0Z');
    const strand = (x,y,sx,sy,color) => {
      c.save(); c.translate(x,y); c.scale(sx,sy); c.fillStyle=color; c.fill(frond); c.restore();
    };
    for (const [x,y,sx,sy] of [[10,32,.8,1.2],[19,33,1,1.4],[28,30,1,1.1],[42,29,-1,1.4],[52,31,-1,1.4]])
      strand(x,y,sx,sy,'#405f52');
    canopy(c,23,32,1.0,.91,'#486d58','#75916b','#a7b585');
    canopy(c,40,30,.97,.88,'#597a61','#859d71','#b7c58b');
    canopy(c,31,23,.8,.67,'#72916b','#a1b382','#d2d19b');
    for (const [x,y,sx,sy] of [[9,29,.75,1.5],[14,25,1,1.65],[21,30,.86,1.05],[26,24,.7,.89],[36,29,-.66,.85],[42,22,-.82,1.03],[48,27,-.86,1.37],[53,30,-.72,1.52]])
      strand(x,y,sx,sy,'#73966c');
    for (const [x,y,sx,sy] of [[12,29,.44,1.1],[20,29,.42,.83],[44,26,-.4,1.02],[52,31,-.46,1.1]])
      strand(x,y,sx,sy,'#acbd83');
  });

  TREE_SPR.pine = makeTreeSprite(c => {
    bark(c, 'M23,79 L28,74 L30,45 L35,45 L36,73 L41,79 L34,77 L31,80 L28,78Z',
      'M28,77 L31,71 L32,62 M35,74 L35,68', '#4e4a44','#7b6454','#b49372');
    const bough = new Path2D('M0,-22 C-4,-12 -10,-6 -19,-3 L-16,-2 L-24,1 Q-17,5 -12,2 L-14,5 Q-5,7 0,4 Q8,8 13,4 L11,2 Q18,6 23,1 L17,-1 L19,-2 C10,-6 5,-13 1,-22Z');
    const snow = new Path2D('M0,-22 C-4,-13 -8,-8 -15,-5 Q-17,-3 -13,-3 Q-11,-3 -9,-5 Q-8,-3 -11,0 Q-7,2 -2,-3 Q-1,0 2,-1 L5,-3 Q9,0 13,-1 Q16,-2 14,-4 C8,-8 4,-14 1,-22Z');
    for (const [x,y,sx,sy] of [[31,62,1.05,1.08],[33,48,.85,.91],[31,36,.66,.80],[33,25,.47,.73],[32,16,.27,.65]]) {
      c.save(); c.translate(x,y); c.scale(sx,sy);
      fillTreePath(c,bough,'#3d756b','#315551',.8);
      fillTreePath(c,snow,'#eaf1de','#b5d5cd',.5);
      c.strokeStyle='#8db5a5'; c.lineWidth=.9; c.lineCap='round';
      c.stroke(new Path2D('M-14,1 Q-10,1 -6,-2 M3,2 L7,1 M15,0 L18,1'));
      c.restore();
    }
  });
  const bare = (c, trunk, tip) => {
    c.strokeStyle = trunk; c.lineCap = 'round';
    c.lineWidth = 7; c.beginPath(); c.moveTo(32, 80); c.lineTo(32, 40); c.stroke();
    c.lineWidth = 4;
    c.beginPath(); c.moveTo(32, 52); c.lineTo(16, 34); c.lineTo(10, 36); c.moveTo(16, 34); c.lineTo(14, 22); c.stroke();
    c.beginPath(); c.moveTo(32, 46); c.lineTo(48, 28); c.lineTo(56, 30); c.moveTo(48, 28); c.lineTo(46, 16); c.stroke();
    c.beginPath(); c.moveTo(32, 42); c.lineTo(30, 20); c.stroke();
    c.fillStyle = tip; for (const [x, y] of [[10, 36], [46, 16], [30, 20], [56, 30]]) { c.beginPath(); c.arc(x, y, 2.5, 0, TAU); c.fill(); }
  };
  TREE_SPR.dead = makeTreeSprite(c => bare(c, '#4a3a58', '#c77dff'));
  TREE_SPR.burnt = makeTreeSprite(c => bare(c, '#1e1414', '#ff8a2a'));
  TREE_SPR.cactus = makeTreeSprite(c => {
    const g = '#3fae4a', d = '#2a7a33';
    c.fillStyle = g; c.strokeStyle = d; c.lineWidth = 2.5;
    roundRect(c, 25, 22, 14, 58, 7); c.fill(); c.stroke();
    roundRect(c, 10, 38, 10, 22, 5); c.fill(); c.stroke(); c.fillRect(16, 52, 10, 7);
    roundRect(c, 44, 30, 10, 24, 5); c.fill(); c.stroke(); c.fillRect(38, 46, 10, 7);
    c.strokeStyle = 'rgba(255,255,255,0.35)'; c.lineWidth = 1.5; c.beginPath(); c.moveTo(29, 28); c.lineTo(29, 74); c.stroke();
    c.fillStyle = '#ff6fb5'; c.beginPath(); c.arc(32, 21, 4, 0, TAU); c.fill();
  });
  TREE_SPR.crystal = makeTreeSprite(c => {
    const shard = (x, y, w, h, col) => {
      c.fillStyle = col; c.beginPath(); c.moveTo(x, y - h); c.lineTo(x + w, y - h * 0.7); c.lineTo(x + w, y); c.lineTo(x - w, y); c.lineTo(x - w, y - h * 0.7); c.closePath(); c.fill();
      c.fillStyle = 'rgba(255,255,255,0.35)'; c.beginPath(); c.moveTo(x, y - h); c.lineTo(x - w, y - h * 0.7); c.lineTo(x - w, y); c.lineTo(x - w * 0.2, y); c.closePath(); c.fill();
    };
    shard(20, 78, 7, 34, '#7a5ad6'); shard(44, 78, 7, 30, '#5be3ff'); shard(32, 79, 9, 56, '#a98bff');
  });
  TREE_SPR.neonpalm = makeTreeSprite(c => {
    c.strokeStyle = '#ff3ea5'; c.lineWidth = 5; c.lineCap = 'round';
    c.beginPath(); c.moveTo(32, 80); c.quadraticCurveTo(26, 50, 34, 26); c.stroke();
    c.strokeStyle = '#3ff0ff'; c.lineWidth = 4;
    for (const a of [-2.6, -2.0, -1.2, -0.5, 0.2]) { c.beginPath(); c.moveTo(34, 26); c.quadraticCurveTo(34 + Math.cos(a) * 14, 26 + Math.sin(a) * 14 - 6, 34 + Math.cos(a) * 26, 26 + Math.sin(a) * 26 + 8); c.stroke(); }
    c.fillStyle = '#ffe04a'; c.beginPath(); c.arc(34, 28, 4, 0, TAU); c.fill();
  });
})();

// ---------- героиня ----------

// ===== 1.0: книжная рисовка – чернильный контур и мягкая тень внутри формы =====
const INK_C = '#4b2e1e';
function inkPart(c, p, base, shadeCol, lw = 1.1, k = 1.4) {
  c.fillStyle = shadeCol; c.fill(p);
  c.save(); c.clip(p); c.translate(-k, -k * 1.2); c.fillStyle = base; c.fill(p); c.restore();
  if (lw) { c.lineWidth = lw; c.lineJoin = 'round'; c.strokeStyle = INK_C; c.stroke(p); }
}
function inkEll(x, y, rx, ry, rot = 0) { const p = new Path2D(); p.ellipse(x, y, rx, ry, rot, 0, TAU); return p; }
const KRI_P = {
  upperWing: new Path2D('M0,0 C3,-7 12,-17 22,-19 C22,-12 18,-5 12,-2 Q6,1 0,0Z'),
  lowerWing: new Path2D('M1,0 Q12,-4 19,-2 C17,3 12,7 7,7 Q2,6 1,0Z'),
  wingVeins: new Path2D('M1,0 Q12,-8 20,-16 M11,-7 Q14,-7 17,-8 M2,1 Q11,2 17,-1'),
  wingLight: new Path2D('M8,-7 Q14,-14 20,-17 Q16,-10 13,-8Z M10,3 Q13,1 16,0 Q13,4 10,4Z'),
  backHair: new Path2D('M-6,-19 Q-12,-17 -10,-11 C-10,-6 -12,-3 -14,-3 Q-12,1 -8,-2 Q-8,1 -10,2 C-4,2 -3,-6 -3,-9Z'),
  backHairLight: new Path2D('M-8,-16 Q-11,-12 -9,-11 Q-8,-6 -12,-4 Q-7,-5 -7,-10Z'),
  dress: new Path2D('M-4,-5 Q0,-8 4,-5 L4.6,-0.5 C9.5,0.6 9.2,4.7 11.7,7.3 Q10,9.8 7.5,8.7 Q5.5,11 2.7,9.4 Q0,11.4 -2.7,9.4 Q-6,11 -7.6,8.6 Q-10,9.6 -11.7,7.3 C-9.2,4.7 -9.5,0.6 -4.6,-0.5Z'),
  pleats: new Path2D('M-4,0 Q-5,4 -8,7.5 Q-4,7 -1.6,1Z M1.4,0 Q2.7,3 3.2,8.8 Q5.5,9 7.6,7.3 Q4.5,4 3.7,0Z'),
  sash: new Path2D('M-5,-1.9 Q0,-0.6 5,-2 L5.5,-0.1 Q0,1.7 -5.5,-0.1Z'),
  arms: new Path2D('M-4,-4.7 Q-7,-4.8 -8,-1 L-9,1.2 Q-9.6,3.2 -8,3.6 Q-6.7,3.8 -6.3,1.8 L-3.9,-0.5Z M4,-4.7 Q6.6,-5 7.8,-2 L9.2,-1.3 Q11,-1.7 11.4,0 Q11.7,1.7 9.5,2 Q7.4,2 5.6,0.4L4,-1Z'),
  brooch: new Path2D('M-0.1,-4.8 L1.5,-3.8 L1.9,-2.1 L0,-0.5 L-1.7,-2.1 L-1.6,-3.8Z'),
  head: inkEll(0, -12, 8.5, 8.5),
  hair: new Path2D('M-9,-12 Q-11,-19 -4,-22 Q3,-25 8,-19 Q10,-17 9,-13.6 Q6,-13.8 4.8,-17.3 Q2,-13.9 -1.3,-14.1 L-0.4,-16.5 Q-4.3,-12.4 -7,-12.5 Q-7.4,-8.4 -8.9,-7.6 Q-10,-9.3 -9,-12Z'),
  hairLight: new Path2D('M-8,-14.2 Q-7.3,-20 -2.7,-20.3 M-4.7,-15.3 Q-1.7,-16.2 0.7,-19 M3,-18.9 Q4.5,-20 6.1,-18.4'),
  crown: new Path2D('M-4,-20 L-3.4,-25 L-1.3,-22.5 L0.2,-26.6 L1.5,-22.7 L4.5,-25 L4,-20Z'),
  crownSpark: new Path2D('M0,-25.9 L0.55,-23 L3.7,-22.4 L0.55,-21.8 L0,-19.3 L-0.55,-21.8 L-3.6,-22.4 L-0.55,-23Z'),
};

function drawFairyWing(c, side, flap, paper) {
  c.save();
  c.translate(side * 2.8, -5.2);
  c.scale(side, 1);
  c.rotate(-0.05 + flap);
  c.lineWidth = 0.95;
  c.strokeStyle = paper ? '#535273' : '#c7e9ff';
  c.fillStyle = paper ? 'rgba(176,192,242,.76)' : 'rgba(159,137,248,.69)';
  c.fill(KRI_P.lowerWing); c.stroke(KRI_P.lowerWing);
  c.fillStyle = paper ? 'rgba(198,238,242,.78)' : 'rgba(162,226,254,.76)';
  c.fill(KRI_P.upperWing); c.stroke(KRI_P.upperWing);
  c.fillStyle = 'rgba(255,255,255,.77)'; c.fill(KRI_P.wingLight);
  c.strokeStyle = paper ? '#8298ad' : '#e4edff'; c.lineWidth = 0.65; c.stroke(KRI_P.wingVeins);
  c.restore();
}

function drawKrilessa(c, x, y, t, face, s = 1, alpha = 1, moving = false) {
  c.save(); c.translate(x, y); c.scale(s * face, s); c.globalAlpha = alpha;
  const paper = PAPER_ART, outline = paper ? INK_C : '#342151';
  const bob = moving ? Math.abs(Math.sin(t * 12)) * 2 : 0;
  const flap = Math.sin(t * (moving ? 18 : 9)) * (moving ? 0.32 : 0.20);
  c.lineJoin = 'round';
  c.save(); c.translate(0, -bob);
  drawFairyWing(c, -1, flap, paper); drawFairyWing(c, 1, flap, paper);
  c.restore();
  const stride = moving ? Math.sin(t * 14) * 2.5 : 0;
  c.fillStyle = paper ? '#5a3a8a' : '#432367'; c.strokeStyle = outline; c.lineWidth = 0.9;
  c.beginPath(); c.roundRect(-5, 6 + stride, 4, 5, 1.5); c.roundRect(1, 6 - stride, 4, 5, 1.5);
  c.fill(); c.stroke();
  c.translate(0, -bob);

  c.fillStyle = '#b7adcf'; c.fill(KRI_P.backHair); c.stroke(KRI_P.backHair);
  c.fillStyle = '#faf5ff'; c.fill(KRI_P.backHairLight);
  c.fillStyle = paper ? '#ffe0c8' : '#ffd7bb'; c.fill(KRI_P.arms); c.stroke(KRI_P.arms);

  if (paper) c.fillStyle = '#bb91e9';
  else {
    const silk = c.createLinearGradient(-7, -5, 8, 10);
    silk.addColorStop(0, '#d7b4ff'); silk.addColorStop(0.48, '#a16ae2'); silk.addColorStop(1, '#613cac');
    c.fillStyle = silk;
  }
  c.fill(KRI_P.dress); c.lineWidth = 1.15; c.stroke(KRI_P.dress);
  c.fillStyle = paper ? '#8f6cc2' : '#8152bf'; c.fill(KRI_P.pleats);
  c.fillStyle = '#f4d89d'; c.fill(KRI_P.sash);

  c.fillStyle = '#fbdcc9'; c.fill(KRI_P.head); c.stroke(KRI_P.head);
  c.fillStyle = paper ? '#e7e8f1' : '#e9e5fc'; c.fill(KRI_P.hair); c.stroke(KRI_P.hair);
  c.strokeStyle = '#ffffff'; c.lineWidth = 1.15; c.lineCap = 'round'; c.stroke(KRI_P.hairLight);
  c.fillStyle = '#332342'; c.beginPath(); c.ellipse(2.1, -11.25, 1.48, 2.05, 0, 0, TAU); c.ellipse(6.45, -11.5, 1.25, 1.9, 0, 0, TAU); c.fill();
  c.fillStyle = '#fff'; c.beginPath(); circ(c, 1.65, -12.0, 0.58); circ(c, 6.12, -12.18, 0.48); c.fill();
  c.fillStyle = '#efabac'; c.beginPath(); c.ellipse(0, -8.4, 1.55, 0.85, -0.10, 0, TAU); c.fill();
  c.strokeStyle = '#925964'; c.lineWidth = 0.55; c.beginPath(); c.moveTo(3.55, -7.65); c.quadraticCurveTo(4.7, -6.9, 5.65, -7.75); c.stroke();

  c.fillStyle = '#f7cf73'; c.fill(KRI_P.crown); c.strokeStyle = outline; c.lineWidth = 0.85; c.stroke(KRI_P.crown);
  c.fillStyle = '#83d7ec'; c.beginPath(); circ(c, 0, -22.4, 1.2); c.fill();
  const sparkle = Math.max(0, Math.sin(t * 2.3)) ** 6;
  if (sparkle > 0.05) { c.globalAlpha = alpha * sparkle; c.fillStyle = '#fff'; c.fill(KRI_P.crownSpark); c.globalAlpha = alpha; }

  c.fillStyle = '#f5ad41'; c.fill(KRI_P.brooch); c.strokeStyle = '#825124'; c.lineWidth = 0.65; c.stroke(KRI_P.brooch);
  c.fillStyle = '#fff1a8'; c.fillRect(-0.9, -3.7, 1, 1);
  c.restore();
}
const SLIME_P = new Path2D('M-14,7 C-16,-6 -9,-16 0,-16 C9,-16 16,-6 14,7 Q0,11 -14,7 Z');
const BAT_WING_P = new Path2D('M4,-3 Q12,-14 20,-10 L16,-3 L20,3 L13,1 L10,5 L5,3 Z');
const BAT_BODY_P = inkEll(0, 0, 8, 7.5);
const BAT_EARS_P = new Path2D('M-6,-4 L-5,-11 L-2,-6 Z M6,-4 L5,-11 L2,-6 Z');
function slimePaper(c, e) {
  const sq = 1 + Math.sin(e.t * 6 + e.seed) * 0.13;
  c.save(); c.scale(1 / sq, sq);
  inkPart(c, SLIME_P, e.col, shade(e.col, -0.28), 1.3, 1.8);
  c.fillStyle = 'rgba(255,255,255,.7)'; c.beginPath(); c.ellipse(-7, -9, 3, 1.8, -0.6, 0, TAU); c.fill(); c.beginPath(); c.arc(-2.5, -12, 1, 0, TAU); c.fill();
  c.restore();
  lookEyes(c, -4.5, 4.5, -4, 3.2, e.look, '#ffffff', '#2a1810');
  c.strokeStyle = INK_C; c.lineWidth = 1.2; c.beginPath(); c.arc(0, 1, 2.6, 0.25, Math.PI - 0.25); c.stroke();
}
function batPaper(c, e) {
  const f = Math.sin(e.t * 22) * 0.6, wc = shade(e.col, -0.2);
  for (const sd of [-1, 1]) { c.save(); c.scale(sd, 1); c.rotate(f * 0.5); inkPart(c, BAT_WING_P, wc, shade(e.col, -0.4), 1, 1.2); c.restore(); }
  inkPart(c, BAT_EARS_P, e.col, shade(e.col, -0.3), 0.9, 0.8);
  inkPart(c, BAT_BODY_P, e.col, shade(e.col, -0.3), 1.1, 1.4);
  c.fillStyle = '#ffd84a'; c.beginPath(); circ(c, -3, -1, 1.9); circ(c, 3, -1, 1.9); c.fill();
  c.fillStyle = '#2a1810'; c.beginPath(); circ(c, -3, -0.8, 0.8); circ(c, 3, -0.8, 0.8); c.fill();
  c.fillStyle = '#fff'; c.fillRect(-2, 3, 1.2, 2); c.fillRect(1, 3, 1.2, 2);
}
// ---------- враги ----------
// Рисуются в локальных координатах (0,0 – центр), e.look – угол на героиню
const ESPR = {
  slime(c, e) {
    if (PAPER_ART) { slimePaper(c, e); return; }
    const sq = 1 + Math.sin(e.t * 6 + e.seed) * 0.13;
    c.save(); c.scale(1 / sq, sq);
    c.fillStyle = glossGrad(c, 0, -4, 15, e.col);
    c.beginPath(); c.moveTo(-14, 7); c.bezierCurveTo(-16, -6, -9, -16, 0, -16); c.bezierCurveTo(9, -16, 16, -6, 14, 7); c.quadraticCurveTo(0, 11, -14, 7); c.closePath();
    c.fill(); c.lineWidth = 2; c.strokeStyle = 'rgba(20,8,30,0.7)'; c.stroke();
    gloss(c, -6, -9, 3.5, 5);
    c.restore();
    lookEyes(c, -4.5, 4.5, -4, 3.2, e.look);
    c.strokeStyle = '#1b1030'; c.lineWidth = 1.5; c.beginPath(); c.arc(0, 1, 3, 0.2, Math.PI - 0.2); c.stroke();
  },
  bat(c, e) {
    if (PAPER_ART) { batPaper(c, e); return; }
    const f = Math.sin(e.t * 22) * 0.6;
    const wc = shade(e.col, -0.25);
    for (const s of [-1, 1]) {
      c.save(); c.scale(s, 1); c.rotate(f * 0.5);
      c.fillStyle = wc; c.strokeStyle = 'rgba(0,0,0,0.6)'; c.lineWidth = 1.5;
      c.beginPath(); c.moveTo(4, -3); c.quadraticCurveTo(12, -14, 20, -10); c.lineTo(16, -3); c.lineTo(20, 3); c.lineTo(13, 1); c.lineTo(10, 5); c.lineTo(5, 3); c.closePath(); c.fill(); c.stroke();
      c.restore();
    }
    blob(c, 0, 0, 8, 7.5, e.col, 1.5);
    c.fillStyle = e.col; c.beginPath(); c.moveTo(-6, -4); c.lineTo(-5, -11); c.lineTo(-2, -6); c.moveTo(6, -4); c.lineTo(5, -11); c.lineTo(2, -6); c.fill();
    c.fillStyle = '#ff3b3b'; c.beginPath(); circ(c, -3, -1, 1.8); circ(c, 3, -1, 1.8); c.fill();
    c.fillStyle = '#fff'; c.fillRect(-2, 3, 1.2, 2); c.fillRect(1, 3, 1.2, 2);
  },
  shroom(c, e) {
    c.rotate(Math.sin(e.t * 8 + e.seed) * 0.08);
    c.fillStyle = glossGrad(c, 0, 2, 9, '#f2e3c8'); roundRect(c, -7, -4, 14, 13, 4); c.fill();
    c.strokeStyle = 'rgba(0,0,0,0.5)'; c.lineWidth = 1.5; c.stroke();
    lookEyes(c, -3, 3, 1.5, 2.2, e.look);
    c.fillStyle = glossGrad(c, 0, -8, 16, e.col);
    c.beginPath(); c.ellipse(0, -5, 16, 11, 0, Math.PI, TAU); c.quadraticCurveTo(0, -1, -16, -5); c.closePath(); c.fill();
    c.strokeStyle = 'rgba(20,8,30,0.7)'; c.lineWidth = 2; c.stroke();
    c.fillStyle = '#fff'; c.beginPath(); circ(c, -8, -9, 2.6); circ(c, 1, -13, 2.2); circ(c, 9, -8, 2.4); c.fill();
  },
  pumpkin(c, e) {
    const pulse = e.fuse > 0 ? 1 + Math.sin(e.t * 40) * 0.08 : 1;
    c.scale(pulse, pulse);
    const col = e.fuse > 0 && Math.floor(e.t * 16) % 2 ? '#ff3b3b' : e.col;
    blob(c, -6, 0, 8, 11, col, 1.5); blob(c, 6, 0, 8, 11, col, 1.5); blob(c, 0, 0, 9, 12, col, 1.5);
    c.fillStyle = '#3f8a2a'; c.fillRect(-1.5, -16, 3, 6);
    c.fillStyle = '#ffe04a';
    c.beginPath(); c.moveTo(-7, -4); c.lineTo(-3, -4); c.lineTo(-5, -8); c.closePath(); c.moveTo(7, -4); c.lineTo(3, -4); c.lineTo(5, -8); c.closePath(); c.fill();
    c.beginPath(); c.moveTo(-7, 3); c.lineTo(-4, 6); c.lineTo(-1, 3); c.lineTo(2, 6); c.lineTo(5, 3); c.lineTo(7, 3); c.lineTo(0, 9); c.closePath(); c.fill();
  },
  frog(c, e) {
    const j = e.wind > 0 ? 0.8 : e.jd > 0 ? 1.25 : 1;
    c.scale(1 / j, j);
    blob(c, 0, 0, 14, 11, e.col);
    c.fillStyle = shade(e.col, 0.5); c.beginPath(); c.ellipse(0, 4, 8, 5, 0, 0, TAU); c.fill();
    blob(c, -6, -9, 5, 5, e.col, 1.5); blob(c, 6, -9, 5, 5, e.col, 1.5);
    lookEyes(c, -6, 6, -9, 3.2, e.look);
    c.strokeStyle = '#1e3a12'; c.lineWidth = 1.5; c.beginPath(); c.arc(0, -1, 6, 0.3, Math.PI - 0.3); c.stroke();
  },
  wisp(c, e) {
    const p = 1 + Math.sin(e.t * 9) * 0.12;
    c.fillStyle = 'rgba(160,255,120,0.22)'; c.beginPath(); c.arc(0, 0, 17 * p, 0, TAU); c.fill();
    c.fillStyle = e.col;
    c.beginPath(); c.moveTo(-8, 2); c.quadraticCurveTo(-4, 16 + Math.sin(e.t * 10) * 3, 0, 20); c.quadraticCurveTo(4, 16, 8, 2); c.fill();
    blob(c, 0, 0, 9, 9, e.col, 0);
    c.fillStyle = '#ffffff'; c.beginPath(); circ(c, 0, 0, 4); c.fill();
    lookEyes(c, -3.5, 3.5, -2, 2, e.look, '#ffffff', '#1a4a1a');
  },
  shaman(c, e) {
    const b = Math.sin(e.t * 3) * 1.5;
    c.strokeStyle = '#6b4a2a'; c.lineWidth = 2.5; c.beginPath(); c.moveTo(10, 10); c.lineTo(12, -18 + b); c.stroke();
    c.fillStyle = e.healing > 0 ? '#ffffff' : '#7dff9a'; c.beginPath(); c.arc(12, -20 + b, 4, 0, TAU); c.fill();
    c.fillStyle = 'rgba(125,255,154,0.3)'; c.beginPath(); c.arc(12, -20 + b, 7, 0, TAU); c.fill();
    c.fillStyle = glossGrad(c, 0, 0, 13, e.col);
    c.beginPath(); c.moveTo(-11, 11); c.quadraticCurveTo(-12, -14, 0, -16); c.quadraticCurveTo(12, -14, 11, 11); c.closePath(); c.fill();
    c.strokeStyle = 'rgba(0,0,0,0.6)'; c.lineWidth = 2; c.stroke();
    c.fillStyle = '#1b1030'; c.beginPath(); c.ellipse(0, -5, 7, 6, 0, 0, TAU); c.fill();
    c.fillStyle = '#ffe04a'; c.beginPath(); circ(c, -2.5, -5, 1.5); circ(c, 2.5, -5, 1.5); c.fill();
    c.fillStyle = '#e04a4a'; c.fillRect(-11, 2, 22, 2);
  },
  wolf(c, e) {
    c.scale(e.face, 1);
    const r = Math.sin(e.t * 14) * 2.5;
    c.fillStyle = shade(e.col, -0.2);
    c.fillRect(-10, 4 + r, 4, 7); c.fillRect(5, 4 - r, 4, 7);
    c.fillStyle = e.col; c.beginPath(); c.moveTo(-13, -2); c.quadraticCurveTo(-24, -12, -20, 2); c.closePath(); c.fill();
    blob(c, -2, 0, 13, 8, e.col);
    blob(c, 10, -5, 7.5, 7, e.col);
    c.fillStyle = e.col; c.beginPath(); c.moveTo(6, -10); c.lineTo(8, -18); c.lineTo(11, -10); c.closePath(); c.moveTo(11, -10); c.lineTo(14, -17); c.lineTo(15, -9); c.closePath(); c.fill();
    c.fillStyle = shade(e.col, -0.5); c.beginPath(); c.arc(17, -4, 2, 0, TAU); c.fill();
    c.fillStyle = '#5be3ff'; c.beginPath(); c.arc(12, -6, 1.8, 0, TAU); c.fill();
  },
  snowman(c, e) {
    blob(c, 0, 5, 12, 11, '#ffffff'); blob(c, 0, -10, 8.5, 8, '#ffffff');
    c.strokeStyle = '#6b4a2a'; c.lineWidth = 2;
    const w = Math.sin(e.t * 4) * 3;
    c.beginPath(); c.moveTo(-10, 0); c.lineTo(-19, -6 + w); c.moveTo(10, 0); c.lineTo(19, -6 - w); c.stroke();
    lookEyes(c, -3, 3, -11, 2, e.look, '#222222', '#000000');
    c.fillStyle = '#ff8a1f'; c.beginPath(); c.moveTo(0, -9); c.lineTo(8, -8); c.lineTo(0, -6.5); c.fill();
    c.fillStyle = '#d63b3b'; c.fillRect(-8, -3, 16, 3);
    c.fillStyle = '#222'; c.fillRect(-6, -22, 12, 5); c.fillRect(-8, -18, 16, 2);
  },
  iceguard(c, e) {
    blob(c, 0, 2, 13, 13, e.col);
    c.fillStyle = shade(e.col, -0.35); roundRect(c, -9, -15, 18, 13, 5); c.fill();
    c.fillStyle = '#e8fbff'; c.fillRect(-6, -10, 12, 3);
    c.fillStyle = '#1b3a5a'; c.fillRect(-5, -9.5, 10, 2);
    c.fillStyle = '#ffffff'; c.beginPath(); c.moveTo(0, -15); c.lineTo(-3, -21); c.lineTo(3, -21); c.fill();
  },
  shade(c, e) {
    const w = e.t * 6;
    const g = c.createLinearGradient(0, -16, 0, 12);
    g.addColorStop(0, shade(e.col, 0.25)); g.addColorStop(1, 'rgba(30,8,50,0.2)');
    c.fillStyle = g;
    c.beginPath(); c.moveTo(-12, 10);
    c.quadraticCurveTo(-14, -16, 0, -16); c.quadraticCurveTo(14, -16, 12, 10);
    for (let k = 0; k < 4; k++) { c.lineTo(12 - (k + 0.5) * 6, 5 + Math.sin(w + k) * 3); c.lineTo(12 - (k + 1) * 6, 10); }
    c.closePath(); c.fill();
    c.fillStyle = '#ff5bf0';
    const ox = Math.cos(e.look) * 1.5, oy = Math.sin(e.look) * 1;
    c.beginPath(); c.ellipse(-4 + ox, -5 + oy, 2.5, 3.5, 0, 0, TAU); c.ellipse(4 + ox, -5 + oy, 2.5, 3.5, 0, 0, TAU); c.fill();
  },
  imp(c, e) {
    const f = Math.sin(e.t * 20) * 0.5;
    c.fillStyle = shade(e.col, -0.5);
    for (const s of [-1, 1]) { c.save(); c.scale(s, 1); c.rotate(f * 0.4); c.beginPath(); c.moveTo(5, -4); c.lineTo(17, -13); c.lineTo(13, 2); c.closePath(); c.fill(); c.restore(); }
    c.strokeStyle = shade(e.col, -0.4); c.lineWidth = 2; c.beginPath(); c.moveTo(0, 8); c.quadraticCurveTo(6, 16, 2, 18); c.stroke();
    blob(c, 0, 0, 10, 10, e.col);
    c.fillStyle = '#ffe9a0'; c.beginPath(); c.moveTo(-7, -7); c.lineTo(-9, -15); c.lineTo(-3, -9); c.moveTo(7, -7); c.lineTo(9, -15); c.lineTo(3, -9); c.fill();
    lookEyes(c, -3.5, 3.5, -2, 2.4, e.look, '#ffeb3b', '#3a0000');
    if (e.charge > 0) { c.fillStyle = `rgba(255,220,80,${0.4 + Math.sin(e.t * 30) * 0.3})`; c.beginPath(); c.arc(0, 0, 14, 0, TAU); c.fill(); }
  },
  bee(c, e) {
    const f = Math.sin(e.t * 40);
    c.fillStyle = 'rgba(220,245,255,0.75)';
    c.beginPath(); c.ellipse(-4, -8, 4, 7 + f * 1.5, -0.4, 0, TAU); c.ellipse(4, -8, 4, 7 - f * 1.5, 0.4, 0, TAU); c.fill();
    blob(c, 0, 0, 8, 7, e.col, 1.5);
    c.fillStyle = '#1b1030'; c.fillRect(-2, -6, 2.5, 12); c.fillRect(3.5, -5, 2, 10);
    c.fillStyle = '#1b1030'; c.beginPath(); c.moveTo(-8, 0); c.lineTo(-12, -1); c.lineTo(-8, 2); c.fill();
    lookEyes(c, 4, 7.5, -2, 1.8, e.look);
  },
  flower(c, e) {
    const open = e.charge > 0 ? 1.25 : 1;
    c.fillStyle = '#3f8a2a';
    c.beginPath(); c.ellipse(-9, 10, 8, 3, -0.4, 0, TAU); c.ellipse(9, 10, 8, 3, 0.4, 0, TAU); c.fill();
    c.save(); c.rotate(e.t * 0.6);
    for (let k = 0; k < 7; k++) {
      c.rotate(TAU / 7);
      c.fillStyle = k % 2 ? e.col : shade(e.col, 0.3);
      c.beginPath(); c.ellipse(0, -11 * open, 5, 9, 0, 0, TAU); c.fill();
    }
    c.restore();
    blob(c, 0, 0, 8, 8, '#ffd23a', 1.5);
    lookEyes(c, -3, 3, -1, 2, e.look);
    c.fillStyle = '#7a1a3a'; c.beginPath(); c.ellipse(0, 4, 2.5, e.charge > 0 ? 3 : 1.2, 0, 0, TAU); c.fill();
  },
  beetle(c, e) {
    const l = Math.sin(e.t * 12) * 2;
    c.strokeStyle = '#1b1030'; c.lineWidth = 2;
    for (const s of [-1, 1]) for (const y of [-5, 1, 7]) { c.beginPath(); c.moveTo(s * 10, y); c.lineTo(s * 17, y + (y === 1 ? l : -l)); c.stroke(); }
    blob(c, 0, 2, 13, 14, e.col);
    c.strokeStyle = 'rgba(0,0,0,0.5)'; c.beginPath(); c.moveTo(0, -11); c.lineTo(0, 15); c.stroke();
    gloss(c, -5, -3, 3, 6, 0.5);
    blob(c, 0, -13, 7, 5, shade(e.col, -0.4), 1.5);
    c.fillStyle = '#ffd23a'; c.beginPath(); circ(c, -3, -14, 1.5); circ(c, 3, -14, 1.5); c.fill();
  },
  scorpion(c, e) {
    c.scale(e.face, 1);
    const l = Math.sin(e.t * 16) * 2;
    c.strokeStyle = shade(e.col, -0.4); c.lineWidth = 2;
    for (const x of [-6, 0, 6]) { c.beginPath(); c.moveTo(x, 4); c.lineTo(x - 3, 11 + l); c.stroke(); }
    blob(c, 0, 0, 12, 7, e.col);
    blob(c, 14, -2, 5, 4, e.col, 1.5); blob(c, 15, 4, 4, 3, e.col, 1.5);
    const glow = e.wind > 0;
    c.strokeStyle = e.col; c.lineWidth = 4; c.lineCap = 'round';
    c.beginPath(); c.moveTo(-10, -2); c.quadraticCurveTo(-22, -14, -10, -20); c.stroke(); c.lineCap = 'butt';
    c.fillStyle = glow ? '#ff3b3b' : shade(e.col, -0.4); c.beginPath(); c.arc(-8, -20, 3.5, 0, TAU); c.fill();
    c.fillStyle = '#1b1030'; c.beginPath(); circ(c, 8, -3, 1.4); circ(c, 11, -3, 1.4); c.fill();
  },
  tumble(c, e) {
    c.rotate(e.t * 9 * (e.vx >= 0 ? 1 : -1));
    c.strokeStyle = e.col; c.lineWidth = 2;
    for (let k = 0; k < 7; k++) { c.beginPath(); c.arc(0, 0, 11 - k % 3, k * 0.9, k * 0.9 + 2.4); c.stroke(); }
    c.strokeStyle = shade(e.col, -0.35);
    for (let k = 0; k < 5; k++) { c.beginPath(); c.moveTo(Math.cos(k * 1.3) * 11, Math.sin(k * 1.3) * 11); c.lineTo(Math.cos(k * 1.3 + 2.6) * 11, Math.sin(k * 1.3 + 2.6) * 11); c.stroke(); }
  },
  mummy(c, e) {
    const s = e.small ? 0.7 : 1;
    c.scale(s, s);
    const w = Math.sin(e.t * 5) * 2;
    c.strokeStyle = e.col; c.lineWidth = 4; c.lineCap = 'round';
    c.beginPath(); c.moveTo(-10, -2); c.lineTo(-18, -6 + w); c.moveTo(10, -2); c.lineTo(18, -6 - w); c.stroke(); c.lineCap = 'butt';
    blob(c, 0, 0, 12, 15, e.col);
    c.strokeStyle = 'rgba(120,100,70,0.6)'; c.lineWidth = 1.5;
    for (let y = -10; y < 14; y += 5) { c.beginPath(); c.moveTo(-11, y); c.lineTo(11, y + 3); c.stroke(); }
    c.fillStyle = '#1b1030'; c.fillRect(-8, -9, 16, 5);
    c.fillStyle = '#7dff4a'; c.beginPath(); c.arc(-3 + Math.cos(e.look) * 1.5, -6.5, 2, 0, TAU); c.fill();
  },
  bomb(c, e) {
    const pulse = e.fuse > 0 ? 1 + Math.sin(e.t * 40) * 0.1 : 1;
    c.scale(pulse, pulse);
    blob(c, 0, 0, 12, 12, e.fuse > 0 && Math.floor(e.t * 16) % 2 ? '#a01818' : e.col);
    gloss(c, -4, -5, 3, 4, 0.5);
    c.strokeStyle = '#8a6a3a'; c.lineWidth = 2; c.beginPath(); c.moveTo(0, -12); c.quadraticCurveTo(4, -18, 8, -17); c.stroke();
    c.fillStyle = Math.floor(e.t * 20) % 2 ? '#ffe04a' : '#ff6a22'; star(c, 8, -17, 4, e.t * 5); c.fill();
    brows(c, -4, 4, -3, 3, 0.5, '#ff4a4a');
    c.fillStyle = '#ffffff'; c.beginPath(); circ(c, -4, 0, 2); circ(c, 4, 0, 2); c.fill();
  },
  spider(c, e) {
    const l = e.t * 18;
    c.strokeStyle = shade(e.col, -0.45); c.lineWidth = 1.8;
    for (const s of [-1, 1]) for (let k = 0; k < 4; k++) {
      const a = (k - 1.5) * 0.45 + Math.sin(l + k + (s > 0 ? 1.5 : 0)) * 0.2;
      c.beginPath(); c.moveTo(0, 0); c.lineTo(s * Math.cos(a) * 9, Math.sin(a) * 9 - 4); c.lineTo(s * Math.cos(a) * 14, Math.sin(a) * 14 + 4); c.stroke();
    }
    c.fillStyle = e.col; c.beginPath(); c.moveTo(0, -9); c.lineTo(7, 0); c.lineTo(0, 9); c.lineTo(-7, 0); c.closePath(); c.fill();
    c.fillStyle = 'rgba(255,255,255,0.4)'; c.beginPath(); c.moveTo(0, -9); c.lineTo(-7, 0); c.lineTo(0, 0); c.fill();
    c.fillStyle = '#ff3b6b'; c.beginPath(); circ(c, -2, -3, 1.3); circ(c, 2, -3, 1.3); circ(c, -1, -5.5, 1); circ(c, 1, -5.5, 1); c.fill();
  },
  cshaman(c, e) {
    const b = Math.sin(e.t * 3) * 3;
    for (let k = 0; k < 3; k++) {
      const a = e.t * 2 + k * TAU / 3;
      c.fillStyle = '#5be3ff'; c.beginPath(); c.moveTo(Math.cos(a) * 18, Math.sin(a) * 10 - 4 - 4); c.lineTo(Math.cos(a) * 18 + 3, Math.sin(a) * 10 - 4); c.lineTo(Math.cos(a) * 18, Math.sin(a) * 10 - 4 + 4); c.lineTo(Math.cos(a) * 18 - 3, Math.sin(a) * 10 - 4); c.fill();
    }
    c.fillStyle = glossGrad(c, 0, b, 14, e.col);
    c.beginPath(); c.moveTo(0, -16 + b); c.lineTo(11, -2 + b); c.lineTo(6, 12 + b); c.lineTo(-6, 12 + b); c.lineTo(-11, -2 + b); c.closePath(); c.fill();
    c.strokeStyle = 'rgba(0,0,30,0.6)'; c.lineWidth = 2; c.stroke();
    lookEyes(c, -3.5, 3.5, -3 + b, 2.2, e.look, '#ffffff', '#0a2a4a');
    if (e.healing > 0) { c.strokeStyle = 'rgba(125,255,154,0.8)'; c.lineWidth = 3; c.beginPath(); c.arc(0, b, 20, 0, TAU); c.stroke(); }
  },
  cguard(c, e) {
    c.fillStyle = glossGrad(c, 0, 0, 16, e.col);
    c.beginPath(); c.moveTo(0, -18); c.lineTo(14, -8); c.lineTo(15, 8); c.lineTo(0, 16); c.lineTo(-15, 8); c.lineTo(-14, -8); c.closePath(); c.fill();
    c.strokeStyle = 'rgba(20,0,40,0.7)'; c.lineWidth = 2; c.stroke();
    c.strokeStyle = 'rgba(255,255,255,0.4)'; c.beginPath(); c.moveTo(0, -18); c.lineTo(0, 16); c.moveTo(-14, -8); c.lineTo(15, 8); c.stroke();
    c.fillStyle = '#ff3b6b'; c.beginPath(); c.ellipse(Math.cos(e.look) * 3, -6, 5, 2, 0, 0, TAU); c.fill();
  },
  bot(c, e) {
    const d = Math.sin(e.t * 8) * 2;
    c.translate(0, d);
    c.fillStyle = '#2a2a3a'; c.fillRect(-7, 9, 4, 6 - d); c.fillRect(3, 9, 4, 6 + d);
    c.fillStyle = glossGrad(c, 0, 4, 10, e.col); roundRect(c, -9, -2, 18, 13, 4); c.fill();
    c.fillStyle = '#1b1030'; roundRect(c, -12, -19, 24, 17, 4); c.fill();
    c.strokeStyle = '#3ff0ff'; c.lineWidth = 2; c.stroke();
    const em = ['😂', '🤪', '💅', '😎'][Math.floor(e.t * 1.5 + e.seed) % 4];
    const spr = emojiSprite(em, 12);
    c.drawImage(spr, -spr.width / 4, -10.5 - spr.height / 4, spr.width / 2, spr.height / 2);
    c.strokeStyle = '#aaa'; c.lineWidth = 1.5; c.beginPath(); c.moveTo(0, -19); c.lineTo(0, -25); c.stroke();
    c.fillStyle = Math.floor(e.t * 6) % 2 ? '#ff3ea5' : '#3ff0ff'; c.beginPath(); c.arc(0, -26, 2.5, 0, TAU); c.fill();
  },
  hater(c, e) {
    c.fillStyle = glossGrad(c, 0, 2, 13, '#2a2a2a');
    c.beginPath(); c.moveTo(-12, 12); c.quadraticCurveTo(-14, -14, 0, -17); c.quadraticCurveTo(14, -14, 12, 12); c.closePath(); c.fill();
    c.strokeStyle = '#000'; c.lineWidth = 2; c.stroke();
    c.fillStyle = '#0a0a0a'; c.beginPath(); c.ellipse(0, -6, 8, 7, 0, 0, TAU); c.fill();
    const ox = Math.cos(e.look) * 1.5;
    c.fillStyle = '#ff2a2a'; c.beginPath(); c.ellipse(-3 + ox, -6, 2.2, 1.3, 0.3, 0, TAU); c.ellipse(3 + ox, -6, 2.2, 1.3, -0.3, 0, TAU); c.fill();
    const spr = emojiSprite('💢', 9);
    c.drawImage(spr, -spr.width / 4, 5 - spr.height / 4, spr.width / 2, spr.height / 2);
  },
  fan(c, e) {
    const big = e.type === 'zclone';
    const s = big ? 1.6 : 1;
    c.scale(s, s);
    const d = Math.sin(e.t * 9 + e.seed) * 0.5;
    c.strokeStyle = '#f5f2ea'; c.lineWidth = 3; c.lineCap = 'round';
    c.beginPath(); c.moveTo(-6, 3); c.lineTo(-12, -4 + d * 8); c.moveTo(6, 3); c.lineTo(12, -4 - d * 8); c.stroke(); c.lineCap = 'butt';
    c.fillStyle = '#f5f2ea'; roundRect(c, -7, 0, 14, 12, 4); c.fill();
    c.strokeStyle = '#ffd25a'; c.lineWidth = 1; c.beginPath(); c.arc(0, 1, 4, 0.3, Math.PI - 0.3); c.stroke();
    if (ART.zyamaSmall) {
      c.save(); c.beginPath(); c.arc(0, -6, 9, 0, TAU); c.clip();
      c.drawImage(ART.zyamaSmall, -9, -15, 18, 18); c.restore();
    }
    c.strokeStyle = big ? '#ff3ea5' : '#ffd25a'; c.lineWidth = 1.5; c.beginPath(); c.arc(0, -6, 9, 0, TAU); c.stroke();
  },
};

// Щит у щитоносцев (рисуется отдельно, в мировом угле)
function drawEnemyShield(c, e, col) {
  c.save(); c.rotate(e.shieldAng);
  c.strokeStyle = shade(col, 0.4); c.lineWidth = 5; c.lineCap = 'round';
  c.beginPath(); c.arc(0, 0, e.r + 7, -1.05, 1.05); c.stroke();
  c.strokeStyle = 'rgba(255,255,255,0.7)'; c.lineWidth = 1.5;
  c.beginPath(); c.arc(0, 0, e.r + 9, -0.8, 0.8); c.stroke();
  c.restore(); c.lineCap = 'butt';
}

// ---------- боссы ----------
const BSPR = {
  shroom(c, b, t, face) {
    const sq = 1 + Math.sin(t * 4) * 0.04 + (b.mode === 'stomp' ? Math.sin(t * 30) * 0.06 : 0);
    c.scale(1 / sq, sq);
    const fl = b.flash > 0;
    c.fillStyle = fl ? '#fff' : glossGrad(c, 0, 10, 28, '#f3e2c4'); c.strokeStyle = '#5a3a1a'; c.lineWidth = 3;
    roundRect(c, -20, -10, 40, 42, 10); c.fill(); c.stroke();
    c.fillStyle = '#5a3a1a'; c.fillRect(-18, 26, 12, 8); c.fillRect(6, 26, 12, 8);
    lookEyes(c, -9, 9, 6, 6, b.look, '#fff', '#300');
    brows(c, -9, 9, -3, 6, b.stage >= 2 ? 0.7 : 0.35, '#300');
    c.strokeStyle = '#300'; c.lineWidth = 3; c.beginPath(); c.arc(0, 22, 7, Math.PI + 0.3, TAU - 0.3); c.stroke();
    const cap = b.stage >= 2 ? '#ff1a1a' : '#d8322b';
    c.fillStyle = fl ? '#fff' : glossGrad(c, 0, -22, 46, cap); c.strokeStyle = '#6a0f0b'; c.lineWidth = 3;
    c.beginPath(); c.ellipse(0, -10, 46, 30, 0, Math.PI, TAU); c.closePath(); c.fill(); c.stroke();
    c.fillStyle = '#fff';
    for (const [x, y, r] of [[-26, -18, 7], [-6, -30, 6], [16, -22, 8], [32, -12, 5], [-38, -10, 4]]) { c.beginPath(); c.arc(x, y, r, 0, TAU); c.fill(); }
  },
  toad(c, b, t, face) {
    const sq = 1 + Math.sin(t * 3) * 0.05;
    c.scale(sq, 1 / sq);
    const fl = b.flash > 0, col = fl ? '#ffffff' : '#4caf50';
    blob(c, -30, 24, 14, 9, col, 3); blob(c, 30, 24, 14, 9, col, 3);
    blob(c, 0, 4, 46, 34, col, 3);
    c.fillStyle = fl ? '#fff' : '#c5e1a5'; c.beginPath(); c.ellipse(0, 14, 30, 18, 0, 0, TAU); c.fill();
    blob(c, -18, -26, 13, 13, col, 3); blob(c, 18, -26, 13, 13, col, 3);
    lookEyes(c, -18, 18, -26, 8, b.look, '#fff59d', '#111');
    c.strokeStyle = '#1b5e20'; c.lineWidth = 3; c.beginPath(); c.moveTo(-22, 0); c.quadraticCurveTo(0, 12, 22, 0); c.stroke();
    c.save(); if (b.stage >= 2) { c.translate(10, -4); c.rotate(0.4); }
    c.fillStyle = '#ffd25a'; c.strokeStyle = '#b8860b'; c.lineWidth = 2;
    c.beginPath(); c.moveTo(-14, -36); c.lineTo(-14, -50); c.lineTo(-7, -42); c.lineTo(0, -54); c.lineTo(7, -42); c.lineTo(14, -50); c.lineTo(14, -36); c.closePath(); c.fill(); c.stroke();
    c.fillStyle = '#ff4081'; c.beginPath(); c.arc(0, -42, 3, 0, TAU); c.fill();
    c.restore();
  },
  yeti(c, b, t, face) {
    const step = b.charging ? Math.sin(t * 30) * 4 : Math.sin(t * 6) * 2;
    const fl = b.flash > 0, col = fl ? '#ffffff' : '#eef6ff';
    c.fillStyle = col; c.strokeStyle = '#7fa3c4'; c.lineWidth = 3;
    c.beginPath(); c.ellipse(-20, 34 + step, 12, 8, 0, 0, TAU); c.fill(); c.stroke();
    c.beginPath(); c.ellipse(20, 34 - step, 12, 8, 0, 0, TAU); c.fill(); c.stroke();
    c.beginPath(); c.ellipse(-44, 4 - step, 12, 22, 0.3, 0, TAU); c.fill(); c.stroke();
    c.beginPath(); c.ellipse(44, 4 + step, 12, 22, -0.3, 0, TAU); c.fill(); c.stroke();
    c.fillStyle = fl ? '#fff' : glossGrad(c, 0, 0, 44, '#eef6ff');
    c.beginPath();
    for (let i = 0; i <= 20; i++) { const a = (i / 20) * TAU, r = 40 + (i % 2) * 4; c.lineTo(Math.cos(a) * r, Math.sin(a) * r * 0.95); }
    c.closePath(); c.fill(); c.stroke();
    c.fillStyle = fl ? '#fff' : '#7fb8e6'; c.beginPath(); c.ellipse(0, -8, 22, 18, 0, 0, TAU); c.fill();
    lookEyes(c, -9, 9, -12, 5, b.look, '#fff', b.stage >= 2 ? '#d81b1b' : '#0b2a4a');
    c.fillStyle = '#0b2a4a'; c.beginPath(); c.ellipse(0, 2, 10, b.charging ? 7 : 4, 0, 0, TAU); c.fill();
    c.fillStyle = '#fff'; c.fillRect(-7, -1, 4, 4); c.fillRect(3, -1, 4, 4);
    c.fillStyle = '#c9d7e6';
    c.beginPath(); c.moveTo(-26, -30); c.lineTo(-36, -50); c.lineTo(-18, -36); c.fill();
    c.beginPath(); c.moveTo(26, -30); c.lineTo(36, -50); c.lineTo(18, -36); c.fill();
    if (b.stage >= 2) { c.fillStyle = 'rgba(120,200,255,0.6)'; for (let k = 0; k < 3; k++) { c.beginPath(); c.arc(-30 + k * 30, 40 + ((t * 40 + k * 13) % 20), 3, 0, TAU); c.fill(); } }
  },
  mrak(c, b, t, face) {
    const fly = Math.sin(t * 2.5) * 5;
    c.translate(0, fly);
    const eyeCol = b.stage >= 1 ? '#ff3b6b' : '#ff5bf0';
    { const og = c.createRadialGradient(face * 40, -40, 2, face * 40, -40, 22); og.addColorStop(0, b.stage >= 1 ? 'rgba(255,60,110,0.55)' : 'rgba(255,91,240,0.5)'); og.addColorStop(1, 'rgba(255,91,240,0)');
      c.fillStyle = og; c.beginPath(); c.arc(face * 40, -40, 22 + Math.sin(t * 6) * 3, 0, TAU); c.fill(); } // сияние шара посоха
    c.fillStyle = b.stage >= 2 ? 'rgba(255,59,107,0.2)' : 'rgba(199,125,255,0.18)'; c.beginPath(); c.arc(0, 0, 54 + Math.sin(t * 5) * 4, 0, TAU); c.fill();
    c.fillStyle = b.flash > 0 ? '#fff' : '#2a1240'; c.strokeStyle = '#c77dff'; c.lineWidth = 2.5;
    c.beginPath(); c.moveTo(-30, 36);
    for (let k = 0; k <= 6; k++) c.lineTo(-30 + k * 10, 36 + (k % 2 ? 8 : 0) + Math.sin(t * 6 + k) * 2);
    c.lineTo(30, 36); c.quadraticCurveTo(26, -20, 0, -40); c.quadraticCurveTo(-26, -20, -30, 36); c.closePath(); c.fill(); c.stroke();
    c.fillStyle = '#000'; c.beginPath(); c.ellipse(0, -14, 16, 14, 0, 0, TAU); c.fill();
    c.fillStyle = eyeCol;
    c.beginPath(); c.ellipse(-6, -15, 4, 2.5, 0.3, 0, TAU); c.ellipse(6, -15, 4, 2.5, -0.3, 0, TAU); c.fill();
    if (b.stage >= 2) { // эмо-чёлка
      c.fillStyle = '#111'; c.beginPath(); c.moveTo(-16, -26); c.quadraticCurveTo(6, -30, 14, -20); c.lineTo(2, -8); c.quadraticCurveTo(-4, -18, -16, -26); c.fill();
    }
    c.strokeStyle = '#6b4a2a'; c.lineWidth = 4; c.beginPath(); c.moveTo(face * 34, 34); c.lineTo(face * 40, -34); c.stroke();
    c.fillStyle = eyeCol; c.beginPath(); c.arc(face * 40, -40, 8 + Math.sin(t * 8) * 1.5, 0, TAU); c.fill();
    c.fillStyle = '#fff'; c.beginPath(); c.arc(face * 38, -42, 2.5, 0, TAU); c.fill();
  },
  cactus(c, b, t, face) {
    const fl = b.flash > 0, col = fl ? '#ffffff' : b.stage >= 2 ? '#2f9a3a' : '#3fae4a';
    const hug = b.charging ? 1 : 0;
    const w = Math.sin(t * 4) * 0.15;
    c.fillStyle = col; c.strokeStyle = '#1f6a2a'; c.lineWidth = 3;
    for (const s of [-1, 1]) {
      c.save(); c.translate(s * 26, -2); c.rotate(s * (hug ? 1.2 : 0.3 + w));
      roundRect(c, -7, -34, 14, 36, 7); c.fill(); c.stroke();
      c.restore();
    }
    c.fillStyle = fl ? '#fff' : glossGrad(c, 0, 0, 42, col);
    roundRect(c, -28, -44, 56, 84, 26); c.fill(); c.stroke();
    c.strokeStyle = 'rgba(0,60,10,0.45)'; c.lineWidth = 2;
    for (const x of [-14, 0, 14]) { c.beginPath(); c.moveTo(x, -38); c.lineTo(x, 34); c.stroke(); }
    c.strokeStyle = '#fff8d0'; c.lineWidth = 1.5;
    for (let k = 0; k < 14; k++) { const x = -24 + (k * 37) % 48, y = -36 + (k * 23) % 70; c.beginPath(); c.moveTo(x, y); c.lineTo(x - 3, y - 3); c.stroke(); }
    lookEyes(c, -10, 10, -14, 6, b.look);
    if (b.stage >= 2) brows(c, -10, 10, -23, 6, 0.6);
    else if (b.stage === 1) { c.fillStyle = '#5be3ff'; c.beginPath(); c.ellipse(-12, -2, 2, 4 + Math.sin(t * 6) * 1, 0, 0, TAU); c.fill(); }
    c.fillStyle = 'rgba(255,120,150,0.6)'; c.beginPath(); c.ellipse(-18, -2, 5, 3, 0, 0, TAU); c.ellipse(18, -2, 5, 3, 0, 0, TAU); c.fill();
    c.strokeStyle = '#1b1030'; c.lineWidth = 2.5;
    c.beginPath(); if (b.stage >= 2) c.arc(0, 8, 7, Math.PI + 0.3, TAU - 0.3); else c.arc(0, 0, 7, 0.3, Math.PI - 0.3); c.stroke();
    for (let k = 0; k < 6; k++) { const a = k * TAU / 6 + t; c.fillStyle = '#ff6fb5'; c.beginPath(); c.ellipse(Math.cos(a) * 7, -48 + Math.sin(a) * 4, 5, 3, a, 0, TAU); c.fill(); }
    c.fillStyle = '#ffd23a'; c.beginPath(); c.arc(0, -48, 4, 0, TAU); c.fill();
  },
  bee(c, b, t, face) {
    const fl = b.flash > 0;
    const f = Math.sin(t * 50);
    c.fillStyle = 'rgba(200,240,255,0.55)'; c.strokeStyle = 'rgba(120,220,255,0.9)'; c.lineWidth = 1.5;
    for (const s of [-1, 1]) {
      c.beginPath(); c.ellipse(s * 16, -26, 12, 24 + f * 3, s * 0.5, 0, TAU); c.fill(); c.stroke();
      c.beginPath(); c.ellipse(s * 24, -10, 9, 16 - f * 2, s * 0.9, 0, TAU); c.fill(); c.stroke();
    }
    c.fillStyle = '#1b1030'; c.beginPath(); c.moveTo(-6, 32); c.lineTo(0, 46); c.lineTo(6, 32); c.fill();
    c.fillStyle = fl ? '#fff' : glossGrad(c, 0, 8, 30, '#ffd23a');
    c.beginPath(); c.ellipse(0, 10, 24, 28, 0, 0, TAU); c.fill();
    c.strokeStyle = '#1b1030'; c.lineWidth = 3; c.stroke();
    c.fillStyle = '#1b1030'; for (const y of [4, 16, 28]) c.fillRect(-23 + Math.abs(y - 10) * 0.3, y - 3, 46 - Math.abs(y - 10) * 0.6, 6);
    c.fillStyle = '#9aa4b8'; c.fillRect(-23, 10, 46, 2);
    blob(c, 0, -20, 18, 16, fl ? '#ffffff' : '#ffd23a', 3);
    const led = b.stage >= 2 ? '#ff2a2a' : '#3ff0ff';
    c.fillStyle = '#1b1030'; roundRect(c, -16, -26, 32, 11, 5); c.fill();
    c.fillStyle = led; c.globalAlpha = 0.85; roundRect(c, -14, -24, 28, 7, 3); c.fill(); c.globalAlpha = 1;
    c.fillStyle = '#fff'; c.fillRect(-10 + ((t * 30) % 20), -23, 4, 5);
    c.strokeStyle = '#1b1030'; c.lineWidth = 2;
    c.beginPath(); c.moveTo(-6, -34); c.lineTo(-12, -48); c.moveTo(6, -34); c.lineTo(12, -48); c.stroke();
    c.fillStyle = Math.floor(t * 8) % 2 ? led : '#ffffff'; c.beginPath(); circ(c, -12, -49, 3); circ(c, 12, -49, 3); c.fill();
  },
  golem(c, b, t, face) {
    const fl = b.flash > 0;
    const slam = b.mode === 'stomp' ? Math.sin(t * 20) * 6 : Math.sin(t * 3) * 2;
    const rock = fl ? '#ffffff' : '#3a3030', glow = b.stage >= 2 ? '#ffe04a' : '#ff6a22';
    for (const s of [-1, 1]) { blob(c, s * 50, 8 + slam * s, 17, 22, rock, 3); }
    blob(c, -20, 40, 14, 10, rock, 3); blob(c, 20, 40, 14, 10, rock, 3);
    c.fillStyle = fl ? '#fff' : glossGrad(c, 0, 0, 50, '#4a3c3c');
    c.beginPath(); c.moveTo(-40, -30); c.lineTo(-10, -50); c.lineTo(30, -44); c.lineTo(46, -10); c.lineTo(38, 30); c.lineTo(0, 42); c.lineTo(-38, 30); c.lineTo(-48, -6); c.closePath(); c.fill();
    c.strokeStyle = '#1a1212'; c.lineWidth = 3; c.stroke();
    c.strokeStyle = glow; c.lineWidth = 3; c.shadowColor = glow;
    c.beginPath(); c.moveTo(-30, -20); c.lineTo(-12, -6); c.lineTo(-18, 14); c.moveTo(20, -30); c.lineTo(10, -8); c.lineTo(26, 10); c.moveTo(-4, 20); c.lineTo(8, 34); c.stroke();
    if (b.stage >= 1) { c.beginPath(); c.moveTo(-40, 0); c.lineTo(-28, 10); c.moveTo(38, -6); c.lineTo(30, 20); c.stroke(); }
    c.fillStyle = glow; c.beginPath(); c.ellipse(-12, -26, 7, 4, 0.2, 0, TAU); c.ellipse(12, -26, 7, 4, -0.2, 0, TAU); c.fill();
    c.fillStyle = '#fff'; c.beginPath(); circ(c, -12 + Math.cos(b.look) * 2, -26, 2); circ(c, 12 + Math.cos(b.look) * 2, -26, 2); c.fill();
    c.fillStyle = glow; c.fillRect(-14, -12, 28, 5);
  },
  spider(c, b, t, face) {
    const fl = b.flash > 0, col = fl ? '#ffffff' : '#8f70ea';
    const glow = b.stage >= 1 ? '#5be3ff' : '#c9b3ff';
    c.strokeStyle = '#3a2a6a'; c.lineWidth = 5; c.lineCap = 'round';
    for (const s of [-1, 1]) for (let k = 0; k < 4; k++) {
      const a = (k - 1.5) * 0.5 + Math.sin(t * 10 + k * 1.3 + (s > 0 ? 1 : 0)) * 0.15;
      const kx = s * Math.cos(a) * 40, ky = Math.sin(a) * 40 - 14, fx = s * Math.cos(a) * 66, fy = Math.sin(a) * 66 + 16;
      c.beginPath(); c.moveTo(s * 10, 0); c.lineTo(kx, ky); c.lineTo(fx, fy); c.stroke();
    }
    c.lineCap = 'butt';
    c.fillStyle = fl ? '#fff' : glossGrad(c, 0, 16, 34, col);
    c.beginPath(); c.moveTo(0, -6); c.lineTo(30, 14); c.lineTo(20, 46); c.lineTo(-20, 46); c.lineTo(-30, 14); c.closePath(); c.fill();
    c.strokeStyle = '#2a1a5a'; c.lineWidth = 3; c.stroke();
    c.fillStyle = glow; c.globalAlpha = 0.7;
    c.beginPath(); c.moveTo(0, 2); c.lineTo(12, 18); c.lineTo(0, 38); c.lineTo(-12, 18); c.closePath(); c.fill(); c.globalAlpha = 1;
    blob(c, 0, -14, 18, 15, col, 3);
    c.fillStyle = '#ff2a5a';
    for (const [x, y, r] of [[-7, -18, 3], [7, -18, 3], [-12, -12, 2.2], [12, -12, 2.2], [-3, -24, 2], [3, -24, 2], [-4, -10, 1.6], [4, -10, 1.6]]) { c.beginPath(); c.arc(x + Math.cos(b.look) * 1.2, y, r, 0, TAU); c.fill(); }
    c.fillStyle = '#fff'; c.beginPath(); c.moveTo(-5, -3); c.lineTo(-3, 4); c.lineTo(-1, -3); c.moveTo(5, -3); c.lineTo(3, 4); c.lineTo(1, -3); c.fill();
  },
  zyama(c, b, t, face) {
    const st = b.vstage ?? b.stage;
    const bob = Math.sin(t * 3) * 4;
    c.translate(0, bob);
    // аура
    if (st >= 3) {
      for (let k = 0; k < 10; k++) {
        const a = k * TAU / 10 + t * 2, rr = 58 + Math.sin(t * 8 + k) * 8;
        c.fillStyle = k % 2 ? 'rgba(255,90,30,0.35)' : 'rgba(255,200,40,0.3)';
        c.beginPath(); c.arc(Math.cos(a) * rr * 0.6, Math.sin(a) * rr * 0.6 - 10, 22, 0, TAU); c.fill();
      }
    } else {
      c.fillStyle = `rgba(255,62,165,${0.16 + Math.sin(t * 4) * 0.06})`; c.beginPath(); c.arc(0, -8, 64, 0, TAU); c.fill();
    }
    // руки танцуют
    const d = Math.sin(t * 7) * 0.7;
    c.strokeStyle = '#f5f2ea'; c.lineWidth = 9; c.lineCap = 'round';
    c.beginPath(); c.moveTo(-22, 22); c.lineTo(-40, 6 + d * 18); c.moveTo(22, 22); c.lineTo(40, 6 - d * 18); c.stroke();
    c.strokeStyle = '#e8c9b0'; c.lineWidth = 7; c.beginPath(); c.moveTo(-40, 6 + d * 18); c.lineTo(-46, -6 + d * 22); c.moveTo(40, 6 - d * 18); c.lineTo(46, -6 - d * 22); c.stroke();
    c.lineCap = 'butt';
    // футболка
    c.fillStyle = b.flash > 0 ? '#ffffff' : glossGrad(c, 0, 34, 30, '#f5f2ea');
    roundRect(c, -26, 14, 52, 42, 14); c.fill(); c.strokeStyle = '#b8b0a0'; c.lineWidth = 2.5; c.stroke();
    // золотая цепь
    c.strokeStyle = '#ffd25a'; c.lineWidth = 2.5; c.setLineDash([3, 2]);
    c.beginPath(); c.arc(0, 14, 14, 0.3, Math.PI - 0.3); c.stroke(); c.setLineDash([]);
    // голова – мультяшное фото
    const R = 40, hx = 0, hy = -18;
    if (ART.zyamaFace) {
      c.save(); c.beginPath(); c.arc(hx, hy, R, 0, TAU); c.clip();
      c.drawImage(ART.zyamaFace, hx - R, hy - R, R * 2, R * 2);
      if (st >= 3) { c.fillStyle = 'rgba(255,40,40,0.22)'; c.fillRect(hx - R, hy - R, R * 2, R * 2); }
      if (b.flash > 0) { c.fillStyle = 'rgba(255,255,255,0.55)'; c.fillRect(hx - R, hy - R, R * 2, R * 2); }
      c.restore();
    }
    c.strokeStyle = st >= 3 ? '#ff5a1e' : '#ffd25a'; c.lineWidth = 4; c.beginPath(); c.arc(hx, hy, R, 0, TAU); c.stroke();
    // очки сигмы
    if (st >= 2) {
      c.fillStyle = '#0a0a0a';
      c.fillRect(hx - 22, hy - 4, 18, 9); c.fillRect(hx + 4, hy - 4, 19, 9); c.fillRect(hx - 24, hy - 4, 48, 3);
      c.fillStyle = 'rgba(255,255,255,0.6)'; c.fillRect(hx - 19, hy - 2, 4, 2); c.fillRect(hx + 7, hy - 2, 4, 2);
    }
    // блеск брекетов
    if (st >= 1) {
      const sp = (Math.sin(t * 12) + 1) / 2;
      c.fillStyle = `rgba(255,255,255,${0.5 + sp * 0.5})`; star(c, hx + 8, hy + 18, 4 + sp * 3, t * 3, 4); c.fill();
    }
    // слёзы в последней стадии
    if (st >= 3) {
      c.fillStyle = '#5be3ff';
      for (const s of [-1, 1]) { c.beginPath(); c.ellipse(hx + s * 12, hy + 6 + ((t * 30) % 22), 2.5, 4, 0, 0, TAU); c.fill(); }
    }
    // корона
    c.save(); c.translate(hx, hy - R + 2); c.rotate(-0.15 + Math.sin(t * 2) * 0.05);
    c.fillStyle = '#ffd25a'; c.strokeStyle = '#b8860b'; c.lineWidth = 2;
    c.beginPath(); c.moveTo(-18, 2); c.lineTo(-18, -14); c.lineTo(-9, -5); c.lineTo(0, -18); c.lineTo(9, -5); c.lineTo(18, -14); c.lineTo(18, 2); c.closePath(); c.fill(); c.stroke();
    c.fillStyle = '#ff3ea5'; c.beginPath(); c.arc(0, -4, 3, 0, TAU); c.fill();
    c.fillStyle = '#3ff0ff'; c.beginPath(); circ(c, -11, -2, 2); circ(c, 11, -2, 2); c.fill();
    c.restore();
  },
};
// Где у босса "рот" (точка вылета лазера)
function bossMouth(b) {
  if (b.kind === 'zyama' || b.kind === 'zyama2') return { x: b.x + 2, y: b.y - b.z - 2 + Math.sin(b.anim * 3) * 4 };
  return { x: b.x, y: b.y - b.z };
}
// Портрет босса для диалога
function bossPortrait(kind, size = 116) {
  const cv = makeCanvas(size, size), c = cv.getContext('2d');
  c.fillStyle = '#2a1238'; c.fillRect(0, 0, size, size);
  if (kind === 'zyama' && ART.zyamaFace) { c.drawImage(ART.zyamaFace, 0, 0, size, size); return cv; }
  const fake = { kind, flash: 0, stage: 0, look: 1.57, mode: 'idle', charging: false, anim: 0, z: 0 };
  c.translate(size / 2, size / 2 + 8);
  const s = size / 120; c.scale(s, s);
  if (BSPR[kind]) BSPR[kind](c, fake, 0.3, 1);
  return cv;
}

// =====================================================================
//  v0.03: Рыжовая, глава 3
// =====================================================================
// Фигура и портрет используют общие контуры лица, шеи и шарфа.
const RYZ_P = {
  scarfTail: new Path2D('M0,0 C-3,-.2 -5.4,1.4 -8.8,1 Q-11.8,.7 -14,-1 C-13.5,2.7 -11.6,5 -8.4,5.8 L-10.1,8 C-4.5,8.1 -1,5.3 1.5,1.4Z'),
  scarfFlame: new Path2D('M-12.2,1.8 Q-9.5,4 -6.1,3.4 Q-6.6,4.4 -7.9,4.9 Q-10.4,4.6 -12.2,1.8Z'),
  cowl: new Path2D('M-9,-2.4 C-8.4,-3.8 -6.1,-5 -4.8,-4.1 C-1.7,-2.1 3.5,-1.9 6.8,-4 C8.7,-3 9.4,-.6 8.3,.9 C6.8,2.7 3.6,4.3 1.3,4.7 C-1.4,5 -6.7,2.7 -8.6,.6 Q-9.6,-.8 -9,-2.4Z'),
  upperFold: new Path2D('M-8.2,-2.1 C-6.6,-4.3 -6.1,-4.1 -4.2,-3.2 C-1,-1.8 2.2,-1.8 5.7,-2.7 C2.5,-.5 -2.3,.2 -6.1,-.8 Q-8.1,-1.3 -8.2,-2.1Z'),
  lowerFold: new Path2D('M-5.1,1 C-.8,2.6 4.3,1 8,-.6 C6.8,1.8 3.2,3.9 1,4.1 C-.9,4.1 -3.7,2.9 -5.1,1Z'),
  body: new Path2D('M-9.1,.1 Q-8.1,-3 -4.7,-3.9 Q0,-4.9 4.5,-3.9 Q7.8,-3.2 9.1,.1 L8.1,2.4 L8.6,8.2 Q.4,11 -8.6,8.3 L-8,2.4Z'),
};

function drawFireScarf(c, sway) {
  c.save(); c.translate(-5, -1.8); c.rotate(sway * .06);
  inkPart(c, RYZ_P.scarfTail, '#bc5143', '#893c3c', .65, .6);
  c.fillStyle = '#f1a064'; c.fill(RYZ_P.scarfFlame); c.restore();
  inkPart(c, RYZ_P.cowl, '#c76148', '#984538', .7, .45);
  c.fillStyle = '#e48b64'; c.fill(RYZ_P.upperFold);
  c.fillStyle = '#ac4738'; c.fill(RYZ_P.lowerFold);
}

const RYZ_FACE = {
  backHair: new Path2D('M-24,-40 C-30,-64 30,-64 24,-40 C28,-28 33,-6 28,12 Q26,17 25,20 Q22,14 22,10 Q17,18 15,19 Q12,12 7,17 Q2,22 -2,18 Q-8,13 -15,19 Q-17,13 -20,12 Q-22,17 -25,19 C-25,10 -31,6 -30,-8 Q-30,-23 -24,-40Z'),
  body: new Path2D('M-29,42 C-29,19 -25,9 -20,6 Q-15,3 -9,2 Q0,5 9,2 Q19,3 23,9 C28,16 29,32 30,42Z'),
  neck: new Path2D('M-6.7,-15 Q-5.8,-10.4 -6.5,-7.3 C-7,-4.2 -10.6,-3.6 -13,-2.4 Q-9.8,3 .2,3.3 Q9.8,3 13.3,-2.2 C9.2,-3.2 6.8,-4.7 6.4,-7.1 Q5.7,-11.2 6.8,-15Z'),
  chinShade: new Path2D('M-6.5,-15 L6.7,-15 L6.2,-8.8 Q1.2,-8.4 -5.8,-5.6 Q-5.4,-10.2 -6.5,-15Z'),
  head: new Path2D('M0,-50 C14,-50 21,-42 20,-31 C19,-20 12,-12 0,-11 C-12,-12 -19,-20 -20,-31 C-21,-42 -14,-50 0,-50 Z'),
  bangs: new Path2D('M-22,-33 C-25,-49 -15,-60 -2,-60 C12,-62 25,-51 22,-33 Q20,-40 17,-41 Q18,-36 15,-32 Q13,-38 8,-42 Q8,-37 4,-34 Q4,-39 0,-42 Q-1,-37 -8,-33 Q-6,-38 -9,-42 Q-13,-35 -19,-32 Q-17,-37 -16,-40 Q-20,-38 -22,-33Z'),
  sides: new Path2D('M-20,-42 C-27,-35 -28,-17 -24,-8 Q-22,-3 -23,2 Q-17,-5 -19,-13 Q-22,-24 -16,-34Z M19,-43 C26,-34 28,-21 24,-12 Q22,-6 24,-1 Q18,-4 18,-11 C18,-17 23,-25 16,-35Z'),
};
function ryzFaceDraw(c, eyesOpen = true, small = false, sway = 0) {
  if (!small) {
    inkPart(c, RYZ_FACE.backHair, '#ee824a', '#b54b27', 1.4, 2);
    inkPart(c, RYZ_FACE.body, '#514957', '#35303e', 1.4, 2);
  }
  // Тень подбородка лежит на коже, а верхняя складка шарфа перекрывает основание шеи.
  c.fillStyle = '#f6c9af'; c.fill(RYZ_FACE.neck);
  c.fillStyle = '#e5ad92'; c.fill(RYZ_FACE.chinShade);
  c.save(); c.translate(0, -.8); c.scale(2.15, 1.85); drawFireScarf(c, sway); c.restore();
  inkPart(c, RYZ_FACE.head, '#ffe4d2', '#f2bfa6', 1.4, 2);
  for (const d of [-8, 8]) {
    if (!eyesOpen) { c.strokeStyle = INK_C; c.lineWidth = 1.8; c.beginPath(); c.moveTo(d - 5, -26); c.quadraticCurveTo(d, -23, d + 5, -26); c.stroke(); continue; }
    c.fillStyle = '#fff'; c.beginPath(); c.ellipse(d, -26.5, 5.2, 6.4, 0, 0, TAU); c.fill();
    const g = c.createLinearGradient(0, -32, 0, -20); g.addColorStop(0, '#1a3a6a'); g.addColorStop(1, '#7ab8f0'); c.fillStyle = g; c.beginPath(); c.ellipse(d + (d < 0 ? 0.6 : -0.6), -26, 4.2, 5.7, 0, 0, TAU); c.fill();
    c.fillStyle = '#0e1a30'; c.beginPath(); c.ellipse(d + (d < 0 ? 0.6 : -0.6), -25.5, 2, 2.9, 0, 0, TAU); c.fill();
    c.fillStyle = '#fff'; c.beginPath(); c.arc(d - 1.4, -28.5, 1.6, 0, TAU); c.fill(); c.globalAlpha *= 0.8; c.beginPath(); c.arc(d + 1.5, -23.6, 0.8, 0, TAU); c.fill(); c.globalAlpha /= 0.8;
    c.strokeStyle = '#3a1a10'; c.lineWidth = 2.1; c.lineCap = 'round'; c.beginPath(); c.moveTo(d - 6, -29.5); c.quadraticCurveTo(d, -35.2, d + 6, -30); c.stroke();
  }
  c.fillStyle = 'rgba(255,110,110,.42)'; c.beginPath(); c.ellipse(-13, -19.5, 4, 2.2, 0, 0, TAU); c.ellipse(13, -19.5, 4, 2.2, 0, 0, TAU); c.fill();
  c.fillStyle = 'rgba(170,80,40,.6)'; for (const [fx, fy] of [[-14, -22], [-11, -21], [-13, -19], [11, -21], [14, -22], [13, -19]]) { c.beginPath(); c.arc(fx, fy, 0.7, 0, TAU); c.fill(); } // веснушки
  c.strokeStyle = '#8a3a2a'; c.lineWidth = 1.4; c.lineCap = 'round'; c.beginPath(); c.moveTo(-3, -16.8); c.quadraticCurveTo(0, -14.2, 3, -16.8); c.stroke();
  inkPart(c, RYZ_FACE.sides, '#f0743a', '#c44a22', 1.3, 1.5);
  inkPart(c, RYZ_FACE.bangs, '#f0743a', '#c44a22', 1.4, 1.8);
  c.save(); c.clip(RYZ_FACE.bangs); c.strokeStyle = 'rgba(255,214,176,.75)'; c.lineWidth = 2.6; c.beginPath(); c.moveTo(-15, -50); c.quadraticCurveTo(0, -56, 15, -50); c.stroke(); c.restore();
}
function ryzFacePortrait(size) {
  const cv = makeCanvas(size, size), c = cv.getContext('2d');
  const g = c.createRadialGradient(size / 2, size * 0.4, size * 0.1, size / 2, size / 2, size * 0.72); g.addColorStop(0, '#fbeedb'); g.addColorStop(1, '#e8c8a0');
  c.fillStyle = g; c.fillRect(0, 0, size, size);
  const k = size / 92; c.save(); c.translate(size / 2, size * 0.47 + 35 * k); c.scale(k, k); ryzFaceDraw(c); c.restore();
  return cv;
}
function drawRyzhovayaPaper(c, x, y, t, face, s, alpha, moving) {
  c.save(); c.translate(x, y); c.scale(s * face, s); c.globalAlpha = alpha;
  const bob = moving ? Math.abs(Math.sin(t * 12)) * 2 : 0, st = moving ? Math.sin(t * 14) * 2.5 : 0, sway = Math.sin(t * (moving ? 10 : 3)) * 2;
  c.fillStyle = `rgba(255,150,60,${0.14 + Math.sin(t * 6) * 0.05})`; c.beginPath(); c.arc(0, -8, 21, 0, TAU); c.fill();
  c.fillStyle = '#3a3448'; c.strokeStyle = INK_C; c.lineWidth = 1;
  for (const [lx, ly] of [[-5, 5 + st], [1, 5 - st]]) { c.beginPath(); c.roundRect(lx, ly, 4, 7, 1.5); c.fill(); c.stroke(); }
  c.translate(0, -bob);
  const hair = new Path2D(`M-11,-17 Q${-16 + sway},2 ${-9 + sway},9 L${9 + sway},9 Q${16 + sway},2 11,-17 Z`);
  inkPart(c, hair, '#f0743a', '#c44a22', 1.1, 1.6);
  c.strokeStyle = 'rgba(255,220,170,.7)'; c.lineWidth = 0.9; c.lineCap = 'round';
  c.beginPath(); c.moveTo(-10, -8); c.quadraticCurveTo(-13 + sway * 0.6, 0, -9 + sway, 6); c.moveTo(10, -8); c.quadraticCurveTo(13 + sway * 0.6, 0, 9 + sway, 6); c.stroke(); c.lineCap = 'butt';
  inkPart(c, RYZ_P.body, '#4a4458', '#2a2636', 1.1, 1.4);
  c.fillStyle = '#ffdcc6'; c.strokeStyle = INK_C; c.lineWidth = 0.9; for (const hx of [-9, 9]) { c.beginPath(); c.arc(hx, 4, 2.5, 0, TAU); c.fill(); c.stroke(); }
  { const fy = 1 + Math.sin(t * 12), fg = c.createRadialGradient(10, fy, 0, 10, fy, 9); fg.addColorStop(0, 'rgba(255,200,80,0.7)'); fg.addColorStop(1, 'rgba(255,120,30,0)'); c.fillStyle = fg; c.beginPath(); c.arc(10, fy, 9, 0, TAU); c.fill(); }
  c.fillStyle = '#ffb03a'; c.beginPath(); c.arc(10, 1 + Math.sin(t * 12), 3.2 + Math.sin(t * 20) * 0.8, 0, TAU); c.fill();
  c.fillStyle = '#fff3b0'; c.beginPath(); c.arc(10, 1 + Math.sin(t * 12), 1.4, 0, TAU); c.fill();
  c.save(); c.translate(0, 2.4); c.scale(0.42, 0.42); // лицо из портрета, в масштабе фигурки
  ryzFaceDraw(c, Math.sin(t * 0.9 + 0.4) < 0.985, true, sway);
  c.restore();
  c.strokeStyle = '#e8602a'; c.lineWidth = 3; c.lineCap = 'round';
  c.beginPath(); c.moveTo(-9, -19); c.quadraticCurveTo(-14, -8, -11 + sway * 0.5, 1); c.moveTo(9, -19); c.quadraticCurveTo(14, -8, 11 + sway * 0.5, 1); c.stroke();
  c.strokeStyle = 'rgba(75,46,30,.55)'; c.lineWidth = 0.8; c.stroke(); c.lineCap = 'butt';
  c.restore();
}
function drawRyzhovaya(c, x, y, t, face, s = 1, alpha = 1, moving = false) {
  if (PAPER_ART) { drawRyzhovayaPaper(c, x, y, t, face, s, alpha, moving); return; }
  c.save(); c.translate(x, y); c.scale(s * face, s); c.globalAlpha = alpha;
  const bob = moving ? Math.abs(Math.sin(t * 12)) * 2 : 0;
  c.fillStyle = `rgba(255,120,40,${0.16 + Math.sin(t * 6) * 0.06})`; c.beginPath(); c.arc(0, -8, 21, 0, TAU); c.fill();
  c.fillStyle = '#2a2a3a';
  const st = moving ? Math.sin(t * 14) * 2.5 : 0;
  c.fillRect(-5, 5 + st, 4, 7); c.fillRect(1, 5 - st, 4, 7);
  c.translate(0, -bob);
  const sway = Math.sin(t * (moving ? 10 : 3)) * 2;
  const hg = c.createLinearGradient(0, -20, 0, 10); hg.addColorStop(0, '#ff8a3a'); hg.addColorStop(0.5, '#e8501c'); hg.addColorStop(1, '#a8280c');
  c.fillStyle = hg;
  c.beginPath(); c.moveTo(-11, -17); c.quadraticCurveTo(-16 + sway, 2, -9 + sway, 9); c.lineTo(9 + sway, 9); c.quadraticCurveTo(16 + sway, 2, 11, -17); c.closePath(); c.fill();
  c.strokeStyle = 'rgba(255,200,140,0.65)'; c.lineWidth = 1; c.lineCap = 'round'; // пряди-блики
  c.beginPath(); c.moveTo(-10, -8); c.quadraticCurveTo(-13 + sway * 0.6, 0, -9 + sway, 6); c.moveTo(10, -8); c.quadraticCurveTo(13 + sway * 0.6, 0, 9 + sway, 6); c.stroke(); c.lineCap = 'butt';
  const bg = c.createLinearGradient(-8, -4, 8, 9); bg.addColorStop(0, '#3a3a4a'); bg.addColorStop(1, '#121218');
  c.fillStyle = bg; c.strokeStyle = '#000'; c.lineWidth = 1.5;
  c.fill(RYZ_P.body); c.stroke(RYZ_P.body);
  c.fillStyle = 'rgba(255,255,255,0.12)'; roundRect(c, -6, -3, 5, 9, 3); c.fill();
  c.fillStyle = '#ffd9c2'; c.beginPath(); circ(c, -9, 4, 2.5); circ(c, 9, 4, 2.5); c.fill();
  { const fy = 1 + Math.sin(t * 12), fg = c.createRadialGradient(10, fy, 0, 10, fy, 9); fg.addColorStop(0, 'rgba(255,200,80,0.7)'); fg.addColorStop(1, 'rgba(255,120,30,0)');
    c.fillStyle = fg; c.beginPath(); c.arc(10, fy, 9, 0, TAU); c.fill(); } // свечение огонька
  c.fillStyle = '#ffb03a'; c.beginPath(); c.arc(10, 1 + Math.sin(t * 12), 3.2 + Math.sin(t * 20) * 0.8, 0, TAU); c.fill();
  c.fillStyle = '#fff3b0'; c.beginPath(); c.arc(10, 1 + Math.sin(t * 12), 1.4, 0, TAU); c.fill();
  const R = 10.5;
  if (ART.ryzhovaSmall) {
    c.save(); c.translate(0, 2); drawFireScarf(c, sway); c.restore();
    c.save(); c.beginPath(); c.arc(0, -13, R, 0, TAU); c.clip(); c.drawImage(ART.ryzhovaSmall, -R, -13 - R, R * 2, R * 2); c.restore();
    const rg = c.createLinearGradient(-R, -13 - R, R, -13 + R);
    rg.addColorStop(0, '#ffe08a'); rg.addColorStop(0.5, '#ff7a2f'); rg.addColorStop(1, '#c0400a');
    c.strokeStyle = rg; c.lineWidth = 2; c.beginPath(); c.arc(0, -13, R, 0, TAU); c.stroke();
  } else {
    c.save(); c.translate(0, 2.4); c.scale(0.42, 0.42);
    ryzFaceDraw(c, Math.sin(t * 0.9 + 0.4) < 0.985, true, sway);
    c.restore();
  }
  c.strokeStyle = '#ff6a22'; c.lineWidth = 3; c.lineCap = 'round';
  c.beginPath(); c.moveTo(-9, -19); c.quadraticCurveTo(-14, -8, -11 + sway * 0.5, 1); c.moveTo(9, -19); c.quadraticCurveTo(14, -8, 11 + sway * 0.5, 1); c.stroke();
  c.lineCap = 'butt';
  c.restore();
}
function drawHero(id, c, x, y, t, face, s, alpha, moving) {
  if (id === 'ryzhovaya') drawRyzhovaya(c, x, y, t, face, s, alpha, moving);
  else drawKrilessa(c, x, y, t, face, s, alpha, moving);
}
function heroPortrait(id, size = 116) {
  const cv = makeCanvas(size, size), c = cv.getContext('2d');
  const g = c.createRadialGradient(size / 2, size / 2, 4, size / 2, size / 2, size * 0.7);
  g.addColorStop(0, id === 'ryzhovaya' ? '#7a2a10' : '#3a2a7a'); g.addColorStop(1, '#140a24');
  c.fillStyle = g; c.fillRect(0, 0, size, size);
  // Крылья Крилессы помещаются в портрет при полном раскрытии.
  const fairy = id === 'krilessa';
  drawHero(id, c, size / 2, size * (fairy ? 0.65 : 0.78), 0.4, 1, size / (fairy ? 52 : 34), 1, false);
  return cv;
}
// Огненный шар Рыжовой
function drawFireball(c, x, y, a, s = 1) {
  c.save(); c.translate(x, y); c.rotate(a); c.scale(s, s);
  c.fillStyle = 'rgba(255,90,20,0.35)'; c.beginPath(); c.ellipse(-10, 0, 14, 6, 0, 0, TAU); c.fill();
  c.fillStyle = 'rgba(255,170,40,0.6)'; c.beginPath(); c.ellipse(-4, 0, 9, 5.5, 0, 0, TAU); c.fill();
  c.fillStyle = '#ffd23a'; c.beginPath(); c.arc(1, 0, 5.5, 0, TAU); c.fill();
  c.fillStyle = '#fff6c8'; c.beginPath(); c.arc(2, -1, 2.5, 0, TAU); c.fill();
  c.restore();
}
// Квадратные "пиксельные" снаряды
const _squareCache = new Map();
function squareSprite(col, r) {
  const key = col + r;
  let cv = _squareCache.get(key);
  if (cv) return cv;
  const s = Math.ceil(r * 2.6) * 2 + 4, h = s / 2;
  cv = makeCanvas(s * 2, s * 2); const c = cv.getContext('2d'); c.scale(2, 2);
  c.globalAlpha = 0.35; c.fillStyle = col; c.fillRect(h - r * 1.5, h - r * 1.5, r * 3, r * 3);
  c.globalAlpha = 1; c.fillRect(h - r, h - r, r * 2, r * 2);
  c.fillStyle = 'rgba(255,255,255,0.8)'; c.fillRect(h - r, h - r, r, r * 0.6);
  c.strokeStyle = 'rgba(0,0,0,0.5)'; c.lineWidth = 1; c.strokeRect(h - r, h - r, r * 2, r * 2);
  _squareCache.set(key, cv);
  return cv;
}
const RAINBOW = ['#ff3b3b', '#ff9a2a', '#ffe04a', '#4dff6a', '#3fc8ff', '#7a5aff', '#ff4ad6'];

// ---------- деревья главы 3 ----------
(() => {
  TREE_SPR.glitchtree = makeTreeSprite(c => {
    c.fillStyle = '#2a1a3a'; c.fillRect(28, 50, 8, 30);
    const px = (x, y, col) => { c.fillStyle = col; c.fillRect(x, y, 6, 6); };
    for (let i = 0; i < 46; i++) {
      const x = 8 + (i * 37) % 48, y = 8 + (i * 23) % 44;
      if ((x - 32) ** 2 / 600 + (y - 30) ** 2 / 500 > 1) continue;
      px(x, y, i % 3 === 0 ? '#3ff0a0' : i % 3 === 1 ? '#1fa078' : '#127058');
    }
    c.globalAlpha = 0.5; c.fillStyle = '#ff3ea5'; c.fillRect(10, 26, 44, 3); c.fillStyle = '#3ff0ff'; c.fillRect(14, 40, 40, 2); c.globalAlpha = 1;
  });
  TREE_SPR.lollipop = makeTreeSprite(c => {
    c.fillStyle = '#fff'; c.fillRect(30, 34, 4, 46);
    c.fillStyle = '#ff6fb5'; c.beginPath(); c.arc(32, 26, 18, 0, TAU); c.fill();
    c.strokeStyle = '#fff'; c.lineWidth = 4;
    c.beginPath(); for (let a = 0; a < 12; a += 0.2) c.lineTo(32 + Math.cos(a) * a * 1.4, 26 + Math.sin(a) * a * 1.4); c.stroke();
    c.strokeStyle = '#c0306a'; c.lineWidth = 2; c.beginPath(); c.arc(32, 26, 18, 0, TAU); c.stroke();
  });
  TREE_SPR.cloudtree = makeTreeSprite(c => {
    c.strokeStyle = '#d0b0ff'; c.lineWidth = 5; c.beginPath(); c.moveTo(32, 80); c.lineTo(32, 46); c.stroke();
    for (const [x, y, r] of [[22, 36, 13], [42, 36, 13], [32, 26, 15], [32, 42, 12]]) { c.fillStyle = '#ffffff'; c.beginPath(); c.arc(x, y, r, 0, TAU); c.fill(); }
    c.fillStyle = 'rgba(180,200,255,0.5)'; c.beginPath(); c.arc(38, 42, 9, 0, TAU); c.fill();
    RAINBOW.slice(0, 5).forEach((col, i) => { c.fillStyle = col; c.fillRect(20 + i * 5, 52, 4, 3); });
  });
  TREE_SPR.junk = makeTreeSprite(c => {
    c.fillStyle = '#1b1b1b';
    for (let i = 0; i < 4; i++) { c.beginPath(); c.ellipse(32, 74 - i * 11, 15, 6, 0, 0, TAU); c.fill(); c.fillStyle = i % 2 ? '#1b1b1b' : '#2a2a2a'; }
    c.strokeStyle = '#5a5a5a'; c.lineWidth = 3; c.beginPath(); c.moveTo(32, 34); c.lineTo(32, 10); c.lineTo(44, 6); c.stroke();
    c.fillStyle = '#7dff4a'; c.beginPath(); c.arc(44, 9, 4, 0, TAU); c.fill();
    c.fillStyle = 'rgba(125,255,74,0.3)'; c.beginPath(); c.arc(44, 10, 9, 0, TAU); c.fill();
  });
  TREE_SPR.mirrorshard = makeTreeSprite(c => {
    const sh = (x, y, w, h, col) => {
      c.fillStyle = col; c.beginPath(); c.moveTo(x, y - h); c.lineTo(x + w, y - h * 0.5); c.lineTo(x + w * 0.6, y); c.lineTo(x - w * 0.6, y); c.lineTo(x - w, y - h * 0.5); c.closePath(); c.fill();
      c.strokeStyle = '#ffffff'; c.lineWidth = 1.5; c.stroke();
      c.fillStyle = 'rgba(255,255,255,0.6)'; c.beginPath(); c.moveTo(x - w * 0.3, y - h * 0.8); c.lineTo(x - w * 0.6, y - h * 0.4); c.lineTo(x - w * 0.2, y - h * 0.3); c.closePath(); c.fill();
    };
    sh(22, 78, 9, 34, '#9ad8f8'); sh(44, 78, 8, 28, '#c8b8ff'); sh(32, 79, 11, 58, '#bfeaff');
  });
})();

// ---------- враги главы 3 ----------
Object.assign(ESPR, {
  glitchbug(c, e) {
    const j = Math.random() < 0.15 ? rnd(-3, 3) : 0;
    c.globalAlpha *= 0.5; c.fillStyle = '#ff3ea5'; c.fillRect(-9 + j - 2, -6, 18, 12);
    c.globalAlpha *= 2; c.fillStyle = e.col; c.fillRect(-9 + j, -7, 18, 13);
    c.fillStyle = '#0a2a2a'; c.fillRect(-9 + j, -1, 18, 2);
    c.fillStyle = '#ffffff'; c.fillRect(-5 + j, -5, 3, 3); c.fillRect(3 + j, -5, 3, 3);
    c.strokeStyle = e.col; c.lineWidth = 2;
    for (const s of [-1, 1]) { c.beginPath(); c.moveTo(s * 9, 0); c.lineTo(s * 14, -4 + Math.sin(e.t * 20) * 3); c.stroke(); }
  },
  errorwin(c, e) {
    const sh = e.charge > 0 ? Math.sin(e.t * 40) * 1.5 : 0;
    c.fillStyle = '#c0c0c0'; c.fillRect(-17 + sh, -14, 34, 28);
    c.fillStyle = '#1a3aa8'; c.fillRect(-17 + sh, -14, 34, 7);
    c.fillStyle = '#ff3b3b'; c.fillRect(10 + sh, -13, 5, 5);
    c.fillStyle = '#ffffff'; c.font = 'bold 7px Krilessa Icons, sans-serif'; c.textAlign = 'center'; c.fillText('ERROR', sh, -8.5);
    c.fillStyle = '#ffd23a'; c.beginPath(); c.moveTo(-10 + sh, 9); c.lineTo(-4 + sh, -2); c.lineTo(2 + sh, 9); c.closePath(); c.fill();
    c.fillStyle = '#000'; c.fillRect(-4.6 + sh, 1, 1.4, 4); c.fillRect(-4.6 + sh, 6, 1.4, 1.4);
    c.fillStyle = '#7a7a7a'; c.fillRect(5 + sh, 2, 9, 5);
    c.strokeStyle = '#000'; c.lineWidth = 1.5; c.strokeRect(-17 + sh, -14, 34, 28);
  },
  pixel(c, e) {
    const cols = ['#3ff0ff', '#ff3ea5', '#ffe04a', '#3ff0a0'];
    c.fillStyle = cols[Math.floor(e.seed * 10) % 4]; c.fillRect(-6, -6, 12, 12);
    c.fillStyle = '#ffffff'; c.fillRect(-4, -3, 3, 3); c.fillRect(1, -3, 3, 3);
  },
  virus(c, e) {
    const pulse = e.fuse > 0 ? 1 + Math.sin(e.t * 40) * 0.1 : 1;
    c.scale(pulse, pulse); c.rotate(e.t * 2);
    c.strokeStyle = e.col; c.lineWidth = 2.5;
    for (let k = 0; k < 8; k++) { const a = k * TAU / 8; c.beginPath(); c.moveTo(Math.cos(a) * 9, Math.sin(a) * 9); c.lineTo(Math.cos(a) * 15, Math.sin(a) * 15); c.stroke(); c.fillStyle = e.col; c.beginPath(); c.arc(Math.cos(a) * 15, Math.sin(a) * 15, 2.5, 0, TAU); c.fill(); }
    blob(c, 0, 0, 10, 10, e.fuse > 0 && Math.floor(e.t * 16) % 2 ? '#ff3b3b' : e.col);
    c.rotate(-e.t * 2);
    brows(c, -3.5, 3.5, -3, 2.5, 0.6);
    c.fillStyle = '#1b1030'; c.beginPath(); circ(c, -3.5, 0, 1.6); circ(c, 3.5, 0, 1.6); c.fill();
  },
  gummy(c, e) {
    const sq = 1 + Math.sin(e.t * 6 + e.seed) * 0.12; c.scale(1 / sq, sq);
    const col = e.col;
    c.globalAlpha *= 0.9;
    blob(c, 0, 4, 11, 11, col, 1.5); blob(c, 0, -9, 9, 8, col, 1.5);
    blob(c, -7, -16, 3.5, 3.5, col, 1.2); blob(c, 7, -16, 3.5, 3.5, col, 1.2);
    blob(c, -11, 2, 4, 3.5, col, 1.2); blob(c, 11, 2, 4, 3.5, col, 1.2);
    c.globalAlpha /= 0.9;
    lookEyes(c, -3.5, 3.5, -10, 2.3, e.look);
    gloss(c, -4, 0, 2.5, 5, 0.5);
  },
  cupcake(c, e) {
    c.fillStyle = '#d6a060'; c.beginPath(); c.moveTo(-11, 0); c.lineTo(-8, 13); c.lineTo(8, 13); c.lineTo(11, 0); c.closePath(); c.fill();
    c.strokeStyle = '#a0703a'; c.lineWidth = 1.5; for (const x of [-5, 0, 5]) { c.beginPath(); c.moveTo(x, 1); c.lineTo(x * 0.8, 12); c.stroke(); }
    blob(c, 0, -4, 13, 9, e.col, 1.5); blob(c, 0, -11, 8, 6, e.col, 1.5);
    c.fillStyle = '#ff3b3b'; c.beginPath(); c.arc(0, -18, 3.5, 0, TAU); c.fill();
    lookEyes(c, -4, 4, -4, 2.3, e.look);
    for (let k = 0; k < 6; k++) { c.fillStyle = RAINBOW[k]; c.fillRect(-9 + k * 3.4, -9 + (k % 2) * 4, 2.5, 1.2); }
    if (e.healing > 0) { c.strokeStyle = 'rgba(255,140,198,0.8)'; c.lineWidth = 3; c.beginPath(); c.arc(0, 0, 22, 0, TAU); c.stroke(); }
  },
  candycane(c, e) {
    c.scale(e.face, 1);
    c.lineCap = 'round'; c.lineWidth = 7; c.strokeStyle = '#ffffff';
    c.beginPath(); c.moveTo(-2, 14); c.lineTo(-2, -8); c.arc(4, -8, 6, Math.PI, TAU); c.stroke();
    c.lineWidth = 7; c.strokeStyle = e.col; c.setLineDash([4, 4]);
    c.beginPath(); c.moveTo(-2, 14); c.lineTo(-2, -8); c.arc(4, -8, 6, Math.PI, TAU); c.stroke(); c.setLineDash([]); c.lineCap = 'butt';
    c.fillStyle = e.wind > 0 ? '#ff2a2a' : '#1b1030'; c.beginPath(); circ(c, -4, -4, 1.6); circ(c, 0, -4, 1.6); c.fill();
  },
  lollipop(c, e) {
    c.fillStyle = '#ffffff'; c.fillRect(-2, 0, 4, 16);
    c.save(); c.rotate(e.t * 3);
    blob(c, 0, 0, 14, 14, e.col, 2);
    c.strokeStyle = '#ffffff'; c.lineWidth = 3; c.beginPath(); for (let a = 0; a < 10; a += 0.25) c.lineTo(Math.cos(a) * a * 1.3, Math.sin(a) * a * 1.3); c.stroke();
    c.restore();
    lookEyes(c, -4, 4, -2, 2.4, e.look);
  },
  cloudling(c, e) {
    const col = e.charge > 0 ? '#5a6a9a' : e.col;
    for (const [x, y, r] of [[-7, 2, 8], [7, 2, 8], [0, -3, 10]]) { c.fillStyle = col; c.beginPath(); c.arc(x, y, r, 0, TAU); c.fill(); }
    c.fillStyle = 'rgba(255,255,255,0.4)'; c.beginPath(); c.arc(-3, -6, 4, 0, TAU); c.fill();
    brows(c, -4, 4, -4, 2.5, 0.6);
    c.fillStyle = '#1b1030'; c.beginPath(); circ(c, -4, -1, 1.6); circ(c, 4, -1, 1.6); c.fill();
    if (e.charge > 0) { c.strokeStyle = '#fff04a'; c.lineWidth = 2; c.beginPath(); c.moveTo(-2, 9); c.lineTo(2, 14); c.lineTo(-1, 14); c.lineTo(3, 20); c.stroke(); }
  },
  pegasus(c, e) {
    c.scale(e.face, 1);
    const f = Math.sin(e.t * 16) * 0.5;
    c.fillStyle = 'rgba(255,255,255,0.85)'; c.save(); c.translate(-2, -6); c.rotate(-0.8 + f); c.beginPath(); c.ellipse(0, -8, 4, 10, 0, 0, TAU); c.fill(); c.restore();
    blob(c, -2, 0, 12, 7, e.col, 1.5); blob(c, 10, -6, 5.5, 5, e.col, 1.5);
    c.fillStyle = RAINBOW[Math.floor(e.t * 8) % 7]; c.fillRect(4, -12, 5, 3);
    c.fillStyle = '#1b1030'; c.beginPath(); c.arc(12, -7, 1.5, 0, TAU); c.fill();
    if (e.wind > 0) { c.fillStyle = 'rgba(255,60,60,0.5)'; c.beginPath(); c.arc(0, 0, 16, 0, TAU); c.fill(); }
  },
  starfall(c, e) {
    const pulse = e.fuse > 0 ? 1 + Math.sin(e.t * 40) * 0.12 : 1;
    c.scale(pulse, pulse);
    c.fillStyle = 'rgba(255,224,74,0.3)'; c.beginPath(); c.arc(0, 0, 16, 0, TAU); c.fill();
    c.fillStyle = e.fuse > 0 && Math.floor(e.t * 16) % 2 ? '#ff6a22' : e.col; star(c, 0, 0, 12, e.t * 3); c.fill();
    c.strokeStyle = '#b8860b'; c.lineWidth = 1.5; c.stroke();
    c.fillStyle = '#1b1030'; c.beginPath(); circ(c, -3, -1, 1.5); circ(c, 3, -1, 1.5); c.fill();
  },
  harpy(c, e) {
    const f = Math.sin(e.t * 18) * 0.6;
    for (const s of [-1, 1]) { c.save(); c.scale(s, 1); c.rotate(f * 0.5); c.fillStyle = shade(e.col, -0.2); c.beginPath(); c.moveTo(4, -2); c.quadraticCurveTo(14, -16, 22, -6); c.lineTo(14, 0); c.lineTo(18, 6); c.lineTo(6, 4); c.closePath(); c.fill(); c.restore(); }
    blob(c, 0, 0, 8, 9, e.col, 1.5);
    c.fillStyle = '#ffe0cc'; c.beginPath(); c.arc(0, -8, 5, 0, TAU); c.fill();
    c.fillStyle = '#ff3ea5'; c.beginPath(); c.arc(0, -11, 5, Math.PI, TAU); c.fill();
    c.fillStyle = '#1b1030'; c.beginPath(); circ(c, -2, -8, 1.2); circ(c, 2, -8, 1.2); c.fill();
  },
  trashbot(c, e) {
    const w = Math.sin(e.t * 8) * 1.5;
    c.fillStyle = '#3a3a3a'; c.fillRect(-10, 10 + w, 6, 6); c.fillRect(4, 10 - w, 6, 6);
    c.fillStyle = glossGrad(c, 0, 0, 16, e.col); roundRect(c, -14, -12, 28, 24, 4); c.fill();
    c.strokeStyle = '#2a2a2a'; c.lineWidth = 2; c.stroke();
    c.fillStyle = '#4a5a6a'; c.fillRect(-15, -16, 30, 5);
    c.fillStyle = '#ff3b3b'; c.fillRect(-8, -6, 5, 3); c.fillRect(3, -6, 5, 3);
    c.fillStyle = '#7dff4a'; c.fillRect(-3, 4, 2, 4); c.fillRect(2, 2, 2, 6);
    c.fillStyle = '#ffd23a'; c.fillRect(8, 6, 4, 3);
  },
  commenter(c, e) {
    blob(c, 0, 4, 11, 10, '#5a8aff', 1.5);
    c.fillStyle = '#ffffff'; c.strokeStyle = '#1b1030'; c.lineWidth = 1.5;
    roundRect(c, -12, -22, 24, 14, 5); c.fill(); c.stroke();
    c.beginPath(); c.moveTo(-3, -8); c.lineTo(0, -4); c.lineTo(3, -8); c.fill();
    c.fillStyle = '#1b1030'; for (let k = 0; k < 3; k++) { c.beginPath(); c.arc(-6 + k * 6, -15, 1.8, 0, TAU); c.fill(); }
    lookEyes(c, -3.5, 3.5, 3, 2.4, e.look);
  },
  rat(c, e) {
    c.scale(e.face, 1);
    const l = Math.sin(e.t * 20) * 1.5;
    c.strokeStyle = '#d8a0a0'; c.lineWidth = 1.5; c.beginPath(); c.moveTo(-8, 1); c.quadraticCurveTo(-16, -2 + l, -18, 4); c.stroke();
    blob(c, -1, 1, 9, 6, e.col, 1.5); blob(c, 8, -1, 4.5, 4, e.col, 1.2);
    c.fillStyle = '#d8a0a0'; c.beginPath(); c.arc(6, -5, 2.5, 0, TAU); c.fill();
    c.fillStyle = '#ff3b3b'; c.beginPath(); c.arc(10, -2, 1.2, 0, TAU); c.fill();
  },
  mknight(c, e) {
    c.fillStyle = glossGrad(c, 0, 0, 16, e.col);
    roundRect(c, -12, -10, 24, 24, 6); c.fill(); c.strokeStyle = '#4a7aa8'; c.lineWidth = 2; c.stroke();
    blob(c, 0, -15, 9, 8, '#d8f0ff', 2);
    c.fillStyle = '#1b2a4a'; c.fillRect(-6, -16, 12, 3);
    c.fillStyle = '#ff3ea5'; c.fillRect(-1, -25, 2, 6);
    c.fillStyle = 'rgba(255,255,255,0.6)'; c.beginPath(); c.moveTo(-8, -6); c.lineTo(-2, -6); c.lineTo(-8, 4); c.fill();
  },
  reflection(c, e) {
    c.globalAlpha *= 0.75;
    drawRyzhovaya(c, 0, 4, e.t, e.look > Math.PI / 2 || e.look < -Math.PI / 2 ? -1 : 1, 0.95, 1, true);
    c.globalAlpha /= 0.75;
    c.fillStyle = 'rgba(150,220,255,0.35)'; c.beginPath(); c.ellipse(0, -6, 14, 18, 0, 0, TAU); c.fill();
  },
  shardling(c, e) {
    c.rotate(e.t * 6);
    c.fillStyle = e.col; c.beginPath(); c.moveTo(0, -10); c.lineTo(6, 0); c.lineTo(0, 10); c.lineTo(-6, 0); c.closePath(); c.fill();
    c.strokeStyle = '#ffffff'; c.lineWidth = 1.5; c.stroke();
  },
  zmirror(c, e) {
    const g = 0.5 + Math.sin(e.t * 4) * 0.5;
    c.fillStyle = `rgba(191,234,255,${0.2 + g * 0.2})`; c.beginPath(); c.ellipse(0, -4, 26, 32, 0, 0, TAU); c.fill();
    c.fillStyle = '#ffd25a'; c.beginPath(); c.ellipse(0, -4, 18, 25, 0, 0, TAU); c.fill();
    const gr = c.createLinearGradient(-14, -24, 14, 16); gr.addColorStop(0, '#ffffff'); gr.addColorStop(0.5, '#9ad8f8'); gr.addColorStop(1, '#c8b8ff');
    c.fillStyle = gr; c.beginPath(); c.ellipse(0, -4, 14, 21, 0, 0, TAU); c.fill();
    if (ART.zyamaSmall) { c.globalAlpha *= 0.55; c.save(); c.beginPath(); c.ellipse(0, -4, 12, 18, 0, 0, TAU); c.clip(); c.drawImage(ART.zyamaSmall, -12, -16, 24, 24); c.restore(); c.globalAlpha /= 0.55; }
    c.fillStyle = 'rgba(255,255,255,0.7)'; c.beginPath(); c.moveTo(-8, -18); c.lineTo(-2, -18); c.lineTo(-10, -2); c.fill();
  },
});
ESPR.sludge = ESPR.slime;

// ---------- боссы главы 3 ----------
Object.assign(BSPR, {
  glitchcat(c, b, t) {
    const fl = b.flash > 0;
    const gl = Math.random() < 0.12 ? rnd(-6, 6) : 0;
    const col = fl ? '#ffffff' : b.stage >= 2 ? '#ff3ea5' : '#3ff0a0';
    c.translate(gl, 0);
    c.globalAlpha *= 0.4; c.fillStyle = '#ff3ea5'; c.fillRect(-30 - 4, -34, 60, 58); c.fillStyle = '#3ff0ff'; c.fillRect(-30 + 4, -30, 60, 58);
    c.globalAlpha /= 0.4;
    c.fillStyle = '#1b1b2a'; c.fillRect(-30, -32, 60, 58);
    c.fillStyle = col;
    c.beginPath(); c.moveTo(-30, -32); c.lineTo(-22, -52); c.lineTo(-10, -32); c.fill();
    c.beginPath(); c.moveTo(30, -32); c.lineTo(22, -52); c.lineTo(10, -32); c.fill();
    c.fillStyle = '#0a0a14'; c.fillRect(-24, -24, 48, 30);
    c.fillStyle = col;
    if (b.stage >= 2) { c.font = 'bold 14px Krilessa Icons, monospace'; c.textAlign = 'center'; c.fillText('X  X', 0, -6); }
    else { c.fillRect(-16, -16, 8, 8 + (Math.floor(t * 3) % 6 === 0 ? -6 : 0)); c.fillRect(8, -16, 8, 8 + (Math.floor(t * 3) % 6 === 0 ? -6 : 0)); }
    c.fillRect(-6, -2, 12, 3);
    c.strokeStyle = col; c.lineWidth = 2;
    for (const s of [-1, 1]) for (let k = 0; k < 3; k++) { c.beginPath(); c.moveTo(s * 26, -6 + k * 5); c.lineTo(s * 40, -10 + k * 7); c.stroke(); }
    c.fillStyle = '#2a2a3a'; c.fillRect(-26, 26, 14, 8); c.fillRect(12, 26, 14, 8);
    c.strokeStyle = col; c.lineWidth = 5; c.beginPath(); c.moveTo(28, 18); c.quadraticCurveTo(52, 10 + Math.sin(t * 5) * 10, 44, -14); c.stroke();
    c.fillStyle = '#fff'; c.font = 'bold 9px Krilessa Icons, monospace'; c.textAlign = 'center'; c.fillText('MEOW.EXE', 0, 20);
  },
  cakequeen(c, b, t) {
    const fl = b.flash > 0;
    const sq = 1 + Math.sin(t * 3) * 0.04; c.scale(1 / sq, sq);
    const tier = (y, w, h, col) => { c.fillStyle = fl ? '#ffffff' : col; roundRect(c, -w / 2, y, w, h, 6); c.fill(); c.strokeStyle = '#a0506a'; c.lineWidth = 2.5; c.stroke(); };
    tier(8, 84, 30, '#f7d8a0'); tier(-16, 66, 26, '#ffb3d6'); tier(-36, 48, 22, '#ffffff');
    c.fillStyle = '#ff6fb5';
    for (let k = 0; k < 8; k++) { c.beginPath(); c.arc(-36 + k * 10.3, 8, 5, 0, Math.PI); c.fill(); }
    for (let k = 0; k < 14; k++) { c.fillStyle = RAINBOW[k % 7]; c.fillRect(-36 + (k * 23) % 72, 16 + (k * 7) % 16, 4, 2); }
    lookEyes(c, -10, 10, -26, 6, b.look);
    if (b.stage >= 2) brows(c, -10, 10, -34, 6, 0.6);
    c.fillStyle = '#c0306a'; c.beginPath(); c.arc(0, -16, 6, 0, Math.PI); c.fill();
    c.fillStyle = 'rgba(255,120,150,0.6)'; c.beginPath(); c.ellipse(-20, -18, 5, 3, 0, 0, TAU); c.ellipse(20, -18, 5, 3, 0, 0, TAU); c.fill();
    c.fillStyle = '#ffd25a'; c.strokeStyle = '#b8860b'; c.lineWidth = 2;
    c.beginPath(); c.moveTo(-14, -38); c.lineTo(-14, -52); c.lineTo(-7, -44); c.lineTo(0, -56); c.lineTo(7, -44); c.lineTo(14, -52); c.lineTo(14, -38); c.closePath(); c.fill(); c.stroke();
    for (const x of [-26, 26]) { c.fillStyle = '#fff'; c.fillRect(x - 2, -48, 4, 12); c.fillStyle = '#ffb03a'; c.beginPath(); c.ellipse(x, -52, 3, 5 + Math.sin(t * 15 + x) * 1, 0, 0, TAU); c.fill(); }
  },
  unicorn(c, b, t) {
    const fl = b.flash > 0, f = Math.sin(t * 8) * 0.4;
    const face = Math.cos(b.look) >= 0 ? 1 : -1;
    c.scale(face, 1);
    for (let k = 0; k < 7; k++) { c.fillStyle = RAINBOW[k]; c.globalAlpha *= 0.6; c.fillRect(-60 - k * 2, -6 + k * 3, 30, 3); c.globalAlpha /= 0.6; }
    c.fillStyle = 'rgba(255,255,255,0.85)';
    c.save(); c.translate(-4, -12); c.rotate(-1 + f); c.beginPath(); c.ellipse(0, -16, 8, 22, 0, 0, TAU); c.fill(); c.restore();
    blob(c, -4, 4, 30, 18, fl ? '#ffffff' : '#ffffff', 3);
    for (const x of [-22, -10, 6, 18]) { c.fillStyle = '#f0e8ff'; c.fillRect(x, 16 + Math.sin(t * 10 + x) * 3, 6, 16); c.fillStyle = '#c8a0ff'; c.fillRect(x, 30 + Math.sin(t * 10 + x) * 3, 6, 4); }
    blob(c, 26, -16, 14, 12, '#ffffff', 3);
    c.fillStyle = '#ffd25a'; c.beginPath(); c.moveTo(28, -26); c.lineTo(36, -50); c.lineTo(34, -26); c.closePath(); c.fill();
    for (let k = 0; k < 6; k++) { c.fillStyle = RAINBOW[(k + Math.floor(t * 10)) % 7]; c.beginPath(); c.arc(16 - k * 5, -26 + (k % 2) * 6, 5, 0, TAU); c.fill(); }
    lookEyes(c, 28, 34, -18, 3.5, 0, '#ffffff', b.stage >= 2 ? '#ff2a5a' : '#5a3aff');
    c.fillStyle = '#ff9db5'; c.beginPath(); c.arc(34, -10, 3, 0, TAU); c.fill();
  },
  trashbot(c, b, t) {
    const fl = b.flash > 0, w = Math.sin(t * 6) * 3;
    const body = fl ? '#ffffff' : '#6a7a8a';
    c.fillStyle = '#2a2a2a'; c.fillRect(-30, 30 + w, 22, 12); c.fillRect(8, 30 - w, 22, 12);
    for (const s of [-1, 1]) { c.fillStyle = '#4a5a6a'; c.save(); c.translate(s * 42, 0); c.rotate(s * (0.3 + Math.sin(t * 4) * 0.2)); c.fillRect(-7, -8, 14, 34); c.fillStyle = '#c0c0c0'; c.beginPath(); c.arc(0, 30, 9, 0, TAU); c.fill(); c.restore(); }
    c.fillStyle = fl ? '#fff' : glossGrad(c, 0, 0, 40, body); roundRect(c, -34, -30, 68, 62, 8); c.fill();
    c.strokeStyle = '#2a2a2a'; c.lineWidth = 3; c.stroke();
    c.fillStyle = '#3a4a5a'; c.fillRect(-38, -38, 76, 10);
    c.fillStyle = '#0a0a14'; roundRect(c, -24, -22, 48, 22, 4); c.fill();
    const ec = b.stage >= 2 ? '#ff2a2a' : '#ff8a3a';
    c.fillStyle = ec; c.fillRect(-18, -16, 12, 6); c.fillRect(6, -16, 12, 6);
    c.fillStyle = '#7dff4a'; c.font = 'bold 9px Krilessa Icons, monospace'; c.textAlign = 'center'; c.fillText(b.stage >= 2 ? '>:(' : 'ГРР', 0, -4);
    c.fillStyle = '#7dff4a'; for (let k = 0; k < 5; k++) { c.fillRect(-26 + k * 12, 6 + ((t * 20 + k * 7) % 14), 3, 5); }
    const spr = emojiSprite('💢', 16); c.drawImage(spr, 14, 6, 20, 20);
  },
});
