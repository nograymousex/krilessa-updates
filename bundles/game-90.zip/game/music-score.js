'use strict';

// Steps are eighth notes. Silence and sustained notes leave room for attacks and dialogue.
const AdventureScore = (() => {
  const parts = [
    [
      'trail',
      'field meadow swamp dark field2 desert volcano crystal field3 glitch candy sky toxic mirror',
    ],
    ['house', 'night4 hall4 tv4 bath4 morning5 detective5 garden5 yard5'],
    ['winter', 'snow winter6 ginger6 blizzard6 aurora6'],
    ['tide', 'reef7 krill7 ship7 jelly7 abyss7'],
    ['battle', 'boss final final2 meowboss final5 mrakboss krillboss ultimate zyamashow'],
    ['homecoming', 'win truewin'],
    ['watch', 'defense'],
    ['harbour', 'banks'],
  ];
  const families = Object.fromEntries(
    parts.flatMap(([family, names]) => names.split(' ').map((name) => [name, family])),
  );
  const phrases = {
    trail: [0, 0, 4, 5, 7, 0, 5, 4, 2, 0, 0, 4, 2, 0, -1, 0],
    house: [0, 0, 0, 3, 7, 0, 6, 0, 3, 0, 2, 0, -2, 0, 0, 2],
    winter: [7, 0, 0, 9, 12, 0, 11, 0, 7, 0, 4, 0, 2, 0, 0, 0],
    tide: [0, 0, 7, 0, 10, 0, 9, 7, 5, 0, 0, 2, 0, 0, 0, 0],
    battle: [0, 0, 0, 7, 3, 2, 0, -2, 0, 0, 7, 10, 7, 0, 5, 2],
    homecoming: [0, 4, 7, 0, 12, 0, 0, 9, 7, 0, 4, 5, 7, 0, 0, 0],
    watch: [0, 0, 7, 0, 3, 0, 2, 0, 0, 0, 5, 7, 2, 0, -2, 0],
    harbour: [0, 0, 7, 5, 0, 3, 0, 2, 0, -2, 0, 3, 7, 0, 0, 0],
  };
  const major = new Set([
    'field',
    'meadow',
    'candy',
    'sky',
    'morning5',
    'garden5',
    'ginger6',
    'aurora6',
    'jelly7',
    'win',
    'truewin',
  ]);
  function play(name, song, step, delay, beat, energy, voice) {
    const family = families[name] || 'trail',
      pos = step % 8,
      bar = Math.floor(step / 8) % 16;
    const quiet = family === 'winter' || family === 'tide',
      fight = family === 'battle';
    const base = song.bass.find(Boolean) || 45;
    const root = song.bass[(step - pos) % song.bass.length] || base;
    const degree = major.has(name) ? 4 : 3;
    const swing = family === 'house' && pos % 2 ? 0.13 * beat : 0,
      d = delay + swing;
    const high = family === 'winter' || family === 'harbour';
    if (pos === 0 || pos === 4 || (energy > 0.48 && pos === 6)) {
      voice.bass(root + (pos === 4 ? 7 : 0), beat * (quiet ? 2.8 : 1.55), d, pos === 0 ? 0.26 : 0.17);
    }
    if (pos === 0 && bar % 2 === 0)
      voice.chord([root + 12, root + 12 + degree, root + 19], beat * 13, d, quiet ? 0.026 : 0.019);
    let lead = song.lead[step % song.lead.length],
      length = 1.12;
    if (bar % 8 >= 4) {
      const phrase = phrases[family],
        off = step % 16,
        interval = phrase[off];
      const attack = interval !== 0 || off === 0 || off === 8;
      lead = attack ? root + 24 + interval : 0;
      if (lead) {
        length = 1;
        while (off + length < 16 && phrase[off + length] === 0 && off + length !== 8) length++;
      }
    }
    if (lead && (!quiet || pos % 2 === 0 || bar >= 8)) {
      if (family === 'house' || fight || family === 'watch')
        voice.string(lead, beat * length, d, fight ? 0.16 : 0.13, fight ? 'bow' : 'pluck');
      else if (high) voice.bell(lead, d, 0.13, beat * (length + 1.6));
      else voice.flute(lead, Math.max(0.19, beat * length * 0.96), d, 0.145);
    }
    if ((pos === 2 || pos === 5 || (bar >= 8 && pos === 7)) && (!fight || energy > 0.35)) {
      const arp = root + 12 + [0, 7, 12 + degree, 7][(bar + pos) % 4];
      voice.string(arp, beat * 1.7, d, 0.085, 'harp');
    }
    if (bar === 7 || bar === 15) {
      const sign = [7, null, 14, 17, null, 15, 14, 12][pos];
      if (sign !== null) voice.bell(base + 24 + sign, d, 0.057, beat * 2.4);
    }
    if (fight || family === 'harbour' || family === 'watch' || energy > 0.4) {
      if (pos === 0 || (pos === 5 && energy > 0.4)) voice.drum(d, fight ? 0.26 : 0.17);
      if ((pos === 3 || pos === 6) && (fight || energy > 0.55)) voice.brush(d, 0.067);
    } else if (song.drums && pos === 6 && bar % 2) voice.brush(d, 0.04);
  }
  return { play };
})();
