'use strict';

const CombatCues = (() => {
  function announce(h) {
    if (!h.cue || h.t >= h.delay || Session.state !== 'play' || Math.hypot(h.x - P.x, h.y - P.y) > 980)
      return;
    if (h.cue === 'charge') {
      Sound.sfx.ramCall();
      Challenges.signal('ram');
    } else Sound.sfx.leapCall();
  }
  function tag(h, b, cue) {
    Object.assign(h, { cue, bossKind: b.kind, ox: b.x, oy: b.y });
    announce(h);
    return h;
  }
  function current(b) {
    return (
      b && G.hazards.find((h) => h.cue && h.bossKind === b.kind && !h.cancel && !h.done && h.t < h.delay)
    );
  }
  function posture(c, b) {
    const h = current(b);
    if (!h) return;
    const p = clamp(h.t / h.delay, 0, 1);
    if (h.cue === 'charge') {
      const sign = Math.cos(h.ang) >= 0 ? 1 : -1;
      c.rotate(sign * (0.07 + p * 0.09));
      if (b.kind === 'yeti') {
        c.fillStyle = '#dff6ff';
        for (let i = 0; i < 8; i++) {
          const f = (p + i / 8) % 1;
          c.beginPath();
          c.arc(-sign * (16 + f * 32), -b.r * 0.85 + f * f * 35, 3 * (1 - f) + 1, 0, TAU);
          c.fill();
        }
      }
    } else if (b.z < 24) c.scale(1.13, 0.83);
  }
  function overlay(c) {
    for (const h of G.hazards) {
      if (!h.cue || h.done || h.cancel || h.t >= h.delay) continue;
      const p = clamp(h.t / h.delay, 0, 1);
      c.save();
      c.translate(h.x, h.y);
      c.lineCap = 'round';
      c.lineJoin = 'round';
      c.beginPath();
      if (h.cue === 'charge') {
        c.rotate(h.ang);
        for (const side of [-1, 1]) {
          c.moveTo(15, side * h.w * 0.48);
          c.lineTo(h.len - 27, side * h.w * 0.31);
          c.lineTo(h.len, 0);
        }
        for (let j = 0; j < 3; j++) {
          const x = 40 + ((p * 92 + j * 145) % (h.len - 65));
          c.moveTo(x - 9, -9);
          c.lineTo(x, 0);
          c.lineTo(x - 9, 9);
        }
      } else {
        c.arc(0, 0, h.r, 0, TAU);
        c.moveTo(h.r * (1.46 - 0.46 * p), 0);
        c.arc(0, 0, h.r * (1.46 - 0.46 * p), 0, TAU);
      }
      c.strokeStyle = '#35283b';
      c.lineWidth = 5;
      c.stroke();
      c.strokeStyle = h.cue === 'charge' ? '#ffdb98' : '#c2f6f2';
      c.lineWidth = 2.4;
      c.stroke();
      if (h.cue === 'leap' && h.bossKind === 'toad') {
        c.strokeStyle = '#b1eacc';
        c.lineWidth = 1.8;
        for (let i = 0; i < 2; i++) {
          const f = (p + i * 0.5) % 1;
          c.globalAlpha = 1 - f;
          c.beginPath();
          c.ellipse(h.ox - h.x, h.oy - h.y, 17 + 68 * f, 9 + 26 * f, 0, 0, TAU);
          c.stroke();
        }
      }
      c.restore();
    }
  }
  function rescue(c, m) {
    if (!m.down || P.down || m.away) return;
    const w = Viewport.VW,
      h = Viewport.VH,
      dx = (m.tx - G.cam.x) * Viewport.ZOOM,
      dy = (m.ty - G.cam.y) * Viewport.ZOOM;
    if (Math.abs(dx) < w / 2 - 18 && Math.abs(dy) < h / 2 - 30) return;
    const top = Viewport.SAFE_TOP + 106,
      bottom = h - 115,
      left = 25,
      right = w - 25;
    const scale = Math.min(
      (dx < 0 ? w / 2 - left : right - w / 2) / Math.max(1, Math.abs(dx)),
      (dy < 0 ? h / 2 - top : bottom - h / 2) / Math.max(1, Math.abs(dy)),
    );
    const x = w / 2 + dx * scale,
      y = h / 2 + dy * scale;
    c.save();
    c.translate(x, y);
    c.rotate(Math.atan2(dy, dx));
    c.fillStyle = '#ffdc92';
    c.beginPath();
    c.moveTo(24, 0);
    c.lineTo(13, -6);
    c.lineTo(13, 6);
    c.closePath();
    c.fill();
    c.rotate(-Math.atan2(dy, dx));
    c.fillStyle = '#222b40';
    c.beginPath();
    c.arc(0, 0, 15, 0, TAU);
    c.fill();
    const portrait = Expedition.heroAvatar(m.hero);
    if (portrait) {
      c.save();
      c.clip();
      c.drawImage(portrait, -14, -14, 28, 28);
      c.restore();
    }
    c.strokeStyle = '#efbe76';
    c.lineWidth = 2;
    c.stroke();
    if (m.rp) {
      c.beginPath();
      c.arc(0, 0, 17, -Math.PI / 2, -Math.PI / 2 + TAU * clamp(m.rp / 100, 0, 1));
      c.strokeStyle = '#8df1b6';
      c.lineWidth = 3;
      c.stroke();
    }
    c.restore();
  }
  return { tag, announce, current, posture, overlay, rescue };
})();
