'use strict';

const Effects = (() => {
  // на поздних волнах обороны, когда врагов толпа, частиц меньше – телефону легче
  const partMax = () => G.td && G.enemies.length > 90 ? 240 : 500;
  function part(x, y, vx, vy, life, size, col, grav = 0) {
    if (G.parts.length > partMax()) return;
    G.parts.push({ x, y, vx, vy, life, max: life, size, col, grav });
  }
  function burst(x, y, n, col, spd) {
    for (let i = 0; i < n; i++) { const a = rnd(0, TAU), s = rnd(0.2, 1) * spd; part(x, y, Math.cos(a) * s, Math.sin(a) * s, rnd(0.3, 0.8), rnd(2, 5), col); }
  }
  function floatText(x, y, txt, col = '#fff', big = false) {
    if (G.texts.length > 45) G.texts.shift();
    G.texts.push({ x, y, txt, t: 0, col, big });
  }
  function dmgText(x,y,v,col='#fff',crit=false,target=null) {
    const hit=crit ? null : target && G.texts.find(t=>t.target===target && t.t<.19 && t.col===col && !t.crit);
    if(hit) {hit.total+=v;hit.txt=String(Math.max(1,Math.round(hit.total)));return;}
    floatText(x,y,String(Math.max(1,Math.round(v)))+(crit?'!':''),crit?'#ffe04a':col,crit);
    Object.assign(G.texts[G.texts.length-1],{target,crit,total:v});
  }
  function healing(amount) {
    if(amount<=0) return;
    G.healReadout={amount:Math.round(amount),at:G.time};
  }
  function drawHealing(c) {
    const h=G.healReadout; if(!h || Session.state!=='play') return;
    const age=G.time-h.at; if(age<0 || age>1.05) return;
    c.save();c.setTransform(Viewport.DPR,0,0,Viewport.DPR,0,0);c.globalAlpha=clamp(1-age/1.05,0,1);
    c.font='bold 15px Nunito,sans-serif';c.textAlign='left';c.lineWidth=3;c.strokeStyle='#163b33';c.fillStyle='#a9ffd1';
    const x=Terrain.paperOn?25:58,y=Viewport.SAFE_TOP+33-age*19;
    c.strokeText('+'+h.amount,x,y);c.fillText('+'+h.amount,x,y);c.restore();
  }
  function shockRing(x, y, col, max = 220) { G.rings.push({ x, y, r: 10, max, col, t: 0 }); }
  // талант «Звездопад»: звезда падает на цель и бьёт всех вокруг
  function starfall(x, y, k = 3, col = '#ffe08a', ic = '🌠') {
    const R = 80, base = P.dmg * k;
    for (const e of G.enemies) if (!e.dead && !(e.spawnT > 0) && (e.x - x) ** 2 + (e.y - y) ** 2 < (R + e.r) ** 2) Enemies.damageEnemy(e, Actors.rollHit(base), 0, 0, false);
    const b = G.activeBoss; if (b && (b.x - x) ** 2 + (b.y - y) ** 2 < (R + b.r) ** 2) Bosses.damageBoss(b, Actors.rollHit(base));
    shockRing(x, y, col, R); burst(x, y, 22, col, 220);
    for (let j = 0; j < 8; j++) part(x + rnd(-10, 10), y - 120 + j * 15, 0, 300, 0.25, 5, col);
    floatText(x, y - 30, ic, col);
  }
  function dropGem(x, y, v) {
    if (G.pickups.length > 280) { const g = G.pickups.find(p => p.kind === 'xp'); if (g) { g.v += v; return; } }
    G.pickups.push({ kind: 'xp', x, y, v, t: 0, pull: false });
  }
  function dropPickup(x, y, kind, extra) { if (kind === 'heart' && G.mut && G.mut.noheart) return; if (kind === 'key' && G.td) return; /* в обороне ключи не нужны */ G.pickups.push(Object.assign({ kind, x, y, v: 0, t: 0, pull: false }, extra || {})); }
  const SHARD_W = SHARDS.map((s, i) => [i, s.w]);
  function dropShard(x, y) { dropPickup(x + rnd(-12, 12), y + rnd(-12, 12), 'shard', { sid: weighted(SHARD_W) }); }

  return { partMax, part, burst, floatText, dmgText, healing, drawHealing, shockRing, starfall, dropGem, dropPickup, dropShard };
})();
