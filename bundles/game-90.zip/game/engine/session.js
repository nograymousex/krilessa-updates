'use strict';

// Эти три объекта живут до закрытия страницы. Смена главы переиспользует их,
// поэтому цикл игры, кооператив и публичный интерфейс видят одно состояние.
const NET = { on: false, host: false, client: false, id: 0, peers: new Map(), mates: new Map(), uid: 0, hitBy: 0, scanning: false, goneB: new Set() };
const P = {
  x: 0, y: 0, r: 13, hp: 100, maxHp: 100, face: 1, t: 0, inv: 0, dashT: 0, dashCd: 0, dashX: 0, dashY: 0,
  fireT: 0, boltT: 0, orbA: 0, moving: false, level: 1, xp: 0, xpNext: 10, up: {}, bonus: {},
  vx: 0, vy: 0, slowT: 0, shieldT: 0, shards: 0, hero: 'krilessa', sp: 0, stormT: 0, stormE: 0,
};
const G = {
  time: 0, kills: 0, defeated: [], cp: { x: 0, y: 0 },
  enemies: [], feathers: [], ebullets: [], hazards: [], pickups: [], parts: [], texts: [], bolts: [], rings: [], beams: [],
  shake: 0, hurtFlash: 0, activeBoss: null, pendingLv: 0, spawnT: 0, fogT: 0, gateMsgT: 0, lowHpT: 0,
  hintT: 0, cutscene: null, cam: { x: 0, y: 0 }, menuT: 0, victoryShown: false, cageOpen: 0,
  combo: 0, comboT: 0, bestCombo: 0, activeShrine: null, pzones: [], novas: [], scaleCache: {}, shooters: 0,
  diff: DIFFS.normal, diffId: 'normal', ev: null, evT: EVENT_EVERY, lastEv: null, st: null, lowHpSaid: false,
  finalFinal: null, rush: null, trueWin: false, musWant: null, musHold: 0, musT: 0,
};

const Session = {
  state: 'boot',
  bosses: [],
  AIM: null,
  IMG: { ryzhova: null, zyama: null },
  AVATAR: {},
  CH_NUMS: Object.keys(CHAPTERS)
    .filter(key => /^[1-9]\d*$/.test(key))
    .map(Number)
    .sort((a, b) => a - b),
};
