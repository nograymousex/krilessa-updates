'use strict';

// ------------------------------------------------------------------
//  Мультиплеер по Wi-Fi. Хозяин считает мир (мобы, боссы, опыт, подбор),
//  каждый гость – только свою героиню: движение, выстрелы, попадания по себе.
//  Попадания гостей по мобам уходят хозяину, хозяин рассылает снимки мира.
// ------------------------------------------------------------------
const NetT = (() => { // транспорт: Android (NetCore через мост) или BroadcastChannel – для проверок в браузере
  const A = () => { const a = window.KrilessaAndroid; return a && a.netPoll ? a : null; };
  let bc = null, role = null, q = [], hostKey = null, beaconT = 0, info = '', scanning = false, nextCid = 2;
  let myKey = null, closeTimer = 0;
  const peers = new Map(), keys = new Map();
  const post = m => { try { bc.postMessage(m); } catch (e) { /* ignore */ } };
  function bcInit() {
    if (bc || typeof BroadcastChannel === 'undefined') return;
    myKey = Math.random().toString(36).slice(2, 10);
    bc = new BroadcastChannel('krilessa-net');
    bc.onmessage = ev => onBc(ev.data);
  }
  function onBc(m) {
    if (!m || (m.to && m.to !== myKey)) return;
    if (m.k === 'beacon') { if (scanning && role !== 'host') q.push(['found', 0, 'local-' + m.from + '\t0\t' + m.info]); }
    else if (m.k === 'join' && role === 'host') { const cid = nextCid++; peers.set(m.from, cid); keys.set(cid, m.from); post({ k: 'open', to: m.from, from: myKey }); q.push(['conn', cid, 'local']); }
    else if (m.k === 'open' && role === 'client') { hostKey = m.from; q.push(['open', 0, '']); }
    else if (m.k === 'msg') { if (role === 'host') { const cid = peers.get(m.from); if (cid) q.push(['msg', cid, m.d]); } else if (m.from === hostKey) q.push(['msg', 0, m.d]); }
    else if (m.k === 'bye') {
      if (role === 'host') { const cid = peers.get(m.from); if (cid) { peers.delete(m.from); keys.delete(cid); q.push(['drop', cid, '']); } }
      else if (m.from === hostKey) { hostKey = null; q.push(['closed', 0, '']); }
    }
  }
  function close() {
    clearTimeout(closeTimer);
    closeTimer = 0;
    const bridge = A();
    if (bridge) bridge.netClose();
    if (bc) {
      if (role === 'host') {
        for (const key of peers.keys()) post({ k: 'bye', to: key, from: myKey });
      } else if (hostKey) {
        post({ k: 'bye', to: hostKey, from: myKey });
      }
      bc.close();
      bc = null;
    }
    clearInterval(beaconT);
    role = hostKey = null;
    peers.clear();
    keys.clear();
    scanning = false;
    q = [];
  }

  return {
    get native() { return !!A(); },
    get oldApk() { return !!window.KrilessaAndroid && !A(); },
    host(inf) {
      if (closeTimer) close();
      const a = A(); if (a) { try { return JSON.parse(a.netHost(inf)); } catch (e) { return { ok: false }; } }
      bcInit(); if (!bc) return { ok: false }; role = 'host'; info = inf; clearInterval(beaconT);
      beaconT = setInterval(() => post({ k: 'beacon', from: myKey, info }), 600);
      return { ok: true, port: 0, ips: [] };
    },
    info(inf) { const a = A(); if (a) a.netInfo(inf); else info = inf; },
    scan(on) {
      if (on && closeTimer) close();
      const bridge = A();
      if (bridge) bridge.netScan(!!on);
      else {
        if (on) bcInit();
        scanning = !!on;
      }
    },
    join(ip, port) {
      if (closeTimer) close();
      const a = A(); if (a) { a.netJoin(String(ip), port | 0); return; }
      bcInit(); role = 'client'; post({ k: 'join', to: String(ip).replace('local-', ''), from: myKey });
    },
    send(cid, obj) {
      const s = typeof obj === 'string' ? obj : JSON.stringify(obj);
      const a = A(); if (a) { a.netSend(cid, s); return; }
      if (!bc) return;
      if (role === 'host') { if (cid === -1) { for (const k of peers.keys()) post({ k: 'msg', to: k, from: myKey, d: s }); } else { const k = keys.get(cid); if (k) post({ k: 'msg', to: k, from: myKey, d: s }); } }
      else if (hostKey) post({ k: 'msg', to: hostKey, from: myKey, d: s });
    },
    kick(cid) { const a = A(); if (a) { a.netKick(cid); return; } const k = keys.get(cid); if (k) { post({ k: 'bye', to: k, from: myKey }); peers.delete(k); keys.delete(cid); } },
    poll() {
      const a = A();
      if (a) {
        const s = a.netPoll(); if (!s) return [];
        return s.split('\n').map(l => { const i1 = l.indexOf('\t'), i2 = l.indexOf('\t', i1 + 1); return [l.slice(0, i1), +l.slice(i1 + 1, i2), l.slice(i2 + 1)]; });
      }
      const out = q; q = []; return out;
    },
    ips() { const a = A(); try { return a ? String(a.netIps() || '').split(',').filter(Boolean) : []; } catch (e) { return []; } },
    close,
    closeAfterFlush() {
      clearTimeout(closeTimer);
      closeTimer = setTimeout(close, 120);
    },
  };
})();
