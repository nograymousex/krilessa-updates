'use strict';

const World = (() => {
  // ------------------------------------------------------------------
  //  Мир (пересоздаётся для каждой главы)
  // ------------------------------------------------------------------
  const T = 40;
  const PX_PER_M = 16;
  let CHN = 1, CFG = CHAPTERS[1], SEED = 0;
  let MW = 0, MH = 0, WORLD_W = 0, WORLD_H = 0, PLAY_H = 0, ARENA = null;
  let tiles = null, biomeMap, treeGrid, trees = [], chests = [], shrines = [], mainPath = [];
  // объекты глав Тессы
  let beds = [], lamps = [], clues = [], npcs = [], qitems = [], shelves = [], boxes = [], fires = [];
  let holes = [], ovens = [], drifts = [], glades = []; // глава 6
  let secrets = [], cracks = new Set(); // тайники: комната в скалах, вход – треснувшая стена
  let pearls = [], flow = null, curPts = []; // глава 7: слова-жемчужины и течения
  let START, CASTLE, GATE_FRONT, GATE_INNER, CAGE;
  let gateOpen = false, landscape = null;
  const tc = v => v * T + T / 2;
  const inMap = (tx, ty) => tx >= 0 && ty >= 0 && tx < MW && ty < MH;
  const tileAt = (tx, ty) => (inMap(tx, ty) ? tiles[ty * MW + tx] : ROCK);
  const isGround = t => t < PATH;

  function isSolidTile(tx, ty, fly) {
    if (!inMap(tx, ty)) return true;
    const i = ty * MW + tx, t = tiles[i];
    if (t === ROCK || t === WALL) return true;
    if (t === GATE) return !gateOpen;
    if (!fly && (t === WATER || t === LAVA)) return true;
    return false;
  }
  function blocksShots(x, y) {
    const tx = Math.floor(x / T), ty = Math.floor(y / T);
    if (!inMap(tx, ty)) return true;
    const t = tiles[ty * MW + tx];
    return t === ROCK || t === WALL || (t === GATE && !gateOpen);
  }

  function biomeAt(tx, ty) {
    const wx = tx + (vnoise(tx * 0.07, ty * 0.07) - 0.5) * 18;
    const wy = ty + (vnoise(tx * 0.07 + 40, ty * 0.07 + 40) - 0.5) * 18;
    let best = 1e9, b = 0;
    for (const [bb, x, y] of CFG.biomeSeeds) {
      const d = (wx - x) * (wx - x) + (wy - y) * (wy - y);
      if (d < best) { best = d; b = bb; }
    }
    return b;
  }

  function generateWorld(chapter, seed, revision = 1) {
    CHN = chapter;
    landscape = Landscapes.create(chapter, revision);
    CFG = landscape ? landscape.cfg : CHAPTERS[chapter];
    SEED = seed || CFG.seed;
    Terrain.paperBiomes();
    MW = CFG.MW; MH = CFG.MH; WORLD_W = MW * T; WORLD_H = MH * T;
    tiles = new Uint8Array(MW * MH); biomeMap = new Uint8Array(MW * MH); treeGrid = new Int32Array(MW * MH);
    trees = []; chests = []; shrines = []; mainPath = [];
    beds = []; lamps = []; clues = []; npcs = []; qitems = []; shelves = []; boxes = []; fires = [];
    holes = []; ovens = []; drifts = []; glades = []; pearls = []; flow = null; curPts = []; secrets = []; cracks = new Set();
    START = CFG.start;
    CASTLE = CFG.castle;
    const h = CASTLE.half;
    if (CASTLE.gate === 'west') {
      GATE_FRONT = { x: CASTLE.x - h - 3, y: CASTLE.y }; GATE_INNER = { x: CASTLE.x - h + 1, y: CASTLE.y };
    } else if (CASTLE.gate === 'east') {
      GATE_FRONT = { x: CASTLE.x + h + 3, y: CASTLE.y }; GATE_INNER = { x: CASTLE.x + h - 1, y: CASTLE.y };
    } else {
      GATE_FRONT = { x: CASTLE.x, y: CASTLE.y + h + 3 }; GATE_INNER = { x: CASTLE.x, y: CASTLE.y + h - 1 };
    }
    CAGE = CFG.cage;
    const rng = mulberry32(SEED);
    for (let ty = 0; ty < MH; ty++) for (let tx = 0; tx < MW; tx++) {
      const i = ty * MW + tx;
      const b = (landscape && landscape.rooms && landscape.rooms[i]) || biomeAt(tx,ty);
      biomeMap[i] = b; tiles[i] = landscape ? Landscapes.ground(landscape.mask[i],b) : b;
    }
    const plan = landscape && landscape.plan;
    if (plan && plan.glades) for (const [cx,cy,b] of plan.glades) {
      for(let y=cy-6;y<=cy+6;y++) for(let x=cx-6;x<=cx+6;x++) biomeMap[y*MW+x]=tiles[y*MW+x]=b;
    }
    const set = (tx, ty, t) => { if (inMap(tx, ty)) tiles[ty * MW + tx] = t; };
    // препятствия
    for (let n = 0; n < CFG.blobs; n++) {
      const cx = 4 + Math.floor(rng() * (MW - 8)), cy = 4 + Math.floor(rng() * (MH - 8));
      const type = weighted(BIOMES[biomeMap[cy * MW + cx]].obst, rng());
      const parts = 2 + Math.floor(rng() * 4);
      for (let k = 0; k < parts; k++) {
        const w = 2 + Math.floor(rng() * 6), hh = 2 + Math.floor(rng() * 5);
        const ox = cx + Math.floor(rng() * 8) - 4, oy = cy + Math.floor(rng() * 8) - 4;
        const ecx = ox + (w - 1) / 2, ecy = oy + (hh - 1) / 2, erx = w / 2, ery = hh / 2;
        for (let y = oy; y < oy + hh; y++) for (let x = ox; x < ox + w; x++) if (((x - ecx) / erx) ** 2 + ((y - ecy) / ery) ** 2 <= 1.05) set(x, y, type);
      }
    }
    for (let ty = 0; ty < MH; ty++) for (let tx = 0; tx < MW; tx++) {
      if (tx < 2 || ty < 2 || tx >= MW - 2 || ty >= MH - 2) set(tx, ty, ROCK);
    }
    // замок
    if (CHN === 8) {
      for (let y=CASTLE.y-h-1; y<=CASTLE.y+h+1; y++) for (let x=CASTLE.x-h-1; x<=CASTLE.x+h+1; x++) {
        const radius = Math.hypot(x-CASTLE.x,y-CASTLE.y);
        if (radius > h+.6) continue;
        set(x,y,radius < h-.65 ? FLOOR : WALL);
        biomeMap[y*MW+x] = CASTLE.biome;
      }
    } else {
      for (let y = CASTLE.y - h - 3; y <= CASTLE.y + h + 3; y++)
        for (let x = CASTLE.x - h - 3; x <= CASTLE.x + h + 3; x++) set(x, y, CASTLE.biome);
      for (let y = CASTLE.y - h; y <= CASTLE.y + h; y++) for (let x = CASTLE.x - h; x <= CASTLE.x + h; x++) {
        const edge = x === CASTLE.x - h || x === CASTLE.x + h || y === CASTLE.y - h || y === CASTLE.y + h;
        set(x, y, edge ? WALL : FLOOR);
        if (inMap(x, y)) biomeMap[y * MW + x] = CASTLE.biome;
      }
      for (const [cx, cy] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) {
        const bx = CASTLE.x + cx * h, by = CASTLE.y + cy * h;
        for (let y = by - 1; y <= by + 1; y++) for (let x = bx - 1; x <= bx + 1; x++) set(x, y, WALL);
      }
    }
    if (CASTLE.gate === 'west') for (let y = CASTLE.y - 1; y <= CASTLE.y + 1; y++) set(CASTLE.x - h, y, GATE);
    else if (CASTLE.gate === 'east') for (let y = CASTLE.y - 1; y <= CASTLE.y + 1; y++) set(CASTLE.x + h, y, GATE);
    else for (let x = CASTLE.x - 1; x <= CASTLE.x + 1; x++) set(x, CASTLE.y + h, GATE);

    const canDress = (x,y) => !landscape || landscape.mask[y * MW + x] === Landscapes.LAND;
    const reserved = (x,y) => landscape && landscape.reserved[y*MW+x];
    // дороги
    const brush = (x, y, rec) => {
      for (let oy = -1; oy <= 1; oy++) for (let ox = -1; ox <= 1; ox++) {
        const tx = x + ox, ty = y + oy;
        if (!inMap(tx, ty) || tx < 2 || ty < 2 || tx >= MW - 2 || ty >= MH - 2) continue;
        const t = tiles[ty * MW + tx];
        if (!canDress(tx,ty) || t === WALL || t === GATE || t === FLOOR) continue;
        const nearCastle = Math.abs(tx - CASTLE.x) < h + 8 && Math.abs(ty - CASTLE.y) < h + 8;
        tiles[ty * MW + tx] = nearCastle ? STONE : PATH;
        if (treeGrid[ty * MW + tx]) treeGrid[ty * MW + tx] = 0;
      }
      if (rec) mainPath.push([x, y]);
    };
    const carve = (ax, ay, bx, by, rec, r = rng) => {
      let x = ax, y = ay, guard = 0;
      brush(x, y, rec);
      while ((x !== bx || y !== by) && guard++ < 6000) {
        const dx = bx - x, dy = by - y;
        const horiz = dy === 0 || (dx !== 0 && r() < Math.abs(dx) / (Math.abs(dx) + Math.abs(dy)));
        const len = 2 + Math.floor(r() * 6);
        for (let k = 0; k < len; k++) {
          if (horiz) { if (x === bx) break; x += Math.sign(dx); } else { if (y === by) break; y += Math.sign(dy); }
          brush(x, y, rec);
        }
      }
    };
    const guards = CFG.bossTiles.slice(0, -1);
    if (landscape) {
      for (const path of landscape.plan.paths) Landscapes.walkLine(path, (x,y) => brush(x,y,true));
      carve(GATE_FRONT.x, GATE_FRONT.y, GATE_INNER.x, GATE_INNER.y, false);
    } else {
      const route = [START, ...guards, GATE_FRONT];
      for (let i = 0; i < route.length - 1; i++) carve(route[i].x, route[i].y, route[i + 1].x, route[i + 1].y, true);
      carve(GATE_FRONT.x, GATE_FRONT.y, GATE_INNER.x, GATE_INNER.y, false);
      if (CHN === 1) carve(START.x, START.y, GATE_FRONT.x, GATE_FRONT.y + 6, true);
      else carve(START.x, START.y, GATE_FRONT.x, GATE_FRONT.y, true);
    }
    const clearCircle = (cx, cy, r) => {
      for (let y = cy - r; y <= cy + r; y++) for (let x = cx - r; x <= cx + r; x++) {
        if (!inMap(x, y) || x < 2 || y < 2 || x >= MW - 2 || y >= MH - 2) continue;
        if ((x - cx) * (x - cx) + (y - cy) * (y - cy) > r * r) continue;
        const t = tiles[y * MW + x];
        treeGrid[y * MW + x] = 0;
        if (!canDress(x,y) || t === WALL || t === GATE || t === FLOOR || t === PATH || t === STONE) continue;
        tiles[y * MW + x] = biomeMap[y * MW + x];
      }
    };
    // ледяные реки-горки (глава 6): плавные извилистые полосы льда через полкарты
    if (CFG.slides) {
      const rs = mulberry32(SEED + 707);
      for (const [[ax, ay], [bx, by]] of CFG.slides) {
        const len = Math.hypot(bx - ax, by - ay), nx = -(by - ay) / len, ny = (bx - ax) / len;
        const amp = 3 + rs() * 5, waves = 1 + rs() * 1.5, ph = rs() * TAU;
        for (let k = 0; k <= len * 2; k++) {
          const t = k / (len * 2), w = Math.sin(t * Math.PI * waves * 2 + ph) * amp * Math.sin(t * Math.PI);
          const cx = Math.round(ax + (bx - ax) * t + nx * w), cy = Math.round(ay + (by - ay) * t + ny * w);
          for (let oy = -1; oy <= 1; oy++) for (let ox = -1; ox <= 1; ox++) {
            const x = cx + ox, y = cy + oy;
            if (!inMap(x, y) || x < 3 || y < 3 || x >= MW - 3 || y >= MH - 3) continue;
            if (Math.abs(x - CASTLE.x) <= h + 4 && Math.abs(y - CASTLE.y) <= h + 4) continue;
            const u = tiles[y * MW + x]; if (u === WALL || u === GATE || u === FLOOR || u === PATH || u === STONE) continue;
            tiles[y * MW + x] = ICE;
          }
        }
      }
    }
    // течения (глава 7): извилистые полосы через полкарты – несут вдоль себя
    if (CFG.currents) {
      flow = new Map();
      const rs = mulberry32(SEED + 717);
      for (const [[ax, ay], [bx, by]] of CFG.currents) {
        const len = Math.hypot(bx - ax, by - ay), nx = -(by - ay) / len, ny = (bx - ax) / len;
        const amp = landscape ? 0 : 3 + rs() * 4, waves = 1 + rs() * 1.2, ph = rs() * TAU;
        let px = ax, py = ay;
        for (let k = 0; k <= len * 2; k++) {
          const t = k / (len * 2), w = Math.sin(t * Math.PI * waves * 2 + ph) * amp * Math.sin(t * Math.PI);
          const fx = ax + (bx - ax) * t + nx * w, fy = ay + (by - ay) * t + ny * w;
          const ddx = fx - px, ddy = fy - py, dl = Math.hypot(ddx, ddy) || 1;
          const ux = k ? ddx / dl : (bx - ax) / len, uy = k ? ddy / dl : (by - ay) / len;
          px = fx; py = fy;
          if (k % 3 === 0) curPts.push({ x: fx * T + T / 2, y: fy * T + T / 2, dx: ux, dy: uy });
          const cx = Math.round(fx), cy = Math.round(fy);
          for (let oy = -1; oy <= 1; oy++) for (let ox = -1; ox <= 1; ox++) {
            const x = cx + ox, y = cy + oy;
            if (!inMap(x, y) || x < 3 || y < 3 || x >= MW - 3 || y >= MH - 3) continue;
            if (Math.abs(x - CASTLE.x) <= h + 4 && Math.abs(y - CASTLE.y) <= h + 4) continue;
            const i = y * MW + x, u = tiles[i]; if (!canDress(x,y) || u === WALL || u === GATE || u === FLOOR) continue;
            if (!isGround(u) && u !== PATH && u !== STONE) tiles[i] = biomeMap[i]; // через течение всегда можно проплыть
            flow.set(i, [ux, uy]);
          }
        }
      }
    }
    for (const g of guards) clearCircle(g.x, g.y, CHN === 1 ? 8 : 9);
    clearCircle(START.x, START.y, 5);
    // сундуки
    let tries = 0;
    while (chests.length < CFG.chests && tries++ < 900) {
      const cx = 5 + Math.floor(rng() * (MW - 10)), cy = 5 + Math.floor(rng() * (MH - 10));
      if (reserved(cx,cy) || !canDress(cx,cy) || Math.abs(cx - CASTLE.x) < h + 5 && Math.abs(cy - CASTLE.y) < h + 5) continue;
      let best = null, bd = 1e9;
      for (const [px, py] of mainPath) { const d = Math.abs(px - cx) + Math.abs(py - cy); if (d < bd) { bd = d; best = [px, py]; } }
      if (!best || bd < CFG.chestDist[0] || bd > CFG.chestDist[1]) continue;
      if (chests.some(c => Math.abs(c.tx - cx) + Math.abs(c.ty - cy) < 14)) continue;
      carve(best[0], best[1], cx, cy, false);
      clearCircle(cx, cy, 2);
      chests.push({ tx: cx, ty: cy, x: tc(cx), y: tc(cy), open: false, biome: biomeMap[cy * MW + cx] });
    }
    // деревья
    const blocked = [START, ...guards];
    for (let ty = 3; ty < MH - 3; ty++) for (let tx = 3; tx < MW - 3; tx++) {
      const t = tiles[ty * MW + tx];
      if (!isGround(t)) continue;
      if (blocked.some((p, i) => (p.x - tx) ** 2 + (p.y - ty) ** 2 < (i === 0 ? 30 : 80))) continue;
      if (chests.some(c => Math.abs(c.tx - tx) <= 1 && Math.abs(c.ty - ty) <= 1)) continue;
      if (Math.abs(tx - CASTLE.x) <= h + 1 && Math.abs(ty - CASTLE.y) <= h + 1) continue;
      if (flow && flow.has(ty * MW + tx)) continue; // течение свободно
      const pathy = (x, y) => { const u = tileAt(x, y); return u === PATH || u === STONE; };
      if (pathy(tx + 1, ty) || pathy(tx - 1, ty) || pathy(tx, ty + 1) || pathy(tx, ty - 1)) continue; // дороги свободны
      const b = biomeMap[ty * MW + tx];
      const dens = Math.min(0.16, BIOMES[b].treeP * (0.5 + vnoise(tx * 0.15 + 9, ty * 0.15 + 3)));
      if (rng() < dens) {
        trees.push({ x: tx * T + 10 + rng() * 20, y: ty * T + 14 + rng() * 20, kind: BIOMES[b].tree, s: 0.85 + rng() * 0.35 });
        treeGrid[ty * MW + tx] = trees.length;
      }
    }
    // алтари испытаний (отдельный генератор, чтобы не менять остальную карту)
    const r2 = mulberry32(SEED + 99);
    tries = 0;
    while (shrines.length < CFG.shrines && tries++ < 1500) {
      const cx = 10 + Math.floor(r2() * (MW - 20)), cy = 10 + Math.floor(r2() * (MH - 20));
      if (reserved(cx,cy) || Math.abs(cx - CASTLE.x) < h + 11 && Math.abs(cy - CASTLE.y) < h + 11) continue;
      if (!isGround(tiles[cy * MW + cx])) continue;
      if (CFG.bossTiles.some(b => Math.abs(b.x - cx) + Math.abs(b.y - cy) < 16)) continue;
      if (Math.abs(START.x - cx) + Math.abs(START.y - cy) < 14) continue;
      if (chests.some(c => Math.abs(c.tx - cx) + Math.abs(c.ty - cy) < 8)) continue;
      if (shrines.some(s => Math.abs(s.tx - cx) + Math.abs(s.ty - cy) < 22)) continue;
      let best = null, bd = 1e9;
      for (const [px, py] of mainPath) { const d = Math.abs(px - cx) + Math.abs(py - cy); if (d < bd) { bd = d; best = [px, py]; } }
      if (!best || bd < 6 || bd > 18) continue;
      carve(best[0], best[1], cx, cy, false, r2);
      clearCircle(cx, cy, 8); // круг испытания (300 px) целиком на чистой поляне
      shrines.push({ tx: cx, ty: cy, x: tc(cx), y: tc(cy), state: 'idle', biome: biomeMap[cy * MW + cx], left: 0 });
    }
    // ---- главы Тессы: лежанки, лампы, улики, жители, полки, коробки ----
    const r3 = mulberry32(SEED + 177);
    const okSpot = (x, y) => !reserved(x,y) && canDress(x,y) && x > 4 && y > 4 && x < MW - 5 && y < MH - 5 && !(Math.abs(x - CASTLE.x) < h + 4 && Math.abs(y - CASTLE.y) < h + 4) &&
      Math.abs(x - START.x) + Math.abs(y - START.y) > 5 && !CFG.bossTiles.some(b => Math.abs(b.x - x) + Math.abs(b.y - y) < 5);
    const taken = [];
    const free = (x, y, d) => taken.every(o => Math.abs(o[0] - x) + Math.abs(o[1] - y) >= d);
    const placeNear = (p, dmin, dmax, sep = 3) => {
      for (let k = 0; k < 24; k++) {
        const a = r3() * TAU, d = dmin + r3() * (dmax - dmin), x = Math.round(p[0] + Math.cos(a) * d), y = Math.round(p[1] + Math.sin(a) * d);
        if (!okSpot(x, y) || !free(x, y, sep)) continue;
        carve(p[0], p[1], x, y, false, r3); clearCircle(x, y, 1);
        taken.push([x, y]); return [x, y];
      }
      return null;
    };
    const pathPoint = pred => { for (let i = 0; i < 600; i++) { const p = mainPath[Math.floor(r3() * mainPath.length)]; if (p && pred(p)) return p; } return null; };
    const fixedSite = ([tx,ty], state) => {
      taken.push([tx,ty]);
      treeGrid[ty*MW+tx] = 0;
      return {tx,ty,x:tc(tx),y:tc(ty),...state};
    };
    if (plan && plan.tunnel) shelves = plan.tunnel.map((p,i) => fixedSite(p,{to:1-i,cd:0,inside:false,tunnel:true}));
    if (plan && plan.holes) holes = plan.holes.map(p=>fixedSite(p,{cd:0,prog:0}));
    if (plan && plan.fires) fires = plan.fires.map(p => fixedSite(p,{lit:false,ph:r3()*6}));
    if (plan && plan.pearls) pearls = plan.pearls.map(p => fixedSite(p,{got:false,ph:r3()*6}));
    if (CFG.beds) {
      const got = [];
      for (let i = 0; i < 400 && got.length < CFG.beds; i++) {
        const p = pathPoint(q => got.every(o => Math.abs(o.tx - q[0]) + Math.abs(o.ty - q[1]) > 16));
        if (!p) break;
        const s = placeNear(p, 2, 3); if (s) got.push({ tx: s[0], ty: s[1], x: tc(s[0]), y: tc(s[1]), cd: 0, nap: 0 });
      }
      beds = got;
    }
    if (CFG.lamps) {
      for (let i = 0; i < 400 && lamps.length < CFG.lamps; i++) {
        const p = pathPoint(q => lamps.every(o => Math.abs(o.tx - q[0]) + Math.abs(o.ty - q[1]) > 10));
        if (!p) break;
        const s = placeNear(p, 1, 2, 2); if (s) lamps.push({ tx: s[0], ty: s[1], x: tc(s[0]), y: tc(s[1]), ph: r3() * 6 });
      }
    }
    if (CFG.detective) {
      for (let gi = 0; gi < 4; gi++) {
        const B = CFG.bossTiles[gi], bb = biomeMap[B.y * MW + B.x];
        for (let k = 0; k < 3; k++) {
          let p = pathPoint(q => biomeMap[q[1] * MW + q[0]] === bb && Math.hypot(q[0] - B.x, q[1] - B.y) > 6 && Math.hypot(q[0] - B.x, q[1] - B.y) < 26 && clues.every(o => Math.abs(o.tx - q[0]) + Math.abs(o.ty - q[1]) > 6));
          if (!p) p = pathPoint(q => Math.hypot(q[0] - B.x, q[1] - B.y) < 30 && Math.hypot(q[0] - B.x, q[1] - B.y) > 6);
          if (!p) { let bd = 1e9; for (const q of mainPath) { const d = Math.hypot(q[0] - B.x, q[1] - B.y); if (d >= 4 && d < bd) { bd = d; p = q; } } }
          if (!p) p = mainPath[0];
          const s = placeNear(p, 1, 3, 2) || p;
          clues.push({ i: gi, k, tx: s[0], ty: s[1], x: tc(s[0]), y: tc(s[1]), found: false });
        }
      }
      NPCS5.forEach((def, ni) => {
        const p = pathPoint(q => biomeMap[q[1] * MW + q[0]] === def.biome && Math.abs(q[0] - START.x) + Math.abs(q[1] - START.y) > 8) || pathPoint(() => true);
        const s = placeNear(p, 2, 3, 3) || p;
        npcs.push({ def, ni, tx: s[0], ty: s[1], x: tc(s[0]), y: tc(s[1]), state: 'new' });
        const q = pathPoint(q2 => { const d = Math.hypot(q2[0] - s[0], q2[1] - s[1]); return d > 16 && d < 45; }) || pathPoint(() => true);
        const it = placeNear(q, 2, 4, 3) || q;
        qitems.push({ ni, tx: it[0], ty: it[1], x: tc(it[0]), y: tc(it[1]), active: false, taken: false });
      });
    }
    if (CFG.shelves) {
      for (let i = 0; i < 2000 && shelves.length < CFG.shelves * 2; i++) {
        const a = Math.floor(r3() * mainPath.length), b = Math.floor(r3() * mainPath.length);
        const i1 = Math.min(a, b), i2 = Math.max(a, b), P1 = mainPath[i1], P2 = mainPath[i2];
        const d = Math.hypot(P1[0] - P2[0], P1[1] - P2[1]);
        if (i2 - i1 < 40 || i2 - i1 < d * 1.6 || d < 8 || d > 30) continue;
        if (!okSpot(P1[0], P1[1]) || !okSpot(P2[0], P2[1]) || !free(P1[0], P1[1], 6) || !free(P2[0], P2[1], 6)) continue;
        const A = placeNear(P1, 2, 3, 6), B2 = A && placeNear(P2, 2, 3, 6);
        if (!A || !B2) continue;
        const k = shelves.length;
        shelves.push({ tx: A[0], ty: A[1], x: tc(A[0]), y: tc(A[1]), to: k + 1, cd: 0, inside: false });
        shelves.push({ tx: B2[0], ty: B2[1], x: tc(B2[0]), y: tc(B2[1]), to: k, cd: 0, inside: false });
      }
    }
    if (CFG.boxes) {
      for (let i = 0; i < 500 && boxes.length < CFG.boxes; i++) {
        const p = pathPoint(q => boxes.every(o => Math.abs(o.tx - q[0]) + Math.abs(o.ty - q[1]) > 7));
        if (!p) break;
        const s = placeNear(p, 2, 4, 3); if (s) boxes.push({ tx: s[0], ty: s[1], x: tc(s[0]), y: tc(s[1]) });
      }
    }
    if (CFG.fires) {
      for (let i = 0; i < 600 && fires.length < CFG.fires; i++) {
        const p = pathPoint(q => Math.abs(q[0] - START.x) + Math.abs(q[1] - START.y) > 7 && fires.every(o => Math.abs(o.tx - q[0]) + Math.abs(o.ty - q[1]) > 18));
        if (!p) break;
        const s = placeNear(p, 2, 3, 3); if (s) fires.push({ tx: s[0], ty: s[1], x: tc(s[0]), y: tc(s[1]), lit: false, ph: r3() * 6 });
      }
    }
    const placeIn = (arr, n, bset, sep, dmin, dmax, mk) => {
      for (let i = 0; i < 900 && arr.length < n; i++) {
        const p = pathPoint(q => bset.includes(biomeMap[q[1] * MW + q[0]]) && arr.every(o => Math.abs(o.tx - q[0]) + Math.abs(o.ty - q[1]) > sep));
        if (!p) break;
        const s = placeNear(p, dmin, dmax, 3); if (s) arr.push(Object.assign({ tx: s[0], ty: s[1], x: tc(s[0]), y: tc(s[1]) }, mk()));
      }
    };
    if (CFG.holes) placeIn(holes, CFG.holes, [28], 10, 2, 4, () => ({ cd: 0, prog: 0 }));
    if (CFG.ovens) placeIn(ovens, CFG.ovens, [29], 14, 2, 3, () => ({ cd: 0, prog: 0, ph: r3() * 6 }));
    if (CFG.drifts) placeIn(drifts, CFG.drifts, [27, 28, 30, 31], 6, 2, 5, () => ({ hp: 3, done: false, s: 0.85 + r3() * 0.3 }));
    if (CFG.pearls && !pearls.length) { const bs = [...new Set(CFG.biomeSeeds.map(q => q[0]))].filter(b => b !== CFG.castle.biome); placeIn(pearls, CFG.pearls, bs, 20, 3, 7, () => ({ got: false, ph: r3() * 6 })); }
    // дорожки к объектам прокладываются после деревьев – убираем деревья вплотную к любой дорожке
    for (let ty = 1; ty < MH - 1; ty++) for (let tx = 1; tx < MW - 1; tx++) {
      const i = ty * MW + tx; if (!treeGrid[i]) continue;
      const pt = u => u === PATH || u === STONE;
      if (pt(tiles[i]) || pt(tiles[i - 1]) || pt(tiles[i + 1]) || pt(tiles[i - MW]) || pt(tiles[i + MW])) treeGrid[i] = 0;
    }
    // ---- сундуки: редкость и мимики ----
    if (chests.length) {
      const r5 = mulberry32(SEED + 313), dist0 = ch => Math.abs(ch.tx - START.x) + Math.abs(ch.ty - START.y);
      for (const ch of chests) { ch.tier = 'wood'; ch.mimic = false; ch.seen = false; }
      const far = chests.slice().sort((a, b) => dist0(b) - dist0(a)).slice(0, Math.max(2, Math.ceil(chests.length / 3)));
      for (let k = 0; k < (CHN === 1 ? 1 : 2) && far.length; k++) far.splice(Math.floor(r5() * far.length), 1)[0].tier = 'gold';
      for (const ch of chests) if (ch.tier !== 'gold') {
        if (r5() < 0.28) ch.tier = 'silver';
        if (r5() < 0.13 && dist0(ch) > 18) ch.mimic = true;
      }
    }
    // ---- глава 6: часть сундуков вмёрзла в ледяные стены ----
    const reachAll = () => {
        const seen = new Uint8Array(MW * MH), q = [START.y * MW + START.x]; seen[q[0]] = 1;
        for (let k = 0; k < q.length; k++) {
          const i = q[k], x = i % MW, y = (i - x) / MW;
          for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
            const nx = x + dx, ny = y + dy; if (!inMap(nx, ny)) continue;
            const j = ny * MW + nx; if (seen[j]) continue;
            const u = tiles[j]; if (u === ROCK || u === WALL || u === WATER || u === LAVA) continue;
            seen[j] = 1; q.push(j);
          }
        }
        const pts = [...shrines.map(o => [o.tx, o.ty]), ...guards.map(o => [o.x, o.y]), [GATE_FRONT.x, GATE_FRONT.y], ...fires.filter(o => !o.glade).map(o => [o.tx, o.ty]),
          ...chests.filter(o => !o.iced && !o.glade).map(o => [o.tx, o.ty]), ...holes.map(o => [o.tx, o.ty]), ...ovens.map(o => [o.tx, o.ty])];
        if (landscape) for (const group of [drifts,lamps,beds,shelves,pearls]) {
          for (const item of group) pts.push([item.tx,item.ty]);
        }
        return pts.every(([x, y]) => seen[y * MW + x]);
      };
    if (CFG.icedChests && chests.length) {
      const r7 = mulberry32(SEED + 521);
      for (const ch of chests) {
        ch.iced = false;
        if (ch.mimic || r7() >= CFG.icedChests) continue;
        const ring = [];
        let ok = true;
        for (let y = ch.ty - 2; y <= ch.ty + 2 && ok; y++) for (let x = ch.tx - 2; x <= ch.tx + 2; x++) {
          if (Math.max(Math.abs(x - ch.tx), Math.abs(y - ch.ty)) !== 2) continue;
          const i = y * MW + x;
          if (!inMap(x, y) || x < 3 || y < 3 || x >= MW - 3 || y >= MH - 3 || !BIOMES[biomeMap[i]].meltable || tiles[i] === WALL || tiles[i] === GATE || tiles[i] === FLOOR) { ok = false; break; }
          ring.push([i, tiles[i], treeGrid[i]]);
        }
        if (!ok) continue;
        for (const [i] of ring) { tiles[i] = ROCK; treeGrid[i] = 0; }
        ch.iced = true;
        if (!reachAll()) { for (const [i, u, tr] of ring) { tiles[i] = u; treeGrid[i] = tr; } ch.iced = false; }
      }
    }
    // ---- тайные поляны за ледяной стеной: сундук, костёр или снежный барс ----
    if (CFG.glades) {
      const r8 = mulberry32(SEED + 919), kinds = ['chest', 'beast', 'fire', 'chest'];
      const fixed = plan && plan.glades;
      for (let it = 0; it < (fixed ? fixed.length : 3000) && glades.length < CFG.glades; it++) {
        const [cx,cy] = fixed ? fixed[it] : [12 + Math.floor(r8() * (MW - 24)),12 + Math.floor(r8() * (MH - 24))];
        if (!canDress(cx,cy) || ![27, 28, 31].includes(biomeMap[cy * MW + cx])) continue;
        if (Math.abs(cx - CASTLE.x) < h + 10 && Math.abs(cy - CASTLE.y) < h + 10) continue;
        if (!fixed && Math.abs(cx - START.x) + Math.abs(cy - START.y) < 20) continue;
        if (!fixed && CFG.bossTiles.some(b => Math.hypot(b.x - cx, b.y - cy) < 16)) continue;
        if (!fixed && mainPath.some(([px, py]) => Math.abs(px - cx) + Math.abs(py - cy) < 9)) continue;
        const near = (arr, d) => arr.some(o => Math.hypot(o.tx - cx, o.ty - cy) < d);
        if (!fixed && (near(chests, 9) || near(shrines, 12) || near(fires, 8) || near(glades, 30) || near(holes, 8) || near(ovens, 8))) continue;
        const ring = [], inner = [];
        let ok = true;
        for (let y = cy - 6; y <= cy + 6 && ok; y++) for (let x = cx - 6; x <= cx + 6; x++) {
          const d = Math.hypot(x - cx, y - cy), i = y * MW + x;
          if (d > 5.6) continue;
          if (!canDress(x,y) || !BIOMES[biomeMap[i]].meltable || tiles[i] === WALL || tiles[i] === FLOOR || tiles[i] === GATE) { ok = false; break; }
          (d >= 4.5 ? ring : inner).push([i, tiles[i], treeGrid[i]]);
        }
        if (!ok) continue;
        for (const [i] of ring) { tiles[i] = ROCK; treeGrid[i] = 0; }
        for (const [i] of inner) { tiles[i] = biomeMap[i]; treeGrid[i] = 0; }
        if (!reachAll()) { for (const [i, u, tr] of ring.concat(inner)) { tiles[i] = u; treeGrid[i] = tr; } continue; }
        const g = { tx: cx, ty: cy, x: tc(cx), y: tc(cy), kind: kinds[glades.length % kinds.length], ring: ring.map(r => r[0]), open: false, done: false, seen: false };
        glades.push(g);
        if (g.kind === 'chest') chests.push({ tx: cx, ty: cy, x: tc(cx), y: tc(cy), open: false, biome: biomeMap[cy * MW + cx], tier: r8() < 0.5 ? 'gold' : 'silver', mimic: false, seen: false, glade: true, iced: false });
        else if (g.kind === 'fire') fires.push({ tx: cx, ty: cy, x: tc(cx), y: tc(cy), lit: false, ph: r8() * 6, glade: true });
      }
    }
    // ---- тайники: комната 3×3 внутри скального массива, вход закрыт треснувшей стеной ----
    if (typeof CHN === 'number') {
      const rs = mulberry32(SEED + 1337), want = 2 + (rs() < 0.5 ? 1 : 0);
      const solid = (x, y) => { const t = tiles[y * MW + x]; return t === ROCK || t === WALL; };
      const open = (x, y) => inMap(x, y) && !isSolidTile(x, y, false);
      for (let it = 0; it < 8000 && secrets.length < want; it++) {
        const cx = 5 + Math.floor(rs() * (MW - 10)), cy = 5 + Math.floor(rs() * (MH - 10));
        if (Math.abs(cx - CASTLE.x) < CASTLE.half + 4 && Math.abs(cy - CASTLE.y) < CASTLE.half + 4) continue;
        if (Math.abs(cx - START.x) < 8 && Math.abs(cy - START.y) < 8) continue;
        let ok = true;
        for (let y = cy - 2; y <= cy + 2 && ok; y++) for (let x = cx - 2; x <= cx + 2; x++) if (!solid(x, y)) { ok = false; break; }
        if (!ok || secrets.some(o => Math.abs(o.cx - cx) < 16 && Math.abs(o.cy - cy) < 16) || chests.some(o => Math.abs(o.tx - cx) < 5 && Math.abs(o.ty - cy) < 5)) continue;
        const sides = [[0, -1], [1, 0], [0, 1], [-1, 0]].filter(([dx, dy]) => open(cx + dx * 3, cy + dy * 3));
        if (!sides.length) continue;
        const [dx, dy] = sides[Math.floor(rs() * sides.length)];
        for (let y = cy - 1; y <= cy + 1; y++) for (let x = cx - 1; x <= cx + 1; x++) { const i = y * MW + x; tiles[i] = biomeMap[i]; treeGrid[i] = 0; }
        const ex = cx + dx * 2, ey = cy + dy * 2, ci = ey * MW + ex;
        cracks.add(ci);
        const ch = { tx: cx, ty: cy, x: tc(cx), y: tc(cy), open: false, biome: biomeMap[cy * MW + cx], tier: rs() < 0.35 ? 'gold' : 'silver', mimic: false, seen: false, secret: true, iced: false };
        chests.push(ch);
        secrets.push({ cx, cy, ex, ey, i: ci, open: false, chest: ch, hinted: false });
      }
    }
    if (CFG.rush || CFG.abyss) {
      // An oval duelling floor and a six-lobed abyss keep the centre open around the player.
      for (let y = 0; y < MH; y++) for (let x = 0; x < MW; x++) {
        const dx = (x-CASTLE.x)/(h-.5), dy = (y-CASTLE.y)/(h*(CFG.rush ? .81 : .92));
        const radius = CFG.rush ? 1 : .93+.065*Math.cos(6*Math.atan2(dy,dx));
        if (dx*dx+dy*dy > radius*radius) { tiles[y*MW+x]=WALL; treeGrid[y*MW+x]=0; }
      }
    }
    // ---- карманная арена испытаний: под картой, за полосой пустоты ----
    PLAY_H = MH;
    const GAP = 14, AS = 22, NH = MH + GAP + AS + 2;
    const nt = new Uint8Array(MW * NH), nbm = new Uint8Array(MW * NH), ngr = new Int32Array(MW * NH);
    nt.set(tiles); nbm.set(biomeMap); ngr.set(treeGrid);
    for (let y = MH; y < NH; y++) for (let x = 0; x < MW; x++) { nt[y * MW + x] = WALL; nbm[y * MW + x] = ARENA_BIOME; }
    const ax0 = Math.floor(MW / 2 - AS / 2), ay0 = MH + GAP, half = AS / 2 - 1;
    for (let y = ay0; y < ay0 + AS; y++) for (let x = ax0; x < ax0 + AS; x++) {
      const qx = (x - (ax0 + AS / 2 - 0.5)) / half, qy = (y - (ay0 + AS / 2 - 0.5)) / half;
      if (((revision === 0 || [1,4,6,7].includes(CHN)) ? qx ** 4 + qy ** 4 : qx*qx*.86 + qy*qy*1.12) <= 1) nt[y * MW + x] = FLOOR;
    }
    for (const [px, py] of [[-6, -6], [4, -6], [-6, 4], [4, 4]]) for (let dy = 0; dy < 2; dy++) for (let dx = 0; dx < 2; dx++) nt[(ay0 + AS / 2 + py + dy) * MW + ax0 + AS / 2 + px + dx] = WALL;
    tiles = nt; biomeMap = nbm; treeGrid = ngr; MH = NH; WORLD_H = MH * T;
    ARENA = { x: tc(ax0 + AS / 2), y: tc(ay0 + AS / 2), exit: { x: tc(ax0 + AS / 2), y: tc(ay0 + AS - 3) } };
    Terrain.rebuildMap();
  }

  function restoreBridge() {
    if (!landscape) return;
    const spans = landscape.plan.spans || (landscape.plan.crossings ? [[82,65,2]] : []);
    const opened = spans.filter(([x,y,guard]) => G.defeated[guard] && tiles[y*MW+x] !== STONE);
    if (!opened.length) return;
    if (landscape.plan.crossings) landscape.bridgeOpen = true;
    const mini = Terrain.miniBase.getContext('2d');
    mini.fillStyle = '#d4a367';
    for (const [cx,cy] of opened) for (let y=cy-1;y<=cy+1;y++) for (let x=cx-3;x<=cx+3;x++) {
      tiles[y*MW+x]=STONE;
      landscape.mask[y*MW+x]=Landscapes.BRIDGE;
      mini.fillRect(x,y,1,1);
    }
    Terrain.chunkCache.clear();
    Terrain.chunkJob=null;
    HUD.MM2.neon = null; HUD.MM2.sign = null;
  }

  function ensureWalkable(o) {
    if (Physics.walkable(o.x, o.y, false)) return;
    for (let r = 1; r < 40; r++) for (let a = 0; a < 16; a++) {
      const x = o.x + Math.cos(a / 16 * TAU) * r * T * 0.5, y = o.y + Math.sin(a / 16 * TAU) * r * T * 0.5;
      if (Physics.walkable(x, y, false)) { o.x = x; o.y = y; return; }
    }
  }

  return {
    T, PX_PER_M, tc, inMap, tileAt, isGround, isSolidTile, blocksShots, generateWorld,
    ensureWalkable, restoreBridge,
    get landscape() { return landscape; },
    get revision() { return landscape ? landscape.revision : 0; },
    get CHN() { return CHN; },
    get CFG() { return CFG; },
    get SEED() { return SEED; },
    get MW() { return MW; },
    get MH() { return MH; },
    get WORLD_W() { return WORLD_W; },
    get WORLD_H() { return WORLD_H; },
    get PLAY_H() { return PLAY_H; },
    get ARENA() { return ARENA; },
    get tiles() { return tiles; },
    get biomeMap() { return biomeMap; },
    get treeGrid() { return treeGrid; },
    get trees() { return trees; },
    get chests() { return chests; },
    get shrines() { return shrines; },
    get beds() { return beds; },
    get lamps() { return lamps; },
    get clues() { return clues; },
    get npcs() { return npcs; },
    get qitems() { return qitems; },
    get shelves() { return shelves; },
    get boxes() { return boxes; },
    get fires() { return fires; },
    get holes() { return holes; },
    get ovens() { return ovens; },
    get drifts() { return drifts; },
    get glades() { return glades; },
    get secrets() { return secrets; },
    get cracks() { return cracks; },
    get pearls() { return pearls; },
    get flow() { return flow; },
    get curPts() { return curPts; },
    get START() { return START; },
    set START(value) { START = value; },
    get CASTLE() { return CASTLE; },
    get GATE_FRONT() { return GATE_FRONT; },
    get CAGE() { return CAGE; },
    get gateOpen() { return gateOpen; },
    set gateOpen(value) { gateOpen = value; },
  };
})();
