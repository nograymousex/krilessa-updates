'use strict';

const StarArt = (() => {
  const ink = '#19203e', turquoise = '#81eddf', gold = '#ffd783';
  const groundSprites = [];
  const nodeTitles = ['Звезда 1/3', 'Звезда 2/3', 'Звезда 3/3'];
  let bloom;
  let collection = null;

  // Узкие грани розы ветров читаются и на каменном диске, и на мини-карте.
  const rose = new Path2D();
  const bright = new Path2D();
  for (let i = 0; i < 8; i++) {
    const angle = i * Math.PI / 4 - Math.PI / 2;
    const outer = i % 2 ? 0.53 : i % 4 ? 0.79 : 1;
    const x = Math.cos(angle) * outer, y = Math.sin(angle) * outer;
    const nx = Math.cos(angle + Math.PI / 8) * 0.23, ny = Math.sin(angle + Math.PI / 8) * 0.23;
    if (!i) rose.moveTo(x, y); else rose.lineTo(x, y);
    rose.lineTo(nx, ny);
    bright.moveTo(0, 0); bright.lineTo(x, y); bright.lineTo(nx, ny); bright.closePath();
  }
  rose.closePath();

  function roseAt(c, x, y, radius, face, glint) {
    c.save();
    c.translate(x, y); c.scale(radius, radius);
    c.fillStyle = face; c.fill(rose);
    c.fillStyle = glint; c.fill(bright);
    c.restore();
  }

  function circle(c, x, y, radius) {
    c.beginPath(); c.arc(x, y, radius, 0, TAU);
  }

  function halo(c, x, y, w, h, alpha) {
    if (!bloom) {
      bloom = makeCanvas(128, 128);
      const b = bloom.getContext('2d');
      const g = b.createRadialGradient(64, 64, 0, 64, 64, 64);
      g.addColorStop(0, '#ebfffa'); g.addColorStop(0.13, '#b4fff0');
      g.addColorStop(0.34, 'rgba(85,228,214,.58)');
      g.addColorStop(0.68, 'rgba(94,102,220,.26)'); g.addColorStop(1, 'rgba(80,74,200,0)');
      b.fillStyle = g; b.fillRect(0, 0, 128, 128);
    }
    c.save(); c.globalAlpha *= alpha;
    c.drawImage(bloom, x - w / 2, y - h / 2, w, h); c.restore();
  }

  // Латунное кольцо, градусы и насечки запекаем один раз для каждого состояния.
  function groundSprite(state) {
    if (groundSprites[state]) return groundSprites[state];
    const cv = makeCanvas(200, 156), c = cv.getContext('2d');
    c.translate(100, 81); c.scale(2, 1.02);
    halo(c, 0, 0, 100, 110, state === 1 ? 0.86 : 0.36);
    c.fillStyle = 'rgba(16,17,33,.43)'; circle(c, 0, 5, 31); c.fill();
    c.fillStyle = '#59445a'; circle(c, 0, 2.3, 30); c.fill();
    const enamel = c.createLinearGradient(-16, -23, 18, 24);
    enamel.addColorStop(0, '#4a5678'); enamel.addColorStop(0.45, '#283657'); enamel.addColorStop(1, '#181f39');
    c.fillStyle = enamel; circle(c, 0, 0, 29.5); c.fill();
    c.strokeStyle = state === 0 ? '#818da4' : gold; c.lineWidth = 1.4; c.stroke();
    circle(c, 0, 0, 25); c.lineWidth = 0.7; c.stroke();
    c.strokeStyle = state === 0 ? '#82969b' : '#a8e6db';
    for (let i = 0; i < 24; i++) {
      const a = i * TAU / 24, r = i % 3 === 0 ? 22 : 24;
      c.beginPath(); c.moveTo(Math.cos(a) * r, Math.sin(a) * r);
      c.lineTo(Math.cos(a) * 27.5, Math.sin(a) * 27.5); c.stroke();
    }
    roseAt(c, 0, 0, 19, state === 2 ? '#d9a052' : '#536683', state === 2 ? gold : '#7e99aa');
    groundSprites[state] = cv;
    return cv;
  }

  function ground(c, trail, vis) {
    for (let i = 0; i < trail.stars.length; i++) {
      const node = trail.stars[i];
      if (!vis(node.x, node.y, 120)) continue;
      const state = i < trail.collected ? 2 : i === trail.collected ? 1 : 0;
      c.drawImage(groundSprite(state), node.x - 50, node.y - 40.5, 100, 78);
    }
  }

  function beacons(c, trail, vis, time) {
    for (let i = 0; i < trail.stars.length; i++) {
      const node = trail.stars[i], x = node.x, y = node.y;
      if (!vis(x, y, 110)) continue;
      const active = i === trail.collected, done = i < trail.collected;
      const t = time + i * 2.1, bob = Math.sin(t * 2.5);
      const cy = y - (active ? 32 + bob * 3 : done ? 10 : 16 + bob);
      c.save();
      if (active) {
        halo(c, x, y - 28, 152, 135, 0.58 + bob * 0.09);
        c.strokeStyle = 'rgba(167,253,240,.64)'; c.lineWidth = 1.1;
        c.beginPath(); c.ellipse(x, cy, 22, 7.5, -0.45, 0, TAU); c.stroke();
        c.beginPath(); c.ellipse(x, cy, 18, 12, 0.7, 0.15, Math.PI * 1.08); c.stroke();
        for (let j = 0; j < 5; j++) {
          const ph = (t * 0.47 + j / 5) % 1;
          const sx = x + Math.cos(t * 1.1 + j * 2.4) * (7 + ph * 8);
          c.globalAlpha = Math.sin(ph * Math.PI) * 0.85;
          roseAt(c, sx, y - 9 - ph * 53, 2.3, turquoise, '#ffffe9');
        }
      }
      c.globalAlpha = done ? 0.82 : 1;
      const size = active ? 19.5 : done ? 7 : 11;
      roseAt(c, x, cy, size + 1.8, ink, ink);
      roseAt(c, x, cy, size, active || done ? '#e9a443' : '#637992', active || done ? '#fff3ba' : '#b0cfcb');
      if (active) {
        const a = t * 1.7;
        roseAt(c, x + Math.cos(a) * 19, cy + Math.sin(a) * 8 - Math.cos(a) * 7, 3.5, turquoise, '#fffbd7');
        if (!G.activeBoss && vis(x, cy, -12)) {
          const halfView = Viewport.VW / Viewport.ZOOM / 2;
          const side = x < P.x ? -1 : 1;
          const labelX = clamp(x + side * 53, G.cam.x - halfView + 36, G.cam.x + halfView - 36);
          c.fillStyle = 'rgba(25,32,62,.92)';
          roundRect(c, labelX - 32, cy + 1, 64, 14, 7); c.fill();
          c.fillStyle = '#fff1cb'; c.font = 'bold 10px Krilessa Icons, sans-serif';
          c.textAlign = 'center'; c.textBaseline = 'middle';
          c.fillText(nodeTitles[i], labelX, cy + 8);
        }
      }
      c.restore();
    }
    if (collection && collection.trail === trail) drawFlash(c, collection, time);
  }

  // Светлые плюсы поднимаются вместе с героиней после последней звезды.
  const healingCross = new Path2D('M-2 -6H2V-2H6V2H2V6H-2V2H-6V-2H-2Z');

  function drawHealing(c, t) {
    for (let i = 0; i < 3; i++) {
      const phase = (t - i * 0.12) / 0.75;
      if (phase < 0 || phase > 1) continue;
      const side = i - 1;
      c.save();
      c.translate(P.x + side * (13 + 7 * phase), P.y - (P.z || 0) - 24 - phase * 34 - (1 - Math.abs(side)) * 7);
      const scale = (i === 1 ? 1.3 : 0.85) * (0.8 + phase * 0.4);
      c.scale(scale, scale);
      c.globalAlpha *= Math.min(1, phase * 8, (1 - phase) * 4);
      c.lineJoin = 'round'; c.lineWidth = 2.4; c.strokeStyle = '#204d53'; c.stroke(healingCross);
      c.fillStyle = '#a8ffda'; c.fill(healingCross);
      c.restore();
    }
  }

  function drawFlash(c, flash, time) {
    const t = (time - flash.at) / (flash.complete ? 1.32 : 0.98);
    if (t >= 1) {
      collection = null;
      return;
    }
    if (t < 0) return;
    c.save();
    const r = 12 + Math.sqrt(t) * (flash.complete ? 46 : 35);
    const x = flash.x, y = flash.y - 17;
    c.globalAlpha = (1 - t) * 0.88;
    halo(c, x, y, r * 2.8, r * 2.7, (1 - t) * 0.7);
    c.strokeStyle = gold; c.lineWidth = 2.1 * (1 - t) + 0.5;
    for (let i = 0; i < 8; i++) {
      const a = i * TAU / 8 + 0.2 + t * 0.23;
      c.beginPath(); c.arc(x, y, r, a, a + (1 - t) * 0.43); c.stroke();
      roseAt(c, x + Math.cos(a) * (r + t * 10), y + Math.sin(a) * (r + t * 10),
        4.5 * (1 - t) + 1, gold, '#fffbe6');
    }
    c.restore();
    if (flash.complete && !G.hidden) drawHealing(c, t);
  }

  function collected(x, y) {
    const trail = StarTrail.view();
    if (trail) collection = { trail, x, y, at: G.time, complete: trail.collected === trail.stars.length };
  }
  return { ground, beacons, collected };
})();
