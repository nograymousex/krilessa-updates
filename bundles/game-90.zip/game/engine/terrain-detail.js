'use strict';

// Ground accents are baked once, at the same scale as the actors and props.
const TerrainDetail = (() => {
  const silhouettes = new Map();
  const cliffs = {
    1: ['#849278', '#4f6053', '#374942'],
    2: ['#c7966c', '#7e5346', '#43363c'],
    3: ['#adbad7', '#6a7293', '#3a455e'],
    4: ['#9b866e', '#534740', '#312f37'],
    5: ['#a8aa82', '#676c55', '#3f4b45'],
    6: ['#c2dae1', '#7a92a2', '#40536b'],
    7: ['#8bb1ab', '#4b777d', '#304e62'],
  };
  function treeShadow(c, tr, bx, by) {
    const sprite = TREE_SPR[tr.kind];
    if (!sprite) return;
    if (!silhouettes.has(tr.kind)) {
      const pic = makeCanvas(66, 86),
        p = pic.getContext('2d');
      p.drawImage(sprite, 0, 0, 66, 86);
      p.globalCompositeOperation = 'source-in';
      const ink = p.createLinearGradient(0, 0, 0, 86);
      ink.addColorStop(0, '#1723229c');
      ink.addColorStop(1, '#172322e0');
      p.fillStyle = ink;
      p.fillRect(0, 0, 66, 86);
      silhouettes.set(tr.kind, pic);
    }
    const w = 64 * tr.s,
      h = 84 * tr.s;
    c.save();
    c.translate(tr.x - bx * World.T, tr.y - by * World.T);
    if (tr.kind === 'blossom') {
      // Fallen petals sit slightly downwind of the crown. Keep nearby paths readable.
      const seed = Math.floor(tr.x * 7 + tr.y * 13);
      for (let j = 0; j < 8; j++) {
        const a = seed + j * 2.4, r = 10 + j * 3;
        c.fillStyle = j % 3 ? '#efbbbd' : '#bd8c96';
        c.beginPath();
        c.ellipse(6 + Math.cos(a) * r, 1 + Math.sin(a) * r * 0.46, 2.1, 0.95, a, 0, TAU);
        c.fill();
      }
    }
    c.transform(0.94, 0.06, -0.6, -0.38, 0, 0);
    c.globalAlpha = 0.26;
    c.drawImage(silhouettes.get(tr.kind), -w / 2, -h + 4 * tr.s, w, h);
    c.restore();
  }
  // Round the visible lip inside the collision cell. Four neighbouring chunks draw the same corner.
  function shoreline(c,tx,ty,x,y,T,maskAt,tones) {
    const N=!maskAt(tx,ty-1), E=!maskAt(tx+1,ty), S=!maskAt(tx,ty+1), W=!maskAt(tx-1,ty);
    if (!(N || E || S || W)) return;
    const radius=12, outside=LandscapeArt.voids[World.CHN][0];
    c.save(); c.translate(x,y); c.lineCap='round';
    const corners=[
      [N&&W,0,0,1,1], [N&&E,T,0,-1,1], [S&&E,T,T,-1,-1], [S&&W,0,T,1,-1]
    ];
    for(const [round,cx,cy,sx,sy] of corners) {
      if (!round) continue;
      const ex=cx+sx*radius, ey=cy+sy*radius;
      c.fillStyle=outside;
      c.beginPath(); c.moveTo(cx,cy); c.lineTo(ex,cy); c.quadraticCurveTo(cx,cy,cx,ey); c.closePath(); c.fill();
      c.strokeStyle=tones[0]; c.lineWidth=2;
      c.beginPath(); c.moveTo(ex,cy); c.quadraticCurveTo(cx,cy,cx,ey); c.stroke();
    }
    const edges=[
      [N,W?radius:0,0,T-(E?radius:0),0],
      [E,T,N?radius:0,T,T-(S?radius:0)],
      [S,W?radius:0,T,T-(E?radius:0),T],
      [W,0,N?radius:0,0,T-(S?radius:0)]
    ];
    for(const [visible,x1,y1,x2,y2] of edges){
      if(!visible) continue;
      c.strokeStyle=tones[0]; c.lineWidth=2;
      c.beginPath(); c.moveTo(x1,y1); c.lineTo(x2,y2); c.stroke();
    }
    if(S){
      const left=W?radius:0, right=T-(E?radius:0), depth=5+2*Math.sin(tx*.7);
      c.fillStyle=tones[1]; c.beginPath(); c.moveTo(left,T+1); c.lineTo(right,T+1);
      c.lineTo(right,T+depth); c.quadraticCurveTo(T*.45,T+depth+2,left,T+4); c.fill();
    }
    c.restore();
  }
  function chunk(c, bx, by, size) {
    const T=World.T, layout=World.landscape;
    const tones=cliffs[World.CHN] || cliffs[2];
    const maskAt=(x,y)=>x>=0 && y>=0 && x<World.MW && y<World.PLAY_H && layout.mask[y*World.MW+x]!==Landscapes.OUT;
    for(let ty=Math.max(0,by-2);ty<Math.min(by+size+2,World.PLAY_H);ty++){
      for(let tx=Math.max(0,bx-3);tx<Math.min(bx+size+2,World.MW);tx++){
        const cell=ty*World.MW+tx, x=(tx-bx)*T, y=(ty-by)*T, tile=World.tiles[cell];
        if(layout && World.CHN!==4 && maskAt(tx,ty)) shoreline(c,tx,ty,x,y,T,maskAt,tones);
        const north=World.tileAt(tx,ty-1);
        if((World.isGround(tile) || tile===PATH || tile===FLOOR) && (north===ROCK || north===WALL)){
          const shade=c.createLinearGradient(0,y,0,y+10);
          shade.addColorStop(0,'#101b243a'); shade.addColorStop(1,'#101b2400');
          c.fillStyle=shade; c.fillRect(x,y,T,10);
        }
        const i=World.treeGrid[cell];
        if(i) treeShadow(c,World.trees[i-1],bx,by);
      }
    }
  }
  return {chunk};
})();
