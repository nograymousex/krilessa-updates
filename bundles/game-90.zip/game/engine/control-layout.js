'use strict';

const ControlLayout = (() => {
  const actions = [
    ['dash', 'dashBtn', 'jeDash'],
    ['super', 'superBtn', 'jeSuper'],
    ['pause', 'pauseBtn', 'jePause'],
  ];
  const orientation = () => (innerWidth > innerHeight ? 'landscape' : 'portrait');
  let loaded = '',
    positions = {};
  function bounded(value, min, max) {
    return clamp(value, min, Math.max(min, max));
  }
  function place(el, point, width, height) {
    if (!point) {
      for (const p of ['left', 'top', 'bottom', 'right']) el.style.removeProperty(p);
      return;
    }
    const probe = getComputedStyle(document.documentElement);
    const inset = (k) => parseFloat(probe.getPropertyValue('--inset-' + k)) || 0;
    const x = bounded(
      point.x * innerWidth - width / 2,
      4 + inset('left'),
      innerWidth - width - 4 - inset('right'),
    );
    const y = bounded(
      point.y * innerHeight - height / 2,
      4 + Viewport.SAFE_TOP,
      innerHeight - height - 4 - inset('bottom'),
    );
    Object.assign(el.style, { left: x + 'px', top: y + 'px', right: 'auto', bottom: 'auto' });
  }
  function paint() {
    for (const [name, id, editor] of actions) {
      const button = $(id),
        ghost = $(editor),
        point = positions[name],
        style = getComputedStyle(button);
      const width = parseFloat(style.width) || 60,
        height = parseFloat(style.height) || 60;
      place(button, point, width, height);
      place(ghost, point, width, height);
    }
  }
  function read(settings) {
    loaded = orientation();
    const layout = (settings.touchLayouts || {})[loaded] || {};
    positions = { ...(layout.buttons || {}) };
    Controls.applyJoy(layout.joy || settings.joy);
    paint();
  }
  function save() {
    const p = Saves.loadProfile(),
      s = p.settings || (p.settings = {});
    const layouts = s.touchLayouts || (s.touchLayouts = {});
    layouts[loaded || orientation()] = { buttons: { ...positions }, joy: { ...Controls.JOY } };
    return Saves.saveProfile(p);
  }
  function reset() {
    positions = {};
    Controls.applyJoy({ fixed: Controls.JOY.fixed });
    paint();
    save();
  }
  for (const [name, id, editor] of actions) {
    const el = $(editor);
    let drag = null;
    el.addEventListener('pointerdown', (e) => {
      const b = el.getBoundingClientRect();
      drag = {
        id: e.pointerId,
        dx: e.clientX - b.left - b.width / 2,
        dy: e.clientY - b.top - b.height / 2,
      };
      el.setPointerCapture(e.pointerId);
      e.preventDefault();
    });
    el.addEventListener('pointermove', (e) => {
      if (!drag || drag.id !== e.pointerId) return;
      positions[name] = {
        x: clamp((e.clientX - drag.dx) / innerWidth, 0, 1),
        y: clamp((e.clientY - drag.dy) / innerHeight, 0, 1),
      };
      paint();
    });
    const end = (e) => {
      if (drag && drag.id === e.pointerId) {
        drag = null;
        save();
      }
    };
    el.addEventListener('pointerup', end);
    el.addEventListener('pointercancel', end);
  }
  window.addEventListener('resize', () => {
    if (orientation() !== loaded) read(Saves.loadProfile().settings || {});
    else paint();
    if (Session.state === 'joyedit') MenuActions.joyEditPaint();
  });
  return { read, paint, save, reset, orientation };
})();
