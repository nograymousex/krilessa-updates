'use strict';

const KrillFactory = (() => {
  // ---------- 1.0.14: тайная фабрика Крилей ----------
  function tdFacIn(F, x, y, tunnel) { return (x >= F.rx0 && x <= F.rx1 && y >= F.ry0 - 6 && y <= F.ry1 + 6) || (!!tunnel && x >= F.tx0 - 24 && x <= F.tx1 + 24 && y >= F.ty0 && y <= F.ty1); }
  function tdFacBan() { Multiplayer.netBan('🏭 Тайная фабрика Крилей!', 'Стой в цеху – станок чеканит монетки. Найми крилек – будут работать и без тебя'); Sound.sfx.event(); Challenges.buzz(60); }
  function tdFacTick(dt) {
    const F = G.td && G.td.fac, A = G.abyss; if (!F) return;
    const hs = []; if (!P.down) hs.push(P); if (NET.host) for (const m of NET.peers.values()) if (m.live && !m.down) hs.push(m);
    if (!F.found && hs.some(h => tdFacIn(F, h.x, h.y, true) && h.y > F.fy - 10)) { F.found = true; tdFacBan(); }
    if (!F.found) return;
    const n = hs.filter(h => tdFacIn(F, h.x, h.y)).length, base = TD_FAC.rate[F.lvl - 1], cap = TD_FAC.cap[F.lvl - 1];
    F.work = n;
    F.crate = Math.min(cap, F.crate + ((n ? base * (1 + TD_FAC.team * (n - 1)) : 0) + F.workers * TD_FAC.worker * base) * dt);
    if (n && F.crate >= 1) { const k = Math.floor(F.crate); F.crate -= k; A.coins += k; F.made += k; F.gain += k; } // кто в цеху – сразу забирает
    F.puff -= dt; if (F.gain && F.puff <= 0) { F.puff = 1.5; Effects.floatText(F.cx, F.cy - 58, `+${F.gain} 🪙`, '#ffd25a'); F.gain = 0; }
    if (F.thT > 0) { F.thT -= dt; if (F.thT <= 0) { for (let i = 0; i < F.thN; i++) tdThiefSpawn(F, i); Multiplayer.netBan('🐀 Воришки на фабрике!', 'Беги вниз – утащат монетки из ящика и из общей копилки'); Sound.sfx.whisper(); Challenges.buzz(80); } }
    F.th = F.th.filter(e => { if (!e.dead) return true; if (e.loot > 0 && !e.gone) { A.coins += e.loot; Effects.floatText(e.x, e.y - 24, `+${e.loot} 🪙 отбили!`, '#9dffc0', true); } return false; });
  }
  function tdThiefSpawn(F, i) {
    const A = G.abyss, e = Enemies.spawnEnemy('rat', F.hx, F.hy + (i - (F.thN - 1) / 2) * 24, G.td.M.biome, { E: A.E, sc: Defense.tdScale(A.E), instant: true });
    e.thief = true; e.hp = e.maxHp = e.maxHp * 2.2; e.tspd = 80; e.loot = 0; e.mode = 'go'; e.name = 'Крыска-воришка'; F.th.push(e);
    Effects.burst(e.x, e.y, 16, '#8a8a8a', 140);
  }
  function tdThiefTick(e, dt) {
    const F = G.td.fac, A = G.abyss;
    if (e.flash > 0) e.flash -= dt;
    if (e.stunT > 0) { e.stunT -= dt; return true; }
    if (e.slowT > 0) e.slowT -= dt;
    const tx = e.mode === 'go' ? F.cx + 36 : F.hx, ty = e.mode === 'go' ? F.cy + 6 : F.hy, dx = tx - e.x, dy = ty - e.y, d = Math.hypot(dx, dy);
    if (d < 12) {
      if (e.mode === 'go') {
        const box = Math.floor(F.crate), purse = Math.max(0, Math.min(Math.floor(A.coins * 0.08), 60 + A.wave * 3));
        F.crate -= box; A.coins -= purse; e.loot = box + purse; e.mode = 'run';
        if (e.loot) { Effects.floatText(e.x, e.y - 26, `−${e.loot} 🪙 утащили!`, '#ff6a6a', true); Sound.sfx.whisper(); }
      } else { e.gone = true; if (e.loot) Effects.floatText(e.x, e.y - 26, `Воришка сбежал с ${e.loot} 🪙`, '#ff8a6a', true); Enemies.killEnemy(e, true); }
      return true;
    }
    const sp = (e.tspd || 80) * (e.slowT > 0 ? 0.55 : 1) * (e.mode === 'run' ? 0.85 : 1);
    e.x += dx / d * sp * dt; e.y += dy / d * sp * dt; e.face = dx > 0 ? 1 : -1;
    return true;
  }
  function tdFacDo(kind) {
    const F = G.td.fac, A = G.abyss; if (!F || !F.found) return false;
    if (kind === 'up') {
      if (F.lvl >= TD_FAC.rate.length) return false; const cost = TD_FAC.up[F.lvl]; if (A.coins < cost) return false;
      A.coins -= cost; F.lvl++; Effects.burst(F.mx, F.my - 10, 26, '#ffd25a', 200); Effects.floatText(F.mx, F.my - 70, `⚙️ Станок ур. ${F.lvl}!`, '#ffd25a', true); Sound.sfx.magic(); return true;
    }
    if (kind === 'hire') {
      if (F.workers >= TD_FAC.hire.length) return false; const cost = TD_FAC.hire[F.workers]; if (A.coins < cost) return false;
      A.coins -= cost; F.workers++; Effects.burst(F.cx, F.cy, 18, '#ff9a6a', 160); Effects.floatText(F.cx, F.cy - 70, '🦐 Новая крилька в цеху!', '#ffb08a', true); Sound.sfx.magic(); return true;
    }
    return false;
  }

  return { tdFacIn, tdFacBan, tdFacTick, tdThiefTick, tdFacDo };
})();
