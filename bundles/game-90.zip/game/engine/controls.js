'use strict';

const Controls = (() => {
  // ------------------------------------------------------------------
  //  Управление
  // ------------------------------------------------------------------
  let JOY_R = 55;
  // джойстик: плавающий (появляется под пальцем) или закреплённый на своём месте; размер – 0,8 / 1 / 1,25
  const JOY = { fixed: false, x: 0.25, y: 0.8, k: 1 };
  function applyJoy(js) { Object.assign(JOY, { fixed: false, x: 0.25, y: 0.8, k: 1 }, js || {}); JOY_R = 55 * JOY.k; }
  const joyBase = () => [clamp(JOY.x, 0, 1) * Viewport.VW, clamp(JOY.y, 0, 1) * Viewport.VH];
  const input = { mx: 0, my: 0, touchId: null, bx: 0, by: 0, keys: {} };
  Viewport.canvas.addEventListener('pointerdown', e => {
    Sound.init();
    if (Session.state === 'play' && G.miniRect) {
      const R = G.miniRect, m = MMP.ptrs.size ? 50 : 6; // второй палец может лечь чуть мимо
      if (e.clientX >= R.x - m && e.clientX <= R.x + R.s + m && e.clientY >= R.y - m && e.clientY <= R.y + R.s + m) {
        MMP.ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY });
        try { Viewport.canvas.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
        if (MMP.ptrs.size === 2) { const [a, b] = [...MMP.ptrs.values()]; MMP.pinch = { d: Math.hypot(a.x - b.x, a.y - b.y) || 1, s: R.s }; MMP.used = true; }
        else if (MMP.ptrs.size === 1) { MMP.used = false; MMP.t0 = performance.now(); }
        return;
      }
    }
    if (Session.state !== 'play' || input.touchId !== null) return;
    if (JOY.fixed) { // закреплённый: слушается только касаний рядом с собой
      const [bx, by] = joyBase();
      if (Math.hypot(e.clientX - bx, e.clientY - by) > JOY_R * 2.4) return;
      input.touchId = e.pointerId; input.bx = bx; input.by = by; joyMove(e.clientX, e.clientY);
    } else { input.touchId = e.pointerId; input.bx = e.clientX; input.by = e.clientY; input.mx = 0; input.my = 0; }
    try { Viewport.canvas.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
  });
  function joyMove(x, y) {
    let dx = x - input.bx, dy = y - input.by;
    const d = Math.hypot(dx, dy);
    if (d > JOY_R) {
      if (JOY.fixed) { dx = dx / d * JOY_R; dy = dy / d * JOY_R; } // закреплённый стоит на месте
      else { input.bx += (dx / d) * (d - JOY_R); input.by += (dy / d) * (d - JOY_R); dx = x - input.bx; dy = y - input.by; }
    }
    input.mx = dx / JOY_R; input.my = dy / JOY_R;
  }
  Viewport.canvas.addEventListener('pointermove', e => {
    if (MMP.ptrs.has(e.pointerId)) { // щипок по мини-карте
      MMP.ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (MMP.pinch && MMP.ptrs.size >= 2 && !G.activeBoss) { // пальцы врозь – окно растёт в сторону игры, вместе – меньше
        const [a, b] = [...MMP.ptrs.values()], base = HUD.MM2.msBase || 124;
        HUD.MM2.sizeF = clamp(MMP.pinch.s * (Math.hypot(a.x - b.x, a.y - b.y) || 1) / MMP.pinch.d, base * 0.8, HUD.MM2.msMax || base * 2.5) / Viewport.VW;
      }
      return;
    }
    if (e.pointerId === input.touchId) joyMove(e.clientX, e.clientY);
  });
  // мини-карта: короткий тап одним пальцем – большая карта, щипок двумя – ближе/дальше
  const MMP = { ptrs: new Map(), pinch: null, used: false, t0: 0 };
  function miniUp(e) {
    if (!MMP.ptrs.has(e.pointerId)) return false;
    MMP.ptrs.delete(e.pointerId);
    if (MMP.pinch && MMP.ptrs.size < 2) { MMP.pinch = null; HUD.MM2.relaxAt = performance.now() + 2500; } // подержим 2,5 с – и обратно
    if (!MMP.ptrs.size && !MMP.used && performance.now() - MMP.t0 < 600 && Session.state === 'play') ChapterMap.openMap();
    return true;
  }
  const endTouch = e => { if (miniUp(e)) return; if (e.pointerId === input.touchId) { input.touchId = null; input.mx = 0; input.my = 0; } };
  Viewport.canvas.addEventListener('pointerup', endTouch);
  Viewport.canvas.addEventListener('pointercancel', endTouch);
  $('dashBtn').addEventListener('pointerdown', e => { e.preventDefault(); e.stopPropagation(); Hero.tryDash(); });
  $('superBtn').addEventListener('pointerdown', e => { e.preventDefault(); e.stopPropagation(); Hero.trySuper(); });
  $('swapBtn').addEventListener('pointerdown', e => { e.preventDefault(); e.stopPropagation(); Expedition.switchHero(); });
  $('tdRing').addEventListener('pointerdown', e => { const b = e.target.closest('button'); if (!b) return; e.preventDefault(); e.stopPropagation(); Defense.tdPanelTap(b); });
  for (const b of $('tdSpells').children) b.addEventListener('pointerdown', e => { e.preventDefault(); e.stopPropagation(); Defense.tdSpellBtn(b.dataset.s); });
  $('tdFac').addEventListener('pointerdown', e => {
    const b = e.target.closest('button[data-f]'); if (!b) return; e.preventDefault(); e.stopPropagation();
    if (b.classList.contains('no')) { RunStats.toast(/максимум|на месте/.test(b.textContent) ? 'Больше некуда – всё уже есть 🏭' : 'Не хватает монеток 🪙'); return; }
    if (Defense.tdAct('f', b.dataset.f)) { Sound.sfx.click(); $('tdFac')._k = ''; }
  });
  $('defSkip').addEventListener('pointerdown', e => { e.preventDefault(); e.stopPropagation(); if (Defense.tdAct('c')) Sound.sfx.click(); });
  { // оборона: короткий тап по площадке выбирает её, даже если героиня далеко
    let tp = null;
    Viewport.canvas.addEventListener('pointerdown', e => { tp = G.td && Session.state === 'play' ? { id: e.pointerId, x: e.clientX, y: e.clientY, t: performance.now() } : null; });
    Viewport.canvas.addEventListener('pointerup', e => { if (tp && tp.id === e.pointerId && performance.now() - tp.t < 320 && Math.hypot(e.clientX - tp.x, e.clientY - tp.y) < 12) Defense.tdTap(e.clientX, e.clientY); tp = null; });
  }
  $('pauseBtn').addEventListener('click', () => Screens.pauseGame(true));
  $('talkTap').addEventListener('pointerdown', e => { e.preventDefault(); Sound.init(); Screens.Dialog.advance(); });
  window.addEventListener('keydown', e => {
    if (e.target && e.target.tagName === 'INPUT') return; // ввод пароля – не управление
    if (Session.state === 'play' && Screens.Dialog.talking && (e.code === 'Space' || e.code === 'Enter')) { Screens.Dialog.advance(); return; }
    input.keys[e.code] = true;
    if (e.code === 'Space' || e.code === 'ShiftLeft') Hero.tryDash();
    if (e.code === 'KeyE' || e.code === 'KeyQ') Hero.trySuper();
    if (e.code === 'KeyR' || e.code === 'Tab') { e.preventDefault(); Expedition.switchHero(); }
    if (e.code === 'Escape') { if (Session.state === 'play') Screens.pauseGame(); else if (Session.state === 'pause') Screens.resumeGame(); }
    if (GameLoop.DEBUG) GameLoop.debugKey(e.code);
  });
  window.addEventListener('keyup', e => { input.keys[e.code] = false; });
  function pollKeys() {
    if (input.touchId !== null) return;
    const k = input.keys;
    const x = (k.KeyD || k.ArrowRight ? 1 : 0) - (k.KeyA || k.ArrowLeft ? 1 : 0);
    const y = (k.KeyS || k.ArrowDown ? 1 : 0) - (k.KeyW || k.ArrowUp ? 1 : 0);
    const m = Math.hypot(x, y) || 1;
    input.mx = x / m; input.my = y / m;
  }

  return {
    JOY, applyJoy, joyBase, input, MMP, pollKeys,
    get JOY_R() { return JOY_R; },
    set JOY_R(value) { JOY_R = value; },
  };
})();
