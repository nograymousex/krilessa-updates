'use strict';

const HomeScreen = (() => {
  // ---------- Домик героинь ----------
  const furnOwned = (it, pr) => !!(it.def || pr.admin || (pr.furn || {})[it.id]);
  function petOwned(pet, pr) {
    if (pr.admin) return true;
    const [t, v] = pet.src.split(':');
    if (t === 'w') return pr.ch4Choice === v || !!(pr.ch4Seen || {})[v];
    if (t === 'ch') return !!pr['ch' + v + 'Done'];
    return !!(pr.ach || {})[v];
  }
  function petHow(pet) {
    const [t, v] = pet.src.split(':');
    if (t === 'w') return 'Живёт у той, кто выбрала добрую концовку';
    if (t === 'ch') return `Пройди главу ${v}`;
    if (v.startsWith('ss_')) return `Сезон «${SEASON_THEMES[+v.split('_')[1]].nm}» – 15-й уровень дороги сезона`;
    const a = Achievements.ACH_BY[v]; return a ? (a.secret ? 'Награда за секретное достижение 🤫' : `Достижение «${a.nm}»`) : 'Скоро';
  }
  function homeState(pr) {
    const H = pr.home = pr.home || {};
    H.wall = H.wall || 'stripes'; H.floor = H.floor || 'wood';
    H.slots = H.slots || { wallL: 'pic', wallR: '', sill: 'teddy', lamp: 'bulb', plant: 'potplant', floorL: 'sofa', center: 'yarn', floorR: '' };
    if (!H.pets) H.pets = PETS.filter(p => petOwned(p, pr)).slice(0, 1).map(p => p.id);
    H.pets = H.pets.filter(id => PET_BY[id] && petOwned(PET_BY[id], pr)).slice(0, HOME_PETS_MAX);
    return H;
  }
  // вещь для домика: случайная из ещё не найденных
  function furnPool(pr) { return [...FURNITURE.filter(f => f.m === undefined), ...WALLPAPERS, ...FLOORS].filter(f => !furnOwned(f, pr)); }
  function furnGive(pr, it) { pr.furn = pr.furn || {}; pr.furn[it.id] = Date.now(); }
  function furnDrop(x, y) {
    const pr = Saves.loadProfile(), pool = furnPool(pr); if (!pool.length) return;
    const it = pool[Math.floor(Math.random() * pool.length)]; furnGive(pr, it); Saves.saveProfile(pr);
    Effects.floatText(x, y - 50, '🏠 ' + (it.ic || '🎨') + ' ' + it.nm, '#ffd25a', true);
    Achievements.achPop({ custom: { ic: it.ic || '🎨', rar: 'Для домика', nm: it.nm, rw: 'Поставить можно в «Коллекции» → «Домик»', col: '#ffb46a' } });
  }
  const HOME = { raf: 0, actors: [], t: 0, last: 0, bubbles: [], hearts: [], edit: false, tab: 'furn', slot: 'wallL', back: 'coll', thumbs: {} };
  function openHome(back) {
    HOME.back = back || 'coll';
    const pr = Saves.loadProfile(), H = homeState(pr); Saves.saveProfile(pr);
    const heroes = ['krilessa'].concat(pr.ch1Done || GameLoop.DEBUG || pr.admin ? ['ryzhovaya'] : []).concat(pr.ch3Done || GameLoop.DEBUG || pr.admin ? ['tessa'] : []);
    HOME.actors = heroes.map((id, i) => ({ hero: id, x: 0.25 + i * 0.25, y: 0.8 + (i % 2) * 0.06, tx: null, face: 1, wait: 1 + i, jump: 0, sayT: 4 + i * 3 }))
      .concat(H.pets.map((id, i) => ({ pet: id, x: 0.3 + i * 0.2, y: 0.88, tx: null, face: 1, wait: i, jump: 0, ph: Math.random() * 6 })));
    HOME.bubbles = []; HOME.hearts = []; HOME.edit = false; $('homeEdit').classList.add('hidden');
    Screens.setState('home'); Sound.music('menu');
    cancelAnimationFrame(HOME.raf); HOME.last = performance.now(); HOME.raf = requestAnimationFrame(homeLoop);
    $('homeInfo').textContent = homeCount(pr);
  }
  function homeCount(pr) {
    const all = [...FURNITURE, ...WALLPAPERS, ...FLOORS], own = all.filter(f => furnOwned(f, pr)).length, pets = PETS.filter(p => petOwned(p, pr)).length;
    return `🛋️ ${own}/${all.length} · 🐾 ${pets}/${PETS.length}`;
  }
  function homeLoop(now) {
    if (Session.state !== 'home') { HOME.raf = 0; return; }
    const dt = Math.min(0.05, (now - HOME.last) / 1000); HOME.last = now; HOME.t += dt;
    const cv = $('homeCv'), r = cv.getBoundingClientRect(), dpr = Math.min(2, window.devicePixelRatio || 1);
    if (cv.width !== Math.round(r.width * dpr) || cv.height !== Math.round(r.height * dpr)) { cv.width = Math.round(r.width * dpr); cv.height = Math.round(r.height * dpr); }
    const c = cv.getContext('2d'); c.setTransform(dpr, 0, 0, dpr, 0, 0);
    homeUpdate(dt);
    try { drawHome(c, r.width, r.height, HOME.t); } catch (e) { GameLoop.logErr(e, 'home'); }
    if (Terrain.paperOn) try { // комната – тоже акварель: светлее и с зерном бумаги
      if (!HUD.PAPER.tex) { HUD.PAPER.tex = HUD.paperTex(); }
      c.save(); c.globalCompositeOperation = 'screen'; c.fillStyle = 'rgba(255,236,206,.22)'; c.fillRect(0, 0, r.width, r.height);
      c.globalCompositeOperation = 'multiply'; c.fillStyle = c.createPattern(HUD.PAPER.tex, 'repeat'); c.fillRect(0, 0, r.width, r.height); c.restore();
    } catch (e) {}
    HOME.raf = requestAnimationFrame(homeLoop);
  }
  function homeUpdate(dt) {
    for (const a of HOME.actors) {
      if (a.jump > 0) a.jump = Math.max(0, a.jump - dt * 1.8);
      if (a.tx === null) { a.wait -= dt; if (a.wait <= 0) { a.tx = 0.08 + Math.random() * 0.84; a.ty = a.hero ? 0.76 + Math.random() * 0.14 : 0.82 + Math.random() * 0.12; } }
      else {
        const dx = a.tx - a.x, dy = a.ty - a.y, d = Math.hypot(dx, dy), sp = (a.hero ? 0.09 : 0.12) * dt;
        if (d < sp) { a.x = a.tx; a.y = a.ty; a.tx = null; a.wait = 1.5 + Math.random() * 4; } else { a.x += dx / d * sp; a.y += dy / d * sp; a.face = dx > 0 ? 1 : -1; }
      }
      if (a.hero) { a.sayT -= dt; if (a.sayT <= 0) { a.sayT = 9 + Math.random() * 10; homeSay(a); } }
    }
    HOME.bubbles = HOME.bubbles.filter(b => (b.t -= dt) > 0);
    HOME.hearts = HOME.hearts.filter(h => (h.t += dt) < 1.2);
  }
  function homeSay(a, txt) { HOME.bubbles = HOME.bubbles.filter(b => b.a !== a); HOME.bubbles.push({ a, txt: txt || pick(HOME_LINES[a.hero] || ['✨']), t: 3 }); }
  // раскладка комнаты в долях экрана
  const HL = { floorY: 0.56, win: [0.33, 0.05, 0.34, 0.2], shelf: [0.25, 0.43, 0.47], cab: [0.79, 0.31, 0.18, 0.26],
    spots: { wallL: [0.14, 0.3, 0.13], wallR: [0.86, 0.2, 0.1], lamp: [0.14, 0.1, 0.11], sill: [0.58, 0.245, 0.08], plant: [0.07, 0.66, 0.17], floorL: [0.25, 0.71, 0.2], center: [0.52, 0.8, 0.13], floorR: [0.8, 0.71, 0.2] } };
  function drawHome(c, W, H, t) {
    const pr = Achievements.loadProfileCached(), S = homeState(pr), wp = WALLPAPERS.find(w => w.id === S.wall) || WALLPAPERS[0], fl = FLOORS.find(f => f.id === S.floor) || FLOORS[0];
    const fy = H * HL.floorY;
    // стена с обоями
    c.fillStyle = wp.c[0]; c.fillRect(0, 0, W, fy);
    c.save(); c.beginPath(); c.rect(0, 0, W, fy); c.clip(); c.fillStyle = wp.c[1]; c.strokeStyle = wp.c[1];
    const u = W / 12;
    if (wp.id === 'stripes') for (let x = 0; x < W; x += u * 2) c.fillRect(x, 0, u, fy);
    else if (wp.id === 'dots') { c.globalAlpha = 0.45; for (let y = u / 2; y < fy; y += u) for (let x = (Math.floor(y / u) % 2) * u / 2; x < W; x += u) { c.beginPath(); c.arc(x, y, u * 0.14, 0, TAU); c.fill(); } }
    else if (wp.id === 'stars' || wp.id === 'hearts') { c.globalAlpha = 0.4; c.font = `${u * 0.45}px Krilessa Icons, sans-serif`; c.textAlign = 'center'; for (let y = u / 2; y < fy; y += u) for (let x = (Math.floor(y / u) % 2) * u / 2; x < W + u; x += u) c.fillText(wp.id === 'stars' ? '★' : '♥', x, y); }
    else if (wp.id === 'waves') { c.globalAlpha = 0.45; c.lineWidth = 3; for (let y = u / 2; y < fy; y += u * 0.8) { c.beginPath(); for (let x = 0; x <= W; x += 6) c.lineTo(x, y + Math.sin(x / u * 3) * u * 0.15); c.stroke(); } }
    else if (wp.id === 'bricks') { c.globalAlpha = 0.5; c.lineWidth = 2; for (let y = 0, row = 0; y < fy; y += u * 0.5, row++) { c.beginPath(); c.moveTo(0, y); c.lineTo(W, y); c.stroke(); for (let x = (row % 2) * u / 2; x < W; x += u) { c.beginPath(); c.moveTo(x, y); c.lineTo(x, y + u * 0.5); c.stroke(); } } }
    c.restore();
    // окно: время суток настоящее, за стеклом – сезон
    const [wx, wy, ww, wh] = [HL.win[0] * W, HL.win[1] * H, HL.win[2] * W, HL.win[3] * H], hr = new Date().getHours();
    const night = hr < 6 || hr >= 21, eve = !night && hr >= 17;
    const sky = c.createLinearGradient(0, wy, 0, wy + wh);
    if (night) { sky.addColorStop(0, '#060a24'); sky.addColorStop(1, '#1a2050'); } else if (eve) { sky.addColorStop(0, '#ff8a5a'); sky.addColorStop(1, '#ffd08a'); } else { sky.addColorStop(0, '#5ab8ff'); sky.addColorStop(1, '#bfeaff'); }
    c.fillStyle = sky; c.fillRect(wx, wy, ww, wh);
    c.save(); c.beginPath(); c.rect(wx, wy, ww, wh); c.clip();
    if (night) { c.fillStyle = '#fff'; for (let k = 0; k < 14; k++) { c.globalAlpha = 0.5 + 0.5 * Math.sin(t * 2 + k); c.fillRect(wx + ((k * 37) % 100) / 100 * ww, wy + ((k * 53) % 70) / 100 * wh, 2, 2); } c.globalAlpha = 1; c.font = `${wh * 0.32}px Krilessa Icons, sans-serif`; c.fillText('🌙', wx + ww * 0.7, wy + wh * 0.4); }
    else { c.font = `${wh * 0.32}px Krilessa Icons, sans-serif`; c.fillText(eve ? '🌇' : '☀️', wx + ww * 0.68, wy + wh * 0.42); c.globalAlpha = 0.85; c.fillText('☁️', wx + ((t * 6) % (ww + 60)) - 40, wy + wh * 0.62); c.globalAlpha = 1; }
    const m = Seasons.seasonMonth(), fall = m === 11 || m <= 1 ? '❄️' : m === 9 || m === 10 ? '🍂' : m >= 2 && m <= 4 ? '🌸' : '';
    if (fall) { c.font = `${wh * 0.12}px Krilessa Icons, sans-serif`; for (let k = 0; k < 6; k++) { const ph = (t * 0.25 + k / 6) % 1; c.fillText(fall, wx + ((k * 29) % 100) / 100 * ww + Math.sin(t + k) * 6, wy + ph * wh); } }
    c.restore();
    c.strokeStyle = '#6a3a1a'; c.lineWidth = 6; c.strokeRect(wx, wy, ww, wh); c.lineWidth = 3; c.beginPath(); c.moveTo(wx + ww / 2, wy); c.lineTo(wx + ww / 2, wy + wh); c.moveTo(wx, wy + wh / 2); c.lineTo(wx + ww, wy + wh / 2); c.stroke();
    c.fillStyle = 'rgba(255,140,190,0.85)'; c.fillRect(wx - 10, wy - 6, 14, wh + 10); c.fillRect(wx + ww - 4, wy - 6, 14, wh + 10); // шторки
    c.fillStyle = '#8a5a30'; c.fillRect(wx - 12, wy + wh, ww + 24, 8); // подоконник
    // плинтус и пол
    c.fillStyle = 'rgba(0,0,0,0.35)'; c.fillRect(0, fy - 6, W, 8);
    c.fillStyle = fl.c[0]; c.fillRect(0, fy, W, H - fy);
    c.save(); c.beginPath(); c.rect(0, fy, W, H - fy); c.clip(); c.strokeStyle = fl.c[1]; c.fillStyle = fl.c[1];
    if (fl.id === 'wood') { c.lineWidth = 2; for (let y = fy, row = 0; y < H; y += 22, row++) { c.beginPath(); c.moveTo(0, y); c.lineTo(W, y); c.stroke(); for (let x = (row % 2) * 40; x < W; x += 80) { c.beginPath(); c.moveTo(x, y); c.lineTo(x, y + 22); c.stroke(); } } }
    else if (fl.id === 'tiles') { const s2 = W / 9; for (let y = fy, r2 = 0; y < H; y += s2, r2++) for (let x = (r2 % 2) * s2, k = 0; x < W; x += s2 * 2, k++) c.fillRect(x, y, s2, s2); }
    else if (fl.id === 'carpet') { c.globalAlpha = 0.5; c.lineWidth = 6; c.strokeRect(10, fy + 10, W - 20, H - fy - 20); }
    else if (fl.id === 'grass') { c.lineWidth = 2; for (let k = 0; k < 90; k++) { const x = (k * 53) % W, y = fy + ((k * 97) % 1000) / 1000 * (H - fy); c.beginPath(); c.moveTo(x, y); c.lineTo(x + 3, y - 8); c.stroke(); } }
    c.restore();
    // ковёр под серединой
    const cs = HL.spots.center; c.fillStyle = 'rgba(255,120,170,0.35)'; c.beginPath(); c.ellipse(cs[0] * W, cs[1] * H + 10, W * 0.2, H * 0.045, 0, 0, TAU); c.fill();
    // полка с трофеями
    const [sx, sy, sw] = [HL.shelf[0] * W, HL.shelf[1] * H, HL.shelf[2] * W];
    c.fillStyle = '#8a5a30'; c.fillRect(sx, sy, sw, 9); c.fillStyle = 'rgba(0,0,0,0.3)'; c.fillRect(sx, sy + 9, sw, 4);
    const D = Collection.bookData(), L = Collection.bookList(), beat = L.bs.filter(k => (D.b[k] || 0) > 0), ts = Math.min(sw / 7, 44);
    beat.slice(0, 7).forEach((k, i) => { if (!HOME.thumbs[k]) HOME.thumbs[k] = Collection.bookThumb('b', k, 64, true); c.drawImage(HOME.thumbs[k], sx + i * (sw / 7) + (sw / 7 - ts) / 2, sy - ts + 4, ts, ts); });
    if (beat.length > 7) { c.fillStyle = '#ffe08a'; c.font = 'bold 11px Krilessa Icons, sans-serif'; c.textAlign = 'right'; c.fillText(`+${beat.length - 7}`, sx + sw, sy + 24); }
    if (!beat.length) { c.fillStyle = 'rgba(255,255,255,0.5)'; c.font = '11px Krilessa Icons, sans-serif'; c.textAlign = 'center'; c.fillText('здесь будут трофеи', sx + sw / 2, sy - 8); }
    // витрина реликвий
    const [cx0, cy0, cw, ch0] = [HL.cab[0] * W, HL.cab[1] * H, HL.cab[2] * W, HL.cab[3] * H];
    c.fillStyle = '#5a3a1a'; c.fillRect(cx0 - 4, cy0 - 4, cw + 8, ch0 + 8);
    c.fillStyle = 'rgba(190,230,255,0.25)'; c.fillRect(cx0, cy0, cw, ch0);
    c.fillStyle = '#5a3a1a'; for (let k = 1; k < 3; k++) c.fillRect(cx0, cy0 + ch0 * k / 3 - 2, cw, 3);
    const lvs = pr.relicLv || {}, own = Object.keys(RELICS).filter(id => lvs[id]);
    c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillStyle = '#fff';
    own.slice(0, 9).forEach((id, i) => {
      const col = i % 3, row = Math.floor(i / 3), x = cx0 + cw * (col + 0.5) / 3, y = cy0 + ch0 * (row + 0.45) / 3;
      c.font = `${Math.min(cw / 3.6, 22)}px Krilessa Icons, sans-serif`; c.fillText(RELICS[id].ic, x, y);
      if (lvs[id] > 1) { c.font = 'bold 9px Krilessa Icons, sans-serif'; c.fillStyle = '#ffd25a'; c.fillText('★'.repeat(lvs[id]), x, y + 13); c.fillStyle = '#fff'; }
    });
    c.fillStyle = 'rgba(255,255,255,0.25)'; c.fillRect(cx0 + 4, cy0 + 4, 4, ch0 - 8);
    // мебель на стенах и свет
    const drawItem = (slot, sz) => { const id = S.slots[slot], f = FURN_BY[id]; if (!f) return; const [x, y, s] = HL.spots[slot]; c.globalAlpha = 1; c.fillStyle = '#fff'; c.font = `${(sz || s) * W}px Krilessa Icons, sans-serif`; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(f.ic, x * W, y * H); }; // цветные эмодзи берут прозрачность заливки – только непрозрачная
    const lamp = FURN_BY[S.slots.lamp];
    if (lamp) { const [lx, ly] = HL.spots.lamp; c.strokeStyle = 'rgba(0,0,0,0.5)'; c.lineWidth = 2; c.beginPath(); c.moveTo(lx * W, 0); c.lineTo(lx * W, ly * H - 14); c.stroke(); drawItem('lamp'); }
    drawItem('wallL'); drawItem('wallR'); drawItem('sill');
    // пол: мебель, героини и питомцы по глубине
    const items = ['plant', 'floorL', 'center', 'floorR'].map(s => ({ y: HL.spots[s][1], slot: s }));
    for (const a of HOME.actors) items.push({ y: a.y, a });
    items.sort((p, q) => p.y - q.y);
    for (const it of items) {
      if (it.slot) { drawItem(it.slot); continue; }
      const a = it.a, x = a.x * W, y = a.y * H - Math.sin(a.jump * Math.PI) * 40;
      if (a.hero) { shadow(c, x, a.y * H + 12, 14, 5); Renderer.drawHeroV(a.hero, c, x, y, t, a.face, 1.35, 1, a.tx !== null); a.sx = x; a.sy = y; }
      else {
        const pet = PET_BY[a.pet]; if (!pet) continue;
        const bob = pet.fly ? Math.sin(t * 3 + a.ph) * 8 - 30 : Math.abs(Math.sin(t * 8 + a.ph)) * (a.tx !== null ? 5 : 0);
        shadow(c, x, a.y * H + 10, 11, 4);
        c.save(); c.translate(x, y - bob); c.scale(a.face < 0 ? -1 : 1, 1); c.globalAlpha = 1; c.fillStyle = '#fff'; c.font = `${W * 0.085}px Krilessa Icons, sans-serif`; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(pet.ic, 0, 0); c.restore();
        a.sx = x; a.sy = y - bob;
      }
    }
    // ночью темнее, лампа светит
    if (night) {
      const [lx, ly] = HL.spots.lamp, g = c.createRadialGradient(lx * W, ly * H, 10, lx * W, ly * H, W * 0.9);
      g.addColorStop(0, 'rgba(255,220,140,0.05)'); g.addColorStop(0.5, 'rgba(10,8,30,0.25)'); g.addColorStop(1, 'rgba(5,4,20,0.5)'); c.fillStyle = g; c.fillRect(0, 0, W, H);
    }
    // реплики и сердечки
    c.textAlign = 'center'; c.textBaseline = 'middle';
    for (const b of HOME.bubbles) {
      const x = b.a.sx || 0, y = (b.a.sy || 0) - 70; c.font = 'bold 12px Krilessa Icons, sans-serif'; const w2 = c.measureText(b.txt).width + 16;
      c.globalAlpha = Math.min(1, b.t * 2); c.fillStyle = 'rgba(255,255,255,0.95)'; roundRect(c, clamp(x - w2 / 2, 4, W - w2 - 4), y - 13, w2, 26, 10); c.fill();
      c.fillStyle = '#2a1a4a'; c.fillText(b.txt, clamp(x, w2 / 2 + 4, W - w2 / 2 - 4), y); c.globalAlpha = 1;
    }
    for (const h of HOME.hearts) { c.globalAlpha = 1 - h.t / 1.2; c.font = '16px Krilessa Icons, sans-serif'; c.fillText(h.g || '💗', h.x + Math.sin(h.t * 6) * 6, h.y - h.t * 60); }
    c.globalAlpha = 1;
  }
  function homeTap(e) {
    if (HOME.edit) return;
    const r = $('homeCv').getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top, W = r.width, H = r.height;
    for (const a of HOME.actors) {
      if (a.sx === undefined || Math.abs(x - a.sx) > 34 || Math.abs(y - (a.sy - (a.hero ? 25 : 0))) > 45) continue;
      a.jump = 1; for (let k = 0; k < 5; k++) HOME.hearts.push({ x: a.sx + rnd(-16, 16), y: a.sy - 30, t: -k * 0.08, g: a.pet ? '💖' : '💗' });
      if (a.hero) { homeSay(a); if (a.hero === 'tessa' && Sound.sfx.meow) Sound.sfx.meow(); else Sound.sfx.blink(); } else Sound.sfx.heart();
      Achievements.life('homeTap'); return;
    }
    const [sx, sy, sw] = [HL.shelf[0] * W, HL.shelf[1] * H, HL.shelf[2] * W];
    if (x > sx && x < sx + sw && y > sy - 50 && y < sy + 14) { Collection.openBook('b', 'home'); return; }
    const [cx0, cy0, cw, ch0] = [HL.cab[0] * W, HL.cab[1] * H, HL.cab[2] * W, HL.cab[3] * H];
    if (x > cx0 && x < cx0 + cw && y > cy0 && y < cy0 + ch0) { Collection.relicsFrom = 'home'; Collection.openRelics(); }
  }
  // редактор: мебель по местам, питомцы, обои и пол
  function renderHomeEdit() {
    const pr = Saves.loadProfile(), S = homeState(pr);
    for (const k of ['furn', 'pets', 'wall']) $('heT_' + k).classList.toggle('on', HOME.tab === k);
    const slots = $('heSlots'), grid = $('heGrid'); slots.innerHTML = ''; grid.innerHTML = '';
    slots.classList.toggle('hidden', HOME.tab !== 'furn');
    const cell = (ic, nm, on, has, fn, how) => {
      const b = document.createElement('button'); b.className = 'heItem' + (on ? ' on' : '') + (has ? '' : ' no');
      b.innerHTML = `<i>${ic}</i><small>${nm}</small>`;
      b.addEventListener('click', () => { if (!has) { RunStats.toast('🔒 ' + how); return; } fn(); Sound.sfx.click(); const p3 = Saves.loadProfile(); Saves.saveProfile(p3); renderHomeEdit(); $('homeInfo').textContent = homeCount(Saves.loadProfile()); });
      grid.appendChild(b);
    };
    const save = fn => { const p2 = Saves.loadProfile(); const S2 = homeState(p2); fn(S2, p2); Saves.saveProfile(p2); Achievements.lpc = null; };
    if (HOME.tab === 'furn') {
      for (const sl of HOME_SLOTS) {
        const b = document.createElement('button'); b.className = 'heSlot' + (HOME.slot === sl.id ? ' on' : ''); const f = FURN_BY[S.slots[sl.id]];
        b.innerHTML = `${f ? f.ic : '∅'}<small>${sl.nm}</small>`; b.addEventListener('click', () => { HOME.slot = sl.id; Sound.sfx.click(); renderHomeEdit(); }); slots.appendChild(b);
      }
      const sl = HOME_SLOTS.find(x => x.id === HOME.slot);
      cell('∅', 'Пусто', !S.slots[sl.id], true, () => save(S2 => { S2.slots[sl.id] = ''; }));
      for (const f of FURNITURE.filter(x => x.k === sl.k)) {
        if (f.m !== undefined && !furnOwned(f, pr) && f.m !== Seasons.seasonMonth()) continue; // чужие сезоны не мелькают
        cell(f.ic, f.nm, S.slots[sl.id] === f.id, furnOwned(f, pr), () => save(S2 => { for (const k in S2.slots) if (S2.slots[k] === f.id && k !== sl.id) S2.slots[k] = ''; S2.slots[sl.id] = f.id; }),
          f.m !== undefined ? `Сезон «${SEASON_THEMES[f.m].nm}» – 3-й уровень дороги сезона` : 'Выпадает из сундуков и с дороги сезона');
      }
      $('heHint').textContent = 'Вещи для домика выпадают из серебряных и золотых сундуков, тайников и с дороги сезона';
    } else if (HOME.tab === 'pets') {
      for (const pt of PETS) {
        const has = petOwned(pt, pr); if (pt.src.includes('ss_') && !has && +pt.src.split('_')[1] !== Seasons.seasonMonth()) continue;
        cell(pt.ic, pt.nm, S.pets.includes(pt.id), has, () => save(S2 => {
          if (S2.pets.includes(pt.id)) S2.pets = S2.pets.filter(x => x !== pt.id);
          else { if (S2.pets.length >= HOME_PETS_MAX) S2.pets.shift(); S2.pets.push(pt.id); }
          HOME.actors = HOME.actors.filter(a => !a.pet || S2.pets.includes(a.pet));
          for (const id of S2.pets) if (!HOME.actors.some(a => a.pet === id)) HOME.actors.push({ pet: id, x: 0.5, y: 0.9, tx: null, face: 1, wait: 0.5, jump: 1, ph: Math.random() * 6 });
        }), petHow(pt));
      }
      $('heHint').textContent = `Дома могут жить до ${HOME_PETS_MAX} питомцев сразу`;
    } else {
      for (const w of WALLPAPERS) cell('🎨', w.nm, S.wall === w.id, furnOwned(w, pr), () => save(S2 => { S2.wall = w.id; }), 'Выпадает из сундуков и с дороги сезона');
      for (const f of FLOORS) cell('🟫', f.nm, S.floor === f.id, furnOwned(f, pr), () => save(S2 => { S2.floor = f.id; }), 'Выпадает из сундуков и с дороги сезона');
      $('heHint').textContent = 'Обои и пол – тоже находки из сундуков';
    }
  }

  return {
    petOwned, homeState, furnPool, furnGive, furnDrop, HOME, openHome, homeTap, renderHomeEdit,
  };
})();
