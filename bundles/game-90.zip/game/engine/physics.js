'use strict';

const Physics = (() => {
  function collide(e) {
    const r = e.r;
    const tx0 = Math.floor((e.x - r) / World.T), tx1 = Math.floor((e.x + r) / World.T);
    const ty0 = Math.floor((e.y - r) / World.T), ty1 = Math.floor((e.y + r) / World.T);
    for (let ty = ty0; ty <= ty1; ty++) for (let tx = tx0; tx <= tx1; tx++) {
      if (!World.isSolidTile(tx, ty, e.fly)) continue;
      const rx = tx * World.T, ry = ty * World.T;
      const nx = clamp(e.x, rx, rx + World.T), ny = clamp(e.y, ry, ry + World.T);
      const dx = e.x - nx, dy = e.y - ny, d2 = dx * dx + dy * dy;
      if (d2 >= r * r) continue;
      if (d2 > 1e-6) { const d = Math.sqrt(d2), push = r - d; e.x += (dx / d) * push; e.y += (dy / d) * push; }
      else {
        const l = e.x - rx, rr = rx + World.T - e.x, u = e.y - ry, dd = ry + World.T - e.y, m = Math.min(l, rr, u, dd);
        if (m === l) e.x = rx - r; else if (m === rr) e.x = rx + World.T + r; else if (m === u) e.y = ry - r; else e.y = ry + World.T + r;
      }
    }
    // деревья больше не преграда: сквозь них проходят и героиня, и враги – никаких тупиков
    // (крона просвечивает, когда кто-то под ней)
  }
  function moveEntity(e, dx, dy) {
    const steps = Math.max(1, Math.ceil(Math.max(Math.abs(dx), Math.abs(dy)) / (e.r * 0.7)));
    for (let s = 0; s < steps; s++) { e.x += dx / steps; e.y += dy / steps; collide(e); }
  }
  function playerInCastle() {
    const tx = Math.floor(P.x / World.T), ty = Math.floor(P.y / World.T);
    return Math.abs(tx - World.CASTLE.x) < World.CASTLE.half && Math.abs(ty - World.CASTLE.y) < World.CASTLE.half;
  }
  function walkable(x, y, fly) {
    const tx = Math.floor(x / World.T), ty = Math.floor(y / World.T);
    if (World.isSolidTile(tx, ty, fly)) return false;
    if (!World.gateOpen && World.tileAt(tx, ty) === FLOOR && World.biomeMap[ty * World.MW + tx] !== ARENA_BIOME && !playerInCastle()) return false;
    return true;
  }
  function leadAngle(x, y, spd, k = 0.85) {
    const Q = Session.AIM || P, d = Math.hypot(Q.x - x, Q.y - y);
    const tt = (d / spd) * k;
    return Math.atan2(Q.y + (Q.vy || 0) * tt - y, Q.x + (Q.vx || 0) * tt - x);
  }

  return { collide, moveEntity, playerInCastle, walkable, leadAngle };
})();
