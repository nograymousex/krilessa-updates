'use strict';

const Achievements = (() => {
  // ---------- достижения 2.0: редкость, слава, звания, награды ----------
  // счётчики «за всё время» копятся в памяти и раз в несколько секунд уходят в профиль
  const LIFE = {}, LIFE_MAX = {}, DAYC = {}, DAYM = {}; // DAY* – то же, но для заданий дня и недели
  function life(k, v = 1) { LIFE[k] = (LIFE[k] || 0) + v; DAYC[k] = (DAYC[k] || 0) + v; }
  function lifeMax(k, v) { LIFE_MAX[k] = Math.max(LIFE_MAX[k] || 0, v); DAYM[k] = Math.max(DAYM[k] || 0, v); }
  let lifeSoonT = 0; // секреты в меню: сохранить чуть погодя, а не на каждый тап
  function lifeSoon() { clearTimeout(lifeSoonT); lifeSoonT = setTimeout(() => { try { lifeFlush(); } catch (e) { /* ignore */ } }, 700); }
  const ACH_CATS = [
    { id: 'all', ic: '🏆', nm: 'Все' },
    { id: 'adv', ic: '🗺️', nm: 'Приключение' },
    { id: 'fight', ic: '⚔️', nm: 'Бой' },
    { id: 'coll', ic: '📦', nm: 'Коллекция' },
    { id: 'modes', ic: '🎮', nm: 'Режимы' },
    { id: 'team', ic: '👥', nm: 'Вместе' },
    { id: 'mast', ic: '🎯', nm: 'Мастерство' },
    { id: 'sec', ic: '🤫', nm: 'Секреты' },
    { id: 'ultra', ic: '🌈', nm: 'Ультра' },
  ];
  const lf = k => p => (p.life || {})[k] || 0;
  const chDone = n => p => (p['ch' + n + 'Done'] ? 1 : 0);
  const chHid = n => () => !Chapters.chapterOpen(n);
  const nDone = p => Session.CH_NUMS.filter(n => p['ch' + n + 'Done']).length;
  const chCnt = k => p => Session.CH_NUMS.filter(n => (p[k] || {})[n]).length;
  const allCh = () => Session.CH_NUMS.length;
  const fastAny = p => { let b = 1e9; for (const n of Session.CH_NUMS) { const f = (p.fast || {})[n]; if (n >= 2 && f && f.t < b) b = f.t; } return b; };
  // ступенчатая линия: одно достижение на каждую ступень, в списке показывается ближайшая
  const LINE = (line, cat, ic, val, steps) => steps.map(([goal, r, nm, ds], i) => ({ id: line + (i + 1), line, tier: i + 1, tiers: steps.length, cat, ic, nm, ds, r, val, goal }));
  const ACHS = [
    // 🗺️ приключение
    { id: 'ch1', cat: 'adv', r: 'c', ic: '🌲', nm: 'Первые шаги', ds: 'Пройди главу 1', val: chDone(1), goal: 1 },
    { id: 'ch2', cat: 'adv', r: 'c', ic: '🪩', nm: 'Диско окончено', ds: 'Пройди главу 2', val: chDone(2), goal: 1 },
    { id: 'ch3', cat: 'adv', r: 'r', ic: '🪞', nm: 'Сквозь зеркала', ds: 'Пройди главу 3', val: chDone(3), goal: 1 },
    { id: 'ch4', cat: 'adv', r: 'r', ic: '🌙', nm: 'Ночная стража', ds: 'Пройди главу 4', val: chDone(4), goal: 1, hid: chHid(4) },
    { id: 'ch5', cat: 'adv', r: 'r', ic: '🔎', nm: 'Дело раскрыто', ds: 'Пройди главу 5', val: chDone(5), goal: 1, hid: chHid(5) },
    { id: 'ch6', cat: 'adv', r: 'e', ic: '❄️', nm: 'Оттепель', ds: 'Пройди главу 6', val: chDone(6), goal: 1, hid: chHid(6) },
    { id: 'ch7', cat: 'adv', r: 'e', ic: '🦐', nm: 'Со дна', ds: 'Пройди главу 7', val: chDone(7), goal: 1, hid: chHid(7) },
    { id: 'season', cat: 'adv', r: 'l', ic: '👑', nm: 'Сезон пройден', ds: 'Пройди все главы', val: nDone, goal: allCh },
    { id: 'truewin', cat: 'adv', r: 'e', ic: '💫', nm: 'Настоящий финал', ds: 'Найди настоящий финал главы 3', val: p => (p.trueWin ? 1 : 0), goal: 1, secret: true },
    { id: 'ends4', cat: 'adv', r: 'e', ic: '🎭', nm: 'Обе стороны', ds: 'Увидь обе концовки главы 4', val: p => Object.keys(p.ch4Seen || {}).length, goal: 2, hid: p => !p.ch4Done },
    { id: 'pearls', cat: 'adv', r: 'e', ic: '💗', nm: 'Все слова на месте', ds: 'Собери все 12 жемчужин за одно прохождение', val: lf('pearls12'), goal: 1, hid: chHid(7) },
    // ⚔️ бой
    ...LINE('kills', 'fight', '⚔️', lf('kills'), [[500, 'c', 'Охотница', 'Победи 500 врагов'], [5000, 'r', 'Гроза монстров', 'Победи 5 000 врагов'], [25000, 'e', 'Перьевой ураган', 'Победи 25 000 врагов'], [100000, 'l', 'Конец света для мобов', 'Победи 100 000 врагов']]),
    ...LINE('elites', 'fight', '💥', lf('elites'), [[50, 'c', 'Элита? Не смешите', 'Победи 50 элитных врагов'], [300, 'r', 'Ломательница корон', 'Победи 300 элитных врагов'], [1000, 'e', 'Элиты больше нет', 'Победи 1 000 элитных врагов']]),
    ...LINE('bosses', 'fight', '🐉', lf('bosses'), [[10, 'c', 'Стражеборица', 'Победи 10 боссов'], [50, 'r', 'Охота на стражей', 'Победи 50 боссов'], [200, 'e', 'Кошмар стражей', 'Победи 200 боссов']]),
    ...LINE('champs', 'fight', '🏵️', lf('champs'), [[5, 'c', 'Чемпионка', 'Победи 5 чемпионов с короной'], [25, 'r', 'Корона за короной', 'Победи 25 чемпионов'], [75, 'e', 'Королева чемпионов', 'Победи 75 чемпионов']]),
    ...LINE('combo', 'fight', '🔥', lf('combo'), [[100, 'c', 'Комбо!', 'Набери комбо 100'], [250, 'r', 'Комбо-мастер', 'Набери комбо 250'], [500, 'e', 'Не остановить', 'Набери комбо 500'], [1000, 'l', 'Тысяча без передышки', 'Набери комбо 1 000']]),
    ...LINE('supers', 'fight', '⚡', lf('supers'), [[50, 'c', 'Супер-девочка', 'Используй супер-удар 50 раз'], [500, 'r', 'Суперсила', 'Используй супер-удар 500 раз']]),
    ...LINE('evos', 'fight', '🌈', p => Object.keys(p.evoSeen || {}).length, [[1, 'c', 'Эволюция!', 'Собери первую эволюцию улучшений'], [4, 'r', 'Алхимичка', 'Открой 4 разные эволюции'], [8, 'e', 'Все превращения', 'Открой все 8 эволюций']]),
    ...LINE('nohit', 'fight', '🛡️', lf('noHit'), [[1, 'r', 'Ни царапины', 'Победи босса, не получив урона'], [10, 'e', 'Неуловимая', 'Победи 10 боссов, не получив урона']]),
    // 📦 коллекция
    ...LINE('chests', 'coll', '📦', lf('chests'), [[50, 'c', 'Кладоискательница', 'Открой 50 сундуков'], [300, 'r', 'Сундучный магнат', 'Открой 300 сундуков'], [1000, 'e', 'Ни одного закрытого', 'Открой 1 000 сундуков']]),
    ...LINE('secrets', 'coll', '🗝️', lf('secrets'), [[1, 'c', 'Тайное место', 'Найди тайник за треснувшей стеной'], [10, 'r', 'Простукивательница', 'Найди 10 тайников'], [30, 'e', 'Ни камня без проверки', 'Найди 30 тайников']]),
    ...LINE('furn', 'coll', '🛋️', p => [...FURNITURE, ...WALLPAPERS, ...FLOORS].filter(f => !f.def && (p.furn || {})[f.id]).length, [[5, 'c', 'Новоселье', 'Найди 5 вещей для домика'], [20, 'r', 'Уютный уголок', 'Найди 20 вещей для домика'], [40, 'e', 'Дизайнерша', 'Найди 40 вещей для домика']]),
    ...LINE('pets', 'coll', '🐾', p => PETS.filter(pt => HomeScreen.petOwned(pt, p)).length, [[1, 'c', 'Хвостик', 'Заведи первого питомца'], [5, 'r', 'Зоопарк', 'Собери 5 питомцев'], [12, 'l', 'Ноев ковчег', 'Собери 12 питомцев']]),
    { id: 'relic3', cat: 'coll', r: 'e', ic: '🏺', nm: 'Реликвия мастера', ds: 'Прокачай любую реликвию до 3-го уровня', val: p => (Object.values(p.relicLv || {}).some(v => v >= 3) ? 1 : 0), goal: 1 },
    ...LINE('mimics', 'coll', '😱', lf('mimics'), [[10, 'c', 'Мимикам тут не место', 'Победи 10 мимиков'], [50, 'r', 'Гроза мимиков', 'Победи 50 мимиков']]),
    ...LINE('trials', 'coll', '⛩️', lf('trials'), [[10, 'c', 'Испытанная', 'Пройди 10 испытаний у алтарей'], [50, 'r', 'Хозяйка алтарей', 'Пройди 50 испытаний']]),
    { id: 'relics', cat: 'coll', r: 'e', ic: '🗝️', nm: 'Музей реликвий', ds: 'Найди все реликвии', val: p => Object.keys(p.relicSeen || {}).filter(id => RELICS[id]).length, goal: () => Object.keys(RELICS).length },
    ...LINE('book', 'coll', '📖', () => Collection.bookCount().pct, [[50, 'r', 'Любопытная', 'Открой половину Кринжопедии'], [100, 'e', 'Кринжевед', 'Открой всю Кринжопедию']]),
    ...LINE('stars', 'coll', '⭐', p => p.stars || 0, [[50, 'r', 'Звёздный путь', 'Собери 50 звёзд'], [120, 'e', 'Созвездие', 'Собери 120 звёзд'], [200, 'l', 'Млечный путь', 'Собери 200 звёзд']]),
    { id: 'outfits', cat: 'coll', r: 'e', ic: '🎀', nm: 'Модница', ds: 'Собери все наряды Тессы', val: p => WARDROBE.filter(w => w.id !== 'none' && ((p.wardrobe || {}).own || {})[w.id]).length, goal: () => WARDROBE.length - 1, hid: p => !p.ch4Done },
    { id: 'talapex', cat: 'coll', r: 'e', ic: '🌠', nm: 'Вершина', ds: 'Прокачай до конца вершину любой ветви талантов', val: p => (TALENTS.some(d => d.apex && ((p.talents || {})[d.id] || 0) >= d.max) ? 1 : 0), goal: 1 },
    { id: 'talall', cat: 'coll', r: 'l', ic: '✨', nm: 'Звездочёт', ds: 'Прокачай все таланты до конца', val: p => TALENTS.filter(d => ((p.talents || {})[d.id] || 0) >= d.max).length, goal: () => TALENTS.length },
    // 🎮 режимы
    { id: 'rush1', cat: 'modes', r: 'r', ic: '⚔️', nm: 'Раш пройден', ds: 'Пройди босс-раш до конца', val: lf('rush'), goal: 1 },
    { id: 'rushfast', cat: 'modes', r: 'e', ic: '⏩', nm: 'Раш на скорости', ds: 'Пройди босс-раш, тратя в среднем не больше 35 с на босса', val: p => { const b = p.rushBest; return b && b.n >= b.total && b.time <= b.total * 35 ? 1 : 0; }, goal: 1 },
    ...LINE('abyss', 'modes', '🕳️', lf('abyss'), [[10, 'c', 'В бездну', 'Дойди до 10-й волны Бездны'], [25, 'r', 'На дне', 'Дойди до 25-й волны Бездны'], [40, 'e', 'Глубже дна', 'Дойди до 40-й волны Бездны'], [60, 'l', 'Покорительница Бездны', 'Дойди до 60-й волны Бездны']]),
    ...LINE('def', 'modes', '🛡️', lf('defWave'), [[5, 'c', 'Защитница', 'Отбей 5 волн в обороне'], [15, 'r', 'Крепость', 'Отбей 15 волн в обороне'], [30, 'e', 'Нерушимая', 'Отбей 30 волн в обороне'], [50, 'l', 'Легенда обороны', 'Отбей 50 волн в обороне']]),
    { id: 'defspell', cat: 'modes', r: 'r', ic: '🌠', nm: 'Повелительница неба', ds: 'Используй заклинания обороны 50 раз', val: lf('defSpells'), goal: 50 },
    { id: 'defmaps', cat: 'modes', r: 'r', ic: '🗺️', nm: 'Три рубежа', ds: 'Отбей по 10 волн на каждой карте обороны', val: lf('defMaps'), goal: 1 },
    { id: 'daily1', cat: 'modes', r: 'c', ic: '📅', nm: 'Каждый день – испытание', ds: 'Сыграй испытание дня', val: lf('daily'), goal: 1 },
    ...LINE('dstreak', 'modes', '🗓️', lf('dStreak'), [[7, 'r', 'Привычка', 'Испытание дня 7 дней подряд'], [30, 'l', 'Железная воля', 'Испытание дня 30 дней подряд']]),
    { id: 'dscore', cat: 'modes', r: 'e', ic: '🎰', nm: 'Рекорд дня', ds: 'Набери 4 000 очков в испытании дня', val: lf('dBest'), goal: 4000 },
    ...LINE('mut', 'modes', '🧪', lf('mutMax'), [[3, 'r', 'Смелая', 'Пройди главу с тремя мутаторами'], [Challenges.MUTS.length, 'l', 'Безумие', 'Пройди главу со всеми мутаторами сразу']]),
    { id: 'season1', cat: 'modes', r: 'e', ic: '🛤️', nm: 'Дорога сезона', ds: 'Дойди до 20-го уровня сезона', val: lf('seasonLvl'), goal: SEASON_MAX },
    ...LINE('quests', 'modes', '📜', lf('questsDone'), [[10, 'c', 'Исполнительная', 'Выполни 10 заданий дня или недели'], [100, 'r', 'Трудяжка', 'Выполни 100 заданий'], [500, 'l', 'Мастер заданий', 'Выполни 500 заданий']]),
    ...LINE('gifts', 'modes', '🎁', p => (p.gift || {}).n || 0, [[7, 'c', 'Неделя с Крилессой', 'Забери подарки дня 7 раз'], [30, 'r', 'Месяц с Крилессой', 'Забери подарки дня 30 раз'], [100, 'e', 'Сто дней вместе', 'Забери подарки дня 100 раз']]),
    { id: 'mutstars', cat: 'modes', r: 'e', ic: '🧬', nm: 'Мутантка', ds: 'Собери 30 звёзд за мутаторы', val: p => Object.keys(p.starsGot || {}).filter(k => k.startsWith('m:')).length, goal: 30 },
    // 👥 вместе
    { id: 'coop1', cat: 'team', r: 'c', ic: '👥', nm: 'Вместе веселее', ds: 'Пройди главу вместе с подругами', val: lf('coop'), goal: 1 },
    { id: 'coop4', cat: 'team', r: 'r', ic: '🏠', nm: 'Полный дом', ds: 'Пройди главу вчетвером', val: lf('coop4'), goal: 1 },
    { id: 'coopall', cat: 'team', r: 'e', ic: '🤝', nm: 'Всё вместе', ds: 'Пройди вместе каждую главу', val: chCnt('coopCh'), goal: allCh },
    ...LINE('revive', 'team', '💫', lf('revives'), [[10, 'c', 'Своих не бросаем', 'Подними подруг 10 раз'], [100, 'r', 'Ангел-хранитель', 'Подними подруг 100 раз']]),
    { id: 'defcoop', cat: 'team', r: 'e', ic: '💎', nm: 'Стена дружбы', ds: 'Отбейте 20 волн обороны вчетвером', val: lf('defCoop4'), goal: 1 },
    { id: 'rushcoop', cat: 'team', r: 'r', ic: '⚔️', nm: 'Раш на всех', ds: 'Пройди босс-раш вместе с подругами', val: p => { const b = p.rushBestCoop; return b && b.n >= b.total ? 1 : 0; }, goal: 1 },
    // 🎯 мастерство
    { id: 'hc1', cat: 'mast', r: 'r', ic: '😈', nm: 'Кринж-хардкор', ds: 'Пройди главу на «Кринж-хардкоре», не меняя сложность', val: chCnt('hcCh'), goal: 1 },
    { id: 'hcall', cat: 'mast', r: 'l', ic: '🩸', nm: 'Хардкорщица', ds: 'Пройди все главы на «Кринж-хардкоре»', val: chCnt('hcCh'), goal: allCh },
    { id: 'clean1', cat: 'mast', r: 'r', ic: '🕊️', nm: 'Ни разу не упала', ds: 'Пройди главу, ни разу не проиграв', val: chCnt('cleanCh'), goal: 1 },
    { id: 'hcclean', cat: 'mast', r: 'e', ic: '🧊', nm: 'Стальные нервы', ds: 'Пройди главу на хардкоре, ни разу не проиграв', val: chCnt('hcClean'), goal: 1 },
    { id: 'noheal', cat: 'mast', r: 'e', ic: '💔', nm: 'Без аптечки', ds: 'Пройди главу, не подобрав ни одного сердечка', val: lf('noHeal'), goal: 1 },
    { id: 'speed1', cat: 'mast', r: 'r', ic: '⏱️', nm: 'Быстрые лапки', ds: 'Пройди любую главу, кроме первой, быстрее 20 минут', val: p => (fastAny(p) <= 1200 ? 1 : 0), goal: 1 },
    { id: 'speed2', cat: 'mast', r: 'l', ic: '⚡', nm: 'Молния', ds: 'Пройди любую главу, кроме первой, быстрее 12 минут', val: p => (fastAny(p) <= 720 ? 1 : 0), goal: 1 },
    // 🤫 секреты: условие видно только после открытия
    { id: 's_toss', cat: 'sec', r: 'c', ic: '💞', nm: 'Попрыгушки', ds: 'Подбрось героинь на стартовом экране 50 раз', val: lf('toss'), goal: 50, secret: true },
    { id: 's_poke', cat: 'sec', r: 'c', ic: '🤫', nm: 'Не трогай её!', ds: 'Потыкай портрет в меню, пока кто-то не обидится', val: lf('poke'), goal: 1, secret: true },
    { id: 's_oops', cat: 'sec', r: 'c', ic: '🙃', nm: 'Падать – это нормально', ds: 'Проиграй 25 раз', val: lf('deaths'), goal: 25, secret: true },
    { id: 's_escape', cat: 'sec', r: 'c', ic: '🚪', nm: 'Выхода нет', ds: 'Попробуй сбежать с представления', val: lf('escape'), goal: 1, secret: true },
    { id: 's_deco', cat: 'sec', r: 'r', ic: '🎯', nm: 'Сбивашка', ds: 'Сбей 100 украшений на карте приключений', val: lf('deco'), goal: 100, secret: true },
    { id: 's_night', cat: 'sec', r: 'r', ic: '🦉', nm: 'Ночная смена', ds: 'Пройди главу между полуночью и пятью утра', val: lf('night'), goal: 1, secret: true },
    { id: 's_krill', cat: 'sec', r: 'r', ic: '🫧', nm: 'Не буди криль', ds: 'Потревожь воду 100 раз в загадке глубин', val: lf('krillTap'), goal: 100, secret: true },
    { id: 's_sniper', cat: 'sec', r: 'e', ic: '🎯', nm: 'Снайперша', ds: 'Сбей 15 украшений подряд, не дав серии остыть', val: lf('decoCombo'), goal: 15, secret: true },
    { id: 's_clutch', cat: 'sec', r: 'e', ic: '❤️‍🩹', nm: 'На волоске', ds: 'Победи босса, когда у тебя меньше 5% здоровья', val: lf('clutch'), goal: 1, secret: true },
    // 🌈 ультра – для самых упорных
    { id: 'u_abyss', cat: 'ultra', r: 'u', ic: '👁️', nm: 'Бездна смотрит в тебя', ds: 'Дойди до 100-й волны Бездны', val: lf('abyss'), goal: 100 },
    { id: 'u_madness', cat: 'ultra', r: 'u', ic: '☠️', nm: 'Абсолютное безумие', ds: 'Пройди главу со всеми мутаторами на «Кринж-хардкоре», не меняя сложность', val: lf('mutHard'), goal: 1 },
    { id: 'u_untouch', cat: 'ultra', r: 'u', ic: '👻', nm: 'Неприкасаемая', ds: 'На хардкоре победи финального босса главы 5 или дальше, не получив ни капли урона', val: lf('untouch'), goal: 1 },
    { id: 'u_perfect', cat: 'ultra', r: 'u', ic: '💎', nm: 'Безупречный сезон', ds: 'Пройди каждую главу на хардкоре, ни разу не проиграв', val: chCnt('hcClean'), goal: allCh },
    { id: 'u_legend', cat: 'ultra', r: 'u', ic: '🌈', nm: 'Легенда Крилессы', ds: 'Получи все остальные достижения', val: p => ACHS.filter(a => a.id !== 'u_legend' && (p.ach || {})[a.id]).length, goal: () => ACHS.length - 1 },
  ];
  const ACH_BY = indexById(ACHS);
  const achGoal = a => (typeof a.goal === 'function' ? a.goal() : a.goal);
  const achVal = (a, p) => { try { return a.val(p) || 0; } catch (e) { return 0; } };
  // награды-косметика по достижениям и званиям
  const LOOK_REW = {};
  for (const k in LOOK_SETS) for (const it of LOOK_SETS[k]) if (it.src) (LOOK_REW[it.src] = LOOK_REW[it.src] || []).push({ k, it });
  const LOOK_KIND = { em: 'эмблема', fr: 'рамка', ti: 'титул', au: 'аура' };
  const lookName = (k, it) => (k === 'em' ? it.ic : k === 'au' ? it.ic + ' ' + it.nm : `«${it.nm}»`);
  const rewText = src => (LOOK_REW[src] || []).map(({ k, it }) => `${LOOK_KIND[k]} ${lookName(k, it)}`).join(', ');
  function fameOf(pr) { let f = 0; const ach = pr.ach || {}; for (const a of ACHS) if (ach[a.id]) f += RARITY[a.r].fame; return f; }
  function gloryOf(pr) {
    const fame = fameOf(pr), rk = rankOf(fame), next = RANKS[rk + 1];
    return { fame, rk, rank: RANKS[rk], next, n: ACHS.filter(a => (pr.ach || {})[a.id]).length };
  }
  function myLook(pr) {
    const lk = Object.assign({}, LOOK_DEF, pr.look || {}), g = gloryOf(pr);
    for (const k in LOOK_DEF) if (!LOOK_SETS[k].some(x => x.id === lk[k]) || !lookOwned(lookItem(k, lk[k]), pr.ach, g.rk)) lk[k] = LOOK_DEF[k];
    return lk;
  }
  const titleText = (ti, rk) => (ti && ti !== 'rank' ? lookItem('ti', ti).nm : RANKS[rk || 0].nm);

  let lifeT = 0;
  function lifeFlush() {
    if (G.bestCombo) lifeMax('combo', G.bestCombo);
    const keys = Object.keys(LIFE), mk = Object.keys(LIFE_MAX), bk = Object.keys(Collection.BOOK.e).length + Object.keys(Collection.BOOK.b).length;
    const pr = Saves.loadProfile(); pr.life = pr.life || {}; pr.book = pr.book || { e: {}, b: {} };
    if (!keys.length && !mk.length && !bk) { const s1 = Seasons.seasonFlush(pr), a1 = achCheck(pr); if (s1 || a1) Saves.saveProfile(pr); return; } // нового нет, но достижение могло уже выполниться (например, глава пройдена)
    for (const k of keys) { pr.life[k] = (pr.life[k] || 0) + LIFE[k]; delete LIFE[k]; }
    for (const k of mk) { pr.life[k] = Math.max(pr.life[k] || 0, LIFE_MAX[k]); delete LIFE_MAX[k]; }
    for (const g of ['e', 'b']) for (const t in Collection.BOOK[g]) { pr.book[g][t] = (pr.book[g][t] || 0) + Collection.BOOK[g][t]; } // 0 – видела, >0 – победила столько раз
    Collection.BOOK.e = {}; Collection.BOOK.b = {};
    Collection.bookCache = pr.book;
    Seasons.seasonFlush(pr);
    achCheck(pr);
    Saves.saveProfile(pr);
  }
  const starCount = pr => Object.keys(pr.starsGot || {}).length;
  // проверить все достижения; silent – без всплывашек (пересчёт при обновлении)
  function achCheck(pr, silent) {
    pr.ach = pr.ach || {}; pr.starsGot = pr.starsGot || {};
    const rk0 = gloryOf(pr).rk, got = [];
    for (let pass = 0; pass < 4; pass++) { // звёзды и «все остальные» зависят от других достижений
      let any = false;
      for (const a of ACHS) {
        if (pr.ach[a.id] || achVal(a, pr) < achGoal(a)) continue;
        pr.ach[a.id] = Date.now();
        for (let k = 0; k < RARITY[a.r].st; k++) pr.starsGot[`g:${a.id}:${k}`] = 1;
        pr.stars = starCount(pr); got.push(a); any = true;
      }
      if (!any) break;
    }
    if (!got.length) return false;
    const rk1 = gloryOf(pr).rk;
    if (!silent) {
      got.sort((a, b) => RAR_ORDER.indexOf(a.r) - RAR_ORDER.indexOf(b.r));
      for (const a of got) achPop({ a });
      for (let k = rk0 + 1; k <= rk1; k++) achPop({ rank: k });
    }
    return true;
  }
  // всплывашка «достижение получено» – сверху экрана, по очереди
  const popQ = []; let popBusy = false;
  function achPop(item) { popQ.push(item); if (!popBusy) popNext(); }
  function popNext() {
    const it = popQ.shift(), box = $('achPop');
    if (!it) { popBusy = false; box.className = 'hidden'; return; }
    popBusy = true;
    let ic, rar, col, nm, rw, cls = '';
    if (it.custom) {
      const C = it.custom; ic = C.ic; rar = C.rar; col = C.col; nm = C.nm; rw = C.rw; cls = C.big ? 'rank' : '';
      if (C.big) { Sound.sfx.win(); Challenges.buzz(120); } else { Sound.sfx.superReady(); Challenges.buzz(50); }
    } else if (it.rank !== undefined) {
      const R = RANKS[it.rank]; ic = R.ic; rar = 'Новое звание'; col = '#ffd25a'; nm = R.nm; cls = 'rank';
      rw = rewText('k:' + it.rank); rw = rw ? '🎁 ' + rw : `слава ${R.at}+`;
      Sound.sfx.win(); Challenges.buzz(120);
    } else {
      const a = it.a, R = RARITY[a.r]; ic = a.ic; rar = R.nm; col = R.col; nm = a.nm; cls = 'r-' + a.r;
      const cos = rewText('a:' + a.id);
      rw = `+${R.st}⭐ · +${R.fame} славы` + (cos ? ` · 🎁 ${cos}` : '');
      if (a.r === 'u' || a.r === 'l') { Sound.sfx.win(); Challenges.buzz(140); } else { Sound.sfx.superReady(); Challenges.buzz(60); }
    }
    $('apIc').textContent = ic; $('apRar').textContent = rar; $('apNm').textContent = nm; $('apRw').textContent = rw;
    box.style.setProperty('--rc', col);
    box.className = 'show ' + cls; void box.offsetWidth;
    const dur = it.a && (it.a.r === 'u' || it.a.r === 'l') || it.rank !== undefined || (it.custom && it.custom.big) ? 4200 : 3000;
    setTimeout(() => { box.className = 'out ' + cls; setTimeout(popNext, 350); }, dur);
  }
  // переход на 0.31: старые достижения и их звёзды пересчитываются по новым правилам, таланты сбрасываются
  function gloryMigrate(pr) {
    if (pr.glory1) return;
    pr.starsGot = pr.starsGot || {};
    for (const k of Object.keys(pr.starsGot)) if (k.startsWith('a:')) delete pr.starsGot[k];
    const old = pr.ach || {}; pr.ach = {};
    if (pr.ch4Choice) pr.ch4Seen = Object.assign({ [pr.ch4Choice]: 1 }, pr.ch4Seen || {});
    for (const id of (pr.relics || [])) (pr.relicSeen = pr.relicSeen || {})[id] = 1;
    pr.stars = starCount(pr);
    if (Object.keys(pr.talents || {}).length) { pr.talents = {}; pr.talReset031 = true; }
    achCheck(pr, true);
    for (const id in pr.ach) if (old[id]) pr.ach[id] = old[id]; // дата открытия – прежняя
    pr.glory1 = true;
  }
  // итоги пройденной главы – для мастерства, рекордов и секретов
  function gloryWin() {
    const s = G.st; if (!s || typeof World.CHN !== 'number' || G.daily) return;
    const pr = Saves.loadProfile(), diffs = String(s.diff).split('→'), pure = diffs.length === 1 ? diffs[0] : null;
    const t = Math.round(s.time), clean = !s.deaths && !s.livesLost, coop = NET.on && G.netRun;
    pr.fast = pr.fast || {};
    const f = pr.fast[World.CHN];
    if (t > 30 && (!f || t < f.t)) pr.fast[World.CHN] = { t, d: pure || diffs[diffs.length - 1], h: P.hero, co: coop ? NET.roster.length : 0 };
    const mark = k => { pr[k] = pr[k] || {}; pr[k][World.CHN] = 1; };
    if (pure === 'hard') mark('hcCh');
    if (clean) mark('cleanCh');
    if (clean && pure === 'hard') mark('hcClean');
    if (coop) { mark('coopCh'); if (NET.roster.length >= 4) life('coop4'); }
    if (!s.hearts) lifeMax('noHeal', 1);
    const h = new Date().getHours(); if (h < 5) lifeMax('night', 1);
    if (G.mut && Challenges.mutIds().length >= Challenges.MUTS.length && pure === 'hard') lifeMax('mutHard', 1);
    Saves.saveProfile(pr);
  }

  // ---------- экран достижений ----------
  let achCat = 'all';
  const ROM = ['', 'I', 'II', 'III', 'IV', 'V'];
  function renderAch() {
    const pr = Saves.loadProfile(); pr.ach = pr.ach || {};
    const g = gloryOf(pr);
    $('achHead').innerHTML = `Получено <b>${g.n}</b> из ${ACHS.length} · ✨ слава <b>${RunStats.fmtN(g.fame)}</b> · ${g.rank.ic} ${g.rank.nm}`;
    const nx = g.next, pct = nx ? clamp((g.fame - g.rank.at) / (nx.at - g.rank.at), 0, 1) : 1;
    $('achRank').innerHTML = `<em class="bar"><u style="width:${Math.round(pct * 100)}%"></u></em><small>${nx ? `до звания ${nx.ic} ${nx.nm}: ещё ${RunStats.fmtN(nx.at - g.fame)} славы` : 'Высшее звание! 🪐'}</small>`;
    const cats = $('achCats'); cats.innerHTML = '';
    for (const C of ACH_CATS) {
      const list = ACHS.filter(a => C.id === 'all' || a.cat === C.id), n = list.filter(a => pr.ach[a.id]).length;
      const b = document.createElement('button'); b.className = 'achCat' + (C.id === achCat ? ' on' : '') + (C.id === 'ultra' ? ' ultra' : '');
      b.innerHTML = `${C.ic}<small>${n}/${list.length}</small>`; b.title = C.nm;
      b.addEventListener('click', () => { achCat = C.id; Sound.sfx.click(); renderAch(); });
      cats.appendChild(b);
    }
    $('achCatName').textContent = ACH_CATS.find(c => c.id === achCat).nm;
    const box = $('achList'); box.innerHTML = '';
    // линии – одной строкой: ближайшая неполученная ступень
    const rows = [], seen = new Set();
    for (const a of ACHS) {
      if (achCat !== 'all' && a.cat !== achCat) continue;
      if (!a.line) { rows.push(a); continue; }
      if (seen.has(a.line)) continue; seen.add(a.line);
      const steps = ACHS.filter(x => x.line === a.line);
      rows.push(steps.find(x => !pr.ach[x.id]) || steps[steps.length - 1]);
    }
    const isDone = a => !!pr.ach[a.id];
    rows.sort((a, b) => (isDone(a) ? 1 : 0) - (isDone(b) ? 1 : 0) || (achCat === 'all' ? 0 : RAR_ORDER.indexOf(a.r) - RAR_ORDER.indexOf(b.r)));
    for (const a of rows) box.appendChild(achRow(a, pr));
  }
  function achRow(a, pr) {
    const done = !!pr.ach[a.id], R = RARITY[a.r], hid = a.hid && !done && a.hid(pr), sec = a.secret && !done;
    const el = document.createElement('div'); el.className = `achRow r-${a.r}` + (done ? ' done' : '') + (hid || sec ? ' sec' : '');
    el.style.setProperty('--rc', R.col);
    const goal = achGoal(a), v = achVal(a, pr);
    let nm = a.nm, ds = a.ds, ic = done ? a.ic : '🔒';
    if (hid) { nm = '???'; ds = 'Откроется позже'; ic = '❔'; }
    else if (sec) { nm = 'Секретное достижение'; ds = 'Условие – секрет. Ищи пасхалки! 🤫'; ic = '🤫'; }
    let pips = '';
    if (a.line) { pips = '<span class="pips">'; for (let k = 1; k <= a.tiers; k++) { const st = ACH_BY[a.line + k]; pips += `<u class="${pr.ach[st.id] ? 'on' : ''}" style="--pc:${RARITY[st.r].col}">${ROM[k]}</u>`; } pips += '</span>'; }
    const cos = hid || sec ? '' : rewText('a:' + a.id);
    const prog = !done && !hid && !sec && goal > 1 ? `<em class="bar"><u style="width:${Math.round(clamp(v / goal, 0, 1) * 100)}%"></u></em><small>${RunStats.fmtN(Math.min(v, goal))} / ${RunStats.fmtN(goal)}</small>` : '';
    const when = done && pr.ach[a.id] > 1 ? `<small>${new Date(pr.ach[a.id]).toLocaleDateString('ru-RU')}</small>` : '';
    el.innerHTML = `<i>${ic}</i><div><b>${Multiplayer.escHtml(nm)}${pips}</b><span>${Multiplayer.escHtml(ds)}</span>${prog}${when}` +
      `<span class="rw"><em style="color:${R.col}">${R.nm}</em> · +${R.st}⭐ · +${R.fame}✨${cos ? ' · 🎁 ' + Multiplayer.escHtml(cos) : ''}</span></div><s>${done ? '✓' : ''}</s>`;
    return el;
  }

  // ---------- таланты-созвездия ----------
  let talBr = 'fury';
  function openTalents() { renderTalents(); Screens.setState('talents'); }
  function renderTalents() {
    const pr = Saves.loadProfile(), tl = pr.talents || {}, stars = pr.stars || 0, free = stars - talentSpent(tl);
    $('talStars').textContent = `⭐ Свободно звёзд: ${free} из ${stars}`;
    const tabs = $('talTabs'); tabs.innerHTML = '';
    for (const B of TAL_BRANCHES) {
      const sp = branchSpent(tl, B.id), mx = TALENTS.reduce((s, d) => s + (d.br === B.id ? d.max * d.cost : 0), 0);
      const b = document.createElement('button'); b.className = 'talTab' + (B.id === talBr ? ' on' : ''); b.style.setProperty('--bc', B.col);
      b.innerHTML = `${B.ic} ${B.nm}<small>${sp} / ${mx}</small>`;
      b.addEventListener('click', () => { talBr = B.id; Sound.sfx.click(); renderTalents(); });
      tabs.appendChild(b);
    }
    const B = TAL_BRANCHES.find(x => x.id === talBr), sp = branchSpent(tl, B.id);
    $('talBrHint').textContent = B.ds;
    const box = $('talList'); box.innerHTML = ''; box.style.setProperty('--bc', B.col);
    for (let tier = 0; tier < TAL_TIERS.length; tier++) {
      const need = TAL_TIERS[tier], open = sp >= need;
      const h = document.createElement('div'); h.className = 'talTier' + (open ? '' : ' locked') + (tier === 3 ? ' apex' : '');
      h.textContent = (tier === 3 ? '✦ Вершина' : `Ступень ${ROM[tier + 1]}`) + (open ? '' : ` · 🔒 вложи в ветвь ${need}⭐ (сейчас ${sp})`);
      box.appendChild(h);
      for (const d of TALENTS) {
        if (d.br !== B.id || d.tier !== tier) continue;
        const r = Math.min(tl[d.id] || 0, d.max), el = document.createElement('div');
        el.className = 'tal' + (r >= d.max ? ' max' : '') + (open ? '' : ' locked') + (d.apex ? ' apex' : '');
        el.dataset.id = d.id;
        el.innerHTML = `<div class="ic">${d.ic}</div><div class="tx"><b>${d.nm}</b><i>${d.ds}</i><div class="pips">${'★'.repeat(r)}${'☆'.repeat(d.max - r)}</div></div>`;
        const bt = document.createElement('button');
        bt.textContent = r >= d.max ? 'макс.' : !open ? '🔒' : `+ ${d.cost}⭐`;
        bt.disabled = !talentCan(tl, d, stars);
        bt.addEventListener('click', () => {
          const p2 = Saves.loadProfile(); p2.talents = p2.talents || {};
          if (!talentCan(p2.talents, d, p2.stars || 0)) return;
          p2.talents[d.id] = (p2.talents[d.id] || 0) + 1; achCheck(p2); Saves.saveProfile(p2);
          Sound.sfx.superReady(); Challenges.buzz(25); renderTalents();
        });
        el.appendChild(bt); box.appendChild(el);
      }
    }
  }

  // ---------- образ: эмблема, рамка, титул, аура ----------
  let lookTab = 'em', lookRaf = 0;
  function openLook() { lookTab = 'em'; const pr = Saves.loadProfile(); $('lkName').value = cardName(pr); renderLook(); Screens.setState('look'); lookLoop(); }
  function cardName(pr) { return String((pr.mp && pr.mp.name) || HEROES.krilessa.name).slice(0, 14); }
  function renderLook() {
    const pr = Saves.loadProfile(), g = gloryOf(pr), lk = myLook(pr);
    $('lkAv').innerHTML = avatarHtml(lk, 64);
    $('lkWho').innerHTML = `<b>${Multiplayer.escHtml(cardName(pr))}</b><span>${Multiplayer.escHtml(titleText(lk.ti, g.rk))}</span><small>${g.rank.ic} ${g.rank.nm} · ✨ ${RunStats.fmtN(g.fame)}</small>`;
    for (const k of ['em', 'fr', 'ti', 'au']) $('lkT_' + k).classList.toggle('on', k === lookTab);
    const set = LOOK_SETS[lookTab], box = $('lkGrid'); box.innerHTML = ''; box.className = 'lk-' + lookTab;
    let own = 0;
    for (const it of set) {
      const has = lookOwned(it, pr.ach, g.rk);
      if (it.season !== undefined && !has && it.season !== Seasons.seasonMonth()) continue; // чужие сезоны не мелькают
      if (has) own++;
      const b = document.createElement('button'); b.className = 'lkItem' + (has ? '' : ' no') + (lk[lookTab] === it.id ? ' on' : '');
      if (lookTab === 'em') b.innerHTML = avatarHtml({ em: it.id, fr: lk.fr }, 44);
      else if (lookTab === 'fr') b.innerHTML = avatarHtml({ em: lk.em, fr: it.id }, 44) + `<small>${it.nm}</small>`;
      else if (lookTab === 'ti') b.innerHTML = `<b>${Multiplayer.escHtml(it.id === 'rank' ? RANKS[g.rk].nm : it.nm)}</b><small>${it.id === 'rank' ? 'твоё звание' : ''}</small>`;
      else b.innerHTML = `<i>${it.ic}</i><small>${it.nm}</small>`;
      b.addEventListener('click', () => {
        if (!has) { RunStats.toast('🔒 ' + lookHow(it)); return; }
        const p2 = Saves.loadProfile(); p2.look = Object.assign({}, LOOK_DEF, p2.look || {}); p2.look[lookTab] = it.id; Saves.saveProfile(p2);
        Sound.sfx.click(); renderLook();
      });
      box.appendChild(b);
    }
    $('lkHint').textContent = `Открыто ${own} из ${set.length} · новые – за достижения и звания`;
  }
  function lookHow(it) {
    const [t, v] = it.src.split(':');
    if (t === 'k') return `Нужно звание ${RANKS[v].ic} ${RANKS[v].nm} (${RANKS[v].at} славы)`;
    if (v.startsWith('ss_')) { const [, m, k] = v.split('_'); const L = Object.keys(SEASON_REWARDS).find(x => SEASON_REWARDS[x] === k); return `Награда сезона «${SEASON_THEMES[m].nm}» – уровень ${L} дороги сезона`; }
    const a = ACH_BY[v], pr = Saves.loadProfile(); if (!a) return 'Скоро';
    if (a.secret && !(pr.ach || {})[a.id]) return 'Награда за секретное достижение 🤫';
    if (a.hid && a.hid(pr)) return 'Награда за достижение, которое откроется позже';
    return `Достижение «${a.nm}» – ${a.ds}`;
  }
  // живое превью ауры с героиней
  function lookLoop() {
    cancelAnimationFrame(lookRaf);
    const step = now => {
      if (Session.state !== 'look') return;
      const cv = $('lkCv'), c = cv.getContext('2d'), t = now / 1000, lk = myLook(loadProfileCached());
      c.clearRect(0, 0, cv.width, cv.height);
      c.save(); c.translate(cv.width / 2, cv.height / 2 + 14); c.scale(1.6, 1.6);
      shadow(c, 0, 10, 11, 4); drawAura(c, lk.au, 0, 0, t); Renderer.drawHeroV(Challenges.rushHeroPick(loadProfileCached()), c, 0, 0, t, 1, 1, 1, false);
      c.restore();
      lookRaf = requestAnimationFrame(step);
    };
    lookRaf = requestAnimationFrame(step);
  }
  let lpcT = 0, lpc = null;
  function loadProfileCached() { const n = performance.now(); if (!lpc || n - lpcT > 500) { lpc = Saves.loadProfile(); lpcT = n; } return lpc; }

  // ---------- доска почёта: рекорды и рейтинг подруг ----------
  let hallTab = 'rec';
  function myCard(pr) {
    pr = pr || Saves.loadProfile();
    if (!pr.pid) { pr.pid = Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4); Saves.saveProfile(pr); }
    const g = gloryOf(pr), lk = myLook(pr), ab = pr.abyssBest, rb = pr.rushBest;
    return { id: pr.pid, nm: cardName(pr), f: g.fame, n: g.n, s: pr.stars || 0, em: lk.em, fr: lk.fr, ti: lk.ti, au: lk.au,
      ab: ab ? ab.wave : 0, rs: rb && rb.n >= rb.total ? rb.time : 0, dl: (pr.life || {}).dBest || 0, ch: nDone(pr), at: Date.now() };
  }
  // карточку присылает чужой телефон – проверяем всё
  function cleanCard(c) {
    if (!c || typeof c !== 'object') return null;
    const id = String(c.id || '').replace(/[^a-z0-9]/g, '').slice(0, 16); if (id.length < 6) return null;
    const num = (v, mx) => clamp(Math.round(+v || 0), 0, mx);
    const pick2 = (k, v) => (LOOK_SETS[k].some(x => x.id === v) ? v : LOOK_DEF[k]);
    return { id, nm: String(c.nm || 'Подруга').replace(/[<>]/g, '').slice(0, 14), f: num(c.f, 99999), n: num(c.n, 999), s: num(c.s, 9999),
      em: pick2('em', c.em), fr: pick2('fr', c.fr), ti: pick2('ti', c.ti), au: pick2('au', c.au), ab: num(c.ab, 9999), rs: num(c.rs, 99999), dl: num(c.dl, 999999), ch: num(c.ch, 99), at: num(c.at, 9e12) };
  }
  function addFriends(cards) {
    const pr = Saves.loadProfile(), me = pr.pid; let ch = false;
    pr.friends = pr.friends || {};
    for (const raw of cards) {
      const c = cleanCard(raw); if (!c || c.id === me) continue;
      const old = pr.friends[c.id];
      if (!old || old.at < c.at) { pr.friends[c.id] = c; ch = true; }
    }
    const ids = Object.keys(pr.friends);
    if (ids.length > 40) { ids.sort((a, b) => pr.friends[a].at - pr.friends[b].at); for (const id of ids.slice(0, ids.length - 40)) delete pr.friends[id]; }
    if (ch) Saves.saveProfile(pr);
    return ch;
  }
  function cardCode(card) {
    const json = JSON.stringify(card);
    const payload = btoa(unescape(encodeURIComponent(json))).replace(/=+$/, '');
    return `KR1-${payload}-${fnv1a32(json).toString(36)}`;
  }
  function readCode(code) {
    const match = String(code || '').replace(/\s+/g, '').match(/KR1-([A-Za-z0-9+/]+)-([a-z0-9]+)/);
    if (!match) return null;
    try {
      const json = decodeURIComponent(escape(atob(match[1])));
      if (fnv1a32(json).toString(36) !== match[2]) return null;
      return cleanCard(JSON.parse(json));
    } catch (e) {
      return null;
    }
  }
  function openHall(tab) { lifeFlush(); hallTab = tab || 'rec'; renderHall(); Screens.setState('hall'); }
  function renderHall() {
    const pr = Saves.loadProfile(), g = gloryOf(pr), lk = myLook(pr);
    $('hlMe').innerHTML = `${avatarHtml(lk, 54)}<div><b>${Multiplayer.escHtml(cardName(pr))}</b><span>${Multiplayer.escHtml(titleText(lk.ti, g.rk))}</span><small>${g.rank.ic} ${g.rank.nm} · ✨ ${RunStats.fmtN(g.fame)} · 🏆 ${g.n}/${ACHS.length} · ⭐ ${pr.stars || 0}</small></div>`;
    $('hlTabR').classList.toggle('on', hallTab === 'rec'); $('hlTabF').classList.toggle('on', hallTab === 'fr');
    $('hlFriendBox').classList.toggle('hidden', hallTab !== 'fr');
    const box = $('hlList'); box.innerHTML = '';
    if (hallTab === 'rec') {
      const L = pr.life || {}, rb = pr.rushBest, rc = pr.rushBestCoop, ab = pr.abyssBest, dd = pr.daily || {}, tot = RunStats.loadTotals();
      const row = (ic, nm, v, sub) => { const d = document.createElement('div'); d.className = 'hlRec'; d.innerHTML = `<i>${ic}</i><div><b>${nm}</b>${sub ? `<span>${sub}</span>` : ''}</div><em>${v}</em>`; box.appendChild(d); };
      const sec = t => { const d = document.createElement('div'); d.className = 'hlSec'; d.textContent = t; box.appendChild(d); };
      sec('Режимы');
      row('🕳️', 'Бездна', ab ? `волна ${ab.wave}` : '–', ab ? `${RunStats.fmtT(ab.time)} · ${HEROES[ab.hero] ? HEROES[ab.hero].name : ''}` : 'ещё не ныряла');
      row('⚔️', 'Босс-раш', rb ? `${rb.n}/${rb.total}` : '–', rb ? RunStats.fmtT(rb.time) : 'ещё не было');
      row('👥', 'Раш вместе', rc ? `${rc.n}/${rc.total}` : '–', rc ? `${RunStats.fmtT(rc.time)} · игроков ${rc.players || 2}` : '');
      row('📅', 'Испытание дня', L.dBest ? RunStats.fmtN(L.dBest) : '–', `лучшая серия: ${L.dStreak || 0} дн. · сыграно ${L.daily || 0}`);
      sec('Быстрее всех');
      for (const n of Session.CH_NUMS) {
        if (!pr['ch' + n + 'Done']) continue;
        const f = (pr.fast || {})[n], nm = (AdventureMenu.SECRET_CARDS[n] && AdventureMenu.SECRET_CARDS[n].title) || CHAPTERS[n].name;
        row(AdventureMenu.CH_META[n] ? AdventureMenu.CH_META[n].ic : '📍', `Глава ${n}`, f ? RunStats.fmtT(f.t) : '–', f ? `${Multiplayer.escHtml(nm)} · ${DIFFS[f.d] ? DIFFS[f.d].name : ''}${f.co ? ' · вместе' : ''}` : Multiplayer.escHtml(nm));
      }
      sec('За всё время');
      row('⚔️', 'Побеждено врагов', RunStats.fmtN(L.kills || 0), `элитных ${RunStats.fmtN(L.elites || 0)} · чемпионов ${RunStats.fmtN(L.champs || 0)}`);
      row('🐉', 'Побеждено боссов', RunStats.fmtN(L.bosses || 0), `без урона: ${L.noHit || 0}`);
      row('🔥', 'Лучшее комбо', RunStats.fmtN(L.combo || 0), '');
      row('📦', 'Сундуков открыто', RunStats.fmtN(L.chests || 0), `мимиков побеждено: ${L.mimics || 0}`);
      row('💫', 'Подруг поднято', RunStats.fmtN(L.revives || 0), `глав вместе: ${L.coop || 0}`);
      row('⏳', 'Время в игре', RunStats.fmtT(tot.playTime || 0), `запусков: ${tot.sessions || 0}`);
    } else {
      const me = myCard(pr), list = [me].concat(Object.values(pr.friends || {}).map(cleanCard).filter(Boolean));
      list.sort((a, b) => b.f - a.f || b.n - a.n);
      list.forEach((c, i) => {
        const d = document.createElement('div'); d.className = 'hlFr' + (c.id === me.id ? ' me' : '') + (i < 3 ? ' top' + (i + 1) : '');
        const rk = rankOf(c.f);
        d.innerHTML = `<u>${['🥇', '🥈', '🥉'][i] || i + 1}</u>${avatarHtml(c, 42)}<div><b>${Multiplayer.escHtml(c.nm)}${c.id === me.id ? ' (ты)' : ''}</b><span>${Multiplayer.escHtml(titleText(c.ti, rk))}</span>` +
          `<small>🏆 ${c.n} · ⭐ ${c.s} · 🗺️ ${c.ch} гл.${c.ab ? ' · 🕳️ ' + c.ab : ''}${c.rs ? ' · ⚔️ ' + RunStats.fmtT(c.rs) : ''}</small></div><em>✨ ${RunStats.fmtN(c.f)}</em>`;
        if (c.id !== me.id) {
          const x = document.createElement('button'); x.className = 'hlDel'; x.textContent = '✖';
          x.addEventListener('click', () => { const p2 = Saves.loadProfile(); if (p2.friends) delete p2.friends[c.id]; Saves.saveProfile(p2); Sound.sfx.click(); renderHall(); });
          d.appendChild(x);
        }
        box.appendChild(d);
      });
      if (list.length === 1) { const d = document.createElement('div'); d.className = 'hint'; d.textContent = 'Пока тут только ты. Сыграйте вместе по Wi-Fi – карточки подруг появятся сами. Или обменяйтесь кодами карточек 👇'; box.appendChild(d); }
    }
  }

  return {
    DAYC, DAYM, life, lifeMax, lifeSoon, ACHS, ACH_BY, gloryOf, myLook, titleText, lifeFlush,
    achCheck, achPop, gloryMigrate, gloryWin, renderAch, openTalents, renderTalents, openLook,
    renderLook, loadProfileCached, myCard, cleanCard, addFriends, cardCode, readCode, openHall,
    renderHall,
    get lifeT() { return lifeT; },
    set lifeT(value) { lifeT = value; },
    get achCat() { return achCat; },
    set achCat(value) { achCat = value; },
    get lookTab() { return lookTab; },
    set lookTab(value) { lookTab = value; },
    get lookRaf() { return lookRaf; },
    get lpc() { return lpc; },
    set lpc(value) { lpc = value; },
    get hallTab() { return hallTab; },
    set hallTab(value) { hallTab = value; },
  };
})();
