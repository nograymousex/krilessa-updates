'use strict';

const Seasons = (() => {
  // ---------- Сезоны: задания дня и недели, событие недели, подарки за дни, дорога наград ----------
  const dayNum = (d = new Date()) => Math.floor(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()) / 864e5);
  const weekKey = (date = new Date()) => Math.floor((dayNum(date) + 3) / 7); // недели с понедельника
  const seasonKey = (d = new Date()) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
  const seasonMonth = () => new Date().getMonth();
  const seasonTheme = () => SEASON_THEMES[seasonMonth()];
  const weekEvent = () => WEEK_EVENTS[((weekKey() % WEEK_EVENTS.length) + WEEK_EVENTS.length) % WEEK_EVENTS.length];
  // сезоны (подарки за дни, задания, событие недели, дорога) пока убраны из игры: доделываются. Прогресс в профиле сохраняется
  const SEASON_OFF = true;
  const weekEv = id => !SEASON_OFF && weekEvent().id === id;
  function seasonState(pr) {
    const today = new Date();
    const sk = seasonKey(today), dk = Challenges.dayKey(today), wk = weekKey(today);
    let S = pr.season;
    if (!S || S.id !== sk) { // новый месяц – новый сезон; прошлый – в историю
      if (S && S.id) { pr.seasonHist = pr.seasonHist || {}; pr.seasonHist[S.id] = { lvl: seasonLvl(S.pts).lvl, pts: S.pts }; }
      S = pr.season = { id: sk, pts: 0, lvl: 0, bonus: 0 };
    }
    if (!pr.sday || pr.sday.key !== dk) pr.sday = { key: dk, c: {}, m: {}, done: {}, rer: -1 };
    if (!pr.sweek || pr.sweek.key !== wk) pr.sweek = { key: wk, c: {}, m: {}, done: 0 };
    pr.gift = pr.gift || { n: 0, last: '' };
    return S;
  }
  function seasonLvl(pts) {
    const lvl = Math.min(SEASON_MAX, Math.floor(pts / SEASON_LVL)), over = pts - SEASON_MAX * SEASON_LVL;
    return { lvl, bonus: over > 0 ? Math.min(SEASON_BONUS, Math.floor(over / (SEASON_LVL * 2))) : 0, into: lvl >= SEASON_MAX ? Math.max(0, over) : pts % SEASON_LVL };
  }
  // задания дня: одинаковые у всех в этот день; одно можно заменить
  function shuffled(arr, rnd) { const a = arr.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }
  function dayQuests(pr) {
    const D = pr.sday, rnd = mulberry32(fnv1a32('kq' + D.key));
    const order = shuffled(QUEST_POOL.filter(q => !q.need || pr[q.need] || GameLoop.DEBUG || pr.admin), rnd);
    const picks = order.slice(0, 3);
    if (D.rer >= 0 && D.rer < picks.length && order.length > 3) picks[D.rer] = order[3];
    return picks.map((q, i) => {
      const goal = i === 2 ? q.n[q.n.length - 1] : q.n[Math.floor(rnd() * q.n.length)];
      return { slot: i, k: q.k, ic: q.ic, max: !!q.max, goal, pts: QUEST_PTS[i], text: q.t(goal) };
    });
  }
  function weekQuest(pr) {
    const pool = WEEK_POOL.filter(q => !q.need || pr[q.need] || GameLoop.DEBUG || pr.admin), q = pool[fnv1a32('kw' + pr.sweek.key) % pool.length];
    return { slot: 'w', k: q.k, ic: q.ic, max: !!q.max, goal: q.n, pts: WEEK_PTS, text: q.t(q.n) };
  }
  const questVal = (q, box) => (q.max ? box.m[q.k] : box.c[q.k]) || 0;
  // всё, что накопилось в игре, – в задания и искры сезона; выполненное – в награды
  function seasonFlush(pr, quiet) {
    if (SEASON_OFF) { for (const k of Object.keys(Achievements.DAYC)) delete Achievements.DAYC[k]; return false; }
    const S = seasonState(pr), D = pr.sday, Wk = pr.sweek;
    let ch = false;
    for (const k of Object.keys(Achievements.DAYC)) { D.c[k] = (D.c[k] || 0) + Achievements.DAYC[k]; Wk.c[k] = (Wk.c[k] || 0) + Achievements.DAYC[k]; if (k === 'spts') S.pts += Achievements.DAYC[k]; delete Achievements.DAYC[k]; ch = true; }
    for (const k of Object.keys(Achievements.DAYM)) { D.m[k] = Math.max(D.m[k] || 0, Achievements.DAYM[k]); Wk.m[k] = Math.max(Wk.m[k] || 0, Achievements.DAYM[k]); delete Achievements.DAYM[k]; ch = true; }
    const got = [];
    for (const q of dayQuests(pr)) if (!D.done[q.slot] && questVal(q, D) >= q.goal) { D.done[q.slot] = 1; S.pts += q.pts; got.push(q); }
    const wq = weekQuest(pr);
    if (!Wk.done && questVal(wq, Wk) >= wq.goal) { Wk.done = 1; S.pts += wq.pts; got.push(wq); }
    if (got.length) { pr.life = pr.life || {}; pr.life.questsDone = (pr.life.questsDone || 0) + got.length; ch = true; }
    if (!S.fx34) { S.fx34 = 1; for (let L = 1; L <= (S.lvl || 0); L++) if (['furn', 'sfurn', 'pet'].includes(SEASON_REWARDS[L])) seasonReward(pr, S, L); } // 0.34: нечётные уровни стали наградами для домика
    const lv = seasonLvl(S.pts), ups = [];
    for (let L = (S.lvl || 0) + 1; L <= lv.lvl; L++) { const r = seasonReward(pr, S, L); if (r) ups.push(r); }
    for (let b = (S.bonus || 0) + 1; b <= lv.bonus; b++) { pr.starsGot = pr.starsGot || {}; pr.starsGot[`s:${S.id}:b${b}`] = 1; ups.push({ L: SEASON_MAX + b, ic: '⭐', nm: 'Бонусная звезда', rw: '+1⭐ для талантов' }); }
    if (lv.lvl !== (S.lvl || 0) || lv.bonus !== (S.bonus || 0)) { S.lvl = lv.lvl; S.bonus = lv.bonus; pr.stars = Object.keys(pr.starsGot || {}).length; ch = true; }
    pr.life = pr.life || {}; pr.life.seasonLvl = Math.max(pr.life.seasonLvl || 0, S.lvl);
    if (!quiet) {
      const T = seasonTheme();
      for (const q of got) Achievements.achPop({ custom: { ic: q.ic, rar: q.slot === 'w' ? 'Задание недели выполнено' : 'Задание дня выполнено', nm: q.text, rw: `+${q.pts} ✦ искр сезона`, col: '#7dff9a' } });
      for (const u of ups) Achievements.achPop({ custom: { ic: u.ic, rar: `${T.nm} · уровень ${u.L}`, nm: u.nm, rw: u.rw, col: T.fr.col, big: true } });
    }
    return ch;
  }
  function seasonReward(pr, S, L) {
    const kind = SEASON_REWARDS[L]; if (!kind) return null;
    const m = +S.id.slice(5) - 1, T = SEASON_THEMES[m];
    if (kind === 'furn') { const pool = HomeScreen.furnPool(pr); if (!pool.length) { S.pts += 30; return { L, ic: '✦', nm: 'Всё для домика уже есть!', rw: '+30 ✦' }; } const it = pool[Math.floor(Math.random() * pool.length)]; HomeScreen.furnGive(pr, it); return { L, ic: it.ic || '🎨', nm: 'Для домика: ' + it.nm, rw: '🏠 поставь в «Домике»' }; }
    if (kind === 'sfurn') { const it = FURN_BY['sz' + m]; HomeScreen.furnGive(pr, it); return { L, ic: it.ic, nm: 'Сезонный декор: ' + it.nm, rw: '🏠 только в этом сезоне' }; }
    if (kind === 'pet') { pr.ach = pr.ach || {}; pr.ach[`ss_${m}_pet`] = Date.now(); const pt = PET_BY['sp' + m]; return { L, ic: pt.ic, nm: 'Питомец: ' + pt.nm, rw: '🐾 будет жить в «Домике»' }; }
    if (kind === 'star') { pr.starsGot = pr.starsGot || {}; pr.starsGot[`s:${S.id}:${L}`] = 1; return { L, ic: '⭐', nm: 'Звезда для талантов', rw: '+1⭐' }; }
    pr.ach = pr.ach || {}; pr.ach[`ss_${m}_${kind}`] = Date.now();
    const it = lookItem(kind, ({ em: 'se_', ti: 'st_', au: 'sa_', fr: 'sf_' })[kind] + m);
    const what = { em: 'эмблема', ti: 'титул', au: 'аура', fr: 'рамка' }[kind];
    return { L, ic: kind === 'em' ? T.ic : kind === 'au' ? T.au[0] : kind === 'fr' ? '🖼️' : '📜', nm: `Новая ${what} – только этого сезона!`, rw: kind === 'ti' ? `титул «${it.nm}»` : kind === 'fr' ? `рамка «${it.nm}»` : it.nm || T.ic };
  }
  // подарок дня – при первом заходе в меню
  function seasonDaily() {
    if (SEASON_OFF) return;
    const pr = Saves.loadProfile(); seasonState(pr);
    const today = Challenges.dayKey();
    if (pr.gift.last !== today) {
      pr.gift.n = (pr.gift.n || 0) + 1; pr.gift.last = today;
      const d = (pr.gift.n - 1) % 7, pts = GIFT_PTS[d];
      pr.season.pts += pts;
      if (d === 6) { pr.starsGot = pr.starsGot || {}; pr.starsGot['gift:' + pr.gift.n] = 1; pr.stars = Object.keys(pr.starsGot).length; }
      setTimeout(() => Achievements.achPop({ custom: { ic: '🎁', rar: `Подарок дня · день ${d + 1} из 7`, nm: d === 6 ? 'Большой подарок!' : 'Спасибо, что заглянула!', rw: `+${pts} ✦` + (d === 6 ? ' · +1⭐' : ''), col: '#ffd25a', big: d === 6 } }), 900);
    }
    seasonFlush(pr);
    Achievements.achCheck(pr);
    Saves.saveProfile(pr);
    renderSeasonBar(pr);
  }
  const leftTxt = ms => { const m = Math.max(0, Math.floor(ms / 60000)), d = Math.floor(m / 1440), h = Math.floor(m % 1440 / 60), mm = m % 60; return d ? `${d} д ${h} ч` : h ? `${h} ч ${mm} мин` : `${mm} мин`; };
  const msToDay = () => { const n = new Date(), e = new Date(n.getFullYear(), n.getMonth(), n.getDate() + 1); return e - n; };
  const msToWeek = () => { const n = new Date(), dow = (n.getDay() + 6) % 7, e = new Date(n.getFullYear(), n.getMonth(), n.getDate() + 7 - dow); return e - n; };
  const msToSeason = () => { const n = new Date(), e = new Date(n.getFullYear(), n.getMonth() + 1, 1); return e - n; };
  function renderSeasonBar(pr) {
    if (SEASON_OFF) { $('seasonBar').classList.add('hidden'); return; }
    pr = pr || Saves.loadProfile(); const S = seasonState(pr), T = seasonTheme(), lv = seasonLvl(S.pts);
    const qs = dayQuests(pr), done = qs.filter(q => pr.sday.done[q.slot]).length;
    const bar = $('seasonBar'); bar.style.setProperty('--sa', T.c[0]); bar.style.setProperty('--sb', T.c[1]);
    $('sbIc').textContent = T.ic;
    $('sbTx').innerHTML = `<b>${T.nm}</b> · ур. ${lv.lvl}${lv.lvl >= SEASON_MAX ? ' ✓' : ''} · 📜 ${done}/3 · ${weekEvent().ic}`;
    $('sbFill').style.width = (lv.lvl >= SEASON_MAX ? 100 : Math.round(lv.into / SEASON_LVL * 100)) + '%';
    $('sbLeft').textContent = 'ещё ' + leftTxt(msToSeason());
    bar.classList.toggle('todo', done < 3);
  }
  // ---------- экран сезона ----------
  let seasonTick = 0;
  function openSeason() { Achievements.lifeFlush(); renderSeason(); Screens.setState('season'); clearInterval(seasonTick); seasonTick = setInterval(() => { if (Session.state !== 'season') { clearInterval(seasonTick); return; } seasonTimes(); }, 1000); }
  function seasonTimes() {
    $('snLeft').textContent = `до конца сезона: ${leftTxt(msToSeason())}`;
    $('snDayLeft').textContent = `новые через ${leftTxt(msToDay())}`;
    $('snWeekLeft').textContent = `ещё ${leftTxt(msToWeek())}`;
  }
  function renderSeason() {
    const pr = Saves.loadProfile(), S = seasonState(pr), T = seasonTheme(), lv = seasonLvl(S.pts), m = seasonMonth();
    const hd = $('snHead'); hd.style.setProperty('--sa', T.c[0]); hd.style.setProperty('--sb', T.c[1]);
    $('snIc').textContent = T.ic; $('snName').textContent = `Сезон «${T.nm}»`;
    $('snLvl').innerHTML = lv.lvl >= SEASON_MAX ? `Дорога пройдена! ✦ ${S.pts}` + (lv.bonus < SEASON_BONUS ? ` · бонусная звезда через ${SEASON_LVL * 2 - lv.into % (SEASON_LVL * 2)} ✦` : ' · все бонусы собраны') : `Уровень <b>${lv.lvl}</b> из ${SEASON_MAX} · ✦ ${lv.into} / ${SEASON_LVL}`;
    $('snFill').style.width = (lv.lvl >= SEASON_MAX ? 100 : Math.round(lv.into / SEASON_LVL * 100)) + '%';
    // подарки
    const gb = $('snGift'); gb.innerHTML = '';
    const today = (pr.gift.n - 1) % 7, gotToday = pr.gift.last === Challenges.dayKey();
    for (let d = 0; d < 7; d++) {
      const el = document.createElement('div'); const past = gotToday ? d <= today : d < ((pr.gift.n) % 7);
      el.className = 'snG' + (past ? ' got' : '') + (gotToday && d === today ? ' now' : '') + (d === 6 ? ' big' : '');
      el.innerHTML = `<small>${d + 1}</small><i>${d === 6 ? '⭐' : '🎁'}</i><b>+${GIFT_PTS[d]}</b>`;
      gb.appendChild(el);
    }
    // задания дня
    const db = $('snDay'); db.innerHTML = '';
    for (const q of dayQuests(pr)) db.appendChild(questRow(q, pr.sday, pr.sday.rer < 0 && !pr.sday.done[q.slot]));
    // неделя
    const wb = $('snWeek'); wb.innerHTML = ''; wb.appendChild(questRow(weekQuest(pr), pr.sweek, false));
    const E = weekEvent();
    $('snEvent').innerHTML = `<i>${E.ic}</i><div><b>${E.nm}</b><span>${E.ds}</span><small id="snEvLeft"></small></div>`;
    // дорога
    const rb = $('snRoad'); rb.innerHTML = '';
    for (let L = 1; L <= SEASON_MAX; L++) {
      const k = SEASON_REWARDS[L], has = lv.lvl >= L, el = document.createElement('div');
      el.className = 'snR' + (has ? ' got' : '') + (L === lv.lvl + 1 ? ' next' : '') + (k && k !== 'star' && k !== 'furn' ? ' cos' : '') + (!k ? ' empty' : '');
      let ic = '·', lab = '';
      if (k === 'star') { ic = '⭐'; lab = '+1⭐'; }
      else if (k === 'furn') { ic = '🛋️'; lab = 'для домика'; }
      else if (k === 'sfurn') { ic = FURN_BY['sz' + m].ic; lab = 'декор'; }
      else if (k === 'pet') { ic = PET_BY['sp' + m].ic; lab = 'питомец'; }
      else if (k) {
        const id = ({ em: 'se_', ti: 'st_', au: 'sa_', fr: 'sf_' })[k] + m;
        if (k === 'em') { ic = avatarHtml({ em: id, fr: 'wood' }, 30); lab = 'эмблема'; }
        else if (k === 'fr') { ic = avatarHtml({ em: Achievements.myLook(pr).em, fr: id }, 30); lab = 'рамка'; }
        else if (k === 'au') { ic = T.au[0]; lab = 'аура'; }
        else { ic = '📜'; lab = 'титул'; }
      }
      el.innerHTML = `<u>${L}</u><i>${ic}</i><small>${lab}</small>`;
      rb.appendChild(el);
    }
    $('snBonus').textContent = `После 20-го уровня – ещё звезда за каждые ${SEASON_LVL * 2} ✦ (до ${SEASON_BONUS}). Вещи сезона бывают только в ${['январе', 'феврале', 'марте', 'апреле', 'мае', 'июне', 'июле', 'августе', 'сентябре', 'октябре', 'ноябре', 'декабре'][m]}!`;
    seasonTimes();
  }
  function questRow(q, box, canSwap) {
    const v = Math.min(questVal(q, box), q.goal), done = !!(q.slot === 'w' ? box.done : box.done[q.slot]);
    const el = document.createElement('div'); el.className = 'snQ' + (done ? ' done' : '') + (q.slot === 'w' ? ' week' : '');
    el.innerHTML = `<i>${done ? '✅' : q.ic}</i><div><b>${Multiplayer.escHtml(q.text)}</b>` + (q.goal > 1 ? `<em class="bar"><u style="width:${Math.round(v / q.goal * 100)}%"></u></em><small>${RunStats.fmtN(v)} / ${RunStats.fmtN(q.goal)}</small>` : '') + `</div><s>+${q.pts} ✦</s>`;
    if (canSwap) {
      const b = document.createElement('button'); b.className = 'snSwap'; b.textContent = '🔄'; b.title = 'Заменить задание (раз в день)';
      b.addEventListener('click', () => { const p2 = Saves.loadProfile(); seasonState(p2); if (p2.sday.rer >= 0 || p2.sday.done[q.slot]) return; p2.sday.rer = q.slot; Saves.saveProfile(p2); Sound.sfx.click(); RunStats.toast('🔄 Задание заменено – следующая замена завтра'); renderSeason(); });
      el.appendChild(b);
    }
    return el;
  }

  return {
    seasonMonth, weekEvent, SEASON_OFF, weekEv, seasonState, seasonLvl, dayQuests, weekQuest,
    seasonFlush, seasonDaily, openSeason,
  };
})();
