'use strict';

const Expedition = (() => {
  // ------------------------------------------------------------------
  //  Глава 6: две героини, скользкий лёд, таяние, костры, метель
  // ------------------------------------------------------------------
  const heroAvatar = id => Session.AVATAR[id === 'ryzhovaya' ? 'ryzhova' : id] || heroPortrait(id);
  const teamOther = () => G.team.list.find(id => id !== P.hero);
  function initTeam(sv) {
    if (!World.CFG.team || NET.on) { G.team = null; return; } // вместе у каждой своя героиня
    const T6 = G.team = { list: World.CFG.team.slice(), f: {}, ko: {}, cd: 0, bx: P.x - 34, by: P.y, fireT: 1.5 };
    for (const id of T6.list) {
      T6.f[id] = sv && sv.f && typeof sv.f[id] === 'number' ? clamp(sv.f[id], 0, 1) : 1;
      T6.ko[id] = !!(sv && sv.ko && sv.ko[id]);
    }
    if (T6.ko[P.hero] || T6.f[P.hero] < 0.05) { T6.ko[P.hero] = false; T6.f[P.hero] = Math.max(T6.f[P.hero], 0.35); }
    P.hp = Math.max(1, Math.round(P.maxHp * T6.f[P.hero]));
  }
  function teamSnapshot() {
    if (!G.team) return null;
    const f = Object.assign({}, G.team.f); f[P.hero] = clamp(P.hp / P.maxHp, 0, 1);
    return { f, ko: Object.assign({}, G.team.ko), h: P.hero };
  }
  function switchHero(forced) {
    const T6 = G.team;
    if (!T6 || G.cutscene || (Session.state !== 'play' && !forced)) return false;
    const o = teamOther();
    if (!forced) {
      if (T6.cd > 0 || P.dashT > 0) return false;
      if (T6.ko[o] || T6.f[o] < 0.25) {
        Effects.floatText(P.x, P.y - 44, `${HEROES[o].name} ещё отдыхает 💤`, '#bfeaff', true); Sound.sfx.click();
        T6.cd = 0.6; return false;
      }
    }
    T6.f[P.hero] = clamp(P.hp / P.maxHp, 0, 1);
    T6.bx = P.x; T6.by = P.y;
    P.hero = o; Actors.computeStats();
    P.hp = Math.max(1, Math.round(P.maxHp * T6.f[o]));
    P.fireT = 0.15; P.inv = Math.max(P.inv, 0.5); T6.cd = 1.2;
    $('dashBtn').querySelector('span').textContent = HEROES[o].dash;
    Effects.burst(P.x, P.y, 22, o === 'ryzhovaya' ? '#ff8a2a' : '#7fd8ff', 200); Effects.shockRing(P.x, P.y, '#ffffff', 60);
    Sound.sfx.blink();
    if (G.st) G.st.swaps = (G.st.swaps || 0) + 1;
    return true;
  }
  // героиня упала – подруга подхватывает
  function teamCatch() {
    const T6 = G.team; if (!T6) return false;
    const o = teamOther();
    if (T6.ko[o] || T6.f[o] < 0.05) return false;
    const was = P.hero;
    switchHero(true);
    T6.f[was] = 0; T6.ko[was] = true; P.inv = 2;
    Screens.showBanner(`${HEROES[P.hero].name} подхватывает!`, `${HEROES[was].name} без сил – отдохнёт у костра`);
    Effects.burst(P.x, P.y, 30, '#ffffff', 240); G.shake = 10;
    return true;
  }
  // ---------- лёд Рыжовая растапливает ----------
  function canMelt(i) {
    const tx = i % World.MW, ty = Math.floor(i / World.MW);
    if (World.cracks.has(i)) return World.tiles[i] === ROCK || World.tiles[i] === WALL;
    return (!World.landscape || World.landscape.mask[i] === Landscapes.LAND) && tx >= 2 && ty >= 2 && tx < World.MW - 2 && ty < World.PLAY_H - 2 && World.tiles[i] === ROCK && !!BIOMES[World.biomeMap[i]].meltable;
  }
  function tryMelt(f) {
    const tx = Math.floor(f.x / World.T), ty = Math.floor(f.y / World.T);
    if (!World.inMap(tx, ty)) return;
    const i = ty * World.MW + tx;
    if (!canMelt(i)) return;
    const ice = Actors.lv('c6ice');
    if (f.ally || (f.kind !== 'fire' && !ice)) { if (Math.random() < 0.3) Effects.part(f.x, f.y, rnd(-30, 30), rnd(-40, 0), 0.4, 3, '#e8f8ff'); return; }
    const h = (G.meltHits[i] || 0) + (f.kind === 'fire' ? 1 : 0.5);
    G.meltHits[i] = h;
    Effects.burst(f.x, f.y, 8, '#e8f8ff', 100);
    for (let k = 0; k < 3; k++) Effects.part(World.tc(tx) + rnd(-14, 14), World.tc(ty) + rnd(-10, 10), rnd(-10, 10), rnd(-70, -30), 0.9, 6, 'rgba(235,245,255,0.7)');
    if (h >= Math.max(1, 3 - ice)) meltTile(i, true);
  }
  function meltTile(i, fx) {
    if (!canMelt(i)) return;
    if (NET.on && G.netRun && !NET.applyMelt) NET.meltOut.push(i); // растаяло у меня – расскажем остальным
    World.tiles[i] = World.biomeMap[i]; delete G.meltHits[i];
    if (!G.melted.includes(i)) G.melted.push(i);
    const tx = i % World.MW, ty = Math.floor(i / World.MW);
    for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) Terrain.chunkCache.delete(Math.floor((tx + dx) / Terrain.CHUNK) + ',' + Math.floor((ty + dy) / Terrain.CHUNK));
    Terrain.chunkJob = null; // кусок, который строился, мог задеть растаявшую клетку
    const mc = Terrain.miniBase.getContext('2d'); mc.fillStyle = BIOMES[World.tiles[i]].mini; mc.fillRect(tx, ty, 1, 1);
    const sc = World.secrets.find(o => o.i === i);
    if (sc) { secretOpened(sc, fx); return; }
    if (fx) {
      const x = World.tc(tx), y = World.tc(ty);
      Effects.burst(x, y, 26, '#ffffff', 190); Effects.burst(x, y, 10, '#7fd8ff', 140);
      for (let k = 0; k < 10; k++) Effects.part(x + rnd(-18, 18), y + rnd(-14, 14), rnd(-20, 20), rnd(-90, -40), 1.3, 8, 'rgba(235,245,255,0.6)');
      Sound.sfx.glass();
      if ((G.meltSayT || 0) <= 0) { G.meltSayT = 6; Effects.floatText(x, y - 20, 'растаяло! 💧', '#bfeaff', true); }
    }
  }
  // треснувшая стена: четыре удара – и проход открыт
  function tryCrack(f) {
    const tx = Math.floor(f.x / World.T), ty = Math.floor(f.y / World.T), i = ty * World.MW + tx;
    if (!World.cracks.has(i) || f.ally || !canMelt(i)) return false;
    G.crackHits[i] = (G.crackHits[i] || 0) + 1;
    Effects.burst(f.x, f.y, 8, '#c8b090', 110); G.shake = Math.max(G.shake, 2); Sound.sfx.hit();
    for (let k = 0; k < 3; k++) Effects.part(World.tc(tx) + rnd(-14, 14), World.tc(ty) + rnd(-10, 10), rnd(-40, 40), rnd(-60, -20), 0.7, 5, 'rgba(140,110,80,0.8)');
    if (G.crackHits[i] >= 4) meltTile(i, true);
    return true;
  }
  function secretOpened(sc, fx) {
    if (sc.open) return; sc.open = true; sc.chest.seen = true;
    const mc = Terrain.miniBase.getContext('2d');
    for (let y = sc.cy - 1; y <= sc.cy + 1; y++) for (let x = sc.cx - 1; x <= sc.cx + 1; x++) { mc.fillStyle = BIOMES[World.tiles[y * World.MW + x]] ? BIOMES[World.tiles[y * World.MW + x]].mini : '#888'; mc.fillRect(x, y, 1, 1); }
    Terrain.revealFog(sc.chest.x, sc.chest.y, 4);
    if (!fx) return;
    const x = World.tc(sc.ex), y = World.tc(sc.ey);
    Effects.burst(x, y, 40, '#c8b090', 240); Effects.burst(sc.chest.x, sc.chest.y, 30, '#ffd25a', 200); Effects.shockRing(x, y, '#ffd25a', 160);
    for (let k = 0; k < 14; k++) Effects.part(x + rnd(-18, 18), y + rnd(-14, 14), rnd(-90, 90), rnd(-120, -30), 1.1, 7, pick(['#8a6a4a', '#a0826a', '#6a5040']));
    G.shake = Math.max(G.shake, 9); Sound.sfx.boom(); Sound.sfx.chest(); Challenges.buzz(90);
    Screens.showBanner('🗝️ Тайник!', 'За стеной спрятана комната с сундуком');
    if (!NET.applyMelt) Achievements.life('secrets');
  }
  // треснувшая стена рядом и врагов нет – героиня бьёт по ней сама
  function crackTarget() {
    let best = null, bd = (P.range + 30) ** 2;
    for (const sc of World.secrets) {
      if (sc.open) continue;
      const x = World.tc(sc.ex), y = World.tc(sc.ey), d = (x - P.x) ** 2 + (y - P.y) ** 2;
      if (d < bd) { bd = d; best = { x, y, z: 0 }; }
      if (!sc.hinted && d < 260 * 260) { sc.hinted = true; Effects.floatText(x, y - 30, '🪨 Тут трещина…', '#ffe9a0', true); }
    }
    return best;
  }
  function drawCracks(c, vis) {
    for (const sc of World.secrets) {
      if (sc.open) continue;
      const x = sc.ex * World.T, y = sc.ey * World.T; if (!vis(x + World.T / 2, y + World.T / 2, 40)) continue;
      const h = G.crackHits[sc.i] || 0, r = mulberry32(sc.i * 7 + 3);
      c.save();
      c.globalAlpha = 0.16 + 0.1 * Math.sin(G.time * 2.2 + sc.i); c.fillStyle = '#ffe9a0'; c.fillRect(x + 7, y + 7, World.T - 14, World.T - 14);
      c.globalAlpha = 0.85; c.strokeStyle = 'rgba(25,15,8,0.9)'; c.lineWidth = 2; c.lineCap = 'round'; c.beginPath();
      for (let k = 0; k < 3 + h * 2; k++) { let px = x + World.T * (0.3 + r() * 0.4), py = y + World.T * (0.3 + r() * 0.4); c.moveTo(px, py); for (let j = 0; j < 3; j++) { px += (r() - 0.5) * 18; py += (r() - 0.5) * 18; c.lineTo(px, py); } }
      c.stroke(); c.restore();
    }
  }
  const ringIntact = ch => { for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) if (Math.max(Math.abs(dx), Math.abs(dy)) === 2 && World.tileAt(ch.tx + dx, ch.ty + dy) !== ROCK) return false; return true; };
  // огонь сам целится в ледяную стену вокруг сундука, если рядом нет врагов
  function iceTarget() {
    let best = null, bd = (P.range + 20) ** 2;
    for (const ch of World.chests) {
      if (!ch.iced || ch.open || Math.abs(ch.x - P.x) > 320 || Math.abs(ch.y - P.y) > 320 || !ringIntact(ch)) continue;
      for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) {
        if (Math.max(Math.abs(dx), Math.abs(dy)) !== 2) continue;
        const x = World.tc(ch.tx + dx), y = World.tc(ch.ty + dy), d = (x - P.x) ** 2 + (y - P.y) ** 2;
        if (d < bd) { bd = d; best = { x, y, z: 0 }; }
      }
    }
    for (const g of World.glades) {
      if (g.open || Math.abs(g.x - P.x) > 420 || Math.abs(g.y - P.y) > 420) continue;
      for (const i of g.ring) {
        const x = World.tc(i % World.MW), y = World.tc(Math.floor(i / World.MW)), d = (x - P.x) ** 2 + (y - P.y) ** 2;
        if (d < bd) { bd = d; best = { x, y, z: 0 }; }
      }
    }
    for (const dr of World.drifts) {
      if (dr.done) continue;
      const d = (dr.x - P.x) ** 2 + (dr.y - P.y) ** 2;
      if (d < bd) { bd = d; best = { x: dr.x, y: dr.y + 4, z: 0 }; }
    }
    return best;
  }
  // ---------- сугробы: огонь растапливает, внутри сюрприз ----------
  function hitDrift(f) {
    for (const dr of World.drifts) {
      if (dr.done || Math.abs(dr.x - f.x) > 30 || Math.abs(dr.y - f.y) > 30) continue;
      if ((dr.x - f.x) ** 2 + (dr.y - 4 - f.y) ** 2 > 26 * 26) continue;
      f.life = 0;
      if (f.kind !== 'fire' && !Actors.lv('c6ice')) { Effects.burst(f.x, f.y, 4, '#ffffff', 80); return true; }
      if (NET.client) { NET.driftHits.push([World.drifts.indexOf(dr), f.kind === 'fire' ? 1 : 0.5]); Effects.burst(dr.x, dr.y, 10, '#ffffff', 120); return true; } // сугроб считает хозяйка
      dr.hp -= f.kind === 'fire' ? 1 : 0.5; Effects.burst(dr.x, dr.y, 10, '#ffffff', 120);
      for (let k = 0; k < 3; k++) Effects.part(dr.x + rnd(-12, 12), dr.y - 6, rnd(-10, 10), rnd(-70, -30), 0.9, 6, 'rgba(235,245,255,0.7)');
      if (dr.hp <= 0) openDrift(dr);
      return true;
    }
    return false;
  }
  function openDrift(dr) {
    dr.done = true; Effects.burst(dr.x, dr.y, 30, '#ffffff', 200); Sound.sfx.glass();
    const r = Math.random(), E = Actors.zoneE(World.biomeMap[dr.ty * World.MW + dr.tx]);
    if (r < 0.22) {
      Effects.floatText(dr.x, dr.y - 30, 'Засада! ⛄', '#ff8a8a', true);
      for (let k = 0; k < 3; k++) { const a = k * TAU / 3, x = dr.x + Math.cos(a) * 40, y = dr.y + Math.sin(a) * 40; if (Physics.walkable(x, y, false)) Enemies.spawnEnemy('snowling', x, y, World.biomeMap[dr.ty * World.MW + dr.tx], { elite: k === 0, instant: true }); }
      return;
    }
    if (r < 0.42) Effects.dropPickup(dr.x, dr.y, 'heart');
    else if (r < 0.47) Effects.dropPickup(dr.x, dr.y, 'key');
    Effects.floatText(dr.x, dr.y - 30, 'Сугроб растаял! ✨', '#bfeaff');
    for (let k = 0; k < 3; k++) Effects.dropGem(dr.x + rnd(-20, 20), dr.y + rnd(-20, 20), Actors.xpFor(E) * 0.08);
    for (let k = 0; k < 2; k++) Effects.dropShard(dr.x, dr.y);
  }
  // ---------- погода главы 6: метель, звездопад, мороз ----------
  function startWeather(id) {
    G.wxId = id; G.lastWx = id;
    if (id === 'blizzard') { G.wxT = 10; G.blizzardT = 10; Screens.showBanner('❄️ МЕТЕЛЬ', 'Ничего не видно! Грейся у костров'); Sound.sfx.whisper(); }
    else if (id === 'starfall') { G.wxT = 14; G.starT = 0.4; Screens.showBanner('🌠 ЗВЕЗДОПАД', 'Лови звёзды – они заряжают супер'); Sound.sfx.magic(); }
    else { G.wxT = 12; G.chill = 0; Screens.showBanner('🥶 МОРОЗ', 'Не стой на месте – замёрзнешь!'); Sound.sfx.whisper(); }
  }
  // ---------- Тесса вырывается из ледяной клетки ----------
  function freeTessa() {
    if (G.tessaAlly || World.CFG.hostage !== 'tessa' || !World.CFG.team) return;
    const cx = World.tc(World.CAGE.x), cy = World.tc(World.CAGE.y);
    G.tessaAlly = { x: cx, y: cy, fireT: 1.2, face: 1 };
    Effects.burst(cx, cy, 50, '#bfeaff', 300); Effects.burst(cx, cy, 24, '#ffffff', 220); Sound.sfx.shatter(); G.shake = 14;
    Screens.showBanner('🐾 Тесса вырвалась!', 'Теперь вас трое');
    Screens.say('Мяу!!! Лёд треснул – я с вами! Держись, Мрак, сейчас будет КУСЬ! 🐾', 4.5);
    if (Saves.loadProfile().ch4Choice === 'kind') { G.pet = { x: cx, y: cy, fireT: 1 }; Screens.say('Мяу.exe тоже здесь! Пиксельный котик спешит на помощь! 💚', 4); }
  }
  // ---------- глава 7: течения и слова-жемчужины ----------
  function updateSea(dt) {
    if (World.flow && Session.state === 'play' && !G.cutscene) {
      const f = World.flow.get(Math.floor(P.y / World.T) * World.MW + Math.floor(P.x / World.T));
      G.onCurrent = !!f;
      if (f) {
        const sp = 150 * Math.pow(1 + 0.4, Actors.lv('c7flow'));
        if (P.dashT <= 0) Physics.moveEntity(P, f[0] * sp * dt, f[1] * sp * dt);
        if (Actors.lv('c7flow') && P.dashCd > 0) P.dashCd -= dt * Actors.lv('c7flow') * 0.5; // попутное течение: рывок быстрее
        if (Math.random() < dt * 14) Effects.part(P.x + rnd(-10, 10), P.y + rnd(-6, 8), -f[0] * 40, -f[1] * 40, 0.5, 3, 'rgba(220,250,255,0.8)');
        if (!G.curSaid) { G.curSaid = true; Screens.say('Ух, течение! Плыви по стрелкам – так быстрее 🌊', 4); }
      }
    }
    for (let k = 0; k < World.pearls.length; k++) {
      const p = World.pearls[k]; if (p.got || Math.hypot(P.x - p.x, P.y - p.y) >= 34) continue;
      if (NET.client) { NET.pearlReq = k; p.got = true; } // жемчужину засчитает хозяин – для всех
      else collectPearl(k);
    }
    if (NET.host) for (const m of NET.peers.values()) for (let k = 0; k < World.pearls.length; k++) { const p = World.pearls[k]; if (!p.got && m.live && !m.down && Math.hypot(m.x - p.x, m.y - p.y) < 34) Multiplayer.netPearl(k, m.id); }
  }
  function collectPearl(k, remote) {
    const p = World.pearls[k]; p.got = true;
    const n = World.pearls.filter(q => q.got).length, word = PEARL_WORDS[(n - 1) % PEARL_WORDS.length];
    Effects.floatText(p.x, p.y - 34, '💗 ' + word, '#ffb0d0', true);
    Screens.showBanner(`💗 Слово ${n}/${World.pearls.length}`, word);
    Effects.burst(p.x, p.y, 26, '#ffb0d0', 200); Effects.burst(p.x, p.y, 10, '#ffffff', 140); Sound.sfx.magic();
    const love = Actors.lv('c7love');
    if (NET.host) NetT.send(-1, { t: 'ban', a: `💗 Слово ${n}/${World.pearls.length}`, b: word });
    if (!remote) { P.hp = Math.min(P.maxHp, P.hp + P.maxHp * 0.15 * (1 + love)); if (love) Hero.addSuper(20 * love); }
    for (let i = 0; i < 3; i++) Effects.dropShard(p.x, p.y);
    if (G.st) G.st.pearls = n;
    if (n === World.pearls.length) {
      Achievements.life('pearls12');
      Screens.showBanner('💗 Все слова вернулись!', 'Крилесса и Рыжовая снова говорят друг другу нежности');
      Encounters.eventLoot(p.x, p.y + 24, 'gold');
      Screens.say('– Ты меня крилюбишь? – Я тебя криливирую! 💗', 4.5);
    } else if (n === 1) Screens.say('Слово вернулось! Их тут целых ' + World.pearls.length + ' – соберём все 💗', 4);
    Saves.saveGame();
  }
  // течения: бегущие струйки, слова-жемчужины в раскрытых ракушках
  function drawSeaFloor(c, x0, y0, x1, y1) {
    if (World.curPts.length) {
      const t = G.time;
      c.strokeStyle = 'rgba(210,248,255,0.38)'; c.lineWidth = 2.2; c.lineCap = 'round'; c.beginPath();
      for (const p of World.curPts) {
        if (p.x < x0 - 60 || p.x > x1 + 60 || p.y < y0 - 60 || p.y > y1 + 60) continue;
        for (let k = 0; k < 2; k++) {
          const o = ((t * 75 + k * 40 + p.x * 0.37) % 80) - 40, sd = k ? 14 : -14;
          const sx = p.x + p.dx * o - p.dy * sd, sy = p.y + p.dy * o + p.dx * sd;
          c.moveTo(sx, sy); c.lineTo(sx + p.dx * 16, sy + p.dy * 16);
        }
      }
      c.stroke(); c.lineCap = 'butt';
    }
    const lure = World.landscape && World.landscape.plan.lure;
    if (lure && Session.bosses.some(b => b.kind === 'angler' && b.state === 'sleep')) {
      const x=World.tc(lure[0]), y=World.tc(lure[1]);
      if (x>=x0-90 && x<=x1+90 && y>=y0-80 && y<=y1+80) {
        const bob=Math.sin(G.time*4.8)*3;
        c.save();c.strokeStyle='#759ba9';c.lineWidth=1.6;c.beginPath();c.moveTo(x+72,y+26);
        c.bezierCurveTo(x+41,y+12,x+12,y-32,x,y+bob);c.stroke();
        const halo=c.createRadialGradient(x-2,y+bob-2,1,x,y+bob,19);
        halo.addColorStop(0,'#fffdf1');halo.addColorStop(0.33,'#ffa8cf');halo.addColorStop(0.55,'#a490d0');halo.addColorStop(1,'rgba(105,145,210,0)');
        c.fillStyle=halo;c.beginPath();c.arc(x,y+bob,19,0,TAU);c.fill();c.restore();
      }
    }
    for (const p of World.pearls) {
      if (p.got || p.x < x0 - 40 || p.x > x1 + 40 || p.y < y0 - 40 || p.y > y1 + 40) continue;
      const bob = Math.sin(G.time * 2.4 + p.ph) * 2;
      c.fillStyle = 'rgba(0,0,0,0.25)'; c.beginPath(); c.ellipse(p.x, p.y + 10, 16, 5, 0, 0, TAU); c.fill();
      for (const sg of [-1, 1]) { // створки ракушки
        c.fillStyle = sg < 0 ? '#f0c8b0' : '#ffdcc8'; c.beginPath(); c.ellipse(p.x, p.y + (sg < 0 ? 6 : -4), 15, 8, 0, sg < 0 ? 0 : Math.PI, sg < 0 ? Math.PI : TAU); c.fill();
        c.strokeStyle = 'rgba(180,120,100,0.6)'; c.lineWidth = 1; for (let r = -10; r <= 10; r += 5) { c.beginPath(); c.moveTo(p.x, p.y + (sg < 0 ? 6 : -4)); c.lineTo(p.x + r, p.y + (sg < 0 ? 13 : -11)); c.stroke(); }
      }
      const g = c.createRadialGradient(p.x - 2, p.y - 2 + bob, 1, p.x, p.y + bob, 9); g.addColorStop(0, '#ffffff'); g.addColorStop(0.5, '#ffd0e0'); g.addColorStop(1, '#e88ab0');
      c.fillStyle = 'rgba(255,160,200,0.35)'; c.beginPath(); c.arc(p.x, p.y + bob, 14 + Math.sin(G.time * 4 + p.ph) * 2, 0, TAU); c.fill();
      c.fillStyle = g; c.beginPath(); c.arc(p.x, p.y + bob, 7, 0, TAU); c.fill();
    }
  }
  // подводная атмосфера: лучи света сверху и пузырьки
  function drawSeaFx(c) {
    if (!World.CFG.currents) return;
    const t = G.time;
    for (let k = 0; k < 3; k++) {
      const x = Viewport.VW * (0.15 + k * 0.33) + Math.sin(t * 0.3 + k * 2) * 40;
      const g = c.createLinearGradient(x, 0, x + 120, Viewport.VH); g.addColorStop(0, 'rgba(180,240,255,0.10)'); g.addColorStop(1, 'rgba(180,240,255,0)');
      c.fillStyle = g; c.beginPath(); c.moveTo(x - 30, 0); c.lineTo(x + 30, 0); c.lineTo(x + 170, Viewport.VH); c.lineTo(x + 60, Viewport.VH); c.closePath(); c.fill();
    }
    c.fillStyle = 'rgba(220,250,255,0.5)';
    for (let i = 0; i < 14; i++) { const k = (t * (0.06 + hash2(i, 2) * 0.05) + hash2(2, i)) % 1, x = hash2(i, 5) * Viewport.VW + Math.sin(t * 1.3 + i) * 8, y = Viewport.VH * (1 - k); c.beginPath(); c.arc(x, y, 1.5 + hash2(i, 7) * 2.5, 0, TAU); c.fill(); }
  }
  function updateWinter(dt) {
    if (G.meltSayT > 0) G.meltSayT -= dt;
    const T6 = G.team;
    if (T6) {
      if (T6.cd > 0) T6.cd -= dt;
      const o = teamOther();
      if (T6.f[o] < 1) T6.f[o] = Math.min(1, T6.f[o] + (T6.ko[o] ? 0.006 : 0.02) * Math.pow(1 + 0.4, Actors.lv('c6duo')) * dt);
      if (T6.ko[o] && T6.f[o] >= 0.25) { T6.ko[o] = false; Effects.floatText(P.x, P.y - 44, `${HEROES[o].name} снова в строю!`, '#7dff9a', true); }
      // подруга бежит рядом и подстреливает врагов
      if (Math.hypot(T6.bx - P.x, T6.by - P.y) > 420) { T6.bx = P.x; T6.by = P.y; }
      T6.bx = lerp(T6.bx, P.x - 34 * P.face, Math.min(1, dt * 4)); T6.by = lerp(T6.by, P.y - 6, Math.min(1, dt * 4));
      T6.fireT -= dt;
      if (T6.fireT <= 0) {
        const tg = T6.ko[o] || G.cutscene ? null : Hero.nearestTarget(P.range * 0.9);
        if (tg) {
          const H = HEROES[o], a = Math.atan2(tg.y - (tg.z || 0) - T6.by, tg.x - T6.bx);
          T6.fireT = 1.1 / Math.pow(1 + 0.3, Actors.lv('c6duo'));
          G.feathers.push({ x: T6.bx, y: T6.by - 8, vx: Math.cos(a) * H.projSpd, vy: Math.sin(a) * H.projSpd, dmg: P.dmg * 0.3, pierce: 0, life: 1.0, hit: [], kind: H.proj, ally: true });
        } else T6.fireT = 0.3;
      }
    }
    // костры: греют, лечат обеих и запоминают место
    G.nearFire = null;
    for (const f of World.fires) {
      if (Math.abs(f.x - P.x) > 120 || Math.abs(f.y - P.y) > 120 || Math.hypot(f.x - P.x, f.y - P.y) > 95) continue;
      G.nearFire = f;
      const warm = Math.pow(1 + 0.5, Actors.lv('c6warm'));
      if (P.hp < P.maxHp) P.hp = Math.min(P.maxHp, P.hp + P.maxHp * 0.05 * warm * dt);
      if (T6) { const o = teamOther(); T6.f[o] = Math.min(1, T6.f[o] + 0.08 * warm * dt); }
      if (!G.activeBoss && !G.activeShrine && (G.cp.x !== f.x || G.cp.y !== f.y + 34)) {
        G.cp = { x: f.x, y: f.y + 34 };
        if (!f.lit) { f.lit = true; Effects.floatText(f.x, f.y - 40, '🔥 Костёр: здесь возродишься', '#ffd25a', true); Sound.sfx.magic(); Saves.saveGame(); }
      }
    }
    if (World.CFG.icedChests && !G.iceSaid && P.hero !== 'ryzhovaya') {
      for (const ch of World.chests) if (ch.iced && !ch.open && Math.hypot(ch.x - P.x, ch.y - P.y) < 210 && ringIntact(ch)) {
        G.iceSaid = true; Screens.say('Сундук вмёрз в лёд! Смени героиню 🔄 – огонь Рыжовой растопит стену.', 5); break;
      }
    }
    // погода: накатывает сама по себе, когда нет боя
    if (G.blizzardT > 0) G.blizzardT -= dt;
    if (World.CFG.weathers) {
      if (G.wxT > 0) { G.wxT -= dt; if (G.wxT <= 0 || G.activeBoss) { if (G.activeBoss && G.wxId === 'blizzard') G.blizzardT = Math.min(G.blizzardT, 0.5); G.wxId = null; G.wxT = 0; } }
      else if (!G.activeBoss && !G.activeShrine && !G.cutscene && P.y < World.PLAY_H * World.T) {
        G.blizT -= dt;
        if (G.blizT <= 0) { G.blizT = rnd(55, 85); startWeather(pick(World.CFG.weathers.filter(w => w !== G.lastWx))); }
      }
      if (G.wxId === 'starfall') {
        G.starT -= dt;
        if (G.starT <= 0) {
          G.starT = 0.55;
          for (let k = 0; k < 6; k++) {
            const a = rnd(0, TAU), r = rnd(40, 330), x = P.x + Math.cos(a) * r, y = P.y + Math.sin(a) * r;
            if (Physics.walkable(x, y, false)) { G.falling.push({ x, y, t: 0, dur: 1.1 }); break; }
          }
        }
      }
      if (G.wxId === 'frost') {
        const warmNear = !!G.nearFire;
        if (warmNear) G.chill = Math.max(0, G.chill - dt * 3);
        else if (!P.moving && P.dashT <= 0) G.chill += dt; else G.chill = Math.max(0, G.chill - dt * 1.5);
        if (G.chill > 1.2) {
          G.frostTick = (G.frostTick || 0) - dt; P.slowT = Math.max(P.slowT, 0.3);
          if (G.frostTick <= 0) {
            G.frostTick = 0.5;
            const d = P.maxHp * 0.025 * (Actors.lv('c6warm') ? 0.5 : 1);
            P.hp = Math.max(1, P.hp - d); Effects.dmgText(P.x, P.y - 30, d, '#9ad8ff');
            if (Math.random() < 0.3) Effects.floatText(P.x, P.y - 50, '🥶 двигайся!', '#bfeaff');
          }
        }
      } else G.chill = 0;
    }
    for (const st of G.falling) {
      st.t += dt;
      if (st.t >= st.dur && !st.done) {
        st.done = true; Effects.dropPickup(st.x, st.y, 'star'); Effects.burst(st.x, st.y, 14, '#ffe08a', 160);
        for (const e of G.enemies) if (!e.dead && (e.x - st.x) ** 2 + (e.y - st.y) ** 2 < 50 * 50) Enemies.damageEnemy(e, Actors.rollHit(P.dmg * 2), 0, 0, false);
      }
    }
    G.falling = G.falling.filter(st => !st.done);
    if (G.cookieT > 0) G.cookieT -= dt;
    // пещеры: темнота, пока героиня внутри
    if (World.CFG.slides || World.CFG.currents) {
      const pb = P.y < World.PLAY_H * World.T ? World.biomeMap[clamp(Math.floor(P.y / World.T), 0, World.MH - 1) * World.MW + clamp(Math.floor(P.x / World.T), 0, World.MW - 1)] : -1;
      G.caveA = lerp(G.caveA || 0, pb >= 0 && BIOMES[pb].cave ? 1 : 0, Math.min(1, dt * 1.8));
      if (pb >= 0 && BIOMES[pb].cave && !G.caveSaid) { G.caveSaid = true; Screens.say('Тут темно! Огонь Рыжовой светит ярче перьев – смени героиню 🔥', 4.5); }
    }
    // тайные поляны: стена растаяла – поляна открыта
    for (const g of World.glades) {
      if (!g.seen && Math.abs(g.x - P.x) < 420 && Math.abs(g.y - P.y) < 420) g.seen = true;
      if (!g.open && g.ring.some(i => World.tiles[i] !== ROCK)) { g.open = true; Effects.floatText(g.x, g.y - 40, '✨ Тайная поляна!', '#ffe08a', true); Sound.sfx.magic(); }
      if (g.open && !g.done && g.kind === 'beast' && Math.hypot(g.x - P.x, g.y - P.y) < 260) {
        g.done = true;
        const e = Enemies.spawnEnemy('snowleopard', g.x, g.y, World.biomeMap[g.ty * World.MW + g.tx], { elite: true, instant: true });
        e.gladeBeast = true; Screens.showBanner('🐆 Снежный барс!', 'Хозяин поляны охраняет добычу'); Sound.sfx.roar();
      }
    }
    fishTick(dt);
    // пряничная печка: печенька +25% урона на минуту
    G.baking = null;
    for (const ov of World.ovens) {
      if (ov.cd > 0) { ov.cd -= dt; continue; }
      const near = Math.hypot(P.x - ov.x, P.y - (ov.y + 20)) < 64 && !G.activeBoss && !P.moving;
      if (!near) { ov.prog = 0; continue; }
      G.baking = ov; ov.prog += dt;
      if (ov.prog >= 2) {
        ov.prog = 0; ov.cd = 90; G.cookieT = 60;
        Effects.floatText(ov.x, ov.y - 50, '🍪 Печенька! +25% урона на минуту', '#ffd25a', true); Sound.sfx.magic(); Effects.burst(ov.x, ov.y - 10, 20, '#ffd25a', 160);
      }
    }
    G.blizA = lerp(G.blizA || 0, G.blizzardT > 0 ? 1 : 0, Math.min(1, dt * 1.6));
    if (G.tessaAlly) {
      const A = G.tessaAlly;
      A.x = lerp(A.x, P.x + 36 * P.face, Math.min(1, dt * 3)); A.y = lerp(A.y, P.y + 6, Math.min(1, dt * 3));
      A.fireT -= dt;
      if (A.fireT <= 0) {
        const tg = Hero.nearestTarget(300);
        if (tg) {
          A.fireT = 0.6; const a = Math.atan2(tg.y - (tg.z || 0) - A.y, tg.x - A.x); A.face = Math.cos(a) >= 0 ? 1 : -1;
          G.feathers.push({ x: A.x, y: A.y - 8, vx: Math.cos(a) * 450, vy: Math.sin(a) * 450, dmg: P.dmg * 0.45, pierce: 1, life: 0.9, hit: [], kind: 'claw', ally: true });
        } else A.fireT = 0.25;
      }
    }
  }
  function drawCampfire(c, f, t) {
    const x = f.x, y = f.y;
    const g = c.createRadialGradient(x, y, 4, x, y, 90);
    g.addColorStop(0, 'rgba(255,170,60,0.32)'); g.addColorStop(1, 'rgba(255,170,60,0)');
    c.fillStyle = g; c.beginPath(); c.arc(x, y, 90, 0, TAU); c.fill();
    shadow(c, x, y + 10, 18, 5);
    c.fillStyle = '#8a8a9a'; for (let k = 0; k < 7; k++) { const a = k * TAU / 7; c.beginPath(); c.arc(x + Math.cos(a) * 15, y + 6 + Math.sin(a) * 6, 4, 0, TAU); c.fill(); }
    c.save(); c.translate(x, y + 4);
    c.fillStyle = '#6a3a1a'; c.strokeStyle = '#3a1a0a'; c.lineWidth = 1.5;
    for (const r of [0.5, -0.5]) { c.save(); c.rotate(r); c.fillRect(-14, -3, 28, 6); c.strokeRect(-14, -3, 28, 6); c.restore(); }
    c.restore();
    const fl = Math.sin(t * 13 + f.ph) * 2, fl2 = Math.sin(t * 17 + f.ph * 2) * 2;
    const flame = (w, h, col, dx) => { c.fillStyle = col; c.beginPath(); c.moveTo(x - w + dx, y + 2); c.quadraticCurveTo(x - w * 0.8 + dx, y - h * 0.5, x + dx + fl * 0.6, y - h); c.quadraticCurveTo(x + w * 0.8 + dx, y - h * 0.5, x + w + dx, y + 2); c.closePath(); c.fill(); };
    flame(11, 30 + fl, '#ff6a1f', 0); flame(8, 22 + fl2, '#ffb03a', 1); flame(4, 13 + fl, '#fff3b0', 0);
    if (Math.random() < 0.15) Effects.part(x + rnd(-6, 6), y - 18, rnd(-15, 15), rnd(-70, -40), 0.9, 3, '#ffd25a');
    if (f.lit) { c.fillStyle = '#ffd25a'; c.font = 'bold 11px Krilessa Icons, sans-serif'; c.textAlign = 'center'; c.fillText('✓', x + 20, y - 18); }
  }
  function drawIceCage(c, x, y, t) {
    shadow(c, x, y + 30, 36, 9);
    drawHero('tessa', c, x, y + 14 + Math.sin(t * 2) * 2, t, 1, 1, 0.9, false);
    c.fillStyle = 'rgba(170,220,255,0.42)'; c.strokeStyle = 'rgba(255,255,255,0.85)'; c.lineWidth = 2;
    c.beginPath(); c.moveTo(x - 30, y + 30); c.lineTo(x - 36, y - 10); c.lineTo(x - 18, y - 48); c.lineTo(x + 4, y - 56); c.lineTo(x + 26, y - 40); c.lineTo(x + 36, y - 4); c.lineTo(x + 30, y + 30); c.closePath(); c.fill(); c.stroke();
    c.fillStyle = 'rgba(255,255,255,0.4)'; c.beginPath(); c.moveTo(x - 24, y + 20); c.lineTo(x - 28, y - 8); c.lineTo(x - 16, y - 38); c.lineTo(x - 12, y - 30); c.lineTo(x - 18, y + 20); c.closePath(); c.fill();
    if (Math.random() < 0.08) { c.fillStyle = '#ffffff'; star(c, x + rnd(-30, 30), y + rnd(-50, 20), 3, t, 4); c.fill(); }
  }
  function fishTick(dt) {
    G.fishing=null;
    const anglers=[P];
    if(NET.host) for(const m of NET.peers.values()) if(m.live && !m.away) anglers.push(m);
    for(const hole of World.holes) {
      if(hole.spent) continue;
      const angler=!G.activeBoss && !G.activeShrine && anglers.find(a=>!a.down && !(a===P?P.moving:a.mv) && Math.hypot((a===P?P.x:a.tx)-hole.x,(a===P?P.y:a.ty)-hole.y)<48);
      if(!angler){hole.prog=0;hole.angler=null;continue;}
      const id=angler===P ? 1 : angler.id;
      if(hole.angler!==id) {hole.prog=0;hole.angler=id;}
      if(angler===P) G.fishing=hole;
      hole.prog+=dt;
      if(hole.prog>=1.6) { hole.spent=true; hole.prog=0; catchAt(hole,angler); Saves.saveGame(); }
    }
  }
  function catchAt(hl,angler) {
        const r = Math.random();
        Effects.burst(hl.x, hl.y, 16, '#9ad8ff', 160); Sound.sfx.clue();
        if (r < 0.38) {
          const hp = Math.round(P.maxHp * 0.2); if (angler===P) { Effects.healing(Math.min(hp,P.maxHp-P.hp)); P.hp = Math.min(P.maxHp, P.hp + hp); } else Multiplayer.netEvent(angler.id,['fishHeal',.2]);
          if (G.team && angler===P) { const T6=G.team; const o = teamOther(); T6.f[o] = Math.min(1, T6.f[o] + 0.2); }
          Effects.floatText(hl.x, hl.y - 30, `🐟 Рыбка! +${hp}`, '#7dff7d', true);
        } else if (r < 0.58) { Effects.floatText(hl.x, hl.y - 30, '💎 Осколки со дна!', '#c77dff', true); for (let k = 0; k < 3; k++) Effects.dropShard(hl.x, hl.y + 20); }
        else if (r < 0.64) { Effects.floatText(hl.x, hl.y - 30, '🔑 Ключ на крючке!', '#ffd25a', true); Effects.dropPickup(hl.x, hl.y + 24, 'key'); }
        else if (r < 0.8) {
          Effects.floatText(hl.x, hl.y - 30, '😱 Щука-мимик!', '#ff8a8a', true);
          const e = Enemies.spawnEnemy('pike', hl.x + 30, hl.y + 10, World.biomeMap[hl.ty * World.MW + hl.tx], { elite: true, instant: true }); e.pikeLoot = true; Sound.sfx.roar();
        } else { Effects.floatText(hl.x, hl.y - 30, '👢 Старый сапог… ну хоть опыт', '#c8c8c8', true); Effects.dropGem(hl.x, hl.y + 20, Actors.xpFor(Actors.zoneE(World.biomeMap[hl.ty * World.MW + hl.tx])) * 0.15); }
  }
  function drawHole(c, hl, t) {
    if(hl.spent) {
      c.save();c.fillStyle='#adcbd9';c.beginPath();c.ellipse(hl.x,hl.y+4,29,12,0,0,TAU);c.fill();
      c.strokeStyle='#e7f4ee';c.lineWidth=2;c.beginPath();c.moveTo(hl.x-18,hl.y+2);c.lineTo(hl.x-4,hl.y+6);c.lineTo(hl.x+8,hl.y+1);c.stroke();c.restore();return;
    }
    c.fillStyle = 'rgba(214,240,255,0.95)'; c.beginPath(); c.ellipse(hl.x, hl.y + 4, 32, 15, 0, 0, TAU); c.fill();
    c.fillStyle = '#1b4a6a'; c.beginPath(); c.ellipse(hl.x, hl.y + 4, 21, 9, 0, 0, TAU); c.fill();
    c.strokeStyle = 'rgba(255,255,255,0.85)'; c.lineWidth = 2; c.stroke();
    if (hl.cd <= 0) { const k = (t * 0.8 + hl.x * 0.01) % 1; c.strokeStyle = `rgba(190,234,255,${1 - k})`; c.lineWidth = 1.5; c.beginPath(); c.ellipse(hl.x, hl.y + 4, 5 + k * 13, 2 + k * 5, 0, 0, TAU); c.stroke(); }
    else { c.fillStyle = 'rgba(255,255,255,0.5)'; c.beginPath(); c.ellipse(hl.x, hl.y + 4, 21 * (1 - hl.cd / 40), 9 * (1 - hl.cd / 40), 0, 0, TAU); c.fill(); }
    if (G.fishing === hl) {
      c.strokeStyle = '#8a5a2a'; c.lineWidth = 3; c.beginPath(); c.moveTo(P.x + 8 * P.face, P.y - 12); c.lineTo(hl.x + 6, hl.y - 36); c.stroke();
      c.strokeStyle = '#ffffff'; c.lineWidth = 1; c.beginPath(); c.moveTo(hl.x + 6, hl.y - 36); c.lineTo(hl.x, hl.y + 4 + Math.sin(t * 22) * 2); c.stroke();
      c.strokeStyle = '#ffd25a'; c.lineWidth = 4; c.beginPath(); c.arc(hl.x, hl.y - 52, 12, -Math.PI / 2, -Math.PI / 2 + TAU * hl.prog / 1.6); c.stroke();
    }
    if (hl.cd <= 0 && G.fishing !== hl && Math.hypot(P.x - hl.x, P.y - hl.y) < 160) { c.font = '14px Krilessa Icons, sans-serif'; c.textAlign = 'center'; c.fillText('🎣', hl.x, hl.y - 22 + Math.sin(t * 3) * 3); }
  }
  function drawOven(c, ov, t) {
    const x = ov.x, y = ov.y;
    shadow(c, x, y + 24, 32, 8);
    c.fillStyle = '#b06a3a'; c.strokeStyle = '#6a3a1a'; c.lineWidth = 2.5;
    c.beginPath(); c.moveTo(x - 30, y + 22); c.lineTo(x - 30, y - 4); c.quadraticCurveTo(x, y - 48, x + 30, y - 4); c.lineTo(x + 30, y + 22); c.closePath(); c.fill(); c.stroke();
    c.strokeStyle = 'rgba(0,0,0,0.18)'; c.lineWidth = 1.5; for (let k = 0; k < 3; k++) { c.beginPath(); c.moveTo(x - 29, y + 14 - k * 9); c.lineTo(x + 29, y + 14 - k * 9); c.stroke(); }
    c.strokeStyle = '#ffffff'; c.lineWidth = 3; c.beginPath(); for (let k = 0; k < 5; k++) { const a = Math.PI + (k + 0.5) * Math.PI / 5; c.moveTo(x + Math.cos(a) * 26, y - 4 + Math.sin(a) * 34); c.quadraticCurveTo(x + Math.cos(a + 0.2) * 22, y + 2 + Math.sin(a + 0.2) * 30, x + Math.cos(a + 0.4) * 26, y - 4 + Math.sin(a + 0.4) * 34); } c.stroke();
    c.fillStyle = '#7a4a2a'; c.fillRect(x + 12, y - 40, 9, 16);
    const ready = ov.cd <= 0, glow = ready ? 0.7 + Math.sin(t * 6 + ov.ph) * 0.2 : 0.15;
    c.fillStyle = `rgba(255,${ready ? 150 : 60},40,${glow})`; c.beginPath(); c.moveTo(x - 12, y + 22); c.lineTo(x - 12, y + 8); c.quadraticCurveTo(x, y - 6, x + 12, y + 8); c.lineTo(x + 12, y + 22); c.closePath(); c.fill();
    if (ready && Math.random() < 0.06) Effects.part(x + 16, y - 42, rnd(-6, 6), -40, 1.4, 7, 'rgba(230,230,230,0.6)');
    for (const [dx, dy, col] of [[-20, 10, '#e53935'], [20, 10, '#43a047'], [0, -20, '#ff6fb5']]) { c.fillStyle = col; c.beginPath(); c.arc(x + dx, y + dy, 2.5, 0, TAU); c.fill(); }
    if (G.baking === ov) { c.strokeStyle = '#ffd25a'; c.lineWidth = 4; c.beginPath(); c.arc(x, y - 62, 12, -Math.PI / 2, -Math.PI / 2 + TAU * ov.prog / 2); c.stroke(); c.font = '13px Krilessa Icons, sans-serif'; c.textAlign = 'center'; c.fillText('🍪', x, y - 57); }
    else if (ready && Math.hypot(P.x - x, P.y - y) < 200) { c.font = '15px Krilessa Icons, sans-serif'; c.textAlign = 'center'; c.fillText('🍪', x, y - 56 + Math.sin(t * 3) * 3); }
  }
  function drawDrift(c, dr, t) {
    const k = (0.55 + 0.45 * dr.hp / 3) * dr.s, x = dr.x, y = dr.y;
    shadow(c, x, y + 8, 24 * k, 6 * k);
    c.fillStyle = '#d8e8f6'; c.beginPath(); c.ellipse(x, y + 4, 26 * k, 12 * k, 0, Math.PI, TAU); c.fill();
    c.fillStyle = '#f4faff'; c.beginPath(); c.ellipse(x - 6 * k, y + 2, 18 * k, 14 * k, 0, Math.PI, TAU); c.fill(); c.beginPath(); c.ellipse(x + 9 * k, y + 3, 14 * k, 10 * k, 0, Math.PI, TAU); c.fill();
    c.fillStyle = '#d8e8f6'; c.fillRect(x - 26 * k, y + 3, 52 * k, 3);
    if (Math.sin(t * 3 + x) > 0.9) { c.fillStyle = '#ffffff'; star(c, x + rnd(-14, 14) * k, y - 6 * k, 2.5, t, 4); c.fill(); }
  }
  // пещеры: темно, светят кристаллы, костры и огонь Рыжовой
  let caveCv = null;
  function drawCaveDark(c) {
    const A = G.caveA || 0;
    if (A < 0.02 || Session.state === 'menu') return;
    if (!caveCv) caveCv = makeCanvas(1, 1);
    const w = Math.ceil(Viewport.VW / 2), h = Math.ceil(Viewport.VH / 2);
    if (caveCv.width !== w || caveCv.height !== h) { caveCv.width = w; caveCv.height = h; }
    const d = caveCv.getContext('2d');
    d.globalCompositeOperation = 'source-over'; d.clearRect(0, 0, w, h);
    d.fillStyle = `rgba(6,4,18,${0.86 * A})`; d.fillRect(0, 0, w, h);
    d.globalCompositeOperation = 'destination-out';
    const toS = (x, y) => [((x - G.cam.x) * Viewport.ZOOM + Viewport.VW / 2) / 2, ((y - G.cam.y) * Viewport.ZOOM + Viewport.VH / 2) / 2];
    const lights = [];
    const hole = (x, y, r, k) => {
      const [sx, sy] = toS(x, y), rr = r * Viewport.ZOOM / 2;
      if (sx < -rr || sy < -rr || sx > w + rr || sy > h + rr) return false;
      const g = d.createRadialGradient(sx, sy, rr * 0.3, sx, sy, rr);
      g.addColorStop(0, `rgba(0,0,0,${k})`); g.addColorStop(1, 'rgba(0,0,0,0)');
      d.fillStyle = g; d.beginPath(); d.arc(sx, sy, rr, 0, TAU); d.fill();
      return true;
    };
    hole(P.x, P.y, P.proj === 'fire' ? 310 : 200, 0.95);
    if (G.team) hole(G.team.bx, G.team.by, G.team.list.find(id => id !== P.hero) === 'ryzhovaya' ? 140 : 70, 0.7);
    for (const f of World.fires) hole(f.x, f.y, 180, 0.95);
    for (const f of G.feathers) if (f.kind === 'fire') hole(f.x, f.y, 70, 0.6);
    const vw = Viewport.VW / Viewport.ZOOM, vh = Viewport.VH / Viewport.ZOOM, tx0 = Math.max(0, Math.floor((G.cam.x - vw / 2) / World.T) - 2), tx1 = Math.min(World.MW - 1, Math.floor((G.cam.x + vw / 2) / World.T) + 2);
    const ty0 = Math.max(0, Math.floor((G.cam.y - vh / 2) / World.T) - 2), ty1 = Math.min(World.MH - 1, Math.floor((G.cam.y + vh / 2) / World.T) + 3);
    for (let ty = ty0; ty <= ty1; ty++) for (let tx = tx0; tx <= tx1; tx++) {
      const ti = World.treeGrid[ty * World.MW + tx]; if (!ti) continue;
      const tr = World.trees[ti - 1]; if (tr.kind !== 'crystal') continue;
      if (hole(tr.x, tr.y - 20, 130, 0.75 + Math.sin(G.time * 2 + tr.x) * 0.1)) lights.push(tr);
    }
    d.globalCompositeOperation = 'source-over';
    c.save(); c.setTransform(Viewport.DPR, 0, 0, Viewport.DPR, 0, 0); c.imageSmoothingEnabled = true;
    c.drawImage(caveCv, 0, 0, Viewport.VW, Viewport.VH);
    c.globalCompositeOperation = 'lighter';
    for (const tr of lights) {
      const [sx, sy] = toS(tr.x, tr.y - 20), X = sx * 2, Y = sy * 2, R = 110 * Viewport.ZOOM;
      const g = c.createRadialGradient(X, Y, 4, X, Y, R); g.addColorStop(0, `rgba(150,110,255,${0.22 * A})`); g.addColorStop(1, 'rgba(150,110,255,0)');
      c.fillStyle = g; c.fillRect(X - R, Y - R, R * 2, R * 2);
    }
    c.globalCompositeOperation = 'source-over';
    for (const e of G.enemies) {
      if (e.dead || e.spawnT > 0) continue;
      const [sx, sy] = toS(e.x, e.y), X = sx * 2, Y = sy * 2;
      if (X < 0 || Y < 0 || X > Viewport.VW || Y > Viewport.VH || Math.sin(e.t * 2 + e.seed * 7) > 0.96) continue;
      c.globalAlpha = A; c.fillStyle = '#ff5bf0'; c.fillRect(X - 4, Y - 7, 2.5, 2.5); c.fillRect(X + 2, Y - 7, 2.5, 2.5);
    }
    c.globalAlpha = 1;
    c.restore();
    if (G.caveA > 0.5) for (const hz of G.hazards) Renderer.drawHazard(c, hz);
  }
  let snowCv = null;
  function drawBlizzard(c) {
    const A = G.blizA || 0;
    if (A < 0.02) return;
    if (!snowCv) snowCv = makeCanvas(1, 1);
    const w = Math.ceil(Viewport.VW / 2), h = Math.ceil(Viewport.VH / 2);
    if (snowCv.width !== w || snowCv.height !== h) { snowCv.width = w; snowCv.height = h; }
    const d = snowCv.getContext('2d');
    d.globalCompositeOperation = 'source-over'; d.clearRect(0, 0, w, h);
    d.fillStyle = `rgba(232,242,252,${0.68 * A})`; d.fillRect(0, 0, w, h);
    d.globalCompositeOperation = 'destination-out';
    const toS = (x, y) => [((x - G.cam.x) * Viewport.ZOOM + Viewport.VW / 2) / 2, ((y - G.cam.y) * Viewport.ZOOM + Viewport.VH / 2) / 2];
    const hole = (x, y, r, k) => {
      const [sx, sy] = toS(x, y), rr = r * Viewport.ZOOM / 2;
      if (sx < -rr || sy < -rr || sx > w + rr || sy > h + rr) return;
      const g = d.createRadialGradient(sx, sy, rr * 0.3, sx, sy, rr);
      g.addColorStop(0, `rgba(0,0,0,${k})`); g.addColorStop(1, 'rgba(0,0,0,0)');
      d.fillStyle = g; d.beginPath(); d.arc(sx, sy, rr, 0, TAU); d.fill();
    };
    hole(P.x, P.y, G.activeBoss ? 300 : 200, 0.92);
    for (const f of World.fires) hole(f.x, f.y, 170, 0.95);
    d.globalCompositeOperation = 'source-over';
    c.save(); c.setTransform(Viewport.DPR, 0, 0, Viewport.DPR, 0, 0); c.imageSmoothingEnabled = true;
    c.drawImage(snowCv, 0, 0, Viewport.VW, Viewport.VH);
    for (const f of World.fires) {
      const [hx,hy]=toS(f.x,f.y-12),x=2*hx,y=2*hy,r=f.lit?56:32;
      if(x < -r || x > Viewport.VW+r || y < -r || y > Viewport.VH+r) continue;
      const glow=c.createRadialGradient(x,y,0,x,y,r);
      glow.addColorStop(0,'rgba(255,218,135,'+(.7*A)+')');glow.addColorStop(.4,'rgba(255,163,73,'+(.28*A)+')');glow.addColorStop(1,'rgba(255,150,80,0)');
      c.fillStyle=glow;c.fillRect(x-r,y-r,2*r,2*r);
    }
    for(let layer=0;layer<2;layer++){
      const near=layer===1,n=near?29:58,speed=near?470:104;
      c.strokeStyle='rgba(245,251,255,'+(A*(near?.71:.42))+')';c.lineWidth=near?2.2:1;c.beginPath();
      for(let i=0;i<n;i++) {
        const k=i+layer*71, flow=1+hash2(k,9)*.48, width=Viewport.VW+44,height=Viewport.VH+22;
        const sx=(hash2(k,3)*width+G.time*speed*flow)%width-22;
        const sy=(hash2(k,7)*height+G.time*speed*.38*flow)%height-8;
        c.moveTo(sx,sy);c.lineTo(sx-(near?18:4),sy-(near?7:1.7));
      }
      c.stroke();
    }
    c.restore();
  }

  return {
    heroAvatar, teamOther, initTeam, teamSnapshot, switchHero, teamCatch, tryMelt, meltTile,
    tryCrack, crackTarget, drawCracks, iceTarget, hitDrift, openDrift, startWeather, freeTessa,
    updateSea, collectPearl, drawSeaFloor, drawSeaFx, updateWinter, drawCampfire, drawIceCage,
    drawHole, drawOven, drawDrift, drawCaveDark, drawBlizzard,
  };
})();
