'use strict';

const RunStats = (() => {
  // ------------------------------------------------------------------
  //  Статистика (для отправки разработчику)
  // ------------------------------------------------------------------
  function newRunStats() {
    return { ch: World.CHN, hero: P.hero, diff: G.diffId, lvl0: P.level, time: 0, deaths: 0, kills: 0, elites: 0, byType: {}, dmgDealt: 0, dmgTaken: 0,
      healed: 0, shards: 0, chests: 0, shrines: 0, supers: 0, dashes: 0, events: {}, bosses: [], ups: [], cur: null, champs: 0, calmUps: 0 };
  }
  function loadTotals() { return GameStorage.readRecord(STATS_KEY, {}); }
  function saveTotals(t) { GameStorage.write(STATS_KEY, t); }
  function startSession() {
    const totals = loadTotals();
    totals.sessions = (totals.sessions || 0) + 1;
    saveTotals(totals);
    setInterval(() => {
      if (Session.state !== 'play') return;
      const current = loadTotals();
      current.playTime = (current.playTime || 0) + 10;
      saveTotals(current);
    }, 10000);
  }
  const topTypes = (m, n) => Object.entries(m || {}).sort((a, b) => b[1] - a[1]).slice(0, n);
  const fmtT = sec => { sec = Math.max(0, Math.round(sec)); const h = Math.floor(sec / 3600), m = Math.floor(sec % 3600 / 60), ss = sec % 60; return (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + String(ss).padStart(2, '0'); };
  const fmtN = v => v >= 1e6 ? (v / 1e6).toFixed(1) + 'M' : v >= 1e3 ? (v / 1e3).toFixed(1) + 'K' : String(Math.round(v));
  function summarizeRun() {
    const s = G.st;
    return { ch: s.ch, hero: s.hero, diff: s.diff, lvl0: s.lvl0, lvl: P.level, time: Math.round(s.time), deaths: s.deaths, kills: s.kills, elites: s.elites,
      dealt: Math.round(s.dmgDealt), taken: Math.round(s.dmgTaken), healed: Math.round(s.healed || 0), shards: s.shards, chests: s.chests, shrines: s.shrines,
      supers: s.supers, dashes: s.dashes, combo: G.bestCombo, champs: s.champs || 0, calmUps: s.calmUps || 0, seed: World.SEED % 10000, mimics: s.mimics || 0, relics: s.relics || 0, events: s.events, bosses: s.bosses, ups: s.ups, top: topTypes(s.byType, 6) };
  }
  function recordRunEnd(result) {
    Achievements.lifeFlush();
    if (!G.st) return;
    const tot = loadTotals();
    tot.runs = tot.runs || [];
    const run = Object.assign(summarizeRun(), { result, at: Date.now() }), top = tot.runs[0]; G.st.recAt = G.st.time; // уже записан – «идёт сейчас» не дублируем
    if (top && top.ch === run.ch && top.seed === run.seed && top.kills <= run.kills && Date.now() - (top.at || 0) < 1800e3 && /пройдена/.test(top.result)) tot.runs[0] = run; // продолжение того же забега
    else tot.runs.unshift(run);
    tot.runs = tot.runs.slice(0, 10);
    saveTotals(tot);
  }
  function buildReport() {
    const prof = Saves.loadProfile(), tot = loadTotals();
    const L = [];
    L.push(`📊 Крилесса v${VERSION} – статистика`);
    const ua = navigator.userAgent, andr = (ua.match(/Android [\d.]+/) || ['?'])[0], chrome = (ua.match(/Chrome\/(\d+)/) || [0, '?'])[1];
    L.push(`📱 ${Viewport.VW}×${Viewport.VH} @${Viewport.DPR}x · ${andr} · WebView ${chrome}`);
    L.push(`⚙️ Сложность: ${DIFFS[(prof.settings || {}).diff || 'normal'].name} · в игре: ${fmtT(tot.playTime || 0)} · запусков: ${tot.sessions || 0}`);
    L.push(`🏆 Главы: ${Session.CH_NUMS.map(n => n + (prof['ch' + n + 'Done'] ? '✓' : '–')).join(' ')}${prof.trueWin ? ' · настоящий финал ✓' : ''}` +
      (prof.rushBest ? ` · Босс-раш: ${prof.rushBest.n}/${prof.rushBest.total} за ${fmtT(prof.rushBest.time)}` : ''));
    { const ab = prof.abyssBest, ck = Challenges.abyssCkLoad(), g = Achievements.gloryOf(prof), L2 = prof.life || {};
      L.push(`🎮 Бездна: ${ab ? 'волна ' + ab.wave : '–'}${ck ? ` (сохранено: волна ${ck.wave})` : ''} · испытание дня: ${L2.dBest || 0} · ✨ слава ${g.fame} · 🏆 ${g.n}/${Achievements.ACHS.length} · ⭐ ${prof.stars || 0}`); }
    const runs = [];
    if (G.st && G.st.time > 1 && !(G.rush && G.rush.done) && !(G.st.recAt !== undefined && G.st.time - G.st.recAt < 5)) runs.push(Object.assign(summarizeRun(), { result: 'идёт сейчас' }));
    for (const r of (tot.runs || [])) runs.push(r);
    for (const r of runs.slice(0, 5)) {
      L.push('');
      L.push(`– ${r.ch === 'rush' || String(r.result).includes('раш') ? 'Босс-раш' : r.ch === 'def' || String(r.result).includes('оборона') ? 'Оборона' : r.ch === 'abyss' ? 'Бездна' : 'Глава ' + r.ch} · ${HEROES[r.hero] ? HEROES[r.hero].name : r.hero} · ${String(r.diff).split('→').map(d => DIFFS[d] ? DIFFS[d].name : d).join(' → ')} · ${r.result} –`);
      L.push(`⏱ ${fmtT(r.time)} · ур. ${r.lvl0}→${r.lvl} · ☠️ ${r.kills} (элита ${r.elites}) · 💀 смертей ${r.deaths} · 🔥 комбо ${r.combo}`);
      if (r.champs !== undefined) L.push(`🗺️ карта #${r.seed} · 👑 чемпионов ${r.champs} · 🕊️ ступеней усмирения ${r.calmUps}` + (r.mimics !== undefined ? ` · 😱 мимиков ${r.mimics} · 🗝️ реликвий ${r.relics}` : ''));
      L.push(`⚔️ нанесено ${fmtN(r.dealt)} · получено ${fmtN(r.taken)} · вылечено ${fmtN(r.healed)} · 💎 ${r.shards} · 📦 ${r.chests} · ⛩ ${r.shrines} · 🌟 ${r.supers} · рывков ${r.dashes}`);
      for (const b of r.bosses || []) L.push(`  👑 ${b.n}: ${fmtT(b.t)} · ур. игрока ${b.pl} / босса ${b.bl} · смертей ${b.d}` + (b.h !== undefined ? ` · ❤️ ${b.h}` : '') + (b.df ? ` · ${DIFFS[b.df] ? DIFFS[b.df].name : b.df}` : ''));
      const ev = Object.entries(r.events || {}).map(([k, v]) => { const e = EVENTS.find(x => x.id === k); return (e ? e.ic : k) + '×' + v; }).join(' ');
      if (ev) L.push(`  🎲 события: ${ev}`);
      if (r.top && r.top.length) L.push(`  👾 ${r.top.map(([k, v]) => (ENEMIES[k] ? ENEMIES[k].name : k) + ' ' + v).join(', ')}`);
      if (r.ups && r.ups.length) { const cnt = {}; r.ups.forEach(u => { cnt[u] = (cnt[u] || 0) + 1; }); L.push(`  ⬆️ ${Object.entries(cnt).map(([k, v]) => k + '×' + v).join(' ')}`); }
    }
    const errs = GameLoop.errLog();
    if (errs.length) {
      L.push(''); L.push('⚠️ Сбои:');
      for (const x of errs.slice(0, 5)) L.push(`  ${new Date(x.at).toLocaleString('ru-RU')} · v${x.v} · ${x.w} · ${x.st} · гл. ${x.ch}: ${x.m}${x.s ? ' (' + x.s + ')' : ''}`);
    }
    L.push('');
    const data = { v: VERSION, scr: [Viewport.VW, Viewport.VH, Viewport.DPR], c: [prof.ch1Done, prof.ch2Done, prof.ch3Done, prof.trueWin, prof.ch4Done, prof.ch5Done, prof.ch6Done, prof.ch7Done].map(Boolean),
      ab: prof.abyssBest ? prof.abyssBest.wave : 0, ack: (Challenges.abyssCkLoad() || {}).wave || 0, gl: [Achievements.gloryOf(prof).fame, Achievements.gloryOf(prof).n], w: prof.ch4Choice || null, a: prof.ch5Accuse || null, d: (prof.settings || {}).diff,
      rb: prof.rushBest || null, pt: Math.round(tot.playTime || 0), ss: tot.sessions || 0, er: GameLoop.errLog().slice(0, 5).map(x => [x.at, x.v, x.w, x.st, x.ch, x.m, x.s]),
      runs: runs.slice(0, 5).map(r => ({ ch: r.ch, h: r.hero, d: r.diff, r: r.result, t: r.time, l: [r.lvl0, r.lvl], k: r.kills, de: r.deaths, dd: r.dealt, dt: r.taken,
        b: (r.bosses || []).map(b => [b.k, b.t, b.pl, b.bl, b.d, b.h || 0, b.df || '']), e: r.events, u: r.ups })) };
    L.push('#KRSTAT ' + JSON.stringify(data));
    return L.join('\n');
  }
  let statsBack = 'menu';
  function openStats() {
    statsBack = Session.state === 'stats' ? statsBack : Session.state;
    $('statsText').textContent = buildReport();
    Screens.setState('stats');
  }
  function toast(msg) {
    const t = $('toast'); t.textContent = msg; t.classList.remove('hidden', 'show'); void t.offsetWidth; t.classList.add('show');
    clearTimeout(toast.tm); toast.tm = setTimeout(() => t.classList.add('hidden'), 2600);
  }
  function fallbackCopy(txt) {
    const ta = document.createElement('textarea'); ta.value = txt; ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.appendChild(ta); ta.select();
    try { document.execCommand('copy'); toast('Скопировано! Вставь в сообщение 📋'); } catch (e) { toast('Не получилось скопировать'); }
    ta.remove();
  }
  function copyText(txt) {
    try { if (window.KrilessaAndroid && window.KrilessaAndroid.copy) { window.KrilessaAndroid.copy(txt); toast('Скопировано! Вставь в сообщение 📋'); return; } } catch (e) { /* ignore */ }
    if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(txt).then(() => toast('Скопировано! Вставь в сообщение 📋'), () => fallbackCopy(txt)); return; }
    fallbackCopy(txt);
  }
  function shareText(txt) {
    try { if (window.KrilessaAndroid && window.KrilessaAndroid.share) { window.KrilessaAndroid.share(txt); return; } } catch (e) { /* ignore */ }
    if (navigator.share) { navigator.share({ title: 'Крилесса – статистика', text: txt }).catch(() => {}); return; }
    copyText(txt);
  }

  return {
    newRunStats, startSession, loadTotals, fmtT, fmtN, recordRunEnd, buildReport, openStats, toast,
    fallbackCopy, copyText, shareText,
    get statsBack() { return statsBack; },
  };
})();
