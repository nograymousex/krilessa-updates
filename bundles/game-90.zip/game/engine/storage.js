'use strict';

// В WebView доступ к хранилищу может быть закрыт, а место для записи ограничено.
const GameStorage = (() => {
  function read(key) {
    try {
      return JSON.parse(localStorage.getItem(key));
    } catch (e) {
      return null;
    }
  }

  function readRecord(key, fallback = null) {
    const value = read(key);
    return value && typeof value === 'object' && !Array.isArray(value) ? value : fallback;
  }

  function readList(key) {
    const value = read(key);
    return Array.isArray(value) ? value : [];
  }

  function write(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch (e) {
      return false;
    }
  }

  function remove(key) {
    try {
      localStorage.removeItem(key);
    } catch (e) { /* хранилище недоступно */ }
  }

  // Старый слот можно удалить, когда новый уже есть или копирование удалось.
  function migrateKey(oldKey, newKey) {
    try {
      const previous = localStorage.getItem(oldKey);
      if (!previous) return;
      if (!localStorage.getItem(newKey)) localStorage.setItem(newKey, previous);
      localStorage.removeItem(oldKey);
    } catch (e) { /* повтор при следующем запуске */ }
  }

  return { readRecord, readList, write, remove, migrateKey };
})();
