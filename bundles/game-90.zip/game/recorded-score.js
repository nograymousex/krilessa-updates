'use strict';

// Each recording is shipped inside both the APK and the offline update. The two
// parts of a battle use the same sample clock, including when the WebView sleeps.
const RecordedScore = (() => {
  const layered = new Set('boss final final2 final5 meowboss mrakboss krillboss ultimate rush defense banks'.split(' '));

  function create(ctx, destination, fallback) {
    const Decoder = window.OfflineAudioContext || window.webkitOfflineAudioContext;
    let decoder = ctx;
    try { if (Decoder) decoder = new Decoder(2, 1, 32000); } catch (e) { /* use the device sample rate */ }
    let request = null, current = null, wanted = null, generation = 0, intensity = 0, rate = 1;

    async function load(file, signal) {
      const response = await fetch('music/' + file + '.ogg', signal ? {signal} : {});
      if (!response.ok) throw Error('Music asset ' + response.status);
      const bytes = await response.arrayBuffer();
      return new Promise((resolve, reject) => decoder.decodeAudioData(bytes, resolve, reject));
    }

    function release(track) {
      if (!track) return;
      const t = ctx.currentTime;
      track.mix.gain.setTargetAtTime(0, t, .105);
      for (const source of track.sources) source.stop(t + .64);
    }

    function begin(name, base, extra) {
      const when = ctx.currentTime + .025;
      const mix = ctx.createGain();
      const layer = ctx.createGain();
      const sources = [];
      const track = {name, mix, layer, sources};
      mix.gain.setValueAtTime(0, when);
      mix.gain.setTargetAtTime(1, when, current ? .12 : .019);
      mix.connect(destination);
      layer.gain.value = intensity;
      layer.connect(mix);
      const length = extra ? Math.min(base.duration, extra.duration) : base.duration;
      for (const buffer of extra ? [base, extra] : [base]) {
        const src = ctx.createBufferSource();
        src.buffer = buffer;
        src.loop = true;
        src.loopEnd = length;
        src.playbackRate.value = rate;
        src.connect(sources.length ? layer : mix);
        sources.push(src);
      }
      let remaining = sources.length;
      for (const src of sources) {
        src.onended = () => {
          src.disconnect();
          if (--remaining === 0) { layer.disconnect(); mix.disconnect(); }
        };
        src.start(when);
      }
      release(current);
      current = track;
    }

    async function select(name) {
      if (name === wanted) return;
      wanted = name;
      const id = ++generation;
      if (request) request.abort();
      request = null;
      if (!name) { release(current); current = null; return; }
      if (current && current.name === name) return;
      const ctl = window.AbortController ? new AbortController() : null;
      request = ctl;
      let timeout;
      try {
        const recordings = Promise.all([load(name, ctl && ctl.signal), layered.has(name)
          ? load(name + '-surge', ctl && ctl.signal).catch(() => null) : null]);
        const limit = new Promise((_, reject) => {
          timeout = setTimeout(() => reject(Error('Music load timeout')), 5000);
        });
        const [base, extra] = await Promise.race([recordings, limit]);
        if (id !== generation) return;
        begin(name, base, extra);
      } catch (e) {
        if (id !== generation) return;
        if (ctl) ctl.abort();
        release(current); current = null;
        fallback();
      } finally {
        clearTimeout(timeout);
        if (id === generation) request = null;
      }
    }

    return {
      select,
      setIntensity(value) {
        intensity = Math.max(0, Math.min(1, (value - .50) * 2.25));
        if (current) current.layer.gain.setTargetAtTime(intensity, ctx.currentTime, .38);
      },
      setGlitch(value) {
        rate = 1 / (1 + .47 * value);
        if (current) for (const source of current.sources) source.playbackRate.setTargetAtTime(rate, ctx.currentTime, .09);
      },
    };
  }
  return {create};
})();
