'use strict';
// =====================================================================
//  КРИЛЕССА – движок игры (v0.02 beta)
//  Глава 1: Спасение Рыжовой. Глава 2: Кринж-Цитадель Зямочкккк.
//  Контент (враги, боссы, реплики) – в content.js, графика – в sprites.js.
// =====================================================================
(() => {
  // ------------------------------------------------------------------
  //  Экран
  // ------------------------------------------------------------------
  const canvas = $('game');
  const ctx = canvas.getContext('2d');
  let VW = 0, VH = 0, DPR = 1, ZOOM = 1, SAFE_TOP = 0;
  const safeProbe = document.createElement('div');
  safeProbe.style.cssText = 'position:fixed;top:0;left:0;height:0;padding-top:env(safe-area-inset-top,0px);visibility:hidden';
  document.body.appendChild(safeProbe);
  function resize() {
    DPR = Math.min(window.devicePixelRatio || 1, 2);
    VW = window.innerWidth; VH = window.innerHeight;
    canvas.width = Math.round(VW * DPR); canvas.height = Math.round(VH * DPR);
    canvas.style.width = VW + 'px'; canvas.style.height = VH + 'px';
    ZOOM = clamp(Math.min(VW, VH) / 370, 0.85, 2);
    SAFE_TOP = parseFloat(getComputedStyle(safeProbe).paddingTop) || 0;
  }
  window.addEventListener('resize', resize);
  resize();

  // ------------------------------------------------------------------
  //  Мир (пересоздаётся для каждой главы)
  // ------------------------------------------------------------------
  const T = 40;
  const PX_PER_M = 16;
  let CHN = 1, CFG = CHAPTERS[1], SEED = 0;
  let MW = 0, MH = 0, WORLD_W = 0, WORLD_H = 0, PLAY_H = 0, ARENA = null;
  let tiles = null, biomeMap, treeGrid, trees = [], chests = [], shrines = [], mainPath = [];
  // объекты глав Тессы
  let beds = [], lamps = [], clues = [], npcs = [], qitems = [], shelves = [], boxes = [], fires = [];
  let holes = [], ovens = [], drifts = [], glades = []; // глава 6
  let START, CASTLE, GATE_FRONT, GATE_INNER, CAGE;
  let gateOpen = false;
  const tc = v => v * T + T / 2;
  const inMap = (tx, ty) => tx >= 0 && ty >= 0 && tx < MW && ty < MH;
  const tileAt = (tx, ty) => (inMap(tx, ty) ? tiles[ty * MW + tx] : ROCK);
  const isGround = t => t < PATH;

  function isSolidTile(tx, ty, fly) {
    if (!inMap(tx, ty)) return true;
    const t = tiles[ty * MW + tx];
    if (t === ROCK || t === WALL) return true;
    if (t === GATE) return !gateOpen;
    if (!fly && (t === WATER || t === LAVA)) return true;
    return false;
  }
  function blocksShots(x, y) {
    const tx = Math.floor(x / T), ty = Math.floor(y / T);
    if (!inMap(tx, ty)) return true;
    const t = tiles[ty * MW + tx];
    return t === ROCK || t === WALL || (t === GATE && !gateOpen);
  }

  function biomeAt(tx, ty) {
    const wx = tx + (vnoise(tx * 0.07, ty * 0.07) - 0.5) * 18;
    const wy = ty + (vnoise(tx * 0.07 + 40, ty * 0.07 + 40) - 0.5) * 18;
    let best = 1e9, b = 0;
    for (const [bb, x, y] of CFG.biomeSeeds) {
      const d = (wx - x) * (wx - x) + (wy - y) * (wy - y);
      if (d < best) { best = d; b = bb; }
    }
    return b;
  }

  function generateWorld() {
    MW = CFG.MW; MH = CFG.MH; WORLD_W = MW * T; WORLD_H = MH * T;
    tiles = new Uint8Array(MW * MH); biomeMap = new Uint8Array(MW * MH); treeGrid = new Int32Array(MW * MH);
    trees = []; chests = []; shrines = []; mainPath = [];
    beds = []; lamps = []; clues = []; npcs = []; qitems = []; shelves = []; boxes = []; fires = [];
    holes = []; ovens = []; drifts = []; glades = [];
    START = CFG.start;
    CASTLE = CFG.castle;
    const h = CASTLE.half;
    if (CASTLE.gate === 'west') {
      GATE_FRONT = { x: CASTLE.x - h - 3, y: CASTLE.y }; GATE_INNER = { x: CASTLE.x - h + 1, y: CASTLE.y };
    } else if (CASTLE.gate === 'east') {
      GATE_FRONT = { x: CASTLE.x + h + 3, y: CASTLE.y }; GATE_INNER = { x: CASTLE.x + h - 1, y: CASTLE.y };
    } else {
      GATE_FRONT = { x: CASTLE.x, y: CASTLE.y + h + 3 }; GATE_INNER = { x: CASTLE.x, y: CASTLE.y + h - 1 };
    }
    CAGE = CFG.cage;
    const rng = mulberry32(SEED);
    for (let ty = 0; ty < MH; ty++) for (let tx = 0; tx < MW; tx++) {
      const b = biomeAt(tx, ty), i = ty * MW + tx;
      biomeMap[i] = b; tiles[i] = b;
    }
    const set = (tx, ty, t) => { if (inMap(tx, ty)) tiles[ty * MW + tx] = t; };
    // препятствия
    for (let n = 0; n < CFG.blobs; n++) {
      const cx = 4 + Math.floor(rng() * (MW - 8)), cy = 4 + Math.floor(rng() * (MH - 8));
      const type = weighted(BIOMES[biomeMap[cy * MW + cx]].obst, rng());
      const parts = 2 + Math.floor(rng() * 4);
      for (let k = 0; k < parts; k++) {
        const w = 2 + Math.floor(rng() * 6), hh = 2 + Math.floor(rng() * 5);
        const ox = cx + Math.floor(rng() * 8) - 4, oy = cy + Math.floor(rng() * 8) - 4;
        const ecx = ox + (w - 1) / 2, ecy = oy + (hh - 1) / 2, erx = w / 2, ery = hh / 2;
        for (let y = oy; y < oy + hh; y++) for (let x = ox; x < ox + w; x++) if (((x - ecx) / erx) ** 2 + ((y - ecy) / ery) ** 2 <= 1.05) set(x, y, type);
      }
    }
    for (let ty = 0; ty < MH; ty++) for (let tx = 0; tx < MW; tx++) {
      if (tx < 2 || ty < 2 || tx >= MW - 2 || ty >= MH - 2) set(tx, ty, ROCK);
    }
    // замок
    for (let y = CASTLE.y - h - 3; y <= CASTLE.y + h + 3; y++)
      for (let x = CASTLE.x - h - 3; x <= CASTLE.x + h + 3; x++) set(x, y, CASTLE.biome);
    for (let y = CASTLE.y - h; y <= CASTLE.y + h; y++) for (let x = CASTLE.x - h; x <= CASTLE.x + h; x++) {
      const edge = x === CASTLE.x - h || x === CASTLE.x + h || y === CASTLE.y - h || y === CASTLE.y + h;
      set(x, y, edge ? WALL : FLOOR);
      if (inMap(x, y)) biomeMap[y * MW + x] = CASTLE.biome;
    }
    for (const [cx, cy] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) {
      const bx = CASTLE.x + cx * h, by = CASTLE.y + cy * h;
      for (let y = by - 1; y <= by + 1; y++) for (let x = bx - 1; x <= bx + 1; x++) set(x, y, WALL);
    }
    if (CASTLE.gate === 'west') for (let y = CASTLE.y - 1; y <= CASTLE.y + 1; y++) set(CASTLE.x - h, y, GATE);
    else if (CASTLE.gate === 'east') for (let y = CASTLE.y - 1; y <= CASTLE.y + 1; y++) set(CASTLE.x + h, y, GATE);
    else for (let x = CASTLE.x - 1; x <= CASTLE.x + 1; x++) set(x, CASTLE.y + h, GATE);

    // дороги
    const brush = (x, y, rec) => {
      for (let oy = -1; oy <= 1; oy++) for (let ox = -1; ox <= 1; ox++) {
        const tx = x + ox, ty = y + oy;
        if (!inMap(tx, ty) || tx < 2 || ty < 2 || tx >= MW - 2 || ty >= MH - 2) continue;
        const t = tiles[ty * MW + tx];
        if (t === WALL || t === GATE || t === FLOOR) continue;
        const nearCastle = Math.abs(tx - CASTLE.x) < h + 8 && Math.abs(ty - CASTLE.y) < h + 8;
        tiles[ty * MW + tx] = nearCastle ? STONE : PATH;
        if (treeGrid[ty * MW + tx]) treeGrid[ty * MW + tx] = 0;
      }
      if (rec) mainPath.push([x, y]);
    };
    const carve = (ax, ay, bx, by, rec, r = rng) => {
      let x = ax, y = ay, guard = 0;
      brush(x, y, rec);
      while ((x !== bx || y !== by) && guard++ < 6000) {
        const dx = bx - x, dy = by - y;
        const horiz = dy === 0 || (dx !== 0 && r() < Math.abs(dx) / (Math.abs(dx) + Math.abs(dy)));
        const len = 2 + Math.floor(r() * 6);
        for (let k = 0; k < len; k++) {
          if (horiz) { if (x === bx) break; x += Math.sign(dx); } else { if (y === by) break; y += Math.sign(dy); }
          brush(x, y, rec);
        }
      }
    };
    const guards = CFG.bossTiles.slice(0, -1);
    const route = [START, ...guards, GATE_FRONT];
    for (let i = 0; i < route.length - 1; i++) carve(route[i].x, route[i].y, route[i + 1].x, route[i + 1].y, true);
    carve(GATE_FRONT.x, GATE_FRONT.y, GATE_INNER.x, GATE_INNER.y, false);
    if (CHN === 1) carve(START.x, START.y, GATE_FRONT.x, GATE_FRONT.y + 6, true);
    else carve(START.x, START.y, GATE_FRONT.x, GATE_FRONT.y, true);
    const clearCircle = (cx, cy, r) => {
      for (let y = cy - r; y <= cy + r; y++) for (let x = cx - r; x <= cx + r; x++) {
        if (!inMap(x, y) || x < 2 || y < 2 || x >= MW - 2 || y >= MH - 2) continue;
        if ((x - cx) * (x - cx) + (y - cy) * (y - cy) > r * r) continue;
        const t = tiles[y * MW + x];
        treeGrid[y * MW + x] = 0;
        if (t === WALL || t === GATE || t === FLOOR || t === PATH || t === STONE) continue;
        tiles[y * MW + x] = biomeMap[y * MW + x];
      }
    };
    // ледяные реки-горки (глава 6): плавные извилистые полосы льда через полкарты
    if (CFG.slides) {
      const rs = mulberry32(SEED + 707);
      for (const [[ax, ay], [bx, by]] of CFG.slides) {
        const len = Math.hypot(bx - ax, by - ay), nx = -(by - ay) / len, ny = (bx - ax) / len;
        const amp = 3 + rs() * 5, waves = 1 + rs() * 1.5, ph = rs() * TAU;
        for (let k = 0; k <= len * 2; k++) {
          const t = k / (len * 2), w = Math.sin(t * Math.PI * waves * 2 + ph) * amp * Math.sin(t * Math.PI);
          const cx = Math.round(ax + (bx - ax) * t + nx * w), cy = Math.round(ay + (by - ay) * t + ny * w);
          for (let oy = -1; oy <= 1; oy++) for (let ox = -1; ox <= 1; ox++) {
            const x = cx + ox, y = cy + oy;
            if (!inMap(x, y) || x < 3 || y < 3 || x >= MW - 3 || y >= MH - 3) continue;
            if (Math.abs(x - CASTLE.x) <= h + 4 && Math.abs(y - CASTLE.y) <= h + 4) continue;
            const u = tiles[y * MW + x]; if (u === WALL || u === GATE || u === FLOOR || u === PATH || u === STONE) continue;
            tiles[y * MW + x] = ICE;
          }
        }
      }
    }
    for (const g of guards) clearCircle(g.x, g.y, CHN === 1 ? 8 : 9);
    clearCircle(START.x, START.y, 5);
    // сундуки
    let tries = 0;
    while (chests.length < CFG.chests && tries++ < 900) {
      const cx = 5 + Math.floor(rng() * (MW - 10)), cy = 5 + Math.floor(rng() * (MH - 10));
      if (Math.abs(cx - CASTLE.x) < h + 5 && Math.abs(cy - CASTLE.y) < h + 5) continue;
      let best = null, bd = 1e9;
      for (const [px, py] of mainPath) { const d = Math.abs(px - cx) + Math.abs(py - cy); if (d < bd) { bd = d; best = [px, py]; } }
      if (!best || bd < CFG.chestDist[0] || bd > CFG.chestDist[1]) continue;
      if (chests.some(c => Math.abs(c.tx - cx) + Math.abs(c.ty - cy) < 14)) continue;
      carve(best[0], best[1], cx, cy, false);
      clearCircle(cx, cy, 2);
      chests.push({ tx: cx, ty: cy, x: tc(cx), y: tc(cy), open: false, biome: biomeMap[cy * MW + cx] });
    }
    // деревья
    const blocked = [START, ...guards];
    for (let ty = 3; ty < MH - 3; ty++) for (let tx = 3; tx < MW - 3; tx++) {
      const t = tiles[ty * MW + tx];
      if (!isGround(t)) continue;
      if (blocked.some((p, i) => (p.x - tx) ** 2 + (p.y - ty) ** 2 < (i === 0 ? 30 : 80))) continue;
      if (chests.some(c => Math.abs(c.tx - tx) <= 1 && Math.abs(c.ty - ty) <= 1)) continue;
      if (Math.abs(tx - CASTLE.x) <= h + 1 && Math.abs(ty - CASTLE.y) <= h + 1) continue;
      const pathy = (x, y) => { const u = tileAt(x, y); return u === PATH || u === STONE; };
      if (pathy(tx + 1, ty) || pathy(tx - 1, ty) || pathy(tx, ty + 1) || pathy(tx, ty - 1)) continue; // дороги свободны
      const b = biomeMap[ty * MW + tx];
      const dens = Math.min(0.16, BIOMES[b].treeP * (0.5 + vnoise(tx * 0.15 + 9, ty * 0.15 + 3)));
      if (rng() < dens) {
        trees.push({ x: tx * T + 10 + rng() * 20, y: ty * T + 14 + rng() * 20, kind: BIOMES[b].tree, s: 0.85 + rng() * 0.35 });
        treeGrid[ty * MW + tx] = trees.length;
      }
    }
    // алтари испытаний (отдельный генератор, чтобы не менять остальную карту)
    const r2 = mulberry32(SEED + 99);
    tries = 0;
    while (shrines.length < CFG.shrines && tries++ < 1500) {
      const cx = 10 + Math.floor(r2() * (MW - 20)), cy = 10 + Math.floor(r2() * (MH - 20));
      if (Math.abs(cx - CASTLE.x) < h + 11 && Math.abs(cy - CASTLE.y) < h + 11) continue;
      if (!isGround(tiles[cy * MW + cx])) continue;
      if (CFG.bossTiles.some(b => Math.abs(b.x - cx) + Math.abs(b.y - cy) < 16)) continue;
      if (Math.abs(START.x - cx) + Math.abs(START.y - cy) < 14) continue;
      if (chests.some(c => Math.abs(c.tx - cx) + Math.abs(c.ty - cy) < 8)) continue;
      if (shrines.some(s => Math.abs(s.tx - cx) + Math.abs(s.ty - cy) < 22)) continue;
      let best = null, bd = 1e9;
      for (const [px, py] of mainPath) { const d = Math.abs(px - cx) + Math.abs(py - cy); if (d < bd) { bd = d; best = [px, py]; } }
      if (!best || bd < 6 || bd > 18) continue;
      carve(best[0], best[1], cx, cy, false, r2);
      clearCircle(cx, cy, 8); // круг испытания (300 px) целиком на чистой поляне
      shrines.push({ tx: cx, ty: cy, x: tc(cx), y: tc(cy), state: 'idle', biome: biomeMap[cy * MW + cx], left: 0 });
    }
    // ---- главы Тессы: лежанки, лампы, улики, жители, полки, коробки ----
    const r3 = mulberry32(SEED + 177);
    const okSpot = (x, y) => x > 4 && y > 4 && x < MW - 5 && y < MH - 5 && !(Math.abs(x - CASTLE.x) < h + 4 && Math.abs(y - CASTLE.y) < h + 4) &&
      Math.abs(x - START.x) + Math.abs(y - START.y) > 5 && !CFG.bossTiles.some(b => Math.abs(b.x - x) + Math.abs(b.y - y) < 5);
    const taken = [];
    const free = (x, y, d) => taken.every(o => Math.abs(o[0] - x) + Math.abs(o[1] - y) >= d);
    const placeNear = (p, dmin, dmax, sep = 3) => {
      for (let k = 0; k < 24; k++) {
        const a = r3() * TAU, d = dmin + r3() * (dmax - dmin), x = Math.round(p[0] + Math.cos(a) * d), y = Math.round(p[1] + Math.sin(a) * d);
        if (!okSpot(x, y) || !free(x, y, sep)) continue;
        carve(p[0], p[1], x, y, false, r3); clearCircle(x, y, 1);
        taken.push([x, y]); return [x, y];
      }
      return null;
    };
    const pathPoint = pred => { for (let i = 0; i < 600; i++) { const p = mainPath[Math.floor(r3() * mainPath.length)]; if (p && pred(p)) return p; } return null; };
    if (CFG.beds) {
      const got = [];
      for (let i = 0; i < 400 && got.length < CFG.beds; i++) {
        const p = pathPoint(q => got.every(o => Math.abs(o.tx - q[0]) + Math.abs(o.ty - q[1]) > 16));
        if (!p) break;
        const s = placeNear(p, 2, 3); if (s) got.push({ tx: s[0], ty: s[1], x: tc(s[0]), y: tc(s[1]), cd: 0, nap: 0 });
      }
      beds = got;
    }
    if (CFG.lamps) {
      for (let i = 0; i < 400 && lamps.length < CFG.lamps; i++) {
        const p = pathPoint(q => lamps.every(o => Math.abs(o.tx - q[0]) + Math.abs(o.ty - q[1]) > 10));
        if (!p) break;
        const s = placeNear(p, 1, 2, 2); if (s) lamps.push({ tx: s[0], ty: s[1], x: tc(s[0]), y: tc(s[1]), ph: r3() * 6 });
      }
    }
    if (CFG.detective) {
      for (let gi = 0; gi < 4; gi++) {
        const B = CFG.bossTiles[gi], bb = biomeMap[B.y * MW + B.x];
        for (let k = 0; k < 3; k++) {
          let p = pathPoint(q => biomeMap[q[1] * MW + q[0]] === bb && Math.hypot(q[0] - B.x, q[1] - B.y) > 6 && Math.hypot(q[0] - B.x, q[1] - B.y) < 26 && clues.every(o => Math.abs(o.tx - q[0]) + Math.abs(o.ty - q[1]) > 6));
          if (!p) p = pathPoint(q => Math.hypot(q[0] - B.x, q[1] - B.y) < 30 && Math.hypot(q[0] - B.x, q[1] - B.y) > 6);
          if (!p) { let bd = 1e9; for (const q of mainPath) { const d = Math.hypot(q[0] - B.x, q[1] - B.y); if (d >= 4 && d < bd) { bd = d; p = q; } } }
          if (!p) p = mainPath[0];
          const s = placeNear(p, 1, 3, 2) || p;
          clues.push({ i: gi, k, tx: s[0], ty: s[1], x: tc(s[0]), y: tc(s[1]), found: false });
        }
      }
      NPCS5.forEach((def, ni) => {
        const p = pathPoint(q => biomeMap[q[1] * MW + q[0]] === def.biome && Math.abs(q[0] - START.x) + Math.abs(q[1] - START.y) > 8) || pathPoint(() => true);
        const s = placeNear(p, 2, 3, 3) || p;
        npcs.push({ def, ni, tx: s[0], ty: s[1], x: tc(s[0]), y: tc(s[1]), state: 'new' });
        const q = pathPoint(q2 => { const d = Math.hypot(q2[0] - s[0], q2[1] - s[1]); return d > 16 && d < 45; }) || pathPoint(() => true);
        const it = placeNear(q, 2, 4, 3) || q;
        qitems.push({ ni, tx: it[0], ty: it[1], x: tc(it[0]), y: tc(it[1]), active: false, taken: false });
      });
    }
    if (CFG.shelves) {
      for (let i = 0; i < 2000 && shelves.length < CFG.shelves * 2; i++) {
        const a = Math.floor(r3() * mainPath.length), b = Math.floor(r3() * mainPath.length);
        const i1 = Math.min(a, b), i2 = Math.max(a, b), P1 = mainPath[i1], P2 = mainPath[i2];
        const d = Math.hypot(P1[0] - P2[0], P1[1] - P2[1]);
        if (i2 - i1 < 40 || i2 - i1 < d * 1.6 || d < 8 || d > 30) continue;
        if (!okSpot(P1[0], P1[1]) || !okSpot(P2[0], P2[1]) || !free(P1[0], P1[1], 6) || !free(P2[0], P2[1], 6)) continue;
        const A = placeNear(P1, 2, 3, 6), B2 = A && placeNear(P2, 2, 3, 6);
        if (!A || !B2) continue;
        const k = shelves.length;
        shelves.push({ tx: A[0], ty: A[1], x: tc(A[0]), y: tc(A[1]), to: k + 1, cd: 0, inside: false });
        shelves.push({ tx: B2[0], ty: B2[1], x: tc(B2[0]), y: tc(B2[1]), to: k, cd: 0, inside: false });
      }
    }
    if (CFG.boxes) {
      for (let i = 0; i < 500 && boxes.length < CFG.boxes; i++) {
        const p = pathPoint(q => boxes.every(o => Math.abs(o.tx - q[0]) + Math.abs(o.ty - q[1]) > 7));
        if (!p) break;
        const s = placeNear(p, 2, 4, 3); if (s) boxes.push({ tx: s[0], ty: s[1], x: tc(s[0]), y: tc(s[1]) });
      }
    }
    if (CFG.fires) {
      for (let i = 0; i < 600 && fires.length < CFG.fires; i++) {
        const p = pathPoint(q => Math.abs(q[0] - START.x) + Math.abs(q[1] - START.y) > 7 && fires.every(o => Math.abs(o.tx - q[0]) + Math.abs(o.ty - q[1]) > 18));
        if (!p) break;
        const s = placeNear(p, 2, 3, 3); if (s) fires.push({ tx: s[0], ty: s[1], x: tc(s[0]), y: tc(s[1]), lit: false, ph: r3() * 6 });
      }
    }
    const placeIn = (arr, n, bset, sep, dmin, dmax, mk) => {
      for (let i = 0; i < 900 && arr.length < n; i++) {
        const p = pathPoint(q => bset.includes(biomeMap[q[1] * MW + q[0]]) && arr.every(o => Math.abs(o.tx - q[0]) + Math.abs(o.ty - q[1]) > sep));
        if (!p) break;
        const s = placeNear(p, dmin, dmax, 3); if (s) arr.push(Object.assign({ tx: s[0], ty: s[1], x: tc(s[0]), y: tc(s[1]) }, mk()));
      }
    };
    if (CFG.holes) placeIn(holes, CFG.holes, [28], 10, 2, 4, () => ({ cd: 0, prog: 0 }));
    if (CFG.ovens) placeIn(ovens, CFG.ovens, [29], 14, 2, 3, () => ({ cd: 0, prog: 0, ph: r3() * 6 }));
    if (CFG.drifts) placeIn(drifts, CFG.drifts, [27, 28, 30, 31], 6, 2, 5, () => ({ hp: 3, done: false, s: 0.85 + r3() * 0.3 }));
    // дорожки к объектам прокладываются после деревьев – убираем деревья вплотную к любой дорожке
    for (let ty = 1; ty < MH - 1; ty++) for (let tx = 1; tx < MW - 1; tx++) {
      const i = ty * MW + tx; if (!treeGrid[i]) continue;
      const pt = u => u === PATH || u === STONE;
      if (pt(tiles[i]) || pt(tiles[i - 1]) || pt(tiles[i + 1]) || pt(tiles[i - MW]) || pt(tiles[i + MW])) treeGrid[i] = 0;
    }
    // ---- сундуки: редкость и мимики ----
    if (chests.length) {
      const r5 = mulberry32(SEED + 313), dist0 = ch => Math.abs(ch.tx - START.x) + Math.abs(ch.ty - START.y);
      for (const ch of chests) { ch.tier = 'wood'; ch.mimic = false; ch.seen = false; }
      const far = chests.slice().sort((a, b) => dist0(b) - dist0(a)).slice(0, Math.max(2, Math.ceil(chests.length / 3)));
      for (let k = 0; k < (CHN === 1 ? 1 : 2) && far.length; k++) far.splice(Math.floor(r5() * far.length), 1)[0].tier = 'gold';
      for (const ch of chests) if (ch.tier !== 'gold') {
        if (r5() < 0.28) ch.tier = 'silver';
        if (r5() < 0.13 && dist0(ch) > 18) ch.mimic = true;
      }
    }
    // ---- глава 6: часть сундуков вмёрзла в ледяные стены ----
    const reachAll = () => {
        const seen = new Uint8Array(MW * MH), q = [START.y * MW + START.x]; seen[q[0]] = 1;
        for (let k = 0; k < q.length; k++) {
          const i = q[k], x = i % MW, y = (i - x) / MW;
          for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
            const nx = x + dx, ny = y + dy; if (!inMap(nx, ny)) continue;
            const j = ny * MW + nx; if (seen[j]) continue;
            const u = tiles[j]; if (u === ROCK || u === WALL || u === WATER || u === LAVA) continue;
            seen[j] = 1; q.push(j);
          }
        }
        const pts = [...shrines.map(o => [o.tx, o.ty]), ...guards.map(o => [o.x, o.y]), [GATE_FRONT.x, GATE_FRONT.y], ...fires.filter(o => !o.glade).map(o => [o.tx, o.ty]),
          ...chests.filter(o => !o.iced && !o.glade).map(o => [o.tx, o.ty]), ...holes.map(o => [o.tx, o.ty]), ...ovens.map(o => [o.tx, o.ty])];
        return pts.every(([x, y]) => seen[y * MW + x]);
      };
    if (CFG.icedChests && chests.length) {
      const r7 = mulberry32(SEED + 521);
      for (const ch of chests) {
        ch.iced = false;
        if (ch.mimic || r7() >= CFG.icedChests) continue;
        const ring = [];
        let ok = true;
        for (let y = ch.ty - 2; y <= ch.ty + 2 && ok; y++) for (let x = ch.tx - 2; x <= ch.tx + 2; x++) {
          if (Math.max(Math.abs(x - ch.tx), Math.abs(y - ch.ty)) !== 2) continue;
          const i = y * MW + x;
          if (!inMap(x, y) || x < 3 || y < 3 || x >= MW - 3 || y >= MH - 3 || !BIOMES[biomeMap[i]].meltable || tiles[i] === WALL || tiles[i] === GATE || tiles[i] === FLOOR) { ok = false; break; }
          ring.push([i, tiles[i], treeGrid[i]]);
        }
        if (!ok) continue;
        for (const [i] of ring) { tiles[i] = ROCK; treeGrid[i] = 0; }
        ch.iced = true;
        if (!reachAll()) { for (const [i, u, tr] of ring) { tiles[i] = u; treeGrid[i] = tr; } ch.iced = false; }
      }
    }
    // ---- тайные поляны за ледяной стеной: сундук, костёр или снежный барс ----
    if (CFG.glades) {
      const r8 = mulberry32(SEED + 919), kinds = ['chest', 'beast', 'fire', 'chest'];
      for (let it = 0; it < 3000 && glades.length < CFG.glades; it++) {
        const cx = 12 + Math.floor(r8() * (MW - 24)), cy = 12 + Math.floor(r8() * (MH - 24));
        if (![27, 28, 31].includes(biomeMap[cy * MW + cx])) continue;
        if (Math.abs(cx - CASTLE.x) < h + 10 && Math.abs(cy - CASTLE.y) < h + 10) continue;
        if (Math.abs(cx - START.x) + Math.abs(cy - START.y) < 20) continue;
        if (CFG.bossTiles.some(b => Math.hypot(b.x - cx, b.y - cy) < 16)) continue;
        if (mainPath.some(([px, py]) => Math.abs(px - cx) + Math.abs(py - cy) < 9)) continue;
        const near = (arr, d) => arr.some(o => Math.hypot(o.tx - cx, o.ty - cy) < d);
        if (near(chests, 9) || near(shrines, 12) || near(fires, 8) || near(glades, 30) || near(holes, 8) || near(ovens, 8)) continue;
        const ring = [], inner = [];
        let ok = true;
        for (let y = cy - 6; y <= cy + 6 && ok; y++) for (let x = cx - 6; x <= cx + 6; x++) {
          const d = Math.hypot(x - cx, y - cy), i = y * MW + x;
          if (d > 5.6) continue;
          if (!BIOMES[biomeMap[i]].meltable || tiles[i] === WALL || tiles[i] === FLOOR || tiles[i] === GATE) { ok = false; break; }
          (d >= 4.5 ? ring : inner).push([i, tiles[i], treeGrid[i]]);
        }
        if (!ok) continue;
        for (const [i] of ring) { tiles[i] = ROCK; treeGrid[i] = 0; }
        for (const [i] of inner) { tiles[i] = biomeMap[i]; treeGrid[i] = 0; }
        if (!reachAll()) { for (const [i, u, tr] of ring.concat(inner)) { tiles[i] = u; treeGrid[i] = tr; } continue; }
        const g = { tx: cx, ty: cy, x: tc(cx), y: tc(cy), kind: kinds[glades.length % kinds.length], ring: ring.map(r => r[0]), open: false, done: false, seen: false };
        glades.push(g);
        if (g.kind === 'chest') chests.push({ tx: cx, ty: cy, x: tc(cx), y: tc(cy), open: false, biome: biomeMap[cy * MW + cx], tier: r8() < 0.5 ? 'gold' : 'silver', mimic: false, seen: false, glade: true, iced: false });
        else if (g.kind === 'fire') fires.push({ tx: cx, ty: cy, x: tc(cx), y: tc(cy), lit: false, ph: r8() * 6, glade: true });
      }
    }
    // ---- карманная арена испытаний: под картой, за полосой пустоты ----
    PLAY_H = MH;
    const GAP = 14, AS = 22, NH = MH + GAP + AS + 2;
    const nt = new Uint8Array(MW * NH), nbm = new Uint8Array(MW * NH), ngr = new Int32Array(MW * NH);
    nt.set(tiles); nbm.set(biomeMap); ngr.set(treeGrid);
    for (let y = MH; y < NH; y++) for (let x = 0; x < MW; x++) { nt[y * MW + x] = WALL; nbm[y * MW + x] = ARENA_BIOME; }
    const ax0 = Math.floor(MW / 2 - AS / 2), ay0 = MH + GAP, half = AS / 2 - 1;
    for (let y = ay0; y < ay0 + AS; y++) for (let x = ax0; x < ax0 + AS; x++) {
      const qx = (x - (ax0 + AS / 2 - 0.5)) / half, qy = (y - (ay0 + AS / 2 - 0.5)) / half;
      if (qx ** 4 + qy ** 4 <= 1) nt[y * MW + x] = FLOOR; // скруглённый квадрат
    }
    for (const [px, py] of [[-6, -6], [4, -6], [-6, 4], [4, 4]]) for (let dy = 0; dy < 2; dy++) for (let dx = 0; dx < 2; dx++) nt[(ay0 + AS / 2 + py + dy) * MW + ax0 + AS / 2 + px + dx] = WALL;
    tiles = nt; biomeMap = nbm; treeGrid = ngr; MH = NH; WORLD_H = MH * T;
    ARENA = { x: tc(ax0 + AS / 2), y: tc(ay0 + AS / 2), exit: { x: tc(ax0 + AS / 2), y: tc(ay0 + AS - 3) } };
    chunkCache.clear();
    buildMinimap();
  }

  // ------------------------------------------------------------------
  //  Отрисовка карты чанками
  // ------------------------------------------------------------------
  const PAL = {
    [PATH]: ['#7a5236', '#855b3c', '#6c482f'], [STONE]: ['#8a8a8e', '#98989c', '#7c7c80'],
    [WATER]: ['#8fcbe8', '#a2d7f0', '#82bfdc'], [ROCK]: ['#a4a4a8', '#b2b2b6', '#96969a'],
    [WALL]: ['#4e4262', '#584b6e', '#433856'], [LAVA]: ['#e0521b', '#f57a24', '#c8410f'],
    [FLOOR]: ['#4b4458', '#554d63', '#433d50'], [ICE]: ['#bfe5f4', '#d4f0fb', '#aed8ea'],
  };
  const PATH_BY_BIOME = { 5: ['#c9a466', '#d2ae70', '#bd9858'], 6: ['#5a4038', '#644840', '#4e3830'], 7: ['#4a4a6e', '#545478', '#404062'], 8: ['#3a2a5a', '#443266', '#30224c'] };
  const CHUNK = 16, CHPX = CHUNK * T;
  const chunkCache = new Map();

  function tilePal(t, b) {
    if (isGround(t)) return BIOMES[t].ground;
    const bi = BIOMES[b];
    if (t === WATER && bi.water) return bi.water;
    if (t === ROCK && bi.rock) return bi.rock;
    if (t === PATH && bi.path) return bi.path;
    if (t === PATH && PATH_BY_BIOME[b]) return PATH_BY_BIOME[b];
    if (t === STONE && bi.mirror) return ['#e4e4f6', '#f2f2ff', '#d6d6ec'];
    if (t === GATE) return PAL[FLOOR];
    return PAL[t];
  }
  function drawTile(c, tx, ty, ox, oy) {
    const i = ty * MW + tx, t = tiles[i], b = biomeMap[i], bi = BIOMES[b];
    const neon = bi.neon;
    if ((t === FLOOR || t === GATE) && neon) {
      c.fillStyle = (tx + ty) % 2 ? '#22143e' : '#2a1a4c'; c.fillRect(ox, oy, T, T);
      c.strokeStyle = 'rgba(63,240,255,0.25)'; c.lineWidth = 1; c.strokeRect(ox + 0.5, oy + 0.5, T - 1, T - 1);
      return;
    }
    if (t === WALL && neon) {
      c.fillStyle = '#1e1236'; c.fillRect(ox, oy, T, T);
      c.fillStyle = '#ff3ea5'; c.fillRect(ox, oy, T, 3);
      c.fillStyle = 'rgba(255,62,165,0.3)'; c.fillRect(ox, oy + 3, T, 3);
      if (tileAt(tx, ty + 1) !== WALL) { c.fillStyle = '#120a22'; c.fillRect(ox, oy + T - 12, T, 12); c.fillStyle = '#3ff0ff'; c.fillRect(ox, oy + T - 13, T, 2); }
      return;
    }
    if (bi.arena) {
      const st = ARENA_STYLE[CHN] || ARENA_STYLE[1];
      if (t === FLOOR) {
        c.fillStyle = (tx + ty) % 2 ? st.floor[0] : st.floor[1]; c.fillRect(ox, oy, T, T);
        const h = hash2(tx * 5 + 3, ty * 7 + 1);
        if (h < 0.45) { c.strokeStyle = st.crack; c.lineWidth = 2; c.beginPath(); c.moveTo(ox + h * T, oy); c.lineTo(ox + T * 0.5, oy + T * (0.3 + h)); c.lineTo(ox + T * (1 - h), oy + T); c.stroke(); }
        if (h > 0.85) { c.fillStyle = st.ember; c.beginPath(); c.arc(ox + 20, oy + 20, 3, 0, TAU); c.fill(); }
        return;
      }
      const nearFloor = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [-1, -1], [1, -1], [-1, 1]].some(([dx, dy]) => tileAt(tx + dx, ty + dy) === FLOOR);
      if (!nearFloor) { c.fillStyle = '#040208'; c.fillRect(ox, oy, T, T); if (hash2(tx, ty) < 0.04) { c.fillStyle = st.ember; c.fillRect(ox + 18, oy + 18, 2, 2); } return; }
      c.fillStyle = st.wall; c.fillRect(ox, oy, T, T);
      c.fillStyle = 'rgba(0,0,0,0.3)'; for (let k = 0; k < 4; k++) c.fillRect(ox, oy + k * 10, T, 2);
      if (tileAt(tx, ty + 1) === FLOOR) { c.fillStyle = st.crack; c.fillRect(ox, oy + T - 4, T, 3); }
      return;
    }
    if (bi.castleStyle === 'ice' && (t === FLOOR || t === GATE)) {
      c.fillStyle = (tx + ty) % 2 ? '#cfe8f8' : '#bcdcf2'; c.fillRect(ox, oy, T, T);
      c.fillStyle = 'rgba(255,255,255,0.45)'; c.beginPath(); c.moveTo(ox + 4, oy + T - 6); c.lineTo(ox + 12, oy + T - 6); c.lineTo(ox + T - 6, oy + 6); c.lineTo(ox + T - 14, oy + 6); c.fill();
      c.strokeStyle = 'rgba(90,150,200,0.35)'; c.lineWidth = 1; c.strokeRect(ox + 0.5, oy + 0.5, T - 1, T - 1);
      if (hash2(tx, ty) < 0.07) { c.fillStyle = '#ffffff'; star(c, ox + 20, oy + 20, 3, 0, 6); c.fill(); }
      return;
    }
    if (bi.castleStyle === 'ice' && t === WALL) {
      c.fillStyle = '#7aa8d8'; c.fillRect(ox, oy, T, T);
      c.fillStyle = 'rgba(255,255,255,0.35)'; c.fillRect(ox + 5, oy + 6, 5, 22); c.fillRect(ox + 22, oy + 4, 3, 14);
      c.fillStyle = '#e8f8ff'; c.fillRect(ox, oy, T, 3);
      if (tileAt(tx, ty + 1) !== WALL) {
        c.fillStyle = '#3a6a9a'; c.fillRect(ox, oy + T - 12, T, 12);
        c.fillStyle = '#bfeaff'; for (let k = 0; k < 4; k++) { c.beginPath(); c.moveTo(ox + k * 10 + 2, oy + T - 12); c.lineTo(ox + k * 10 + 8, oy + T - 12); c.lineTo(ox + k * 10 + 5, oy + T - 3 - (k % 2) * 4); c.fill(); }
      }
      return;
    }
    if (bi.castleStyle && (t === FLOOR || t === GATE)) {
      const night = bi.castleStyle === 'attic';
      for (let k = 0; k < 4; k++) { c.fillStyle = night ? ((k + tx) % 2 ? '#2a2230' : '#241d2a') : ((k + tx) % 2 ? '#d4a676' : '#c89a6a'); c.fillRect(ox, oy + k * 10, T, 9); }
      c.fillStyle = 'rgba(0,0,0,0.3)'; c.fillRect(ox + ((tx * 13 + ty * 7) % 4) * 10, oy, 1.5, T);
      if (night && hash2(tx, ty) < 0.08) { c.fillStyle = '#3ff0a0'; c.fillRect(ox + 10 + hash2(ty, tx) * 20, oy + 14, 3, 3); }
      return;
    }
    if (bi.castleStyle && t === WALL) {
      const night = bi.castleStyle === 'attic';
      c.fillStyle = night ? '#3a2a24' : '#8a5a3a'; c.fillRect(ox, oy, T, T);
      c.fillStyle = 'rgba(0,0,0,0.25)'; for (let k = 0; k < 4; k++) c.fillRect(ox, oy + k * 10, T, 2);
      if (tileAt(tx, ty + 1) !== WALL) { c.fillStyle = night ? '#1a1210' : '#5a3a20'; c.fillRect(ox, oy + T - 12, T, 12); c.fillStyle = night ? '#3ff0a0' : '#ffd25a'; c.fillRect(ox, oy + T - 13, T, 2); }
      return;
    }
    if (bi.mirror && (t === FLOOR || t === GATE)) {
      c.fillStyle = (tx + ty) % 2 ? '#dcdcf2' : '#c8c8e4'; c.fillRect(ox, oy, T, T);
      c.fillStyle = 'rgba(255,255,255,0.45)'; c.beginPath(); c.moveTo(ox + 4, oy + T - 4); c.lineTo(ox + 14, oy + T - 4); c.lineTo(ox + T - 4, oy + 4); c.lineTo(ox + T - 14, oy + 4); c.fill();
      c.strokeStyle = 'rgba(120,120,170,0.35)'; c.lineWidth = 1; c.strokeRect(ox + 0.5, oy + 0.5, T - 1, T - 1);
      return;
    }
    if (bi.mirror && t === WALL) {
      c.fillStyle = '#9a9abc'; c.fillRect(ox, oy, T, T);
      c.fillStyle = '#ffffff'; c.fillRect(ox, oy, T, 3);
      c.fillStyle = 'rgba(255,255,255,0.35)'; c.fillRect(ox + 6, oy + 8, 4, 20);
      if (tileAt(tx, ty + 1) !== WALL) { c.fillStyle = '#5a5a7a'; c.fillRect(ox, oy + T - 12, T, 12); c.fillStyle = '#bfeaff'; c.fillRect(ox, oy + T - 13, T, 2); }
      return;
    }
    if (bi.rainbow && t === PATH) {
      for (let k = 0; k < 4; k++) { c.fillStyle = RAINBOW[(tx + ty + k) % 7]; c.fillRect(ox, oy + k * 10, T, 10); }
      c.fillStyle = 'rgba(255,255,255,0.35)'; c.fillRect(ox, oy, T, T);
      return;
    }
    const pal = tilePal(t, b);
    // вода, камни, лава, лёд и дорожки – со скруглёнными краями поверх земли
    const organic = t === PATH || t === WATER || t === LAVA || t === ICE || (t === STONE && !bi.mirror) || (t === ROCK && !bi.furniture && !bi.fence);
    let ex = null;
    if (organic) {
      c.save();
      ex = tileShape(c, ox, oy, tx, ty, sameGroup(t), t === PATH || t === STONE ? 11 : 15);
      c.fillStyle = pal[0]; c.fill(); c.clip();
    } else if (!isGround(t)) { c.fillStyle = pal[0]; c.fillRect(ox, oy, T, T); }
    if (!isGround(t) && !(t === ROCK && (bi.furniture || bi.fence))) for (let k = 0; k < 9; k++) {
      const h1 = hash2(tx * 31 + k * 7, ty * 17 + k * 13), h2 = hash2(tx * 11 + k * 29, ty * 41 + k * 3);
      c.fillStyle = pal[1 + (k & 1)];
      if (organic) { c.beginPath(); c.arc(ox + 2 + Math.floor(h1 * 9) * 4, oy + 2 + Math.floor(h2 * 9) * 4, 2.2, 0, TAU); c.fill(); }
      else c.fillRect(ox + Math.floor(h1 * 9) * 4, oy + Math.floor(h2 * 9) * 4, 4, 4);
    }
    const below = tileAt(tx, ty + 1), above = tileAt(tx, ty - 1);
    const hr = hash2(tx * 7 + 3, ty * 5 + 1);
    if (t === FLOOR || t === GATE) {
      c.strokeStyle = 'rgba(0,0,0,0.25)'; c.lineWidth = 2; c.strokeRect(ox + 1, oy + 1, T - 2, T - 2);
    } else if (t === WALL) {
      c.fillStyle = 'rgba(0,0,0,0.25)';
      for (let r = 0; r < 4; r++) { c.fillRect(ox, oy + r * 10, T, 2); c.fillRect(ox + ((r & 1) ? 6 : 26), oy + r * 10, 2, 10); }
      if (below !== WALL) { c.fillStyle = '#2c2238'; c.fillRect(ox, oy + T - 12, T, 12); c.fillStyle = '#7a6a94'; c.fillRect(ox, oy, T, 3); }
    } else if (t === ROCK && (bi.furniture || bi.fence)) {
      drawFurniture(c, bi, pal, ox, oy, below, above, hr);
    } else if (t === ROCK) {
      c.fillStyle = 'rgba(255,255,255,0.18)'; c.fillRect(ox + 4, oy + 6, 10, 3);
      if (below !== ROCK) { c.fillStyle = shade(pal[0], -0.3); c.fillRect(ox, oy + T - 12, T, 12); c.fillStyle = 'rgba(0,0,0,0.25)'; c.fillRect(ox, oy + T - 4, T, 4); }
      if (above !== ROCK) { c.fillStyle = 'rgba(255,255,255,0.3)'; c.fillRect(ox, oy, T, 3); }
      if (b === 7 && hr < 0.4) { c.fillStyle = 'rgba(91,227,255,0.6)'; c.fillRect(ox + 14, oy + 10, 4, 10); }
      if (bi.candy) { c.fillStyle = 'rgba(255,111,181,0.7)'; for (let k = -2; k < 4; k++) { c.beginPath(); c.moveTo(ox + k * 14, oy + T); c.lineTo(ox + k * 14 + 7, oy + T); c.lineTo(ox + k * 14 + 7 + T, oy); c.lineTo(ox + k * 14 + T, oy); c.fill(); } }
      if (bi.mirror) { c.fillStyle = 'rgba(255,255,255,0.6)'; c.beginPath(); c.moveTo(ox + 6, oy + 26); c.lineTo(ox + 12, oy + 26); c.lineTo(ox + 26, oy + 6); c.lineTo(ox + 20, oy + 6); c.fill(); }
      if (b === 9 && hr < 0.5) { c.fillStyle = '#ff3ea5'; c.fillRect(ox + 4, oy + 12, 30, 3); c.fillStyle = '#3ff0ff'; c.fillRect(ox + 8, oy + 16, 26, 2); }
      if (b === 12) { c.fillStyle = ['#c0392b', '#2980b9', '#f1c40f'][Math.floor(hr * 3)]; c.fillRect(ox + 8 + hr * 14, oy + 10, 8, 5); }
      if (neon && hr < 0.5) { c.fillStyle = '#ff3ea5'; c.fillRect(ox + 6, oy + 14, 28, 2); }
    } else if (t === WATER) {
      c.fillStyle = 'rgba(255,255,255,0.35)';
      if (hr < 0.5) c.fillRect(ox + 8 + Math.floor(hr * 30), oy + 14, 10, 2);
      if (above !== WATER) { c.fillStyle = 'rgba(0,30,60,0.35)'; c.fillRect(ox, oy, T, 6); }
      if (b === 11) { c.fillStyle = '#ffffff'; c.fillRect(ox + Math.floor(hr * 30), oy + Math.floor(hash2(ty, tx) * 30), 2, 2); c.fillRect(ox + Math.floor(hash2(tx, 7) * 34), oy + Math.floor(hash2(9, ty) * 34), 1, 1); }
      if (b === 12 && hr < 0.6) { c.fillStyle = 'rgba(220,255,180,0.8)'; c.beginPath(); c.arc(ox + 8 + hr * 24, oy + 12 + hr * 14, 3, 0, TAU); c.fill(); }
      if (b === 9) { c.fillStyle = 'rgba(63,240,160,0.55)'; c.fillRect(ox + 6 + Math.floor(hr * 20), oy + 8, 2, 6); c.fillRect(ox + 20, oy + 22 + Math.floor(hr * 8), 5, 2); }
    } else if (t === LAVA) {
      c.fillStyle = '#ffd23a';
      for (let k = 0; k < 3; k++) {
        const hh = hash2(tx * 3 + k, ty * 9 + k);
        c.fillRect(ox + Math.floor(hh * 8) * 4, oy + Math.floor(hash2(ty + k, tx * 2) * 8) * 4, 6, 4);
      }
      if (above !== LAVA) { c.fillStyle = 'rgba(60,0,0,0.4)'; c.fillRect(ox, oy, T, 6); }
    } else if (t === ICE) {
      c.strokeStyle = 'rgba(255,255,255,0.7)'; c.lineWidth = 2;
      c.beginPath(); c.moveTo(ox + 6 + hr * 10, oy + 30); c.lineTo(ox + 22 + hr * 10, oy + 14); c.stroke();
    } else if (isGround(t)) {
      drawDeco(c, bi.deco, tx, ty, ox, oy);
      if (above === ROCK || above === WALL) { c.fillStyle = 'rgba(0,0,0,0.3)'; c.fillRect(ox, oy, T, 7); }
    }
    if (organic) {
      // кромка: пена у воды, тень у дорожки
      const wet = t === WATER || t === LAVA || t === ICE;
      c.fillStyle = wet ? 'rgba(255,255,255,0.22)' : t === ROCK ? 'rgba(0,0,0,0.12)' : 'rgba(0,0,0,0.1)';
      const bw = wet ? 3 : 2;
      if (!ex.n) c.fillRect(ox, oy, T, bw); if (!ex.s) c.fillRect(ox, oy + T - bw, T, bw);
      if (!ex.w) c.fillRect(ox, oy, bw, T); if (!ex.e) c.fillRect(ox + T - bw, oy, bw, T);
      c.restore();
    }
  }
  // ---- поверхность: земля в два слоя (основа + мягкие пятна), формы со скруглёнными краями ----
  function drawGroundBase(c, tx, ty, ox, oy) {
    const i = ty * MW + tx, t = tiles[i], bi = BIOMES[isGround(t) ? t : biomeMap[i]];
    if (t === FLOOR || t === WALL || t === GATE) return;
    const pal = bi.ground;
    c.fillStyle = pal[0]; c.fillRect(ox, oy, T, T);
    if (bi.floor) { drawFloor(c, bi.floor, pal, tx, ty, ox, oy); return; }
    for (let k = 0; k < 14; k++) {
      const h1 = hash2(tx * 31 + k * 7, ty * 17 + k * 13), h2 = hash2(tx * 11 + k * 29, ty * 41 + k * 3), s = 2 + Math.floor(hash2(tx + k * 5, ty * 3 + k) * 3);
      c.fillStyle = pal[1 + (k & 1)];
      c.fillRect(ox + Math.floor(h1 * 19) * 2, oy + Math.floor(h2 * 19) * 2, s, s);
    }
  }
  function drawGroundDetail(c, tx, ty, ox, oy) {
    if (!inMap(tx, ty)) return;
    const i = ty * MW + tx, t = tiles[i], bi = BIOMES[isGround(t) ? t : biomeMap[i]];
    if (t === FLOOR || t === WALL || t === GATE || bi.floor) return;
    const pal = bi.ground, h1 = hash2(tx * 3 + 11, ty * 7 + 5), h2 = hash2(tx * 13 + 1, ty * 5 + 3), h3 = hash2(tx + 17, ty * 19 + 2);
    c.globalAlpha = 0.45;
    c.fillStyle = h1 < 0.5 ? pal[1] : pal[2];
    c.beginPath(); c.ellipse(ox + h2 * T, oy + h3 * T, 9 + h1 * 13, 6 + h3 * 9, h2 * 3, 0, TAU); c.fill();
    if (h3 > 0.55) { c.fillStyle = shade(pal[0], h2 > 0.5 ? 0.1 : -0.1); c.beginPath(); c.arc(ox + h1 * T, oy + h2 * T, 7 + h3 * 9, 0, TAU); c.fill(); }
    c.globalAlpha = 1;
    if (bi.deco === 'grass' || bi.deco === 'flowers' || bi.deco === 'reeds' || bi.deco === 'glitch' || bi.deco === 'leaves') {
      c.strokeStyle = shade(pal[0], -0.28); c.lineWidth = 1.5;
      for (let k = 0; k < 3; k++) {
        const x = ox + hash2(tx * 7 + k, ty * 3 + 1) * T, y = oy + hash2(ty * 7 + k, tx * 5 + 2) * T;
        c.beginPath(); c.moveTo(x, y + 4); c.lineTo(x - 2.5, y - 2); c.moveTo(x, y + 4); c.lineTo(x + 2, y - 3); c.stroke();
      }
    }
  }
  const sameGroup = t => (t === PATH || t === STONE) ? (u => u === PATH || u === STONE || u === GATE || u === FLOOR)
    : t === ROCK ? (u => u === ROCK || u === WALL) : (u => u === t);
  function tileShape(c, ox, oy, tx, ty, test, r) {
    const n = test(tileAt(tx, ty - 1)), s = test(tileAt(tx, ty + 1)), w = test(tileAt(tx - 1, ty)), e = test(tileAt(tx + 1, ty));
    const tl = !n && !w ? r : 0, tr = !n && !e ? r : 0, br = !s && !e ? r : 0, bl = !s && !w ? r : 0;
    c.beginPath();
    c.moveTo(ox + tl, oy);
    c.lineTo(ox + T - tr, oy); if (tr) c.quadraticCurveTo(ox + T, oy, ox + T, oy + tr);
    c.lineTo(ox + T, oy + T - br); if (br) c.quadraticCurveTo(ox + T, oy + T, ox + T - br, oy + T);
    c.lineTo(ox + bl, oy + T); if (bl) c.quadraticCurveTo(ox, oy + T, ox, oy + T - bl);
    c.lineTo(ox, oy + tl); if (tl) c.quadraticCurveTo(ox, oy, ox + tl, oy);
    c.closePath();
    return { n, s, w, e };
  }

  function drawFloor(c, kind, pal, tx, ty, ox, oy) {
    c.save(); c.beginPath(); c.rect(ox, oy, T, T); c.clip();
    switch (kind) {
      case 'parquet':
        if ((tx + ty) % 2) { c.fillStyle = pal[1]; c.fillRect(ox, oy, T, T / 2 - 1); c.fillStyle = pal[2]; c.fillRect(ox, oy + T / 2, T, T / 2 - 1); }
        else { c.fillStyle = pal[2]; c.fillRect(ox, oy, T / 2 - 1, T); c.fillStyle = pal[1]; c.fillRect(ox + T / 2, oy, T / 2 - 1, T); }
        c.fillStyle = 'rgba(0,0,0,0.18)'; c.fillRect(ox, oy + T - 1, T, 1); c.fillRect(ox + T - 1, oy, 1, T);
        break;
      case 'boards':
        for (let k = 0; k < 4; k++) { c.fillStyle = pal[(k + tx) % 2 ? 1 : 2]; c.fillRect(ox, oy + k * 10, T, 9); }
        c.fillStyle = 'rgba(0,0,0,0.25)'; c.fillRect(ox + ((tx * 13 + ty * 7) % 4) * 10, oy, 1.5, T);
        break;
      case 'checker':
        c.fillStyle = (tx + ty) % 2 ? pal[1] : shade(pal[0], -0.12); c.fillRect(ox, oy, T, T);
        c.fillStyle = 'rgba(255,255,255,0.12)'; c.fillRect(ox + 2, oy + 2, T - 4, 3);
        break;
      case 'tiles':
        for (let k = 0; k < 2; k++) for (let m = 0; m < 2; m++) { c.fillStyle = (k + m + tx + ty) % 2 ? pal[1] : pal[2]; c.fillRect(ox + k * 20 + 1, oy + m * 20 + 1, 18, 18); }
        break;
      case 'carpet':
        for (let k = 0; k < 6; k++) { c.fillStyle = pal[1 + (k & 1)]; c.fillRect(ox + Math.floor(hash2(tx * 5 + k, ty * 3 + k) * 18) * 2, oy + Math.floor(hash2(ty + k, tx * 2 + k) * 18) * 2, 3, 3); }
        if ((tx * 3 + ty * 5) % 7 === 0) { c.fillStyle = shade(pal[0], 0.15); c.beginPath(); c.arc(ox + 20, oy + 20, 6, 0, TAU); c.fill(); }
        break;
      case 'paving': {
        const off = ty % 2 ? 10 : 0;
        for (let k = -1; k < 3; k++) { c.fillStyle = pal[(k + tx + ty + 8) % 2 ? 1 : 2]; c.fillRect(ox + k * 20 + off + 1, oy + 1, 18, 18); c.fillRect(ox + k * 20 + 11 - off, oy + 21, 18, 18); }
        break;
      }
    }
    c.restore();
  }
  function drawFurniture(c, bi, pal, ox, oy, below, above, hr) {
    if (bi.fence) {
      c.fillStyle = shade(pal[0], -0.25); c.fillRect(ox, oy, T, T);
      for (let k = 0; k < 4; k++) { c.fillStyle = pal[1]; c.fillRect(ox + k * 10 + 1, oy + 4, 8, T - 4); c.beginPath(); c.moveTo(ox + k * 10 + 1, oy + 4); c.lineTo(ox + k * 10 + 5, oy); c.lineTo(ox + k * 10 + 9, oy + 4); c.fill(); }
      c.fillStyle = 'rgba(0,0,0,0.25)'; c.fillRect(ox, oy + 12, T, 3); c.fillRect(ox, oy + 28, T, 3);
      return;
    }
    if (bi.toyRocks) {
      const col = pal[Math.floor(hr * 3)];
      c.fillStyle = col; c.fillRect(ox + 1, oy + 1, T - 2, T - 2); c.strokeStyle = shade(col, -0.35); c.lineWidth = 2; c.strokeRect(ox + 2, oy + 2, T - 4, T - 4);
      c.fillStyle = 'rgba(255,255,255,0.85)'; c.font = 'bold 18px sans-serif'; c.textAlign = 'center'; c.fillText('АБВГДЕЖЗ'[Math.floor(hr * 8)], ox + T / 2, oy + T / 2 + 6);
      return;
    }
    if (above !== ROCK) { c.fillStyle = shade(pal[0], 0.25); c.fillRect(ox, oy, T, 6); }
    c.strokeStyle = 'rgba(0,0,0,0.35)'; c.lineWidth = 1.5; c.strokeRect(ox + 4, oy + 9, T - 8, 12); c.strokeRect(ox + 4, oy + 24, T - 8, 12);
    c.fillStyle = '#d8c080'; c.fillRect(ox + T / 2 - 3, oy + 14, 6, 2); c.fillRect(ox + T / 2 - 3, oy + 29, 6, 2);
    if (below !== ROCK) { c.fillStyle = shade(pal[0], -0.35); c.fillRect(ox, oy + T - 6, T, 6); }
  }
  function drawDeco(c, deco, tx, ty, ox, oy) {
    const d = hash2(tx * 13 + 5, ty * 19 + 7), e = hash2(tx * 3 + 1, ty * 7 + 2);
    const px = ox + 6 + Math.floor(e * 24), py = oy + 8 + Math.floor((d * 997) % 22);
    switch (deco) {
      case 'grass':
        if (d < 0.12) { c.fillStyle = ['#ff8fb1', '#ffe066', '#b8a6ff'][Math.floor(d * 1000) % 3]; c.fillRect(px, py, 4, 4); }
        else if (d < 0.35) { c.fillStyle = '#2f5a35'; c.fillRect(px, py, 2, 6); c.fillRect(px + 4, py + 2, 2, 4); }
        break;
      case 'reeds':
        if (d < 0.18) { c.fillStyle = '#5c6e2e'; c.fillRect(px, oy + 8, 2, 14); c.fillStyle = '#7a4a2a'; c.fillRect(px - 1, oy + 6, 4, 6); }
        break;
      case 'snow':
        if (d < 0.15) { c.fillStyle = '#ffffff'; c.fillRect(px, py, 3, 3); }
        break;
      case 'bones':
        if (d < 0.08) { c.fillStyle = '#b26bff'; c.fillRect(px, oy + 16, 6, 4); c.fillStyle = '#d9d0e6'; c.fillRect(px + 2, oy + 20, 2, 4); }
        else if (d < 0.14) { c.fillStyle = '#d8d0c0'; c.fillRect(ox + 10, oy + 20, 10, 3); c.fillRect(ox + 9, oy + 19, 3, 5); c.fillRect(ox + 19, oy + 19, 3, 5); }
        break;
      case 'flowers':
        if (d < 0.35) {
          const col = ['#ff6fb5', '#ffe04a', '#ffffff', '#b18cff', '#ff8a3a'][Math.floor(d * 1000) % 5];
          c.fillStyle = col; c.fillRect(px - 2, py, 2, 2); c.fillRect(px + 2, py, 2, 2); c.fillRect(px, py - 2, 2, 2); c.fillRect(px, py + 2, 2, 2);
          c.fillStyle = '#ffd23a'; c.fillRect(px, py, 2, 2);
        } else if (d < 0.5) { c.fillStyle = '#5aa04a'; c.fillRect(px, py, 2, 6); }
        break;
      case 'desert':
        if (d < 0.1) { c.fillStyle = '#b89a5a'; c.fillRect(px, py, 6, 4); }
        else if (d < 0.13) { c.fillStyle = '#f0e8d8'; c.fillRect(px, py, 8, 6); c.fillStyle = '#3a2a1a'; c.fillRect(px + 1, py + 2, 2, 2); c.fillRect(px + 5, py + 2, 2, 2); }
        else if (d < 0.3) { c.fillStyle = 'rgba(160,120,60,0.35)'; c.fillRect(px, py, 12, 2); }
        break;
      case 'embers':
        if (d < 0.14) { c.fillStyle = '#ff8a2a'; c.fillRect(px, py, 3, 3); c.fillStyle = 'rgba(255,138,42,0.3)'; c.fillRect(px - 2, py - 2, 7, 7); }
        else if (d < 0.3) { c.fillStyle = '#1e1414'; c.fillRect(px, py, 10, 2); c.fillRect(px + 8, py, 2, 6); }
        break;
      case 'gems':
        if (d < 0.14) { c.fillStyle = ['#5be3ff', '#c77dff', '#ff6fb5'][Math.floor(d * 1000) % 3]; c.beginPath(); c.moveTo(px, py - 4); c.lineTo(px + 3, py); c.lineTo(px, py + 4); c.lineTo(px - 3, py); c.fill(); }
        break;
      case 'glitch':
        if (d < 0.16) { c.fillStyle = 'rgba(255,62,165,0.6)'; c.fillRect(px, py, 6, 2); c.fillStyle = 'rgba(63,240,255,0.6)'; c.fillRect(px + 2, py + 2, 6, 2); }
        else if (d < 0.26) { c.fillStyle = '#3ff0a0'; c.fillRect(px, py, 3, 3); }
        break;
      case 'sprinkles':
        if (d < 0.4) { for (let k = 0; k < 3; k++) { c.fillStyle = RAINBOW[(Math.floor(d * 100) + k) % 7]; c.fillRect(px + k * 5 - 5, py + (k % 2) * 6, 4, 2); } }
        break;
      case 'sky':
        if (d < 0.08) { c.fillStyle = '#ffe04a'; star(c, px, py, 3); c.fill(); }
        else if (d < 0.25) { c.fillStyle = 'rgba(255,255,255,0.8)'; c.beginPath(); c.arc(px, py, 5, 0, TAU); c.arc(px + 6, py, 4, 0, TAU); c.fill(); }
        break;
      case 'trash':
        if (d < 0.1) { c.fillStyle = '#c0392b'; c.fillRect(px, py, 4, 7); c.fillStyle = '#ddd'; c.fillRect(px, py, 4, 2); }
        else if (d < 0.18) { c.fillStyle = 'rgba(46,204,113,0.7)'; c.fillRect(px, py, 3, 8); }
        else if (d < 0.26) { c.fillStyle = 'rgba(120,255,80,0.25)'; c.beginPath(); c.arc(px, py, 6, 0, TAU); c.fill(); }
        break;
      case 'mirror':
        if (d < 0.1) { c.fillStyle = '#ffffff'; star(c, px, py, 3, 0, 4); c.fill(); }
        else if (d < 0.2) { c.fillStyle = 'rgba(255,255,255,0.5)'; c.fillRect(px, py, 10, 1); }
        break;
      case 'toys':
        if (d < 0.05) { c.fillStyle = ['#ff6a6a', '#6ac8ff', '#ffd25a'][Math.floor(d * 1000) % 3]; c.beginPath(); c.arc(px, py, 3, 0, TAU); c.fill(); }
        else if (d < 0.08) { c.fillStyle = '#ffffff'; c.fillRect(px, py, 4, 4); }
        break;
      case 'dust':
        if (d < 0.12) { c.fillStyle = 'rgba(200,200,220,0.25)'; c.beginPath(); c.arc(px, py, 4, 0, TAU); c.fill(); }
        break;
      case 'crumbs':
        if (d < 0.14) { c.fillStyle = '#c8a060'; c.fillRect(px, py, 2, 2); c.fillRect(px + 4, py + 2, 2, 2); }
        break;
      case 'pixelnight':
        if (d < 0.06) { c.fillStyle = 'rgba(63,240,160,0.5)'; c.fillRect(px, py, 3, 3); }
        else if (d < 0.09) { c.fillStyle = 'rgba(255,62,165,0.4)'; c.fillRect(px, py, 3, 3); }
        break;
      case 'drops':
        if (d < 0.12) { c.fillStyle = 'rgba(160,220,255,0.45)'; c.beginPath(); c.ellipse(px, py, 3, 2, 0, 0, TAU); c.fill(); }
        break;
      case 'leaves':
        if (d < 0.12) { c.fillStyle = ['#d88a3a', '#c8a03a', '#a05a2a'][Math.floor(d * 1000) % 3]; c.beginPath(); c.ellipse(px, py, 4, 2, d * 20, 0, TAU); c.fill(); }
        break;
      case 'neon':
        if ((tx + ty) % 4 === 0) { c.fillStyle = 'rgba(63,240,255,0.18)'; c.fillRect(ox, oy, T, 1); }
        if ((tx * 3 + ty) % 5 === 0) { c.fillStyle = 'rgba(255,62,165,0.18)'; c.fillRect(ox, oy, 1, T); }
        if (d < 0.05) { c.fillStyle = '#ffe04a'; star(c, px, py, 3); c.fill(); }
        break;
    }
  }
  function getChunk(cx, cy) {
    const key = cx + ',' + cy;
    let ch = chunkCache.get(key);
    if (ch) { chunkCache.delete(key); chunkCache.set(key, ch); return ch; }
    ch = makeCanvas(CHPX, CHPX);
    const c = ch.getContext('2d');
    for (let ty = 0; ty < CHUNK; ty++) for (let tx = 0; tx < CHUNK; tx++) {
      const gx = cx * CHUNK + tx, gy = cy * CHUNK + ty;
      if (inMap(gx, gy)) drawGroundBase(c, gx, gy, tx * T, ty * T);
    }
    // мягкие пятна заходят на соседние клетки, поэтому рисуем и рамку вокруг куска – без швов
    for (let ty = -1; ty <= CHUNK; ty++) for (let tx = -1; tx <= CHUNK; tx++) drawGroundDetail(c, cx * CHUNK + tx, cy * CHUNK + ty, tx * T, ty * T);
    for (let ty = 0; ty < CHUNK; ty++) for (let tx = 0; tx < CHUNK; tx++) {
      const gx = cx * CHUNK + tx, gy = cy * CHUNK + ty;
      if (inMap(gx, gy)) drawTile(c, gx, gy, tx * T, ty * T);
    }
    chunkCache.set(key, ch);
    if (chunkCache.size > 42) chunkCache.delete(chunkCache.keys().next().value);
    return ch;
  }

  // мини-карта и туман
  let miniBase = makeCanvas(1, 1), fog = makeCanvas(1, 1);
  function buildMinimap() {
    miniBase = makeCanvas(MW, PLAY_H); fog = makeCanvas(MW, PLAY_H);
    const c = miniBase.getContext('2d');
    const MINI = { [PATH]: '#9a6b45', [STONE]: '#a0a0a4', [WALL]: '#6a5a86', [GATE]: '#ffcf4a', [LAVA]: '#ff6a22', [FLOOR]: '#5a5268', [ICE]: '#c8eefb' };
    for (let ty = 0; ty < PLAY_H; ty++) for (let tx = 0; tx < MW; tx++) {
      const t = tiles[ty * MW + tx], b = biomeMap[ty * MW + tx];
      let col;
      if (isGround(t)) col = BIOMES[t].mini;
      else if (t === WATER) col = (BIOMES[b].water || ['#8fcbe8'])[0];
      else if (t === ROCK) col = shade((BIOMES[b].rock || ['#a4a4a8'])[0], 0.2);
      else col = MINI[t];
      c.fillStyle = col; c.fillRect(tx, ty, 1, 1);
    }
    trees.forEach((tr, k) => { const tx = Math.floor(tr.x / T), ty = Math.floor(tr.y / T); if (treeGrid[ty * MW + tx] === k + 1) { c.fillStyle = 'rgba(0,0,0,0.25)'; c.fillRect(tx, ty, 1, 1); } });
    resetFog();
  }
  function resetFog() { const c = fog.getContext('2d'); c.globalCompositeOperation = 'source-over'; c.fillStyle = '#0d0a16'; c.fillRect(0, 0, MW, MH); }
  function revealFog(x, y, r) {
    const c = fog.getContext('2d');
    c.globalCompositeOperation = 'destination-out';
    const g = c.createRadialGradient(x / T, y / T, r * 0.6, x / T, y / T, r);
    g.addColorStop(0, 'rgba(0,0,0,1)'); g.addColorStop(1, 'rgba(0,0,0,0)');
    c.fillStyle = g; c.beginPath(); c.arc(x / T, y / T, r, 0, TAU); c.fill();
    c.globalCompositeOperation = 'source-over';
  }

  // ------------------------------------------------------------------
  //  Состояние
  // ------------------------------------------------------------------
  let state = 'intro';
  const IMG = { ryzhova: null, zyama: null };
  const AVATAR = {};
  const P = {
    x: 0, y: 0, r: 13, hp: 100, maxHp: 100, face: 1, t: 0, inv: 0, dashT: 0, dashCd: 0, dashX: 0, dashY: 0,
    fireT: 0, boltT: 0, orbA: 0, moving: false, level: 1, xp: 0, xpNext: 10, up: {}, bonus: {},
    vx: 0, vy: 0, slowT: 0, shieldT: 0, shards: 0, hero: 'krilessa', sp: 0, stormT: 0, stormE: 0,
  };
  const G = {
    time: 0, kills: 0, defeated: [], cp: { x: 0, y: 0 },
    enemies: [], feathers: [], ebullets: [], hazards: [], pickups: [], parts: [], texts: [], bolts: [], rings: [], beams: [],
    shake: 0, hurtFlash: 0, activeBoss: null, pendingLv: 0, spawnT: 0, fogT: 0, gateMsgT: 0, lowHpT: 0,
    hintT: 0, cutscene: null, cam: { x: 0, y: 0 }, menuT: 0, victoryShown: false, cageOpen: 0,
    combo: 0, comboT: 0, bestCombo: 0, activeShrine: null, pzones: [], novas: [], scaleCache: {}, shooters: 0,
    diff: DIFFS.normal, diffId: 'normal', ev: null, evT: EVENT_EVERY, lastEv: null, st: null, lowHpSaid: false,
    finalFinal: null, rush: null, trueWin: false, musWant: null, musHold: 0, musT: 0,
  };
  let bosses = [];

  // ------------------------------------------------------------------
  //  Улучшения и характеристики
  // ------------------------------------------------------------------
  const lv = id => P.up[id] || 0;
  const bon = id => P.bonus[id] || 0;
  const talent = id => (G.tal && G.tal[id]) || 0;
  const relicMax = () => 3 + talent('relic');
  function computeStats() {
    const oldMax = P.maxHp;
    Object.assign(P, statsFor(P.up, P.bonus, P.hero));
    if (hasRelic('boots')) { P.speed *= 1.15; P.dashCdMax *= 0.75; }
    if (hasRelic('horseshoe')) P.magnet *= 3;
    if (hasRelic('hourglass')) P.superGain *= 1.4;
    if (hasRelic('clover')) P.crit = Math.min(0.85, P.crit + 0.1);
    if (hasRelic('heartstone')) P.maxHp = Math.round(P.maxHp * 1.25);
    if (hasRelic('crown')) P.dmg *= 1.25;
    // таланты (звёзды)
    if (talent('dmg')) P.dmg *= 1 + 0.05 * talent('dmg');
    if (talent('hp')) P.maxHp = Math.round(P.maxHp * (1 + 0.06 * talent('hp')));
    if (talent('crit')) P.crit = Math.min(0.85, P.crit + 0.03 * talent('crit'));
    if (talent('speed')) P.speed *= 1 + 0.04 * talent('speed');
    if (talent('magnet')) P.magnet *= 1 + 0.25 * talent('magnet');
    if (P.maxHp > oldMax) P.hp += P.maxHp - oldMax;
    P.hp = Math.min(P.hp, P.maxHp);
  }
  const xpFor = l => 5 + l * 4 + Math.floor(l * l * 0.35);
  // ---------- Баланс: всё подстраивается под силу героя ----------
  function nextBossIdx() { for (let i = 0; i < bosses.length; i++) if (!G.defeated[i]) return i; return bosses.length - 1; }
  function zoneE(biome) {
    const keys = Object.keys(CFG.zoneLevel);
    const zl = CFG.zoneLevel[biome] !== undefined ? CFG.zoneLevel[biome] : CFG.zoneLevel[keys[0]];
    const prog = bosses.length ? CFG.bossLevels[nextBossIdx()] - 3 : zl;
    return Math.max(zl, prog);
  }
  // Сложность главы набирает силу постепенно: на старте (ур. 4) мобы как в главе 1,
  // к локациям 16-го уровня – полный множитель главы. Глава всегда начинается с 1 уровня.
  function chDiff(E) {
    const k = CFG.rush ? 1 : clamp((E - 4) / 12, 0, 1);
    return { hp: 1 + (CFG.diff.hp - 1) * k, dmg: 1 + (CFG.diff.dmg - 1) * k, k };
  }
  function mobScale(E) {
    const key = Math.round(E);
    const cached = G.scaleCache[key];
    if (cached) return cached;
    const Rm = estMobDPS(P) / refMobDPS(E), Q = estEHP(P) / refEHP(E), cd = chDiff(E);
    const sc = {
      hp: BAL.mobHpK * BAL.metaK * refMobDPS(E) / refMobDPS(4) * cd.hp * G.diff.hp * scaleUp(Rm, BAL.mobHpExp, 0.6),
      dmg: BAL.mobDmgK * BAL.metaK * refEHP(E) / refEHP(4) * cd.dmg * G.diff.dmg * scaleUp(Q, BAL.mobDmgExp, 0.7),
      xp: xpFor(E) / BAL.xpDiv * xpGap(P.level, E),
    };
    G.scaleCache[key] = sc;
    return sc;
  }
  function bossStats(b) {
    const E = CFG.bossLevels[b.id] !== undefined ? CFG.bossLevels[b.id] : CFG.bossLevels[CFG.bossLevels.length - 1] + 2;
    const Rb = estDPS(P) / refDPS(E), Q = estEHP(P) / refEHP(E);
    b.E = E;
    const cd = chDiff(E);
    b.maxHp = b.hp = b.def.ttk * refDPS(E) * BAL.eff * BAL.metaK * cd.hp * G.diff.hp * scaleUp(Rb, BAL.bossHpExp, 0.6);
    const dm = refEHP(E) * BAL.bossDmgK * BAL.metaK * cd.dmg * G.diff.dmg * scaleUp(Q, BAL.bossDmgExp, 0.7);
    b.dmg = b.def.hit * dm; b.cdmg = b.def.touch * dm;
    b.level = E + Math.max(0, Math.round((P.level - E) * 0.7));
    b.aggro = 1 + clamp((P.level - E) * 0.02, 0, 0.3);
  }
  function rollHit(base) {
    const crit = Math.random() < P.crit;
    const combo = P.up.c2combo ? 1 + 0.01 * P.up.c2combo * Math.min(G.combo, 100) / 10 : 1;
    return { v: base * (crit ? P.critMul : 1) * rnd(0.9, 1.1) * (P.napT > 0 ? 1.2 : 1) * combo * (G.cookieT > 0 ? 1.25 : 1), crit };
  }

  // ------------------------------------------------------------------
  //  Физика
  // ------------------------------------------------------------------
  function collide(e) {
    const r = e.r;
    const tx0 = Math.floor((e.x - r) / T), tx1 = Math.floor((e.x + r) / T);
    const ty0 = Math.floor((e.y - r) / T), ty1 = Math.floor((e.y + r) / T);
    for (let ty = ty0; ty <= ty1; ty++) for (let tx = tx0; tx <= tx1; tx++) {
      if (!isSolidTile(tx, ty, e.fly)) continue;
      const rx = tx * T, ry = ty * T;
      const nx = clamp(e.x, rx, rx + T), ny = clamp(e.y, ry, ry + T);
      const dx = e.x - nx, dy = e.y - ny, d2 = dx * dx + dy * dy;
      if (d2 >= r * r) continue;
      if (d2 > 1e-6) { const d = Math.sqrt(d2), push = r - d; e.x += (dx / d) * push; e.y += (dy / d) * push; }
      else {
        const l = e.x - rx, rr = rx + T - e.x, u = e.y - ry, dd = ry + T - e.y, m = Math.min(l, rr, u, dd);
        if (m === l) e.x = rx - r; else if (m === rr) e.x = rx + T + r; else if (m === u) e.y = ry - r; else e.y = ry + T + r;
      }
    }
    if (e.fly) return;
    const cx = Math.floor(e.x / T), cy = Math.floor(e.y / T);
    for (let ty = cy - 1; ty <= cy + 1; ty++) for (let tx = cx - 1; tx <= cx + 1; tx++) {
      if (!inMap(tx, ty)) continue;
      const ti = treeGrid[ty * MW + tx];
      if (!ti) continue;
      const tr = trees[ti - 1];
      const dx = e.x - tr.x, dy = e.y - (tr.y - 3), rr = r + 4;
      const d2 = dx * dx + dy * dy;
      if (d2 < rr * rr && d2 > 1e-6) { const d = Math.sqrt(d2); e.x += (dx / d) * (rr - d); e.y += (dy / d) * (rr - d); }
    }
  }
  function moveEntity(e, dx, dy) {
    const steps = Math.max(1, Math.ceil(Math.max(Math.abs(dx), Math.abs(dy)) / (e.r * 0.7)));
    for (let s = 0; s < steps; s++) { e.x += dx / steps; e.y += dy / steps; collide(e); }
  }
  function playerInCastle() {
    const tx = Math.floor(P.x / T), ty = Math.floor(P.y / T);
    return Math.abs(tx - CASTLE.x) < CASTLE.half && Math.abs(ty - CASTLE.y) < CASTLE.half;
  }
  function walkable(x, y, fly) {
    const tx = Math.floor(x / T), ty = Math.floor(y / T);
    if (isSolidTile(tx, ty, fly)) return false;
    if (!gateOpen && tileAt(tx, ty) === FLOOR && biomeMap[ty * MW + tx] !== ARENA_BIOME && !playerInCastle()) return false;
    return true;
  }
  function leadAngle(x, y, spd, k = 0.85) {
    const d = Math.hypot(P.x - x, P.y - y);
    const tt = (d / spd) * k;
    return Math.atan2(P.y + P.vy * tt - y, P.x + P.vx * tt - x);
  }

  // ------------------------------------------------------------------
  //  Эффекты
  // ------------------------------------------------------------------
  function part(x, y, vx, vy, life, size, col, grav = 0) {
    if (G.parts.length > 500) return;
    G.parts.push({ x, y, vx, vy, life, max: life, size, col, grav });
  }
  function burst(x, y, n, col, spd) {
    for (let i = 0; i < n; i++) { const a = rnd(0, TAU), s = rnd(0.2, 1) * spd; part(x, y, Math.cos(a) * s, Math.sin(a) * s, rnd(0.3, 0.8), rnd(2, 5), col); }
  }
  function floatText(x, y, txt, col = '#fff', big = false) {
    if (G.texts.length > 45) G.texts.shift();
    G.texts.push({ x, y, txt, t: 0, col, big });
  }
  function dmgText(x, y, v, col = '#fff', crit = false) {
    floatText(x, y, String(Math.max(1, Math.round(v))) + (crit ? '!' : ''), crit ? '#ffe04a' : col, crit);
  }
  function shockRing(x, y, col, max = 220) { G.rings.push({ x, y, r: 10, max, col, t: 0 }); }
  function dropGem(x, y, v) {
    if (G.pickups.length > 280) { const g = G.pickups.find(p => p.kind === 'xp'); if (g) { g.v += v; return; } }
    G.pickups.push({ kind: 'xp', x, y, v, t: 0, pull: false });
  }
  function dropPickup(x, y, kind, extra) { G.pickups.push(Object.assign({ kind, x, y, v: 0, t: 0, pull: false }, extra || {})); }
  const SHARD_W = SHARDS.map((s, i) => [i, s.w]);
  function dropShard(x, y) { dropPickup(x + rnd(-12, 12), y + rnd(-12, 12), 'shard', { sid: weighted(SHARD_W) }); }

  // ------------------------------------------------------------------
  //  Враги
  // ------------------------------------------------------------------
  const SLIME_COL = { 0: '#63d65a', 1: '#8fae3a', 2: '#8fd8ff', 3: '#b05bd6', 4: '#7dff9a', 7: '#a98bff' };
  const BAT_COL = { 0: '#6b4a8f', 1: '#4a6b3a', 2: '#5a7fa8', 3: '#3a2050', 4: '#8a5aa8', 7: '#4a3a8f' };
  function spawnEnemy(type, x, y, biome, opts = {}) {
    const d = ENEMIES[type];
    const E = opts.E || zoneE(biome);
    const sc = mobScale(E);
    const elite = !!opts.elite;
    const affix = elite ? pick(AFFIXES).id : null;
    let col = d.col;
    if (type === 'slime' && SLIME_COL[biome]) col = SLIME_COL[biome];
    if (type === 'bat' && BAT_COL[biome]) col = BAT_COL[biome];
    const calm = opts.minion ? 0 : calmOf(biome);
    const hp = d.hp * sc.hp * (elite ? 3 : 1) * (1 - calm);
    const e = {
      type, def: d, sprite: d.sprite || type, x, y, r: d.r * (elite ? 1.35 : 1),
      hp, maxHp: hp, dmg: d.dmg * sc.dmg * (elite ? 1.4 : 1) * (affix === 'frenzied' ? 1.2 : 1) * (1 - calm),
      spd: d.spd * rnd(0.9, 1.1) * (elite ? 1.08 : 1) * (affix === 'fast' ? 1.45 : 1), xp: d.xp * sc.xp * (elite ? 5 : 1), fly: !!d.fly,
      t: 0, seed: Math.random() * 10, flash: 0, kx: 0, ky: 0, orbCd: 0, cd: rnd(0.8, 2.2), jt: rnd(0.3, 1.5), jd: 0, jx: 0, jy: 0,
      wind: 0, fuse: 0, charge: 0, burst: 0, burstT: 0, blink: 0, bx: 0, by: 0, healing: 0, healTargets: [],
      face: 1, look: 0, dead: false, flank: rnd(-1, 1) * (d.pack ? 1.3 : d.ai === 'swarm' ? 1.2 : 0.8),
      steerT: 0, steerDir: 1, stuckT: 0, dodgeCd: rnd(0, 1), slowT: 0, spawnT: opts.instant ? 0 : 0.45, elite,
      col, shieldAng: 0, biome, minion: !!opts.minion, small: type === 'mummini', vx: 0, vy: 0, dashAng: 0,
      shrine: opts.shrine || null, haz: null, exploded: false, E, affix, dr: affix === 'armored' ? 0.5 : 0,
      cdMul: affix === 'frenzied' ? 0.6 : 1, buffT: 0, burnT: 0, burnDps: 0, burnTick: 0, owner: opts.owner || null, sumT: rnd(1, 3),
      bossPart: opts.bossPart || null,
    };
    G.enemies.push(e);
    return e;
  }
  function seek(e, ux, uy, d, mul = 1) {
    const f = e.flank * mul * clamp((d - 90) / 220, 0, 1);
    const c = Math.cos(f), s = Math.sin(f);
    return [ux * c - uy * s, ux * s + uy * c];
  }
  function fireShot(e) {
    const s = e.def.shot;
    const dmg = s.dmg * (e.dmg / e.def.dmg);
    if (s.kind === 'bolt') {
      const tt = 0.6;
      hazardCircle(P.x + P.vx * tt, P.y + P.vy * tt, 44, 0.7, dmg, 'bolt');
    } else if (s.ring) {
      const off = s.spin ? e.t * 2 : e.t;
      for (let k = 0; k < s.n; k++) ebullet(e.x, e.y, k / s.n * TAU + off, s.spd, dmg, s.col || '#ff3ea5', 8, { emoji: s.emoji, square: s.square });
    } else {
      const a = leadAngle(e.x, e.y, s.spd);
      for (let k = 0; k < s.n; k++) ebullet(e.x, e.y, a + (k - (s.n - 1) / 2) * (s.spread || 0), s.spd, dmg, s.col || '#ffffff', s.emoji ? 9 : 6, { emoji: s.emoji, emojiSet: s.emojiSet, square: s.square });
    }
    Sound.sfx.enemyShot();
  }
  function tryDodge(e) {
    for (const f of G.feathers) {
      const rx = e.x - f.x, ry = e.y - f.y;
      if (rx * rx + ry * ry > 95 * 95) continue;
      const sp = Math.hypot(f.vx, f.vy) || 1, vx = f.vx / sp, vy = f.vy / sp;
      const along = rx * vx + ry * vy, cross = rx * vy - ry * vx;
      if (along > 0 && Math.abs(cross) < e.r + 10) {
        const s = cross >= 0 ? 1 : -1;
        e.kx += -vy * s * 330; e.ky += vx * s * 330;
        e.dodgeCd = e.elite ? 0.9 : 1.6;
        part(e.x, e.y, 0, 0, 0.3, 4, 'rgba(255,255,255,0.7)');
        return;
      }
    }
  }
  function updateEnemy(e, dt) {
    e.t += dt;
    if (e.flash > 0) e.flash -= dt;
    if (e.orbCd > 0) e.orbCd -= dt;
    if (e.slowT > 0) e.slowT -= dt;
    if (e.dodgeCd > 0) e.dodgeCd -= dt;
    if (e.healing > 0) e.healing -= dt;
    if (e.buffT > 0) e.buffT -= dt;
    if (e.spawnT > 0) { e.spawnT -= dt; return; }
    if (e.burnT > 0) {
      e.burnT -= dt; e.burnTick -= dt;
      if (e.burnTick <= 0) {
        e.burnTick = 0.4; e.hp -= e.burnDps * 0.4 * (1 - e.dr);
        if (Math.random() < 0.5) part(e.x + rnd(-6, 6), e.y - 6, rnd(-20, 20), rnd(-60, -30), 0.4, 3, '#ff8a2a');
        if (e.hp <= 0) { killEnemy(e); return; }
      }
    }
    if (e.affix === 'vampiric' && e.hp < e.maxHp) e.hp = Math.min(e.maxHp, e.hp + e.maxHp * 0.02 * dt);
    const def = e.def;
    const dx = P.x - e.x, dy = P.y - e.y, d = Math.hypot(dx, dy) || 1;
    const ux = dx / d, uy = dy / d;
    e.look = Math.atan2(dy, dx);
    let mx = 0, my = 0, spd = e.spd * (e.slowT > 0 ? 0.55 : 1);
    const evId = G.ev ? G.ev.def.id : null;
    if (evId === 'song' && !e.minion) { e.kx *= 0.9; e.ky *= 0.9; return; } // концерт: замерли и танцуют
    if (G.hidden && !e.minion) { const a = e.seed * 3 + e.t * 0.6; moveEntity(e, Math.cos(a) * spd * 0.3 * dt, Math.sin(a) * spd * 0.3 * dt); return; } // Тесса в коробке
    if (e.lit > 0) { e.lit -= dt; spd *= 0.6; } // тёплый свет лампы глитчам не нравится
    if (evId === 'rage') spd *= 1.4; else if (evId === 'fog') spd *= 0.8;
    switch (def.ai) {
      case 'chase': [mx, my] = seek(e, ux, uy, d); if (def.pack && d < 170) spd *= 1.35; break;
      case 'hop': [mx, my] = seek(e, ux, uy, d); spd *= 1.8 * Math.max(0, Math.sin(e.t * 6 + e.seed)); break;
      case 'bat': { const w = Math.sin(e.t * 5 + e.seed) * 0.9; const [sx, sy] = seek(e, ux, uy, d); mx = sx - sy * w; my = sy + sx * w; break; }
      case 'swarm': if (d < 130) { mx = ux; my = uy; spd *= 1.15; } else [mx, my] = seek(e, ux, uy, d, 1.6); break;
      case 'jump':
        e.jt -= dt;
        if (e.wind > 0) { e.wind -= dt; if (e.wind <= 0) { e.jd = 0.35; const a = leadAngle(e.x, e.y, 300, 0.5); e.jx = Math.cos(a); e.jy = Math.sin(a); } }
        else if (e.jd > 0) { e.jd -= dt; mx = e.jx; my = e.jy; spd = 300; }
        else if (e.jt <= 0 && d < 500) { e.jt = rnd(1.2, 1.8); e.wind = 0.35; }
        break;
      case 'ranged': case 'turret': {
        if (def.ai === 'ranged') {
          if (d > 230) { [mx, my] = seek(e, ux, uy, d); } else if (d < 105) { mx = -ux; my = -uy; }
          else { const s = Math.sin(e.seed) > 0 ? 1 : -1; mx = -uy * s; my = ux * s; spd *= 0.6; }
        }
        e.cd -= dt;
        if (e.burst > 0) { e.burstT -= dt; if (e.burstT <= 0) { fireShot(e); e.burst--; e.burstT = 0.16; } }
        else if (e.charge > 0) { e.charge -= dt; spd *= 0.3; if (e.charge <= 0) { fireShot(e); if (def.shot.burst) { e.burst = def.shot.burst - 1; e.burstT = 0.16; } } }
        else if (e.cd <= 0 && d < 430) {
          if (G.shooters < 2 + CHN) { e.charge = 0.38; e.cd = def.shot.cd * rnd(0.85, 1.15) * e.cdMul; G.shooters++; }
          else e.cd = 0.3;
        }
        break;
      }
      case 'summoner': {
        e.cd -= dt; e.sumT -= dt;
        if (e.charge > 0) { e.charge -= dt; if (e.charge <= 0) fireShot(e); }
        else if (e.cd <= 0 && d < 430 && G.shooters < 2 + CHN) { e.charge = 0.4; e.cd = def.shot.cd * e.cdMul; G.shooters++; }
        if (e.sumT <= 0) {
          e.sumT = 5;
          const mine = G.enemies.filter(o => o.owner === e && !o.dead).length;
          for (let k = 0; k < 2 && mine + k < 6; k++) { const s = spawnEnemy(def.summons, e.x + rnd(-24, 24), e.y + rnd(-24, 24), e.biome, { owner: e, E: e.E }); s.xp *= 0.3; }
        }
        break;
      }
      case 'buffer': {
        if (d < 260) { mx = -ux; my = -uy; }
        let cxs = 0, cys = 0, n = 0;
        for (const o of G.enemies) { if (o === e || o.dead) continue; const dd = (o.x - e.x) ** 2 + (o.y - e.y) ** 2; if (dd < 400 * 400) { cxs += o.x; cys += o.y; n++; } }
        if (n) { const tx = cxs / n - e.x, ty = cys / n - e.y, tl = Math.hypot(tx, ty) || 1; if (tl > 90) { mx += tx / tl * 0.7; my += ty / tl * 0.7; } }
        e.cd -= dt;
        if (e.cd <= 0) {
          e.cd = 3.5; e.healTargets = [];
          for (const o of G.enemies) {
            if (o === e || o.dead) continue;
            if ((o.x - e.x) ** 2 + (o.y - e.y) ** 2 < 200 * 200) { o.buffT = 3; e.healTargets.push(o); }
          }
          if (e.healTargets.length) e.healing = 0.5;
        }
        break;
      }
      case 'healer': {
        if (d < 260) { mx = -ux; my = -uy; }
        let cxs = 0, cys = 0, n = 0;
        for (const o of G.enemies) { if (o === e || o.dead || o.def.ai === 'healer') continue; const dd = (o.x - e.x) ** 2 + (o.y - e.y) ** 2; if (dd < 400 * 400) { cxs += o.x; cys += o.y; n++; } }
        if (n) { const tx = cxs / n - e.x, ty = cys / n - e.y, tl = Math.hypot(tx, ty) || 1; if (tl > 90) { mx += tx / tl * 0.7; my += ty / tl * 0.7; } }
        e.cd -= dt;
        if (e.cd <= 0) {
          e.cd = 3.2; e.healTargets = [];
          for (const o of G.enemies) {
            if (o === e || o.dead || o.hp >= o.maxHp) continue;
            if ((o.x - e.x) ** 2 + (o.y - e.y) ** 2 < 190 * 190) { o.hp = Math.min(o.maxHp, o.hp + o.maxHp * 0.3); e.healTargets.push(o); floatText(o.x, o.y - o.r - 8, '+', '#7dff9a'); }
          }
          if (e.healTargets.length) e.healing = 0.5;
        }
        break;
      }
      case 'shield':
        e.shieldAng += clamp(angDiff(e.shieldAng, e.look), -2.1 * dt, 2.1 * dt);
        [mx, my] = seek(e, ux, uy, d, 0.5);
        break;
      case 'exploder':
        if (e.fuse > 0) { e.fuse -= dt; if (e.fuse <= 0) { e.exploded = true; killEnemy(e); } }
        else { [mx, my] = seek(e, ux, uy, d); if (d < 72) { e.fuse = 0.65; e.haz = hazardCircle(e.x, e.y, 88, 0.65, e.dmg, 'boom'); Sound.sfx.fuse(); } }
        break;
      case 'charger':
        if (e.wind > 0) { e.wind -= dt; if (e.wind <= 0) e.jd = 0.42; }
        else if (e.jd > 0) { e.jd -= dt; mx = Math.cos(e.dashAng); my = Math.sin(e.dashAng); spd = 490; if (e.jd <= 0) e.cd = rnd(1.2, 2); }
        else {
          e.cd -= dt;
          [mx, my] = seek(e, ux, uy, d);
          if (d < 290 && e.cd <= 0) { e.wind = 0.55; e.dashAng = leadAngle(e.x, e.y, 490, 0.5); mx = 0; my = 0; }
        }
        break;
      case 'bouncer': {
        if (!e.vx && !e.vy) { const a = e.look + rnd(-0.6, 0.6); e.vx = Math.cos(a); e.vy = Math.sin(a); }
        const cur = Math.atan2(e.vy, e.vx), na = cur + clamp(angDiff(cur, e.look), -1.3 * dt, 1.3 * dt);
        e.vx = Math.cos(na); e.vy = Math.sin(na);
        const ox = e.x, oy = e.y, stx = e.vx * spd * dt, sty = e.vy * spd * dt;
        moveEntity(e, stx, sty);
        if (Math.abs(e.x - ox) < Math.abs(stx) * 0.5) e.vx = -e.vx;
        if (Math.abs(e.y - oy) < Math.abs(sty) * 0.5) e.vy = -e.vy;
        spd = 0;
        break;
      }
      case 'blinker':
        if (e.blink > 0) {
          e.blink -= dt; spd = 0;
          if (e.blink <= 0) { e.x = e.bx; e.y = e.by; burst(e.x, e.y, 14, '#ff5bf0', 160); e.kx = ux * 220; e.ky = uy * 220; }
        } else {
          [mx, my] = seek(e, ux, uy, d);
          e.cd -= dt;
          if (e.cd <= 0 && d > 150 && d < 480) {
            const base = Math.hypot(P.vx, P.vy) > 20 ? Math.atan2(P.vy, P.vx) : rnd(0, TAU);
            for (let k = 0; k < 6; k++) {
              const a = base + rnd(-0.9, 0.9), x = P.x + Math.cos(a) * 95, y = P.y + Math.sin(a) * 95;
              if (walkable(x, y, e.fly)) { e.bx = x; e.by = y; e.blink = 0.55; hazardCircle(x, y, 26, 0.55, 0, 'dark'); break; }
            }
            e.cd = rnd(3, 4.5);
          }
        }
        break;
    }
    if (def.dodge && e.dodgeCd <= 0) tryDodge(e);
    // обход препятствий
    if (e.steerT > 0) {
      e.steerT -= dt;
      const a = e.steerDir * 1.25, c = Math.cos(a), s = Math.sin(a);
      const nx = mx * c - my * s, ny = mx * s + my * c; mx = nx; my = ny;
    }
    if (Math.abs(mx) > 0.1) e.face = mx > 0 ? 1 : -1;
    const ex = e.x, ey = e.y;
    const want = Math.hypot(mx, my) * spd * dt;
    moveEntity(e, (mx * spd + e.kx) * dt, (my * spd + e.ky) * dt);
    if (!e.fly && want > 0.6) {
      const moved = Math.hypot(e.x - ex, e.y - ey);
      if (moved < want * 0.3) { e.stuckT += dt; if (e.stuckT > 0.2) { e.steerT = 0.7; e.steerDir = Math.random() < 0.5 ? -1 : 1; e.stuckT = 0; } }
      else e.stuckT = 0;
    }
    const kd = Math.pow(0.002, dt); e.kx *= kd; e.ky *= kd;
    if (d < e.r + P.r - 2 && e.blink <= 0 && e.fuse <= 0) {
      const wasInv = P.inv > 0 || P.dashT > 0;
      hurtPlayer(e.jd > 0 && def.ai === 'charger' ? e.dmg * 1.5 : e.dmg, e.x, e.y);
      if (!wasInv && e.affix === 'vampiric') e.hp = Math.min(e.maxHp, e.hp + e.dmg * 2);
    }
    if (d > 1600 && !e.shrine && !e.champion && !e.mimicOf) e.dead = true;
  }
  function updateEnemies(dt) {
    const list = G.enemies;
    G.shooters = 0;
    for (const e of list) if (!e.dead && (e.charge > 0 || e.burst > 0)) G.shooters++;
    for (const e of list) if (!e.dead) updateEnemy(e, dt);
    for (let i = 0; i < list.length; i++) {
      const a = list[i]; if (a.dead || a.spawnT > 0) continue;
      for (let j = i + 1; j < list.length; j++) {
        const b = list[j]; if (b.dead || b.spawnT > 0) continue;
        const dx = b.x - a.x, dy = b.y - a.y, rr = a.r + b.r;
        const d2 = dx * dx + dy * dy;
        if (d2 < rr * rr && d2 > 0.01) {
          const d = Math.sqrt(d2), push = (rr - d) * 0.5, nx = dx / d, ny = dy / d;
          if (a.def.ai !== 'turret') { a.x -= nx * push; a.y -= ny * push; }
          if (b.def.ai !== 'turret') { b.x += nx * push; b.y += ny * push; }
        }
      }
    }
    G.enemies = list.filter(e => !e.dead);
  }
  function killEnemy(e, silent) {
    if (e.dead) return;
    e.dead = true;
    if (e.haz && !e.exploded) e.haz.cancel = true;
    burst(e.x, e.y, e.elite ? 30 : 12, e.type === 'snowman' ? '#ffffff' : e.col.startsWith('#') ? e.col : '#c77dff', 170);
    if (e.exploded) { burst(e.x, e.y, 30, '#ff8a2a', 260); Sound.sfx.boom(); G.shake = Math.max(G.shake, 8); }
    if (e.shrine) e.shrine.left--;
    if (e.bossPart) bossPartDestroyed(e.bossPart);
    if (e.affix === 'volatile' && !silent) hazardCircle(e.x, e.y, 95, 0.55, e.dmg * 1.3, 'boom');
    if (e.def.puddle && !silent) G.hazards.push({ kind: 'zone', x: e.x, y: e.y, r: 52, t: 0, delay: 0.2, dur: 4, dot: e.dmg * 0.3, fx: 'toxic' });
    if (silent || e.def.noDrop) return;
    G.kills++;
    addSuper(e.elite ? 8 : 2.2);
    if (G.st) { G.st.kills++; if (e.elite) G.st.elites++; G.st.byType[e.type] = (G.st.byType[e.type] || 0) + 1; }
    Sound.sfx.die();
    dropGem(e.x, e.y, e.xp * (1 + Math.min(G.combo, 100) / 100));
    G.combo++; G.comboT = 2.6; G.bestCombo = Math.max(G.bestCombo, G.combo);
    if (P.vamp && P.hp < P.maxHp) P.hp = Math.min(P.maxHp, P.hp + P.vamp);
    const luck = 1 + 0.15 * talent('luck');
    const nShards = e.elite ? 3 : (Math.random() < SHARD_CHANCE * luck * (G.ev && G.ev.def.id === 'gold' ? 2 : 1) ? 1 : 0);
    for (let i = 0; i < nShards; i++) dropShard(e.x, e.y);
    if (e.elite && !e.champion && Math.random() < 0.06) dropPickup(e.x - 12, e.y, 'key');
    if (e.mimicOf) mimicKilled(e);
    if (e.gladeBeast || e.pikeLoot) {
      dropPickup(e.x + 14, e.y, 'heart'); for (let k = 0; k < (e.gladeBeast ? 6 : 3); k++) dropShard(e.x, e.y);
      if (e.gladeBeast) { dropPickup(e.x - 14, e.y, 'key'); floatText(e.x, e.y - 40, '🐆 Барс повержен!', '#ffd25a', true); }
    }
    if (hasRelic('fang') && P.hp < P.maxHp) P.hp = Math.min(P.maxHp, P.hp + P.maxHp * 0.01);
    const r = Math.random();
    // чем меньше здоровья, тем чаще падают сердечки
    if (e.elite || r < (0.03 + 0.05 * clamp(1 - P.hp / P.maxHp, 0, 1) + 0.04 * lv('c1petal')) * luck) dropPickup(e.x + 10, e.y, 'heart');
    else if (r > 0.993) dropPickup(e.x + 10, e.y, 'magnet');
    calmKill(e.biome);
    if (e.champion) {
      G.champ = null; if (G.st) G.st.champs = (G.st.champs || 0) + 1;
      { const pr = loadProfile(); pr.champsTotal = (pr.champsTotal || 0) + 1; saveProfile(pr); if (pr.champsTotal >= 10) unlockOutfit('crown'); }
      showBanner('👑 Чемпион повержен!', 'Награда: улучшение, осколки и сердечко');
      Sound.sfx.chest(); burst(e.x, e.y, 40, '#ffd25a', 260);
      for (let i = 0; i < 6; i++) dropShard(e.x + rnd(-30, 30), e.y + rnd(-30, 30));
      dropPickup(e.x, e.y + 20, 'heart'); dropPickup(e.x - 24, e.y + 20, 'key');
      G.pendingLv++; openLevelUp();
    }
    if (e.def.split) for (let k = 0; k < 2; k++) {
      const s = spawnEnemy(e.def.split, e.x + rnd(-10, 10), e.y + rnd(-10, 10), e.biome, { instant: true, E: e.E });
      s.kx = rnd(-200, 200); s.ky = rnd(-200, 200); s.shrine = e.shrine;
      if (e.shrine) e.shrine.left++;
    }
  }
  function damageEnemy(e, hit, kx, ky, fromFeather) {
    if (e.dead || e.spawnT > 0) return false;
    const v = hit.v * (1 - e.dr) * (e.buffT > 0 ? 0.6 : 1);
    e.hp -= v; e.flash = 0.1;
    if (G.st) G.st.dmgDealt += Math.min(v, e.hp + v);
    if (e.def.ai !== 'turret') { e.kx += kx; e.ky += ky; }
    if (P.frost && fromFeather) e.slowT = 1.2 + 0.4 * P.frost;
    dmgText(e.x + rnd(-6, 6), e.y - e.r - 6, v, e.dr || e.buffT > 0 ? '#b8c4d8' : '#fff', hit.crit);
    Sound.sfx.hit();
    if (e.hp <= 0) killEnemy(e);
    return true;
  }

  // ------------------------------------------------------------------
  //  Боссы
  // ------------------------------------------------------------------
  function makeBosses() {
    bosses = CFG.bosses.map((kind, i) => {
      const d = BOSSES[kind];
      const hx = tc(CFG.bossTiles[i].x), hy = tc(CFG.bossTiles[i].y);
      return {
        id: i, kind, def: d, name: d.name, sub: d.sub, r: d.r, maxHp: 1, hp: 1, spd: d.spd, dmg: 0, cdmg: 0,
        E: CFG.bossLevels[i], level: CFG.bossLevels[i], aggro: 1, shield: false, stunT: 0, burnT: 0, burnDps: 0, burnTick: 0,
        fly: !!d.fly, move: d.move, hx, hy, x: hx, y: hy, state: G.defeated[i] ? 'dead' : 'sleep', mode: 'idle', t: 0,
        flash: 0, z: 0, last: null, stage: 0, sub: 0, cnt: 0, anim: Math.random() * 5, alpha: 1, ang: 0, tx: 0, ty: 0,
        sx: 0, sy: 0, dist: 0, charging: false, dur: 0, inv: false, final: i === CFG.bosses.length - 1, look: 0, p: null,
        speedMul: 1, tauntT: 9, orbCd: 0, bubble: null,
        calmBiome: i < CFG.bosses.length - 1 ? biomeMap[CFG.bossTiles[i].y * MW + CFG.bossTiles[i].x] : -1,
      };
    });
  }
  const guardiansCount = () => bosses.length - 1;
  const guardiansDone = () => G.defeated.slice(0, guardiansCount()).filter(Boolean).length;
  function startBossFight(b) {
    bossStats(b);
    if (G.st && !G.st.cur) G.st.cur = { k: b.kind, n: b.name, pl: P.level, bl: b.level, t0: G.st.time, d: 0, h: 0, df: G.diffId };
    b.state = 'fight'; b.mode = 'idle'; b.t = 1.5; b.stage = 0; b.speedMul = b.aggro; G.activeBoss = b;
    // обычные мобы разбегаются – на арене только босс и его свита
    for (const e of G.enemies) if (!e.minion && !e.shrine && !e.bossPart && Math.hypot(e.x - b.x, e.y - b.y) < 800) { e.dead = true; burst(e.x, e.y, 6, '#c9b3ff', 90); }
    G.bossHeartT = (HEART_EVERY[G.diffId] || 12) * 0.8;
    b.shield = false; b.stunT = 0; b.burnT = 0;
    showBanner(b.name, `${b.sub} · ур. ${b.level}`);
    Sound.sfx.roar(); Sound.music(b.def.music ? b.def.music : b.def.immortal ? 'ultimate' : b.def.final ? (CHN === 3 ? 'final2' : 'final') : 'boss');
    if (G.ev) endEvent();
    speak(b.kind, b.def.lines.intro);
    G.shake = 10;
  }
  function resetBoss(b) {
    b.state = 'sleep'; b.hp = b.maxHp; b.x = b.hx; b.y = b.hy; b.z = 0; b.alpha = 1; b.stage = 0; b.speedMul = 1;
    b.mode = 'idle'; b.charging = false; b.inv = false; b.shield = false; b.stunT = 0; b.burnT = 0;
    if (G.activeBoss === b) { G.activeBoss = null; biomeMusic(true); }
    G.hazards.length = 0; G.ebullets.length = 0; G.beams.length = 0;
    for (const e of G.enemies) if (e.minion) e.dead = true;
  }
  function startStage(b, i) {
    b.stage = i; b.mode = 'trans'; b.t = 2.3; b.inv = true; b.charging = false; b.z = 0; b.alpha = 1;
    if (i > 0) dropHeartNear(100, 200);
    b.speedMul = (b.def.stages[i].spd || 1) * b.aggro; b.stunT = 0;
    G.ebullets.length = 0; G.hazards.length = 0; G.beams.length = 0;
    shockRing(b.x, b.y, '#ffffff', 320);
    const d = Math.hypot(P.x - b.x, P.y - b.y);
    if (d < 230) { const a = Math.atan2(P.y - b.y, P.x - b.x); moveEntity(P, Math.cos(a) * (230 - d), Math.sin(a) * (230 - d)); }
    showBanner(`СТАДИЯ ${i + 1}`, b.name);
    speak(b.kind, b.def.lines.stages[i]);
    if (b.final && i >= 2 && CFG.team) freeTessa();
    Sound.sfx.stage(); G.shake = 16;
  }
  function endAttack(b, rest) { b.mode = 'idle'; b.t = rest / b.speedMul; b.sub = 0; b.cnt = 0; b.charging = false; b.z = 0; b.alpha = 1; }
  function nextAttack(b) {
    const list = b.def.stages[b.stage].attacks;
    let a, guard = 0;
    do { a = pick(list); } while ((a[0] === b.last || (a[0] === 'mirrors' && b.shield)) && guard++ < 12 && list.length > 1);
    if (a[0] === 'mirrors' && b.shield) a = ['ring', { n: 16, waves: 2 }];
    b.last = a[0]; b.mode = a[0]; b.p = a[1] || {}; b.sub = 0; b.t = 0; b.cnt = 0;
  }
  function bossMove(b, dt) {
    const spd = b.spd * b.speedMul;
    const dx = P.x - b.x, dy = P.y - b.y, d = Math.hypot(dx, dy) || 1;
    let mx, my;
    if (b.move === 'hover') {
      const want = 150;
      mx = (-dy / d) + (dx / d) * (d - want) / 100; my = (dx / d) + (dy / d) * (d - want) / 100;
    } else { mx = dx / d; my = dy / d; if (d < b.r + P.r + 6) { mx = 0; my = 0; } }
    const hd = Math.hypot(b.x - b.hx, b.y - b.hy);
    if (hd > 340) { mx = (b.hx - b.x) / hd; my = (b.hy - b.y) / hd; }
    const m = Math.hypot(mx, my);
    if (m > 0.01) moveEntity(b, (mx / m) * spd * dt, (my / m) * spd * dt);
  }
  function ebullet(x, y, a, spd, dmg, col, r = 7, o = {}) {
    if (G.ebullets.length > 260 || (G.ebullets.length > 170 && Math.random() < 0.4)) return;
    G.ebullets.push({ x, y, vx: Math.cos(a) * spd, vy: Math.sin(a) * spd, spd, dmg, col, r, homing: o.homing || 0,
      life: o.life || 6, emoji: o.emoji ? pick(o.emojiSet || (G.activeBoss && G.activeBoss.def.emojiSet) || ZYAMA_EMOJI) : (o.heart ? '❤️' : null), slow: !!o.slow,
      square: !!o.square, saw: !!o.saw, bounce: !!o.bounce, missile: !!o.missile, hx: o.hx, hy: o.hy, rot: 0 });
  }
  function bdmg(b, k = 1) { return b.dmg * k * (1 + 0.1 * b.stage); }
  function bossRing(b, n, spd, dmg, col, off = 0, o = {}) {
    for (let i = 0; i < n; i++) ebullet(b.x, b.y - b.z, off + (i / n) * TAU, spd, dmg, col, 7, o);
    Sound.sfx.enemyShot();
  }
  function hazardCircle(x, y, r, delay, dmg, fx) { const h = { kind: 'circle', x, y, r, t: 0, delay, dmg, fx, done: false }; G.hazards.push(h); return h; }
  function hazardLine(x, y, ang, len, w, delay, dmg, fx) { const h = { kind: 'line', x, y, ang, len, w, t: 0, delay, dmg, fx, done: false }; G.hazards.push(h); return h; }
  function minionCount(type) { let n = 0; for (const e of G.enemies) if (e.type === type && e.minion && !e.dead) n++; return n; }
  function summon(b, type, n, max = 6) {
    n = Math.max(1, Math.round(n * 0.85)); max = Math.max(2, Math.round(max * 0.8));
    const biome = biomeMap[Math.floor(b.hy / T) * MW + Math.floor(b.hx / T)];
    for (let i = 0; i < n; i++) {
      if (minionCount(type) >= max) break;
      const a = rnd(0, TAU), x = b.x + Math.cos(a) * (b.r + 34), y = b.y + Math.sin(a) * (b.r + 34);
      if (!walkable(x, y, ENEMIES[type].fly)) continue;
      const e = spawnEnemy(type, x, y, biome, { minion: true, E: b.E }); e.xp *= 0.3;
    }
    Sound.sfx.magic();
  }
  const ATK = {
    ring(b, dt, p) {
      if (b.t <= 0) {
        bossRing(b, p.n || 14, (p.spd || 150), bdmg(b), p.col || '#d7ff7a', b.cnt * 0.22, { square: p.square });
        b.cnt++; b.t = (p.gap || 0.45) / b.speedMul; if (b.cnt >= (p.waves || 3)) endAttack(b, 1.2);
      }
    },
    emoji(b, dt, p) {
      if (b.t <= 0) {
        bossRing(b, p.n || 14, 170, bdmg(b), '#ff3ea5', b.cnt * 0.25, { emoji: true });
        b.cnt++; b.t = 0.5 / b.speedMul; if (b.cnt >= (p.waves || 3)) endAttack(b, 1.2);
      }
    },
    spiral(b, dt, p) {
      if (b.sub === 0) { b.sub = 1; b.dur = p.dur || 2.6; b.t = 0; }
      b.dur -= dt;
      if (b.t <= 0) {
        const arms = p.arms || 3;
        for (let k = 0; k < arms; k++) ebullet(b.x, b.y - b.z, b.anim * 1.7 + (k / arms) * TAU, p.spd || 150, bdmg(b), p.rainbow ? RAINBOW[(b.cnt++) % 7] : (p.col || '#c77dff'), 7, { emoji: p.emoji, square: p.square });
        b.t = p.rate || 0.11; Sound.sfx.enemyShot();
      }
      if (b.dur <= 0) endAttack(b, 1.0);
    },
    aimed(b, dt, p) {
      if (b.t <= 0) {
        const spd = p.spd || 270;
        ebullet(b.x, b.y - b.z, leadAngle(b.x, b.y, spd) + rnd(-(p.spread || 0.22), p.spread || 0.22), spd, bdmg(b), p.col || '#ffffff', p.r || 9, { square: p.square, emoji: p.emoji });
        Sound.sfx.enemyShot(); b.cnt++; b.t = (p.rate || 0.16) / b.speedMul; if (b.cnt >= (p.count || 10)) endAttack(b, 1.1);
      }
    },
    shotgun(b, dt, p) {
      if (b.t <= 0) {
        const n = p.n || 5, a = leadAngle(b.x, b.y, 200);
        for (let k = 0; k < n; k++) ebullet(b.x, b.y - b.z, a + (k - (n - 1) / 2) * 0.17, 200, bdmg(b), p.col || '#7dffb0', 8, { emoji: p.emoji, emojiSet: p.emojiSet });
        Sound.sfx.enemyShot(); b.cnt++; b.t = 0.5 / b.speedMul; if (b.cnt >= (p.waves || 3)) endAttack(b, 1.2);
      }
    },
    stomp(b, dt, p) {
      if (b.sub === 0) { hazardCircle(b.x, b.y, (p.r || 140) + b.cnt * 25, 0.9 / Math.sqrt(b.speedMul), bdmg(b, 1.7), 'stomp'); b.sub = 1; b.t = 1.05 / Math.sqrt(b.speedMul); }
      else if (b.t <= 0) { b.cnt++; if (b.cnt < (p.repeat || 1)) b.sub = 0; else endAttack(b, 1.0); }
    },
    leap(b, dt, p) {
      if (b.sub === 0) {
        let tx = P.x + P.vx * 0.4, ty = P.y + P.vy * 0.4; const hd = Math.hypot(tx - b.hx, ty - b.hy);
        if (hd > 330) { tx = b.hx + (tx - b.hx) / hd * 330; ty = b.hy + (ty - b.hy) / hd * 330; }
        b.tx = tx; b.ty = ty; b.sx = b.x; b.sy = b.y; b.dur = 0.95 / Math.sqrt(b.speedMul);
        hazardCircle(tx, ty, p.r || 100, b.dur, bdmg(b, 1.8), 'stomp'); b.sub = 1; b.t = b.dur;
      } else if (b.sub === 1) {
        const k = 1 - clamp(b.t / b.dur, 0, 1);
        b.x = lerp(b.sx, b.tx, k); b.y = lerp(b.sy, b.ty, k); b.z = Math.sin(k * Math.PI) * 130;
        if (b.t <= 0) { b.z = 0; b.x = b.tx; b.y = b.ty; collide(b); bossRing(b, p.ringN || 12, 175, bdmg(b), '#7dffb0'); G.shake = 12; b.sub = 2; b.t = 0.5; }
      } else if (b.t <= 0) { b.cnt++; if (b.cnt < (p.repeat || 1)) b.sub = 0; else endAttack(b, 1.0); }
    },
    lash(b, dt, p) {
      if (b.sub === 0) {
        const base = Math.atan2(P.y - b.y, P.x - b.x), fan = p.fan || 1;
        for (let k = 0; k < fan; k++) hazardLine(b.x, b.y, base + (k - (fan - 1) / 2) * 0.4, 380, 34, 0.7, bdmg(b, 1.5), 'tongue');
        b.sub = 1; b.t = 1.0;
      } else if (b.t <= 0) { b.cnt++; if (b.cnt < (p.repeat || 1)) b.sub = 0; else endAttack(b, 0.9); }
    },
    charge(b, dt, p) {
      const spd = p.spd || 640;
      if (b.sub === 0) { b.ang = leadAngle(b.x, b.y, spd, 0.4); b.trailD = 0; hazardLine(b.x, b.y, b.ang, 560, 76, 0.75, 0, 'charge'); b.sub = 1; b.t = 0.75; }
      else if (b.sub === 1) { if (b.t <= 0) { b.sub = 2; b.dist = 0; b.charging = true; Sound.sfx.roar(); } }
      else if (b.sub === 2) {
        const step = spd * dt, ox = b.x, oy = b.y;
        moveEntity(b, Math.cos(b.ang) * step, Math.sin(b.ang) * step);
        const moved = Math.hypot(b.x - ox, b.y - oy);
        b.dist += step;
        if (p.trail && b.dist - (b.trailD || 0) > 40) { b.trailD = b.dist; G.hazards.push({ kind: 'zone', x: b.x, y: b.y, r: 30, t: 0, delay: 0.15, dur: 2.4, dot: bdmg(b, 0.45), fx: 'rainbow' }); }
        if (Math.random() < 0.6) part(b.x + rnd(-20, 20), b.y + 30, rnd(-40, 40), rnd(-60, -10), 0.5, 4, p.trail ? pick(RAINBOW) : '#ffffff');
        if (moved < step * 0.5 || b.dist >= 560 || Math.hypot(b.x - b.hx, b.y - b.hy) > 430) {
          b.charging = false; b.sub = 3; b.t = 0.6; G.shake = 10; Sound.sfx.boom(); burst(b.x, b.y, 18, '#e6f4ff', 200);
          if (p.ringN) bossRing(b, p.ringN, 180, bdmg(b), '#ffffff');
        }
      } else if (b.t <= 0) { b.cnt++; if (b.cnt < (p.repeat || 2)) b.sub = 0; else endAttack(b, 1.0); }
    },
    rain(b, dt, p) {
      if (b.t <= 0) {
        const a = rnd(0, TAU), d = b.cnt === 0 ? 0 : rnd(0, 150);
        hazardCircle(P.x + P.vx * 0.5 + Math.cos(a) * d, P.y + P.vy * 0.5 + Math.sin(a) * d, p.r || 58, 0.9, bdmg(b, 1.3), p.fx || 'rain');
        b.cnt++; b.t = (p.rate || 0.26) / b.speedMul; if (b.cnt >= (p.n || 8)) endAttack(b, 1.1);
      }
    },
    summon(b, dt, p) { summon(b, p.type, p.n || 2, p.max || 6); endAttack(b, 1.4); },
    laser(b, dt, p) {
      if (b.sub === 0) {
        const n = p.beams || 2, base = Math.atan2(P.y - b.y, P.x - b.x), dir = Math.random() < 0.5 ? -1 : 1;
        const dur = p.dur || 3.2;
        for (let k = 0; k < n; k++) G.beams.push({ b, ang: base + (k / n) * TAU + (n === 1 ? 0 : 0.4), rot: (p.rot || 0.8) * dir, len: 560, w: 24, t: 0, warm: 0.9, dur, dmg: bdmg(b, 1.1), mouth: !!p.mouth, rainbow: !!p.rainbow });
        b.sub = 1; b.t = 0.9 + dur; Sound.sfx.laser();
      } else { bossMove(b, dt * 0.25); if (b.t <= 0) endAttack(b, 1.0); }
    },
    cross(b, dt, p) {
      if (b.sub === 0) { for (let k = 0; k < 4; k++) hazardLine(b.x, b.y, k * Math.PI / 2, 700, 44, 0.9, bdmg(b, 1.5), 'beam'); b.sub = 1; b.t = 1.0; }
      else if (b.sub === 1) { if (b.t <= 0) { for (let k = 0; k < 4; k++) hazardLine(b.x, b.y, Math.PI / 4 + k * Math.PI / 2, 700, 44, 0.9, bdmg(b, 1.5), 'beam'); b.sub = 2; b.t = 1.1; } }
      else if (b.t <= 0) endAttack(b, 1.0);
    },
    wave(b, dt, p) {
      if (b.t <= 0) {
        G.hazards.push({ kind: 'wave', x: b.x, y: b.y, r: 10, spd: p.spd || 250, thick: 26, max: 760, dmg: bdmg(b, 1.4), t: 0, hit: false });
        Sound.sfx.boom(); G.shake = 6;
        b.cnt++; b.t = (p.gap || 0.95) / b.speedMul; if (b.cnt >= (p.n || 2)) endAttack(b, 1.3);
      }
    },
    suck(b, dt, p) {
      if (b.sub === 0) { b.sub = 1; b.dur = p.dur || 2.5; Sound.sfx.laser(); }
      b.dur -= dt;
      const d = Math.hypot(b.x - P.x, b.y - P.y) || 1;
      if (P.dashT <= 0 && d > b.r) moveEntity(P, (b.x - P.x) / d * 150 * dt, (b.y - P.y) / d * 150 * dt);
      if (Math.random() < 0.7) { const a = rnd(0, TAU), r = rnd(120, 260); part(b.x + Math.cos(a) * r, b.y + Math.sin(a) * r, -Math.cos(a) * 280, -Math.sin(a) * 280, 0.6, 4, '#c8d0e0'); }
      if (b.dur <= 0) { if (p.ring) bossRing(b, 18, 170, bdmg(b), '#b0b0c0'); endAttack(b, 1.1); }
    },
    invert(b, dt, p) {
      G.invertT = p.dur || 2.5;
      showBanner('🔄 ПЕРЕВЁРНУТО', 'Управление шиворот-навыворот!'); Sound.sfx.whisper(); G.shake = 6;
      bossRing(b, 12, 150, bdmg(b), '#c08aff');
      endAttack(b, 1.2);
    },
    static(b, dt, p) {
      if (b.sub === 0) { b.sub = 1; b.dur = p.dur || 2.5; G.staticT = b.dur; Sound.sfx.staticNoise(); }
      b.dur -= dt; b.t -= dt;
      if (b.t <= 0) { b.t = 0.45 / b.speedMul; const a = Math.atan2(P.y - b.y, P.x - b.x); for (let k = -1; k <= 1; k++) ebullet(b.x, b.y - b.z, a + k * 0.25, 230, bdmg(b), '#e8e8e8', 7, { square: true }); }
      if (b.dur <= 0) endAttack(b, 1.1);
    },
    blizzard(b, dt, p) {
      if (b.sub === 0) { b.sub = 1; b.dur = p.dur || 3; b.t = 0.4; G.blizzardT = Math.max(G.blizzardT || 0, b.dur + 1); Sound.sfx.whisper(); floatText(b.x, b.y - b.r - 20, '❄️ МЕТЕЛЬ', '#e8f8ff', true); }
      b.dur -= dt; bossMove(b, dt * 0.6);
      if (b.t <= 0) {
        b.t = 0.75 / b.speedMul; const a = Math.atan2(P.y - b.y, P.x - b.x);
        for (let k = -2; k <= 2; k++) ebullet(b.x, b.y - b.z, a + k * 0.24, 200, bdmg(b), '#e8f8ff', 7);
        Sound.sfx.enemyShot();
      }
      if (b.dur <= 0) endAttack(b, 1.0);
    },
    homing(b, dt, p) {
      const n = p.n || 4;
      for (let k = 0; k < n; k++) ebullet(b.x, b.y - b.z, (k / n) * TAU + b.anim, 125, bdmg(b, 1.2), p.heart ? '#ff3b6b' : '#ff5bf0', 10, { homing: 1.8, life: 5.5, heart: p.heart });
      Sound.sfx.enemyShot(); endAttack(b, 1.6);
    },
    teleport(b, dt, p) {
      if (b.sub === 0) { b.sub = 1; b.t = 0.45; }
      else if (b.sub === 1) {
        b.alpha = clamp(b.t / 0.45, 0, 1);
        if (b.t <= 0) {
          let tx = b.x, ty = b.y;
          for (let k = 0; k < 14; k++) {
            const a = rnd(0, TAU), x = P.x + Math.cos(a) * 170, y = P.y + Math.sin(a) * 170;
            if (walkable(x, y, true) && Math.hypot(x - b.hx, y - b.hy) < 380) { tx = x; ty = y; break; }
          }
          b.tx = tx; b.ty = ty; hazardCircle(tx, ty, 80, 0.6, bdmg(b, 1.2), 'dark'); b.sub = 2; b.t = 0.6;
        }
      } else if (b.sub === 2) {
        if (b.t <= 0) { b.x = b.tx; b.y = b.ty; b.alpha = 1; bossRing(b, p.ringN || 14, 175, bdmg(b), '#c77dff', 0, { emoji: b.kind === 'zyama' }); burst(b.x, b.y, 24, '#c77dff', 220); b.sub = 3; b.t = 0.5; }
      } else if (b.t <= 0) endAttack(b, 0.9);
    },
    mines(b, dt, p) {
      if (b.sub === 0) {
        const n = p.n || 12;
        for (let k = 0; k < n; k++) hazardCircle(P.x + rnd(-260, 260), P.y + rnd(-260, 260), 52, 1.0 + k * 0.07, bdmg(b, 1.3), 'crystal');
        b.sub = 1; b.t = 1.0 + n * 0.07 + 0.4;
      } else if (b.t <= 0) endAttack(b, 1.0);
    },
    clones(b, dt, p) {
      const n = p.n || 3;
      for (let k = 0; k < n; k++) {
        const a = (k / n) * TAU + rnd(-0.3, 0.3), x = b.hx + Math.cos(a) * 230, y = b.hy + Math.sin(a) * 230;
        if (!walkable(x, y, true)) continue;
        const e = spawnEnemy('zclone', x, y, CASTLE.biome, { minion: true, E: b.E });
        e.hp = e.maxHp = b.maxHp * 0.035; e.dmg = bdmg(b);
      }
      speak(b.kind, 'Знакомьтесь – мои клоны! Каждый из них тоже Зямочкккк! 👯');
      Sound.sfx.magic(); endAttack(b, 1.5);
    },
    web(b, dt, p) {
      if (b.t <= 0) {
        const n = p.n || 5, a = leadAngle(b.x, b.y, 210);
        for (let k = 0; k < n; k++) ebullet(b.x, b.y - b.z, a + (k - (n - 1) / 2) * 0.22, 210, bdmg(b, 0.8), '#e8e0ff', 10, { slow: true });
        Sound.sfx.enemyShot(); b.cnt++; b.t = 0.6; if (b.cnt >= (p.waves || 1)) endAttack(b, 1.0);
      }
    },
    honey(b, dt, p) {
      for (let k = 0; k < (p.n || 4); k++) G.hazards.push({ kind: 'zone', x: P.x + rnd(-190, 190), y: P.y + rnd(-190, 190), r: 72, t: 0, delay: 0.5, dur: 6, slow: true, fx: p.fx || 'honey' });
      endAttack(b, 1.0);
    },
    cream(b, dt, p) { ATK.honey(b, dt, Object.assign({ fx: 'cream' }, p)); },
    // --- Глава 3 ---
    glitch(b, dt, p) {
      if (b.t <= 0) {
        hazardCircle(b.x, b.y, 70, 0.6, bdmg(b, 1.3), 'glitch');
        let tx = b.x, ty = b.y;
        for (let k = 0; k < 12; k++) {
          const a = rnd(0, TAU), r = rnd(120, 200), x = P.x + Math.cos(a) * r, y = P.y + Math.sin(a) * r;
          if (walkable(x, y, b.fly) && Math.hypot(x - b.hx, y - b.hy) < 380) { tx = x; ty = y; break; }
        }
        burst(b.x, b.y, 16, '#ff3ea5', 180);
        b.x = tx; b.y = ty; collide(b);
        burst(b.x, b.y, 16, '#3ff0a0', 180);
        bossRing(b, 8, 170, bdmg(b), '#3ff0a0', rnd(0, 1), { square: true });
        Sound.sfx.blink();
        b.cnt++; b.t = 0.55 / b.speedMul; if (b.cnt >= (p.n || 3)) endAttack(b, 1.0);
      }
    },
    pixels(b, dt, p) {
      if (b.t <= 0) {
        const vertical = p.both ? b.cnt % 2 === 1 : false;
        const gap = Math.floor(rnd(-4, 5));
        for (let k = -9; k <= 9; k++) {
          if (Math.abs(k - gap) <= 1) continue;
          if (!vertical) ebullet(P.x + k * 40, P.y - 380, Math.PI / 2, 190, bdmg(b), '#3ff0a0', 9, { square: true, life: 4.5 });
          else ebullet(P.x - 380, P.y + k * 40, 0, 190, bdmg(b), '#ff3ea5', 9, { square: true, life: 4.5 });
        }
        Sound.sfx.enemyShot();
        b.cnt++; b.t = 1.0 / b.speedMul; if (b.cnt >= (p.n || 1) * (p.both ? 2 : 1)) endAttack(b, 1.0);
      }
    },
    sprinkles(b, dt, p) {
      if (b.sub === 0) { b.sub = 1; b.dur = p.dur || 2; b.t = 0; }
      b.dur -= dt;
      if (b.t <= 0) {
        const a = Math.atan2(P.y - b.y, P.x - b.x);
        for (let k = 0; k < 2; k++) ebullet(b.x, b.y - b.z, a + rnd(-0.9, 0.9), rnd(160, 260), bdmg(b, 0.8), pick(RAINBOW), 5);
        b.t = 0.05; if (Math.random() < 0.3) Sound.sfx.enemyShot();
      }
      if (b.dur <= 0) endAttack(b, 1.0);
    },
    lightning(b, dt, p) {
      if (b.t <= 0) {
        const a = rnd(0, TAU), d = b.cnt === 0 ? 0 : rnd(0, 160);
        hazardCircle(P.x + P.vx * 0.6 + Math.cos(a) * d, P.y + P.vy * 0.6 + Math.sin(a) * d, 50, 0.75, bdmg(b, 1.4), 'bolt');
        b.cnt++; b.t = (p.rate || 0.22) / b.speedMul; if (b.cnt >= (p.n || 8)) endAttack(b, 1.1);
      }
    },
    saws(b, dt, p) {
      const n = p.n || 2, a0 = Math.atan2(P.y - b.y, P.x - b.x);
      for (let k = 0; k < n; k++) ebullet(b.x, b.y, a0 + (k - (n - 1) / 2) * 0.5, 240, bdmg(b, 1.2), '#c0c0c0', 13, { saw: true, bounce: true, life: 7, hx: b.hx, hy: b.hy });
      Sound.sfx.enemyShot(); endAttack(b, 1.2);
    },
    missiles(b, dt, p) {
      const n = p.n || 4;
      for (let k = 0; k < n; k++) ebullet(b.x, b.y - 20, -Math.PI / 2 + (k - (n - 1) / 2) * 0.45, 175, bdmg(b, 1.2), '#ff6a22', 9, { homing: 2.6, life: 4.5, missile: true });
      Sound.sfx.enemyShot(); endAttack(b, 1.4);
    },
    comments(b, dt, p) {
      if (b.t <= 0) {
        const a = leadAngle(b.x, b.y, 220);
        for (let k = 0; k < 5; k++) ebullet(b.x, b.y, a + (k - 2) * 0.2, 220, bdmg(b), '#ffffff', 9, { emoji: true, emojiSet: ['💬', '🤬', '💢', '🙄'] });
        Sound.sfx.enemyShot(); b.cnt++; b.t = 0.45 / b.speedMul; if (b.cnt >= (p.waves || 3)) endAttack(b, 1.1);
      }
    },
    toxic(b, dt, p) {
      for (let k = 0; k < (p.n || 4); k++) G.hazards.push({ kind: 'zone', x: P.x + rnd(-200, 200), y: P.y + rnd(-200, 200), r: 62, t: 0, delay: 0.6, dur: 5, dot: bdmg(b, 0.35), fx: 'toxic' });
      endAttack(b, 1.0);
    },
    mirrors(b, dt, p) {
      const n = p.n || 4;
      let made = 0;
      for (let k = 0; k < n * 3 && made < n; k++) {
        const a = (made / n) * TAU + rnd(-0.3, 0.3), r = rnd(150, 190), x = P.x + Math.cos(a) * r, y = P.y + Math.sin(a) * r;
        if (!walkable(x, y, true) || Math.hypot(x - b.hx, y - b.hy) > 420) continue;
        const e = spawnEnemy('zmirror', x, y, CASTLE.biome, { minion: true, E: b.E, bossPart: b });
        e.hp = e.maxHp = b.maxHp * 0.035; e.dmg = bdmg(b); made++;
      }
      if (made) { b.shield = true; b.shieldT = 22; speak(b.kind, 'Пока зеркала целы – я НЕУЯЗВИМ! Разбей их, если сможешь! 🪞'); Sound.sfx.magic(); }
      endAttack(b, 1.2);
    },
    erupt(b, dt, p) {
      if (b.t <= 0) {
        hazardCircle(P.x + rnd(-210, 210), P.y + rnd(-210, 210), 62, 0.9, bdmg(b, 1.4), 'erupt');
        b.cnt++; b.t = 0.17 / b.speedMul; if (b.cnt >= (p.n || 8)) endAttack(b, 1.2);
      }
    },
  };

  function updateBoss(b, dt) {
    if (b.state === 'dead') return;
    if (b.bubble) { b.bubble.t -= dt; if (b.bubble.t <= 0) b.bubble = null; }
    b.anim += dt; if (b.flash > 0) b.flash -= dt; if (b.orbCd > 0) b.orbCd -= dt;
    b.look = Math.atan2(P.y - b.y, P.x - b.x);
    const dHome = Math.hypot(P.x - b.hx, P.y - b.hy);
    if (b.state === 'sleep') {
      if (CFG.rush) {
        if (b.id === G.rush.idx && G.rush.wait <= 0 && !G.rush.done && !G.activeBoss) {
          // в раше босс выходит рядом с героиней, а не в дальнем углу арены
          const nx = P.x, ny = P.y - 300;
          if (walkable(nx, ny, b.fly)) { b.hx = b.x = nx; b.hy = b.y = ny; }
          startBossFight(b);
        }
        return;
      }
      if (b.def.immortal) return;
      const clueOk = !CFG.detective || b.final || (G.clues5[b.id] || 0) >= 3;
      if (!clueOk && dHome < 330 && G.clueMsgT <= 0) { G.clueMsgT = 3; floatText(b.x, b.y - b.r - 20, `🔎 Сначала найди улики: ${G.clues5[b.id] || 0}/3`, '#ffd25a', true); }
      const can = (!b.final || (gateOpen && playerInCastle())) && clueOk;
      if (can && dHome < 330 && !G.activeBoss) startBossFight(b);
      return;
    }
    if (dHome > 1000 && !CFG.rush) { resetBoss(b); return; }
    const stages = b.def.stages;
    if (b.mode !== 'trans' && b.stage < stages.length - 1 && b.hp <= b.maxHp * stages[b.stage + 1].at) startStage(b, b.stage + 1);
    if (b.burnT > 0) {
      b.burnT -= dt; b.burnTick -= dt;
      if (b.burnTick <= 0) { b.burnTick = 0.4; damageBoss(b, { v: b.burnDps * 0.4, crit: false }, true); if (b.state !== 'fight') return; }
    }
    if (b.shield) {
      b.shieldT -= dt;
      if (b.shieldT <= 0) { for (const o of G.enemies) if (o.bossPart === b) killEnemy(o, true); bossPartDestroyed(b); b.stunT = 1.2; }
    }
    if (b.stunT > 0) {
      b.stunT -= dt;
      if (Math.random() < 0.3) part(b.x + rnd(-b.r, b.r), b.y - b.r - 10, 0, -30, 0.6, 4, '#ffe04a');
      return;
    }
    b.t -= dt;
    if (b.mode === 'trans') {
      if (Math.random() < 0.5) part(b.x + rnd(-b.r, b.r), b.y + rnd(-b.r, b.r), rnd(-40, 40), rnd(-120, -40), 0.7, 5, pick(['#ffffff', '#ffd25a', '#ff3ea5']));
      if (b.t <= 0) { b.inv = false; endAttack(b, 0.6); }
    } else if (b.mode === 'idle') { bossMove(b, dt); if (b.t <= 0) nextAttack(b); }
    else ATK[b.mode](b, dt, b.p);
    if (b.def.lines.taunts && b.mode !== 'trans') {
      b.tauntT -= dt;
      if (b.tauntT <= 0) { b.tauntT = rnd(9, 14); b.bubble = { text: pick(b.def.lines.taunts), t: 3.6 }; }
    }
    if (b.z < 10 && b.alpha > 0.5) {
      const d = Math.hypot(P.x - b.x, P.y - b.y);
      if (d < b.r + P.r - 4) hurtPlayer(b.charging ? b.cdmg * 1.6 : b.cdmg, b.x, b.y);
    }
  }
  function damageBoss(b, hit, dot) {
    if (b.state !== 'fight' || b.alpha < 0.3 || b.z > 30) return false;
    if (b.inv) { if (Math.random() < 0.08) floatText(b.x, b.y - b.r - 14, 'неуязвим', '#aaaaaa'); return false; }
    if (b.shield) { if (Math.random() < 0.06) floatText(b.x, b.y - b.r - 14, 'зеркальный щит!', '#bfeaff'); return false; }
    if (b.def.immortal) { if (Math.random() < 0.08) floatText(b.x + rnd(-20, 20), b.y - b.r - 14, '∞', '#ff3ea5', true); addSuper(0.3); return false; }
    const v = hit.v * (b.stunT > 0 ? 1.5 : 1) * (1 + 0.12 * lv('c1guard'));
    if (G.st) G.st.dmgDealt += v;
    b.hp -= v; if (!dot) b.flash = 0.08;
    addSuper(v / b.maxHp * 150);
    if (dot) { if (Math.random() < 0.4) floatText(b.x + rnd(-20, 20), b.y - b.r, String(Math.round(v)), '#ff8a2a'); }
    else dmgText(b.x + rnd(-15, 15), b.y - b.r - 10, v, '#ffd25a', hit.crit);
    if (b.hp <= 0) bossDefeated(b);
    return true;
  }
  function bossPartDestroyed(b) {
    if (!b.shield) return;
    const left = b.shieldT > 0 && G.enemies.some(o => o.bossPart === b && !o.dead);
    if (left) return;
    b.shield = false; b.stunT = 2.8;
    showBanner('Щит разбит!', 'Бей, пока он оглушён!');
    Sound.sfx.glass(); G.shake = 12; burst(b.x, b.y, 40, '#bfeaff', 300);
    speak(b.kind, 'Мои зеркала!!! Это был эксклюзивный декор! 😱');
  }
  // звезда – за каждого босса, один раз навсегда
  function awardStar(b) {
    if (typeof CHN !== 'number') return;
    const prof = loadProfile(); prof.starsGot = prof.starsGot || {};
    const key = CHN + ':' + b.id;
    if (prof.starsGot[key]) return;
    prof.starsGot[key] = 1; prof.stars = Object.keys(prof.starsGot).length; saveProfile(prof);
    setTimeout(() => { floatText(P.x, P.y - 64, '⭐ +1 звезда для талантов!', '#ffd25a', true); Sound.sfx.superReady(); }, 1400);
    if (G.st) G.st.stars = (G.st.stars || 0) + 1;
  }
  function bossDefeated(b) {
    if (G.st && G.st.cur) { const c = G.st.cur; G.st.bosses.push({ k: c.k, n: c.n, pl: c.pl, bl: c.bl, t: Math.round(G.st.time - c.t0), d: c.d, h: c.h || 0, df: c.df || G.diffId }); G.st.cur = null; }
    b.state = 'dead'; b.hp = 0; G.defeated[b.id] = true; G.activeBoss = null; G.invertT = 0; G.staticT = 0;
    G.hazards.length = 0; G.ebullets.length = 0; G.beams.length = 0;
    for (const e of G.enemies) if (e.minion) killEnemy(e, true);
    burst(b.x, b.y, 80, '#ffd25a', 400); burst(b.x, b.y, 50, '#ff7a2f', 280); shockRing(b.x, b.y, '#ffd25a', 400);
    G.shake = 20; Sound.sfx.boom(); Sound.sfx.win();
    speak(b.kind, b.def.lines.death, 4);
    const nG = 24, gemV = xpFor(b.E) * 3.2 * xpGap(P.level, b.E) / nG;
    for (let i = 0; i < nG; i++) dropGem(b.x + rnd(-70, 70), b.y + rnd(-70, 70), gemV);
    for (let i = 0; i < 8 + b.id * 2; i++) dropShard(b.x + rnd(-60, 60), b.y + rnd(-60, 60));
    dropPickup(b.x + 30, b.y, 'heart'); dropPickup(b.x - 30, b.y, 'heart'); dropPickup(b.x, b.y + 30, 'magnet'); dropPickup(b.x - 50, b.y + 20, 'key');
    G.cp = { x: b.hx, y: b.hy };
    if (CFG.rush) { rushBossDown(b); return; }
    awardStar(b);
    if (!b.final && talent('heal')) {
      P.hp = P.maxHp; if (G.team) for (const id of G.team.list) { G.team.f[id] = 1; G.team.ko[id] = false; }
      floatText(P.x, P.y - 70, '🩹 Передышка: здоровье полное', '#7dff9a', true);
    }
    if (!b.final && b.calmBiome >= 0 && G.calm[b.calmBiome] === undefined) {
      G.calm[b.calmBiome] = 0;
      setTimeout(() => { if (state === 'play' && !G.activeBoss) showBanner('🕊️ Усмирение I', 'Враги тут слабее на 10%. Охоться здесь – до −30% и награды'); }, 5000);
    }
    if (!b.final) {
      setTimeout(() => { if (state === 'play') showBanner('Страж повержен!', b.name); }, 300);
      const done = guardiansDone(), total = guardiansCount();
      if (done >= total && !gateOpen) {
        gateOpen = true;
        say(CHN === 1 ? 'Все стражи побеждены! Ворота замка открыты – спаси меня!' : CFG.gateSay || 'Все стражи пали! Ворота Кринж-Цитадели открыты! Скорее!!!');
        setTimeout(() => { if (state === 'play') { showBanner('Ворота открыты!', CHN === 1 ? 'Тёмный замок ждёт' : CFG.gateBanner || 'Кринж-Цитадель ждёт'); Sound.sfx.gate(); } }, 3000);
        if (CFG.detective) G.boardPending = true;
      } else say(`Осталось стражей: ${total - done}. Иди по стрелке!`);
      biomeMusic(true);
      saveGame();
    } else startVictoryCutscene();
  }

  // ------------------------------------------------------------------
  //  Игрок
  // ------------------------------------------------------------------
  function hurtPlayer(dmg, sx, sy) {
    if (P.inv > 0 || P.dashT > 0 || state !== 'play' || G.cutscene) return;
    if (P.shieldLv && P.shieldT <= 0) {
      P.shieldT = P.shieldCd; P.inv = 0.5;
      floatText(P.x, P.y - 36, 'БЛОК!', '#7fe8ff', true); shockRing(P.x, P.y, '#7fe8ff', 70); Sound.sfx.block();
      return;
    }
    if (hasRelic('guard') && (G.guardT || 0) <= 0) { G.guardT = 10; P.inv = 0.5; floatText(P.x, P.y - 36, '🛡️ БЛОК!', '#ffd25a', true); shockRing(P.x, P.y, '#ffd25a', 70); Sound.sfx.block(); return; }
    if (hasRelic('mirror') && Math.random() < 0.125) { P.inv = 0.3; floatText(P.x, P.y - 36, '🪞 мимо!', '#bfeaff', true); return; }
    const d = dmg * (1 - P.armor) * (G.ev && G.ev.def.id === 'rage' ? 1.4 : 1) * (hasRelic('crown') ? 1.15 : 1);
    P.hp -= d; P.inv = 0.6;
    if (G.st) G.st.dmgTaken += d; G.shake = Math.max(G.shake, 7); G.hurtFlash = 0.35;
    dmgText(P.x, P.y - 30, d, '#ff5b5b');
    Sound.sfx.hurt();
    if (sx !== undefined) { const a = Math.atan2(P.y - sy, P.x - sx); moveEntity(P, Math.cos(a) * 14, Math.sin(a) * 14); }
    G.combo = 0;
    if (P.hp <= 0) {
      if (G.team && teamCatch()) { /* вторая героиня в строю */ }
      else if (hasRelic('phoenix') && !G.phoenixUsed) {
        G.phoenixUsed = true; P.hp = Math.round(P.maxHp * 0.5); P.inv = 2.5;
        showBanner('🪶 Перо феникса!', 'Ты возродилась из пепла'); burst(P.x, P.y, 40, '#ff8a2a', 260); Sound.sfx.magic();
      } else if (P.lives > 1 && !CFG.rush) loseLife(); else { P.hp = 0; playerDied(); }
    }
    else if (P.hp < P.maxHp * 0.3 && !G.lowHpSaid) { G.lowHpSaid = true; say('Осторожно! Собирай сердечки, чтобы подлечиться!'); }
  }
  function gainXp(v) {
    if (G.ev && G.ev.def.id === 'gold') v *= 2;
    v *= 1 + 0.08 * talent('xp');
    P.xp += v;
    while (P.xp >= P.xpNext) { P.xp -= P.xpNext; P.level++; P.xpNext = xpFor(P.level); G.pendingLv++; }
    if (G.pendingLv > 0 && state === 'play' && !G.cutscene) openLevelUp();
  }
  function tryDash() {
    if (state !== 'play' || P.dashCd > 0 || G.cutscene) return;
    let dx = input.mx, dy = input.my;
    if (G.invertT > 0) { dx = -dx; dy = -dy; }
    if (Math.hypot(dx, dy) < 0.1) { dx = P.face; dy = 0; }
    const m = Math.hypot(dx, dy); dx /= m; dy /= m;
    P.dashCd = P.dashCdMax;
    if (G.st) G.st.dashes++;
    if (P.up.c3glitch) P.inv = Math.max(P.inv, 0.2 + 0.3 * P.up.c3glitch);
    if (HEROES[P.hero].blink) {
      const sx = P.x, sy = P.y;
      for (let k = 0; k < 15; k++) {
        const nx = P.x + dx * 10, ny = P.y + dy * 10;
        if (isSolidTile(Math.floor(nx / T), Math.floor(ny / T), false)) break;
        P.x = nx; P.y = ny;
      }
      collide(P);
      P.inv = Math.max(P.inv, 0.35);
      for (let k = 0; k <= 3; k++) G.pzones.push({ x: lerp(sx, P.x, k / 3), y: lerp(sy, P.y, k / 3), r: 30, t: 0, dur: 1.6, tick: 0, dmg: P.dmg * 0.8 });
      burst(sx, sy, 14, '#ff8a2a', 160); burst(P.x, P.y, 18, '#ffd23a', 200);
      Sound.sfx.blink();
    } else {
      P.dashX = dx; P.dashY = dy; P.dashT = 0.2;
      if (HEROES[P.hero].pounce) { P.pounce = true; Sound.sfx.pounce(); } else Sound.sfx.dash();
    }
  }
  function addSuper(v) {
    if (P.sp >= 100 || G.cutscene) return;
    P.sp = Math.min(100, P.sp + v * (P.superGain || 1));
    if (P.sp >= 100) { Sound.sfx.superReady(); floatText(P.x, P.y - 46, 'СУПЕР ГОТОВ!', '#ffd25a', true); }
  }
  function trySuper() {
    if (state !== 'play' || P.sp < 100 || G.cutscene) return;
    P.sp = 0;
    if (G.st) G.st.supers++;
    for (const bl of G.ebullets) if ((bl.x - P.x) ** 2 + (bl.y - P.y) ** 2 < 220 * 220) bl.life = 0;
    const H = HEROES[P.hero];
    if (G.team) {
      showBanner('ДРУЖБА-СУПЕР!', 'Перьевой ураган + Огненная ярость');
      P.stormT = 2.6; P.stormE = 0; G.novas.push({ x: P.x, y: P.y, r: 10, max: 470, hit: new Set() });
      P.inv = Math.max(P.inv, 1.4); Sound.sfx.magic(); Sound.sfx.nova(); G.shake = 14;
      return;
    }
    showBanner(H.superName + '!', '');
    if (H.super === 'storm') { P.stormT = 2.6; P.stormE = 0; P.inv = Math.max(P.inv, 1.3); Sound.sfx.magic(); Sound.sfx.dash(); }
    else if (H.super === 'purr') {
      const heal = Math.round(P.maxHp * 0.25); P.hp = Math.min(P.maxHp, P.hp + heal); floatText(P.x, P.y - 40, '+' + heal, '#7dff7d', true);
      G.novas.push({ x: P.x, y: P.y, r: 10, max: 420, hit: new Set(), purr: true }); P.inv = Math.max(P.inv, 1.1); Sound.sfx.purr();
    }
    else { G.novas.push({ x: P.x, y: P.y, r: 10, max: 470, hit: new Set() }); P.inv = Math.max(P.inv, 1.1); Sound.sfx.nova(); }
    G.shake = 14;
  }
  function nearestTarget(range) {
    let best = null, bd = range * range;
    for (const e of G.enemies) {
      if (e.dead || e.spawnT > 0) continue;
      let d = (e.x - P.x) ** 2 + (e.y - P.y) ** 2;
      if (d > range * range) continue;
      if (e.def.ai === 'healer') d *= 0.6; // лекарей бьём первыми
      if (d < bd) { bd = d; best = e; }
    }
    const b = G.activeBoss;
    if (b && b.state === 'fight' && b.alpha > 0.3 && b.z < 30 && !b.inv && !b.shield) {
      const d = (b.x - P.x) ** 2 + (b.y - P.y) ** 2;
      if (d < (range + b.r) ** 2 && (!best || bd > 85 * 85 || d < bd * 2.5)) best = b;
    }
    return best;
  }
  function hitAny(tg, hit, kx, ky, fromFeather) {
    if (tg.kind) return damageBoss(tg, hit);
    return damageEnemy(tg, hit, kx, ky, fromFeather);
  }
  function onProjHit(f, tg) {
    if (f.kind === 'fire') {
      const R = P.splash || 38;
      for (const e of G.enemies) {
        if (e === tg || e.dead || e.spawnT > 0) continue;
        if ((e.x - f.x) ** 2 + (e.y - f.y) ** 2 < (R + e.r) ** 2) damageEnemy(e, { v: f.dmg * 0.5, crit: false }, 0, 0, false);
      }
      G.rings.push({ x: f.x, y: f.y, r: 6, max: R, col: '#ff8a2a', t: 0 });
      burst(f.x, f.y, 6, '#ffb03a', 120);
      if (tg && !tg.dead) { tg.burnT = 2; tg.burnDps = Math.max(tg.burnDps || 0, f.dmg * (P.burn || 0.35)); tg.burnTick = tg.burnTick || 0.4; }
    } else if (P.explode) featherExplode(f.x, f.y, f.dmg, tg && !tg.kind ? tg : null);
  }
  function featherExplode(x, y, dmg, skip) {
    const R = 40 + 12 * P.explode;
    for (const e of G.enemies) {
      if (e === skip || e.dead || e.spawnT > 0) continue;
      if ((e.x - x) ** 2 + (e.y - y) ** 2 < (R + e.r) ** 2) damageEnemy(e, { v: dmg * 0.35, crit: false }, 0, 0, false);
    }
    G.rings.push({ x, y, r: 6, max: R, col: '#ffb03a', t: 0 });
  }

  function updatePlayer(dt) {
    P.t += dt;
    if (state === 'dying') return;
    if (P.inv > 0) P.inv -= dt;
    if (P.dashCd > 0) P.dashCd -= dt;
    if (P.slowT > 0) P.slowT -= dt;
    if (P.shieldLv && P.shieldT > 0) P.shieldT -= dt;
    if (P.regen && P.hp < P.maxHp) P.hp = Math.min(P.maxHp, P.hp + P.regen * dt);
    let mx = input.mx, my = input.my;
    if (G.invertT > 0) { mx = -mx; my = -my; }
    if (P.napT > 0) P.napT -= dt;
    const m = Math.hypot(mx, my);
    if (m > 1) { mx /= m; my /= m; }
    P.moving = m > 0.08;
    const ox = P.x, oy = P.y;
    const spd = P.speed * (P.slowT > 0 ? 0.55 : 1) * (G.blizzardT > 0 && !G.nearFire && !lv('c6warm') ? 0.9 : 1);
    const onIce = CFG.slippery && tileAt(Math.floor(P.x / T), Math.floor(P.y / T)) === ICE;
    if (P.dashT > 0) {
      P.dashT -= dt;
      moveEntity(P, P.dashX * P.speed * 3.3 * dt, P.dashY * P.speed * 3.3 * dt);
      P.ivx = P.dashX * P.speed * 1.3; P.ivy = P.dashY * P.speed * 1.3;
      part(P.x + rnd(-6, 6), P.y + rnd(-10, 6), 0, 0, 0.35, 5, 'rgba(160,225,255,0.8)');
      if (Math.abs(P.dashX) > 0.2) P.face = P.dashX > 0 ? 1 : -1;
      if (P.dashT <= 0 && P.pounce) { P.pounce = false; pounceHit(); }
    } else if (onIce) {
      // лёд: разгон и торможение с инерцией
      const k = Math.min(1, dt * 2.4);
      const isp = CFG.iceSpeed || 1.15;
      P.ivx = (P.ivx || 0) + ((P.moving ? mx * spd * isp : 0) - (P.ivx || 0)) * k;
      P.ivy = (P.ivy || 0) + ((P.moving ? my * spd * isp : 0) - (P.ivy || 0)) * k;
      moveEntity(P, P.ivx * dt, P.ivy * dt);
      if (dt > 0) { P.ivx = (P.x - ox) / dt; P.ivy = (P.y - oy) / dt; }
      if (P.moving && Math.abs(mx) > 0.15) P.face = mx > 0 ? 1 : -1;
      if (Math.hypot(P.ivx, P.ivy) > 70 && Math.random() < 0.3) part(P.x + rnd(-6, 6), P.y + 10, -P.ivx * 0.1, -10, 0.4, 3, 'rgba(230,248,255,0.9)');
    } else if (P.moving) {
      moveEntity(P, mx * spd * dt, my * spd * dt);
      if (Math.abs(mx) > 0.15) P.face = mx > 0 ? 1 : -1;
      P.ivx = mx * spd; P.ivy = my * spd;
    } else { P.ivx = 0; P.ivy = 0; }
    if (dt > 0) { P.vx = lerp(P.vx, (P.x - ox) / dt, 0.3); P.vy = lerp(P.vy, (P.y - oy) / dt, 0.3); }
    // супер Крилессы: перьевой ураган
    if (P.stormT > 0) {
      P.stormT -= dt; P.stormE -= dt;
      if (P.stormE <= 0) {
        P.stormE = 0.07;
        for (let k = 0; k < 5; k++) {
          const a = P.t * 4 + (k / 5) * TAU;
          G.feathers.push({ x: P.x, y: P.y - 8, vx: Math.cos(a) * 520, vy: Math.sin(a) * 520, dmg: P.dmg * 0.9, pierce: 2, life: 0.9, hit: [], kind: 'feather' });
        }
      }
    }
    // перья
    P.fireT -= dt;
    if (P.fireT <= 0 && !G.hidden && !G.jump) {
      P.volley = (P.volley || 0) + 1;
      let tg = nearestTarget(P.range);
      // каждый второй залп – в босса, даже если вокруг толпа миньонов
      const bb = G.activeBoss;
      if (bb && P.volley % 2 === 0 && bb.state === 'fight' && !bb.inv && !bb.shield && bb.alpha > 0.3 && bb.z < 30 &&
        (bb.x - P.x) ** 2 + (bb.y - P.y) ** 2 < (P.range + bb.r) ** 2) tg = bb;
      if (!tg && CFG.icedChests && (P.proj === 'fire' || lv('c6ice'))) tg = iceTarget();
      if (tg) {
        const base = Math.atan2(tg.y - (tg.z || 0) - P.y, tg.x - P.x);
        for (let i = 0; i < P.shots; i++) {
          const a = base + (i - (P.shots - 1) / 2) * 0.16;
          const life = (P.range / P.projSpd) * 1.35;
          G.feathers.push({ x: P.x, y: P.y - 8, vx: Math.cos(a) * P.projSpd, vy: Math.sin(a) * P.projSpd, dmg: P.dmg, pierce: P.pierce, life, life0: life, hit: [], kind: P.proj });
        }
        if (P.up.c3twin && Math.random() < 0.1 * P.up.c3twin) {
          const life = (P.range / P.projSpd) * 1.35;
          for (let i = 0; i < P.shots; i++) {
            const a = base + (i - (P.shots - 1) / 2) * 0.16 + 0.09;
            G.feathers.push({ x: P.x, y: P.y - 8, vx: Math.cos(a) * P.projSpd, vy: Math.sin(a) * P.projSpd, dmg: P.dmg, pierce: P.pierce, life, life0: life, hit: [], kind: P.proj, twin: true });
          }
        }
        if (P.proj === 'fire') Sound.sfx.fireball(); else if (P.proj === 'claw') Sound.sfx.claw(); else Sound.sfx.shoot();
        P.fireT = P.fireInt;
      } else P.fireT = 0.1;
    }
    if (P.up.c2disco) {
      P.discoT = (P.discoT === undefined ? 6 : P.discoT) - dt;
      if (P.discoT <= 0 && !G.cutscene) { P.discoT = 6; G.novas.push({ x: P.x, y: P.y, r: 10, max: 150 + 25 * P.up.c2disco, hit: new Set(), k: 0.8 * P.up.c2disco, disco: true }); }
    }
    // вихрь
    if (P.orbit) {
      P.orbA += dt * 3.2;
      for (let k = 0; k < P.orbit; k++) {
        const a = P.orbA + (k / P.orbit) * TAU, ox2 = P.x + Math.cos(a) * 62, oy2 = P.y + Math.sin(a) * 62;
        for (const e of G.enemies) {
          if (e.dead || e.orbCd > 0 || e.spawnT > 0) continue;
          if ((e.x - ox2) ** 2 + (e.y - oy2) ** 2 < (e.r + 10) ** 2) { e.orbCd = 0.35; damageEnemy(e, rollHit(P.dmg * 0.7), Math.cos(a) * 120, Math.sin(a) * 120, false); }
        }
        const b = G.activeBoss;
        if (b && (b.x - ox2) ** 2 + (b.y - oy2) ** 2 < (b.r + 10) ** 2 && b.orbCd <= 0) { b.orbCd = 0.3; damageBoss(b, rollHit(P.dmg * 0.7)); }
      }
    }
    // молния
    if (P.bolt) {
      P.boltT -= dt;
      if (P.boltT <= 0) {
        P.boltT = Math.max(1.0, 2.8 - P.bolt * 0.28);
        const cands = G.enemies.filter(e => !e.dead && e.spawnT <= 0 && (e.x - P.x) ** 2 + (e.y - P.y) ** 2 < (P.range * 1.3) ** 2);
        if (G.activeBoss && G.activeBoss.state === 'fight' && !G.activeBoss.inv) cands.push(G.activeBoss);
        if (cands.length) {
          let cur = pick(cands); const pts = [[P.x, P.y - 20]]; const used = new Set();
          for (let k = 0; k <= P.bolt; k++) {
            if (!cur) break;
            used.add(cur); pts.push([cur.x, cur.y]);
            hitAny(cur, rollHit(P.dmg * 1.6), 0, 0, false);
            let nb = null, nd = 160 * 160;
            for (const e of cands) { if (used.has(e) || e.dead) continue; const d = (e.x - cur.x) ** 2 + (e.y - cur.y) ** 2; if (d < nd) { nd = d; nb = e; } }
            cur = nb;
          }
          G.bolts.push({ pts, t: 0.25 });
          Sound.sfx.bolt();
        }
      }
    }
  }

  // ------------------------------------------------------------------
  //  Мир: спавн, снаряды, опасности, подбор
  // ------------------------------------------------------------------
  function spawnEnemies(dt) {
    G.spawnT -= dt;
    if (G.spawnT > 0) return;
    G.spawnT = CFG.spawnEvery * 0.8 * (G.ev && G.ev.def.id === 'horde' ? 0.35 : 1);
    if (G.activeShrine || CFG.rush || G.finalFinal) return;
    const ptx = Math.floor(P.x / T), pty = Math.floor(P.y / T);
    if (Math.hypot(ptx - START.x, pty - START.y) < 7) return;
    const pb = biomeMap[clamp(pty, 0, MH - 1) * MW + clamp(ptx, 0, MW - 1)];
    const zi = Math.max(0, Object.keys(CFG.zoneLevel).indexOf(String(pb)));
    let cap = CFG.capBase * 1.3 + zi * 2 + Math.min(8, Math.max(0, P.level - zoneE(pb)) * 0.3);
    if (CHN !== 1) cap *= clamp(0.5 + P.level * 0.035, 0.5, 1); // глава начинается с 1 уровня – толпа нарастает постепенно
    if (G.activeBoss) return;
    if (G.ev && G.ev.def.id === 'horde') cap *= 1.8;
    if (G.enemies.length >= cap) return;
    const vw = VW / ZOOM, vh = VH / ZOOM;
    const inCastle = playerInCastle();
    for (let k = 0; k < 8; k++) {
      const R = inCastle ? rnd(240, 420) : Math.hypot(vw, vh) / 2 + 50;
      const a = rnd(0, TAU), x = P.x + Math.cos(a) * R, y = P.y + Math.sin(a) * R;
      const tx = Math.floor(x / T), ty = Math.floor(y / T);
      if (!inMap(tx, ty) || ty >= PLAY_H) continue; // ниже карты – пустота и арена
      if (inCastle && tiles[ty * MW + tx] !== FLOOR) continue;
      const biome = inCastle ? CASTLE.biome : biomeMap[ty * MW + tx];
      if (!SPAWNS[biome]) continue;
      const type = weighted(SPAWNS[biome]);
      if (!walkable(x, y, ENEMIES[type].fly)) continue;
      if (bosses.some(b => b.state === 'sleep' && Math.hypot(x - b.hx, y - b.hy) < 300)) continue;
      const elite = Math.random() < CFG.elite * G.diff.elite * (0.35 + 0.65 * chDiff(zoneE(biome)).k); // элита в начале главы реже
      spawnEnemy(type, x, y, biome, { elite, instant: !inCastle });
      const grp = ENEMIES[type].group;
      if (grp) { const n = grp[0] + Math.floor(Math.random() * (grp[1] - grp[0] + 1)) - 1; for (let i = 0; i < n; i++) spawnEnemy(type, x + rnd(-30, 30), y + rnd(-30, 30), biome, { instant: !inCastle }); }
      return;
    }
  }
  function updateProjectiles(dt) {
    for (const f of G.feathers) {
      f.x += f.vx * dt; f.y += f.vy * dt; f.life -= dt;
      if (blocksShots(f.x, f.y)) { f.life = 0; burst(f.x, f.y, 3, '#fff', 60); if (CFG.slippery) tryMelt(f); continue; }
      if (drifts.length && !f.ally && hitDrift(f)) continue;
      for (const e of G.enemies) {
        if (e.dead || e.spawnT > 0 || f.hit.includes(e)) continue;
        if ((e.x - f.x) ** 2 + (e.y - f.y) ** 2 < (e.r + 5) ** 2) {
          f.hit.push(e);
          if (e.def.ai === 'shield' && Math.abs(angDiff(e.shieldAng, Math.atan2(f.y - e.y, f.x - e.x))) < 1.05) {
            f.life = 0; burst(f.x, f.y, 6, '#bfefff', 120); if (Math.random() < 0.3) floatText(e.x, e.y - e.r - 8, 'блок', '#bfefff'); Sound.sfx.block(); break;
          }
          damageEnemy(e, rollHit(f.dmg), f.vx * 0.25, f.vy * 0.25, true);
          onProjHit(f, e);
          if (f.pierce-- <= 0) { f.life = 0; break; }
        }
      }
      const b = G.activeBoss;
      if (f.life > 0 && b && !f.hit.includes(b) && (b.x - f.x) ** 2 + (b.y - b.z - f.y) ** 2 < (b.r + 5) ** 2) {
        f.hit.push(b);
        if (damageBoss(b, rollHit(f.dmg))) { Sound.sfx.hit(); burst(f.x, f.y, 4, '#ffd25a', 90); onProjHit(f, b); }
        else if (b.def.immortal && G.finalFinal && !f.ally) { G.finalFinal.bank = Math.min(0.5, G.finalFinal.bank + 0.1); burst(f.x, f.y, 3, '#ff8ad8', 70); }
        if (f.pierce-- <= 0) f.life = 0;
      }
    }
    G.feathers = G.feathers.filter(f => f.life > 0);
    for (const b of G.ebullets) {
      if (b.homing) {
        const want = Math.atan2(P.y - b.y, P.x - b.x), cur = Math.atan2(b.vy, b.vx);
        const na = cur + clamp(angDiff(cur, want), -b.homing * dt, b.homing * dt);
        b.vx = Math.cos(na) * b.spd; b.vy = Math.sin(na) * b.spd;
      }
      if (b.bounce) {
        const nx = b.x + b.vx * dt, ny = b.y + b.vy * dt;
        if (blocksShots(nx, b.y) || Math.abs(nx - b.hx) > 430) b.vx = -b.vx;
        if (blocksShots(b.x, ny) || Math.abs(ny - b.hy) > 430) b.vy = -b.vy;
        b.rot += dt * 12;
      }
      if (b.missile && Math.random() < 0.4) part(b.x, b.y, rnd(-10, 10), rnd(-10, 10), 0.5, 4, 'rgba(160,160,160,0.6)');
      b.x += b.vx * dt; b.y += b.vy * dt; b.life -= dt;
      if (!b.bounce && blocksShots(b.x, b.y)) { b.life = 0; continue; }
      if ((P.x - b.x) ** 2 + (P.y - 6 - b.y) ** 2 < (b.r + P.r - 3) ** 2) {
        if (P.inv <= 0 && P.dashT <= 0) { hurtPlayer(b.dmg); if (b.slow) P.slowT = 1.6; b.life = 0; }
      }
    }
    G.ebullets = G.ebullets.filter(b => b.life > 0);
    // лазеры
    for (const bm of G.beams) {
      bm.t += dt;
      if (bm.b.state !== 'fight' || bm.b.mode === 'trans') { bm.t = 1e9; continue; }
      const o = bm.mouth ? bossMouth(bm.b) : { x: bm.b.x, y: bm.b.y - bm.b.z };
      bm.x = o.x; bm.y = o.y;
      if (bm.t > bm.warm) {
        bm.ang += bm.rot * dt;
        const ca = Math.cos(bm.ang), sa = Math.sin(bm.ang);
        let len = 0;
        for (len = 0; len < 560; len += 20) if (blocksShots(bm.x + ca * len, bm.y + sa * len)) break;
        bm.len = len;
        const dx = P.x - bm.x, dy = P.y - bm.y;
        const along = dx * ca + dy * sa, perp = Math.abs(-dx * sa + dy * ca);
        if (along > 0 && along < bm.len && perp < bm.w / 2 + P.r * 0.4) hurtPlayer(bm.dmg);
      }
    }
    G.beams = G.beams.filter(bm => bm.t < bm.warm + bm.dur);
  }
  function updatePlayerFx(dt) {
    for (const z of G.pzones) {
      z.t += dt; z.tick -= dt;
      if (Math.random() < 0.4) part(z.x + rnd(-z.r, z.r) * 0.6, z.y + rnd(-z.r, z.r) * 0.6, 0, -50, 0.5, 4, pick(['#ff8a2a', '#ffd23a', '#ff4a1a']));
      if (z.tick <= 0) {
        z.tick = 0.35;
        for (const e of G.enemies) if (!e.dead && e.spawnT <= 0 && (e.x - z.x) ** 2 + (e.y - z.y) ** 2 < (z.r + e.r) ** 2) damageEnemy(e, { v: z.dmg, crit: false }, 0, 0, false);
        const b = G.activeBoss;
        if (b && (b.x - z.x) ** 2 + (b.y - z.y) ** 2 < (z.r + b.r) ** 2) damageBoss(b, { v: z.dmg, crit: false }, true);
      }
    }
    G.pzones = G.pzones.filter(z => z.t < z.dur);
    for (const n of G.novas) {
      n.r += (n.disco ? 520 : 900) * dt;
      for (const e of G.enemies) {
        if (e.dead || e.spawnT > 0 || n.hit.has(e)) continue;
        const d = Math.hypot(e.x - n.x, e.y - n.y);
        if (Math.abs(d - n.r) < 36 + e.r) {
          n.hit.add(e);
          if (n.k) damageEnemy(e, rollHit(P.dmg * n.k), (e.x - n.x) / d * 160, (e.y - n.y) / d * 160, false);
          else if (n.purr) { damageEnemy(e, rollHit(P.dmg * 4), (e.x - n.x) / d * 260, (e.y - n.y) / d * 260, false); e.slowT = Math.max(e.slowT || 0, 2.5); }
          else { damageEnemy(e, rollHit(P.dmg * 6), (e.x - n.x) / d * 300, (e.y - n.y) / d * 300, false); e.burnT = 3; e.burnDps = P.dmg * 0.6; }
        }
      }
      const b = G.activeBoss;
      if (b && !n.hit.has(b) && Math.abs(Math.hypot(b.x - n.x, b.y - n.y) - n.r) < 40 + b.r) {
        n.hit.add(b);
        if (n.k) damageBoss(b, rollHit(P.dmg * n.k * 1.5));
        else if (n.purr) { damageBoss(b, rollHit(P.dmg * 9)); if (!b.def.immortal) b.stunT = Math.max(b.stunT, 1.2); }
        else { damageBoss(b, rollHit(P.dmg * 12)); b.burnT = 3; b.burnDps = P.dmg * 0.6; }
      }
      if (!n.disco) for (const bl of G.ebullets) if ((bl.x - n.x) ** 2 + (bl.y - n.y) ** 2 < n.r * n.r) bl.life = 0;
    }
    G.novas = G.novas.filter(n => n.r < n.max);
  }
  function updateHazards(dt) {
    for (const h of G.hazards) {
      h.t += dt;
      if (h.cancel) { h.t = 1e9; h.r = 1e9; continue; }
      if (h.kind === 'wave') {
        h.r += h.spd * dt;
        const d = Math.hypot(P.x - h.x, P.y - h.y);
        if (!h.hit && Math.abs(d - h.r) < h.thick / 2 + P.r * 0.4 && P.inv <= 0 && P.dashT <= 0) { hurtPlayer(h.dmg); h.hit = true; }
        continue;
      }
      if (h.kind === 'zone') {
        if (h.t > h.delay && Math.hypot(P.x - h.x, P.y - h.y) < h.r) {
          if (h.slow) P.slowT = Math.max(P.slowT, 0.25);
          if (h.dot) { h.tick = (h.tick || 0) - dt; if (h.tick <= 0) { h.tick = 0.5; hurtPlayer(h.dot); } }
        }
        continue;
      }
      if (!h.done && h.t >= h.delay) {
        h.done = true;
        let hit = false;
        if (h.kind === 'circle') hit = Math.hypot(P.x - h.x, P.y - h.y) < h.r + P.r * 0.5;
        else {
          const dx = P.x - h.x, dy = P.y - h.y, ca = Math.cos(h.ang), sa = Math.sin(h.ang);
          const along = dx * ca + dy * sa, perp = Math.abs(-dx * sa + dy * ca);
          hit = along > -10 && along < h.len && perp < h.w / 2 + P.r * 0.5;
        }
        if (hit && h.dmg) hurtPlayer(h.dmg);
        if (h.fx === 'stomp') { burst(h.x, h.y, 26, '#c9a46b', 260); G.shake = Math.max(G.shake, 9); Sound.sfx.boom(); }
        else if (h.fx === 'meteor') {
          burst(h.x, h.y, 26, '#ff8a2a', 260); burst(h.x, h.y, 10, '#ffd23a', 160); G.shake = Math.max(G.shake, 6); Sound.sfx.meteor();
          for (const e of G.enemies) if (!e.dead && e.spawnT <= 0 && (e.x - h.x) ** 2 + (e.y - h.y) ** 2 < (h.r + e.r) ** 2) damageEnemy(e, { v: P.dmg * 4, crit: false }, 0, 0, false);
        }
        else if (h.fx === 'icicle') { burst(h.x, h.y, 14, '#bfefff', 200); Sound.sfx.hit(); }
        else if (h.fx === 'dark') burst(h.x, h.y, 16, '#c77dff', 200);
        else if (h.fx === 'crystal') burst(h.x, h.y, 16, '#5be3ff', 200);
        else if (h.fx === 'rain') burst(h.x, h.y, 12, '#ffffff', 160);
        else if (h.fx === 'boom') { burst(h.x, h.y, 30, '#ff8a2a', 280); G.shake = Math.max(G.shake, 8); }
        else if (h.fx === 'bolt') { G.bolts.push({ pts: [[h.x + rnd(-30, 30), h.y - 340], [h.x, h.y]], t: 0.3, col: '255,240,120' }); burst(h.x, h.y, 14, '#fff04a', 200); Sound.sfx.bolt(); }
        else if (h.fx === 'glitch') { burst(h.x, h.y, 18, '#3ff0a0', 220); burst(h.x, h.y, 10, '#ff3ea5', 180); }
        else if (h.fx === 'erupt') {
          burst(h.x, h.y, 22, '#ff6a22', 260);
          G.hazards.push({ kind: 'zone', x: h.x, y: h.y, r: 46, t: 0, delay: 0, dur: 2.6, dot: h.dmg * 0.25, fx: 'lava' });
        }
      }
    }
    G.hazards = G.hazards.filter(h => {
      if (h.kind === 'wave') return h.r < h.max;
      if (h.kind === 'zone') return h.t < h.delay + h.dur;
      return h.t < h.delay + 0.3;
    });
  }
  function updatePickups(dt) {
    for (const p of G.pickups) {
      p.t += dt;
      const dx = P.x - p.x, dy = P.y - p.y, d = Math.hypot(dx, dy) || 1;
      if (d < P.magnet || p.pull) {
        p.pull = true;
        const s = 260 + p.t * 120;
        p.x += (dx / d) * Math.min(d, s * dt); p.y += (dy / d) * Math.min(d, s * dt);
      }
      if (d < P.r + 8) {
        p.got = true;
        if (p.kind === 'xp') { gainXp(p.v); Sound.sfx.gem(); }
        else if (p.kind === 'heart') { const h = Math.round(P.maxHp * 0.25 * (hasRelic('heartstone') ? 1.5 : 1) * (1 + 0.2 * lv('c5snack'))), gain = Math.max(0, Math.min(h, P.maxHp - P.hp)); if (G.st) { G.st.healed = (G.st.healed || 0) + (isFinite(gain) ? gain : 0); if (G.st.cur) G.st.cur.h = (G.st.cur.h || 0) + 1; } P.hp = Math.min(P.maxHp, P.hp + h); floatText(P.x, P.y - 34, '+' + h, '#7dff7d'); Sound.sfx.heart(); }
        else if (p.kind === 'star') { addSuper(10); floatText(P.x, P.y - 34, '⭐ +10% супера', '#ffe08a'); Sound.sfx.shard(); }
        else if (p.kind === 'key') { G.keys = (G.keys || 0) + 1; floatText(P.x, P.y - 34, '🔑 +1', '#ffd25a', true); Sound.sfx.clue(); }
        else if (p.kind === 'magnet') { for (const q of G.pickups) if (q.kind !== 'heart') q.pull = true; Sound.sfx.heart(); }
        else if (p.kind === 'shard') {
          const s = SHARDS[p.sid];
          const pb = biomeMap[clamp(Math.floor(P.y / T), 0, MH - 1) * MW + clamp(Math.floor(P.x / T), 0, MW - 1)];
          const val = s.id === 'hp' ? Math.max(3, Math.round(refEHP(zoneE(pb)) * 0.012)) : s.val;
          P.bonus[s.id] = (P.bonus[s.id] || 0) + val; P.shards++;
          computeStats();
          if (s.id === 'hp') P.hp = Math.min(P.maxHp, P.hp + val);
          floatText(P.x + rnd(-10, 10), P.y - 40, s.txt(val), s.col);
          if (G.st) G.st.shards++;
          Sound.sfx.shard();
        }
      }
    }
    G.pickups = G.pickups.filter(p => !p.got);
    for (const c of chests) {
      if (c.open) continue;
      const dd = Math.hypot(P.x - c.x, P.y - c.y);
      if (dd < 320) c.seen = true; // спрятанные сундуки появляются на карте, только когда их увидишь
      if (dd < 34) openChest(c);
    }
  }
  function updateShrines() {
    for (const s of shrines) {
      if (s.state === 'done') continue;
      const d = Math.hypot(P.x - s.x, P.y - s.y);
      if (s.state === 'idle' && d < 36 && !G.activeBoss && !G.activeShrine && !G.jump && ARENA) enterTrial(s);
      else if (s.state === 'active') {
        G.trialT = (G.trialT || 0) + 1 / 60;
        if (G.trialT > 1.5 && Math.hypot(P.x - ARENA.exit.x, P.y - ARENA.exit.y) < 24) failTrial(s);
        else if (s.left <= 0) completeTrial(s);
      }
    }
  }
  function updateParticles(dt) {
    for (const p of G.parts) { p.x += p.vx * dt; p.y += p.vy * dt; p.vx *= 0.92; p.vy = p.vy * 0.92 + p.grav * dt; p.life -= dt; }
    G.parts = G.parts.filter(p => p.life > 0);
    for (const t of G.texts) t.t += dt;
    G.texts = G.texts.filter(t => t.t < (t.big ? 1.1 : 0.8));
    for (const b of G.bolts) b.t -= dt;
    G.bolts = G.bolts.filter(b => b.t > 0);
    for (const r of G.rings) { r.t += dt; r.r += (r.max - r.r) * Math.min(1, dt * 8); }
    G.rings = G.rings.filter(r => r.t < 0.45);
  }
  function updateTriggers(dt) {
    G.gateMsgT -= dt; G.lowHpT -= dt;
    if (G.comboT > 0) { G.comboT -= dt; if (G.comboT <= 0) G.combo = 0; }
    if (!gateOpen && G.gateMsgT <= 0 && Math.hypot(P.x - tc(GATE_FRONT.x), P.y - tc(GATE_FRONT.y)) < 180) {
      say(`Ворота заперты магией! Победи стражей: ${guardiansDone()}/${guardiansCount()}.`);
      G.gateMsgT = 12;
    }
    G.fogT -= dt;
    if (G.fogT <= 0) { G.fogT = 0.25; revealFog(P.x, P.y, 9); }
    G.scaleT = (G.scaleT || 0) - dt;
    if (G.scaleT <= 0) { G.scaleT = 1; G.scaleCache = {}; }
    if (G.hintT > 0) G.hintT -= dt;
  }
  function objective() {
    for (let i = 0; i < guardiansCount(); i++) if (!G.defeated[i]) {
      if (CFG.detective && (G.clues5[i] || 0) < 3) {
        let best = null, bd = 1e12;
        for (const q of clues) if (q.i === i && !q.found) { const d = (q.x - P.x) ** 2 + (q.y - P.y) ** 2; if (d < bd) { bd = d; best = q; } }
        if (best) return { x: best.x, y: best.y };
      }
      return { x: bosses[i].hx, y: bosses[i].hy };
    }
    const fin = bosses[bosses.length - 1];
    if (!G.defeated[fin.id]) {
      if (!playerInCastle()) return { x: tc(GATE_FRONT.x), y: tc(GATE_FRONT.y) };
      return { x: fin.hx, y: fin.hy };
    }
    return { x: tc(CAGE.x), y: tc(CAGE.y) };
  }
  function update(dt) {
    G.time += dt;
    if (G.cutscene) updateCutscene(dt);
    else {
      updatePlayer(dt);
      updateEnemies(dt);
      for (const b of bosses) updateBoss(b, dt);
      updateProjectiles(dt);
      updatePlayerFx(dt);
      updateHazards(dt);
      updatePickups(dt);
      updateShrines();
      spawnEnemies(dt);
      updateTriggers(dt);
      updateEvents(dt);
      updateFinalFinal(dt);
      updateBossHearts(dt);
      updateChampions(dt);
      updateHouse(dt);
      updateWinter(dt);
      updateRelics(dt);
      updateMusic(dt);
    }
    if (G.st && state === 'play') G.st.time += dt;
    if (G.rush && !G.rush.done && state === 'play') { G.rush.t += dt; if (G.rush.wait > 0) G.rush.wait -= dt; }
    updateParticles(dt);
    Dialog.update(dt);
    if (G.shake > 0) G.shake = Math.max(0, G.shake - dt * 30);
    if (G.hurtFlash > 0) G.hurtFlash -= dt;
    updateCamera();
  }
  function updateCamera() {
    const vw = VW / ZOOM, vh = VH / ZOOM;
    let tx = P.x, ty = P.y;
    if (state === 'menu') { G.menuT += 1 / 60; tx = tc(START.x) + Math.sin(G.menuT * 0.12) * 900 - 500; ty = tc(START.y) - 600 + Math.cos(G.menuT * 0.09) * 500; }
    G.cam.x = clamp(tx, vw / 2, WORLD_W - vw / 2);
    const inArena = state !== 'menu' && P.y > PLAY_H * T;
    G.cam.y = clamp(ty, (inArena ? PLAY_H * T : 0) + vh / 2, (inArena ? WORLD_H : PLAY_H * T) - vh / 2);
  }



  // ------------------------------------------------------------------
  //  Главы Тессы: жизни, прыжок, лежанки, улики, жители, полки, коробки
  // ------------------------------------------------------------------
  function loseLife() {
    P.lives--; P.hp = Math.round(P.maxHp * 0.35); P.inv = 2.2;
    for (const bl of G.ebullets) if ((bl.x - P.x) ** 2 + (bl.y - P.y) ** 2 < 200 * 200) bl.life = 0;
    burst(P.x, P.y, 30, '#bfeaff', 220); shockRing(P.x, P.y, '#bfeaff', 180);
    if (P.up.c4life) G.novas.push({ x: P.x, y: P.y, r: 10, max: 320, hit: new Set(), k: 2.5 * P.up.c4life, life: true });
    showBanner(`🐾 Осталось жизней: ${P.lives}`, P.lives <= 2 ? 'Найди лежанку – там можно вздремнуть' : 'Кошки так просто не сдаются');
    Sound.sfx.meow(); G.shake = 10;
    if (G.st) G.st.livesLost = (G.st.livesLost || 0) + 1;
  }
  function pounceHit() {
    const R = 80;
    for (const e of G.enemies) {
      if (e.dead || e.spawnT > 0) continue;
      const d = Math.hypot(e.x - P.x, e.y - P.y) || 1;
      if (d < R + e.r) { damageEnemy(e, rollHit(P.dmg * 1.8), (e.x - P.x) / d * 260, (e.y - P.y) / d * 260, false); e.slowT = Math.max(e.slowT || 0, 1); }
    }
    const b = G.activeBoss;
    if (b && b.state === 'fight' && Math.hypot(b.x - P.x, b.y - P.y) < R + b.r) damageBoss(b, rollHit(P.dmg * 1.8));
    G.rings.push({ x: P.x, y: P.y, r: 8, max: R, col: '#ffd0f0', t: 0 }); burst(P.x, P.y, 12, '#fff0f8', 160); G.shake = Math.max(G.shake, 4);
  }
  function napOn(bd) {
    bd.nap = 0; bd.cd = 75;
    P.hp = P.maxHp; if (P.lives) P.lives = Math.min(HEROES[P.hero].lives || 9, P.lives + 1); P.napT = 60;
    G.cp = { x: bd.x, y: bd.y + 30 };
    showBanner('💤 Тесса вздремнула', 'Здоровье полное, +1 жизнь, +20% урона на минуту');
    Sound.sfx.nap(); burst(bd.x, bd.y, 20, '#ffe0a0', 120);
    saveGame();
  }
  function updateHouse(dt) {
    if (G.invertT > 0) G.invertT -= dt;
    if (G.staticT > 0) G.staticT -= dt;
    if (G.clueMsgT > 0) G.clueMsgT -= dt;
    if (G.revealT > 0) G.revealT -= dt;
    for (const bd of beds) {
      if (bd.cd > 0) { bd.cd -= dt; continue; }
      const near = Math.hypot(P.x - bd.x, P.y - bd.y) < 34 && !G.activeBoss && !G.activeShrine;
      if (near && !P.moving) { bd.nap += dt; if (bd.nap >= 1.4) napOn(bd); } else bd.nap = 0;
    }
    for (const l of lamps) {
      if (Math.abs(l.x - P.x) > 700 || Math.abs(l.y - P.y) > 700) continue;
      for (const e of G.enemies) if (!e.dead && (e.x - l.x) ** 2 + (e.y - l.y) ** 2 < 150 * 150) e.lit = 0.2;
    }
    if (CFG.dark) {
      G.flickT -= dt; if (G.flickT < -G.flickGap) { G.flickT = 0.6; G.flickGap = rnd(6, 14); if (Math.random() < 0.4) Sound.sfx.staticNoise(); }
      G.eyesT -= dt;
      if (!G.eyes && G.eyesT <= 0 && !G.activeBoss) {
        G.eyesT = rnd(14, 24); const a = rnd(0, TAU), r = rnd(280, 380);
        G.eyes = { x: P.x + Math.cos(a) * r, y: P.y + Math.sin(a) * r, t: 0, dur: 2.8 }; Sound.sfx.whisper();
      }
      if (G.eyes) { G.eyes.t += dt; if (Math.hypot(G.eyes.x - P.x, G.eyes.y - P.y) < 160) G.eyes.dur = Math.min(G.eyes.dur, G.eyes.t + 0.2); if (G.eyes.t > G.eyes.dur) G.eyes = null; }
      G.glitchT -= dt; if (G.glitchT <= 0) { G.glitchT = rnd(25, 45); G.glitchFx = 0.35; Sound.sfx.staticNoise(); }
      if (G.glitchFx > 0) G.glitchFx -= dt;
    }
    for (const q of clues) {
      if (q.found || Math.hypot(q.x - P.x, q.y - P.y) > 30) continue;
      q.found = true; G.clues5[q.i] = (G.clues5[q.i] || 0) + 1;
      const [ic, txt] = CLUES5[q.i][q.k];
      Sound.sfx.clue(); burst(q.x, q.y, 16, '#ffd25a', 140); floatText(q.x, q.y - 24, `${ic} улика ${G.clues5[q.i]}/3`, '#ffd25a', true);
      say(`${ic} ${txt}`, 4.2);
      if (G.st) G.st.clues = (G.st.clues || 0) + 1;
      if (G.clues5[q.i] >= 3) { const nm = BOSSES[CFG.bosses[q.i]].name; setTimeout(() => { if (state === 'play') showBanner('🔎 Подозреваемый найден!', nm + ' ждёт допроса'); }, 1200); }
      saveGame();
    }
    let nearN = null;
    for (const n of npcs) if (Math.hypot(n.x - P.x, n.y - P.y) < 56) nearN = n;
    G.nearNpc = nearN;
    for (const it of qitems) {
      if (!it.active || it.taken || Math.hypot(it.x - P.x, it.y - P.y) > 30) continue;
      it.taken = true; const def = NPCS5[it.ni];
      Sound.sfx.chest(); burst(it.x, it.y, 16, '#ffd25a', 140);
      showBanner(`${def.item.ic} Нашла: ${def.item.name}!`, `Отнеси – ${def.name} ждёт`);
      saveGame();
    }
    if (G.jump) {
      const J = G.jump; J.t += dt; const k = Math.min(1, J.t / J.dur);
      P.x = lerp(J.sx, J.tx, k); P.y = lerp(J.sy, J.ty, k); P.z = Math.sin(k * Math.PI) * 70; P.inv = Math.max(P.inv, 0.15);
      if (k >= 1) { G.jump = null; P.z = 0; burst(P.x, P.y, 12, '#c8945a', 120); revealFog(P.x, P.y, 12); }
    } else {
      for (const s of shelves) {
        if (s.cd > 0) s.cd -= dt;
        const inside = Math.hypot(s.x - P.x, s.y - P.y) < 22;
        if (inside && !s.inside && s.cd <= 0 && !G.activeBoss) {
          const o = shelves[s.to]; s.cd = o.cd = 1.5; o.inside = true;
          G.jump = { sx: P.x, sy: P.y, tx: o.x, ty: o.y, t: 0, dur: 0.8 };
          Sound.sfx.pounce(); floatText(P.x, P.y - 30, 'прыг!', '#ffd25a');
          if (G.st) G.st.jumps = (G.st.jumps || 0) + 1;
        }
        s.inside = inside;
      }
    }
    if (boxes.length) {
      const bx = !G.activeBoss && !G.activeShrine && !P.moving && boxes.find(o => Math.hypot(o.x - P.x, o.y - P.y) < 20);
      G.hideT = bx ? (G.hideT || 0) + dt : 0;
      const was = G.hidden; G.hidden = G.hideT > 0.25 ? bx : null;
      if (G.hidden && !was) { floatText(P.x, P.y - 30, 'спряталась 📦', '#ffd25a'); Sound.sfx.click(); }
      if (G.hidden) P.hp = Math.min(P.maxHp, P.hp + P.maxHp * 0.03 * dt);
    }
    if (G.pet) {
      const A = G.pet;
      A.x = lerp(A.x, P.x - 26 * P.face, Math.min(1, dt * 5)); A.y = lerp(A.y, P.y - 20, Math.min(1, dt * 5)); A.fireT -= dt;
      if (A.fireT <= 0) {
        const tg = G.hidden ? null : nearestTarget(280);
        if (tg) { A.fireT = 0.7; const a = Math.atan2(tg.y - (tg.z || 0) - A.y, tg.x - A.x); G.feathers.push({ x: A.x, y: A.y, vx: Math.cos(a) * 420, vy: Math.sin(a) * 420, dmg: P.dmg * 0.45, pierce: 0, life: 0.9, hit: [], kind: 'pixel', ally: true }); }
        else A.fireT = 0.25;
      }
    }
    if (G.boardPending && state === 'play' && !Dialog.talking && !G.activeBoss) { G.boardPending = false; openBoard(); }
  }
  // объекты дома на земле
  function drawHouseGround(c, vis) {
    for (const s of shelves) if (vis(s.x, s.y, 40)) {
      c.fillStyle = 'rgba(0,0,0,0.25)'; c.beginPath(); c.ellipse(s.x, s.y + 14, 22, 5, 0, 0, TAU); c.fill();
      c.fillStyle = '#6a4024'; c.fillRect(s.x - 16, s.y + 4, 4, 10); c.fillRect(s.x + 12, s.y + 4, 4, 10);
      c.fillStyle = '#9a6a40'; c.strokeStyle = '#5a3a20'; c.lineWidth = 2; roundRect(c, s.x - 20, s.y - 6, 40, 12, 3); c.fill(); c.stroke();
      if (s.cd <= 0) { c.font = '14px sans-serif'; c.textAlign = 'center'; c.globalAlpha = 0.6 + Math.sin(G.time * 5) * 0.3; c.fillText('🐾', s.x, s.y - 12); c.globalAlpha = 1; }
    }
    for (const bd of beds) if (vis(bd.x, bd.y, 40)) {
      c.fillStyle = 'rgba(0,0,0,0.3)'; c.beginPath(); c.ellipse(bd.x, bd.y + 10, 26, 8, 0, 0, TAU); c.fill();
      c.fillStyle = bd.cd > 0 ? '#7a6a7a' : '#c86a8a'; c.beginPath(); c.ellipse(bd.x, bd.y + 2, 26, 14, 0, 0, TAU); c.fill();
      c.fillStyle = bd.cd > 0 ? '#b0a0b0' : '#ffd0e0'; c.beginPath(); c.ellipse(bd.x, bd.y, 19, 9, 0, 0, TAU); c.fill();
      c.fillStyle = 'rgba(255,255,255,0.4)'; c.beginPath(); c.ellipse(bd.x - 6, bd.y - 3, 7, 3, -0.3, 0, TAU); c.fill();
      if (bd.nap > 0) { c.strokeStyle = '#ffe080'; c.lineWidth = 3; c.beginPath(); c.arc(bd.x, bd.y - 26, 10, -Math.PI / 2, -Math.PI / 2 + TAU * bd.nap / 1.4); c.stroke(); }
      if (bd.cd <= 0) { c.font = 'bold 10px sans-serif'; c.textAlign = 'center'; c.fillStyle = '#ffe0f0'; c.fillText(bd.nap > 0 ? '💤' : 'ЛЕЖАНКА', bd.x, bd.y - 20); }
    }
    for (const l of lamps) if (vis(l.x, l.y, 40)) {
      c.fillStyle = '#5a4a3a'; c.fillRect(l.x - 7, l.y + 4, 14, 4); c.fillRect(l.x - 1.5, l.y - 12, 3, 16);
      c.fillStyle = '#ffd890'; c.beginPath(); c.moveTo(l.x - 10, l.y - 10); c.lineTo(l.x + 10, l.y - 10); c.lineTo(l.x + 6, l.y - 22); c.lineTo(l.x - 6, l.y - 22); c.closePath(); c.fill();
    }
    for (const q of clues) if (!q.found && vis(q.x, q.y, 30)) {
      const bob = Math.sin(G.time * 3 + q.k) * 3;
      c.fillStyle = `rgba(255,220,90,${0.25 + Math.sin(G.time * 4 + q.k) * 0.15})`; c.beginPath(); c.arc(q.x, q.y, 16, 0, TAU); c.fill();
      const spr = emojiSprite(CLUES5[q.i][q.k][0], 18); c.drawImage(spr, q.x - spr.width / 4, q.y - 10 + bob - spr.height / 4, spr.width / 2, spr.height / 2);
      c.fillStyle = '#ffd25a'; star(c, q.x + 10, q.y - 16 + bob, 3, G.time, 4); c.fill();
    }
    for (const it of qitems) if (it.active && !it.taken && vis(it.x, it.y, 30)) {
      const def = NPCS5[it.ni], spr = emojiSprite(def.item.ic, 20), bob = Math.sin(G.time * 3) * 3;
      c.fillStyle = 'rgba(255,255,255,0.3)'; c.beginPath(); c.arc(it.x, it.y, 14, 0, TAU); c.fill();
      c.drawImage(spr, it.x - spr.width / 4, it.y - 8 + bob - spr.height / 4, spr.width / 2, spr.height / 2);
    }
    for (const n of npcs) if (vis(n.x, n.y, 40)) {
      shadow(c, n.x, n.y + 10, 12, 4);
      const spr = emojiSprite(n.def.ic, 26), hop = Math.abs(Math.sin(G.time * 2 + n.ni)) * 3;
      c.drawImage(spr, n.x - spr.width / 4, n.y - 8 - hop - spr.height / 4, spr.width / 2, spr.height / 2);
      c.font = 'bold 10px sans-serif'; c.textAlign = 'center'; c.fillStyle = '#000'; c.fillText(n.def.name, n.x + 1, n.y - 29); c.fillStyle = '#ffffff'; c.fillText(n.def.name, n.x, n.y - 30);
      const it = qitems[n.ni], mark = n.state === 'done' ? '' : it.taken ? '🎁' : n.state === 'new' ? '💬' : '';
      if (mark) { c.font = '14px sans-serif'; c.fillText(mark, n.x + 16, n.y - 22 - Math.abs(Math.sin(G.time * 3)) * 3); }
    }
    for (const bx of boxes) if (vis(bx.x, bx.y, 40) && bx !== G.hidden) drawBox(c, bx, false);
  }
  function drawBox(c, bx, peek) {
    c.fillStyle = 'rgba(0,0,0,0.25)'; c.beginPath(); c.ellipse(bx.x, bx.y + 10, 20, 6, 0, 0, TAU); c.fill();
    if (peek) {
      c.fillStyle = '#5a4034';
      c.beginPath(); c.moveTo(bx.x - 9, bx.y - 11); c.lineTo(bx.x - 6, bx.y - 22); c.lineTo(bx.x - 2, bx.y - 11); c.fill();
      c.beginPath(); c.moveTo(bx.x + 2, bx.y - 11); c.lineTo(bx.x + 6, bx.y - 22); c.lineTo(bx.x + 9, bx.y - 11); c.fill();
    }
    c.fillStyle = '#c8945a'; c.strokeStyle = '#8a6036'; c.lineWidth = 2;
    c.fillRect(bx.x - 16, bx.y - 12, 32, 22); c.strokeRect(bx.x - 16, bx.y - 12, 32, 22);
    c.fillStyle = 'rgba(255,255,255,0.35)'; c.fillRect(bx.x - 3, bx.y - 12, 6, 22);
    if (peek) { c.fillStyle = '#5ab8ff'; c.fillRect(bx.x - 7, bx.y - 9, 3, 2); c.fillRect(bx.x + 4, bx.y - 9, 3, 2); }
    c.fillStyle = '#d8a46a';
    c.beginPath(); c.moveTo(bx.x - 16, bx.y - 12); c.lineTo(bx.x - 24, bx.y - 18); c.lineTo(bx.x - 8, bx.y - 18); c.lineTo(bx.x, bx.y - 12); c.fill();
    c.beginPath(); c.moveTo(bx.x + 16, bx.y - 12); c.lineTo(bx.x + 24, bx.y - 18); c.lineTo(bx.x + 8, bx.y - 18); c.lineTo(bx.x, bx.y - 12); c.fill();
  }
  function drawPet(c) {
    const A = G.pet, y0 = A.y + Math.sin(G.time * 4) * 2;
    c.fillStyle = 'rgba(63,240,160,0.25)'; c.beginPath(); c.arc(A.x, y0, 12, 0, TAU); c.fill();
    const px = (x, y, col) => { c.fillStyle = col; c.fillRect(A.x + x * 2.4, y0 + y * 2.4, 2.4, 2.4); };
    for (const [x, y] of [[-3, -4], [3, -4], [-3, -3], [-2, -3], [-1, -3], [0, -3], [1, -3], [2, -3], [3, -3], [-3, -2], [-2, -2], [0, -2], [2, -2], [3, -2],
      [-3, -1], [-2, -1], [-1, -1], [0, -1], [1, -1], [2, -1], [3, -1], [-2, 0], [-1, 0], [0, 0], [1, 0], [2, 0], [-2, 1], [2, 1]]) px(x, y, '#3ff0a0');
    px(-1, -2, '#0a2a1a'); px(1, -2, '#0a2a1a');
  }
  // темнота главы 4: свет только вокруг Тессы, ламп и лежанок
  let darkCv = null;
  function drawDarkness(c) {
    if (!darkCv) darkCv = makeCanvas(1, 1);
    const w = Math.ceil(VW / 2), h = Math.ceil(VH / 2);
    if (darkCv.width !== w || darkCv.height !== h) { darkCv.width = w; darkCv.height = h; }
    const d = darkCv.getContext('2d');
    d.globalCompositeOperation = 'source-over'; d.clearRect(0, 0, w, h);
    const fl = G.flickT > 0 && Math.random() < 0.5 ? 0.08 : 0;
    d.fillStyle = `rgba(4,3,14,${0.88 + fl})`; d.fillRect(0, 0, w, h);
    d.globalCompositeOperation = 'destination-out';
    const toS = (x, y) => [((x - G.cam.x) * ZOOM + VW / 2) / 2, ((y - G.cam.y) * ZOOM + VH / 2) / 2];
    const hole = (x, y, r, k = 1) => {
      const [sx, sy] = toS(x, y), rr = r * ZOOM / 2;
      if (sx < -rr || sy < -rr || sx > w + rr || sy > h + rr) return;
      const g = d.createRadialGradient(sx, sy, rr * 0.35, sx, sy, rr);
      g.addColorStop(0, `rgba(0,0,0,${k})`); g.addColorStop(1, 'rgba(0,0,0,0)');
      d.fillStyle = g; d.beginPath(); d.arc(sx, sy, rr, 0, TAU); d.fill();
    };
    hole(P.x, P.y, (G.activeBoss ? 340 : 245) * (1 + 0.2 * lv('c4lamp')));
    for (const l of lamps) hole(l.x, l.y, 165, 0.85 + Math.sin(G.time * 7 + l.ph) * 0.05);
    for (const b of beds) hole(b.x, b.y, 150, 0.8);
    const ab = G.activeBoss; if (ab) hole(ab.x, ab.y, 130, 0.65);
    d.globalCompositeOperation = 'source-over';
    c.save(); c.setTransform(DPR, 0, 0, DPR, 0, 0); c.imageSmoothingEnabled = true;
    c.drawImage(darkCv, 0, 0, VW, VH);
    c.globalCompositeOperation = 'lighter';
    for (const l of lamps) {
      const [sx, sy] = toS(l.x, l.y), X = sx * 2, Y = sy * 2, R = 150 * ZOOM;
      if (X < -R || Y < -R || X > VW + R || Y > VH + R) continue;
      const g = c.createRadialGradient(X, Y, 4, X, Y, R); g.addColorStop(0, 'rgba(255,170,80,0.22)'); g.addColorStop(1, 'rgba(255,170,80,0)');
      c.fillStyle = g; c.fillRect(X - R, Y - R, R * 2, R * 2);
    }
    c.globalCompositeOperation = 'source-over';
    for (const e of G.enemies) {
      if (e.dead || e.spawnT > 0) continue;
      const [sx, sy] = toS(e.x, e.y), X = sx * 2, Y = sy * 2;
      if (X < 0 || Y < 0 || X > VW || Y > VH || Math.sin(e.t * 2 + e.seed * 7) > 0.96) continue;
      c.fillStyle = e.type === 'shadowcat' ? '#ffffff' : '#ff3b3b'; c.fillRect(X - 4, Y - 7, 2.5, 2.5); c.fillRect(X + 2, Y - 7, 2.5, 2.5);
    }
    if (G.eyes) {
      const [sx, sy] = toS(G.eyes.x, G.eyes.y), X = sx * 2, Y = sy * 2;
      const a = clamp(G.eyes.t / 0.5, 0, 1) * clamp((G.eyes.dur - G.eyes.t) / 0.4, 0, 1), blinkE = Math.sin(G.eyes.t * 5) > 0.93 ? 0.15 : 1;
      c.globalAlpha = a; c.shadowColor = '#3ff0a0'; c.shadowBlur = 14; c.fillStyle = '#3ff0a0';
      c.beginPath(); c.ellipse(X - 12, Y, 6, 3.5 * blinkE, 0, 0, TAU); c.ellipse(X + 12, Y, 6, 3.5 * blinkE, 0, 0, TAU); c.fill();
      c.shadowBlur = 0; c.fillStyle = '#000'; c.fillRect(X - 13, Y - 3 * blinkE, 2, 6 * blinkE); c.fillRect(X + 11, Y - 3 * blinkE, 2, 6 * blinkE);
      c.globalAlpha = 1;
    }
    c.restore();
  }
  // экранные эффекты: помехи, перевёрнутое управление, глитч
  function drawHouseFx(c) {
    if (G.wxId === 'frost' && G.chill > 0.2) {
      const a = clamp(G.chill / 2.5, 0, 1) * 0.55;
      const g = c.createRadialGradient(VW / 2, VH / 2, Math.min(VW, VH) * 0.28, VW / 2, VH / 2, Math.max(VW, VH) * 0.7);
      g.addColorStop(0, 'rgba(150,210,255,0)'); g.addColorStop(1, `rgba(190,230,255,${a})`); c.fillStyle = g; c.fillRect(0, 0, VW, VH);
      if (G.chill > 0.8) { c.font = '900 15px sans-serif'; c.textAlign = 'center'; c.fillStyle = '#000'; c.fillText('🥶 Замерзаешь! Двигайся', VW / 2 + 1, VH * 0.7 + 1); c.fillStyle = '#d8f2ff'; c.fillText('🥶 Замерзаешь! Двигайся', VW / 2, VH * 0.7); }
    }
    if (G.activeShrine && P.y > PLAY_H * T) {
      const st = ARENA_STYLE[CHN] || ARENA_STYLE[1], a = 0.32 + Math.sin(G.time * 3) * 0.06;
      const g = c.createRadialGradient(VW / 2, VH / 2, Math.min(VW, VH) * 0.3, VW / 2, VH / 2, Math.max(VW, VH) * 0.72);
      g.addColorStop(0, `rgba(${st.tint},0)`); g.addColorStop(1, `rgba(${st.tint},${a})`);
      c.fillStyle = g; c.fillRect(0, 0, VW, VH);
    }
    if (G.staticT > 0) {
      const a = Math.min(1, G.staticT) * 0.35;
      for (let i = 0; i < 160; i++) { const v = Math.random() * 255 | 0; c.fillStyle = `rgba(${v},${v},${v},${a})`; c.fillRect(Math.random() * VW, Math.random() * VH, rnd(6, 30), 2); }
    }
    if (G.invertT > 0) {
      c.fillStyle = `rgba(140,60,255,${0.12 + Math.sin(G.time * 10) * 0.05})`; c.fillRect(0, 0, VW, VH);
      c.font = '900 15px sans-serif'; c.textAlign = 'center'; c.fillStyle = '#e0c8ff'; c.fillText('🔄 управление перевёрнуто', VW / 2, VH * 0.7);
    }
    if (G.glitchFx > 0) {
      c.save(); c.setTransform(1, 0, 0, 1, 0, 0);
      for (let i = 0; i < 6; i++) { const y = Math.random() * canvas.height, hh = rnd(6, 30) * DPR, dx = rnd(-30, 30) * DPR; c.drawImage(canvas, 0, y, canvas.width, hh, dx, y, canvas.width, hh); }
      c.restore();
      c.fillStyle = 'rgba(63,240,160,0.08)'; c.fillRect(0, 0, VW, VH);
    }
    if (G.hidden) { c.font = 'bold 13px sans-serif'; c.textAlign = 'center'; c.fillStyle = '#000'; c.fillText('📦 Тессу не видно · она лечится', VW / 2 + 1, VH * 0.66 + 1); c.fillStyle = '#ffd25a'; c.fillText('📦 Тессу не видно · она лечится', VW / 2, VH * 0.66); }
  }

  // ------------------------------------------------------------------
  //  Глава 6: две героини, скользкий лёд, таяние, костры, метель
  // ------------------------------------------------------------------
  const heroAvatar = id => AVATAR[id === 'ryzhovaya' ? 'ryzhova' : id] || heroPortrait(id);
  const teamOther = () => G.team.list.find(id => id !== P.hero);
  function initTeam(sv) {
    if (!CFG.team) { G.team = null; return; }
    const T6 = G.team = { list: CFG.team.slice(), f: {}, ko: {}, cd: 0, bx: P.x - 34, by: P.y, fireT: 1.5 };
    for (const id of T6.list) {
      T6.f[id] = sv && sv.f && typeof sv.f[id] === 'number' ? clamp(sv.f[id], 0, 1) : 1;
      T6.ko[id] = !!(sv && sv.ko && sv.ko[id]);
    }
    if (T6.ko[P.hero] || T6.f[P.hero] < 0.05) { T6.ko[P.hero] = false; T6.f[P.hero] = Math.max(T6.f[P.hero], 0.35); }
    P.hp = Math.max(1, Math.round(P.maxHp * T6.f[P.hero]));
  }
  function teamSnapshot() {
    if (!G.team) return null;
    const f = Object.assign({}, G.team.f); f[P.hero] = clamp(P.hp / P.maxHp, 0, 1);
    return { f, ko: Object.assign({}, G.team.ko), h: P.hero };
  }
  function switchHero(forced) {
    const T6 = G.team;
    if (!T6 || G.cutscene || (state !== 'play' && !forced)) return false;
    const o = teamOther();
    if (!forced) {
      if (T6.cd > 0 || P.dashT > 0) return false;
      if (T6.ko[o] || T6.f[o] < 0.25) {
        floatText(P.x, P.y - 44, `${HEROES[o].name} ещё отдыхает 💤`, '#bfeaff', true); Sound.sfx.click();
        T6.cd = 0.6; return false;
      }
    }
    T6.f[P.hero] = clamp(P.hp / P.maxHp, 0, 1);
    T6.bx = P.x; T6.by = P.y;
    P.hero = o; computeStats();
    P.hp = Math.max(1, Math.round(P.maxHp * T6.f[o]));
    P.fireT = 0.15; P.inv = Math.max(P.inv, 0.5); T6.cd = 1.2;
    $('dashBtn').querySelector('span').textContent = HEROES[o].dash;
    burst(P.x, P.y, 22, o === 'ryzhovaya' ? '#ff8a2a' : '#7fd8ff', 200); shockRing(P.x, P.y, '#ffffff', 60);
    Sound.sfx.blink();
    if (G.st) G.st.swaps = (G.st.swaps || 0) + 1;
    return true;
  }
  // героиня упала – подруга подхватывает
  function teamCatch() {
    const T6 = G.team; if (!T6) return false;
    const o = teamOther();
    if (T6.ko[o] || T6.f[o] < 0.05) return false;
    const was = P.hero;
    switchHero(true);
    T6.f[was] = 0; T6.ko[was] = true; P.inv = 2;
    showBanner(`${HEROES[P.hero].name} подхватывает!`, `${HEROES[was].name} без сил – отдохнёт у костра`);
    burst(P.x, P.y, 30, '#ffffff', 240); G.shake = 10;
    return true;
  }
  // ---------- лёд Рыжовая растапливает ----------
  function canMelt(i) {
    const tx = i % MW, ty = Math.floor(i / MW);
    return tx >= 2 && ty >= 2 && tx < MW - 2 && ty < PLAY_H - 2 && tiles[i] === ROCK && !!BIOMES[biomeMap[i]].meltable;
  }
  function tryMelt(f) {
    const tx = Math.floor(f.x / T), ty = Math.floor(f.y / T);
    if (!inMap(tx, ty)) return;
    const i = ty * MW + tx;
    if (!canMelt(i)) return;
    const ice = lv('c6ice');
    if (f.ally || (f.kind !== 'fire' && !ice)) { if (Math.random() < 0.3) part(f.x, f.y, rnd(-30, 30), rnd(-40, 0), 0.4, 3, '#e8f8ff'); return; }
    const h = (G.meltHits[i] || 0) + (f.kind === 'fire' ? 1 : 0.5);
    G.meltHits[i] = h;
    burst(f.x, f.y, 8, '#e8f8ff', 100);
    for (let k = 0; k < 3; k++) part(tc(tx) + rnd(-14, 14), tc(ty) + rnd(-10, 10), rnd(-10, 10), rnd(-70, -30), 0.9, 6, 'rgba(235,245,255,0.7)');
    if (h >= Math.max(1, 3 - ice)) meltTile(i, true);
  }
  function meltTile(i, fx) {
    if (!canMelt(i)) return;
    tiles[i] = biomeMap[i]; delete G.meltHits[i];
    if (!G.melted.includes(i)) G.melted.push(i);
    const tx = i % MW, ty = Math.floor(i / MW);
    for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) chunkCache.delete(Math.floor((tx + dx) / CHUNK) + ',' + Math.floor((ty + dy) / CHUNK));
    const mc = miniBase.getContext('2d'); mc.fillStyle = BIOMES[tiles[i]].mini; mc.fillRect(tx, ty, 1, 1);
    if (fx) {
      const x = tc(tx), y = tc(ty);
      burst(x, y, 26, '#ffffff', 190); burst(x, y, 10, '#7fd8ff', 140);
      for (let k = 0; k < 10; k++) part(x + rnd(-18, 18), y + rnd(-14, 14), rnd(-20, 20), rnd(-90, -40), 1.3, 8, 'rgba(235,245,255,0.6)');
      Sound.sfx.glass();
      if ((G.meltSayT || 0) <= 0) { G.meltSayT = 6; floatText(x, y - 20, 'растаяло! 💧', '#bfeaff', true); }
    }
  }
  const ringIntact = ch => { for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) if (Math.max(Math.abs(dx), Math.abs(dy)) === 2 && tileAt(ch.tx + dx, ch.ty + dy) !== ROCK) return false; return true; };
  // огонь сам целится в ледяную стену вокруг сундука, если рядом нет врагов
  function iceTarget() {
    let best = null, bd = (P.range + 20) ** 2;
    for (const ch of chests) {
      if (!ch.iced || ch.open || Math.abs(ch.x - P.x) > 320 || Math.abs(ch.y - P.y) > 320 || !ringIntact(ch)) continue;
      for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) {
        if (Math.max(Math.abs(dx), Math.abs(dy)) !== 2) continue;
        const x = tc(ch.tx + dx), y = tc(ch.ty + dy), d = (x - P.x) ** 2 + (y - P.y) ** 2;
        if (d < bd) { bd = d; best = { x, y, z: 0 }; }
      }
    }
    for (const g of glades) {
      if (g.open || Math.abs(g.x - P.x) > 420 || Math.abs(g.y - P.y) > 420) continue;
      for (const i of g.ring) {
        const x = tc(i % MW), y = tc(Math.floor(i / MW)), d = (x - P.x) ** 2 + (y - P.y) ** 2;
        if (d < bd) { bd = d; best = { x, y, z: 0 }; }
      }
    }
    for (const dr of drifts) {
      if (dr.done) continue;
      const d = (dr.x - P.x) ** 2 + (dr.y - P.y) ** 2;
      if (d < bd) { bd = d; best = { x: dr.x, y: dr.y + 4, z: 0 }; }
    }
    return best;
  }
  // ---------- сугробы: огонь растапливает, внутри сюрприз ----------
  function hitDrift(f) {
    for (const dr of drifts) {
      if (dr.done || Math.abs(dr.x - f.x) > 30 || Math.abs(dr.y - f.y) > 30) continue;
      if ((dr.x - f.x) ** 2 + (dr.y - 4 - f.y) ** 2 > 26 * 26) continue;
      f.life = 0;
      if (f.kind !== 'fire' && !lv('c6ice')) { burst(f.x, f.y, 4, '#ffffff', 80); return true; }
      dr.hp -= f.kind === 'fire' ? 1 : 0.5; burst(dr.x, dr.y, 10, '#ffffff', 120);
      for (let k = 0; k < 3; k++) part(dr.x + rnd(-12, 12), dr.y - 6, rnd(-10, 10), rnd(-70, -30), 0.9, 6, 'rgba(235,245,255,0.7)');
      if (dr.hp <= 0) openDrift(dr);
      return true;
    }
    return false;
  }
  function openDrift(dr) {
    dr.done = true; burst(dr.x, dr.y, 30, '#ffffff', 200); Sound.sfx.glass();
    const r = Math.random(), E = zoneE(biomeMap[dr.ty * MW + dr.tx]);
    if (r < 0.22) {
      floatText(dr.x, dr.y - 30, 'Засада! ⛄', '#ff8a8a', true);
      for (let k = 0; k < 3; k++) { const a = k * TAU / 3, x = dr.x + Math.cos(a) * 40, y = dr.y + Math.sin(a) * 40; if (walkable(x, y, false)) spawnEnemy('snowling', x, y, biomeMap[dr.ty * MW + dr.tx], { elite: k === 0, instant: true }); }
      return;
    }
    if (r < 0.42) dropPickup(dr.x, dr.y, 'heart');
    else if (r < 0.47) dropPickup(dr.x, dr.y, 'key');
    floatText(dr.x, dr.y - 30, 'Сугроб растаял! ✨', '#bfeaff');
    for (let k = 0; k < 3; k++) dropGem(dr.x + rnd(-20, 20), dr.y + rnd(-20, 20), xpFor(E) * 0.08);
    for (let k = 0; k < 2; k++) dropShard(dr.x, dr.y);
  }
  // ---------- погода главы 6: метель, звездопад, мороз ----------
  function startWeather(id) {
    G.wxId = id; G.lastWx = id;
    if (id === 'blizzard') { G.wxT = 10; G.blizzardT = 10; showBanner('❄️ МЕТЕЛЬ', 'Ничего не видно! Грейся у костров'); Sound.sfx.whisper(); }
    else if (id === 'starfall') { G.wxT = 14; G.starT = 0.4; showBanner('🌠 ЗВЕЗДОПАД', 'Лови звёзды – они заряжают супер'); Sound.sfx.magic(); }
    else { G.wxT = 12; G.chill = 0; showBanner('🥶 МОРОЗ', 'Не стой на месте – замёрзнешь!'); Sound.sfx.whisper(); }
  }
  // ---------- Тесса вырывается из ледяной клетки ----------
  function freeTessa() {
    if (G.tessaAlly || CFG.hostage !== 'tessa' || !CFG.team) return;
    const cx = tc(CAGE.x), cy = tc(CAGE.y);
    G.tessaAlly = { x: cx, y: cy, fireT: 1.2, face: 1 };
    burst(cx, cy, 50, '#bfeaff', 300); burst(cx, cy, 24, '#ffffff', 220); Sound.sfx.shatter(); G.shake = 14;
    showBanner('🐾 Тесса вырвалась!', 'Теперь вас трое');
    say('Мяу!!! Лёд треснул – я с вами! Держись, Мрак, сейчас будет КУСЬ! 🐾', 4.5);
    if (loadProfile().ch4Choice === 'kind') { G.pet = { x: cx, y: cy, fireT: 1 }; say('Мяу.exe тоже здесь! Пиксельный котик спешит на помощь! 💚', 4); }
  }
  function updateWinter(dt) {
    if (G.meltSayT > 0) G.meltSayT -= dt;
    const T6 = G.team;
    if (T6) {
      if (T6.cd > 0) T6.cd -= dt;
      const o = teamOther();
      if (T6.f[o] < 1) T6.f[o] = Math.min(1, T6.f[o] + (T6.ko[o] ? 0.006 : 0.02) * (1 + 0.4 * lv('c6duo')) * dt);
      if (T6.ko[o] && T6.f[o] >= 0.25) { T6.ko[o] = false; floatText(P.x, P.y - 44, `${HEROES[o].name} снова в строю!`, '#7dff9a', true); }
      // подруга бежит рядом и подстреливает врагов
      if (Math.hypot(T6.bx - P.x, T6.by - P.y) > 420) { T6.bx = P.x; T6.by = P.y; }
      T6.bx = lerp(T6.bx, P.x - 34 * P.face, Math.min(1, dt * 4)); T6.by = lerp(T6.by, P.y - 6, Math.min(1, dt * 4));
      T6.fireT -= dt;
      if (T6.fireT <= 0) {
        const tg = T6.ko[o] || G.cutscene ? null : nearestTarget(P.range * 0.9);
        if (tg) {
          const H = HEROES[o], a = Math.atan2(tg.y - (tg.z || 0) - T6.by, tg.x - T6.bx);
          T6.fireT = 1.1 / (1 + 0.3 * lv('c6duo'));
          G.feathers.push({ x: T6.bx, y: T6.by - 8, vx: Math.cos(a) * H.projSpd, vy: Math.sin(a) * H.projSpd, dmg: P.dmg * 0.3, pierce: 0, life: 1.0, hit: [], kind: H.proj, ally: true });
        } else T6.fireT = 0.3;
      }
    }
    // костры: греют, лечат обеих и запоминают место
    G.nearFire = null;
    for (const f of fires) {
      if (Math.abs(f.x - P.x) > 120 || Math.abs(f.y - P.y) > 120 || Math.hypot(f.x - P.x, f.y - P.y) > 95) continue;
      G.nearFire = f;
      const warm = 1 + 0.5 * lv('c6warm');
      if (P.hp < P.maxHp) P.hp = Math.min(P.maxHp, P.hp + P.maxHp * 0.05 * warm * dt);
      if (T6) { const o = teamOther(); T6.f[o] = Math.min(1, T6.f[o] + 0.08 * warm * dt); }
      if (!G.activeBoss && !G.activeShrine && (G.cp.x !== f.x || G.cp.y !== f.y + 34)) {
        G.cp = { x: f.x, y: f.y + 34 };
        if (!f.lit) { f.lit = true; floatText(f.x, f.y - 40, '🔥 Костёр: здесь возродишься', '#ffd25a', true); Sound.sfx.magic(); saveGame(); }
      }
    }
    if (CFG.icedChests && !G.iceSaid && P.hero !== 'ryzhovaya') {
      for (const ch of chests) if (ch.iced && !ch.open && Math.hypot(ch.x - P.x, ch.y - P.y) < 210 && ringIntact(ch)) {
        G.iceSaid = true; say('Сундук вмёрз в лёд! Смени героиню 🔄 – огонь Рыжовой растопит стену.', 5); break;
      }
    }
    // погода: накатывает сама по себе, когда нет боя
    if (G.blizzardT > 0) G.blizzardT -= dt;
    if (CFG.weathers) {
      if (G.wxT > 0) { G.wxT -= dt; if (G.wxT <= 0 || G.activeBoss) { if (G.activeBoss && G.wxId === 'blizzard') G.blizzardT = Math.min(G.blizzardT, 0.5); G.wxId = null; G.wxT = 0; } }
      else if (!G.activeBoss && !G.activeShrine && !G.cutscene && P.y < PLAY_H * T) {
        G.blizT -= dt;
        if (G.blizT <= 0) { G.blizT = rnd(55, 85); startWeather(pick(CFG.weathers.filter(w => w !== G.lastWx))); }
      }
      if (G.wxId === 'starfall') {
        G.starT -= dt;
        if (G.starT <= 0) {
          G.starT = 0.55;
          for (let k = 0; k < 6; k++) {
            const a = rnd(0, TAU), r = rnd(40, 330), x = P.x + Math.cos(a) * r, y = P.y + Math.sin(a) * r;
            if (walkable(x, y, false)) { G.falling.push({ x, y, t: 0, dur: 1.1 }); break; }
          }
        }
      }
      if (G.wxId === 'frost') {
        const warmNear = !!G.nearFire;
        if (warmNear) G.chill = Math.max(0, G.chill - dt * 3);
        else if (!P.moving && P.dashT <= 0) G.chill += dt; else G.chill = Math.max(0, G.chill - dt * 1.5);
        if (G.chill > 1.2) {
          G.frostTick = (G.frostTick || 0) - dt; P.slowT = Math.max(P.slowT, 0.3);
          if (G.frostTick <= 0) {
            G.frostTick = 0.5;
            const d = P.maxHp * 0.025 * (lv('c6warm') ? 0.5 : 1);
            P.hp = Math.max(1, P.hp - d); dmgText(P.x, P.y - 30, d, '#9ad8ff');
            if (Math.random() < 0.3) floatText(P.x, P.y - 50, '🥶 двигайся!', '#bfeaff');
          }
        }
      } else G.chill = 0;
    }
    for (const st of G.falling) {
      st.t += dt;
      if (st.t >= st.dur && !st.done) {
        st.done = true; dropPickup(st.x, st.y, 'star'); burst(st.x, st.y, 14, '#ffe08a', 160);
        for (const e of G.enemies) if (!e.dead && (e.x - st.x) ** 2 + (e.y - st.y) ** 2 < 50 * 50) damageEnemy(e, rollHit(P.dmg * 2), 0, 0, false);
      }
    }
    G.falling = G.falling.filter(st => !st.done);
    if (G.cookieT > 0) G.cookieT -= dt;
    // пещеры: темнота, пока героиня внутри
    if (CFG.slides) {
      const pb = P.y < PLAY_H * T ? biomeMap[clamp(Math.floor(P.y / T), 0, MH - 1) * MW + clamp(Math.floor(P.x / T), 0, MW - 1)] : -1;
      G.caveA = lerp(G.caveA || 0, pb >= 0 && BIOMES[pb].cave ? 1 : 0, Math.min(1, dt * 1.8));
      if (pb >= 0 && BIOMES[pb].cave && !G.caveSaid) { G.caveSaid = true; say('Тут темно! Огонь Рыжовой светит ярче перьев – смени героиню 🔥', 4.5); }
    }
    // тайные поляны: стена растаяла – поляна открыта
    for (const g of glades) {
      if (!g.seen && Math.abs(g.x - P.x) < 420 && Math.abs(g.y - P.y) < 420) g.seen = true;
      if (!g.open && g.ring.some(i => tiles[i] !== ROCK)) { g.open = true; floatText(g.x, g.y - 40, '✨ Тайная поляна!', '#ffe08a', true); Sound.sfx.magic(); }
      if (g.open && !g.done && g.kind === 'beast' && Math.hypot(g.x - P.x, g.y - P.y) < 260) {
        g.done = true;
        const e = spawnEnemy('snowleopard', g.x, g.y, biomeMap[g.ty * MW + g.tx], { elite: true, instant: true });
        e.gladeBeast = true; showBanner('🐆 Снежный барс!', 'Хозяин поляны охраняет добычу'); Sound.sfx.roar();
      }
    }
    // проруби: постой рядом – клюёт!
    G.fishing = null;
    for (const hl of holes) {
      if (hl.cd > 0) { hl.cd -= dt; continue; }
      const near = Math.hypot(P.x - hl.x, P.y - hl.y) < 48 && !G.activeBoss && !G.activeShrine && !P.moving;
      if (!near) { hl.prog = 0; continue; }
      G.fishing = hl; hl.prog += dt;
      if (hl.prog >= 1.6) {
        hl.prog = 0; hl.cd = 40;
        const r = Math.random();
        burst(hl.x, hl.y, 16, '#9ad8ff', 160); Sound.sfx.clue();
        if (r < 0.38) {
          const hp = Math.round(P.maxHp * 0.2); P.hp = Math.min(P.maxHp, P.hp + hp);
          if (T6) { const o = teamOther(); T6.f[o] = Math.min(1, T6.f[o] + 0.2); }
          floatText(hl.x, hl.y - 30, `🐟 Рыбка! +${hp}`, '#7dff7d', true);
        } else if (r < 0.58) { floatText(hl.x, hl.y - 30, '💎 Осколки со дна!', '#c77dff', true); for (let k = 0; k < 3; k++) dropShard(hl.x, hl.y + 20); }
        else if (r < 0.64) { floatText(hl.x, hl.y - 30, '🔑 Ключ на крючке!', '#ffd25a', true); dropPickup(hl.x, hl.y + 24, 'key'); }
        else if (r < 0.8) {
          floatText(hl.x, hl.y - 30, '😱 Щука-мимик!', '#ff8a8a', true);
          const e = spawnEnemy('pike', hl.x + 30, hl.y + 10, biomeMap[hl.ty * MW + hl.tx], { elite: true, instant: true }); e.pikeLoot = true; Sound.sfx.roar();
        } else { floatText(hl.x, hl.y - 30, '👢 Старый сапог… ну хоть опыт', '#c8c8c8', true); dropGem(hl.x, hl.y + 20, xpFor(zoneE(biomeMap[hl.ty * MW + hl.tx])) * 0.15); }
      }
    }
    // пряничная печка: печенька +25% урона на минуту
    G.baking = null;
    for (const ov of ovens) {
      if (ov.cd > 0) { ov.cd -= dt; continue; }
      const near = Math.hypot(P.x - ov.x, P.y - (ov.y + 20)) < 64 && !G.activeBoss && !P.moving;
      if (!near) { ov.prog = 0; continue; }
      G.baking = ov; ov.prog += dt;
      if (ov.prog >= 2) {
        ov.prog = 0; ov.cd = 90; G.cookieT = 60;
        floatText(ov.x, ov.y - 50, '🍪 Печенька! +25% урона на минуту', '#ffd25a', true); Sound.sfx.magic(); burst(ov.x, ov.y - 10, 20, '#ffd25a', 160);
      }
    }
    G.blizA = lerp(G.blizA || 0, G.blizzardT > 0 ? 1 : 0, Math.min(1, dt * 1.6));
    if (G.tessaAlly) {
      const A = G.tessaAlly;
      A.x = lerp(A.x, P.x + 36 * P.face, Math.min(1, dt * 3)); A.y = lerp(A.y, P.y + 6, Math.min(1, dt * 3));
      A.fireT -= dt;
      if (A.fireT <= 0) {
        const tg = nearestTarget(300);
        if (tg) {
          A.fireT = 0.6; const a = Math.atan2(tg.y - (tg.z || 0) - A.y, tg.x - A.x); A.face = Math.cos(a) >= 0 ? 1 : -1;
          G.feathers.push({ x: A.x, y: A.y - 8, vx: Math.cos(a) * 450, vy: Math.sin(a) * 450, dmg: P.dmg * 0.45, pierce: 1, life: 0.9, hit: [], kind: 'claw', ally: true });
        } else A.fireT = 0.25;
      }
    }
  }
  function drawCampfire(c, f, t) {
    const x = f.x, y = f.y;
    const g = c.createRadialGradient(x, y, 4, x, y, 90);
    g.addColorStop(0, 'rgba(255,170,60,0.32)'); g.addColorStop(1, 'rgba(255,170,60,0)');
    c.fillStyle = g; c.beginPath(); c.arc(x, y, 90, 0, TAU); c.fill();
    shadow(c, x, y + 10, 18, 5);
    c.fillStyle = '#8a8a9a'; for (let k = 0; k < 7; k++) { const a = k * TAU / 7; c.beginPath(); c.arc(x + Math.cos(a) * 15, y + 6 + Math.sin(a) * 6, 4, 0, TAU); c.fill(); }
    c.save(); c.translate(x, y + 4);
    c.fillStyle = '#6a3a1a'; c.strokeStyle = '#3a1a0a'; c.lineWidth = 1.5;
    for (const r of [0.5, -0.5]) { c.save(); c.rotate(r); c.fillRect(-14, -3, 28, 6); c.strokeRect(-14, -3, 28, 6); c.restore(); }
    c.restore();
    const fl = Math.sin(t * 13 + f.ph) * 2, fl2 = Math.sin(t * 17 + f.ph * 2) * 2;
    const flame = (w, h, col, dx) => { c.fillStyle = col; c.beginPath(); c.moveTo(x - w + dx, y + 2); c.quadraticCurveTo(x - w * 0.8 + dx, y - h * 0.5, x + dx + fl * 0.6, y - h); c.quadraticCurveTo(x + w * 0.8 + dx, y - h * 0.5, x + w + dx, y + 2); c.closePath(); c.fill(); };
    flame(11, 30 + fl, '#ff6a1f', 0); flame(8, 22 + fl2, '#ffb03a', 1); flame(4, 13 + fl, '#fff3b0', 0);
    if (Math.random() < 0.15) part(x + rnd(-6, 6), y - 18, rnd(-15, 15), rnd(-70, -40), 0.9, 3, '#ffd25a');
    if (f.lit) { c.fillStyle = '#ffd25a'; c.font = 'bold 11px sans-serif'; c.textAlign = 'center'; c.fillText('✓', x + 20, y - 18); }
  }
  function drawIceCage(c, x, y, t) {
    shadow(c, x, y + 30, 36, 9);
    drawHero('tessa', c, x, y + 14 + Math.sin(t * 2) * 2, t, 1, 1, 0.9, false);
    c.fillStyle = 'rgba(170,220,255,0.42)'; c.strokeStyle = 'rgba(255,255,255,0.85)'; c.lineWidth = 2;
    c.beginPath(); c.moveTo(x - 30, y + 30); c.lineTo(x - 36, y - 10); c.lineTo(x - 18, y - 48); c.lineTo(x + 4, y - 56); c.lineTo(x + 26, y - 40); c.lineTo(x + 36, y - 4); c.lineTo(x + 30, y + 30); c.closePath(); c.fill(); c.stroke();
    c.fillStyle = 'rgba(255,255,255,0.4)'; c.beginPath(); c.moveTo(x - 24, y + 20); c.lineTo(x - 28, y - 8); c.lineTo(x - 16, y - 38); c.lineTo(x - 12, y - 30); c.lineTo(x - 18, y + 20); c.closePath(); c.fill();
    if (Math.random() < 0.08) { c.fillStyle = '#ffffff'; star(c, x + rnd(-30, 30), y + rnd(-50, 20), 3, t, 4); c.fill(); }
  }
  function drawHole(c, hl, t) {
    c.fillStyle = 'rgba(214,240,255,0.95)'; c.beginPath(); c.ellipse(hl.x, hl.y + 4, 32, 15, 0, 0, TAU); c.fill();
    c.fillStyle = '#1b4a6a'; c.beginPath(); c.ellipse(hl.x, hl.y + 4, 21, 9, 0, 0, TAU); c.fill();
    c.strokeStyle = 'rgba(255,255,255,0.85)'; c.lineWidth = 2; c.stroke();
    if (hl.cd <= 0) { const k = (t * 0.8 + hl.x * 0.01) % 1; c.strokeStyle = `rgba(190,234,255,${1 - k})`; c.lineWidth = 1.5; c.beginPath(); c.ellipse(hl.x, hl.y + 4, 5 + k * 13, 2 + k * 5, 0, 0, TAU); c.stroke(); }
    else { c.fillStyle = 'rgba(255,255,255,0.5)'; c.beginPath(); c.ellipse(hl.x, hl.y + 4, 21 * (1 - hl.cd / 40), 9 * (1 - hl.cd / 40), 0, 0, TAU); c.fill(); }
    if (G.fishing === hl) {
      c.strokeStyle = '#8a5a2a'; c.lineWidth = 3; c.beginPath(); c.moveTo(P.x + 8 * P.face, P.y - 12); c.lineTo(hl.x + 6, hl.y - 36); c.stroke();
      c.strokeStyle = '#ffffff'; c.lineWidth = 1; c.beginPath(); c.moveTo(hl.x + 6, hl.y - 36); c.lineTo(hl.x, hl.y + 4 + Math.sin(t * 22) * 2); c.stroke();
      c.strokeStyle = '#ffd25a'; c.lineWidth = 4; c.beginPath(); c.arc(hl.x, hl.y - 52, 12, -Math.PI / 2, -Math.PI / 2 + TAU * hl.prog / 1.6); c.stroke();
    }
    if (hl.cd <= 0 && G.fishing !== hl && Math.hypot(P.x - hl.x, P.y - hl.y) < 160) { c.font = '14px sans-serif'; c.textAlign = 'center'; c.fillText('🎣', hl.x, hl.y - 22 + Math.sin(t * 3) * 3); }
  }
  function drawOven(c, ov, t) {
    const x = ov.x, y = ov.y;
    shadow(c, x, y + 24, 32, 8);
    c.fillStyle = '#b06a3a'; c.strokeStyle = '#6a3a1a'; c.lineWidth = 2.5;
    c.beginPath(); c.moveTo(x - 30, y + 22); c.lineTo(x - 30, y - 4); c.quadraticCurveTo(x, y - 48, x + 30, y - 4); c.lineTo(x + 30, y + 22); c.closePath(); c.fill(); c.stroke();
    c.strokeStyle = 'rgba(0,0,0,0.18)'; c.lineWidth = 1.5; for (let k = 0; k < 3; k++) { c.beginPath(); c.moveTo(x - 29, y + 14 - k * 9); c.lineTo(x + 29, y + 14 - k * 9); c.stroke(); }
    c.strokeStyle = '#ffffff'; c.lineWidth = 3; c.beginPath(); for (let k = 0; k < 5; k++) { const a = Math.PI + (k + 0.5) * Math.PI / 5; c.moveTo(x + Math.cos(a) * 26, y - 4 + Math.sin(a) * 34); c.quadraticCurveTo(x + Math.cos(a + 0.2) * 22, y + 2 + Math.sin(a + 0.2) * 30, x + Math.cos(a + 0.4) * 26, y - 4 + Math.sin(a + 0.4) * 34); } c.stroke();
    c.fillStyle = '#7a4a2a'; c.fillRect(x + 12, y - 40, 9, 16);
    const ready = ov.cd <= 0, glow = ready ? 0.7 + Math.sin(t * 6 + ov.ph) * 0.2 : 0.15;
    c.fillStyle = `rgba(255,${ready ? 150 : 60},40,${glow})`; c.beginPath(); c.moveTo(x - 12, y + 22); c.lineTo(x - 12, y + 8); c.quadraticCurveTo(x, y - 6, x + 12, y + 8); c.lineTo(x + 12, y + 22); c.closePath(); c.fill();
    if (ready && Math.random() < 0.06) part(x + 16, y - 42, rnd(-6, 6), -40, 1.4, 7, 'rgba(230,230,230,0.6)');
    for (const [dx, dy, col] of [[-20, 10, '#e53935'], [20, 10, '#43a047'], [0, -20, '#ff6fb5']]) { c.fillStyle = col; c.beginPath(); c.arc(x + dx, y + dy, 2.5, 0, TAU); c.fill(); }
    if (G.baking === ov) { c.strokeStyle = '#ffd25a'; c.lineWidth = 4; c.beginPath(); c.arc(x, y - 62, 12, -Math.PI / 2, -Math.PI / 2 + TAU * ov.prog / 2); c.stroke(); c.font = '13px sans-serif'; c.textAlign = 'center'; c.fillText('🍪', x, y - 57); }
    else if (ready && Math.hypot(P.x - x, P.y - y) < 200) { c.font = '15px sans-serif'; c.textAlign = 'center'; c.fillText('🍪', x, y - 56 + Math.sin(t * 3) * 3); }
  }
  function drawDrift(c, dr, t) {
    const k = (0.55 + 0.45 * dr.hp / 3) * dr.s, x = dr.x, y = dr.y;
    shadow(c, x, y + 8, 24 * k, 6 * k);
    c.fillStyle = '#d8e8f6'; c.beginPath(); c.ellipse(x, y + 4, 26 * k, 12 * k, 0, Math.PI, TAU); c.fill();
    c.fillStyle = '#f4faff'; c.beginPath(); c.ellipse(x - 6 * k, y + 2, 18 * k, 14 * k, 0, Math.PI, TAU); c.fill(); c.beginPath(); c.ellipse(x + 9 * k, y + 3, 14 * k, 10 * k, 0, Math.PI, TAU); c.fill();
    c.fillStyle = '#d8e8f6'; c.fillRect(x - 26 * k, y + 3, 52 * k, 3);
    if (Math.sin(t * 3 + x) > 0.9) { c.fillStyle = '#ffffff'; star(c, x + rnd(-14, 14) * k, y - 6 * k, 2.5, t, 4); c.fill(); }
  }
  // пещеры: темно, светят кристаллы, костры и огонь Рыжовой
  let caveCv = null;
  function drawCaveDark(c) {
    const A = G.caveA || 0;
    if (A < 0.02 || state === 'menu') return;
    if (!caveCv) caveCv = makeCanvas(1, 1);
    const w = Math.ceil(VW / 2), h = Math.ceil(VH / 2);
    if (caveCv.width !== w || caveCv.height !== h) { caveCv.width = w; caveCv.height = h; }
    const d = caveCv.getContext('2d');
    d.globalCompositeOperation = 'source-over'; d.clearRect(0, 0, w, h);
    d.fillStyle = `rgba(6,4,18,${0.86 * A})`; d.fillRect(0, 0, w, h);
    d.globalCompositeOperation = 'destination-out';
    const toS = (x, y) => [((x - G.cam.x) * ZOOM + VW / 2) / 2, ((y - G.cam.y) * ZOOM + VH / 2) / 2];
    const lights = [];
    const hole = (x, y, r, k) => {
      const [sx, sy] = toS(x, y), rr = r * ZOOM / 2;
      if (sx < -rr || sy < -rr || sx > w + rr || sy > h + rr) return false;
      const g = d.createRadialGradient(sx, sy, rr * 0.3, sx, sy, rr);
      g.addColorStop(0, `rgba(0,0,0,${k})`); g.addColorStop(1, 'rgba(0,0,0,0)');
      d.fillStyle = g; d.beginPath(); d.arc(sx, sy, rr, 0, TAU); d.fill();
      return true;
    };
    hole(P.x, P.y, P.proj === 'fire' ? 310 : 200, 0.95);
    if (G.team) hole(G.team.bx, G.team.by, G.team.list.find(id => id !== P.hero) === 'ryzhovaya' ? 140 : 70, 0.7);
    for (const f of fires) hole(f.x, f.y, 180, 0.95);
    for (const f of G.feathers) if (f.kind === 'fire') hole(f.x, f.y, 70, 0.6);
    const vw = VW / ZOOM, vh = VH / ZOOM, tx0 = Math.max(0, Math.floor((G.cam.x - vw / 2) / T) - 2), tx1 = Math.min(MW - 1, Math.floor((G.cam.x + vw / 2) / T) + 2);
    const ty0 = Math.max(0, Math.floor((G.cam.y - vh / 2) / T) - 2), ty1 = Math.min(MH - 1, Math.floor((G.cam.y + vh / 2) / T) + 3);
    for (let ty = ty0; ty <= ty1; ty++) for (let tx = tx0; tx <= tx1; tx++) {
      const ti = treeGrid[ty * MW + tx]; if (!ti) continue;
      const tr = trees[ti - 1]; if (tr.kind !== 'crystal') continue;
      if (hole(tr.x, tr.y - 20, 130, 0.75 + Math.sin(G.time * 2 + tr.x) * 0.1)) lights.push(tr);
    }
    d.globalCompositeOperation = 'source-over';
    c.save(); c.setTransform(DPR, 0, 0, DPR, 0, 0); c.imageSmoothingEnabled = true;
    c.drawImage(caveCv, 0, 0, VW, VH);
    c.globalCompositeOperation = 'lighter';
    for (const tr of lights) {
      const [sx, sy] = toS(tr.x, tr.y - 20), X = sx * 2, Y = sy * 2, R = 110 * ZOOM;
      const g = c.createRadialGradient(X, Y, 4, X, Y, R); g.addColorStop(0, `rgba(150,110,255,${0.22 * A})`); g.addColorStop(1, 'rgba(150,110,255,0)');
      c.fillStyle = g; c.fillRect(X - R, Y - R, R * 2, R * 2);
    }
    c.globalCompositeOperation = 'source-over';
    for (const e of G.enemies) {
      if (e.dead || e.spawnT > 0) continue;
      const [sx, sy] = toS(e.x, e.y), X = sx * 2, Y = sy * 2;
      if (X < 0 || Y < 0 || X > VW || Y > VH || Math.sin(e.t * 2 + e.seed * 7) > 0.96) continue;
      c.globalAlpha = A; c.fillStyle = '#ff5bf0'; c.fillRect(X - 4, Y - 7, 2.5, 2.5); c.fillRect(X + 2, Y - 7, 2.5, 2.5);
    }
    c.globalAlpha = 1;
    c.restore();
    if (G.caveA > 0.5) for (const hz of G.hazards) drawHazard(c, hz);
  }
  let snowCv = null;
  function drawBlizzard(c) {
    const A = G.blizA || 0;
    if (A < 0.02) return;
    if (!snowCv) snowCv = makeCanvas(1, 1);
    const w = Math.ceil(VW / 2), h = Math.ceil(VH / 2);
    if (snowCv.width !== w || snowCv.height !== h) { snowCv.width = w; snowCv.height = h; }
    const d = snowCv.getContext('2d');
    d.globalCompositeOperation = 'source-over'; d.clearRect(0, 0, w, h);
    d.fillStyle = `rgba(232,242,252,${0.68 * A})`; d.fillRect(0, 0, w, h);
    d.globalCompositeOperation = 'destination-out';
    const toS = (x, y) => [((x - G.cam.x) * ZOOM + VW / 2) / 2, ((y - G.cam.y) * ZOOM + VH / 2) / 2];
    const hole = (x, y, r, k) => {
      const [sx, sy] = toS(x, y), rr = r * ZOOM / 2;
      if (sx < -rr || sy < -rr || sx > w + rr || sy > h + rr) return;
      const g = d.createRadialGradient(sx, sy, rr * 0.3, sx, sy, rr);
      g.addColorStop(0, `rgba(0,0,0,${k})`); g.addColorStop(1, 'rgba(0,0,0,0)');
      d.fillStyle = g; d.beginPath(); d.arc(sx, sy, rr, 0, TAU); d.fill();
    };
    hole(P.x, P.y, G.activeBoss ? 300 : 200, 0.92);
    for (const f of fires) hole(f.x, f.y, 170, 0.95);
    d.globalCompositeOperation = 'source-over';
    c.save(); c.setTransform(DPR, 0, 0, DPR, 0, 0); c.imageSmoothingEnabled = true;
    c.drawImage(snowCv, 0, 0, VW, VH);
    c.strokeStyle = `rgba(255,255,255,${0.75 * A})`; c.lineWidth = 2; c.beginPath();
    const tt = G.time;
    for (let k = 0; k < 90; k++) {
      const sx = ((hash2(k, 3) * VW * 1.4 + tt * (420 + hash2(k, 9) * 260)) % (VW * 1.4)) - VW * 0.2;
      const sy = ((hash2(k, 7) * VH + tt * (140 + hash2(k, 5) * 120)) % VH);
      c.moveTo(sx, sy); c.lineTo(sx - 16, sy - 6);
    }
    c.stroke();
    c.restore();
  }

  // ------------------------------------------------------------------
  //  Финал главы 4: хорошая или добрая?
  // ------------------------------------------------------------------
  function openChoice(fromMenu) { G.choiceFromMenu = !!fromMenu; setState('choice'); Sound.music('night4'); }
  function finishCh4(ch) {
    const prof = loadProfile(); prof.ch4Choice = ch; saveProfile(prof);
    unlockOutfit('bow');
    // игру закрыли на экране выбора – спрашиваем ещё раз из меню, без экрана победы
    if (G.choiceFromMenu) { G.choiceFromMenu = false; openMenu(); toast(ch === 'kind' ? '💗 Добрая кошка. Мяу.exe приручён' : '🛡️ Хорошая кошка. Дом спасён'); return; }
    if (ch === 'kind') Sound.sfx.purr(); else Sound.sfx.win();
    showVictory(ch);
  }
  // ------------------------------------------------------------------
  //  Глава 5: доска подозреваемых
  // ------------------------------------------------------------------
  function openBoard() {
    setState('board'); G.accused = false;
    const list = $('boardClues'); list.innerHTML = '';
    for (const q of clues) if (q.found) { const [ic, txt] = CLUES5[q.i][q.k]; const el = document.createElement('div'); el.className = 'bclue'; el.textContent = `${ic} ${txt}`; list.appendChild(el); }
    const sus = $('boardSus'); sus.innerHTML = '';
    for (const s of SUSPECTS) {
      const el = document.createElement('button'); el.className = 'bsus'; el.innerHTML = `<span>${s.ic}</span>${s.name}`;
      el.addEventListener('click', () => { Sound.sfx.click(); accuse(s); }); sus.appendChild(el);
    }
    $('boardResult').innerHTML = ''; $('boardGo').classList.add('hidden');
    Sound.sfx.magic();
  }
  function accuse(s) {
    if (G.accused) return; G.accused = true;
    const ok = s.id === 'zyama', prof = loadProfile(); prof.ch5Accuse = s.id; saveProfile(prof);
    G.boardPending = false; saveGame();
    const wrong = { baron: 'Барон обиженно гавкнул.', cucumber: 'Огурец покраснел. Насколько огурцы умеют.', laserdot: 'Точка смущённо замигала.', pigeonboss: 'Голубь поправил шляпу: «Курлык, не мы».' };
    $('boardResult').innerHTML = ok ? '🎯 Точно! Блёстки, какао, ода и программка «Режиссёр – З.»… Это <b>Зямочкккк</b>!<br>Награда: улучшение, осколки и очки детектива 👓'
      : `🤔 ${s.name}? ${wrong[s.id] || ''}<br>Но все улики всё равно ведут в кладовую…`;
    for (const el of document.querySelectorAll('.bsus')) el.disabled = true;
    if (ok) { Sound.sfx.win(); for (let i = 0; i < 8; i++) dropShard(P.x + rnd(-40, 40), P.y + rnd(-40, 40)); G.pendingLv++; unlockOutfit('glasses'); } else Sound.sfx.hurt();
    $('boardGo').classList.remove('hidden');
  }
  // ------------------------------------------------------------------
  //  Глава 5: разговоры с жителями
  // ------------------------------------------------------------------
  function npcButtons(list) {
    const box = $('npcChoices'); box.innerHTML = '';
    for (const [label, fn] of list) { const el = document.createElement('button'); el.className = 'btn alt'; el.textContent = label; el.addEventListener('click', () => { Sound.sfx.click(); fn(); }); box.appendChild(el); }
  }
  function openNpc(n) {
    if (!n) return;
    G.talkN = n; setState('npc');
    $('npcIc').textContent = n.def.ic; $('npcName').textContent = n.def.name;
    npcPage(n.state === 'done' ? 'Спасибо ещё раз, Тесса! Заходи в гости. 💛' : n.def.greet);
  }
  function npcPage(text) {
    const n = G.talkN, it = qitems[n.ni], def = n.def;
    $('npcText').textContent = text;
    const opts = [];
    if (it.taken && n.state !== 'done') opts.push([`🎁 Вот: ${def.item.ic} ${def.item.name}!`, () => { n.state = 'done'; npcReward(n); npcPage(def.thanks); }]);
    opts.push(['🔎 Кто взял корм?', () => { G.revealT = 120; npcPage(def.hint + '\n\n(Ближайшие улики теперь мигают на мини-карте)'); }]);
    if (n.state === 'new') opts.push(['🤝 Тебе нужна помощь?', () => npcQuest(n)]);
    opts.push(['😽 Потереться носом', () => { P.hp = Math.min(P.maxHp, P.hp + P.maxHp * 0.15); Sound.sfx.purr(); npcPage(def.pet); }]);
    opts.push(['👋 Пока!', () => setState('play')]);
    npcButtons(opts);
  }
  function npcQuest(n) {
    const def = n.def;
    $('npcText').textContent = def.quest;
    npcButtons([
      ['Найду! 🐾', () => { n.state = 'quest'; qitems[n.ni].active = true; setState('play'); showBanner(`${def.item.ic} Поручение`, `Найди: ${def.item.name} – отмечено на мини-карте`); saveGame(); }],
      ['Потом', () => npcPage(def.greet)],
    ]);
  }
  function npcReward(n) {
    Sound.sfx.chest();
    for (let i = 0; i < 6; i++) dropShard(P.x + rnd(-40, 40), P.y + rnd(-40, 40));
    dropPickup(P.x, P.y + 40, 'heart'); addSuper(25);
    unlockOutfit('bell');
    if (G.st) G.st.quests = (G.st.quests || 0) + 1;
    saveGame();
  }
  // ------------------------------------------------------------------
  //  Гардероб Тессы
  // ------------------------------------------------------------------
  function unlockOutfit(id) {
    const prof = loadProfile(); prof.wardrobe = prof.wardrobe || { own: {}, on: 'none' };
    if (prof.wardrobe.own[id]) return;
    prof.wardrobe.own[id] = 1;
    if (!prof.wardrobe.on || prof.wardrobe.on === 'none') { prof.wardrobe.on = id; TESSA_OUTFIT = id; }
    saveProfile(prof);
    const w = WARDROBE.find(x => x.id === id);
    if (w) toast(`🎀 Новый наряд для Тессы: ${w.ic} ${w.name}!`);
  }
  let wardBack = 'menu';
  function openWardrobe() { wardBack = state === 'wardrobe' ? wardBack : state; setState('wardrobe'); renderWardrobe(); }
  function renderWardrobe() {
    const prof = loadProfile(), wd = prof.wardrobe || { own: {}, on: 'none' };
    const box = $('wardList'); box.innerHTML = '';
    for (const w of WARDROBE) {
      const own = w.id === 'none' || DEBUG || wd.own[w.id], on = (wd.on || 'none') === w.id;
      const el = document.createElement('button'); el.className = 'ward' + (on ? ' on' : '') + (own ? '' : ' lock');
      el.innerHTML = `<span>${own ? w.ic : '🔒'}</span><b>${w.name}</b><i>${own ? (on ? 'надето' : 'надеть') : w.how}</i>`;
      el.addEventListener('click', () => {
        Sound.sfx.click();
        if (!own) { toast('🔒 ' + w.how); return; }
        const p2 = loadProfile(); p2.wardrobe = p2.wardrobe || { own: {}, on: 'none' }; p2.wardrobe.on = w.id; saveProfile(p2);
        TESSA_OUTFIT = w.id; renderWardrobe();
      });
      box.appendChild(el);
    }
    const cv = $('wardPreview'), c2 = cv.getContext('2d'); c2.clearRect(0, 0, 200, 200);
    const g = c2.createRadialGradient(100, 100, 10, 100, 100, 100); g.addColorStop(0, '#3a5a9a'); g.addColorStop(1, '#0a1428');
    c2.fillStyle = g; c2.beginPath(); c2.arc(100, 100, 98, 0, TAU); c2.fill();
    drawTessa(c2, 92, 140, 0.4, 1, 4.6, 1, false);
  }


  // ------------------------------------------------------------------
  //  Большая карта (нажми на мини-карту)
  // ------------------------------------------------------------------
  function openMap() {
    setState('mapscr'); Sound.sfx.click();
    const cv = $('mapCanvas'), d = Math.min(window.devicePixelRatio || 1, 2);
    const S = Math.max(160, Math.floor(Math.min(VW - 24, VH - 240)));
    cv.style.width = S + 'px'; cv.style.height = S + 'px'; cv.width = Math.round(S * d); cv.height = Math.round(S * d);
    const c = cv.getContext('2d'); c.setTransform(d, 0, 0, d, 0, 0);
    c.imageSmoothingEnabled = false; c.drawImage(miniBase, 0, 0, S, S);
    c.globalAlpha = 0.85; c.drawImage(fog, 0, 0, S, S); c.globalAlpha = 1; c.imageSmoothingEnabled = true;
    const k = S / WORLD_W;
    const icon = (ch, x, y, sz = 14) => { c.font = sz + 'px sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(ch, x * k, y * k); };
    for (const ch of chests) if (!ch.open && (ch.seen || (hasRelic('compass') && Math.hypot(ch.x - P.x, ch.y - P.y) < 1000))) { c.fillStyle = ch.tier === 'gold' ? '#ffd25a' : ch.tier === 'silver' ? '#e0eaff' : '#c8945a'; c.fillRect(ch.x * k - 2.5, ch.y * k - 2.5, 5, 5); }
    for (const s of shrines) icon(s.state === 'done' ? '🌀' : '⛩', s.x, s.y, 13);
    for (const bd of beds) icon('🛏', bd.x, bd.y, 11);
    for (const f of fires) if (!f.glade) icon('🔥', f.x, f.y, 12);
    for (const hl of holes) icon('🎣', hl.x, hl.y, 12);
    for (const ov of ovens) icon('🍪', ov.x, ov.y, 12);
    for (const g of glades) if (g.seen) icon(g.open ? '🌲' : '✨', g.x, g.y, 13);
    for (const n of npcs) icon(n.def.ic, n.x, n.y, 13);
    for (const q of clues) if (!q.found && (G.clearSight || G.revealT > 0 || (G.pet && Math.hypot(q.x - P.x, q.y - P.y) < 700) || Math.hypot(q.x - P.x, q.y - P.y) < 350 * lv('c5nose'))) icon('🔎', q.x, q.y, 11);
    for (const it of qitems) if (it.active && !it.taken) icon(NPCS5[it.ni].item.ic, it.x, it.y, 12);
    for (const b of bosses) { if (CFG.rush && G.rush && b.id !== G.rush.idx) continue; icon(b.def.immortal ? '♾️' : b.state === 'dead' ? '✅' : '💀', b.hx, b.hy, 15); }
    if (!CFG.noCage || (CFG.team && !G.tessaAlly)) icon('❤️', tc(CAGE.x), tc(CAGE.y), 13);
    if (!CFG.rush) icon('🏠', tc(START.x), tc(START.y), 13);
    if (G.champ && !G.champ.dead) icon('👑', G.champ.x, G.champ.y, 15);
    if (!CFG.rush) {
      const o = objective();
      c.strokeStyle = '#d6f03a'; c.lineWidth = 2; c.setLineDash([4, 4]); c.beginPath(); c.moveTo(P.x * k, P.y * k); c.lineTo(o.x * k, o.y * k); c.stroke(); c.setLineDash([]);
    }
    c.fillStyle = '#ffffff'; c.strokeStyle = '#000000'; c.lineWidth = 2; c.beginPath(); c.arc(P.x * k, P.y * k, 6, 0, TAU); c.fill(); c.stroke();
    c.textBaseline = 'alphabetic';
    $('mapTitle').textContent = `🗺️ ${CFG.title || ''} · ${CFG.name}`;
    const lg = $('mapLegend'); if (!lg._base) lg._base = lg.textContent;
    lg.textContent = lg._base + (CFG.slides ? ' · 🔥 костёр · 🎣 прорубь · 🍪 печка · ✨ тайная поляна' : '');
  }
  function ensureWalkable(o) {
    if (walkable(o.x, o.y, false)) return;
    for (let r = 1; r < 40; r++) for (let a = 0; a < 16; a++) {
      const x = o.x + Math.cos(a / 16 * TAU) * r * T * 0.5, y = o.y + Math.sin(a / 16 * TAU) * r * T * 0.5;
      if (walkable(x, y, false)) { o.x = x; o.y = y; return; }
    }
  }


  // ------------------------------------------------------------------
  //  Испытания: карманная «инфернальная» арена под картой
  // ------------------------------------------------------------------
  function enterTrial(s) {
    const st = ARENA_STYLE[CHN] || ARENA_STYLE[1];
    s.state = 'active'; G.activeShrine = s; s.left = 0; G.trialT = 0;
    G.trialRet = { x: s.x, y: s.y + 60 };
    burst(P.x, P.y, 30, `rgb(${st.tint})`, 240);
    P.x = ARENA.x; P.y = ARENA.y; P.vx = 0; P.vy = 0; P.dashT = 0; P.inv = Math.max(P.inv, 1.2);
    G.ebullets.length = 0; G.hazards.length = 0; G.beams.length = 0;
    const n = Math.min(42, 10 + CHN * 5 + Math.floor(P.level / 4));
    for (let i = 0; i < n * 4 && s.left < n; i++) {
      const a = rnd(0, TAU), r = rnd(200, 360), x = ARENA.x + Math.cos(a) * r, y = ARENA.y + Math.sin(a) * r;
      const type = weighted(SPAWNS[s.biome]);
      if (!walkable(x, y, ENEMIES[type].fly)) continue;
      spawnEnemy(type, x, y, s.biome, { shrine: s, elite: s.left === 0 || Math.random() < CFG.elite * 2 * G.diff.elite });
      s.left++;
    }
    showBanner('⛩ ' + st.name, 'Победи всех – и вернёшься с наградой');
    Sound.sfx.roar(); Sound.sfx.blink(); G.shake = 10; Sound.music('boss');
    shockRing(P.x, P.y, `rgb(${st.tint})`, 300);
  }
  function leaveArena() {
    burst(P.x, P.y, 24, '#ffffff', 200);
    // добыча из арены отправляется вместе с героиней
    const dx = G.trialRet.x - P.x, dy = G.trialRet.y - P.y;
    for (const p of G.pickups) if (p.y > PLAY_H * T) { p.x += dx; p.y += dy; p.pull = true; }
    P.x = G.trialRet.x; P.y = G.trialRet.y; ensureWalkable(P); P.inv = Math.max(P.inv, 1);
    G.ebullets.length = 0; G.hazards.length = 0; G.beams.length = 0;
    revealFog(P.x, P.y, 12); biomeMusic(true); Sound.sfx.blink();
    burst(P.x, P.y, 30, '#5be3ff', 240);
  }
  function completeTrial(s) {
    s.state = 'done'; G.activeShrine = null;
    if (G.st) G.st.shrines++;
    Sound.sfx.win();
    leaveArena();
    showBanner('Испытание пройдено!', 'Награда: улучшение и осколки');
    for (let i = 0; i < 6; i++) dropShard(P.x + rnd(-40, 40), P.y + rnd(-40, 40));
    dropPickup(P.x, P.y + 40, 'heart'); dropPickup(P.x - 30, P.y + 40, 'key');
    addSuper(30);
    G.pendingLv++; openLevelUp();
    saveGame();
  }
  function failTrial(s) {
    s.state = 'idle'; G.activeShrine = null;
    for (const e of G.enemies) if (e.shrine === s) e.dead = true;
    leaveArena();
    floatText(P.x, P.y - 40, 'Испытание провалено', '#ff8a8a', true);
  }
  function drawArenaExit(c) {
    if (!ARENA || !G.activeShrine) return;
    const ex = ARENA.exit, g = 0.5 + Math.sin(G.time * 4) * 0.3;
    c.fillStyle = `rgba(150,220,255,${0.15 + g * 0.15})`; c.beginPath(); c.arc(ex.x, ex.y, 26, 0, TAU); c.fill();
    c.strokeStyle = `rgba(190,240,255,${0.5 + g * 0.4})`; c.lineWidth = 3; c.beginPath(); c.arc(ex.x, ex.y, 22, 0, TAU); c.stroke();
    c.font = 'bold 10px sans-serif'; c.textAlign = 'center'; c.fillStyle = '#bfeaff'; c.fillText('ВЫХОД (провал)', ex.x, ex.y - 32);
  }


  // ------------------------------------------------------------------
  //  Сундуки, мимики, ключи и реликвии
  // ------------------------------------------------------------------
  function hasRelic(id) { return !!(G.relics && G.relics.includes(id)); }
  function chestReward(c, mult) {
    const R = CHEST_TIERS[c.tier] || CHEST_TIERS.wood, zl = zoneE(c.biome), v = xpFor(zl) / 14 * xpGap(P.level, zl);
    const luck = hasRelic('clover') ? 1.5 : 1;
    for (let i = 0; i < R.gems * mult; i++) dropGem(c.x + rnd(-30, 30), c.y + rnd(-30, 30), v);
    for (let i = 0; i < Math.round(R.shards * mult * luck); i++) dropShard(c.x, c.y);
    if (Math.random() < R.heart) dropPickup(c.x, c.y + 26, 'heart');
    if (Math.random() < R.magnet) dropPickup(c.x + 20, c.y + 20, 'magnet');
    if (R.super) addSuper(R.super * mult);
    if (Math.random() < R.key * mult) dropPickup(c.x - 20, c.y + 20, 'key');
  }
  function openChest(c) {
    if (c.tier === 'gold') {
      if ((G.keys || 0) <= 0) {
        if ((G.keyMsgT || 0) <= 0) { G.keyMsgT = 2.5; floatText(c.x, c.y - 30, '🔒 Нужен ключ 🔑', '#ffd25a', true); Sound.sfx.block(); }
        return;
      }
      G.keys--; floatText(c.x, c.y - 34, '🔑 −1', '#ffd25a', true);
    }
    c.open = true;
    if (c.mimic) { wakeMimic(c); return; }
    if (G.st) G.st.chests++;
    Sound.sfx.chest(); burst(c.x, c.y, 30, c.tier === 'gold' ? '#ffd25a' : c.tier === 'silver' ? '#e0eaff' : '#d8a060', 220);
    chestReward(c, 1);
    if (c.tier === 'gold') G.relicPending = true;
    saveGame();
  }
  function wakeMimic(c) {
    const e = spawnEnemy('mimic', c.x, c.y, c.biome, { instant: true });
    e.mimicOf = c; e.chn = CHN; e.hp = e.maxHp = e.maxHp * (c.tier === 'silver' ? 5 : 4); e.dmg *= 1.15;
    showBanner('😱 Это мимик!', 'Победи его – награда будет двойной');
    Sound.sfx.roar(); G.shake = 10; burst(c.x, c.y, 24, '#a0623a', 200);
  }
  function mimicKilled(e) {
    const c = e.mimicOf; c.mimicDone = true;
    chestReward(c, 2);
    if (Math.random() < 0.5) dropPickup(e.x, e.y + 20, 'key');
    showBanner('Мимик побеждён!', 'Двойная награда'); Sound.sfx.chest();
    if (G.st) { G.st.mimics = (G.st.mimics || 0) + 1; G.st.chests++; }
    saveGame();
  }
  function updateRelics(dt) {
    if (G.guardT > 0) G.guardT -= dt;
    if (G.keyMsgT > 0) G.keyMsgT -= dt;
    if (G.relicPending && state === 'play' && !Dialog.talking) { G.relicPending = false; openRelicChoice(); return; }
    if (hasRelic('collar')) {
      G.thornT = (G.thornT || 0) - dt;
      if (G.thornT <= 0) {
        G.thornT = 0.5;
        for (const e of G.enemies) if (!e.dead && e.spawnT <= 0 && Math.hypot(e.x - P.x, e.y - P.y) < P.r + e.r + 6) damageEnemy(e, { v: P.dmg * 1.5, crit: false }, 0, 0, false);
      }
    }
    if (hasRelic('storm')) {
      G.stormRT = (G.stormRT === undefined ? 2.5 : G.stormRT) - dt;
      if (G.stormRT <= 0) {
        G.stormRT = 2.5;
        const tg = nearestTarget(320);
        if (tg) { G.bolts.push({ pts: [[P.x, P.y - 30], [tg.x, tg.y - (tg.z || 0)]], t: 0.25, col: '190,230,255' }); hitAny(tg, rollHit(P.dmg * 3), 0, 0, false); Sound.sfx.bolt(); }
      }
    }
  }
  function openRelicChoice() {
    const owned = G.relics || [];
    const pool = Object.keys(RELICS).filter(id => !owned.includes(id));
    const opts = [];
    while (opts.length < 3 && pool.length) opts.push(pool.splice(Math.floor(Math.random() * pool.length), 1)[0]);
    if (!opts.length) { for (let i = 0; i < 12; i++) dropShard(P.x + rnd(-40, 40), P.y + rnd(-40, 40)); return; }
    const box = $('relicCards'); box.innerHTML = '';
    opts.forEach((id, i) => {
      const r = RELICS[id], el = document.createElement('button');
      el.className = 'card'; el.style.animationDelay = (i * 0.07) + 's';
      el.innerHTML = `<div class="ic">${r.ic}</div><div><div class="nm">${r.name}</div><div class="ds">${r.ds}</div></div>`;
      el.addEventListener('click', () => { Sound.sfx.click(); pickRelic(id); });
      box.appendChild(el);
    });
    $('relicSwap').classList.add('hidden');
    $('relicHint').textContent = `Выбери реликвию · носить можно ${relicMax()}, сейчас ${owned.length}`;
    setState('relic'); Sound.sfx.chest();
  }
  function pickRelic(id) {
    if ((G.relics || []).length < relicMax()) { addRelic(id); return; }
    $('relicHint').textContent = `${RELICS[id].ic} ${RELICS[id].name} – что заменить?`;
    const box = $('relicOwned'); box.innerHTML = '';
    for (const old of G.relics) {
      const r = RELICS[old], el = document.createElement('button');
      el.className = 'btn alt'; el.textContent = `${r.ic} ${r.name}`;
      el.addEventListener('click', () => { Sound.sfx.click(); G.relics = G.relics.filter(x => x !== old); addRelic(id); });
      box.appendChild(el);
    }
    $('relicSwap').classList.remove('hidden');
  }
  function addRelic(id) {
    G.relics = (G.relics || []).concat(id).slice(-relicMax());
    const prof = loadProfile(); prof.relics = G.relics; saveProfile(prof);
    computeStats(); setState('play');
    showBanner(`${RELICS[id].ic} ${RELICS[id].name}`, RELICS[id].ds); Sound.sfx.magic();
    if (G.st) G.st.relics = (G.st.relics || 0) + 1;
  }

  // ------------------------------------------------------------------
  //  Сердечки в бою с боссом и «усмирённые» локации
  // ------------------------------------------------------------------
  const HEART_EVERY = { easy: 11, normal: 18, hard: 22 };
  function dropHeartNear(r0, r1) {
    for (let k = 0; k < 12; k++) {
      const a = rnd(0, TAU), r = rnd(r0, r1), x = P.x + Math.cos(a) * r, y = P.y + Math.sin(a) * r;
      if (!walkable(x, y, false)) continue;
      dropPickup(x, y, 'heart'); burst(x, y, 10, '#ff5b8a', 120); return;
    }
    dropPickup(P.x + rnd(-30, 30), P.y + 50, 'heart');
  }
  function updateBossHearts(dt) {
    const b = G.activeBoss;
    if (!b || b.state !== 'fight') return;
    G.bossHeartT -= dt * (P.hp < P.maxHp * 0.35 ? 2 : 1);
    if (G.bossHeartT > 0) return;
    G.bossHeartT = HEART_EVERY[G.diffId] || 12;
    dropHeartNear(130, 250);
  }
  // Усмирение: после победы над стражем его локация слабеет ступенями I–V.
  // Ступень растёт за убийства в этой локации, за каждую – награда.
  const CALM_STEPS = [0, 120, 350, 700, 1200], CALM_PCT = [0.10, 0.15, 0.20, 0.25, 0.30], ROMAN = ['I', 'II', 'III', 'IV', 'V'];
  const calmStage = biome => { const n = G.calm[biome] || 0; let s = 0; while (s < 4 && n >= CALM_STEPS[s + 1]) s++; return s; };
  const calmOf = biome => (G.calm && G.calm[biome] !== undefined) ? CALM_PCT[calmStage(biome)] : 0;
  function calmKill(biome) {
    if (!G.calm || G.calm[biome] === undefined || G.calm[biome] >= CALM_STEPS[4]) return;
    const before = calmStage(biome);
    G.calm[biome]++;
    const st = calmStage(biome);
    if (st <= before) return;
    showBanner(`🕊️ Усмирение ${ROMAN[st]}`, `${BIOMES[biome].name}: враги слабее на ${Math.round(CALM_PCT[st] * 100)}%`);
    Sound.sfx.chest();
    for (let i = 0; i < [0, 4, 6, 8, 12][st]; i++) dropShard(P.x + rnd(-40, 40), P.y + rnd(-40, 40));
    dropPickup(P.x, P.y + 40, 'heart');
    if (G.st) G.st.calmUps = (G.st.calmUps || 0) + 1;
    if (st >= 3) { G.pendingLv++; openLevelUp(); }
  }

  // ------------------------------------------------------------------
  //  Чемпионы: сильные бродячие мобы с наградой
  // ------------------------------------------------------------------
  function updateChampions(dt) {
    if (G.champ && (G.champ.dead || !G.enemies.includes(G.champ))) G.champ = null;
    if (G.champ) { if (Math.hypot(G.champ.x - P.x, G.champ.y - P.y) > 3200) { G.champ.dead = true; G.champ = null; } return; }
    if (CFG.rush || G.finalFinal || G.activeBoss || G.activeShrine || playerInCastle()) return;
    G.champT -= dt;
    if (G.champT > 0) return;
    G.champT = rnd(150, 210);
    spawnChampion();
  }
  function spawnChampion() {
    const biome = curBiome();
    const types = (SPAWNS[biome] || []).map(s => s[0]).filter(t => !ENEMIES[t].group && ENEMIES[t].ai !== 'exploder' && ENEMIES[t].ai !== 'swarm');
    if (!types.length) return;
    for (let k = 0; k < 20; k++) {
      const a = rnd(0, TAU), r = rnd(450, 750), x = P.x + Math.cos(a) * r, y = P.y + Math.sin(a) * r;
      const type = pick(types), tx = Math.floor(x / T), ty = Math.floor(y / T);
      if (!inMap(tx, ty) || tiles[ty * MW + tx] === FLOOR || !walkable(x, y, ENEMIES[type].fly)) continue;
      const e = spawnEnemy(type, x, y, biome, { elite: true, instant: true });
      e.champion = true; e.hp = e.maxHp = e.maxHp * 6; e.dmg *= 1.2; e.r *= 1.2; e.xp *= 3; e.name = ENEMIES[type].name;
      G.champ = e;
      showBanner('👑 Чемпион!', `${e.name} бродит рядом – ищи корону на карте`);
      Sound.sfx.roar();
      return;
    }
  }

  // ------------------------------------------------------------------
  //  Порталы между пройденными алтарями
  // ------------------------------------------------------------------
  const portalHere = () => shrines.find(s => s.state === 'done' && Math.hypot(P.x - s.x, P.y - s.y) < 60);
  function openPortals() {
    const here = portalHere();
    if (!here) return;
    const dests = shrines.filter(s => s.state === 'done' && s !== here).map(s => ({ ic: '⛩', nm: 'Алтарь · ' + BIOMES[s.biome].name, x: s.x, y: s.y + 56 }));
    dests.push({ ic: '🏠', nm: 'Начало пути', x: tc(START.x), y: tc(START.y) });
    if (gateOpen) dests.push({ ic: '🏰', nm: 'Ворота замка', x: tc(GATE_FRONT.x), y: tc(GATE_FRONT.y) + 20 });
    for (const d of dests) d.dist = Math.round(Math.hypot(d.x - P.x, d.y - P.y) / PX_PER_M);
    dests.sort((a, b) => a.dist - b.dist);
    const list = $('portalList'); list.innerHTML = '';
    for (const d of dests) {
      const el = document.createElement('button'); el.className = 'btn alt';
      el.innerHTML = `${d.ic} ${d.nm} <small>· ${d.dist} м</small>`;
      el.addEventListener('click', () => { Sound.sfx.click(); portalTo(d); });
      list.appendChild(el);
    }
    setState('portal'); Sound.sfx.magic();
  }
  function portalTo(d) {
    burst(P.x, P.y, 30, '#c77dff', 220);
    P.x = d.x; P.y = d.y; P.inv = 1.2; P.vx = 0; P.vy = 0; P.dashT = 0;
    revealFog(P.x, P.y, 12);
    for (const e of G.enemies) if (!e.minion && !e.champion && Math.hypot(e.x - P.x, e.y - P.y) < 260) e.dead = true;
    burst(P.x, P.y, 40, '#c77dff', 260); shockRing(P.x, P.y, '#c77dff', 200);
    Sound.sfx.blink(); setState('play'); biomeMusic(true);
  }

  // ------------------------------------------------------------------
  //  Музыка локаций
  // ------------------------------------------------------------------
  function curBiome() {
    if (playerInCastle()) return CASTLE.biome;
    return biomeMap[clamp(Math.floor(P.y / T), 0, MH - 1) * MW + clamp(Math.floor(P.x / T), 0, MW - 1)];
  }
  function biomeMusic(now) {
    const want = CFG.rush ? 'boss' : (BIOME_MUSIC[curBiome()] || CFG.music);
    if (now) { G.musWant = want; G.musHold = 0; Sound.music(want); }
    return want;
  }
  function updateMusic(dt) {
    if (G.activeBoss || G.cutscene || G.finalFinal || state !== 'play') return;
    G.musT -= dt; if (G.musT > 0) return; G.musT = 0.5;
    const want = biomeMusic(false);
    if (want !== G.musWant) { G.musWant = want; G.musHold = 0; return; }
    G.musHold += 0.5;
    if (G.musHold >= 1.5 && Sound.current() !== want) Sound.music(want);
  }

  // ------------------------------------------------------------------
  //  События на карте (раз в ~3 минуты)
  // ------------------------------------------------------------------
  function startEvent(forceId) {
    const pool = EVENTS.filter(e => e.id !== G.lastEv && (e.id !== 'song' || CHN >= 2) && !(CFG.noEvents || []).includes(e.id));
    const def = (forceId && EVENTS.find(e => e.id === forceId)) || weighted(pool.map(e => [e, e.w]));
    G.ev = { def, t: 0, k: 0 }; G.lastEv = def.id;
    G.evT = EVENT_EVERY * G.diff.event;
    showBanner(def.ic + ' ' + def.name, def.desc);
    Sound.sfx.event(); G.shake = Math.max(G.shake, 6);
    if (G.st) G.st.events[def.id] = (G.st.events[def.id] || 0) + 1;
    if (def.id === 'song') {
      G.ev.line = Math.floor(Math.random() * SONG_TEXTS.length); G.ev.lineT = 2.6;
      $('songText').textContent = SONG_TEXTS[G.ev.line];
      const ac = $('songAvatar').getContext('2d'); ac.clearRect(0, 0, 96, 96);
      if (ART.zyamaFace) ac.drawImage(ART.zyamaFace, 0, 0, 96, 96);
      $('songBanner').classList.remove('hidden');
    }
  }
  function endEvent() {
    if (G.ev && G.ev.def.id === 'song') $('songBanner').classList.add('hidden');
    G.ev = null;
  }
  function updateEvents(dt) {
    if (CFG.rush || G.cutscene || G.finalFinal) { if (G.ev) endEvent(); return; }
    if (G.ev) {
      const ev = G.ev; ev.t += dt; ev.k -= dt;
      if (ev.def.id === 'meteor' && ev.k <= 0) {
        ev.k = 0.3;
        const a = rnd(0, TAU), r = rnd(20, 270);
        hazardCircle(P.x + P.vx * 0.6 + Math.cos(a) * r, P.y + P.vy * 0.6 + Math.sin(a) * r, 62, 1.1, P.maxHp * 0.12, 'meteor');
      }
      if (ev.def.id === 'hearts' && ev.k <= 0) { ev.k = 0.55; const a = rnd(0, TAU), r = rnd(60, 240); dropPickup(P.x + Math.cos(a) * r, P.y + Math.sin(a) * r, 'heart'); }
      if (ev.def.id === 'song') {
        const left = Math.ceil(ev.def.dur - ev.t); $('songLeft').textContent = left > 0 ? `Песня кончится через ${left}…` : '';
        ev.lineT -= dt;
        if (ev.lineT <= 0) { ev.lineT = 2.6; ev.line = (ev.line + 1) % SONG_TEXTS.length; $('songText').textContent = SONG_TEXTS[ev.line]; }
        if (Math.random() < dt * 6) floatText(P.x + rnd(-160, 160), P.y + rnd(-200, 40), pick(['♪', '♫', '🎵']), '#ff8ad8', true);
      }
      if (ev.t >= ev.def.dur) endEvent();
      return;
    }
    if (G.activeBoss || G.activeShrine) return;
    G.evT -= dt;
    if (G.evT <= 0) startEvent();
  }

  // ------------------------------------------------------------------
  //  Статистика (для отправки разработчику)
  // ------------------------------------------------------------------
  function newRunStats() {
    return { ch: CHN, hero: P.hero, diff: G.diffId, lvl0: P.level, time: 0, deaths: 0, kills: 0, elites: 0, byType: {}, dmgDealt: 0, dmgTaken: 0,
      healed: 0, shards: 0, chests: 0, shrines: 0, supers: 0, dashes: 0, events: {}, bosses: [], ups: [], cur: null, champs: 0, calmUps: 0 };
  }
  function loadTotals() { try { return JSON.parse(localStorage.getItem(STATS_KEY)) || {}; } catch (e) { return {}; } }
  function saveTotals(t) { try { localStorage.setItem(STATS_KEY, JSON.stringify(t)); } catch (e) { /* ignore */ } }
  const topTypes = (m, n) => Object.entries(m || {}).sort((a, b) => b[1] - a[1]).slice(0, n);
  const fmtT = sec => { sec = Math.max(0, Math.round(sec)); const h = Math.floor(sec / 3600), m = Math.floor(sec % 3600 / 60), ss = sec % 60; return (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + String(ss).padStart(2, '0'); };
  const fmtN = v => v >= 1e6 ? (v / 1e6).toFixed(1) + 'M' : v >= 1e3 ? (v / 1e3).toFixed(1) + 'K' : String(Math.round(v));
  function summarizeRun() {
    const s = G.st;
    return { ch: s.ch, hero: s.hero, diff: s.diff, lvl0: s.lvl0, lvl: P.level, time: Math.round(s.time), deaths: s.deaths, kills: s.kills, elites: s.elites,
      dealt: Math.round(s.dmgDealt), taken: Math.round(s.dmgTaken), healed: Math.round(s.healed || 0), shards: s.shards, chests: s.chests, shrines: s.shrines,
      supers: s.supers, dashes: s.dashes, combo: G.bestCombo, champs: s.champs || 0, calmUps: s.calmUps || 0, seed: SEED % 10000, mimics: s.mimics || 0, relics: s.relics || 0, events: s.events, bosses: s.bosses, ups: s.ups, top: topTypes(s.byType, 6) };
  }
  function recordRunEnd(result) {
    if (!G.st) return;
    const tot = loadTotals();
    tot.runs = tot.runs || [];
    tot.runs.unshift(Object.assign(summarizeRun(), { result, at: Date.now() }));
    tot.runs = tot.runs.slice(0, 10);
    saveTotals(tot);
  }
  function buildReport() {
    const prof = loadProfile(), tot = loadTotals();
    const L = [];
    L.push(`📊 Крилесса v${VERSION} – статистика`);
    const ua = navigator.userAgent, andr = (ua.match(/Android [\d.]+/) || ['?'])[0], chrome = (ua.match(/Chrome\/(\d+)/) || [0, '?'])[1];
    L.push(`📱 ${VW}×${VH} @${DPR}x · ${andr} · WebView ${chrome}`);
    L.push(`⚙️ Сложность: ${DIFFS[(prof.settings || {}).diff || 'normal'].name} · в игре: ${fmtT(tot.playTime || 0)} · запусков: ${tot.sessions || 0}`);
    L.push(`🏆 Главы: ${[1, 2, 3, 4, 5].map(n => n + (prof['ch' + n + 'Done'] ? '✓' : '–')).join(' ')}${prof.trueWin ? ' · настоящий финал ✓' : ''}` +
      (prof.rushBest ? ` · Босс-раш: ${prof.rushBest.n}/${prof.rushBest.total} за ${fmtT(prof.rushBest.time)}` : ''));
    const runs = [];
    if (G.st && G.st.time > 1 && !(G.rush && G.rush.done)) runs.push(Object.assign(summarizeRun(), { result: 'идёт сейчас' }));
    for (const r of (tot.runs || [])) runs.push(r);
    for (const r of runs.slice(0, 5)) {
      L.push('');
      L.push(`– ${r.ch === 'rush' || String(r.result).includes('раш') ? 'Босс-раш' : 'Глава ' + r.ch} · ${HEROES[r.hero] ? HEROES[r.hero].name : r.hero} · ${String(r.diff).split('→').map(d => DIFFS[d] ? DIFFS[d].name : d).join(' → ')} · ${r.result} –`);
      L.push(`⏱ ${fmtT(r.time)} · ур. ${r.lvl0}→${r.lvl} · ☠️ ${r.kills} (элита ${r.elites}) · 💀 смертей ${r.deaths} · 🔥 комбо ${r.combo}`);
      if (r.champs !== undefined) L.push(`🗺️ карта #${r.seed} · 👑 чемпионов ${r.champs} · 🕊️ ступеней усмирения ${r.calmUps}` + (r.mimics !== undefined ? ` · 😱 мимиков ${r.mimics} · 🗝️ реликвий ${r.relics}` : ''));
      L.push(`⚔️ нанесено ${fmtN(r.dealt)} · получено ${fmtN(r.taken)} · вылечено ${fmtN(r.healed)} · 💎 ${r.shards} · 📦 ${r.chests} · ⛩ ${r.shrines} · 🌟 ${r.supers} · рывков ${r.dashes}`);
      for (const b of r.bosses || []) L.push(`  👑 ${b.n}: ${fmtT(b.t)} · ур. игрока ${b.pl} / босса ${b.bl} · смертей ${b.d}` + (b.h !== undefined ? ` · ❤️ ${b.h}` : '') + (b.df ? ` · ${DIFFS[b.df] ? DIFFS[b.df].name : b.df}` : ''));
      const ev = Object.entries(r.events || {}).map(([k, v]) => { const e = EVENTS.find(x => x.id === k); return (e ? e.ic : k) + '×' + v; }).join(' ');
      if (ev) L.push(`  🎲 события: ${ev}`);
      if (r.top && r.top.length) L.push(`  👾 ${r.top.map(([k, v]) => (ENEMIES[k] ? ENEMIES[k].name : k) + ' ' + v).join(', ')}`);
      if (r.ups && r.ups.length) { const cnt = {}; r.ups.forEach(u => { cnt[u] = (cnt[u] || 0) + 1; }); L.push(`  ⬆️ ${Object.entries(cnt).map(([k, v]) => k + '×' + v).join(' ')}`); }
    }
    L.push('');
    const data = { v: VERSION, scr: [VW, VH, DPR], c: [prof.ch1Done, prof.ch2Done, prof.ch3Done, prof.trueWin, prof.ch4Done, prof.ch5Done].map(Boolean), w: prof.ch4Choice || null, a: prof.ch5Accuse || null, d: (prof.settings || {}).diff,
      rb: prof.rushBest || null, pt: Math.round(tot.playTime || 0), ss: tot.sessions || 0,
      runs: runs.slice(0, 5).map(r => ({ ch: r.ch, h: r.hero, d: r.diff, r: r.result, t: r.time, l: [r.lvl0, r.lvl], k: r.kills, de: r.deaths, dd: r.dealt, dt: r.taken,
        b: (r.bosses || []).map(b => [b.k, b.t, b.pl, b.bl, b.d, b.h || 0, b.df || '']), e: r.events, u: r.ups })) };
    L.push('#KRSTAT ' + JSON.stringify(data));
    return L.join('\n');
  }
  let statsBack = 'menu';
  function openStats() {
    statsBack = state === 'stats' ? statsBack : state;
    $('statsText').textContent = buildReport();
    setState('stats');
  }
  function toast(msg) {
    const t = $('toast'); t.textContent = msg; t.classList.remove('hidden', 'show'); void t.offsetWidth; t.classList.add('show');
    clearTimeout(toast.tm); toast.tm = setTimeout(() => t.classList.add('hidden'), 2600);
  }
  function fallbackCopy(txt) {
    const ta = document.createElement('textarea'); ta.value = txt; ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.appendChild(ta); ta.select();
    try { document.execCommand('copy'); toast('Скопировано! Вставь в сообщение 📋'); } catch (e) { toast('Не получилось скопировать'); }
    ta.remove();
  }
  function copyText(txt) {
    try { if (window.KrilessaAndroid && window.KrilessaAndroid.copy) { window.KrilessaAndroid.copy(txt); toast('Скопировано! Вставь в сообщение 📋'); return; } } catch (e) { /* ignore */ }
    if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(txt).then(() => toast('Скопировано! Вставь в сообщение 📋'), () => fallbackCopy(txt)); return; }
    fallbackCopy(txt);
  }
  function shareText(txt) {
    try { if (window.KrilessaAndroid && window.KrilessaAndroid.share) { window.KrilessaAndroid.share(txt); return; } } catch (e) { /* ignore */ }
    if (navigator.share) { navigator.share({ title: 'Крилесса – статистика', text: txt }).catch(() => {}); return; }
    copyText(txt);
  }

  // ------------------------------------------------------------------
  //  Босс-раш
  // ------------------------------------------------------------------
  function rushPool() {
    const prof = loadProfile(), kinds = [], levels = [];
    for (const n of [1, 2, 3, 4, 5, 6]) if (CHAPTERS[n] && (prof['ch' + n + 'Done'] || DEBUG || prof.admin)) CHAPTERS[n].bosses.forEach((k, i) => { kinds.push(k); levels.push(CHAPTERS[n].bossLevels[i]); });
    return { kinds, levels };
  }
  function startRush() {
    const prof = loadProfile();
    const { kinds, levels } = rushPool();
    if (!kinds.length) return;
    const R = CHAPTERS.rush;
    R.bosses = kinds; R.bossLevels = levels; R.bossTiles = kinds.map(() => ({ x: 30, y: 24 }));
    const rhs = (prof.settings || {}).rushHero;
    R.hero = rhs === 'tessa' && (prof.ch4Done || DEBUG || prof.admin) ? 'tessa' : rhs === 'ryzhovaya' && (prof.ch3Done || DEBUG || prof.admin) ? 'ryzhovaya' : 'krilessa';
    loadChapter('rush'); resetRun();
    // у всех одинаковая героиня 24 уровня (плюс свои таланты и реликвии) – рекорды честные
    { const rb = refBuild(24); P.level = 24; P.up = rb.up; P.bonus = rb.bonus; P.shards = 0; }
    P.xpNext = xpFor(P.level);
    beginPlay();
    gateOpen = true;
    G.rush = { idx: 0, wait: 2.5, t: 0, total: kinds.length, done: false };
    G.st = newRunStats();
    showBanner('⚔️ Босс-раш', `${kinds.length} боссов подряд. Время пошло!`);
    Sound.music('boss');
  }
  function rushBossDown() {
    const R = G.rush;
    R.idx++;
    P.hp = Math.min(P.maxHp, P.hp + P.maxHp * 0.5);
    for (const e of G.enemies) if (e.minion) e.dead = true;
    if (R.idx >= R.total) { rushFinish(true); return; }
    R.wait = 3.5;
    showBanner(`Босс ${R.idx}/${R.total} повержен!`, `Время ${fmtT(R.t)}`);
    G.pendingLv++; openLevelUp();
  }
  function rushFinish(win) {
    const R = G.rush, prof = loadProfile();
    if (R.done) return;
    R.done = true;
    const res = { n: R.idx, total: R.total, time: Math.round(R.t), hero: P.hero };
    const best = prof.rushBest;
    R.better = !best || res.n > best.n || (res.n === best.n && res.time < best.time);
    if (R.better) { prof.rushBest = res; saveProfile(prof); }
    recordRunEnd(win ? 'босс-раш пройден' : `босс-раш ${R.idx}/${R.total}`);
    if (win) { Sound.music('win'); setTimeout(() => showVictory('rush'), 1500); }
  }

  // ------------------------------------------------------------------
  //  Подлянка финала главы 3
  // ------------------------------------------------------------------
  let trickTimers = [];
  const later = (ms, fn) => trickTimers.push(setTimeout(fn, ms));
  const Trick = { cv: null, c: null, raf: 0, t0: 0, mode: '', cracks: [], shards: [] };
  function trickSetup() {
    Trick.cv = $('trickCanvas'); Trick.c = Trick.cv.getContext('2d');
    const d = Math.min(window.devicePixelRatio || 1, 2);
    Trick.cv.width = Math.round(VW * d); Trick.cv.height = Math.round(VH * d);
    Trick.c.setTransform(d, 0, 0, d, 0, 0);
    Trick.cv.classList.remove('hidden');
  }
  function trickLoop(now) {
    const c = Trick.c, t = (now - Trick.t0) / 1000;
    c.clearRect(0, 0, VW, VH);
    if (Trick.mode === 'crack') {
      const k = clamp(t / 0.9, 0, 1);
      c.strokeStyle = 'rgba(255,255,255,0.9)'; c.lineWidth = 2; c.shadowColor = '#ff3ea5'; c.shadowBlur = 8;
      for (const cr of Trick.cracks) {
        const n = Math.floor(cr.length * k);
        c.beginPath(); c.moveTo(cr[0][0], cr[0][1]);
        for (let i = 1; i < n; i++) c.lineTo(cr[i][0], cr[i][1]);
        c.stroke();
      }
      c.shadowBlur = 0;
    } else if (Trick.mode === 'shatter') {
      c.fillStyle = `rgba(10,4,20,${clamp(t / 0.3, 0, 1)})`; c.fillRect(0, 0, VW, VH);
      for (const s of Trick.shards) {
        s.vy += 900 * (1 / 60); s.x += s.vx / 60; s.y += s.vy / 60; s.a += s.va / 60;
        c.save(); c.translate(s.x, s.y); c.rotate(s.a);
        c.globalAlpha = clamp(1.6 - t, 0, 1);
        const g = c.createLinearGradient(-30, -30, 30, 30); g.addColorStop(0, '#5a2a4a'); g.addColorStop(0.5, '#ffb347'); g.addColorStop(1, '#2a1238');
        c.fillStyle = g; c.beginPath(); s.pts.forEach(([x, y], i) => i ? c.lineTo(x, y) : c.moveTo(x, y)); c.closePath(); c.fill();
        c.strokeStyle = 'rgba(255,255,255,0.8)'; c.lineWidth = 1.5; c.stroke();
        c.restore();
      }
      c.globalAlpha = 1;
    }
    Trick.raf = requestAnimationFrame(trickLoop);
  }
  function startTrick() {
    if (state !== 'victory' || CHN !== 3 || G.trueWin) return;
    const vic = $('victory'); vic.classList.add('glitching');
    Sound.setGlitch(1); Sound.sfx.staticNoise();
    const title = $('victoryTitle'), orig = title.textContent, glyphs = '█▓▒░#@%&?!ЗЯМОЧКККК';
    let n = 0;
    const scr = setInterval(() => { n++; title.textContent = orig.split('').map(ch => Math.random() < n * 0.05 ? glyphs[Math.floor(Math.random() * glyphs.length)] : ch).join(''); }, 90);
    later(900, () => Sound.sfx.staticNoise());
    later(1800, () => { Sound.sfx.staticNoise(); G.shake = 20; });
    later(2200, () => {
      trickSetup(); Trick.mode = 'crack'; Trick.t0 = performance.now(); Trick.cracks = [];
      const cx = VW * 0.5, cy = VH * 0.38;
      for (let i = 0; i < 16; i++) {
        let a = (i / 16) * TAU + rnd(-0.2, 0.2), x = cx, y = cy; const pts = [[x, y]];
        for (let k = 0; k < 10; k++) { a += rnd(-0.5, 0.5); const l = rnd(25, 70); x += Math.cos(a) * l; y += Math.sin(a) * l; pts.push([x, y]); }
        Trick.cracks.push(pts);
      }
      Sound.sfx.glass();
      cancelAnimationFrame(Trick.raf); Trick.raf = requestAnimationFrame(trickLoop);
    });
    later(3200, () => {
      clearInterval(scr);
      Trick.mode = 'shatter'; Trick.t0 = performance.now(); Trick.shards = [];
      const cols = 6, rows = 10, w = VW / cols, h = VH / rows;
      for (let i = 0; i < cols; i++) for (let j = 0; j < rows; j++) {
        const x0 = i * w, y0 = j * h;
        for (const tri of [[[0, 0], [w, 0], [0, h]], [[w, 0], [w, h], [0, h]]]) {
          const cxs = (tri[0][0] + tri[1][0] + tri[2][0]) / 3, cys = (tri[0][1] + tri[1][1] + tri[2][1]) / 3;
          const px = x0 + cxs, py = y0 + cys, da = Math.atan2(py - VH * 0.38, px - VW / 2);
          Trick.shards.push({ x: px, y: py, pts: tri.map(([a, b]) => [a - cxs, b - cys]), vx: Math.cos(da) * rnd(80, 300), vy: Math.sin(da) * rnd(80, 300) - 200, a: 0, va: rnd(-6, 6) });
        }
      }
      Sound.sfx.shatter(); G.shake = 25;
      vic.classList.add('hidden'); vic.classList.remove('glitching');
    });
    later(4300, () => {
      cancelAnimationFrame(Trick.raf); Trick.cv.classList.add('hidden');
      Sound.setGlitch(0); Sound.music('zyamashow'); openZyamaMenu();
    });
  }
  function openZyamaMenu() {
    setState('zmenu');
    const ac = $('zmAvatar').getContext('2d'); ac.clearRect(0, 0, 160, 160);
    if (ART.zyamaFace) ac.drawImage(ART.zyamaFace, 0, 0, 160, 160);
    $('zmSay').textContent = 'Ой. Вы что, правда думали, что победили? 😏';
    const ex = $('zmExit'); ex.style.transform = ''; ex.textContent = '✖ Выйти';
    G.zm = { tries: 0, go: false };
    later(9500, zyamaMenuGo);
  }
  function zmReact(text, go) { $('zmSay').textContent = text; Sound.sfx.click(); if (go) later(1900, zyamaMenuGo); }
  function zyamaMenuGo() {
    if (!G.zm || G.zm.go) return;
    G.zm.go = true;
    $('zmSay').textContent = 'Вы думали, это конец? Это был только АНТРАКТ! 😈';
    Sound.sfx.roar(); G.shake = 20;
    later(2300, startFinalFinal);
  }
  function startFinalFinal() {
    trickTimers.forEach(clearTimeout); trickTimers = [];
    const d = BOSSES.zyamaInf, hx = tc(CASTLE.x), hy = tc(CASTLE.y);
    const b = {
      id: bosses.length, kind: 'zyamaInf', def: d, name: d.name, sub: d.sub, r: d.r, maxHp: 1, hp: 1, spd: d.spd, dmg: 0, cdmg: 0,
      E: 0, level: 0, aggro: 1, shield: false, stunT: 0, burnT: 0, burnDps: 0, burnTick: 0,
      fly: true, move: d.move, hx, hy, x: hx, y: hy - 80, state: 'sleep', mode: 'idle', t: 0, flash: 0, z: 0, last: null, stage: 0, vstage: 3,
      sub: 0, cnt: 0, anim: 0, alpha: 1, ang: 0, tx: 0, ty: 0, sx: 0, sy: 0, dist: 0, charging: false, dur: 0, inv: false, final: true, look: 0, p: null,
      speedMul: 1, tauntT: 6, orbCd: 0,
    };
    bosses.push(b);
    G.cutscene = null; G.cageOpen = 1;
    P.x = hx; P.y = hy + 210; P.hp = P.maxHp; P.inv = 2;
    G.cp = { x: P.x, y: P.y };
    G.finalFinal = { t: 0, bank: 0, need: d.survive, ally: { x: P.x - 55, y: P.y - 20, fireT: 0 }, said: {} };
    G.enemies.length = 0; G.ebullets.length = 0; G.hazards.length = 0; G.beams.length = 0;
    setState('play');
    startBossFight(b);
    later(2600, () => showBanner('ЗЯМОЧКККК ∞', 'Продержись 40 секунд! Попадания ускоряют ДРУЖБА-СУПЕР'));
  }
  function updateFinalFinal(dt) {
    const F = G.finalFinal;
    if (!F || G.cutscene) return;
    const A = F.ally, b = G.activeBoss;
    A.x = lerp(A.x, P.x - 55 * P.face, Math.min(1, dt * 4)); A.y = lerp(A.y, P.y - 26, Math.min(1, dt * 4));
    A.fireT -= dt;
    if (b && A.fireT <= 0) {
      A.fireT = 0.25;
      const a = Math.atan2(b.y - A.y, b.x - A.x);
      G.feathers.push({ x: A.x, y: A.y, vx: Math.cos(a) * 480, vy: Math.sin(a) * 480, dmg: P.dmg * 0.5, pierce: 3, life: 1.2, hit: [], kind: 'feather', ally: true });
    }
    if (!b) return;
    const extra = Math.min(F.bank, dt * 0.6); F.bank -= extra;
    F.t += dt + extra;
    const lines = [[3, 'Рыжовая, держись! Я заряжаю ДРУЖБА-СУПЕР! 💜'], [16, 'Он бессмертный, но дружба сильнее! Ещё немного!'], [29, 'Почти готово!!! Не сдавайся!'], [36, 'На счёт три... раз... два...']];
    for (const [tt, text] of lines) if (F.t >= tt && !F.said[tt]) { F.said[tt] = 1; say(text, 3.2); }
    if (F.t >= F.need) startTeamUp();
  }
  function startTeamUp() {
    G.cutscene = { t: 0, kind: 'teamup' };
    G.ebullets.length = 0; G.hazards.length = 0; G.beams.length = 0;
    // без опыта: окно улучшений не должно выскакивать посреди сцены
    for (const e of G.enemies) burst(e.x, e.y, 8, '#ffffff', 100);
    G.enemies.length = 0;
    showBanner('ДРУЖБА-СУПЕР!', 'Крилесса + Рыжовая');
    Sound.sfx.nova(); Sound.sfx.magic(); G.shake = 12;
  }
  function updateTeamUp(dt, cs) {
    const b = bosses[bosses.length - 1], A = G.finalFinal.ally;
    A.x = lerp(A.x, P.x - 46, Math.min(1, dt * 3)); A.y = lerp(A.y, P.y - 6, Math.min(1, dt * 3));
    P.t += dt;
    if (cs.t > 0.8 && cs.t < 3.2) { G.shake = Math.max(G.shake, 5); if (Math.random() < 0.9) part(b.x + rnd(-40, 40), b.y + rnd(-40, 40), rnd(-220, 220), rnd(-220, 220), 0.5, 6, pick(RAINBOW)); }
    if (cs.t >= 3.2 && !cs.boom) {
      cs.boom = true; b.state = 'dead'; G.activeBoss = null;
      burst(b.x, b.y, 120, '#ffd25a', 520); burst(b.x, b.y, 80, '#ff3ea5', 420); burst(b.x, b.y, 60, '#3ff0ff', 360);
      shockRing(b.x, b.y, '#ffffff', 650); G.shake = 30; Sound.sfx.boom(); Sound.sfx.win();
      speak('zyamaInf', b.def.lines.death, 4.5);
      Sound.music('truewin');
      if (G.st && G.st.cur) { const c = G.st.cur; G.st.bosses.push({ k: c.k, n: c.n, pl: c.pl, bl: c.bl, t: Math.round(G.st.time - c.t0), d: c.d, h: c.h || 0, df: c.df || G.diffId }); G.st.cur = null; }
    }
    if (cs.boom && Math.random() < 0.4) part(P.x + rnd(-80, 80), P.y + rnd(-90, 10), 0, -50, 1.4, 6, '#ff5b8a');
    if (cs.t > 8.5 && !G.trueWin) {
      G.trueWin = true;
      const prof = loadProfile(); prof.trueWin = true; saveProfile(prof);
      recordRunEnd('настоящая победа');
      showVictory('true');
    }
  }

  // ------------------------------------------------------------------
  //  Что нового (после обновления)
  // ------------------------------------------------------------------
  let wnBack = 'menu', confetti = [], confRaf = 0;
  function confLoop() {
    const cv = $('wnCanvas'), c = cv.getContext('2d');
    const d = Math.min(window.devicePixelRatio || 1, 2);
    if (cv.width !== Math.round(VW * d)) { cv.width = Math.round(VW * d); cv.height = Math.round(VH * d); }
    c.setTransform(d, 0, 0, d, 0, 0); c.clearRect(0, 0, VW, VH);
    if (confetti.length < 90) confetti.push({ x: rnd(0, VW), y: -10, vy: rnd(60, 160), vx: rnd(-30, 30), a: rnd(0, TAU), va: rnd(-6, 6), col: pick(RAINBOW), w: rnd(5, 10) });
    for (const p of confetti) { p.y += p.vy / 60; p.x += p.vx / 60; p.a += p.va / 60; c.save(); c.translate(p.x, p.y); c.rotate(p.a); c.fillStyle = p.col; c.fillRect(-p.w / 2, -3, p.w, 6); c.restore(); }
    confetti = confetti.filter(p => p.y < VH + 20);
    confRaf = requestAnimationFrame(confLoop);
  }
  // 0.11 вышла раньше и потом стала 0.10.2 – для неё показываем всё, что новее 0.10.1
  const VERSION_ALIAS = { '0.11 beta': '0.10.1 beta' };
  function openWhatsNew(fromVer) {
    fromVer = VERSION_ALIAS[fromVer] || fromVer;
    const idx = CHANGELOG.findIndex(cl => cl.v === fromVer);
    const list = idx > 0 ? CHANGELOG.slice(0, idx) : CHANGELOG;
    $('wnVer').textContent = fromVer && fromVer !== VERSION ? `v${fromVer} → v${VERSION}` : `v${VERSION}`;
    const box = $('wnList'); box.innerHTML = '';
    let k = 0;
    list.forEach((cl, i) => {
      const h = document.createElement('div'); h.className = 'wnHead'; h.style.animationDelay = (k++ * 0.07) + 's';
      h.textContent = `v${cl.v} · ${cl.title}`; box.appendChild(h);
      for (const [ic, nm, ds] of cl.items) {
        const el = document.createElement('div'); el.className = 'wnItem' + (i > 0 ? ' old' : ''); el.style.animationDelay = (k++ * 0.07) + 's';
        el.innerHTML = `<div class="ic">${ic}</div><div><b>${nm}</b><span>${ds}</span></div>`;
        box.appendChild(el);
      }
    });
    wnBack = state === 'whatsnew' ? wnBack : state;
    setState('whatsnew');
    confetti = []; cancelAnimationFrame(confRaf); confRaf = requestAnimationFrame(confLoop);
    Sound.sfx.win();
  }
  function closeWhatsNew() {
    cancelAnimationFrame(confRaf);
    const prof = loadProfile(); prof.lastVersion = VERSION; saveProfile(prof);
    if (wnBack === 'menu') openMenu(); else setState(wnBack);
  }

  // ------------------------------------------------------------------
  //  Глава 4: загадка
  // ------------------------------------------------------------------
  let teaserBack = 'menu', teaserRaf = 0, teaserImg = null, teaserT0 = 0, teaserGlow = 0;
  const TEASER_LINES = ['Хорошая… или добрая?..', 'Спит двадцать часов в сутки – но видит всё.', 'Голубые глаза. Мягкие лапки. Острые коготки.',
    'Говорят, она знает, где Зямочкккк прячет корм.', 'Глава 4. Скоро.', 'Мяу.'];
  function teaserLoop(now) {
    const cv = $('teaserCanvas'), c = cv.getContext('2d'), t = (now - teaserT0) / 1000;
    c.clearRect(0, 0, 480, 640);
    const br = 1 + Math.sin(t * 1.4) * 0.012;
    c.save(); c.translate(240, 320); c.scale(br, br); c.translate(-240, -320);
    c.filter = `brightness(${(0.42 + teaserGlow * 0.6).toFixed(2)}) blur(${Math.max(0, 1.4 - teaserGlow * 1.4).toFixed(2)}px)`;
    if (teaserImg) c.drawImage(teaserImg, 0, 0, 480, 640);
    c.filter = 'none';
    c.restore();
    const vg = c.createRadialGradient(240, 300, 120, 240, 320, 400);
    vg.addColorStop(0, 'rgba(0,0,0,0)'); vg.addColorStop(1, 'rgba(0,0,0,0.85)');
    c.fillStyle = vg; c.fillRect(0, 0, 480, 640);
    const g = (0.25 + 0.2 * Math.sin(t * 2)) + teaserGlow;
    for (const [ex, ey] of [[0.345, 0.322], [0.555, 0.322]]) {
      const x = ex * 480, y = ey * 640;
      const gr = c.createRadialGradient(x, y, 0, x, y, 26);
      gr.addColorStop(0, `rgba(120,200,255,${clamp(g, 0, 1) * 0.55})`); gr.addColorStop(1, 'rgba(120,200,255,0)');
      c.fillStyle = gr; c.fillRect(x - 30, y - 30, 60, 60);
      c.strokeStyle = `rgba(180,230,255,${clamp(g, 0, 1) * 0.8})`; c.lineWidth = 2.5;
      c.beginPath(); c.ellipse(x, y, 12, 2.4, 0, 0, TAU); c.stroke();
    }
    teaserGlow = Math.max(0, teaserGlow - 0.02);
    teaserRaf = requestAnimationFrame(teaserLoop);
  }
  function openTeaser() {
    teaserBack = state === 'teaser' ? teaserBack : state;
    setState('teaser');
    const box = $('teaserLines'); box.innerHTML = '';
    TEASER_LINES.forEach((ln, i) => {
      const el = document.createElement('div'); el.className = 'tline' + (i === TEASER_LINES.length - 1 ? ' meow' : '');
      el.textContent = ln; el.style.animationDelay = (0.6 + i * 1.15) + 's'; box.appendChild(el);
    });
    if (!teaserImg) { teaserImg = new Image(); teaserImg.src = 'ch4_shadow.jpg'; }
    teaserT0 = performance.now(); cancelAnimationFrame(teaserRaf); teaserRaf = requestAnimationFrame(teaserLoop);
    Sound.music(null);
    setTimeout(() => { if (state === 'teaser') { Sound.sfx.meow(); teaserGlow = 0.6; } }, (0.6 + (TEASER_LINES.length - 1) * 1.15) * 1000);
  }
  function closeTeaser() { cancelAnimationFrame(teaserRaf); if (teaserBack === 'menu') openMenu(); else setState(teaserBack); }

  // ------------------------------------------------------------------
  //  Прогресс: миграция старых сохранений
  // ------------------------------------------------------------------
  function migrateProfile() {
    const prof = loadProfile();
    const s2 = loadSave(2), s3 = loadSave(3);
    if (s2 || s3 || prof.ch2Done || prof.ch3Done) prof.ch1Done = true;
    if (s3 || prof.ch3Done) prof.ch2Done = true;
    if (prof.ch2Done && !prof.carry2) {
      // 0.02 не запоминала героиню после главы 2 – восстанавливаем
      if (s3) prof.carry2 = { level: s3.level, up: s3.up, bonus: s3.bonus || {}, shards: s3.shards || 0 };
      else {
        const L = Math.max(46, prof.carry ? prof.carry.level : 0), rb = refBuild(L);
        prof.carry2 = { level: L, up: rb.up, bonus: rb.bonus, shards: L * 3, restored: true };
      }
    }
    if (!prof.settings) prof.settings = { diff: 'normal' };
    // 0.10: прокачка своя в каждой главе. Звёзды – за всех уже побеждённых боссов,
    // незаконченные главы начинаются заново (старые уровни с новыми не стыкуются)
    if (!prof.prog2) {
      prof.starsGot = prof.starsGot || {};
      for (const n of [1, 2, 3, 4, 5, 6]) {
        const C = CHAPTERS[n]; if (!C) continue;
        const sv = loadSave(n);
        C.bosses.forEach((k, i) => { if (prof['ch' + n + 'Done'] || (sv && sv.defeated && sv.defeated[i])) prof.starsGot[n + ':' + i] = 1; });
        if (sv && (sv.v || 0) < 5) { prof.restarted = (prof.restarted || []).concat(n); try { localStorage.removeItem(saveKey(n)); } catch (e) { /* ignore */ } }
      }
      prof.stars = Object.keys(prof.starsGot).length;
      prof.talents = prof.talents || {};
      delete prof.hero;
      prof.prog2 = true;
    }
    saveProfile(prof);
    return prof;
  }

  // ------------------------------------------------------------------
  //  Финальная сцена
  // ------------------------------------------------------------------
  function startVictoryCutscene() {
    recordRunEnd('глава пройдена');
    G.cutscene = { t: 0 };
    G.enemies.forEach(e => burst(e.x, e.y, 8, '#fff', 100));
    G.enemies.length = 0; G.ebullets.length = 0; G.hazards.length = 0; G.beams.length = 0;
    showBanner('ПОБЕДА!', bosses[bosses.length - 1].name + ' повержен');
    Sound.music('win');
    const prof = loadProfile();
    const build = { level: P.level, up: P.up, bonus: P.bonus, shards: P.shards };
    prof['ch' + CHN + 'Done'] = true;
    prof[CHN === 1 ? 'carry' : 'carry' + CHN] = build;
    saveProfile(prof);
    try { localStorage.removeItem(saveKey(CHN)); } catch (e) { /* ignore */ }
  }
  function updateCutscene(dt) {
    const cs = G.cutscene; cs.t += dt;
    if (cs.kind === 'teamup') { updateTeamUp(dt, cs); return; }
    if (CFG.noCage) {
      P.moving = false; P.t += dt;
      if (Math.random() < 0.3) part(P.x + rnd(-60, 60), P.y + rnd(-70, 10), 0, -40, 1.4, 6, CHN === 4 ? '#3ff0a0' : '#ffd25a');
      if (cs.t > 3.5 && !G.victoryShown) { G.victoryShown = true; if (CHN === 4) openChoice(); else showVictory(); }
      return;
    }
    const cx = tc(CAGE.x), cy = tc(CAGE.y);
    const dx = cx - 80 - P.x, dy = cy + 30 - P.y, d = Math.hypot(dx, dy);
    if (cs.t > 4 && d > 4) { const s = Math.min(d, 220 * dt); P.x += dx / d * s; P.y += dy / d * s; P.moving = true; P.face = dx > 0 ? 1 : -1; }
    else { P.moving = false; if (cs.t > 4) P.face = 1; }
    P.t += dt;
    if (cs.t > 5.5 && G.cageOpen < 1) {
      G.cageOpen = Math.min(1, G.cageOpen + dt / 1.5);
      if (Math.random() < 0.5) part(cx + rnd(-30, 30), cy + rnd(-40, 20), rnd(-30, 30), rnd(-90, -30), 1, 4, pick(['#ffd25a', '#ff7a2f', '#ff9db5']));
      if (G.cageOpen >= 1) { say(['', 'Спасибо, Крилесса! Ты меня спасла! ❤', 'Крилесса, ты лучшая! Больше никаких кринж-стихов! ❤', 'Рыжовая, ты меня спасла! Теперь мы квиты! ❤🔥'][CHN], 5); Sound.sfx.win(); }
    }
    if (G.cageOpen >= 1 && Math.random() < 0.3) part(cx + rnd(-60, 60), cy + rnd(-60, 20), 0, -40, 1.4, 6, '#ff5b8a');
    if (cs.t > 11 && !G.victoryShown) { G.victoryShown = true; showVictory(); }
  }

  // ------------------------------------------------------------------
  //  Рендер
  // ------------------------------------------------------------------
  function drawCage(c, x, y, open, t) {
    shadow(c, x, y + 32, 40, 10);
    const bob = Math.sin(t * 2) * 3 - open * 14;
    const R = 26 + open * 16;
    if (CFG.hostage === 'krilessa') {
      if (open > 0) { c.fillStyle = `rgba(255,210,90,${open * 0.35})`; c.beginPath(); c.arc(x, y - 6 + bob, R + 14, 0, TAU); c.fill(); }
      drawKrilessa(c, x, y + 16 + bob, t, 1, 1.6 + open * 0.4, 1, open > 0);
    } else if (ART.ryzhovaSmall) {
      if (open > 0) { c.fillStyle = `rgba(255,210,90,${open * 0.35})`; c.beginPath(); c.arc(x, y - 6 + bob, R + 14, 0, TAU); c.fill(); }
      c.save(); c.beginPath(); c.arc(x, y - 6 + bob, R, 0, TAU); c.clip();
      c.drawImage(ART.ryzhovaSmall, x - R, y - 6 - R + bob, R * 2, R * 2); c.restore();
      c.strokeStyle = '#ff7a2f'; c.lineWidth = 3; c.beginPath(); c.arc(x, y - 6 + bob, R, 0, TAU); c.stroke();
    }
    const lift = open * 90;
    c.globalAlpha = 1 - open * 0.8;
    const gold = CHN === 2 ? '#ff3ea5' : CHN === 3 ? '#bfeaff' : '#ffd25a', dark = CHN === 2 ? '#a0206a' : CHN === 3 ? '#6a8ab8' : '#d9a520';
    c.fillStyle = '#7a5a1a'; c.beginPath(); c.ellipse(x, y + 28, 38, 9, 0, 0, TAU); c.fill();
    c.fillStyle = gold; c.beginPath(); c.ellipse(x, y + 25, 38, 8, 0, 0, TAU); c.fill();
    c.strokeStyle = dark; c.lineWidth = 3;
    for (let i = 0; i < 7; i++) { const bx = x - 33 + i * 11; c.beginPath(); c.moveTo(bx, y + 25 - lift); c.lineTo(bx, y - 38 - lift); c.stroke(); }
    c.lineWidth = 4;
    c.beginPath(); c.ellipse(x, y - 38 - lift, 34, 12, 0, Math.PI, TAU); c.stroke();
    c.beginPath(); c.moveTo(x - 34, y - 38 - lift); c.lineTo(x + 34, y - 38 - lift); c.stroke();
    c.fillStyle = gold; c.beginPath(); c.arc(x, y - 52 - lift, 5, 0, TAU); c.fill();
    c.globalAlpha = 1;
  }
  function drawBoss(c, b) {
    const t = b.anim;
    shadow(c, b.x, b.y + b.r * 0.75, b.r * 0.9 * (1 - Math.min(0.5, b.z / 260)), b.r * 0.28);
    c.save();
    const sx = b.mode === 'trans' ? Math.sin(t * 50) * 4 : 0;
    c.translate(b.x + sx, b.y - b.z);
    c.globalAlpha = b.alpha;
    BSPR[b.def.sprite || b.kind](c, b, t, P.x > b.x ? 1 : -1);
    c.restore();
    if (b.kind === 'zyama2' || b.kind === 'zyamaInf') {
      const inf = b.kind === 'zyamaInf';
      c.save(); c.translate(b.x + 30, b.y - b.z - 74 + (inf ? Math.sin(t * 4) * 3 : 0)); c.rotate(inf ? Math.sin(t * 2) * 0.25 : 0.2);
      c.fillStyle = inf ? RAINBOW[Math.floor(t * 6) % RAINBOW.length] : '#ff3ea5'; roundRect(c, -16, -10, 32, 20, 6); c.fill();
      c.fillStyle = '#fff'; c.font = inf ? '900 18px sans-serif' : '900 13px sans-serif'; c.textAlign = 'center'; c.fillText(inf ? '∞' : '2.0', 0, inf ? 6 : 5);
      c.restore();
    }
    if (b.shield) {
      const g = 0.5 + Math.sin(t * 6) * 0.3;
      c.strokeStyle = `rgba(191,234,255,${0.6 + g * 0.3})`; c.lineWidth = 5;
      c.fillStyle = `rgba(191,234,255,${0.12 + g * 0.08})`;
      c.beginPath(); c.arc(b.x, b.y - b.z - 10, b.r + 26, 0, TAU); c.fill(); c.stroke();
    }
    if (b.stunT > 0) {
      for (let k = 0; k < 3; k++) { const a = t * 4 + k * TAU / 3; c.fillStyle = '#ffe04a'; star(c, b.x + Math.cos(a) * 30, b.y - b.r - 30 + Math.sin(a) * 8, 7, t); c.fill(); }
    }
    if (b.burnT > 0 && Math.random() < 0.4) part(b.x + rnd(-b.r, b.r), b.y + rnd(-b.r, b.r * 0.5), 0, -60, 0.5, 5, '#ff8a2a');
    if (b.mode === 'trans') {
      c.strokeStyle = `rgba(255,255,255,${0.4 + Math.sin(t * 20) * 0.3})`; c.lineWidth = 4;
      c.beginPath(); c.arc(b.x, b.y - b.z, b.r + 18 + Math.sin(t * 10) * 4, 0, TAU); c.stroke();
    }
  }
  const FX_COL = { dark: '199,125,255', crystal: '91,227,255', honey: '255,200,40', lava: '255,100,30', glitch: '63,240,160',
    bolt: '255,240,120', toxic: '110,255,60', rainbow: '255,120,220', cream: '255,255,255', meteor: '255,120,30' };
  function drawHazard(c, h) {
    if (h.kind === 'wave') {
      c.strokeStyle = 'rgba(255,80,60,0.85)'; c.lineWidth = h.thick;
      c.beginPath(); c.arc(h.x, h.y, h.r, 0, TAU); c.stroke();
      c.strokeStyle = 'rgba(255,230,180,0.9)'; c.lineWidth = 3;
      c.beginPath(); c.arc(h.x, h.y, h.r, 0, TAU); c.stroke();
      return;
    }
    if (h.kind === 'zone') {
      const a = clamp(h.t / 0.4, 0, 1) * clamp((h.delay + h.dur - h.t) / 0.5, 0, 1);
      const col = FX_COL[h.fx] || '255,200,40';
      c.fillStyle = `rgba(${col},${0.32 * a})`; c.beginPath(); c.arc(h.x, h.y, h.r, 0, TAU); c.fill();
      c.strokeStyle = `rgba(${col},${0.7 * a})`; c.lineWidth = 2; c.stroke();
      return;
    }
    const k = clamp(h.t / h.delay, 0, 1);
    const col = FX_COL[h.fx] || '255,40,40';
    if (!h.done) {
      c.fillStyle = `rgba(${col},0.18)`; c.strokeStyle = `rgba(${col},0.85)`; c.lineWidth = 2;
      if (h.kind === 'circle') {
        c.beginPath(); c.arc(h.x, h.y, h.r, 0, TAU); c.fill(); c.stroke();
        c.fillStyle = `rgba(${col},0.32)`; c.beginPath(); c.arc(h.x, h.y, h.r * k, 0, TAU); c.fill();
        if (h.fx === 'meteor') { const fx = h.x + 230 * (1 - k), fy = h.y - 330 * (1 - k); drawFireball(c, fx, fy, Math.atan2(330, -230), 2.4); }
        if (h.fx === 'icicle' || h.fx === 'rain') { c.fillStyle = '#e6fbff'; c.beginPath(); c.moveTo(h.x - 7, h.y - 260 * (1 - k) - 30); c.lineTo(h.x + 7, h.y - 260 * (1 - k) - 30); c.lineTo(h.x, h.y - 260 * (1 - k)); c.fill(); }
      } else {
        c.save(); c.translate(h.x, h.y); c.rotate(h.ang);
        c.fillRect(0, -h.w / 2, h.len, h.w); c.strokeRect(0, -h.w / 2, h.len, h.w);
        c.fillStyle = `rgba(${col},0.32)`; c.fillRect(0, -h.w / 2, h.len * k, h.w);
        c.restore();
      }
    } else if (h.fx === 'tongue') {
      const a = 1 - (h.t - h.delay) / 0.3;
      c.save(); c.translate(h.x, h.y); c.rotate(h.ang); c.globalAlpha = clamp(a, 0, 1);
      c.fillStyle = '#ff6f91'; c.fillRect(0, -9, h.len, 18);
      c.beginPath(); c.arc(h.len, 0, 14, 0, TAU); c.fill(); c.restore();
    } else if (h.kind === 'line') {
      const a = clamp(1 - (h.t - h.delay) / 0.3, 0, 1);
      c.save(); c.translate(h.x, h.y); c.rotate(h.ang);
      c.fillStyle = `rgba(255,255,255,${a * 0.8})`; c.fillRect(0, -h.w / 2, h.len, h.w); c.restore();
    } else if (h.kind === 'circle') {
      const a = 1 - (h.t - h.delay) / 0.3;
      c.strokeStyle = `rgba(255,255,255,${clamp(a, 0, 1) * 0.8})`; c.lineWidth = 4;
      c.beginPath(); c.arc(h.x, h.y, h.r * (1 + (1 - a) * 0.3), 0, TAU); c.stroke();
    }
  }
  function drawBeam(c, bm) {
    if (bm.x === undefined) return;
    const ca = Math.cos(bm.ang), sa = Math.sin(bm.ang);
    if (bm.t < bm.warm) {
      c.strokeStyle = `rgba(255,60,60,${0.4 + Math.sin(bm.t * 30) * 0.3})`; c.lineWidth = 2;
      c.setLineDash([10, 8]); c.beginPath(); c.moveTo(bm.x, bm.y); c.lineTo(bm.x + ca * 560, bm.y + sa * 560); c.stroke(); c.setLineDash([]);
      return;
    }
    const col = bm.rainbow ? RAINBOW[Math.floor(bm.t * 10) % 7] : bm.mouth ? '#3ff0ff' : '#ff3ea5';
    c.lineCap = 'round';
    c.beginPath(); c.moveTo(bm.x, bm.y); c.lineTo(bm.x + ca * bm.len, bm.y + sa * bm.len);
    c.strokeStyle = col; c.globalAlpha = 0.35; c.lineWidth = bm.w * 1.6; c.stroke();
    c.globalAlpha = 1; c.lineWidth = bm.w * 0.7; c.stroke();
    c.strokeStyle = '#ffffff'; c.lineWidth = bm.w * 0.25; c.stroke();
    c.lineCap = 'butt';
  }
  function drawPickup(c, p) {
    const bob = Math.sin(p.t * 5 + p.x) * 2;
    if (p.kind === 'xp') {
      const col = p.v >= 30 ? '#ffd23a' : p.v >= 10 ? '#d36bff' : p.v >= 3 ? '#4dff9a' : '#5bc8ff';
      const s = p.v >= 30 ? 9 : p.v >= 10 ? 8 : p.v >= 3 ? 6.5 : 5;
      c.fillStyle = col; c.strokeStyle = 'rgba(255,255,255,0.8)'; c.lineWidth = 1.5;
      c.beginPath(); c.moveTo(p.x, p.y - s + bob); c.lineTo(p.x + s * 0.7, p.y + bob); c.lineTo(p.x, p.y + s + bob); c.lineTo(p.x - s * 0.7, p.y + bob); c.closePath(); c.fill(); c.stroke();
    } else if (p.kind === 'heart') {
      c.fillStyle = '#ff3b5c'; c.strokeStyle = '#fff'; c.lineWidth = 2;
      heartPath(c, p.x, p.y + bob, 11); c.fill(); c.stroke();
    } else if (p.kind === 'shard') {
      const s = SHARDS[p.sid];
      const g = 0.5 + Math.sin(p.t * 6) * 0.3;
      c.fillStyle = s.col; c.globalAlpha = 0.3 * g; c.beginPath(); c.arc(p.x, p.y + bob, 13, 0, TAU); c.fill(); c.globalAlpha = 1;
      c.strokeStyle = '#fff'; c.lineWidth = 1.5;
      c.beginPath(); c.moveTo(p.x, p.y - 9 + bob); c.lineTo(p.x + 6, p.y - 2 + bob); c.lineTo(p.x + 3, p.y + 8 + bob); c.lineTo(p.x - 3, p.y + 8 + bob); c.lineTo(p.x - 6, p.y - 2 + bob); c.closePath(); c.fill(); c.stroke();
    } else if (p.kind === 'star') {
      c.fillStyle = `rgba(255,224,138,${0.3 + Math.sin(p.t * 6) * 0.15})`; c.beginPath(); c.arc(p.x, p.y + bob, 15, 0, TAU); c.fill();
      c.fillStyle = '#ffe08a'; c.strokeStyle = '#fff'; c.lineWidth = 2; star(c, p.x, p.y + bob, 10, p.t * 2); c.fill(); c.stroke();
    } else if (p.kind === 'key') {
      c.fillStyle = `rgba(255,210,90,${0.25 + Math.sin(p.t * 6) * 0.12})`; c.beginPath(); c.arc(p.x, p.y + bob, 14, 0, TAU); c.fill();
      const spr = emojiSprite('🔑', 18); c.drawImage(spr, p.x - spr.width / 4, p.y + bob - spr.height / 4, spr.width / 2, spr.height / 2);
    } else {
      c.fillStyle = '#5bc8ff'; c.strokeStyle = '#fff'; c.lineWidth = 2;
      star(c, p.x, p.y + bob, 11, p.t); c.fill(); c.stroke();
    }
  }
  function drawChest(c, ch) {
    const tell = ch.mimic && !ch.open && Math.sin(G.time * 1.3 + ch.x * 0.01) > 0.97;
    drawChestSprite(c, ch.x, ch.y, ch.tier || 'wood', ch.open, CHN, G.time, { twitch: tell, eyes: ch.mimic && !ch.open && (tell || hasRelic('compass')) });
  }
  function drawChestOld(c, ch) {
    shadow(c, ch.x, ch.y + 14, 18, 5);
    if (ch.open) {
      c.fillStyle = '#6b3d1f'; c.fillRect(ch.x - 16, ch.y - 4, 32, 18);
      c.fillStyle = '#3a1f0f'; c.fillRect(ch.x - 14, ch.y - 4, 28, 6);
      c.fillStyle = '#8b5530'; c.fillRect(ch.x - 16, ch.y - 22, 32, 10);
      return;
    }
    const g = Math.sin(G.time * 4 + ch.x) * 0.5 + 0.5;
    c.fillStyle = `rgba(255,210,90,${0.15 + g * 0.2})`; c.beginPath(); c.arc(ch.x, ch.y, 28, 0, TAU); c.fill();
    c.fillStyle = '#8b5530'; c.strokeStyle = '#3a1f0f'; c.lineWidth = 2;
    c.fillRect(ch.x - 16, ch.y - 10, 32, 24); c.strokeRect(ch.x - 16, ch.y - 10, 32, 24);
    c.fillStyle = '#a0643a'; c.fillRect(ch.x - 16, ch.y - 14, 32, 8);
    c.fillStyle = '#ffd25a'; c.fillRect(ch.x - 16, ch.y - 2, 32, 3); c.fillRect(ch.x - 3, ch.y - 5, 6, 8);
  }
  function drawShrine(c, s) {
    const g = 0.5 + Math.sin(G.time * 3 + s.x) * 0.5;
    const col = s.state === 'done' ? '199,125,255' : s.state === 'active' ? '255,70,70' : '91,227,255';
    if (s.state === 'active') {
      c.strokeStyle = `rgba(255,70,70,${0.25 + g * 0.2})`; c.lineWidth = 3; c.setLineDash([12, 10]);
      c.beginPath(); c.arc(s.x, s.y, 300, 0, TAU); c.stroke(); c.setLineDash([]);
    }
    c.fillStyle = `rgba(${col},${0.15 + g * 0.15})`; c.beginPath(); c.arc(s.x, s.y, 34, 0, TAU); c.fill();
    c.fillStyle = '#6a6a7a'; c.strokeStyle = '#2a2a3a'; c.lineWidth = 2;
    c.beginPath(); c.ellipse(s.x, s.y + 6, 24, 9, 0, 0, TAU); c.fill(); c.stroke();
    c.fillStyle = '#8a8a9a'; roundRect(c, s.x - 8, s.y - 30, 16, 36, 4); c.fill(); c.stroke();
    c.fillStyle = `rgb(${col})`; star(c, s.x, s.y - 16, 6 + g * 2, G.time, 4); c.fill();
    if (s.state === 'idle') {
      c.font = 'bold 10px sans-serif'; c.textAlign = 'center'; c.fillStyle = '#bff6ff';
      c.fillText('ИСПЫТАНИЕ', s.x, s.y - 40);
    } else if (s.state === 'done') {
      for (let k = 0; k < 3; k++) {
        const a0 = G.time * (2 + k);
        c.strokeStyle = `rgba(199,125,255,${0.55 - k * 0.13})`; c.lineWidth = 3;
        c.beginPath(); c.arc(s.x, s.y + 4, 16 + k * 8 + Math.sin(G.time * 3 + k) * 2, a0, a0 + 4.2); c.stroke();
      }
      c.font = 'bold 10px sans-serif'; c.textAlign = 'center'; c.fillStyle = '#e0b0ff';
      c.fillText('ПОРТАЛ', s.x, s.y - 40);
    }
  }
  function drawGate(c) {
    if (gateOpen) return;
    const h = CASTLE.half, neon = CHN >= 2;
    let x, y, w, hh;
    if (CASTLE.gate === 'west') { x = (CASTLE.x - h) * T; y = (CASTLE.y - 1) * T; w = T; hh = T * 3; }
    else if (CASTLE.gate === 'east') { x = (CASTLE.x + h) * T; y = (CASTLE.y - 1) * T; w = T; hh = T * 3; }
    else { x = (CASTLE.x - 1) * T; y = (CASTLE.y + h) * T; w = T * 3; hh = T; }
    const iceG = BIOMES[CASTLE.biome].castleStyle === 'ice';
    c.fillStyle = iceG ? '#2a4a6a' : '#2a1f33'; c.fillRect(x, y, w, hh);
    c.strokeStyle = iceG ? '#bfeaff' : neon ? '#ff3ea5' : '#8a8a96'; c.lineWidth = 4;
    if (w < hh) { for (let i = 0; i < 7; i++) { c.beginPath(); c.moveTo(x + 4, y + 8 + i * 17); c.lineTo(x + w - 4, y + 8 + i * 17); c.stroke(); } }
    else { for (let i = 0; i < 7; i++) { c.beginPath(); c.moveTo(x + 8 + i * 17, y + 4); c.lineTo(x + 8 + i * 17, y + hh - 4); c.stroke(); } }
    const g = 0.5 + Math.sin(G.time * 3) * 0.3;
    c.fillStyle = iceG ? `rgba(127,216,255,${g * 0.45})` : `rgba(199,125,255,${g * 0.5})`; c.fillRect(x - 4, y - 4, w + 8, hh + 8);
    c.font = 'bold 16px sans-serif'; c.textAlign = 'center';
    c.fillText('🔒', x + w / 2, y + hh / 2 + 6);
  }
  function drawEnemy(c, e) {
    const lift = e.fly ? 8 : 0;
    let sc = 1, alpha = 1;
    if (e.spawnT > 0) {
      const k = 1 - e.spawnT / 0.45; sc = 0.3 + 0.7 * k; alpha = k;
      c.fillStyle = `rgba(199,125,255,${(1 - k) * 0.6})`; c.beginPath(); c.ellipse(e.x, e.y + e.r * 0.6, e.r * 1.6, e.r * 0.6, 0, 0, TAU); c.fill();
    }
    if (e.blink > 0) alpha = clamp(e.blink / 0.55, 0.15, 1);
    shadow(c, e.x, e.y + e.r * 0.7, e.r * 0.85, e.r * 0.3);
    const evId = G.ev ? G.ev.def.id : null;
    if (evId === 'rage' && e.spawnT <= 0) {
      const g = 0.5 + Math.sin(e.t * 8 + (e.seed || 0)) * 0.5;
      c.fillStyle = `rgba(255,30,30,${0.2 + g * 0.2})`; c.beginPath(); c.arc(e.x, e.y - lift, e.r + 9, 0, TAU); c.fill();
    }
    if (e.elite) {
      const g = 0.5 + Math.sin(e.t * 5) * 0.5;
      c.fillStyle = `rgba(255,210,60,${0.18 + g * 0.15})`; c.beginPath(); c.arc(e.x, e.y - lift, e.r + 10, 0, TAU); c.fill();
      if (e.champion) { c.strokeStyle = `rgba(255,210,60,${0.6 + g * 0.4})`; c.lineWidth = 3; c.beginPath(); c.arc(e.x, e.y - lift, e.r + 15 + g * 3, 0, TAU); c.stroke(); }
    }
    if (e.def.ai === 'charger' && e.wind > 0) {
      c.fillStyle = `rgba(255,40,40,${0.25 + Math.sin(e.t * 30) * 0.1})`;
      c.save(); c.translate(e.x, e.y); c.rotate(e.dashAng); c.fillRect(0, -e.r, 210, e.r * 2); c.restore();
    }
    if (e.healing > 0) {
      c.strokeStyle = e.def.ai === 'buffer' ? 'rgba(255,140,198,0.8)' : 'rgba(125,255,154,0.8)'; c.lineWidth = 3;
      for (const o of e.healTargets) { if (o.dead) continue; c.beginPath(); c.moveTo(e.x, e.y); c.lineTo(o.x, o.y); c.stroke(); }
    }
    c.save(); c.translate(e.x, e.y - lift);
    if (evId === 'song' && !e.minion) { const ph = G.ev.t * 9 + (e.seed || 0); c.translate(0, -Math.abs(Math.sin(ph)) * 6); c.rotate(Math.sin(ph) * 0.3); }
    c.globalAlpha = alpha;
    const s = sc * (e.elite ? 1.35 : 1);
    if (s !== 1) c.scale(s, s);
    // у зеркальных спрайтов (волк, скорпион) взгляд не нужен
    ESPR[e.sprite](c, e);
    c.restore();
    if (e.def.ai === 'shield' && e.spawnT <= 0) { c.save(); c.translate(e.x, e.y - lift); drawEnemyShield(c, e, e.col); c.restore(); }
    if (e.flash > 0) { c.fillStyle = 'rgba(255,255,255,0.55)'; c.beginPath(); c.arc(e.x, e.y - lift, e.r, 0, TAU); c.fill(); }
    if (e.slowT > 0) { c.strokeStyle = 'rgba(150,220,255,0.7)'; c.lineWidth = 2; c.beginPath(); c.arc(e.x, e.y - lift, e.r + 3, 0, TAU); c.stroke(); }
    if (e.buffT > 0) { c.fillStyle = 'rgba(255,140,198,0.22)'; c.strokeStyle = 'rgba(255,140,198,0.7)'; c.lineWidth = 2; c.beginPath(); c.arc(e.x, e.y - lift, e.r + 6, 0, TAU); c.fill(); c.stroke(); }
    if (e.burnT > 0 && Math.random() < 0.25) part(e.x + rnd(-e.r, e.r) * 0.6, e.y - lift, rnd(-10, 10), -50, 0.4, 3, '#ff8a2a');
    if (e.elite) {
      const af = AFFIXES.find(a => a.id === e.affix);
      c.font = 'bold 10px sans-serif'; c.textAlign = 'center'; c.fillStyle = af ? af.col : '#ffd25a';
      if (e.champion) { c.font = '900 12px sans-serif'; c.fillStyle = '#ffd25a'; c.fillText('👑 Чемпион · ' + e.name, e.x, e.y - e.r - 20 - lift); }
      else c.fillText('★ ' + (af ? af.name : 'ЭЛИТА'), e.x, e.y - e.r - 18 - lift);
    }
    if (e.hp < e.maxHp && e.spawnT <= 0) {
      const w = e.elite ? 36 : 24;
      c.fillStyle = 'rgba(0,0,0,0.6)'; c.fillRect(e.x - w / 2, e.y - e.r - 12 - lift, w, 4);
      c.fillStyle = e.elite ? '#ffd25a' : '#ff4d4d'; c.fillRect(e.x - w / 2, e.y - e.r - 12 - lift, w * clamp(e.hp / e.maxHp, 0, 1), 4);
    }
  }
  function drawFeather(c, x, y, a, s) {
    c.save(); c.translate(x, y); c.rotate(a); c.scale(s, s);
    c.fillStyle = 'rgba(150,225,255,0.35)'; c.beginPath(); c.ellipse(-8, 0, 10, 4, 0, 0, TAU); c.fill();
    c.fillStyle = P.frost ? '#cdf6ff' : '#ffffff'; c.strokeStyle = P.explode ? '#ff8a2a' : '#7b4dff'; c.lineWidth = 1.2;
    c.beginPath(); c.moveTo(9, 0); c.quadraticCurveTo(0, -5, -8, 0); c.quadraticCurveTo(0, 5, 9, 0); c.fill(); c.stroke();
    c.beginPath(); c.moveTo(9, 0); c.lineTo(-10, 0); c.stroke();
    c.restore();
  }
  function drawBubble(c, x, y, text, a, minX, maxX) {
    c.save(); c.globalAlpha = a; c.font = 'bold 12px sans-serif';
    const lines = []; let ln = '';
    for (const w of text.split(' ')) { const t = ln ? ln + ' ' + w : w; if (ln && c.measureText(t).width > 180) { lines.push(ln); ln = w; } else ln = t; }
    if (ln) lines.push(ln);
    const w = Math.max(...lines.map(l => c.measureText(l).width)) + 16, h = lines.length * 15 + 9, by = y - h;
    const bx = clamp(x - w / 2, minX + 6, maxX - w - 6); x = clamp(x, bx + 12, bx + w - 12);
    c.fillStyle = 'rgba(255,255,255,0.95)'; roundRect(c, bx, by, w, h, 9); c.fill();
    c.beginPath(); c.moveTo(x - 7, y - 1); c.lineTo(x + 7, y - 1); c.lineTo(x, y + 9); c.fill();
    c.strokeStyle = '#ff3ea5'; c.lineWidth = 1.5; roundRect(c, bx, by, w, h, 9); c.stroke();
    c.fillStyle = '#3a0a3a'; c.textAlign = 'center';
    lines.forEach((l, i) => c.fillText(l, bx + w / 2, by + 16 + i * 15));
    c.restore();
  }
  function renderWorld() {
    const c = ctx;
    const vw = VW / ZOOM, vh = VH / ZOOM;
    const shx = G.shake ? rnd(-G.shake, G.shake) * 0.6 : 0, shy = G.shake ? rnd(-G.shake, G.shake) * 0.6 : 0;
    const camX = G.cam.x + shx, camY = G.cam.y + shy;
    const s = DPR * ZOOM;
    c.setTransform(s, 0, 0, s, Math.round(DPR * VW / 2 - camX * s), Math.round(DPR * VH / 2 - camY * s));
    c.imageSmoothingEnabled = false;
    const x0 = camX - vw / 2, y0 = camY - vh / 2, x1 = x0 + vw, y1 = y0 + vh;
    c.fillStyle = '#0d0a14'; c.fillRect(x0 - 2, y0 - 2, vw + 4, vh + 4);
    for (let cy = Math.floor(y0 / CHPX); cy <= Math.floor(y1 / CHPX); cy++) {
      for (let cx = Math.floor(x0 / CHPX); cx <= Math.floor(x1 / CHPX); cx++) {
        if (cx < 0 || cy < 0 || cx * CHUNK >= MW || cy * CHUNK >= MH) continue;
        c.drawImage(getChunk(cx, cy), cx * CHPX, cy * CHPX);
      }
    }
    c.imageSmoothingEnabled = true;
    // заранее строим один соседний кусок карты за кадр – без рывков при беге
    if (state === 'play') {
      let built = false;
      for (let cy = Math.floor(y0 / CHPX) - 1; cy <= Math.floor(y1 / CHPX) + 1 && !built; cy++)
        for (let cx = Math.floor(x0 / CHPX) - 1; cx <= Math.floor(x1 / CHPX) + 1 && !built; cx++) {
          if (cx < 0 || cy < 0 || cx * CHUNK >= MW || cy * CHUNK >= MH || chunkCache.has(cx + ',' + cy)) continue;
          getChunk(cx, cy); built = true;
        }
    }
    const vis = (x, y, m) => x > x0 - m && x < x1 + m && y > y0 - m && y < y1 + m;
    drawGate(c);
    for (const sh of shrines) if (vis(sh.x, sh.y, 320)) drawShrine(c, sh);
    if (!CFG.dark && !(G.caveA > 0.5)) for (const h of G.hazards) drawHazard(c, h);
    drawHouseGround(c, vis);
    drawArenaExit(c);
    for (const hl of holes) if (vis(hl.x, hl.y, 70)) drawHole(c, hl, G.time);
    for (const ch of chests) if (vis(ch.x, ch.y, 40)) drawChest(c, ch);
    for (const p of G.pickups) if (vis(p.x, p.y, 20)) drawPickup(c, p);
    if (state !== 'menu' && !G.cutscene) {
      c.save(); c.setLineDash([7, 8]); c.strokeStyle = 'rgba(255,255,255,0.16)'; c.lineWidth = 1.5;
      c.beginPath(); c.arc(P.x, P.y, P.range, 0, TAU); c.stroke(); c.restore();
    }
    const items = [];
    const tx0 = Math.max(0, Math.floor(x0 / T) - 1), tx1 = Math.min(MW - 1, Math.floor(x1 / T) + 1);
    const ty0 = Math.max(0, Math.floor(y0 / T) - 1), ty1 = Math.min(MH - 1, Math.floor(y1 / T) + 3);
    for (let ty = ty0; ty <= ty1; ty++) for (let tx = tx0; tx <= tx1; tx++) {
      const ti = treeGrid[ty * MW + tx];
      if (ti) items.push({ y: trees[ti - 1].y, tree: trees[ti - 1] });
    }
    for (const e of G.enemies) if (vis(e.x, e.y, 60)) items.push({ y: e.y, e });
    for (const b of bosses) if (b.state !== 'dead' && vis(b.x, b.y, 140) && (!CFG.rush || !G.rush || b.id === G.rush.idx)) items.push({ y: b.y, b });
    const ally = G.finalFinal && G.finalFinal.ally;
    if (ally && state !== 'menu') items.push({ y: ally.y, ally });
    const cageX = tc(CAGE.x), cageY = tc(CAGE.y);
    if (!CFG.noCage && vis(cageX, cageY, 80)) items.push({ y: cageY + 20, cage: true });
    if (CFG.team && CFG.hostage === 'tessa' && !G.tessaAlly && !G.cutscene && state !== 'menu' && vis(cageX, cageY, 90)) items.push({ y: cageY + 20, iceCage: true });
    for (const f of fires) if (vis(f.x, f.y, 100)) items.push({ y: f.y + 6, fire: f });
    for (const ov of ovens) if (vis(ov.x, ov.y, 80)) items.push({ y: ov.y + 20, oven: ov });
    for (const dr of drifts) if (!dr.done && vis(dr.x, dr.y, 50)) items.push({ y: dr.y + 8, drift: dr });
    if (G.team && state !== 'menu' && !G.cutscene) items.push({ y: G.team.by, buddy: true });
    if (G.tessaAlly && state !== 'menu') items.push({ y: G.tessaAlly.y, tessa: G.tessaAlly });
    if (state !== 'menu' && state !== 'dying' && state !== 'dead') items.push({ y: P.y, player: true });
    items.sort((a, b) => a.y - b.y);
    for (const it of items) {
      if (it.tree) {
        const tr = it.tree, spr = TREE_SPR[tr.kind];
        const w = 64 * tr.s, h = 84 * tr.s;
        const under = (x, y) => y < tr.y && y > tr.y - h * 0.95 && Math.abs(x - tr.x) < w * 0.5;
        const behind = state !== 'menu' && (under(P.x, P.y) || (G.activeBoss && under(G.activeBoss.x, G.activeBoss.y)));
        if (behind) c.globalAlpha = 0.42;
        c.drawImage(spr, tr.x - w / 2, tr.y - h + 5 * tr.s, w, h);
        c.globalAlpha = 1;
      } else if (it.e) drawEnemy(c, it.e);
      else if (it.b) drawBoss(c, it.b);
      else if (it.cage) drawCage(c, cageX, cageY, G.cageOpen, G.time);
      else if (it.iceCage) drawIceCage(c, cageX, cageY, G.time);
      else if (it.fire) drawCampfire(c, it.fire, G.time);
      else if (it.oven) drawOven(c, it.oven, G.time);
      else if (it.drift) drawDrift(c, it.drift, G.time);
      else if (it.buddy) {
        const T6 = G.team, o = teamOther(), ko = T6.ko[o];
        shadow(c, T6.bx, T6.by + 10, 10, 4);
        const tg = G.activeBoss || null;
        drawHero(o, c, T6.bx, T6.by, P.t, tg ? (tg.x > T6.bx ? 1 : -1) : P.face, 0.9, ko ? 0.45 : 0.92, P.moving);
        if (ko) { c.font = '14px sans-serif'; c.textAlign = 'center'; c.fillText('💤', T6.bx + 12, T6.by - 34 + Math.sin(P.t * 3) * 3); }
      }
      else if (it.tessa) {
        const A = it.tessa;
        shadow(c, A.x, A.y + 10, 10, 4);
        drawHero('tessa', c, A.x, A.y, P.t, A.face, 0.85, 1, true);
      }
      else if (it.ally) {
        const A = it.ally, ab = G.activeBoss || bosses[bosses.length - 1];
        shadow(c, A.x, A.y + 10, 11, 4);
        c.fillStyle = `rgba(191,234,255,${0.18 + Math.sin(P.t * 5) * 0.08})`; c.beginPath(); c.arc(A.x, A.y - 6, 26, 0, TAU); c.fill();
        drawHero('krilessa', c, A.x, A.y + Math.sin(P.t * 4) * 3, P.t, ab && ab.x > A.x ? 1 : -1, 1, 1, true);
      }
      else if (it.player) {
        const blink = P.inv > 0 && Math.floor(P.t * 20) % 2 === 0;
        shadow(c, P.x, P.y + 10, 11, 4);
        if (!(G.hidden && P.hero === 'tessa')) drawHero(P.hero, c, P.x, P.y - (P.z || 0), P.t, P.face, 1, blink ? 0.4 : 1, P.moving || P.dashT > 0 || !!G.jump);
        if (P.napT > 0) { c.fillStyle = `rgba(255,220,120,${0.25 + Math.sin(P.t * 4) * 0.1})`; c.beginPath(); c.arc(P.x, P.y - 6 - (P.z || 0), 20, 0, TAU); c.fill(); }
        if (P.stormT > 0) { c.strokeStyle = 'rgba(150,225,255,0.6)'; c.lineWidth = 3; c.beginPath(); c.arc(P.x, P.y - 6, 28 + Math.sin(P.t * 20) * 4, 0, TAU); c.stroke(); }
        if (P.shieldLv && P.shieldT <= 0) {
          c.strokeStyle = `rgba(127,232,255,${0.5 + Math.sin(P.t * 4) * 0.2})`; c.lineWidth = 2;
          c.beginPath(); c.arc(P.x, P.y - 6, 22, 0, TAU); c.stroke();
        }
        if (P.slowT > 0) { c.fillStyle = 'rgba(255,220,80,0.35)'; c.beginPath(); c.ellipse(P.x, P.y + 10, 16, 6, 0, 0, TAU); c.fill(); }
      }
    }
    if (G.hidden) drawBox(c, G.hidden, true);
    if (G.pet && state !== 'menu') drawPet(c);
    if (P.orbit && state !== 'menu' && !G.cutscene) {
      for (let k = 0; k < P.orbit; k++) {
        const a = P.orbA + (k / P.orbit) * TAU, ox = P.x + Math.cos(a) * 62, oy = P.y + Math.sin(a) * 62;
        if (P.proj === 'fire') drawFireball(c, ox, oy, a + Math.PI / 2, 1.2);
        else if (P.proj === 'claw') { c.fillStyle = '#ff6fb5'; c.beginPath(); c.arc(ox, oy, 7, 0, TAU); c.fill(); c.strokeStyle = '#c0306a'; c.lineWidth = 1.5; c.beginPath(); c.arc(ox, oy, 7, a, a + 2.4); c.stroke(); }
        else drawFeather(c, ox, oy, a + Math.PI / 2, 1.3);
      }
    }
    for (const z of G.pzones) {
      const a = clamp((z.dur - z.t) / 0.5, 0, 1);
      c.fillStyle = `rgba(255,120,30,${0.25 * a})`; c.beginPath(); c.arc(z.x, z.y, z.r, 0, TAU); c.fill();
    }
    for (const n of G.novas) {
      if (n.disco || n.life) {
        const a = clamp(1 - n.r / n.max, 0, 1) + 0.2;
        c.lineWidth = n.disco ? 7 : 14;
        c.strokeStyle = n.disco ? `hsla(${(G.time * 360) % 360},100%,70%,${a})` : `rgba(191,234,255,${a})`;
        c.beginPath(); c.arc(n.x, n.y, n.r, 0, TAU); c.stroke();
        continue;
      }
      if (n.purr) {
        c.lineWidth = 22; c.strokeStyle = 'rgba(255,140,200,0.4)'; c.beginPath(); c.arc(n.x, n.y, n.r, 0, TAU); c.stroke();
        c.lineWidth = 6; c.strokeStyle = 'rgba(255,220,240,0.9)'; c.stroke();
        for (let k = 0; k < 8; k++) { const a = k * TAU / 8 + n.r * 0.01; c.fillStyle = '#ff6fb5'; heartPath(c, n.x + Math.cos(a) * n.r, n.y + Math.sin(a) * n.r, 7); c.fill(); }
        continue;
      }
      c.lineWidth = 26; c.strokeStyle = 'rgba(255,90,20,0.45)'; c.beginPath(); c.arc(n.x, n.y, n.r, 0, TAU); c.stroke();
      c.lineWidth = 10; c.strokeStyle = 'rgba(255,220,80,0.9)'; c.stroke();
      c.lineWidth = 3; c.strokeStyle = '#ffffff'; c.stroke();
    }
    if (CFG.dark) { drawDarkness(c); for (const h of G.hazards) drawHazard(c, h); }
    for (const st of G.falling) {
      const k = clamp(st.t / st.dur, 0, 1), sx = st.x + (1 - k) * 140, sy = st.y - (1 - k) * 320;
      c.strokeStyle = `rgba(255,224,138,${0.25 + k * 0.5})`; c.lineWidth = 2; c.beginPath(); c.arc(st.x, st.y, 10 + (1 - k) * 26, 0, TAU); c.stroke();
      c.strokeStyle = 'rgba(255,240,190,0.6)'; c.lineWidth = 4; c.beginPath(); c.moveTo(sx, sy); c.lineTo(sx + 40, sy - 90); c.stroke();
      c.fillStyle = '#ffe08a'; star(c, sx, sy, 9, st.t * 8); c.fill();
    }
    drawCaveDark(c);
    drawBlizzard(c);
    for (const bm of G.beams) drawBeam(c, bm);
    // ДРУЖБА-СУПЕР: два луча сливаются в радугу
    const cs = G.cutscene;
    if (cs && cs.kind === 'teamup' && G.finalFinal) {
      const A = G.finalFinal.ally, tb = bosses[bosses.length - 1];
      if (cs.t < 0.8) {
        for (const [hx, hy, col] of [[P.x, P.y - 6, '255,140,40'], [A.x, A.y - 6, '120,200,255']]) {
          c.fillStyle = `rgba(${col},${0.25 + cs.t * 0.5})`; c.beginPath(); c.arc(hx, hy, 18 + cs.t * 30 + Math.sin(cs.t * 40) * 3, 0, TAU); c.fill();
        }
      } else if (cs.t < 3.2 && tb) {
        const mx = (P.x + A.x) / 2, my = (P.y + A.y) / 2 - 30, w = 10 + Math.sin(cs.t * 30) * 3;
        c.lineCap = 'round';
        for (const [hx, hy, col] of [[P.x, P.y - 6, '#ff8a2a'], [A.x, A.y - 6, '#7fd8ff']]) {
          c.strokeStyle = col; c.lineWidth = w; c.beginPath(); c.moveTo(hx, hy); c.lineTo(mx, my); c.stroke();
        }
        const ang = Math.atan2(tb.y - tb.z - my, tb.x - mx), len = Math.hypot(tb.x - mx, tb.y - tb.z - my);
        c.save(); c.translate(mx, my); c.rotate(ang);
        RAINBOW.forEach((col, i) => { c.fillStyle = col; c.fillRect(0, (i - RAINBOW.length / 2) * (w * 0.6), len, w * 0.6); });
        c.fillStyle = 'rgba(255,255,255,0.85)'; c.fillRect(0, -w * 0.4, len, w * 0.8);
        c.restore();
        c.fillStyle = '#ffffff'; c.beginPath(); c.arc(mx, my, w * 1.6, 0, TAU); c.fill();
        c.lineCap = 'butt';
      }
    }
    for (const f of G.feathers) {
      if (f.kind === 'fire') drawFireball(c, f.x, f.y, Math.atan2(f.vy, f.vx), 1);
      else if (f.kind === 'claw') drawClaw(c, f);
      else if (f.kind === 'pixel') { c.fillStyle = '#3ff0a0'; c.fillRect(f.x - 3, f.y - 3, 6, 6); c.fillStyle = '#ffffff'; c.fillRect(f.x - 3, f.y - 3, 2, 2); }
      else drawFeather(c, f.x, f.y, Math.atan2(f.vy, f.vx), 1);
    }
    for (const b of G.ebullets) {
      if (!vis(b.x, b.y, 20)) continue;
      if (b.saw) {
        c.save(); c.translate(b.x, b.y); c.rotate(b.rot);
        c.fillStyle = '#9aa4b8'; c.beginPath();
        for (let k = 0; k < 16; k++) { const rr = k % 2 ? b.r * 0.75 : b.r; const a = k / 16 * TAU; c.lineTo(Math.cos(a) * rr, Math.sin(a) * rr); }
        c.closePath(); c.fill(); c.strokeStyle = '#3a3a4a'; c.lineWidth = 1.5; c.stroke();
        c.fillStyle = '#ff3b3b'; c.beginPath(); c.arc(0, 0, 3, 0, TAU); c.fill();
        c.restore(); continue;
      }
      const spr = b.emoji ? emojiSprite(b.emoji, 18) : b.square ? squareSprite(b.col, b.r * 0.85) : bulletSprite(b.col, b.r);
      c.drawImage(spr, b.x - spr.width / 4, b.y - spr.height / 4, spr.width / 2, spr.height / 2);
    }
    for (const b of G.bolts) {
      c.strokeStyle = `rgba(${b.col || '190,230,255'},${clamp(b.t * 4, 0, 1)})`; c.lineWidth = 3;
      c.beginPath();
      for (let i = 0; i < b.pts.length - 1; i++) {
        const [ax, ay] = b.pts[i], [bx, by] = b.pts[i + 1];
        c.moveTo(ax, ay);
        for (let k = 1; k <= 4; k++) c.lineTo(lerp(ax, bx, k / 4) + (k < 4 ? rnd(-10, 10) : 0), lerp(ay, by, k / 4) + (k < 4 ? rnd(-10, 10) : 0));
      }
      c.stroke();
    }
    for (const r of G.rings) {
      c.strokeStyle = r.col; c.globalAlpha = clamp(1 - r.t / 0.45, 0, 1); c.lineWidth = 4;
      c.beginPath(); c.arc(r.x, r.y, r.r, 0, TAU); c.stroke(); c.globalAlpha = 1;
    }
    for (const p of G.parts) {
      c.globalAlpha = clamp(p.life / p.max, 0, 1); c.fillStyle = p.col;
      c.fillRect(p.x - p.size / 2, p.y - p.size / 2, p.size, p.size);
    }
    c.globalAlpha = 1;
    c.textAlign = 'center';
    for (const t of G.texts) {
      const life = t.big ? 1.1 : 0.8;
      c.globalAlpha = clamp(1 - t.t / life, 0, 1);
      c.font = t.big ? 'bold 17px sans-serif' : 'bold 13px sans-serif';
      c.fillStyle = '#000'; c.fillText(t.txt, t.x + 1, t.y - t.t * 30 + 1);
      c.fillStyle = t.col; c.fillText(t.txt, t.x, t.y - t.t * 30);
    }
    c.globalAlpha = 1;
    for (const b of bosses) if (b.bubble && b.state === 'fight') drawBubble(c, b.x, b.y - b.z - b.r - 30, b.bubble.text, clamp(b.bubble.t / 0.3, 0, 1), x0, x1);
    if (state === 'menu' || G.cutscene) return;
    const bw = 64, bx = P.x - bw / 2, by = P.y - 52;
    c.fillStyle = 'rgba(0,0,0,0.65)'; c.fillRect(bx - 2, by - 2, bw + 4, 13);
    c.fillStyle = P.hp < P.maxHp * 0.3 ? '#ff4d4d' : '#4cd964'; c.fillRect(bx, by, bw * clamp(P.hp / P.maxHp, 0, 1), 9);
    c.font = 'bold 9px sans-serif'; c.fillStyle = '#fff';
    c.fillText(`${Math.ceil(P.hp)}/${P.maxHp}` + (P.lives ? ` · 🐾${P.lives}` : ''), P.x, by + 8);
    if (!G.activeBoss && !G.activeShrine) {
      const o = objective();
      const dx = o.x - P.x, dy = o.y - P.y, d = Math.hypot(dx, dy);
      if (d > 170) {
        const a = Math.atan2(dy, dx), ax = P.x + Math.cos(a) * 82, ay = P.y + Math.sin(a) * 82 - 6;
        c.save(); c.translate(ax, ay); c.rotate(a);
        c.fillStyle = '#d6f03a'; c.strokeStyle = '#4a5a00'; c.lineWidth = 2;
        c.beginPath(); c.moveTo(14, 0); c.lineTo(-8, -11); c.lineTo(-3, 0); c.lineTo(-8, 11); c.closePath(); c.fill(); c.stroke();
        c.restore();
        c.font = 'bold 13px sans-serif'; c.fillStyle = '#000'; c.fillText(`${Math.round(d / PX_PER_M)} м`, ax + 1, ay + 27);
        c.fillStyle = '#fff'; c.fillText(`${Math.round(d / PX_PER_M)} м`, ax, ay + 26);
      }
    }
    if (G.champ && !G.champ.dead && !G.activeBoss) {
      const dx = G.champ.x - P.x, dy = G.champ.y - P.y;
      if (Math.hypot(dx, dy) > 260) {
        const a = Math.atan2(dy, dx), ax = P.x + Math.cos(a) * 62, ay = P.y + Math.sin(a) * 62 - 6;
        c.font = '15px sans-serif'; c.textAlign = 'center'; c.globalAlpha = 0.6 + 0.4 * Math.sin(G.time * 5); c.fillText('👑', ax, ay + 5); c.globalAlpha = 1;
      }
    }
  }

  function drawEventFx(c) {
    const ev = G.ev; if (!ev) return;
    const d = ev.def, fade = clamp(ev.t / 0.6, 0, 1) * clamp((d.dur - ev.t) / 0.8, 0, 1);
    const sx = (P.x - G.cam.x) * ZOOM + VW / 2, sy = (P.y - G.cam.y) * ZOOM + VH / 2;
    if (d.id === 'fog') {
      const g = c.createRadialGradient(sx, sy, 70, sx, sy, 250);
      g.addColorStop(0, 'rgba(36,28,56,0)'); g.addColorStop(1, `rgba(36,28,56,${0.93 * fade})`);
      c.fillStyle = g; c.fillRect(0, 0, VW, VH);
      return;
    }
    const pulse = d.id === 'rage' ? 0.6 + 0.3 * Math.sin(ev.t * 7) : 0.4 + 0.12 * Math.sin(ev.t * 3);
    const g = c.createRadialGradient(VW / 2, VH / 2, Math.min(VW, VH) * 0.25, VW / 2, VH / 2, Math.max(VW, VH) * 0.72);
    g.addColorStop(0, `rgba(${d.tint},0)`); g.addColorStop(1, `rgba(${d.tint},${0.55 * pulse * fade})`);
    c.fillStyle = g; c.fillRect(0, 0, VW, VH);
    if (d.id === 'rage') { c.fillStyle = `rgba(255,20,20,${(0.07 + 0.04 * Math.sin(ev.t * 7)) * fade})`; c.fillRect(0, 0, VW, VH); }
  }
  function drawEventPill(c, x, y) {
    const ev = G.ev;
    if (ev) {
      const d = ev.def, left = Math.max(0, d.dur - ev.t);
      c.fillStyle = `rgba(${d.tint},0.85)`; roundRect(c, x, y, 156, 24, 8); c.fill();
      c.fillStyle = 'rgba(0,0,0,0.35)'; c.fillRect(x + 6, y + 18, 144, 3);
      c.fillStyle = '#fff'; c.fillRect(x + 6, y + 18, 144 * clamp(left / d.dur, 0, 1), 3);
      c.font = '900 11px sans-serif'; c.textAlign = 'left'; c.fillStyle = '#fff';
      c.fillText(`${d.ic} ${d.name}`, x + 6, y + 13);
      c.textAlign = 'right'; c.fillText(`${Math.ceil(left)}с`, x + 150, y + 13);
      return;
    }
    if (CFG.rush || G.cutscene || G.finalFinal || G.activeBoss || G.activeShrine) return;
    if (G.evT > 10) {
      const bi = curBiome(), cm = calmOf(bi);
      if (cm > 0) {
        const st = calmStage(bi), n = G.calm[bi], nx = CALM_STEPS[st + 1];
        c.fillStyle = 'rgba(30,110,130,0.8)'; roundRect(c, x, y, 156, 24, 8); c.fill();
        c.font = 'bold 11px sans-serif'; c.textAlign = 'left'; c.fillStyle = '#dffaff';
        c.fillText(`🕊️ Усмирение ${ROMAN[st]} · −${Math.round(cm * 100)}%`, x + 6, y + 13);
        c.textAlign = 'right'; c.font = 'bold 9px sans-serif'; c.fillText(nx ? `${n}/${nx}` : 'МАКС', x + 150, y + 13);
        c.fillStyle = 'rgba(0,0,0,0.35)'; c.fillRect(x + 6, y + 18, 144, 3);
        c.fillStyle = '#bff6ff'; c.fillRect(x + 6, y + 18, 144 * (nx ? clamp((n - CALM_STEPS[st]) / (nx - CALM_STEPS[st]), 0, 1) : 1), 3);
      }
      return;
    }
    c.fillStyle = 'rgba(0,0,0,0.5)'; roundRect(c, x, y, 156, 20, 8); c.fill();
    c.font = 'bold 11px sans-serif'; c.textAlign = 'left'; c.fillStyle = Math.floor(G.evT * 2) % 2 ? '#ffd25a' : '#ffffff';
    c.fillText(`🎲 Событие через ${Math.ceil(G.evT)}…`, x + 8, y + 14);
  }
  function renderHUD() {
    const c = ctx;
    c.setTransform(DPR, 0, 0, DPR, 0, 0);
    if (state === 'play' || state === 'pause' || state === 'levelup') { drawEventFx(c); drawHouseFx(c); }
    if (G.hurtFlash > 0) {
      const g = c.createRadialGradient(VW / 2, VH / 2, Math.min(VW, VH) * 0.3, VW / 2, VH / 2, Math.max(VW, VH) * 0.7);
      g.addColorStop(0, 'rgba(255,0,0,0)'); g.addColorStop(1, `rgba(255,0,0,${G.hurtFlash})`);
      c.fillStyle = g; c.fillRect(0, 0, VW, VH);
    }
    const top = SAFE_TOP + 10;
    const lx = 58;
    c.fillStyle = 'rgba(0,0,0,0.5)'; roundRect(c, lx, top, 156, 40, 10); c.fill();
    c.font = '900 14px sans-serif'; c.textAlign = 'left'; c.fillStyle = '#ffd25a';
    c.fillText(`Ур. ${P.level}`, lx + 8, top + 17);
    c.font = 'bold 11px sans-serif'; c.fillStyle = '#fff';
    const pbz = biomeMap[clamp(Math.floor(P.y / T), 0, MH - 1) * MW + clamp(Math.floor(P.x / T), 0, MW - 1)];
    if (CFG.rush && G.rush) c.fillText(`⚔️ Раш · ${Math.min(G.rush.idx + 1, G.rush.total)}/${G.rush.total} · ${fmtT(G.rush.t)}`, lx + 56, top + 17);
    else { const zl = zoneE(curBiome()); c.fillText(`Гл.${CHN} · Б ${G.defeated.filter(Boolean).length}/${CFG.bosses.length} · зона ${isFinite(zl) ? zl : '–'}`, lx + 56, top + 17); }
    c.fillStyle = 'rgba(255,255,255,0.15)'; c.fillRect(lx + 8, top + 25, 140, 7);
    c.fillStyle = '#5bc8ff'; c.fillRect(lx + 8, top + 25, 140 * clamp(P.xp / P.xpNext, 0, 1), 7);
    if (state === 'play') drawEventPill(c, lx, top + 46);
    // мини-карта
    const ms = Math.min(124, VW * 0.3), mx = VW - ms - 10, my = top;
    G.miniRect = { x: mx, y: my, s: ms };
    c.save();
    roundRect(c, mx - 3, my - 3, ms + 6, ms + 6, 12); c.fillStyle = 'rgba(255,255,255,0.85)'; c.fill();
    roundRect(c, mx, my, ms, ms, 10); c.clip();
    c.imageSmoothingEnabled = false;
    c.drawImage(miniBase, mx, my, ms, ms);
    c.globalAlpha = 0.72; c.drawImage(fog, mx, my, ms, ms); c.globalAlpha = 1;
    c.imageSmoothingEnabled = true;
    const k = ms / WORLD_W;
    c.fillStyle = '#ff3b3b';
    for (const e of G.enemies) c.fillRect(mx + e.x * k - 1.5, my + e.y * k - 1.5, 3, 3);
    c.fillStyle = '#ffd25a';
    for (const ch of chests) if (!ch.open && (ch.seen || (hasRelic('compass') && Math.hypot(ch.x - P.x, ch.y - P.y) < 1000))) {
      c.fillStyle = ch.tier === 'gold' ? '#ffd25a' : ch.tier === 'silver' ? '#e0eaff' : '#c8945a';
      c.fillRect(mx + ch.x * k - 1.5, my + ch.y * k - 1.5, 3, 3);
    }
    c.fillStyle = '#5be3ff';
    const blink = 0.35 + 0.65 * Math.abs(Math.sin(performance.now() / 380));
    for (const s of shrines) {
      const sx = mx + s.x * k, sy = my + s.y * k;
      if (s.state === 'done') { c.fillStyle = '#c77dff'; c.beginPath(); c.arc(sx, sy, 2.4, 0, TAU); c.fill(); continue; }
      c.globalAlpha = blink; c.fillStyle = '#5be3ff'; c.fillRect(sx - 2.5, sy - 2.5, 5, 5);
      c.strokeStyle = '#5be3ff'; c.lineWidth = 1; c.beginPath(); c.arc(sx, sy, 4 + blink * 2.5, 0, TAU); c.stroke(); c.globalAlpha = 1;
    }
    for (const bd of beds) { c.fillStyle = '#ff9ad0'; c.fillRect(mx + bd.x * k - 1.5, my + bd.y * k - 1.5, 3, 3); }
    for (const f of fires) if (!f.glade || f.lit) { c.fillStyle = '#ff8a2a'; c.beginPath(); c.arc(mx + f.x * k, my + f.y * k, 2.2, 0, TAU); c.fill(); }
    for (const q of clues) if (!q.found && (G.clearSight || G.revealT > 0 || (G.pet && Math.hypot(q.x - P.x, q.y - P.y) < 700) || Math.hypot(q.x - P.x, q.y - P.y) < 350 * lv('c5nose'))) {
      c.globalAlpha = blink; c.fillStyle = '#ffd25a'; c.beginPath(); c.arc(mx + q.x * k, my + q.y * k, 2.5, 0, TAU); c.fill(); c.globalAlpha = 1;
    }
    for (const n of npcs) { c.fillStyle = '#ffffff'; c.fillRect(mx + n.x * k - 2, my + n.y * k - 2, 4, 4); }
    for (const it of qitems) if (it.active && !it.taken) { c.globalAlpha = blink; c.fillStyle = '#7dff7d'; c.fillRect(mx + it.x * k - 2, my + it.y * k - 2, 4, 4); c.globalAlpha = 1; }
    if (G.champ && !G.champ.dead) { c.globalAlpha = blink; c.font = '10px sans-serif'; c.textAlign = 'center'; c.fillText('👑', mx + G.champ.x * k, my + G.champ.y * k + 4); c.globalAlpha = 1; }
    c.font = '10px sans-serif'; c.textAlign = 'center';
    for (const b of bosses) {
      if (CFG.rush && G.rush && b.id !== G.rush.idx) continue;
      c.fillText(b.def.immortal ? '♾️' : b.state === 'dead' ? '✅' : '💀', mx + b.hx * k, my + b.hy * k + 4);
    }
    if (!CFG.noCage || (CFG.team && !G.tessaAlly)) c.fillText('❤️', mx + tc(CAGE.x) * k, my + tc(CAGE.y) * k - 4);
    c.strokeStyle = '#fff'; c.lineWidth = 2; c.beginPath(); c.arc(mx + P.x * k, my + P.y * k, 4, 0, TAU); c.stroke();
    c.restore();
    c.font = 'bold 10px sans-serif'; c.textAlign = 'right'; c.fillStyle = '#000'; c.fillText('🗺️ нажми – карта', mx + ms + 1, my + ms + 15); c.fillStyle = 'rgba(255,255,255,0.85)'; c.fillText('🗺️ нажми – карта', mx + ms, my + ms + 14);
    // комбо
    if (G.combo >= 5) {
      const cy = top + ms + (G.activeBoss ? 70 : 30);
      c.globalAlpha = clamp(G.comboT / 0.6, 0, 1); c.textAlign = 'right';
      c.font = '900 18px sans-serif'; c.fillStyle = '#000'; c.fillText(`КОМБО x${G.combo}`, VW - 11, cy + 1);
      c.fillStyle = G.combo >= 50 ? '#ff3ea5' : G.combo >= 20 ? '#ffd25a' : '#ffffff'; c.fillText(`КОМБО x${G.combo}`, VW - 12, cy);
      c.font = 'bold 10px sans-serif'; c.fillStyle = '#bff6ff'; c.fillText(`+${Math.min(G.combo, 100)}% опыта`, VW - 12, cy + 13);
      c.globalAlpha = 1;
    }
    // босс
    const b = G.activeBoss;
    if (b && b.state === 'fight') {
      const w = Math.min(VW - 40, 380), x = (VW - w) / 2, y = top + ms + 12;
      c.fillStyle = 'rgba(0,0,0,0.7)'; roundRect(c, x - 4, y - 4, w + 8, 34, 8); c.fill();
      c.fillStyle = '#3a0a0a'; c.fillRect(x, y + 13, w, 11);
      if (b.def.immortal && G.finalFinal) {
        // бессмертный: вместо здоровья – заряд ДРУЖБА-СУПЕР
        const F = G.finalFinal, k2 = clamp(F.t / F.need, 0, 1), seg = w / RAINBOW.length;
        RAINBOW.forEach((col, i) => { c.fillStyle = col; c.fillRect(x + i * seg, y + 13, seg, 11); });
        c.fillStyle = '#ff3ea5'; c.fillRect(x, y + 13, w, 11);
        c.save(); c.beginPath(); c.rect(x, y + 13, w * k2, 11); c.clip();
        RAINBOW.forEach((col, i) => { c.fillStyle = col; c.fillRect(x + i * seg, y + 13, seg + 1, 11); });
        c.restore();
        c.font = '900 12px sans-serif'; c.textAlign = 'center'; c.fillStyle = '#ffd25a';
        c.fillText(`${b.name.toUpperCase()} · НЕУЯЗВИМ · ПРОДЕРЖИСЬ ${Math.ceil(Math.max(0, F.need - F.t))}с`, VW / 2, y + 8);
        c.font = '900 9px sans-serif'; c.fillStyle = '#fff'; c.fillText(`💜 ДРУЖБА-СУПЕР ${Math.floor(k2 * 100)}%${F.bank > 0.05 ? ' ⏩' : ''}`, VW / 2, y + 22);
      } else {
        c.fillStyle = b.stage >= 2 ? '#ff3b6b' : b.stage === 1 ? '#ff7a2f' : '#e53935';
        c.fillRect(x, y + 13, w * clamp(b.hp / b.maxHp, 0, 1), 11);
        c.fillStyle = '#ffffff';
        for (const st of b.def.stages) if (st.at) c.fillRect(x + w * st.at - 1, y + 11, 2, 15);
        c.font = '900 12px sans-serif'; c.textAlign = 'center'; c.fillStyle = '#ffd25a';
        c.fillText(`${b.name.toUpperCase()} · УР. ${b.level} · СТАДИЯ ${b.stage + 1}/${b.def.stages.length}`, VW / 2, y + 8);
      }
    }
    if (CFG.rush && G.rush && !G.rush.done && !G.activeBoss && G.rush.wait > 0 && state === 'play') {
      const nb = bosses[G.rush.idx];
      if (nb) {
        c.font = '900 16px sans-serif'; c.textAlign = 'center';
        const txt = `Следующий: ${nb.name} через ${Math.ceil(G.rush.wait)}…`;
        c.fillStyle = '#000'; c.fillText(txt, VW / 2 + 1, top + ms + 41); c.fillStyle = '#ffa080'; c.fillText(txt, VW / 2, top + ms + 40);
      }
    }
    if (G.activeShrine) {
      c.font = '900 14px sans-serif'; c.textAlign = 'center'; c.fillStyle = '#000';
      c.fillText(`Испытание: осталось ${G.activeShrine.left}`, VW / 2 + 1, top + ms + 63);
      c.fillStyle = '#ff8a8a'; c.fillText(`Испытание: осталось ${G.activeShrine.left}`, VW / 2, top + ms + 62);
    }
    if (input.touchId !== null) {
      c.strokeStyle = 'rgba(255,255,255,0.35)'; c.lineWidth = 3; c.fillStyle = 'rgba(255,255,255,0.08)';
      c.beginPath(); c.arc(input.bx, input.by, JOY_R, 0, TAU); c.fill(); c.stroke();
      c.fillStyle = 'rgba(255,255,255,0.45)';
      c.beginPath(); c.arc(input.bx + input.mx * JOY_R, input.by + input.my * JOY_R, 24, 0, TAU); c.fill();
    }
    if (G.hintT > 0) {
      c.globalAlpha = clamp(G.hintT, 0, 1);
      c.font = 'bold 15px sans-serif'; c.textAlign = 'center';
      c.fillStyle = '#000'; c.fillText('Веди пальцем по экрану, чтобы бежать', VW / 2 + 1, VH * 0.72 + 1);
      c.fillStyle = '#fff'; c.fillText('Веди пальцем по экрану, чтобы бежать', VW / 2, VH * 0.72);
      c.fillStyle = '#000'; c.fillText('Крилесса стреляет перьями сама!', VW / 2 + 1, VH * 0.72 + 23);
      c.fillStyle = '#ffd25a'; c.fillText('Крилесса стреляет перьями сама!', VW / 2, VH * 0.72 + 22);
      c.globalAlpha = 1;
    }
    let ry = top + 50;
    c.textAlign = 'left';
    if (G.keys > 0) { c.font = 'bold 13px sans-serif'; c.fillStyle = '#000'; c.fillText('🔑' + G.keys, 13, ry + 14); c.fillStyle = '#ffd25a'; c.fillText('🔑' + G.keys, 12, ry + 13); ry += 22; }
    if (G.cookieT > 0) { const tx = '🍪 ' + Math.ceil(G.cookieT) + 'с'; c.font = 'bold 13px sans-serif'; c.fillStyle = '#000'; c.fillText(tx, 13, ry + 14); c.fillStyle = '#ffd25a'; c.fillText(tx, 12, ry + 13); ry += 22; }
    if (G.wxId && G.wxT > 0) { const tx = { blizzard: '❄️', starfall: '🌠', frost: '🥶' }[G.wxId] + ' ' + Math.ceil(G.wxT) + 'с'; c.font = 'bold 13px sans-serif'; c.fillStyle = '#000'; c.fillText(tx, 13, ry + 14); c.fillStyle = '#d8f2ff'; c.fillText(tx, 12, ry + 13); ry += 22; }
    for (const id of (G.relics || [])) { c.globalAlpha = id === 'phoenix' && G.phoenixUsed ? 0.35 : 1; c.font = '17px sans-serif'; c.fillText(RELICS[id].ic, 14, ry + 15); ry += 24; }
    c.globalAlpha = 1;
    if (state === 'play' && !G.activeBoss && !G.activeShrine) {
      let near = false;
      for (const ch of chests) if (!ch.open && !ch.seen && Math.hypot(ch.x - P.x, ch.y - P.y) < 520) { near = true; break; }
      if (near) {
        c.globalAlpha = 0.6 + Math.sin(G.time * 5) * 0.35; c.font = 'bold 12px sans-serif'; c.textAlign = 'center';
        c.fillStyle = '#000'; c.fillText('✨ Где-то рядом сокровище…', VW / 2 + 1, VH * 0.25 + 1); c.fillStyle = '#ffe9a0'; c.fillText('✨ Где-то рядом сокровище…', VW / 2, VH * 0.25);
        c.globalAlpha = 1;
      }
    }
    const nearN = state === 'play' && !G.activeBoss && !!G.nearNpc;
    const nb = $('npcBtn'); if (nb._on !== nearN) { nb._on = nearN; nb.classList.toggle('hidden', !nearN); }
    const nearPortal = state === 'play' && !G.activeBoss && !G.activeShrine && !G.cutscene && !CFG.rush && !!portalHere();
    const pb = $('portalBtn'); if (pb._on !== nearPortal) { pb._on = nearPortal; pb.classList.toggle('hidden', !nearPortal); }
    const sw = $('swapBtn'), showSw = !!G.team && state === 'play' && !G.cutscene;
    if (sw._on !== showSw) { sw._on = showSw; sw.classList.toggle('hidden', !showSw); }
    if (showSw) {
      const o = teamOther(), f = G.team.f[o], ko = G.team.ko[o] || f < 0.25, cd = G.team.cd > 0;
      const key = o + Math.round(f * 60) + (ko ? 'k' : '') + (cd ? 'c' : '');
      if (sw._k !== key) {
        sw._k = key;
        if (sw._o !== o) { sw._o = o; const sc = $('swapAvatar').getContext('2d'); sc.clearRect(0, 0, 96, 96); sc.drawImage(heroAvatar(o), 0, 0, 96, 96); $('swapName').textContent = '🔄 ' + HEROES[o].name; }
        sw.style.setProperty('--hp', Math.round(f * 360) + 'deg');
        sw.classList.toggle('ko', ko); sw.classList.toggle('cool', cd);
      }
    }
    const dashEl = $('dashBtn');
    const cool = P.dashCd > 0;
    if (cool !== dashEl._cool) { dashEl._cool = cool; dashEl.classList.toggle('cool', cool); }
    const supEl = $('superBtn'), sp = Math.floor(P.sp);
    if (supEl._sp !== sp) {
      supEl._sp = sp;
      supEl.style.setProperty('--sp', (sp * 3.6) + 'deg');
      supEl.classList.toggle('ready', sp >= 100);
      $('superPct').textContent = sp >= 100 ? 'ГОТОВ' : sp + '%';
    }
  }

  // ------------------------------------------------------------------
  //  Управление
  // ------------------------------------------------------------------
  const JOY_R = 55;
  const input = { mx: 0, my: 0, touchId: null, bx: 0, by: 0, keys: {} };
  canvas.addEventListener('pointerdown', e => {
    Sound.init();
    if (state === 'play' && G.miniRect) {
      const R = G.miniRect;
      if (e.clientX >= R.x - 6 && e.clientX <= R.x + R.s + 6 && e.clientY >= R.y - 6 && e.clientY <= R.y + R.s + 18) { openMap(); return; }
    }
    if (state !== 'play' || input.touchId !== null) return;
    input.touchId = e.pointerId; input.bx = e.clientX; input.by = e.clientY; input.mx = 0; input.my = 0;
    try { canvas.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
  });
  canvas.addEventListener('pointermove', e => {
    if (e.pointerId !== input.touchId) return;
    let dx = e.clientX - input.bx, dy = e.clientY - input.by;
    const d = Math.hypot(dx, dy);
    if (d > JOY_R) { input.bx += (dx / d) * (d - JOY_R); input.by += (dy / d) * (d - JOY_R); dx = e.clientX - input.bx; dy = e.clientY - input.by; }
    input.mx = dx / JOY_R; input.my = dy / JOY_R;
  });
  const endTouch = e => { if (e.pointerId === input.touchId) { input.touchId = null; input.mx = 0; input.my = 0; } };
  canvas.addEventListener('pointerup', endTouch);
  canvas.addEventListener('pointercancel', endTouch);
  $('dashBtn').addEventListener('pointerdown', e => { e.preventDefault(); e.stopPropagation(); tryDash(); });
  $('superBtn').addEventListener('pointerdown', e => { e.preventDefault(); e.stopPropagation(); trySuper(); });
  $('swapBtn').addEventListener('pointerdown', e => { e.preventDefault(); e.stopPropagation(); switchHero(); });
  $('pauseBtn').addEventListener('click', () => pauseGame());
  $('talkTap').addEventListener('pointerdown', e => { e.preventDefault(); Sound.init(); Dialog.advance(); });
  window.addEventListener('keydown', e => {
    if (e.target && e.target.tagName === 'INPUT') return; // ввод пароля – не управление
    if (state === 'play' && Dialog.talking && (e.code === 'Space' || e.code === 'Enter')) { Dialog.advance(); return; }
    input.keys[e.code] = true;
    if (e.code === 'Space' || e.code === 'ShiftLeft') tryDash();
    if (e.code === 'KeyE' || e.code === 'KeyQ') trySuper();
    if (e.code === 'KeyR' || e.code === 'Tab') { e.preventDefault(); switchHero(); }
    if (e.code === 'Escape') { if (state === 'play') pauseGame(); else if (state === 'pause') resumeGame(); }
    if (DEBUG) debugKey(e.code);
  });
  window.addEventListener('keyup', e => { input.keys[e.code] = false; });
  function pollKeys() {
    if (input.touchId !== null) return;
    const k = input.keys;
    const x = (k.KeyD || k.ArrowRight ? 1 : 0) - (k.KeyA || k.ArrowLeft ? 1 : 0);
    const y = (k.KeyS || k.ArrowDown ? 1 : 0) - (k.KeyW || k.ArrowUp ? 1 : 0);
    const m = Math.hypot(x, y) || 1;
    input.mx = x / m; input.my = y / m;
  }

  // ------------------------------------------------------------------
  //  Диалоги и баннеры
  // ------------------------------------------------------------------
  const Dialog = {
    queue: [], cur: null, t: 0, shown: -1,
    get talking() { return !!(this.cur && this.cur.pause); },
    update(dt) {
      if (!this.cur && this.queue.length) {
        this.cur = this.queue.shift(); this.t = 0; this.shown = -1;
        const who = this.cur.who;
        const heroine = who === 'ryzhova' || who === 'krilessa' || who === 'tessa';
        $('dlgName').textContent = who === 'ryzhova' ? 'Рыжовая' : who === 'krilessa' ? 'Крилесса' : who === 'tessa' ? 'Тесса' : BOSSES[who].name;
        $('dialog').classList.toggle('boss', !heroine);
        const dc = $('dlgAvatar').getContext('2d'); dc.clearRect(0, 0, 116, 116);
        if (AVATAR[who]) dc.drawImage(AVATAR[who], 0, 0, 116, 116);
        $('dialog').classList.remove('hidden');
        // речь босса: игра на паузе, пока не коснёшься экрана
        $('dialog').classList.toggle('wait', !!this.cur.pause);
        $('talkTap').classList.toggle('hidden', !this.cur.pause);
        if (this.cur.pause) { input.touchId = null; input.mx = 0; input.my = 0; }
      }
      if (!this.cur) return;
      this.t += dt;
      const n = Math.min(this.cur.text.length, Math.floor(this.t * 42));
      if (n !== this.shown) { this.shown = n; $('dlgText').textContent = this.cur.text.slice(0, n); }
      if (!this.cur.pause && this.t > this.cur.dur) this.close();
    },
    advance() {
      if (!this.cur) return;
      if (this.shown < this.cur.text.length) { this.t = 99; this.shown = this.cur.text.length; $('dlgText').textContent = this.cur.text; return; }
      this.close();
    },
    close() { this.cur = null; $('dialog').classList.add('hidden'); $('talkTap').classList.add('hidden'); },
    clear() { this.queue.length = 0; this.close(); },
  };
  function say(text, dur) { if (!text) return; Dialog.queue.push({ text, who: CFG.hostage || 'ryzhova', dur: dur || Math.max(3.2, text.length * 0.06) }); }
  function speak(kind, text, dur, pause = true) {
    if (!text) return;
    if (!AVATAR[kind]) AVATAR[kind] = BOSSES[kind].avatar ? AVATAR[BOSSES[kind].avatar] : bossPortrait(kind);
    // реплики босса показываем сразу, героиня подождёт
    Dialog.queue.unshift({ text, who: kind, dur: dur || Math.max(3.4, text.length * 0.065), pause });
    if (Dialog.cur && (Dialog.cur.who === 'ryzhova' || Dialog.cur.who === 'krilessa' || Dialog.cur.who === 'tessa')) Dialog.queue.push(Dialog.cur);
    Dialog.cur = null;
  }
  let bannerTimer = 0;
  function showBanner(big, sub) {
    const el = $('banner');
    $('bannerBig').textContent = big; $('bannerSub').textContent = sub || '';
    el.classList.remove('hidden', 'show'); void el.offsetWidth; el.classList.add('show');
    clearTimeout(bannerTimer); bannerTimer = setTimeout(() => el.classList.add('hidden'), 2700);
  }

  // ------------------------------------------------------------------
  //  Экраны
  // ------------------------------------------------------------------
  const screens = ['intro', 'menu', 'levelup', 'pause', 'dead', 'victory', 'stats', 'whatsnew', 'teaser', 'zmenu', 'portal', 'choice', 'board', 'npc', 'wardrobe', 'mapscr', 'intros', 'relic', 'talents', 'admin', 'chapSheet', 'settings'];
  function setState(s) {
    state = s;
    for (const n of screens) $(n).classList.toggle('hidden', n !== s && !(s === 'chapSheet' && n === 'menu')); // карточка главы – поверх карты
    $('hud').classList.toggle('hidden', s !== 'play');
    $('talkTap').classList.toggle('hidden', !(s === 'play' && Dialog.talking));
    $('dialog').classList.toggle('offscreen', s !== 'play' && s !== 'dying'); // диалог не висит поверх меню и карты
    if (s !== 'play') { input.touchId = null; input.mx = 0; input.my = 0; }
  }
  function openLevelUp() {
    if (G.pendingLv <= 0) return;
    setState('levelup');
    Sound.sfx.level();
    // особые улучшения своей главы выпадают вдвое чаще обычных
    const avail = UPGRADES.filter(u => lv(u.id) < u.max && (!u.ch || u.ch === CHN));
    const opts = [];
    while (opts.length < 3 && avail.length) {
      let r = Math.random() * avail.reduce((t, u) => t + (u.ch ? 2 : 1), 0), k = 0;
      for (; k < avail.length - 1; k++) { r -= avail[k].ch ? 2 : 1; if (r <= 0) break; }
      opts.push(avail.splice(k, 1)[0]);
    }
    $('lvHint').textContent = (G.freePicks > 0 ? '🎁 Стартовый набор · ' : '') + (G.pendingLv > 1 ? `Выбери улучшение (ещё ${G.pendingLv})` : 'Выбери улучшение');
    const box = $('cards'); box.innerHTML = '';
    opts.forEach((u, i) => {
      const el = document.createElement('button');
      el.className = 'card' + (u.ch ? ' special' : ''); el.style.animationDelay = (i * 0.07) + 's';
      const ov = HEROES[P.hero].names[u.id];
      const ic = ov ? ov[0] : u.ic, nm = ov ? ov[1] : u.nm, ds = ov ? ov[2] : u.ds;
      el.innerHTML = `<div class="ic">${ic}</div><div>${u.ch ? '<div class="sp">✨ особое – только в этой главе</div>' : ''}<div class="nm">${nm}</div><div class="ds">${ds}</div><div class="lv">Уровень ${lv(u.id)} → ${lv(u.id) + 1}</div></div>`;
      el.dataset.id = u.id;
      el.addEventListener('click', () => {
        P.up[u.id] = lv(u.id) + 1;
        if (G.st) G.st.ups.push(u.id);
        if (G.freePicks > 0) G.freePicks--;
        if (u.id === 'hp') P.hp = Math.min(P.maxHp + 30, P.hp + 30 + P.maxHp * 0.2);
        computeStats();
        Sound.sfx.click();
        G.pendingLv--;
        saveGame();
        if (G.pendingLv > 0) openLevelUp(); else setState('play');
      });
      box.appendChild(el);
    });
    if (!opts.length) { G.pendingLv = 0; P.hp = P.maxHp; setState('play'); }
  }
  function pauseGame() {
    if (state !== 'play') return;
    $('pauseStats').innerHTML =
      `<b>Глава ${CHN}: ${CFG.name}</b> · ${HEROES[P.hero].name}<br>` +
      `❤️ HP ${Math.ceil(P.hp)}/${P.maxHp} · 🪶 урон ${Math.round(P.dmg)} · 💨 ${(1 / P.fireInt).toFixed(1)} выстр/с<br>` +
      `🎯 крит ${Math.round(P.crit * 100)}% (x${P.critMul.toFixed(2)}) · 🛡️ броня ${Math.round(P.armor * 100)}%<br>` +
      `💎 осколков ${P.shards} · ☠️ врагов ${G.kills} · 🔥 лучшее комбо ${G.bestCombo}<br>` +
      `🔑 ключей ${G.keys || 0}` + ((G.relics || []).length ? ' · ' + G.relics.map(id => RELICS[id].ic + ' ' + RELICS[id].name).join(', ') : '') + '<br>' +
      `🗺️ карта #${SEED % 10000} · 🌟 супер ${Math.floor(P.sp)}% · ⚖️ зона: ур. ${zoneE(biomeMap[clamp(Math.floor(P.y / T), 0, MH - 1) * MW + clamp(Math.floor(P.x / T), 0, MW - 1)])}`;
    setState('pause'); Sound.sfx.click();
  }
  function resumeGame() { setState('play'); }
  function playerDied() {
    burst(P.x, P.y, 40, '#c9b3ff', 260);
    if (G.st) { G.st.deaths++; if (G.st.cur) G.st.cur.d++; }
    if (G.rush) rushFinish(false);
    setTimeout(() => {
      const R = G.rush;
      $('deadTitle').textContent = R ? 'Босс-раш окончен' : G.team ? 'Обе героини без сил…' : `${HEROES[P.hero].name} без сил…`;
      $('deadText').innerHTML = R ? `Побеждено боссов: <b>${R.idx}/${R.total}</b> за ${fmtT(R.t)}${R.better ? '<br>🏆 Новый рекорд!' : ''}`
        : CFG.deadText ? CFG.deadText : (CHN === 3 ? 'Крилесса всё ещё ждёт!' : 'Рыжовая всё ещё ждёт!') + ' Попробуй снова –<br>уровень и улучшения сохранятся.';
      setState('dead');
    }, 700);
    state = 'dying';
  }
  function respawn() {
    if (G.rush) { startRush(); return; }
    if (G.finalFinal) {
      // подлянка: бой с бессмертным начинается заново
      G.finalFinal.t = 0; G.finalFinal.bank = 0; G.finalFinal.said = {};
      G.enemies.length = 0; G.ebullets.length = 0; G.hazards.length = 0; G.feathers.length = 0; G.beams.length = 0;
      P.x = G.cp.x; P.y = G.cp.y; P.hp = P.maxHp; P.inv = 2.5; P.dashT = 0; P.slowT = 0;
      Dialog.clear(); say('Я с тобой, Рыжовая! Ещё раз – вместе!');
      setState('play');
      return;
    }
    for (const b of bosses) if (b.state === 'fight') resetBoss(b);
    for (const ch of chests) if (ch.mimic && ch.open && !ch.mimicDone) ch.open = false; // мимик снова прячется
    G.activeBoss = null;
    if (G.activeShrine) { G.activeShrine.state = 'idle'; G.activeShrine = null; }
    // чемпион не исчезает после смерти героини: остаётся на карте с тем же здоровьем
    const champ = G.champ && !G.champ.dead && G.enemies.includes(G.champ) ? G.champ : null;
    G.enemies.length = 0; G.ebullets.length = 0; G.hazards.length = 0; G.feathers.length = 0; G.beams.length = 0;
    if (champ) {
      const d = Math.hypot(champ.x - G.cp.x, champ.y - G.cp.y);
      // не караулит у точки возрождения, но и не теряется далеко – ждёт в паре экранов (корона на карте)
      if (d < 520 || d > 1600) {
        const base = Math.atan2(champ.y - G.cp.y, champ.x - G.cp.x), R = d < 520 ? 620 : 900;
        for (let k = 0; k < 32; k++) {
          const a = base + (k ? rnd(-1.6, 1.6) : 0), x = G.cp.x + Math.cos(a) * R, y = G.cp.y + Math.sin(a) * R;
          if (walkable(x, y, !!champ.def.fly) && y < PLAY_H * T) { champ.x = x; champ.y = y; break; }
        }
      }
      champ.jd = 0; champ.wind = 0; champ.slowT = 0; champ.burnT = 0;
      G.enemies.push(champ);
    }
    P.x = G.cp.x; P.y = G.cp.y; P.hp = P.maxHp; P.inv = 2; P.dashT = 0; P.slowT = 0; P.lives = HEROES[P.hero].lives || 0; G.invertT = 0; G.staticT = 0; G.jump = null; P.z = 0;
    G.combo = 0;
    if (talent('super')) P.sp = Math.max(P.sp, 25 * talent('super'));
    if (G.team) { for (const id of G.team.list) { G.team.f[id] = 1; G.team.ko[id] = false; } G.team.bx = P.x; G.team.by = P.y; }
    if (G.tessaAlly) { G.tessaAlly = null; G.pet = null; } // бой с Мраком заново – Тесса снова во льду
    G.blizzardT = 0; G.wxId = null; G.wxT = 0; G.falling = []; G.chill = 0;
    Dialog.clear(); say(`Я жду тебя, ${HEROES[P.hero].name}! Не сдавайся!`);
    setState('play');
    biomeMusic(true);
  }
  function showVictory(mode) {
    Dialog.clear();
    $('victoryButtons').classList.remove('hidden');
    if (mode === 'rush') {
      const R = G.rush, vc0 = $('victoryPortrait').getContext('2d');
      vc0.clearRect(0, 0, 300, 300); vc0.drawImage(heroPortrait(P.hero, 300), 0, 0, 300, 300);
      $('victoryTitle').textContent = '⚔️ Босс-раш пройден!';
      $('victoryStats').innerHTML = `Все <b>${R.total}</b> боссов за <b>${fmtT(R.t)}</b>${R.better ? '<br>🏆 Новый рекорд!' : ''}`;
      $('victoryNext').classList.add('hidden'); $('victoryTeaser').classList.add('hidden');
      setState('victory');
      return;
    }
    if (CHN === 6) {
      const v6 = $('victoryPortrait').getContext('2d'); v6.clearRect(0, 0, 300, 300);
      v6.drawImage(heroPortrait('krilessa', 300), 0, 0, 300, 300);
      const small6 = (img, x, y, col) => { if (!img) return; v6.save(); v6.beginPath(); v6.arc(x, y, 46, 0, TAU); v6.clip(); v6.drawImage(img, x - 46, y - 46, 92, 92); v6.restore(); v6.strokeStyle = col; v6.lineWidth = 5; v6.beginPath(); v6.arc(x, y, 46, 0, TAU); v6.stroke(); };
      small6(AVATAR.ryzhova, 56, 245, '#ff7a2f'); small6(AVATAR.tessa, 245, 245, '#bfeaff');
      const m6 = Math.floor(G.time / 60), s6 = Math.floor(G.time % 60);
      $('victoryTitle').textContent = 'Зима отступила!';
      $('victoryStats').innerHTML = 'Лёд растаял, Тесса на свободе, лето вернулось. ☀️<br>Мрак оттаял и впервые улыбнулся. Но его последние слова не дают покоя…<br>' +
        `Время: <b>${m6}:${String(s6).padStart(2, '0')}</b> · Уровень: <b>${P.level}</b> · Врагов: <b>${G.kills}</b>`;
      $('victoryTeaser').innerHTML = '…где-то далеко стало подозрительно тихо. 🤫';
      $('victoryNext').classList.toggle('hidden', !CHAPTERS[7]); $('victoryNext').textContent = 'Глава 7 →';
      $('victoryTeaser').classList.remove('hidden');
      setState('victory'); Sound.music('truewin');
      return;
    }
    if (CHN === 4 || CHN === 5) {
      const vc4 = $('victoryPortrait').getContext('2d'); vc4.clearRect(0, 0, 300, 300);
      vc4.drawImage(AVATAR.tessaBig || heroPortrait('tessa', 300), 0, 0, 300, 300);
      const small = (img, x, y, col) => { if (!img) return; vc4.save(); vc4.beginPath(); vc4.arc(x, y, 44, 0, TAU); vc4.clip(); vc4.drawImage(img, x - 44, y - 44, 88, 88); vc4.restore(); vc4.strokeStyle = col; vc4.lineWidth = 5; vc4.beginPath(); vc4.arc(x, y, 44, 0, TAU); vc4.stroke(); };
      const mm = Math.floor(G.time / 60), ss = Math.floor(G.time % 60);
      const statLine = `Время: <b>${mm}:${String(ss).padStart(2, '0')}</b> · Уровень: <b>${P.level}</b> · Врагов: <b>${G.kills}</b>`;
      if (CHN === 4) {
        small(AVATAR.glitchcat, 245, 245, mode === 'kind' ? '#ff6fb5' : '#3ff0a0');
        $('victoryTitle').textContent = mode === 'kind' ? 'Мяу.exe приручён!' : 'Дом спасён!';
        $('victoryStats').innerHTML = (mode === 'kind' ? 'Тесса не стала удалять вирус. Она просто потёрлась о него носом…<br>Мяу.exe впервые замурлыкал. <b>Добрая</b> кошка. 💗<br>'
          : 'Тесса удалила Мяу.exe. Лампочки больше не мигают, телевизор молчит.<br><b>Хорошая</b> кошка. 🛡️<br>') + statLine;
        $('victoryTeaser').innerHTML = '…а утром из всех мисок пропал корм. 🐟<br>Глава 5 открыта!';
      } else {
        small(ART.zyamaFace, 56, 245, '#ffd25a'); small(heroPortrait('krilessa', 88), 245, 245, '#bfeaff'); small(AVATAR.ryzhova, 245, 56, '#ff7a2f');
        $('victoryTitle').textContent = 'Банкет!';
        $('victoryStats').innerHTML = 'Дело раскрыто: корм спрятал Зямочкккк – для банкета в честь Тессы!<br>Пришли все: Крилесса, Рыжовая, Пик, Гуля, Шуршик и даже Барон. 🎉<br>' + statLine;
        $('victoryTeaser').innerHTML = CHAPTERS[6] ? '…а ночью выпал снег. Посреди лета. ❄️<br>Глава 6 открыта!' : 'Продолжение следует… 🐾';
      }
      $('victoryNext').classList.toggle('hidden', !CHAPTERS[CHN + 1]);
      $('victoryNext').textContent = `Глава ${CHN + 1} →`;
      $('victoryTeaser').classList.remove('hidden');
      setState('victory'); Sound.music(CHN === 5 ? 'final5' : 'truewin');
      return;
    }
    const vc = $('victoryPortrait').getContext('2d');
    vc.clearRect(0, 0, 300, 300);
    if (AVATAR.ryzhovaBig) vc.drawImage(AVATAR.ryzhovaBig, 0, 0, 300, 300);
    if (CHN === 3) {
      vc.clearRect(0, 0, 300, 300);
      if (AVATAR.ryzhovaBig) vc.drawImage(AVATAR.ryzhovaBig, 0, 0, 300, 300);
      const kp = heroPortrait('krilessa', 120);
      vc.save(); vc.beginPath(); vc.arc(62, 238, 56, 0, TAU); vc.clip(); vc.drawImage(kp, 2, 178, 120, 120); vc.restore();
      vc.strokeStyle = '#bfeaff'; vc.lineWidth = 5; vc.beginPath(); vc.arc(62, 238, 56, 0, TAU); vc.stroke();
    }
    if (CHN >= 2 && ART.zyamaFace) {
      vc.save(); vc.beginPath(); vc.arc(240, 240, 52, 0, TAU); vc.clip(); vc.drawImage(ART.zyamaFace, 188, 188, 104, 104); vc.restore();
      vc.strokeStyle = '#ff3ea5'; vc.lineWidth = 5; vc.beginPath(); vc.arc(240, 240, 52, 0, TAU); vc.stroke();
      const em = emojiSprite(mode === 'true' ? '❤️' : '😭', 30); vc.drawImage(em, 250, 160, 50, 50);
    }
    const m = Math.floor(G.time / 60), s = Math.floor(G.time % 60);
    $('victoryTitle').textContent = ['', 'Рыжовая спасена!', 'Рыжовая снова свободна!', 'Крилесса спасена!'][CHN];
    $('victoryStats').innerHTML = [
      '', 'Крилесса освободила Рыжовую из Тёмного замка!<br>',
      'Зямочкккк повержен! (Но обещал вернуться в версии 0.03…)<br>',
      'Рыжовая разбила Зеркальный дворец и спасла подругу!<br>Зямочкккк попросил у неё автограф 🥲 Конец трилогии… или нет? 👀<br>'][CHN] +
      `Время: <b>${m}:${String(s).padStart(2, '0')}</b> · Уровень: <b>${P.level}</b> · Врагов: <b>${G.kills}</b> · Осколков: <b>${P.shards}</b>`;
    $('victoryNext').classList.toggle('hidden', CHN >= 3 && !(CHN === 3 && mode === 'true'));
    $('victoryTeaser').classList.toggle('hidden', CHN >= 3);
    $('victoryNext').textContent = `Глава ${CHN + 1} →`;
    $('victoryTeaser').innerHTML = CHN === 1 ? '…но в небе уже открылся кринжовый портал.<br>Глава 2 открыта!'
      : '…Зямочкккк сдержал слово и вернулся в 0.03!<br>Глава 3 открыта – играешь за Рыжовую! 🔥';
    if (mode === 'true') {
      $('victoryTitle').textContent = 'НАСТОЯЩАЯ ПОБЕДА!';
      $('victoryStats').innerHTML = 'Рыжовая и Крилесса вместе одолели Зямочкккк ∞!<br>Он поклонился, сказал «браво» и ушёл пить какао ❤️<br><b>Трилогия завершена!</b><br>' +
        `Время: <b>${m}:${String(s).padStart(2, '0')}</b> · Уровень: <b>${P.level}</b> · Врагов: <b>${G.kills}</b>`;
      $('victoryTeaser').innerHTML = '…но кто это мурлычет в темноте? 🐾<br>Глава 4 открыта – играешь за Тессу!';
      $('victoryTeaser').classList.remove('hidden');
    }
    setState('victory');
    if (CHN === 3 && !mode && !G.trueWin) { $('victoryButtons').classList.add('hidden'); later(4800, startTrick); }
  }

  // ------------------------------------------------------------------
  //  Сохранения
  // ------------------------------------------------------------------
  const PROFILE_KEY = 'krilessa_profile_v2';
  const saveKey = ch => 'krilessa_save_v2_ch' + ch;
  function loadProfile() { try { return JSON.parse(localStorage.getItem(PROFILE_KEY)) || {}; } catch (e) { return {}; } }
  function saveProfile(p) { try { localStorage.setItem(PROFILE_KEY, JSON.stringify(p)); } catch (e) { /* ignore */ } }
  function loadSave(ch) { try { const s = localStorage.getItem(saveKey(ch)); return s ? JSON.parse(s) : null; } catch (e) { return null; } }
  function saveGame() {
    if (CFG.rush || G.finalFinal) return;
    if (state === 'menu' || state === 'intro') return;
    if (G.cutscene || !bosses.length || G.defeated[bosses.length - 1]) return;
    const data = { v: 5, defeated: G.defeated, level: P.level, xp: P.xp, up: P.up, bonus: P.bonus, shards: P.shards, cp: G.cp, sp: P.sp,
      kills: G.kills, time: G.time, bestCombo: G.bestCombo, chests: chests.map(c => c.open && (!c.mimic || c.mimicDone) ? 1 : 0), cs: chests.map(c => c.seen ? 1 : 0), keys: G.keys || 0, ph: !!G.phoenixUsed, shrines: shrines.map(s => s.state === 'done' ? 1 : 0),
      st: G.st, lowHp: G.lowHpSaid, calm: G.calm, seed: SEED,
      clues: clues.map(q => q.found ? 1 : 0), npcs: npcs.map(n => n.state), qi: qitems.map(i => (i.active ? 1 : 0) + (i.taken ? 2 : 0)), acc: !!G.accused,
      tm: teamSnapshot(), ml: G.melted, fl: fires.map(f => f.lit ? 1 : 0), dr: drifts.map(d => d.done ? 1 : 0), gl: glades.map(g => g.done ? 1 : 0) };
    try { localStorage.setItem(saveKey(CHN), JSON.stringify(data)); } catch (e) { /* ignore */ }
  }
  (function migrateV1() {
    try {
      const old = localStorage.getItem('krilessa_save_v1');
      if (old && !localStorage.getItem(saveKey(1))) localStorage.setItem(saveKey(1), old);
      if (old) localStorage.removeItem('krilessa_save_v1');
    } catch (e) { /* ignore */ }
  })();

  // ------------------------------------------------------------------
  //  Запуск глав
  // ------------------------------------------------------------------
  function loadChapter(n, seed) {
    CHN = n; CFG = CHAPTERS[n]; SEED = seed || CFG.seed; // каждое новое прохождение – своя карта
    generateWorld();
  }
  function resetRun() {
    G.time = 0; G.kills = 0; G.defeated = CFG.bosses.map(() => false);
    G.cp = { x: tc(START.x), y: tc(START.y) };
    G.enemies = []; G.feathers = []; G.ebullets = []; G.hazards = []; G.pickups = []; G.parts = []; G.texts = []; G.bolts = []; G.rings = []; G.beams = [];
    G.shake = 0; G.hurtFlash = 0; G.activeBoss = null; G.pendingLv = 0; G.spawnT = 2; G.gateMsgT = 0; G.lowHpT = 0; G.calm = {}; G.bossHeartT = 12; G.champ = null; G.champT = 150;
    G.invertT = 0; G.staticT = 0; G.clues5 = [0, 0, 0, 0]; G.clueMsgT = 0; G.revealT = 0; G.hidden = null; G.hideT = 0; G.jump = null; G.pet = null;
    G.clearSight = false; G.boardPending = false; G.nearNpc = null; G.eyes = null; G.eyesT = 10; G.glitchT = 30; G.glitchFx = 0; G.flickT = -5; G.flickGap = 8; G.accused = false;
    P.z = 0; P.napT = 0; P.pounce = false; P.lives = 0;
    G.keys = 0; G.phoenixUsed = false; G.relicPending = false; G.guardT = 0; G.hintT = 0; G.freePicks = 0;
    G.team = null; G.teamSave = null; G.tessaAlly = null; G.blizzardT = 0; G.blizA = 0; G.blizT = 55; G.melted = []; G.meltHits = {}; G.iceSaid = false; G.nearFire = null;
    for (const f of fires) f.lit = false;
    P.ivx = 0; P.ivy = 0; P.discoT = undefined;
    G.wxId = null; G.wxT = 0; G.lastWx = null; G.falling = []; G.chill = 0; G.cookieT = 0; G.caveA = 0; G.caveSaid = false; G.fishing = null; G.baking = null;
    for (const d of drifts) { d.hp = 3; d.done = false; }
    for (const g of glades) { g.open = false; g.done = false; g.seen = false; }
    for (const o of holes.concat(ovens)) { o.cd = 0; o.prog = 0; }
    for (const ch of chests) { ch.mimicDone = false; ch.seen = false; }
    for (const bd of beds) { bd.cd = 0; bd.nap = 0; }
    for (const q of clues) q.found = false;
    for (const n of npcs) n.state = 'new';
    for (const it of qitems) { it.active = false; it.taken = false; }
    for (const s of shelves) { s.cd = 0; s.inside = false; }
    G.cutscene = null; G.victoryShown = false; G.cageOpen = 0; G.combo = 0; G.comboT = 0; G.bestCombo = 0; G.activeShrine = null;
    P.level = 1; P.xp = 0; P.xpNext = xpFor(1); P.up = {}; P.bonus = {}; P.shards = 0; P.maxHp = 100; P.hp = 100;
    P.inv = 0; P.dashT = 0; P.dashCd = 0; P.fireT = 0; P.boltT = 1; P.face = 1; P.slowT = 0; P.shieldT = 0; P.vx = 0; P.vy = 0;
    P.hero = CFG.hero; P.sp = 0; P.stormT = 0; G.pzones = []; G.novas = []; G.scaleCache = {};
    if (G.ev) endEvent();
    G.ev = null; G.evT = EVENT_EVERY; G.lowHpSaid = false; G.finalFinal = null; G.rush = null; G.trueWin = false; G.st = null; G.zm = null;
    trickTimers.forEach(clearTimeout); trickTimers = [];
    for (const c of chests) c.open = false;
    for (const s of shrines) s.state = 'idle';
    gateOpen = false;
    resetFog();
    Dialog.clear();
  }
  function beginPlay() {
    G.inMenu = false;
    const prof = loadProfile();
    G.tal = Object.assign({}, prof.talents || {});
    G.relics = (prof.relics || []).filter(id => RELICS[id]).slice(0, relicMax());
    G.diffId = (prof.settings && prof.settings.diff) || 'normal'; G.diff = DIFFS[G.diffId] || DIFFS.normal;
    G.evT = EVENT_EVERY * G.diff.event;
    P.maxHp = 100; computeStats(); P.hp = P.maxHp;
    initTeam(G.teamSave); G.teamSave = null;
    P.lives = CFG.rush ? 0 : HEROES[P.hero].lives || 0;
    if (CHN === 5) { const ch4 = prof.ch4Choice; G.pet = ch4 === 'kind' ? { x: P.x, y: P.y, fireT: 1 } : null; G.clearSight = ch4 === 'good'; }
    P.x = G.cp.x; P.y = G.cp.y; ensureWalkable(P);
    makeBosses();
    revealFog(P.x, P.y, 12);
    $('dashBtn').querySelector('span').textContent = HEROES[P.hero].dash;
    setState('play');
    if (!G.st) G.st = newRunStats();
    else if (!String(G.st.diff).split('→').includes(G.diffId)) G.st.diff += '→' + G.diffId; // сложность меняли по ходу
    Sound.init(); biomeMusic(true);
  }
  // Если герой слабее стартового уровня главы – автонабор + последние улучшения на выбор
  function autoPick() {
    let best = null, bv = 1e9;
    for (const k in REF_W) { const l = P.up[k] || 0; if (l >= UPGRADE_MAX[k]) continue; const v = (l + 1) / REF_W[k]; if (v < bv) { bv = v; best = k; } }
    if (best) P.up[best] = (P.up[best] || 0) + 1;
  }
  function newChapter(n) {
    loadChapter(n, 1 + Math.floor(Math.random() * 2e9)); resetRun();
    try { localStorage.removeItem(saveKey(n)); } catch (e) { /* ignore */ }
    // прокачка своя в каждой главе: всегда с 1 уровня. Навсегда остаются реликвии и таланты
    beginPlay();
    const tStart = talent('start');
    if (tStart) { G.pendingLv += tStart; G.freePicks = tStart; }
    if (talent('super')) P.sp = 25 * talent('super');
    if (talent('key')) G.keys = 1;
    if (n === 1) {
      G.hintT = 6;
      showBanner('Спаси Рыжовую!', 'Победи трёх стражей и открой Тёмный замок');
      say('Крилесса! Колдун Мрак запер меня в Тёмном замке!', 4);
      say('Победи трёх стражей – тогда ворота откроются. Иди по стрелке!', 4.5);
      say('Убивай врагов – копи СУПЕР-удар (кнопка над рывком)!', 4);
    } else if (n === 2) {
      showBanner('Глава 2', 'Кринж-Цитадель');
      say('Крилесса! Зямочкккк утащил меня в свою Кринж-Цитадель! Тут везде его портреты и диско-шары!!!', 5);
      say('Победи четырёх стражей: Кактуса, Пчелу, Голема и Паука. Враги здесь подстраиваются под твою силу!', 6);
    } else if (n === 3) {
      showBanner('Глава 3', 'Рыжовая спешит на помощь');
      say('Рыжовая! Это я, Крилесса! Зямочкккк запер меня в Зеркальном дворце!', 5);
      say('Победи четырёх стражей Зямоверса. Огонь в твоих волосах – твоё оружие! 🔥', 5);
      say('Твоя ВСПЫШКА переносит сквозь врагов и оставляет огненный след. СУПЕР – огненная волна!', 6);
    } else if (n === 4) {
      showBanner('Глава 4', 'Ночь глитчей');
      say('Мрр… Три часа ночи. Почему мигает свет? И кто шепчет в колонке?..', 5);
      say('Я царапаю сама. ПРЫЖОК – прыжок-кусь, СУПЕР – мурчание: лечит и оглушает.', 6);
      say('У кошки девять жизней 🐾. А на лежанке можно вздремнуть – станет легче.', 5.5);
      say('Тёплый свет ламп пугает глитчей. Держись поближе к свету…', 4.5);
    } else if (n === 5) {
      unlockOutfit('hat');
      showBanner('Глава 5', 'Пропавший корм');
      say('Миска пуста. ВСЕ миски пусты. Это дело для детектива Тессы. 🕵️', 5);
      say('У каждого подозреваемого спрятано три улики – найди их, и он не отвертится.', 5.5);
      say('Полки 🐾 – кошачьи короткие пути. В коробке 📦 меня никто не найдёт.', 5);
      const ch4 = loadProfile().ch4Choice;
      if (ch4 === 'kind') say('Мяу.exe теперь мой маленький пиксельный котик. Он помогает искать улики!', 5);
      else if (ch4 === 'good') say('После ночи с глитчами я вижу яснее: все улики видны на мини-карте.', 5);
    } else if (n === 6) {
      showBanner('Глава 6', 'Мрак: новый сезон');
      say('Крилесса! Рыжовая! Я в ледяной клетке на вершине замка… Тут так холодно! 🥶', 5);
      say('Победите четырёх стражей зимы – тогда ворота Ледяного замка откроются.', 5);
      say('Вы теперь вдвоём! Кнопка 🔄 меняет героиню. Пока одна бьётся – вторая отдыхает.', 6);
      say('Костры 🔥 греют и лечат. Огонь Рыжовой растапливает лёд и сугробы – за ними прячутся сокровища!', 5.5);
      say('По ледяным рекам можно мчаться с ветерком – но тормозить на льду трудно! ⛸️', 4.5);
    }
    if (G.pendingLv > 0) openLevelUp();
  }
  function continueChapter(n) {
    const s = loadSave(n);
    if (!s || (s.v || 0) < 5) { newChapter(n); return; }
    loadChapter(n, s.seed); resetRun();
    P.sp = s.sp || 0;
    G.defeated = CFG.bosses.map((_, i) => !!(s.defeated && s.defeated[i]));
    G.kills = s.kills || 0; G.time = s.time || 0; G.cp = s.cp || G.cp; G.bestCombo = s.bestCombo || 0;
    P.level = s.level || 1; P.xp = s.xp || 0; P.xpNext = xpFor(P.level); P.up = s.up || {}; P.bonus = s.bonus || {}; P.shards = s.shards || 0;
    (s.chests || []).forEach((o, i) => { if (chests[i]) { chests[i].open = !!o; if (o && chests[i].mimic) chests[i].mimicDone = true; } });
    (s.cs || []).forEach((o, i) => { if (chests[i]) chests[i].seen = !!o; });
    G.keys = s.keys || 0; G.phoenixUsed = !!s.ph;
    (s.shrines || []).forEach((o, i) => { if (shrines[i] && o) shrines[i].state = 'done'; });
    G.st = s.st || null; G.lowHpSaid = !!s.lowHp; G.calm = s.calm || {};
    (s.clues || []).forEach((f, i) => { if (clues[i] && f) { clues[i].found = true; G.clues5[clues[i].i]++; } });
    (s.npcs || []).forEach((st, i) => { if (npcs[i]) npcs[i].state = st; });
    (s.qi || []).forEach((v, i) => { if (qitems[i]) { qitems[i].active = !!(v & 1); qitems[i].taken = !!(v & 2); } });
    (s.ml || []).forEach(i => meltTile(i, false));
    (s.fl || []).forEach((v, i) => { if (fires[i]) fires[i].lit = !!v; });
    (s.dr || []).forEach((v, i) => { if (drifts[i] && v) { drifts[i].done = true; drifts[i].hp = 0; } });
    (s.gl || []).forEach((v, i) => { if (glades[i] && v) glades[i].done = true; });
    for (const g of glades) if (g.ring.some(i => tiles[i] !== ROCK)) { g.open = true; g.seen = true; }
    if (s.tm && CFG.team && CFG.team.includes(s.tm.h)) P.hero = s.tm.h;
    G.teamSave = s.tm || null;
    beginPlay();
    gateOpen = guardiansDone() >= guardiansCount();
    G.accused = !!s.acc;
    if (CFG.detective && gateOpen && !G.accused) G.boardPending = true;
    // старые сохранения: локации уже побеждённых стражей сразу усмирены
    bosses.forEach((b, i) => { if (G.defeated[i] && b.calmBiome >= 0 && G.calm[b.calmBiome] === undefined) G.calm[b.calmBiome] = 0; });
    say(gateOpen ? 'Ворота открыты! Скорее в замок!' : `С возвращением! Стражей побеждено: ${guardiansDone()}/${guardiansCount()}.`);
  }
  function chapterOpen(n) {
    const prof = loadProfile();
    return DEBUG || !!prof.admin || n === 1 || !!prof['ch' + (n - 1) + 'Done'];
  }
  function startChapter(n) {
    if (!chapterOpen(n)) { toast(`🔒 Сначала пройди главу ${n - 1}`); return; }
    if (loadSave(n)) { continueChapter(n); return; }
    if (n === 1) newChapter(1);
    else Intro.start('ch' + n, () => newChapter(n));
  }
  const startChapter2 = () => startChapter(2);

  // ------------------------------------------------------------------
  //  Меню
  // ------------------------------------------------------------------
  // карточки секретных глав: название показываем только когда глава открыта
  const SECRET_CARDS = {
    4: { title: 'Ночь глитчей', locked: 'Хорошая… или добрая?..', open: 'Хорошая… или добрая?.. Новая героиня ждёт 🐾' },
    5: { title: 'Пропавший корм', locked: 'Кто-то что-то съел…', open: 'Кто украл корм? Уютный детектив 🕵️' },
    6: { title: 'Мрак: новый сезон', locked: 'Кто-то выключил лето…', open: 'Зима пришла не одна. Играешь вдвоём ❄️' },
  };
  function drawMenuPortrait() {
    const c = $('menuPortrait').getContext('2d');
    c.clearRect(0, 0, 240, 320);
    if (IMG.ryzhova) {
      // крупно лицо – в шапке меню портрет маленький
      const cv = IMG.ryzhova.cartoon, f = IMG.ryzhova.face || { x: 0.5, y: 0.4, r: 0.3 };
      const R = cv.width * f.r * 1.25, cx = cv.width * f.x, cy = cv.height * f.y;
      c.drawImage(cv, cx - R * 0.75, cy - R, R * 1.5, R * 2, 0, 0, 240, 320);
    }
    c.strokeStyle = 'rgba(255,210,90,0.85)'; c.lineWidth = 6;
    for (let i = 1; i < 6; i++) { c.beginPath(); c.moveTo(i * 40, 0); c.lineTo(i * 40, 320); c.stroke(); }
    c.lineWidth = 8; c.beginPath(); c.moveTo(0, 6); c.lineTo(240, 6); c.moveTo(0, 314); c.lineTo(240, 314); c.stroke();
  }
  function openMenu() {
    G.inMenu = true;
    if (CHN !== 1 || !tiles) loadChapter(1);
    resetRun();
    makeBosses();
    const prof = loadProfile();
    renderMap(prof);
    $('btnWardrobe').classList.toggle('hidden', !(prof.ch3Done || DEBUG || prof.admin));
    const freeStars = (prof.stars || 0) - talentSpent(prof.talents || {});
    $('mStarsN').textContent = prof.stars || 0;
    $('talBadge').textContent = freeStars; $('talBadge').classList.toggle('hidden', freeStars <= 0);
    // интро – только после прохождения главы
    ['btnIntro', 'btnIntro2', 'btnIntro3', 'btnIntro4', 'btnIntro5', 'btnIntro6'].forEach((id, i) => {
      const done = DEBUG || prof.admin || prof['ch' + (i + 1) + 'Done'];
      $(id).classList.toggle('locked', !done);
      $(id).textContent = (done ? '' : '🔒 ') + 'Интро ' + (i + 1);
    });
    const rushOpen = DEBUG || prof.admin || prof.ch1Done;
    $('chapRush').classList.toggle('locked', !rushOpen);
    $('menu').querySelector('.version').textContent = 'v' + VERSION + (prof.admin ? ' · 🔓 админ' : '');
    $('btnDiff').textContent = 'Сложность: ' + DIFFS[(prof.settings || {}).diff || 'normal'].name;
    updateSoundButtons();
    drawMenuPortrait();
    try { const A = window.KrilessaAndroid; const raw = A && A.updateInfo ? A.updateInfo() : ''; if (raw && !G.update) G.update = JSON.parse(raw); } catch (e) { /* ignore */ }
    showUpdate();
    setState('menu');
    Sound.music('menu');
    if (prof.ch4Done && !prof.ch4Choice && !G.pendingWhatsNew) { setTimeout(() => { if (state === 'menu') openChoice(true); }, 400); }
    if (G.pendingWhatsNew) { const from = G.pendingWhatsNew; G.pendingWhatsNew = null; setTimeout(() => openWhatsNew(from === true ? null : from), 300); }
  }
  // ---------- главный экран: карта приключений ----------
  const CH_META = {
    1: { ic: '🌲', c: ['#7dff7d', '#1f7a2a'], sc: '30,90,40', deco: ['🌲', '🌳', '🍄', '🌼'], hero: 'krilessa', desc: 'Рыжовая в плену у колдуна Мрака. Победи трёх стражей и открой Тёмный замок' },
    2: { ic: '🪩', c: ['#ff8ad8', '#6a2ad8'], sc: '90,30,110', deco: ['🪩', '✨', '🎤', '💿'], hero: 'krilessa', desc: 'Зямочкккк утащил Рыжовую в свою Кринж-Цитадель. Диско-шары, портреты и много кринжа' },
    3: { ic: '🪞', c: ['#ffc070', '#c03a10'], sc: '110,45,20', deco: ['🪞', '🔥', '🦄', '✨'], hero: 'ryzhovaya', desc: 'Теперь играешь за Рыжовую! Огонь в её волосах – оружие. Спаси Крилессу из Зеркального дворца' },
    4: { ic: '🌙', c: ['#8fa6e8', '#141a40'], sc: '20,26,60', deco: ['🌙', '🐾', '💡', '📺'], hero: 'tessa' },
    5: { ic: '🔎', c: ['#ffe08a', '#d8782a'], sc: '110,70,20', deco: ['🐟', '🔎', '📦', '🥣'], hero: 'tessa' },
    6: { ic: '❄️', c: ['#d8f2ff', '#3a6ac8'], sc: '30,60,110', deco: ['❄️', '⛄', '🔥', '🌨️'], hero: 'krilessa' },
  };
  const CH_LOCKED_META = { ic: '❔', c: ['#6a6080', '#1a1626'], sc: '30,26,44' };
  function chapterView(n, prof) {
    const C = CHAPTERS[n], open = chapterOpen(n), done = !!prof['ch' + n + 'Done'], sv = loadSave(n), sec = SECRET_CARDS[n];
    const hidden = !open && !!sec; // закрытая секретная глава – загадка
    const meta = hidden ? CH_LOCKED_META : CH_META[n];
    // идёт новое прохождение – показываем его прогресс, иначе для пройденной главы все звёзды
    const nb = C.bosses.length, beaten = sv && sv.defeated ? sv.defeated.filter(Boolean).length : done ? nb : 0;
    let stat = '';
    if (!open) stat = hidden ? '🔒 ' + sec.locked : `🔒 Откроется после главы ${n - 1}`;
    else if (sv) stat = `💾 Сохранение: боссы ${beaten}/${nb} · ур. ${sv.level}`;
    else if (n === 3 && prof.trueWin) stat = '✓ Настоящий финал пройден ❤';
    else if (n === 4 && done) stat = prof.ch4Choice === 'kind' ? '✓ Пройдена · добрая концовка 💗' : prof.ch4Choice === 'good' ? '✓ Пройдена · хорошая концовка 🛡️' : '✓ Пройдена';
    else if (n === 5 && done) stat = '✓ Дело раскрыто 🕵️';
    else if (n === 6 && done) stat = '✓ Зима отступила ❄️';
    else if (done) stat = '✓ Пройдена';
    else stat = 'Новая прокачка с 1 уровня';
    return { n, open, done, sv, hidden, meta, nb, beaten, stat,
      title: hidden ? '???' : (sec ? sec.title : C.name),
      desc: hidden ? 'Что здесь – секрет. Пройди предыдущую главу.' : (sec ? sec.open : CH_META[n].desc),
      isNew: open && !done && !sv && n > 1 && !!prof['ch' + (n - 1) + 'Done'] };
  }
  function renderMap(prof) {
    const map = $('mMap'), road = $('mRoad'), hero = $('mHero');
    for (const el of [...map.querySelectorAll('.node,.zone,.deco')]) el.remove();
    const N = 6, GAP = 150, TOP = 110, BOT = 90, W = Math.min(map.clientWidth || window.innerWidth, 460);
    const H = TOP + BOT + GAP * N;
    map.style.height = H + 'px';
    const xs = [0.5, 0.27, 0.72, 0.3, 0.7, 0.34, 0.62];
    const pos = i => ({ x: (map.clientWidth || W) / 2 + (xs[i] - 0.5) * W, y: H - BOT - i * GAP }); // i=0 – глава 1, снизу
    const views = [];
    for (let n = 1; n <= N; n++) views.push(chapterView(n, prof));
    let cur = views.find(v => v.open && !v.done) || [...views].reverse().find(v => v.open) || views[0];
    // цветные «зоны» глав и украшения вокруг дороги
    views.forEach((v, i) => {
      const p = pos(i), z = document.createElement('div');
      z.className = 'zone'; z.style.top = (p.y - GAP * 0.75) + 'px'; z.style.height = (GAP * 1.5) + 'px';
      z.style.background = `radial-gradient(ellipse 70% 50% at ${Math.round(xs[i] * 100)}% 50%, ${v.meta.c[0]}, transparent)`;
      z.style.opacity = v.open ? 0.3 : 0.1; map.appendChild(z);
      const eyes = v.n === 4 ? EYES4(xs[i] <= 0.5 ? 1 : -1) : [];
      if (!v.hidden) CH_META[v.n].deco.forEach((d, k) => {
        const side = (k % 2 ? 1 : -1) * (xs[i] < 0.5 ? -1 : 1), dx = side * (70 + hash2(v.n, k) * 70), dy = (hash2(k, v.n) - 0.5) * 90;
        if (eyes.some(([ax, ay]) => Math.hypot(dx + 11 - ax, dy - 3 - ay) < 48)) return; // глаза в темноте не загораживаем
        const e = document.createElement('div'); e.className = 'deco'; e.textContent = d;
        e.style.left = Math.max(6, Math.min((map.clientWidth || W) - 30, p.x + dx)) + 'px'; e.style.top = (p.y + dy - 14) + 'px';
        e.style.animationDelay = (k * 0.7 + v.n * 0.3) + 's'; e.style.opacity = v.open ? 0.85 : 0.35;
        e.addEventListener('click', ev2 => { ev2.stopPropagation(); knockDeco(e, d); });
        map.appendChild(e);
      });
    });
    // дорога
    const pts = views.map((v, i) => pos(i)).concat([pos(N)]);
    let d = `M ${pts[0].x} ${pts[0].y + 70}`;
    let gold = '';
    for (let i = 0; i < pts.length; i++) {
      const a2 = i === 0 ? { x: pts[0].x, y: pts[0].y + 70 } : pts[i - 1], b2 = pts[i], my = (a2.y + b2.y) / 2;
      const seg = ` C ${a2.x} ${my}, ${b2.x} ${my}, ${b2.x} ${b2.y}`;
      d += seg;
      if (i === 0 || (views[i - 1] && views[i - 1].done)) gold += (gold ? '' : `M ${a2.x} ${a2.y}`) + seg;
    }
    road.setAttribute('viewBox', `0 0 ${map.clientWidth || W} ${H}`);
    road.innerHTML = `<path d="${d}" fill="none" stroke="rgba(0,0,0,.35)" stroke-width="30" stroke-linecap="round"/>` +
      `<path d="${d}" fill="none" stroke="#e9d6b0" stroke-width="22" stroke-linecap="round"/>` +
      (gold ? `<path d="${gold}" fill="none" stroke="#ffd25a" stroke-width="22" stroke-linecap="round" opacity=".9"/>` : '') +
      `<path d="${d}" fill="none" stroke="rgba(120,80,40,.55)" stroke-width="3" stroke-dasharray="10 12" stroke-linecap="round"/>`;
    // главы
    views.forEach((v, i) => {
      const p = pos(i), el = document.createElement('button');
      el.className = 'node' + (v.open ? '' : ' locked') + (v.done ? ' done' : '') + (v === cur ? ' cur' : '');
      el.id = 'chap' + v.n; el.style.left = p.x + 'px'; el.style.top = (p.y - 42) + 'px';
      el.style.setProperty('--c1', v.meta.c[0]); el.style.setProperty('--c2', v.meta.c[1]);
      const stars = v.open ? '★'.repeat(v.beaten) + '☆'.repeat(v.nb - v.beaten) : '';
      el.innerHTML = `<div class="med"><span class="ic">${v.open ? v.meta.ic : (v.hidden ? '❔' : '🔒')}</span><b class="num">${v.n}</b>${v.isNew ? '<div class="newb">НОВОЕ</div>' : ''}</div>` +
        `<div class="lbl">${v.title}${stars ? `<span class="pr">${stars}</span>` : ''}</div>`;
      el.insertAdjacentHTML('afterbegin', chapterFx(v, xs[i] <= 0.5 ? 1 : -1));
      el.addEventListener('click', () => { Sound.init(); Sound.sfx.click(); openChapterSheet(v.n); });
      map.appendChild(el);
    });
    // «скоро…»
    const ps = pos(N), soon = document.createElement('button');
    soon.className = 'node soon locked'; soon.style.left = ps.x + 'px'; soon.style.top = (ps.y - 42) + 'px';
    soon.innerHTML = '<div class="med"><span class="ic">☁️</span></div><div class="lbl">Скоро…</div>';
    soon.addEventListener('click', () => toast('Продолжение следует… 🤫'));
    map.appendChild(soon);
    // героиня над текущей главой
    const pc = pos(cur.n - 1), side = xs[cur.n - 1] <= 0.5 ? 1 : -1; // сбоку от медальона, к центру экрана
    hero.style.left = (pc.x + side * 62) + 'px'; hero.style.top = (pc.y - 100) + 'px';
    const hc = $('mHeroCv').getContext('2d'); hc.clearRect(0, 0, 96, 96);
    const hid = cur.hidden ? null : (CH_META[cur.n] || {}).hero;
    if (hid) { const img = heroAvatar(hid); if (img) hc.drawImage(img, 0, 0, 96, 96); }
    $('mSub').textContent = cur.hidden ? 'Спасение Рыжовой' : `Глава ${cur.n} · ${cur.title}`;
    G.menuCur = cur.n;
    requestAnimationFrame(() => { const box = $('mPath'); box.scrollTop = Math.max(0, pc.y - box.clientHeight * 0.55); });
  }
  // ---------- украшения на карте можно сбивать тапом ----------
  const DECO_COL = {
    '❄️': ['#ffffff', '#bfeaff', '#7fd8ff'], '🌨️': ['#ffffff', '#bfeaff'], '⛄': ['#ffffff', '#ff8a2a', '#bfeaff'],
    '🔥': ['#ffe08a', '#ffb03a', '#ff6a1f'], '✨': ['#fff3b0', '#ffd25a', '#ffffff'], '🌲': ['#7dff7d', '#2f9a3a', '#c8ffb0'], '🌳': ['#7dff7d', '#3fae4a'],
    '🍄': ['#ff4a4a', '#ffffff'], '🌼': ['#ffe04a', '#ffffff'], '🪩': ['#ff6fd8', '#6ae6ff', '#ffe08a', '#ffffff'], '💿': ['#c8d4ff', '#ff9ad8', '#9affe8'],
    '🎤': ['#ff6fb5', '#c8c8d8'], '🪞': ['#d8f2ff', '#ffffff', '#ffd25a'], '🦄': ['#ff9ad8', '#9ad8ff', '#fff3b0', '#c8a8ff'], '🌙': ['#ffe08a', '#fff7c8'],
    '🐾': ['#ff9ab8', '#ffd0dc'], '💡': ['#fff7a0', '#ffe04a'], '📺': ['#3ff0a0', '#ff3ea5', '#6ae6ff'], '🐟': ['#6ac8ff', '#ffd25a'],
    '🔎': ['#ffd25a', '#d8f2ff'], '📦': ['#d8a050', '#8a5a2a'], '🥣': ['#ffffff', '#6ac8ff'],
  };
  let decoCombo = 0, decoComboT = 0;
  function knockDeco(el, glyph) {
    if (el.classList.contains('hit')) return;
    Sound.init();
    const cols = DECO_COL[glyph] || ['#ffffff', '#ffd25a'], map = $('mMap');
    const cx = el.offsetLeft + el.offsetWidth / 2, cy = el.offsetTop + el.offsetHeight / 2; // центр значка
    el.style.setProperty('--kx', ((Math.random() < 0.5 ? -1 : 1) * (40 + Math.random() * 50)) + 'px');
    el.style.setProperty('--kr', ((Math.random() < 0.5 ? -1 : 1) * (240 + Math.random() * 200)) + 'deg');
    el.classList.remove('back'); el.classList.add('hit');
    // искры в цветах украшения + пара маленьких копий
    const add = (cls, html, css) => { const b = document.createElement('i'); b.className = cls; if (html) b.textContent = html; b.style.cssText = css; map.appendChild(b); setTimeout(() => b.remove(), 900); };
    for (let k = 0; k < 12; k++) {
      const a = k / 12 * TAU + Math.random() * 0.4, r = 34 + Math.random() * 34, col = cols[k % cols.length];
      add('spark', '', `left:${cx}px;top:${cy}px;background:${col};box-shadow:0 0 6px ${col};--dx:${Math.cos(a) * r}px;--dy:${Math.sin(a) * r}px;animation-duration:${0.5 + Math.random() * 0.3}s`);
    }
    for (let k = 0; k < 2; k++) {
      const a = -Math.PI / 2 + (k ? 0.8 : -0.8);
      add('spark g', glyph, `left:${cx}px;top:${cy}px;--dx:${Math.cos(a) * 46}px;--dy:${Math.sin(a) * 46}px;animation-duration:.7s`);
    }
    add('ringFx', '', `left:${cx}px;top:${cy}px;--rc:${cols[0]}`);
    // серия быстрых тапов – множитель
    const now = performance.now();
    decoCombo = now - decoComboT < 1600 ? decoCombo + 1 : 1; decoComboT = now;
    if (decoCombo >= 2) add('comboFx', '×' + decoCombo + (decoCombo >= 5 ? '!' : ''), `left:${cx}px;top:${cy - 18}px`);
    if (glyph === '❄️' || glyph === '🌨️' || glyph === '🪞') Sound.sfx.glass(); else if (glyph === '🔥') Sound.sfx.fireball(); else Sound.sfx.shard();
    // через несколько секунд украшение возвращается
    setTimeout(() => { if (!el.isConnected) return; el.classList.remove('hit'); void el.offsetWidth; el.classList.add('back'); }, 5000 + Math.random() * 4000);
  }
  // живые украшения у медальонов: глаза в темноте, светлячки, диско-лучи, искры, следы лап, снег
  const EYES4 = side => [[side * 80, -52], [side * 120, 18], [-side * 110, 40]];
  function chapterFx(v, side) {
    const at = (x, y, extra = '') => `style="left:${Math.round(x)}px;top:${Math.round(y)}px;${extra}"`;
    const d = k => `animation-delay:${(-k).toFixed(2)}s;`;
    let h = '';
    if (v.n === 4) { // глаза – как раньше на карточке, видны даже у закрытой главы
      const [e1, e2, e3] = EYES4(side);
      h += `<div class="eyes2" ${at(e1[0] - 22, e1[1] - 6)}><i></i><i></i></div>`;
      h += `<div class="eyes2 s" ${at(e2[0] - 22, e2[1] - 6)}><i style="${d(1.3)}"></i><i style="${d(1.3)}"></i></div>`;
      if (v.open) h += `<div class="eyes2 g s" ${at(e3[0] - 22, e3[1] - 6)}><i style="${d(2.6)}"></i><i style="${d(2.6)}"></i></div>`;
    } else if (v.n === 6) { // снег – тоже виден заранее
      for (let k = 0; k < 7; k++) h += `<b class="sn" ${at(-70 + k * 22 + hash2(k, 6) * 10, -10 + hash2(6, k) * 20, d(k * 0.55))}></b>`;
    } else if (!v.open && v.n === 5) {
      for (let k = 0; k < 3; k++) h += `<b class="q" ${at(side * (55 + k * 22), -20 + k * 18, d(k * 1.1))}>?</b>`;
    } else if (v.open && v.n === 1) {
      for (let k = 0; k < 6; k++) h += `<b class="ff" ${at((hash2(k, 1) - 0.5) * 180, (hash2(1, k) - 0.5) * 110, d(k * 0.85))}></b>`;
    } else if (v.open && v.n === 2) {
      ['rgba(255,110,220,.45)', 'rgba(110,230,255,.45)', 'rgba(255,230,110,.45)'].forEach((col, k) => {
        h += `<b class="beam" style="background:linear-gradient(transparent, ${col});${d(k * 1.66)}"></b>`;
      });
      for (let k = 0; k < 4; k++) h += `<b class="tw" ${at((hash2(k, 2) - 0.5) * 150, (hash2(2, k) - 0.5) * 110, d(k * 0.45))}>✦</b>`;
    } else if (v.open && v.n === 3) {
      for (let k = 0; k < 6; k++) h += `<b class="em" ${at(-40 + k * 16, 22 - hash2(k, 3) * 12, d(k * 0.43))}></b>`;
    } else if (v.open && v.n === 5) {
      for (let k = 0; k < 4; k++) h += `<b class="paw" ${at(side * (52 + k * 22), 46 - k * 22, `transform:rotate(${side * 25}deg);` + `animation-delay:${(k * 0.5).toFixed(1)}s;`)}>🐾</b>`;
    }
    return `<div class="fx">${h}</div>`;
  }
  let sheetCh = 0;
  function openChapterSheet(n) {
    const prof = loadProfile(), sh = $('chapSheet');
    sheetCh = n;
    const show = (id, on) => $(id).classList.toggle('hidden', !on);
    if (n === 'rush') {
      const rushOpen = DEBUG || prof.admin || prof.ch1Done, rb = prof.rushBest;
      sh.style.setProperty('--c1', '#ff8a6a'); sh.style.setProperty('--c2', '#8a1a1a'); sh.style.setProperty('--sc', '110,25,25');
      $('shIc').textContent = '⚔️'; $('shNum').textContent = 'Испытание'; $('shTitle').textContent = 'Босс-раш';
      $('shDesc').textContent = 'Все побеждённые боссы подряд, на время. У всех одинаковая героиня 24 уровня + твои таланты и реликвии';
      $('shStat').textContent = !rushOpen ? '🔒 Откроется после главы 1' : rb ? `🏆 Рекорд: ${rb.n}/${rb.total} боссов за ${fmtT(rb.time)}` : 'Рекорда пока нет';
      $('shPlay').textContent = rushOpen ? 'В бой!' : '🔒 Закрыто';
      const rhId = (prof.settings || {}).rushHero;
      $('rushHero').textContent = '🔄 ' + (HEROES[rhId] ? HEROES[rhId].name : 'Крилесса');
      show('shNew', false); show('shIntro', false); show('ch4Riddle', false); show('rushHero', rushOpen && !!(prof.ch3Done || DEBUG || prof.admin));
    } else {
      const v = chapterView(n, prof);
      sh.style.setProperty('--c1', v.meta.c[0]); sh.style.setProperty('--c2', v.meta.c[1]); sh.style.setProperty('--sc', v.meta.sc);
      $('shIc').textContent = v.open ? v.meta.ic : (v.hidden ? '❔' : '🔒');
      $('shNum').textContent = 'Глава ' + n; $('shTitle').textContent = v.title; $('shDesc').textContent = v.desc; $('shStat').textContent = v.stat;
      $('shPlay').textContent = !v.open ? '🔒 Закрыто' : v.sv ? 'Продолжить' : 'Играть';
      show('shNew', v.open && !!v.sv); show('shIntro', v.done || DEBUG || !!prof.admin); show('ch4Riddle', n === 4 && !prof.ch4Done); show('rushHero', false);
    }
    setState('chapSheet');
  }
  function closeSheet() { setState('menu'); }
  // ---------- таланты за звёзды ----------
  function openTalents() { renderTalents(); setState('talents'); }
  function renderTalents() {
    const pr = loadProfile(), tl = pr.talents || {}, stars = pr.stars || 0, free = stars - talentSpent(tl);
    $('talStars').textContent = `⭐ Свободно звёзд: ${free} из ${stars}`;
    const box = $('talList'); box.innerHTML = '';
    for (const d of TALENTS) {
      const r = tl[d.id] || 0, el = document.createElement('div');
      el.className = 'tal' + (r >= d.max ? ' max' : '');
      el.innerHTML = `<div class="ic">${d.ic}</div><div class="tx"><b>${d.nm}</b><i>${d.ds}</i><div class="pips">${'★'.repeat(r)}${'☆'.repeat(d.max - r)}</div></div>`;
      const bt = document.createElement('button');
      bt.textContent = r >= d.max ? 'макс.' : `+ ${d.cost}⭐`;
      bt.disabled = r >= d.max || free < d.cost;
      bt.addEventListener('click', () => {
        const p2 = loadProfile(); p2.talents = p2.talents || {};
        if ((p2.talents[d.id] || 0) >= d.max || (p2.stars || 0) - talentSpent(p2.talents) < d.cost) return;
        p2.talents[d.id] = (p2.talents[d.id] || 0) + 1; saveProfile(p2);
        Sound.sfx.superReady(); renderTalents();
      });
      el.appendChild(bt); box.appendChild(el);
    }
  }
  // ---------- обновления через интернет (только в приложении на Android) ----------
  const kb = v => v >= 1048576 ? (v / 1048576).toFixed(1) + ' МБ' : Math.max(1, Math.round(v / 1024)) + ' КБ';
  function showUpdate() {
    const box = $('updBox'), u = G.update;
    if (!u || u.hiddenByUser || !['found', 'progress', 'ready', 'apk', 'loading', 'perm', 'installer', 'error'].includes(u.type)) { box.classList.add('hidden'); return; }
    const ic = $('updIc'), bar = $('updBar'), fill = $('updFill'), btns = box.querySelector('.updBtns');
    const quote = u.title ? `«${u.title}»` : '';
    let title = '', text = '', icon = '🔄', anim = 'spin', go = '', later = false, pct = -1;
    if (u.type === 'found' || u.type === 'progress') {
      title = `Обновление v${u.version}`;
      pct = u.total > 0 ? Math.min(100, Math.round(u.done / u.total * 100)) : -1;
      text = (quote ? quote + ' · ' : '') + (pct >= 0 ? `скачиваю ${pct}% · ${kb(u.done)} из ${kb(u.total)}` : 'скачиваю…');
    } else if (u.type === 'ready') {
      title = `Обновление v${u.version} готово!`; text = quote || 'Перезапусти – и играй в новой версии'; icon = '✨'; anim = 'bounce'; go = 'Перезапустить'; later = true; pct = 100;
    } else if (u.type === 'apk') {
      title = `Новая версия приложения v${u.version}`; text = (quote ? quote + ' · ' : '') + 'нужна переустановка, это быстро'; icon = '📦'; anim = 'bounce'; go = 'Скачать и установить'; later = true;
    } else if (u.type === 'loading') {
      title = 'Скачиваю приложение'; icon = '⬇️'; anim = 'bounce';
      pct = u.total > 0 ? Math.min(100, Math.round(u.done / u.total * 100)) : -1;
      text = pct >= 0 ? `${pct}% · ${kb(u.done)} из ${kb(u.total)}` : 'подожди немного…';
    } else if (u.type === 'perm') {
      title = 'Нужно разрешение'; text = 'Разреши установку приложений для Крилессы, вернись и нажми ещё раз'; icon = '🔐'; anim = ''; go = 'Установить';
    } else if (u.type === 'installer') {
      title = 'Почти готово'; text = 'Подтверди установку в окне Android'; icon = '📦'; anim = 'bounce'; go = 'Открыть ещё раз';
    } else {
      title = 'Не получилось скачать'; text = 'Проверь интернет и попробуй ещё раз'; icon = '⚠️'; anim = ''; go = 'Ещё раз'; later = true;
    }
    ic.textContent = icon; ic.className = anim;
    $('updTitle').textContent = title; $('updText').textContent = text;
    bar.classList.toggle('hidden', pct === -1 && !['found', 'progress', 'loading'].includes(u.type));
    bar.classList.toggle('indet', pct < 0);
    if (pct >= 0) fill.style.width = pct + '%';
    $('updGo').textContent = go; $('updGo').classList.toggle('hidden', !go); $('updLater').classList.toggle('hidden', !later);
    btns.classList.toggle('hidden', !go && !later);
    box.classList.remove('hidden');
  }
  window.krUpdate = u => {
    if (!u || !u.type) return;
    const prev = G.update;
    if (u.type === 'fail') { G.update = null; showUpdate(); if (prev) toast('⚠️ Обновление не скачалось – попробую в следующий раз'); return; }
    if (['found', 'progress', 'ready', 'apk', 'loading'].includes(u.type)) G.update = Object.assign({ base: u.type === 'loading' ? 'apk' : undefined }, prev && u.type === 'loading' ? { version: prev.version, title: prev.title } : {}, u);
    else if (prev) G.update = Object.assign({}, prev, { type: u.type, base: prev.base || prev.type });
    showUpdate();
    // в игре не мешаем – только короткая подсказка
    if (state !== 'menu' && state !== 'chapSheet') {
      if (u.type === 'found' && !(prev && prev.type === 'found')) toast(`⬇️ Скачивается обновление v${u.version}…`);
      if (u.type === 'ready' && !(prev && prev.type === 'ready')) toast(`✨ Обновление v${u.version} готово – перезапусти в меню`);
      if (u.type === 'apk' && !(prev && prev.type === 'apk')) toast(`📦 Вышла новая версия приложения v${u.version}`);
    }
  };
  function updateSoundButtons() {
    const t = 'Звук: ' + (Sound.isEnabled() ? 'вкл' : 'выкл');
    $('btnSound').textContent = t; $('btnSound2').textContent = t;
  }
  const onTap = (id, fn) => $(id).addEventListener('click', () => { Sound.init(); Sound.sfx.click(); fn(); });
  const introOpen = n => { const pr = loadProfile(); return DEBUG || !!pr.admin || !!pr['ch' + n + 'Done']; };
  onTap('btnIntro', () => introOpen(1) ? Intro.start('ch1', openMenu) : toast('🔒 Интро 1 откроется после главы 1'));
  onTap('btnIntro2', () => introOpen(2) ? Intro.start('ch2', openMenu) : toast('🔒 Интро 2 откроется после главы 2'));
  onTap('btnIntro3', () => introOpen(3) ? Intro.start('ch3', openMenu) : toast('🔒 Интро 3 откроется после главы 3'));
  onTap('btnIntro4', () => introOpen(4) ? Intro.start('ch4', openMenu) : toast('🔒 Интро 4 откроется после главы 4'));
  onTap('btnIntro5', () => introOpen(5) ? Intro.start('ch5', openMenu) : toast('🔒 Интро 5 откроется после главы 5'));
  onTap('btnIntro6', () => introOpen(6) ? Intro.start('ch6', openMenu) : toast('🔒 Интро 6 откроется после главы 6'));
  onTap('btnTalents', openTalents);
  onTap('updGo', () => {
    const A = window.KrilessaAndroid, u = G.update; if (!A || !u) return;
    const kind = u.base || u.type;
    if (kind === 'ready') {
      $('updOverlay').classList.remove('hidden'); Sound.sfx.superReady();
      setTimeout(() => { if (A.applyUpdate) A.applyUpdate(); }, 900);
      setTimeout(() => $('updOverlay').classList.add('hidden'), 6000);
    } else if (A.installApk) A.installApk();
  });
  onTap('updLater', () => { if (G.update) G.update.hiddenByUser = true; showUpdate(); toast('Хорошо! Обновление включится само при следующем запуске'); });
  // главный экран: карточка главы, панель, настройки
  onTap('shClose', closeSheet);
  $('shBack').addEventListener('click', closeSheet);
  onTap('shPlay', () => {
    if (sheetCh === 'rush') { const pr = loadProfile(); if (DEBUG || pr.admin || pr.ch1Done) startRush(); else toast('🔒 Босс-раш откроется после главы 1'); return; }
    if (!chapterOpen(sheetCh)) { toast(`🔒 Сначала пройди главу ${sheetCh - 1}`); return; }
    startChapter(sheetCh);
  });
  onTap('shNew', () => { const n = sheetCh; try { localStorage.removeItem(saveKey(n)); } catch (e) { /* ignore */ } startChapter(n); });
  onTap('shIntro', () => { const n = sheetCh; Intro.start('ch' + n, openMenu); });
  onTap('chapRush', () => openChapterSheet('rush'));
  onTap('mStars', openTalents);
  onTap('btnGear', () => setState('settings'));
  onTap('setBack', openMenu);
  // ---------- режим админа: 5 касаний по номеру версии в меню ----------
  const ADMIN_HASH = 'xa5467';
  const passHash = str => { let x = 5381; for (const ch of str) x = ((x * 33) ^ ch.codePointAt(0)) >>> 0; return x.toString(36); };
  let verTaps = 0, verT = 0;
  $('menu').querySelector('.version').addEventListener('click', () => {
    const now = performance.now(); verTaps = now - verT < 1500 ? verTaps + 1 : 1; verT = now;
    if (verTaps >= 5) { verTaps = 0; openAdmin(); }
  });
  function openAdmin() {
    const on = !!loadProfile().admin;
    $('adminHint').className = 'hint';
    $('adminHint').textContent = on ? 'Режим админа включён ✅ Все главы, интро и босс-раш открыты' : 'Введи пароль – откроются все главы, интро и босс-раш';
    $('adminPass').classList.toggle('hidden', on); $('adminPass').value = '';
    $('adminOk').textContent = on ? 'Выключить' : 'Войти';
    setState('admin');
    if (!on) setTimeout(() => $('adminPass').focus(), 50);
  }
  function adminSubmit() {
    const pr = loadProfile();
    if (pr.admin) { delete pr.admin; saveProfile(pr); toast('🔒 Режим админа выключен'); openMenu(); return; }
    if (passHash($('adminPass').value.trim().toLowerCase()) !== ADMIN_HASH) {
      $('adminHint').className = 'hint bad'; $('adminHint').textContent = 'Неверный пароль'; $('adminPass').value = ''; Sound.sfx.hurt(); return;
    }
    pr.admin = true; saveProfile(pr); Sound.sfx.superReady();
    toast('🔓 Открыты все главы, интро и босс-раш'); openMenu();
  }
  onTap('adminOk', adminSubmit);
  onTap('adminBack', openMenu);
  $('adminPass').addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); adminSubmit(); } });
  onTap('talBack', openMenu);
  onTap('talReset', () => {
    const pr = loadProfile(); if (!talentSpent(pr.talents || {})) return;
    pr.talents = {};
    if ((pr.relics || []).length > 3) { pr.relics = pr.relics.slice(0, 3); toast('🎒 Четвёртый карман пуст – последняя реликвия убрана'); }
    saveProfile(pr); renderTalents();
  });
  onTap('rushHero', () => {
    const pr = loadProfile(); pr.settings = pr.settings || {};
    const list = ['krilessa', 'ryzhovaya'].concat(pr.ch4Done || DEBUG || pr.admin ? ['tessa'] : []);
    pr.settings.rushHero = list[(list.indexOf(pr.settings.rushHero || 'krilessa') + 1) % list.length]; saveProfile(pr); openChapterSheet('rush');
  });
  onTap('btnDiff', () => {
    const pr = loadProfile(); pr.settings = pr.settings || {};
    const order = ['easy', 'normal', 'hard'], cur = pr.settings.diff || 'normal';
    pr.settings.diff = order[(order.indexOf(cur) + 1) % 3]; saveProfile(pr);
    $('btnDiff').textContent = 'Сложность: ' + DIFFS[pr.settings.diff].name;
    toast(pr.settings.diff === 'hard' ? 'Кринж-хардкор: враги злее, элита чаще 😈' : pr.settings.diff === 'easy' ? 'Лёгкий режим: можно расслабиться 🍵' : 'Нормальная сложность');
  });
  onTap('btnStats', openStats); onTap('btnStats2', openStats); onTap('btnStats3', openStats); onTap('btnStats4', openStats);
  onTap('statsShare', () => shareText(buildReport()));
  onTap('statsCopy', () => copyText(buildReport()));
  onTap('statsBack', () => { if (statsBack === 'menu') openMenu(); else setState(statsBack); });
  onTap('btnWhatsNew', () => openWhatsNew(null));
  onTap('wnClose', closeWhatsNew);
  onTap('ch4Riddle', openTeaser);
  onTap('relicMelt', () => { for (let i = 0; i < 12; i++) dropShard(P.x + rnd(-40, 40), P.y + rnd(-40, 40)); setState('play'); toast('💎 Реликвия переплавлена в 12 осколков'); });
  onTap('mapClose', () => setState('play'));
  $('mapCanvas').addEventListener('click', () => setState('play'));
  onTap('btnIntros', () => setState('intros'));
  onTap('introsBack', () => setState('menu'));
  onTap('choiceGood', () => finishCh4('good'));
  onTap('choiceKind', () => finishCh4('kind'));
  onTap('boardGo', () => { setState('play'); if (G.pendingLv > 0) openLevelUp(); });
  onTap('npcBtn', () => openNpc(G.nearNpc));
  onTap('btnWardrobe', openWardrobe);
  onTap('wardBack', () => { if (wardBack === 'menu') openMenu(); else setState(wardBack); });
  onTap('portalBtn', openPortals);
  onTap('portalBack', () => setState('play'));
  onTap('teaserBack', closeTeaser);
  $('teaserCanvas').addEventListener('pointerdown', () => { Sound.init(); Sound.sfx.meow(); teaserGlow = 1; });
  onTap('zmPlay', () => zmReact('Браво мне! БРАВО! Но спектакль ещё не окончен! 😈', true));
  onTap('zmLike', () => zmReact('Роза?! Мне?! ...Спасибо, зайка. Но тебя это не спасёт! 🌹😈', true));
  onTap('zmDonate', () => zmReact('ПОМИДОР?! В мою лучшую корону?! Ну всё!!! 🍅😤', true));
  $('zmExit').addEventListener('pointerdown', e => {
    e.preventDefault(); Sound.init(); Sound.sfx.click();
    if (!G.zm) return;
    G.zm.tries++;
    const el = $('zmExit');
    el.style.transform = `translate(${rnd(-110, 110)}px, ${rnd(-140, 60)}px) rotate(${rnd(-25, 25)}deg)`;
    el.textContent = ['✖ Выйти', 'Куда?! 😏', 'Не-не-не!', 'Выхода нет 😈'][Math.min(3, G.zm.tries)];
    if (G.zm.tries >= 3) zmReact('Из театра не уходят посреди спектакля! Второй акт! 😈', true);
  });
  // пасхалка: потыкай портрет в меню
  let portraitTaps = 0;
  $('menuPortrait').addEventListener('click', () => {
    portraitTaps++;
    if (portraitTaps % 7 === 0) {
      const c = $('menuPortrait').getContext('2d');
      if (IMG.zyama) c.drawImage(IMG.zyama.cartoon, 0, 0, 240, 320);
      Sound.init(); Sound.sfx.roar();
      toast('Зямочкккк: Эй! Не трогай её! Я ей, между прочим, стих посвятил! 😤');
      setTimeout(drawMenuPortrait, 2200);
    }
  });
  onTap('btnSound', () => { Sound.setEnabled(!Sound.isEnabled()); updateSoundButtons(); });
  onTap('btnSound2', () => { Sound.setEnabled(!Sound.isEnabled()); updateSoundButtons(); });
  onTap('btnResume', resumeGame);
  onTap('btnToMenu', () => { saveGame(); openMenu(); });
  onTap('btnRetry', respawn);
  onTap('btnDeadMenu', () => { saveGame(); openMenu(); });
  onTap('btnVictoryMenu', openMenu);
  onTap('victoryNext', () => startChapter(CHN + 1));
  for (const el of document.querySelectorAll('.version')) el.textContent = 'v' + VERSION;

  window.krBack = () => {
    if (state === 'stats') { if (statsBack === 'menu') openMenu(); else setState(statsBack); return 'handled'; }
    if (state === 'whatsnew') { closeWhatsNew(); return 'handled'; }
    if (state === 'teaser') { closeTeaser(); return 'handled'; }
    if (state === 'choice' || state === 'relic') return 'handled';
    if (state === 'mapscr') { setState('play'); return 'handled'; }
    if (state === 'intros') { setState('menu'); return 'handled'; }
    if (state === 'talents' || state === 'admin') { openMenu(); return 'handled'; }
    if (state === 'chapSheet' || state === 'settings') { openMenu(); return 'handled'; }
    if (state === 'board') { if (G.accused) { setState('play'); if (G.pendingLv > 0) openLevelUp(); } return 'handled'; }
    if (state === 'npc') { setState('play'); return 'handled'; }
    if (state === 'wardrobe') { if (wardBack === 'menu') openMenu(); else setState(wardBack); return 'handled'; }
    if (state === 'portal') { setState('play'); return 'handled'; }
    if (state === 'zmenu') { zmReact('Кнопка «Назад» тоже моя! Сидеть и смотреть! 😈', true); return 'handled'; }
    if (state === 'victory' && $('victoryButtons').classList.contains('hidden')) return 'handled';
    if (state === 'play') { pauseGame(); return 'handled'; }
    if (state === 'pause') { resumeGame(); return 'handled'; }
    if (state === 'levelup') return 'handled';
    if (state === 'intro') { Intro.skip(); return 'handled'; }
    if (state === 'dead' || state === 'victory') { openMenu(); return 'handled'; }
    return 'exit';
  };
  window.krPause = () => { if (state === 'play') pauseGame(); Sound.suspend(); };
  window.krResume = () => { Sound.resume(); };
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) { if (state === 'play') pauseGame(); Sound.suspend(); }
    else Sound.resume();
  });

  // ------------------------------------------------------------------
  //  Интро (две истории)
  // ------------------------------------------------------------------
  const Intro = (() => {
    const cv = $('introCanvas'), c = cv.getContext('2d');
    const STORIES = {
      ch1: {
        wipe: [2.9, 5.2], end: 14.6,
        scenes: [
          { at: 0, text: 'Это Рыжовая.<br>Самая обычная девушка…' },
          { at: 2.6, text: '…пока на неё не упала<br><b>волшебная искра</b>!', sfx: 'magic' },
          { at: 5.4, text: 'Теперь она – <b>мультяшная</b>!', sfx: 'level', flash: true },
          { at: 7.8, text: 'Но злой колдун <b>Мрак</b> похитил её<br>и запер в Тёмном замке!', sfx: 'roar' },
          { at: 11.0, text: 'Спасти её может только<br>отважная крылатая <b>Крилесса</b>!', music: 'menu' },
        ],
      },
      ch2: {
        wipe: [6.3, 8.4], end: 18.2,
        scenes: [
          { at: 0, text: 'Рыжовая спасена! Крилесса и Рыжовая<br>пьют какао и смотрят на звёзды…', music: 'menu' },
          { at: 3.0, text: '…как вдруг небо треснуло,<br>и из портала вылез <b>ОН</b>.', sfx: 'roar' },
          { at: 6.0, text: 'Мультяшная магия сделала его…<br><b>ещё кринжовее</b>!', sfx: 'magic' },
          { at: 8.6, text: '«Трепещите, зайки! Я – <b>ЗЯМОЧКККК</b>,<br>Император Кринжа!» 💅', sfx: 'level', flash: true, music: 'final' },
          { at: 11.8, text: '«Рыжовая будет слушать мои стихи.<br><b>ВЕЧНО!</b>»', sfx: 'gate' },
          { at: 14.8, text: '<b>Глава 2: Кринж-Цитадель</b><br>Крилесса, вперёд! Спаси её снова!' },
        ],
      },
      ch4: {
        end: 17,
        scenes: [
          { at: 0, text: 'Три часа ночи. Весь дом спит.<br>Тесса спит <b>двадцать часов в сутки</b>…', music: 'night4' },
          { at: 3.4, text: '…но этой ночью её разбудил<br><b>странный звук</b>.', sfx: 'staticNoise' },
          { at: 6.6, text: 'Лампочки мигают. Телевизор включился сам.<br>Из экрана смотрят <b>зелёные глаза</b>.', sfx: 'whisper' },
          { at: 10, text: '«Мяу. Я – <b>Мяу.exe</b>.<br>Теперь это <b>мой</b> дом.»', sfx: 'roar', flash: true, music: 'tv4' },
          { at: 13.4, text: '<b>Глава 4: Ночь глитчей</b><br>Тесса одна. Но она видит всё.', sfx: 'meow' },
        ],
      },
      ch5: {
        end: 16,
        scenes: [
          { at: 0, text: 'Утро. Солнце. Пахнет блинчиками…', music: 'morning5' },
          { at: 3.2, text: 'Тесса идёт к миске и видит…<br><b>ПУСТОТУ</b>.', sfx: 'roar' },
          { at: 6.4, text: 'Корм пропал. Из <b>всех</b> мисок в доме!', sfx: 'staticNoise' },
          { at: 9.4, text: 'Тесса надевает шапку детектива.<br>Это дело – для неё. 🕵️', sfx: 'magic', flash: true },
          { at: 12.6, text: '<b>Глава 5: Пропавший корм</b><br>Ищи улики. Допрашивай подозреваемых.', sfx: 'meow', music: 'detective5' },
        ],
      },
      ch6: {
        end: 16,
        scenes: [
          { at: 0, text: 'Лето. Банкет в честь Тессы.<br>Торт, музыка, все друзья вместе. 🎉', music: 'truewin' },
          { at: 3.2, text: 'И вдруг… пошёл снег.<br><b>В июле.</b>', sfx: 'whisper' },
          { at: 6.4, text: '«Новый сезон, – прошептал Мрак. –<br>Вечная <b>зима</b>.» 👑❄️', sfx: 'roar', flash: true, music: 'mrakboss' },
          { at: 9.6, text: 'Лёд сковал Тессу – и Мрак унёс её<br>в свой Ледяной замок!', sfx: 'shatter' },
          { at: 12.8, text: '<b>Глава 6: Мрак – новый сезон</b><br>Крилесса и Рыжовая – вместе! Меняйтесь кнопкой 🔄', sfx: 'magic', music: 'winter6' },
        ],
      },
      ch3: {
        wipe: [12.8, 14.8], end: 19,
        scenes: [
          { at: 0, text: 'Прошла неделя. Крилесса и Рыжовая –<br>теперь лучшие подруги.', music: 'menu' },
          { at: 3.0, text: 'Но вдруг из всех зеркал мира<br>раздалось: «<b>Трепещите, зайки!</b>»', sfx: 'roar' },
          { at: 6.2, text: '<b>Зямочкккк</b> сдержал слово и вернулся<br>в версии 0.03. Теперь он – <b>2.0</b>!', sfx: 'level', flash: true, music: 'final2' },
          { at: 9.2, text: 'Он затянул Крилессу в свой<br><b>Зеркальный Зямоверс</b>!', sfx: 'gate' },
          { at: 12.4, text: 'Но у Рыжовой есть секрет:<br>её волосы – <b>настоящий огонь</b>!', sfx: 'magic' },
          { at: 15.6, text: '<b>Глава 3: Рыжовая спешит на помощь</b><br>Теперь ты играешь за неё!', sfx: 'level', flash: true },
        ],
      },
    };
    let story = null, t = 0, last = 0, scene = -1, running = false, done = null, raf = 0, sparks = [], flash = 0, lightning = 0;
    function start(which, cb) {
      story = STORIES[which]; story.id = which; Dialog.clear(); $('introTap').classList.remove('ready');
      done = cb; t = 0; scene = -1; sparks = []; flash = 0; running = true;
      setState('intro');
      last = performance.now();
      cancelAnimationFrame(raf); raf = requestAnimationFrame(frame);
    }
    function skip() { if (running) finish(); }
    function finish() { running = false; cancelAnimationFrame(raf); if (done) done(); }
    // интро листается по касанию: сцена доигрывает анимацию и ждёт
    function boundary() { for (const s of story.scenes) if (s.at > t + 0.02) return s.at; return story.end; }
    function next() { t = boundary(); $('introTap').classList.remove('ready'); }
    cv.addEventListener('pointerdown', () => { Sound.init(); if (running) next(); });
    $('introSkip').addEventListener('click', () => { Sound.init(); skip(); });
    function setText(html) {
      const el = $('introText');
      el.style.opacity = 0;
      setTimeout(() => { el.innerHTML = html; el.style.opacity = 1; }, 200);
    }
    function frame(now) {
      if (!running) return;
      const dt = Math.min(0.05, (now - last) / 1000); last = now;
      if (t >= story.end) { finish(); return; }
      const lim = boundary() - 0.06;
      if (t + dt < lim) t += dt; else { t = Math.max(t, lim); $('introTap').classList.add('ready'); }
      let s = 0; for (let i = 0; i < story.scenes.length; i++) if (t >= story.scenes[i].at) s = i;
      if (s !== scene) {
        scene = s; const sc = story.scenes[s];
        setText(sc.text);
        if (sc.sfx) Sound.sfx[sc.sfx]();
        if (sc.flash) flash = 1;
        if (sc.music) Sound.music(sc.music);
        if (sc.sfx === 'roar') lightning = 0.6;
      }
      if (story.id === 'ch1') drawCh1(dt); else if (story.id === 'ch2') drawCh2(dt); else if (story.id === 'ch4') drawCh4(dt); else if (story.id === 'ch5') drawCh5(dt); else if (story.id === 'ch6') drawCh6(dt); else drawCh3(dt);
      if (flash > 0) { c.setTransform(1, 0, 0, 1, 0, 0); c.fillStyle = `rgba(255,255,255,${flash})`; c.fillRect(0, 0, cv.width, cv.height); flash -= dt * 2; }
      raf = requestAnimationFrame(frame);
    }
    function setup() {
      const W = window.innerWidth, H = window.innerHeight, dpr = Math.min(window.devicePixelRatio || 1, 2);
      if (cv.width !== Math.round(W * dpr) || cv.height !== Math.round(H * dpr)) { cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr); }
      c.setTransform(dpr, 0, 0, dpr, 0, 0);
      return [W, H];
    }
    function bg(W, H, top, bottom) {
      const g = c.createLinearGradient(0, 0, 0, H);
      g.addColorStop(0, top); g.addColorStop(1, bottom);
      c.fillStyle = g; c.fillRect(0, 0, W, H);
      for (let i = 0; i < 60; i++) {
        const x = hash2(i, 1) * W, y = hash2(i, 2) * H, tw = 0.5 + 0.5 * Math.sin(t * 2 + i);
        c.fillStyle = `rgba(255,255,255,${0.15 + tw * 0.35})`; c.fillRect(x, y, 2, 2);
      }
    }
    // Полароид с фото; wipe 0..1 – превращение в мультик
    function card(img, cx, cy, cw, sc, rot, alpha, wipe, caption, cageK, sparkCols, dt) {
      const ch = cw * 4 / 3;
      c.save();
      c.translate(cx, cy); c.rotate(rot); c.scale(sc, sc);
      c.globalAlpha = alpha;
      c.fillStyle = 'rgba(0,0,0,0.4)'; c.fillRect(-cw / 2 - 4, -ch / 2 - 2, cw + 28, ch + 60);
      c.fillStyle = '#fff8ee'; c.fillRect(-cw / 2 - 12, -ch / 2 - 12, cw + 24, ch + 64);
      c.drawImage(wipe >= 1 ? img.cartoon : img.photo, -cw / 2, -ch / 2, cw, ch);
      const toX = u => -cw / 2 + u * cw, toY = v => -ch / 2 + v * ch;
      if (wipe > 0 && wipe < 1) {
        const dl = -0.12 + wipe * 1.24;
        c.save(); c.beginPath();
        c.moveTo(toX(2 * dl + 10), toY(-10)); c.lineTo(toX(-10), toY(2 * dl + 10)); c.lineTo(toX(-40), toY(-40)); c.closePath();
        c.clip(); c.drawImage(img.cartoon, -cw / 2, -ch / 2, cw, ch); c.restore();
        for (let k = 0; k < 4; k++) {
          const u = Math.random(), v = 2 * dl - u;
          if (v >= 0 && v <= 1) sparks.push({ x: toX(u), y: toY(v), vx: rnd(-40, 40), vy: rnd(-60, 20), life: rnd(0.4, 0.9), r: rnd(3, 8), rot: rnd(0, TAU), col: pick(sparkCols) });
        }
        c.save(); c.beginPath(); c.rect(-cw / 2, -ch / 2, cw, ch); c.clip();
        c.strokeStyle = 'rgba(255,240,180,0.9)'; c.lineWidth = 4;
        c.beginPath(); c.moveTo(toX(2 * dl), toY(0)); c.lineTo(toX(0), toY(2 * dl)); c.stroke();
        c.restore();
      }
      c.fillStyle = '#5a2a10'; c.textAlign = 'center';
      c.font = `bold ${Math.round(cw * 0.1)}px "Comic Sans MS", "Trebuchet MS", sans-serif`;
      c.fillText(caption, 0, ch / 2 + 36);
      if (cageK > 0) {
        const off = (1 - cageK) * -ch * 1.3;
        c.strokeStyle = '#3a3a48'; c.lineWidth = Math.max(5, cw * 0.03);
        for (let i = 0; i <= 6; i++) { const x = -cw / 2 - 6 + i * (cw + 12) / 6; c.beginPath(); c.moveTo(x, -ch / 2 - 16 + off); c.lineTo(x, ch / 2 + 50 + off); c.stroke(); }
        c.strokeStyle = '#ffd25a'; c.lineWidth = Math.max(7, cw * 0.04);
        c.beginPath(); c.moveTo(-cw / 2 - 16, -ch / 2 - 16 + off); c.lineTo(cw / 2 + 16, -ch / 2 - 16 + off); c.stroke();
        c.beginPath(); c.moveTo(-cw / 2 - 16, ch / 2 + 50 + off); c.lineTo(cw / 2 + 16, ch / 2 + 50 + off); c.stroke();
      }
      c.globalCompositeOperation = 'lighter';
      for (const s of sparks) {
        s.x += s.vx * dt; s.y += s.vy * dt; s.life -= dt; s.rot += dt * 4;
        c.globalAlpha = clamp(s.life, 0, 1); c.fillStyle = s.col;
        star(c, s.x, s.y, s.r, s.rot); c.fill();
      }
      sparks = sparks.filter(s => s.life > 0);
      c.globalCompositeOperation = 'source-over';
      c.restore();
    }
    function title(W, k, main, sub, col = '#ffd25a', glow = '#7a2a00') {
      c.globalAlpha = k; c.textAlign = 'center';
      const fs = Math.min(W * 0.12, 56);
      c.font = `900 ${fs}px "Trebuchet MS", sans-serif`;
      c.fillStyle = glow; c.fillText(main, W / 2, SAFE_TOP + fs + 50);
      c.fillStyle = col; c.fillText(main, W / 2, SAFE_TOP + fs + 46);
      if (sub) { c.font = `bold ${fs * 0.42}px "Trebuchet MS", sans-serif`; c.fillStyle = '#ffe8d0'; c.fillText(sub, W / 2, SAFE_TOP + fs * 1.6 + 50); }
      c.globalAlpha = 1;
    }
    function drawCh1(dt) {
      const [W, H] = setup();
      const dark = clamp((t - 7.6) / 0.8, 0, 1) * (1 - clamp((t - 11) / 1, 0, 1));
      bg(W, H, `rgb(${lerp(70, 15, dark) | 0},${lerp(30, 8, dark) | 0},${lerp(100, 30, dark) | 0})`, `rgb(${lerp(20, 5, dark) | 0},${lerp(8, 3, dark) | 0},${lerp(30, 10, dark) | 0})`);
      if (t > 7.8 && t < 11 && Math.random() < 0.02) lightning = 0.5;
      if (lightning > 0) { c.fillStyle = `rgba(200,170,255,${lightning * 0.6})`; c.fillRect(0, 0, W, H); lightning -= dt * 2; }
      const cw = Math.min(W * 0.7, H * 0.42 * 0.75), ch = cw * 4 / 3;
      let cx = W / 2, cy = H * 0.42, sc = 1;
      if (t < 0.9) sc = 0.85 + 0.15 * ease(t / 0.9);
      if (t >= 5.4 && t < 7.8) sc = 1 + 0.07 * Math.sin((t - 5.4) * 12) * Math.exp(-(t - 5.4) * 2.5);
      if (t > 8.6 && t < 9.4) cx += Math.sin(t * 60) * 6 * (9.4 - t);
      const titleK = ease((t - 11) / 1.0);
      cy -= titleK * H * 0.06; sc *= 1 - titleK * 0.22;
      const wipe = clamp((t - story.wipe[0]) / (story.wipe[1] - story.wipe[0]), 0, 1);
      card(IMG.ryzhova, cx, cy, cw, sc, -0.035, clamp(t / 0.8, 0, 1), wipe, t >= 5.4 ? '★ Рыжовая ★' : 'Рыжовая', ease((t - 8.1) / 0.5), ['#ffe066', '#ffb03a', '#fff3b0'], dt);
      if (t > 7.8 && t < 11.4) {
        const a = clamp((t - 7.8) / 0.6, 0, 1) * (1 - clamp((t - 10.8) / 0.6, 0, 1));
        c.fillStyle = `rgba(255,91,240,${a})`;
        const ey = H * 0.09 + SAFE_TOP;
        c.beginPath(); c.ellipse(W / 2 - 30, ey, 16, 7, 0.25, 0, TAU); c.ellipse(W / 2 + 30, ey, 16, 7, -0.25, 0, TAU); c.fill();
      }
      if (titleK > 0) {
        title(W, titleK, 'Крилесса', 'Спасение Рыжовой');
        const kx = lerp(-60, W * 0.78, ease((t - 11.2) / 1.4)), ky = cy + ch * sc * 0.66 + Math.sin(t * 3) * 8;
        drawKrilessa(c, kx, ky, t, 1, Math.min(4, W / 110), titleK, true);
      }
    }
    function drawCh2(dt) {
      const [W, H] = setup();
      const neon = clamp((t - 8.4) / 0.6, 0, 1);
      bg(W, H, neon > 0 ? `rgb(${lerp(42, 60, neon) | 0},${lerp(22, 10, neon) | 0},${lerp(64, 90, neon) | 0})` : '#2a1640', '#0a0614');
      if (lightning > 0) { c.fillStyle = `rgba(255,120,220,${lightning * 0.5})`; c.fillRect(0, 0, W, H); lightning -= dt * 2; }
      if (neon > 0) {
        for (let k = 0; k < 6; k++) {
          const a = t * 0.6 + k * TAU / 6;
          c.strokeStyle = k % 2 ? `rgba(255,62,165,${0.18 * neon})` : `rgba(63,240,255,${0.18 * neon})`; c.lineWidth = 30;
          c.beginPath(); c.moveTo(W / 2, H * 0.4); c.lineTo(W / 2 + Math.cos(a) * H, H * 0.4 + Math.sin(a) * H); c.stroke();
        }
      }
      const cw = Math.min(W * 0.62, H * 0.38 * 0.75);
      const ks = Math.min(4, W / 110);
      // Рыжовая (празднует, потом попадает в клетку)
      const move = ease((t - 11.8) / 1.2);
      const ryzX = lerp(W * 0.32, W * 0.5, move), ryzY = lerp(H * 0.62, H * 0.66, move);
      const ryzR = Math.min(W, H) * 0.13;
      if (t < 3.2 || t > 11.6) {
        const a = t < 3.2 ? 1 - clamp((t - 2.6) / 0.6, 0, 1) : clamp((t - 11.6) / 0.4, 0, 1);
        c.save(); c.globalAlpha = a;
        if (AVATAR.ryzhovaBig) { c.save(); c.beginPath(); c.arc(ryzX, ryzY, ryzR, 0, TAU); c.clip(); c.drawImage(AVATAR.ryzhovaBig, ryzX - ryzR, ryzY - ryzR, ryzR * 2, ryzR * 2); c.restore(); }
        c.strokeStyle = '#ff7a2f'; c.lineWidth = 5; c.beginPath(); c.arc(ryzX, ryzY, ryzR, 0, TAU); c.stroke();
        if (t > 12.6) {
          const k = ease((t - 12.6) / 0.5), off = (1 - k) * -H * 0.5;
          c.strokeStyle = '#ff3ea5'; c.lineWidth = 6;
          for (let i = 0; i <= 5; i++) { const x = ryzX - ryzR - 6 + i * (ryzR * 2 + 12) / 5; c.beginPath(); c.moveTo(x, ryzY - ryzR - 14 + off); c.lineTo(x, ryzY + ryzR + 10 + off); c.stroke(); }
          c.strokeStyle = '#3ff0ff'; c.lineWidth = 8; c.beginPath(); c.moveTo(ryzX - ryzR - 12, ryzY - ryzR - 14 + off); c.lineTo(ryzX + ryzR + 12, ryzY - ryzR - 14 + off); c.stroke();
        }
        c.restore();
      }
      if (t < 3.2) {
        const r0 = 1 - clamp((t - 2.6) / 0.6, 0, 1);
        drawKrilessa(c, W * 0.7, H * 0.64 + Math.sin(t * 3) * 6, t, -1, ks, r0, true);
        c.globalAlpha = r0;
        for (let i = 0; i < 6; i++) { c.fillStyle = '#ff5b8a'; heartPath(c, W * 0.5 + Math.sin(t * 2 + i) * 60, H * 0.55 - ((t * 40 + i * 30) % 140), 8); c.fill(); }
        c.globalAlpha = 1;
      }
      // портал
      const pk = clamp((t - 2.8) / 0.8, 0, 1) * (1 - clamp((t - 8.4) / 0.8, 0, 1));
      if (pk > 0) {
        const pr = Math.min(W, H) * 0.34 * pk;
        for (let k = 0; k < 5; k++) {
          c.strokeStyle = k % 2 ? 'rgba(255,62,165,0.8)' : 'rgba(63,240,255,0.8)'; c.lineWidth = 6;
          c.beginPath(); c.ellipse(W / 2, H * 0.38, pr * (1 - k * 0.15), pr * 0.75 * (1 - k * 0.15), t * (k % 2 ? 2 : -2), 0, TAU * 0.85); c.stroke();
        }
      }
      // карточка Зямочкккк
      if (t > 3.4 && t < 15.2) {
        const appear = ease((t - 3.4) / 1.4);
        let sc = 0.2 + 0.8 * appear;
        if (t >= 8.6 && t < 11) sc *= 1 + 0.08 * Math.sin((t - 8.6) * 12) * Math.exp(-(t - 8.6) * 2.5);
        let cy = H * 0.4;
        if (t > 11.8) { sc *= 1 - 0.3 * move; cy -= move * H * 0.12; }
        const fade = 1 - clamp((t - 14.6) / 0.6, 0, 1);
        const wipe = clamp((t - story.wipe[0]) / (story.wipe[1] - story.wipe[0]), 0, 1);
        card(IMG.zyama, W / 2, cy, cw, sc, 0.04 * Math.sin(t * 2), appear * fade, wipe, t >= 8.6 ? '★ ЗЯМОЧКККК ★' : '???', 0, ['#ff3ea5', '#3ff0ff', '#ffe04a'], dt);
        if (t >= 8.6) {
          c.save(); c.translate(W / 2, cy - cw * 4 / 3 * sc / 2 - 6); c.rotate(-0.15);
          const s = sc * cw / 140; c.scale(s, s); c.globalAlpha = fade;
          c.fillStyle = '#ffd25a'; c.strokeStyle = '#b8860b'; c.lineWidth = 3;
          c.beginPath(); c.moveTo(-36, 4); c.lineTo(-36, -28); c.lineTo(-18, -10); c.lineTo(0, -36); c.lineTo(18, -10); c.lineTo(36, -28); c.lineTo(36, 4); c.closePath(); c.fill(); c.stroke();
          c.fillStyle = '#ff3ea5'; c.beginPath(); c.arc(0, -8, 5, 0, TAU); c.fill();
          c.restore();
        }
      }
      if (t > 8.6 && t < 15) {
        for (let i = 0; i < 10; i++) {
          const spr = emojiSprite(ZYAMA_EMOJI[i % ZYAMA_EMOJI.length], 26);
          const a = t * 0.8 + i * TAU / 10, rr = Math.min(W, H) * 0.42;
          c.globalAlpha = 0.85; c.drawImage(spr, W / 2 + Math.cos(a) * rr - 20, H * 0.4 + Math.sin(a) * rr * 0.8 - 20, 40, 40); c.globalAlpha = 1;
        }
      }
      if (t >= 8.6 && t < 11.8) title(W, ease((t - 8.6) / 0.6), 'ЗЯМОЧКККК', 'Император Кринжа', '#ff3ea5', '#3a0a3a');
      if (t >= 14.8) {
        const k = ease((t - 14.8) / 0.8);
        title(W, k, 'Глава 2', 'Кринж-Цитадель', '#3ff0ff', '#0a2a4a');
        drawKrilessa(c, lerp(-60, W * 0.5, ease((t - 15) / 1.4)), H * 0.5 + Math.sin(t * 3) * 8, t, 1, Math.min(4.5, W / 100), k, true);
      }
    }
    let flames = [];

    // ---------- глава 4: ночь, телевизор сам включился ----------
    function drawCh4(dt) {
      const [W, H] = setup();
      bg(W, H, '#0a0a1e', '#020208');
      c.fillStyle = '#141432'; c.fillRect(W * 0.08, H * 0.12, W * 0.3, H * 0.2);
      c.fillStyle = '#e8e8ff'; c.beginPath(); c.arc(W * 0.23, H * 0.2, Math.min(W, H) * 0.035, 0, TAU); c.fill();
      c.strokeStyle = '#2a2a4a'; c.lineWidth = 4; c.strokeRect(W * 0.08, H * 0.12, W * 0.3, H * 0.2);
      c.beginPath(); c.moveTo(W * 0.23, H * 0.12); c.lineTo(W * 0.23, H * 0.32); c.stroke();
      const tvOn = t > 3.4, tx = W * 0.72, ty = H * 0.28, tw = Math.min(W * 0.4, 190), th = tw * 0.7;
      c.fillStyle = '#111'; roundRect(c, tx - tw / 2 - 8, ty - th / 2 - 8, tw + 16, th + 16, 10); c.fill();
      if (tvOn) {
        for (let i = 0; i < 240; i++) { const v = Math.random() * 255 | 0; c.fillStyle = `rgb(${v},${v},${v})`; c.fillRect(tx - tw / 2 + Math.random() * (tw - 5), ty - th / 2 + Math.random() * (th - 3), 5, 3); }
        c.fillStyle = 'rgba(255,255,255,0.06)'; c.beginPath(); c.moveTo(tx - tw / 2, ty + th / 2); c.lineTo(tx + tw / 2, ty + th / 2); c.lineTo(W, H); c.lineTo(0, H); c.closePath(); c.fill();
        if (t > 6.6) {
          const a = clamp((t - 6.6) / 1, 0, 1), bl = Math.sin(t * 3) > 0.95 ? 0.1 : 1;
          c.fillStyle = `rgba(63,240,160,${a})`; c.beginPath();
          c.ellipse(tx - tw * 0.17, ty, tw * 0.08, th * 0.15 * bl, 0, 0, TAU); c.ellipse(tx + tw * 0.17, ty, tw * 0.08, th * 0.15 * bl, 0, 0, TAU); c.fill();
          c.fillStyle = '#000'; c.fillRect(tx - tw * 0.18, ty - th * 0.13 * bl, 3, th * 0.26 * bl); c.fillRect(tx + tw * 0.16, ty - th * 0.13 * bl, 3, th * 0.26 * bl);
        }
      } else { c.fillStyle = '#06060c'; c.fillRect(tx - tw / 2, ty - th / 2, tw, th); }
      const bx = W * 0.5, by = H * 0.62, ks = Math.min(5, W / 70);
      c.fillStyle = '#4a2240'; c.beginPath(); c.ellipse(bx, by + ks * 3, ks * 16, ks * 6, 0, 0, TAU); c.fill();
      c.fillStyle = '#7a3a60'; c.beginPath(); c.ellipse(bx, by + ks * 2, ks * 12, ks * 4, 0, 0, TAU); c.fill();
      const awake = t > 3.4;
      drawTessa(c, bx, by, awake ? t : 0.4, awake && t > 6.6 ? 1 : -1, ks, 1, false);
      if (!awake) { c.fillStyle = '#bfd8ff'; c.font = `bold ${Math.round(14 + ks * 2)}px sans-serif`; c.textAlign = 'center'; c.fillText('z', bx + 30 + Math.sin(t * 2) * 6, by - 40 - (t * 20) % 40); c.fillText('Z', bx + 46, by - 64 - (t * 16) % 50); }
      if (t > 6.6 && Math.random() < 0.07) { c.fillStyle = 'rgba(0,0,0,0.65)'; c.fillRect(0, 0, W, H); }
      if (t > 10 && t < 13.4) {
        const a = clamp((t - 10) / 0.6, 0, 1) * clamp((13.4 - t) / 0.6, 0, 1), sz = Math.min(W, H) * 0.55;
        if (!AVATAR.glitchcat) AVATAR.glitchcat = bossPortrait('glitchcat');
        c.globalAlpha = a; c.drawImage(AVATAR.glitchcat, W / 2 - sz / 2 + (Math.random() < 0.2 ? rnd(-12, 12) : 0), H * 0.4 - sz / 2, sz, sz); c.globalAlpha = 1;
        for (let i = 0; i < 8; i++) { c.fillStyle = Math.random() < 0.5 ? 'rgba(63,240,160,0.25)' : 'rgba(255,62,165,0.25)'; c.fillRect(0, Math.random() * H, W, rnd(3, 18)); }
      }
      if (t > 13.4) { c.fillStyle = 'rgba(90,184,255,0.15)'; c.beginPath(); c.arc(bx + ks * 8, by - ks * 7, ks * 10 + Math.sin(t * 4) * 4, 0, TAU); c.fill(); }
    }
    // ---------- глава 5: утро, миски пусты ----------
    function drawCh5(dt) {
      const [W, H] = setup();
      const g = c.createLinearGradient(0, 0, 0, H); g.addColorStop(0, '#ffe9b8'); g.addColorStop(1, '#f2b880'); c.fillStyle = g; c.fillRect(0, 0, W, H);
      c.fillStyle = '#9ad8ff'; c.fillRect(W * 0.58, H * 0.1, W * 0.32, H * 0.2);
      c.fillStyle = '#ffe04a'; c.beginPath(); c.arc(W * 0.72, H * 0.18, Math.min(W, H) * 0.045 + Math.sin(t * 2) * 2, 0, TAU); c.fill();
      c.strokeStyle = '#ffffff'; c.lineWidth = 6; c.strokeRect(W * 0.58, H * 0.1, W * 0.32, H * 0.2);
      for (let i = 0; i < 12; i++) for (let j = 0; j < 6; j++) { c.fillStyle = (i + j) % 2 ? '#e8dcc8' : '#d0c4ae'; c.fillRect(i * W / 12, H * 0.62 + j * H * 0.07, W / 12 + 1, H * 0.07 + 1); }
      const ks = Math.min(5, W / 70), empty = t > 3.2;
      for (let k = 0; k < 3; k++) {
        const x = W * (0.22 + k * 0.28), y = H * 0.76;
        c.fillStyle = ['#ff6a8a', '#6ac8ff', '#ffd25a'][k]; c.beginPath(); c.ellipse(x, y, 34, 13, 0, 0, TAU); c.fill();
        c.fillStyle = empty ? '#3a2a20' : '#c87a3a'; c.beginPath(); c.ellipse(x, y - 3, 25, 8, 0, 0, TAU); c.fill();
        if (!empty) { c.fillStyle = '#a05a2a'; for (let m = 0; m < 6; m++) { c.beginPath(); c.arc(x - 12 + m * 5, y - 6 + (m % 2) * 2, 3, 0, TAU); c.fill(); } }
      }
      const det = t > 9.4;
      drawTessa(c, W * 0.5, H * 0.58, t, t > 6.4 && t < 9.4 ? (Math.sin(t * 2) > 0 ? 1 : -1) : 1, ks, 1, false, TESSA_PAL, det ? 'hat' : 'none');
      if (empty && !det) { c.fillStyle = '#5a2a10'; c.font = `900 ${Math.round(18 + ks * 4)}px sans-serif`; c.textAlign = 'center'; c.fillText('?!', W * 0.5 + 10, H * 0.58 - ks * 16); }
      if (t > 12.6) {
        const lx = W * 0.5 + Math.sin(t * 1.5) * W * 0.25, ly = H * 0.42 + Math.cos(t * 1.2) * 20;
        c.strokeStyle = '#6a4a2a'; c.lineWidth = 8; c.beginPath(); c.moveTo(lx + 26, ly + 26); c.lineTo(lx + 56, ly + 56); c.stroke();
        c.strokeStyle = '#d8a050'; c.lineWidth = 6; c.beginPath(); c.arc(lx, ly, 34, 0, TAU); c.stroke(); c.fillStyle = 'rgba(200,240,255,0.35)'; c.fill();
      }
    }
    function drawCh6(dt) {
      const [W, H] = setup();
      const ks = Math.min(4.2, W / 90), night = clamp((t - 3.2) / 3, 0, 1);
      const mix = (a, b) => `rgb(${a.map((v, i) => Math.round(lerp(v, b[i], night))).join(',')})`;
      const g = c.createLinearGradient(0, 0, 0, H); g.addColorStop(0, mix([255, 196, 140], [10, 20, 52])); g.addColorStop(1, mix([255, 150, 110], [30, 46, 90]));
      c.fillStyle = g; c.fillRect(0, 0, W, H);
      if (lightning > 0) { c.fillStyle = `rgba(190,234,255,${lightning * 0.5})`; c.fillRect(0, 0, W, H); lightning -= dt * 2; }
      // северное сияние
      if (night > 0.3) for (let k = 0; k < 3; k++) {
        c.strokeStyle = ['rgba(90,255,180,', 'rgba(120,200,255,', 'rgba(200,120,255,'][k] + (0.25 * night) + ')'; c.lineWidth = 26 - k * 6;
        c.beginPath(); for (let x = 0; x <= W; x += 20) { const y = H * (0.14 + k * 0.06) + Math.sin(x * 0.012 + t * 0.8 + k) * 22; if (x) c.lineTo(x, y); else c.moveTo(x, y); } c.stroke();
      }
      // земля: трава превращается в снег
      c.fillStyle = mix([110, 190, 90], [236, 244, 252]); c.fillRect(0, H * 0.7, W, H * 0.3);
      // банкет
      if (t < 9.6) {
        const tx = W * 0.5, ty = H * 0.66;
        c.fillStyle = '#c8945a'; c.fillRect(tx - W * 0.28, ty, W * 0.56, 10);
        c.fillStyle = '#ffffff'; c.fillRect(tx - 30, ty - 30, 60, 30); c.fillStyle = '#ff6fb5'; c.fillRect(tx - 30, ty - 30, 60, 8);
        c.fillStyle = '#ffd25a'; for (let k = -2; k <= 2; k++) c.fillRect(tx + k * 11 - 1, ty - 42, 3, 12);
        if (night < 0.5) for (let k = -2; k <= 2; k++) { c.fillStyle = '#ff8a2a'; c.beginPath(); c.arc(tx + k * 11, ty - 45 + Math.sin(t * 10 + k) * 1.5, 3, 0, TAU); c.fill(); }
      }
      const tY = t < 9.6 ? H * 0.6 : lerp(H * 0.6, H * 0.12, ease(clamp((t - 9.6) / 2.4, 0, 1)));
      if (t < 12.8) {
        drawTessa(c, W * 0.5, tY, t, 1, ks * 0.8, 1, false, TESSA_PAL, 'none');
        if (t >= 9.6) { c.fillStyle = 'rgba(170,220,255,0.5)'; c.strokeStyle = '#ffffff'; c.lineWidth = 2; roundRect(c, W * 0.5 - ks * 13, tY - ks * 26, ks * 26, ks * 30, 8); c.fill(); c.stroke(); }
      }
      // Мрак в ледяной короне
      if (t >= 6.4 && t < 12.8) {
        const a = clamp((t - 6.4) / 0.8, 0, 1) * (1 - clamp((t - 12) / 0.8, 0, 1));
        c.save(); c.globalAlpha = a; c.translate(W * 0.5, H * 0.24 + Math.sin(t * 2) * 6); c.scale(ks * 0.42, ks * 0.42);
        BSPR.mrak2(c, { kind: 'mrak2', flash: 0, stage: 2, look: 1.57, mode: 'idle', charging: false, anim: t, z: 0 }, t, 1);
        c.restore();
      }
      // героини
      const sep = t < 12.8 ? 0.3 : 0.2;
      drawHero('krilessa', c, W * (0.5 - sep), H * 0.66, t, 1, ks * 0.9, 1, t > 12.8);
      drawHero('ryzhovaya', c, W * (0.5 + sep), H * 0.66, t, -1, ks * 0.9, 1, t > 12.8);
      if (t < 3.2) for (let i = 0; i < 5; i++) { c.fillStyle = '#ff5b8a'; heartPath(c, W * 0.5 + Math.sin(t * 2 + i) * 70, H * 0.5 - ((t * 40 + i * 30) % 140), 7); c.fill(); }
      if (t >= 12.8) { c.font = `900 ${Math.round(24 + ks * 4)}px sans-serif`; c.textAlign = 'center'; c.fillStyle = '#ffffff'; c.fillText('🔄', W * 0.5, H * 0.6 + Math.sin(t * 4) * 4); }
      // снег
      if (t >= 3.2) {
        c.fillStyle = '#ffffff';
        for (let i = 0; i < 90; i++) {
          const x = (hash2(i, 1) * W + Math.sin(t + i) * 20 + t * 15) % W, y = (hash2(i, 2) * H + t * (40 + hash2(i, 3) * 60)) % H;
          c.globalAlpha = 0.5 + hash2(i, 4) * 0.5; c.beginPath(); c.arc(x, y, 1.5 + hash2(i, 5) * 2, 0, TAU); c.fill();
        }
        c.globalAlpha = 1;
      }
    }
    function drawCh3(dt) {
      const [W, H] = setup();
      const ks = Math.min(4, W / 110);
      const mir = clamp((t - 6) / 1, 0, 1) * (1 - clamp((t - 12.2) / 0.8, 0, 1));
      const fire = clamp((t - 12.2) / 0.8, 0, 1);
      const top = fire > 0 ? `rgb(${lerp(42, 110, fire) | 0},${lerp(30, 30, fire) | 0},${lerp(70, 20, fire) | 0})`
        : mir > 0 ? `rgb(${lerp(42, 70, mir) | 0},${lerp(22, 80, mir) | 0},${lerp(64, 120, mir) | 0})` : '#2a1640';
      bg(W, H, top, '#0a0614');
      if (lightning > 0) { c.fillStyle = `rgba(255,120,220,${lightning * 0.5})`; c.fillRect(0, 0, W, H); lightning -= dt * 2; }
      const cw = Math.min(W * 0.62, H * 0.38 * 0.75);
      // подруги вместе
      if (t < 3.4) {
        const a = 1 - clamp((t - 2.8) / 0.6, 0, 1), R = Math.min(W, H) * 0.12;
        c.globalAlpha = a;
        if (AVATAR.ryzhovaBig) { c.save(); c.beginPath(); c.arc(W * 0.32, H * 0.56, R, 0, TAU); c.clip(); c.drawImage(AVATAR.ryzhovaBig, W * 0.32 - R, H * 0.56 - R, R * 2, R * 2); c.restore(); }
        c.strokeStyle = '#ff7a2f'; c.lineWidth = 5; c.beginPath(); c.arc(W * 0.32, H * 0.56, R, 0, TAU); c.stroke();
        for (let i = 0; i < 6; i++) { c.fillStyle = '#ff5b8a'; heartPath(c, W * 0.5 + Math.sin(t * 2 + i) * 60, H * 0.5 - ((t * 40 + i * 30) % 140), 8); c.fill(); }
        c.globalAlpha = 1;
        drawKrilessa(c, W * 0.7, H * 0.6 + Math.sin(t * 3) * 6, t, -1, ks, a, true);
      }
      // зеркала
      if (t >= 3 && t < 6.4) {
        const k = ease((t - 3) / 0.6), out = 1 - clamp((t - 5.8) / 0.6, 0, 1);
        for (let i = 0; i < 6; i++) {
          const px = W * (0.2 + (i % 3) * 0.3), py = H * (0.24 + Math.floor(i / 3) * 0.3) + Math.sin(t * 6 + i) * 4;
          const pw = Math.min(W * 0.2, 90) * k, ph = pw * 1.8;
          c.save(); c.globalAlpha = out; c.translate(px, py); c.rotate(Math.sin(i * 2.1) * 0.2);
          c.fillStyle = '#d9a640'; c.beginPath(); c.ellipse(0, 0, pw / 2 + 5, ph / 2 + 5, 0, 0, TAU); c.fill();
          c.strokeStyle = '#7a4a10'; c.lineWidth = 2; c.stroke();
          if (pw > 4) {
            const g = Math.random() < 0.1 ? rnd(-4, 4) : 0;
            c.save(); c.beginPath(); c.ellipse(0, 0, pw / 2, ph / 2, 0, 0, TAU); c.clip();
            const mg = c.createLinearGradient(-pw / 2, -ph / 2, pw / 2, ph / 2); mg.addColorStop(0, '#bfe6ff'); mg.addColorStop(0.5, '#ff9ad8'); mg.addColorStop(1, '#6a4aa0');
            c.fillStyle = mg; c.fillRect(-pw / 2, -ph / 2, pw, ph);
            if (ART.zyamaFace) c.drawImage(ART.zyamaFace, -pw / 2 + 2 + g, -pw / 2 + ph * 0.18, pw - 4, pw - 4);
            c.fillStyle = 'rgba(255,255,255,0.35)'; c.beginPath(); c.ellipse(-pw * 0.18, -ph * 0.25, pw * 0.08, ph * 0.18, 0.4, 0, TAU); c.fill();
            c.restore();
          }
          c.restore();
        }
        c.globalAlpha = out; c.font = `900 ${Math.min(W * 0.09, 40)}px "Trebuchet MS", sans-serif`; c.textAlign = 'center';
        c.fillStyle = '#3a0a3a'; c.fillText('«Трепещите, зайки!»', W / 2 + 2, H * 0.84 + 2);
        c.fillStyle = '#ff3ea5'; c.fillText('«Трепещите, зайки!»', W / 2, H * 0.84);
        c.globalAlpha = 1;
      }
      // Зямочкккк 2.0
      if (t >= 6.2 && t < 12.6) {
        const ap = ease((t - 6.2) / 0.8), fade = 1 - clamp((t - 12) / 0.6, 0, 1);
        let sc = 0.3 + 0.7 * ap;
        if (t < 8) sc *= 1 + 0.08 * Math.sin((t - 6.2) * 12) * Math.exp(-(t - 6.2) * 2.5);
        const cy = t < 9.2 ? H * 0.42 : lerp(H * 0.42, H * 0.3, ease((t - 9.2) / 0.8));
        for (let k = 0; k < 8; k++) {
          const a = t * 1.2 + k * TAU / 8, rr = cw * 0.95;
          c.save(); c.globalAlpha = 0.8 * fade; c.translate(W / 2 + Math.cos(a) * rr, cy + Math.sin(a) * rr * 0.9); c.rotate(a);
          c.fillStyle = '#bfeaff'; c.beginPath(); c.moveTo(0, -14); c.lineTo(9, 0); c.lineTo(0, 14); c.lineTo(-9, 0); c.closePath(); c.fill();
          c.strokeStyle = '#fff'; c.lineWidth = 2; c.stroke(); c.restore();
        }
        card(IMG.zyama, W / 2, cy, cw * (t < 9.2 ? 1 : 0.8), sc, 0.04 * Math.sin(t * 2), ap * fade, 1, '★ ЗЯМОЧКККК 2.0 ★', 0, ['#bfeaff'], dt);
        if (t < 9.2) title(W, ease((t - 6.2) / 0.6), 'ЗЯМОЧКККК 2.0', 'Зеркальный Император', '#bfeaff', '#2a3a6a');
      }
      // Крилессу затягивает в зеркало
      if (t >= 9.2 && t < 12.6) {
        const k = ease((t - 9.6) / 2.2), out = 1 - clamp((t - 12) / 0.6, 0, 1);
        const mx = W / 2, my = H * 0.7, mr = Math.min(W, H) * 0.16;
        c.globalAlpha = out;
        c.fillStyle = '#ffd25a'; c.beginPath(); c.ellipse(mx, my, mr + 10, mr * 1.3 + 10, 0, 0, TAU); c.fill();
        const gr = c.createLinearGradient(mx - mr, my - mr, mx + mr, my + mr); gr.addColorStop(0, '#ffffff'); gr.addColorStop(0.5, '#9ad8f8'); gr.addColorStop(1, '#7a5aff');
        c.fillStyle = gr; c.beginPath(); c.ellipse(mx, my, mr, mr * 1.3, 0, 0, TAU); c.fill();
        for (let i = 0; i < 4; i++) { c.strokeStyle = `rgba(255,255,255,${0.5 - i * 0.1})`; c.lineWidth = 3; c.beginPath(); c.ellipse(mx, my, mr * (0.8 - i * 0.18), mr * 1.3 * (0.8 - i * 0.18), t * (i % 2 ? 2 : -2), 0, TAU * 0.8); c.stroke(); }
        c.globalAlpha = 1;
        c.save(); c.translate(lerp(W * 0.15, mx, k), lerp(my, my, k)); c.rotate(k * 6);
        drawKrilessa(c, 0, 0, t, 1, ks * (1 - k * 0.9), (1 - k * 0.8) * out, true);
        c.restore();
      }
      // огненное превращение Рыжовой
      if (t >= 12.2) {
        const ap = ease((t - 12.2) / 0.6);
        const tk = ease((t - 15.6) / 0.8);
        const cy = H * 0.42 - tk * H * 0.04, sc = (0.6 + 0.4 * ap) * (1 - tk * 0.2);
        if (Math.random() < 0.8) flames.push({ x: W / 2 + rnd(-cw * 0.6, cw * 0.6), y: cy + cw * 0.6, vy: rnd(-160, -60), r: rnd(6, 16), life: 1 });
        for (const f of flames) { f.y += f.vy * dt; f.life -= dt * 0.9; f.r *= 0.995; }
        flames = flames.filter(f => f.life > 0);
        c.globalCompositeOperation = 'lighter';
        for (const f of flames) { c.fillStyle = `rgba(255,${(120 + f.life * 100) | 0},40,${f.life * 0.5})`; c.beginPath(); c.arc(f.x, f.y, f.r, 0, TAU); c.fill(); }
        c.globalCompositeOperation = 'source-over';
        const wipe = clamp((t - story.wipe[0]) / (story.wipe[1] - story.wipe[0]), 0, 1);
        card(IMG.ryzhova, W / 2, cy, cw, sc, -0.03, ap, wipe, '🔥 Рыжовая 🔥', 0, ['#ff8a2a', '#ffd23a', '#ff4a1a'], dt);
        if (t >= 15.6) {
          title(W, tk, 'Глава 3', 'Рыжовая спешит на помощь', '#ff9a3a', '#5a1a00');
          drawRyzhovaya(c, lerp(-60, W * 0.76, ease((t - 15.8) / 1.4)), cy + cw * 4 / 3 * sc * 0.62 + Math.sin(t * 3) * 6, t, 1, ks * 1.1, tk, true);
        }
      }
    }
    return { start, skip };
  })();

  // ------------------------------------------------------------------
  //  Отладка (?debug)
  // ------------------------------------------------------------------
  const DEBUG = /[?&]debug/.test(location.search);
  function teleport(i) {
    const b = bosses[i];
    if (b.final) {
      for (let k = 0; k < bosses.length - 1; k++) { G.defeated[k] = true; bosses[k].state = 'dead'; }
      gateOpen = true; P.x = b.hx; P.y = b.hy + 220;
    } else { P.x = b.hx - 200; P.y = b.hy; }
  }
  function debugKey(code) {
    const m = code.match(/^Digit([1-5])$/);
    if (m && bosses[+m[1] - 1]) teleport(+m[1] - 1);
    if (code === 'KeyK' && G.activeBoss) { G.activeBoss.inv = false; damageBoss(G.activeBoss, { v: G.activeBoss.hp + 1, crit: false }); }
    if (code === 'KeyJ' && G.activeBoss) { const b = G.activeBoss; const st = b.def.stages[b.stage + 1]; if (st) b.hp = b.maxHp * st.at - 1; }
    if (code === 'KeyL') gainXp(P.xpNext);
    if (code === 'KeyG') P.inv = 9999;
  }

  // ------------------------------------------------------------------
  //  Главный цикл
  // ------------------------------------------------------------------
  let lastT = performance.now();
  function loop(now) {
    const dt = Math.min(0.05, (now - lastT) / 1000); lastT = now;
    if (state === 'play' || state === 'dying') { pollKeys(); if (state === 'play' && Dialog.talking) Dialog.update(dt); else update(dt); }
    if (state !== 'intro' && state !== 'teaser' && tiles) {
      // экраны поверх меню («Что нового», статистика) показывают тот же фон, без HUD
      const bg = G.inMenu && state !== 'play' && state !== 'dying', real = state;
      // под меню мир еле виден и плывёт медленно – хватит 15 кадров в секунду, телефону легче
      if (!bg || now - (G.bgT || 0) > 66) {
        if (bg) { G.bgT = now; state = 'menu'; updateCamera(); }
        ctx.setTransform(1, 0, 0, 1, 0, 0);
        renderWorld();
        state = real;
        if (!bg) renderHUD();
      }
    }
    requestAnimationFrame(loop);
  }

  window.KR = {
    get state() { return state; }, P, G, get bosses() { return bosses; }, get chests() { return chests; }, get shrines() { return shrines; },
    get CHN() { return CHN; }, newChapter, continueChapter, openMenu, update, damageBoss, gainXp, teleport, spawnEnemy, startChapter,
    mobScale, zoneE, trySuper, tryDash, computeStats,
    get gateOpen() { return gateOpen; }, get MW() { return MW; }, loadProfile, saveProfile, startChapter2,
    debugKey, isSolidTile, walkable, tileAt: (x, y) => tileAt(x, y),
    startRush, startEvent, endEvent, openStats, buildReport, openWhatsNew, openTeaser, showVictory, startTrick, startFinalFinal,
    loadSave, migrateProfile, hurtPlayer, openBoard, openWardrobe, openRelicChoice,
    get beds() { return beds; }, get clues() { return clues; }, get npcs() { return npcs; }, get qitems() { return qitems; },
    get arena() { return ARENA; }, get playH() { return PLAY_H; },
    get shelves() { return shelves; }, get boxes() { return boxes; }, get lamps() { return lamps; },
    input, get miniBase() { return miniBase; }, get fires() { return fires; }, get holes() { return holes; }, get ovens() { return ovens; }, get drifts() { return drifts; }, get glades() { return glades; }, startWeather, switchHero, freeTessa, meltTile, openTalents, saveGame, talent, iceTarget, openLevelUp,
  };

  // ------------------------------------------------------------------
  //  Запуск
  // ------------------------------------------------------------------
  function fallbackPortrait() {
    const W = 480, H = 640, cv = makeCanvas(W, H), c = cv.getContext('2d');
    c.fillStyle = '#2a1238'; c.fillRect(0, 0, W, H);
    c.fillStyle = '#ff6a1f'; c.beginPath(); c.ellipse(240, 330, 190, 260, 0, 0, TAU); c.fill();
    c.fillStyle = '#ffe0cc'; c.beginPath(); c.ellipse(240, 290, 120, 150, 0, 0, TAU); c.fill();
    c.fillStyle = '#111'; c.fillRect(0, 500, W, 140);
    return { photo: cv, cartoon: cv, face: { x: 0.5, y: 0.45, r: 0.36 } };
  }
  async function boot() {
    Sound.init();
    loadChapter(1); resetRun(); makeBosses(); computeStats();
    for (const name of ['ryzhova', 'zyama']) {
      try { IMG[name] = await Cartoon.make(name); }
      catch (e) { console.warn('Не удалось обработать фото', name, e); IMG[name] = fallbackPortrait(); }
    }
    ART.ryzhovaSmall = Cartoon.avatar(IMG.ryzhova.cartoon, 128, IMG.ryzhova.face);
    AVATAR.ryzhova = Cartoon.avatar(IMG.ryzhova.cartoon, 116, IMG.ryzhova.face);
    AVATAR.ryzhovaBig = Cartoon.avatar(IMG.ryzhova.cartoon, 300, IMG.ryzhova.face);
    ART.zyamaFace = Cartoon.avatar(IMG.zyama.cartoon, 160, IMG.zyama.face);
    ART.zyamaSmall = Cartoon.avatar(IMG.zyama.cartoon, 48, IMG.zyama.face);
    AVATAR.zyama = ART.zyamaFace;
    AVATAR.krilessa = heroPortrait('krilessa');
    for (const k of Object.keys(BOSSES)) if (!AVATAR[k]) AVATAR[k] = BOSSES[k].avatar ? AVATAR[BOSSES[k].avatar] : bossPortrait(k);
    AVATAR.tessa = heroPortrait('tessa'); AVATAR.tessaBig = heroPortrait('tessa', 300);
    Cartoon.make('tessa').then(img => {
      IMG.tessa = img;
      AVATAR.tessa = Cartoon.avatar(img.cartoon, 116, img.face); AVATAR.tessaBig = Cartoon.avatar(img.cartoon, 300, img.face);
    }).catch(e => console.warn('Не удалось обработать фото Тессы', e));
    const pre = [1, 2, 3].map(n => !!loadSave(n)); // до переноса: старые сохранения он может убрать
    const prof = migrateProfile();
    TESSA_OUTFIT = (prof.wardrobe && prof.wardrobe.on) || 'none';
    const hasData = prof.ch1Done || prof.carry || pre[0] || pre[1] || pre[2];
    if (prof.lastVersion !== VERSION) {
      // версии до 0.04 не запоминали себя – угадываем по сохранениям
      const guess = prof.ch3Done || pre[2] ? '0.03 beta' : (prof.ch2Done || pre[1] || prof.carry) ? '0.02 beta' : true;
      if (prof.lastVersion || hasData) G.pendingWhatsNew = prof.lastVersion || guess;
      else { prof.lastVersion = VERSION; saveProfile(prof); }
    }
    const tot = loadTotals(); tot.sessions = (tot.sessions || 0) + 1; saveTotals(tot);
    setInterval(() => { if (state === 'play') { const t2 = loadTotals(); t2.playTime = (t2.playTime || 0) + 10; saveTotals(t2); } }, 10000);
    requestAnimationFrame(loop);
    // игра успешно запустилась – скачанное обновление рабочее, откатывать не нужно
    try { if (window.KrilessaAndroid && KrilessaAndroid.booted) KrilessaAndroid.booted(); } catch (e) { /* ignore */ }
    Intro.start('ch1', openMenu);
  }
  boot();
})();
