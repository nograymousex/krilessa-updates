'use strict';

const Multiplayer = (() => {
  const NET_SNAP = 1 / 15, NET_ST = 1 / 20, NET_AOI = 1150, NET_MAX = 4;
  const MATE_COL = ['#ffd25a', '#7fd8ff', '#ff7ac8', '#7dff9a', '#ffa24a'], MATE_EMO = ['🟡', '🔵', '🟣', '🟢', '🟠'];
  const FK = ['feather', 'fire', 'claw', 'pixel'];
  const PK = ['xp', 'heart', 'star', 'key', 'magnet', 'shard'];
  const mateCol = id => MATE_COL[(id - 1) % MATE_COL.length];
  function netReset() {
    Object.assign(NET, { on: false, host: false, client: false, id: 0, started: false, ch: 1, seed: 0, roster: [], found: new Map(), hits: [], bhits: [], bcons: [], burns: [],
      ev: new Map(), killed: [], snapT: 0, stT: 0, lastSnap: 0, hzCancel: [], fxIn: [], eMap: new Map(), bMap: new Map(), hMap: new Map(), pMap: new Map(), wipeT: 0, info: null, joining: null, scanT: 0, meltOut: [], driftHits: [], c4: null, applyMelt: false, rdy: false, goAt: 0, setKey: undefined });
    Object.assign(NET, { scanning: false, paused: false, ips: [], dmap: '', mut: [], resume: null,
      checkpoint: null, completed: false, loading: false, savedSummary: null, res: null, coopId: null, kickedNames: new Set(), rush: null });
    NET.peers.clear(); NET.mates.clear(); NET.goneB.clear();
    G.rfeathers = []; G.netRun = false;
  }
  function netHeroes() {
    const pr = Saves.loadProfile();
    return ['krilessa', 'ryzhovaya'].concat(pr.ch4Done || GameLoop.DEBUG || pr.admin ? ['tessa'] : []);
  }
  function netEvent(cid, e) { if (!NET.ev.has(cid)) NET.ev.set(cid, []); NET.ev.get(cid).push(e); }
  // ---------- лобби ----------
  function openMP() {
    Sound.init();
    if (NetT.oldApk) { RunStats.toast('📲 Игра вместе появится после обновления приложения (APK)'); return; }
    if (!NET.on) netReset();
    const pr = Saves.loadProfile(), mp = pr.mp || {};
    NET.hero = netHeroes().includes(mp.hero) ? mp.hero : 'krilessa';
    NET.name = mp.name || HEROES[NET.hero].name;
    $('mpName').value = NET.name;
    delete $('mp').dataset.phase;
    Screens.setState('mp');
    mpRender();
  }
  function mpSavePrefs() {
    const pr = Saves.loadProfile(); pr.mp = { name: NET.name, hero: NET.hero }; Saves.saveProfile(pr);
  }
  function lobbyText(node, text) {
    if (node.textContent !== text) node.textContent = text;
  }

  function portraitCanvas(hero) {
    // Тесса в меню может иметь фотоаватар. Для лобби рисуем её игровую модель.
    return heroPortrait(hero, 104);
  }

  function renderHeroChoices() {
    const box = $('mpHero'), heroes = netHeroes();
    const signature = [heroes.join(' '), TESSA_OUTFIT, PAPER_ART].join('|');
    if (box.dataset.choices !== signature) {
      box.dataset.choices = signature;
      box.textContent = '';
      for (const hero of heroes) {
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'mpHc';
        button.dataset.hero = hero;
        const avatar = document.createElement('span');
        avatar.className = 'av';
        avatar.setAttribute('aria-hidden', 'true');
        avatar.appendChild(portraitCanvas(hero));
        const label = document.createElement('b');
        label.textContent = HEROES[hero].name;
        button.append(avatar, label);
        button.addEventListener('click', () => {
          if (NET.started || NET.hero === hero) return;
          NET.rdy = false;
          NET.hero = hero;
          mpSavePrefs();
          Sound.sfx.click();
          if (NET.host) mpLobbyBroadcast();
          else {
            if (NET.client) NetT.send(0, { t: 'me', name: NET.name, hero: NET.hero });
            mpRender();
          }
        });
        box.appendChild(button);
      }
    }
    for (const button of box.children) {
      const selected = button.dataset.hero === NET.hero;
      button.classList.toggle('on', selected);
      button.setAttribute('aria-pressed', String(selected));
      button.disabled = !!NET.started;
    }
    $('mpName').disabled = !!NET.started;
  }

  function renderFoundRooms() {
    const list = $('mpList'), now = performance.now();
    // Маяки приходят повторно; кнопка остаётся на месте под пальцем или в фокусе.
    for (const [ip, room] of NET.found) {
      if (now - room.at >= 4500) NET.found.delete(ip);
    }
    const buttons = new Map();
    for (const item of Array.from(list.children)) {
      const ip = item.dataset.ip;
      if (ip && NET.found.has(ip)) buttons.set(ip, item);
      else if (ip || NET.found.size) item.remove();
    }
    if (!NET.found.size && !list.firstElementChild) {
      const empty = document.createElement('p');
      empty.className = 'mpNone';
      empty.textContent = 'Пока нет открытых комнат.';
      list.appendChild(empty);
    }
    for (const room of NET.found.values()) {
      let button = buttons.get(room.ip);
      if (!button) {
        button = document.createElement('button');
        button.type = 'button';
        button.className = 'mpGame';
        button.dataset.ip = room.ip;
        button.append(document.createElement('strong'), document.createElement('small'));
        button.addEventListener('click', () => {
          const found = NET.found.get(button.dataset.ip);
          if (found) mpJoin(found.ip, found.port);
        });
        list.appendChild(button);
      }
      lobbyText(button.firstElementChild, room.name);
      lobbyText(button.lastElementChild, room.desc);
    }
  }

  function renderPlayers() {
    const list = $('mpPlayers'), count = NET.roster.length;
    for (const item of Array.from(list.children)) {
      if (!NET.roster.some(player => String(player.id) === item.dataset.player)) item.remove();
    }
    for (const player of NET.roster) {
      let row = Array.from(list.children).find(item => item.dataset.player === String(player.id));
      if (!row) {
        row = document.createElement('div');
        row.className = 'mpP';
        row.dataset.player = player.id;
        const label = document.createElement('div');
        label.className = 'mpPlayerLabel';
        label.append(document.createElement('strong'), document.createElement('small'));
        const status = document.createElement('span');
        status.className = 'mpStatus';
        row.append(label, status);
        list.appendChild(row);
      }
      const hero = HEROES[player.hero] ? player.hero : 'krilessa';
      if (row.dataset.hero !== hero) {
        const old = row.querySelector('canvas');
        if (old) old.remove();
        const portrait = portraitCanvas(hero);
        portrait.setAttribute('aria-hidden', 'true');
        row.prepend(portrait);
        row.dataset.hero = hero;
      }
      const label = row.querySelector('.mpPlayerLabel');
      lobbyText(label.firstElementChild, player.name + (player.id === NET.id ? ' (ты)' : ''));
      lobbyText(label.lastElementChild, HEROES[hero].name + (player.id === 1 ? ' · хозяйка' : ' · гостья'));
      const status = row.querySelector('.mpStatus');
      lobbyText(status, count < 2 ? '' : player.rd ? 'Готова' : 'Не готова');
      status.classList.toggle('rd', !!player.rd);
      let kick = row.querySelector('.mpKick');
      if (NET.host && player.id !== 1) {
        if (!kick) {
          kick = document.createElement('button');
          kick.type = 'button';
          kick.className = 'mpKick';
          kick.textContent = '×';
          kickBtn(kick, player.id, '×');
          row.appendChild(kick);
        }
        const action = 'Исключить игрока ' + player.name;
        kick.setAttribute('aria-label', action);
        kick.title = action;
      } else if (kick) kick.remove();
    }
    lobbyText($('mpCount'), count + '/' + NET_MAX);
  }

  function renderInvite() {
    const addresses = NET.ips || [];
    $('mpManualHost').classList.toggle('hidden', !addresses.length);
    const extra = $('mpExtraAddrs'), signature = addresses.join('\n');
    if (extra.dataset.addresses === signature) return;
    extra.dataset.addresses = signature;
    $('mpAddr').textContent = addresses[0] || '';
    extra.textContent = '';
    for (const address of addresses.slice(1)) {
      const row = document.createElement('div');
      row.className = 'mpAddressLine';
      const value = document.createElement('code');
      value.textContent = address;
      const copy = document.createElement('button');
      copy.type = 'button';
      copy.className = 'mpCopyExtra';
      copy.textContent = 'Копировать';
      copy.setAttribute('aria-label', 'Копировать адрес ' + address);
      copy.addEventListener('click', () => RunStats.copyText(address));
      row.append(value, copy);
      extra.appendChild(row);
    }
  }

  const lobbyPhases = {
    entry: ['Вместе', 'До четырёх игроков в одной сети Wi-Fi. Можно раздать точку доступа с одного телефона.', 'В меню'],
    search: ['Найти комнату', 'Выбери комнату, созданную на другом телефоне в той же сети Wi-Fi.', 'Назад'],
    connecting: ['Подключение', 'Ждём ответа хозяйки комнаты.', 'Отменить'],
    host: ['Моя комната', 'Ты выбираешь, во что играет команда.', 'Выйти'],
    guest: ['В комнате', 'Главу и режим выбирает хозяйка комнаты.', 'Выйти'],
  };

  function mpRender() {
    const phase = NET.host ? 'host' : NET.client ? (NET.joining || !NET.id || !NET.roster.length ? 'connecting' : 'guest') : NET.scanning ? 'search' : 'entry';
    const room = phase === 'host' || phase === 'guest', screen = $('mp');
    if (screen.dataset.phase !== phase) {
      screen.dataset.phase = phase;
      const [title, hint, back] = lobbyPhases[phase];
      lobbyText($('mpTitle'), title);
      lobbyText($('mpHint'), hint);
      lobbyText($('mpBack'), back);
      $('mpStart').classList.toggle('hidden', phase !== 'entry');
      $('mpFound').classList.toggle('hidden', phase !== 'search');
      $('mpConnecting').classList.toggle('hidden', phase !== 'connecting');
      $('mpLobby').classList.toggle('hidden', !room);
      $('mpMe').open = phase === 'entry';
      $('mpManualJoin').open = false;
      $('mpManualHost').open = false;
      // У прокручиваемых лобби и поиска независимые начальные позиции.
      screen.querySelector('.mpScroll').scrollTop = 0;
      $('mpBack').focus({ preventScroll: true });
    }
    renderHeroChoices();
    if (phase === 'entry') CoopActivity.entry();
    if (phase === 'search') renderFoundRooms();
    if (!room) return;

    $('mpWait').classList.remove('hidden');
    renderPlayers();
    if (NET.host) renderInvite();
    else if (NET.roster[0]) lobbyText($('mpHint'), 'Главу и режим выбирает ' + NET.roster[0].name + '.');
    CoopActivity.render();
    const multi = NET.roster.length > 1;
    $('mpGo').classList.toggle('hidden', !NET.host || multi || !!NET.started);
    lobbyText($('mpGo'), 'Начать игру');
    const ready = $('mpReady');
    ready.classList.toggle('hidden', !multi || !!NET.started);
    ready.classList.toggle('on', !!NET.rdy);
    ready.setAttribute('aria-pressed', String(!!NET.rdy));
    lobbyText(ready, NET.rdy ? 'Отменить готовность' : 'Я готова');
    mpWaitText();
  }

  function mpWaitText() {
    const count = NET.roster.length;
    if (NET.started && !G.netRun) {
      lobbyText($('mpWait'), 'Команда в игре. Оставайся в комнате до следующего старта.');
      return;
    }
    const message = NET.goAt
      ? 'Старт через ' + Math.max(1, Math.ceil((NET.goAt - performance.now()) / 1000)) + '…'
      : count > 1 ? 'Готовы ' + NET.roster.filter(player => player.rd).length + ' из ' + count + '. Игра начнётся, когда будут готовы все.'
      : NET.host ? 'Можно начать одной. Подруги смогут войти позже.' : 'Ждём хозяйку комнаты.';
    lobbyText($('mpWait'), message);
  }

  function mpToggleReady() {
    if (NET.started || !(NET.host || NET.client)) return;
    NET.rdy = !NET.rdy; Sound.sfx.click();
    const me = NET.roster.find(r => r.id === (NET.host ? 1 : NET.id)); if (me) me.rd = NET.rdy;
    if (NET.host) mpLobbyBroadcast();
    else { NetT.send(0, { t: 'rdy', v: NET.rdy ? 1 : 0 }); mpRender(); }
  }
  const escHtml = s => String(s).replace(/[&<>"]/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[ch]));
  function mpName() {
    const input = $('mpName');
    NET.name = input.value.trim().slice(0, 14) || HEROES[NET.hero].name;
    input.value = NET.name;
    mpSavePrefs();
    return NET.name;
  }
  function mpHost() {
    mpName();
    const r = NetT.host(mpBeacon());
    if (!r || !r.ok) { RunStats.toast('Не получилось создать игру 😿 Проверь Wi-Fi'); return; }
    NET.on = true; NET.host = true; NET.id = 1;
    const addresses = r.ips && r.ips.length ? r.ips : NetT.ips();
    NET.ips = [...new Set(addresses)].map(ip => r.port && r.port !== 47821 ? ip + ':' + r.port : ip);
    if (!Chapters.chapterOpen(NET.ch)) NET.ch = 1;
    { const pr = Saves.loadProfile(); if (pr.lastCh && Chapters.chapterOpen(pr.lastCh)) NET.ch = pr.lastCh; }
    NET.card = Achievements.myCard();
    Sound.sfx.magic(); mpLobbyBroadcast();
  }
  // имя и описание через «|»: Android-маячок заменяет табуляции пробелами
  function mpBeacon() { return `${String(NET.name).replace(/[|\t\n]/g, ' ')}|${NET.ch === 'rush' ? 'босс-раш' : NET.ch === 'defense' ? 'оборона' : 'глава ' + NET.ch} · игроков ${Math.max(1, NET.roster.length)}/${NET_MAX}`; }
  function mpLobbyBroadcast() {
    if (!NET.host) return;
    NET.card = Object.assign(NET.card || Achievements.myCard(), { nm: NET.name, at: Date.now() });
    const setKey = CoopActivity.settingsKey();
    if (NET.setKey !== undefined && NET.setKey !== setKey) { NET.rdy = false; for (const m of NET.peers.values()) m.rd = false; }
    NET.setKey = setKey;
    NET.roster = [{ id: 1, name: NET.name, hero: NET.hero, cd: NET.card, rd: !!NET.rdy }].concat([...NET.peers.values()].map(m => ({ id: m.id, name: m.name, hero: m.hero, cd: m.cd || null, rd: !!m.rd })));
    // все готовы – через 3 секунды старт; кто-то передумал или зашла новая подруга – отсчёт сбрасывается
    const all = !NET.started && NET.roster.length > 1 && NET.roster.every(r => r.rd);
    if (all && !NET.goAt) { NET.goAt = performance.now() + 3000; Sound.sfx.superReady(); }
    else if (!all) NET.goAt = 0;
    netLooks();
    NetT.info(mpBeacon());
    NetT.send(-1, { t: 'lobby', roster: NET.roster, saved: CoopActivity.resumeSummary(NET.resume), ch: NET.ch, dm: NET.dmap || '', mut: typeof NET.ch === 'number' ? NET.mut || [] : [], started: NET.started, go: NET.goAt ? Math.max(0.1, (NET.goAt - performance.now()) / 1000) : 0 });
    if (Session.state === 'mp') mpRender();
  }
  function mpScan() {
    mpName();
    NET.scanning = true; NET.found.clear();
    NetT.scan(true); Sound.sfx.click(); mpRender();
  }
  function backToSearch(message) {
    netReset();
    NetT.close();
    NET.scanning = true;
    NetT.scan(true);
    mpRender();
    if (message) RunStats.toast(message);
  }
  function mpJoin(ip, port) {
    NetT.scan(false); NET.scanning = false;
    NET.on = true; NET.client = true; NET.id = 0; NET.joining = { ip, port, t: performance.now() };
    NetT.join(ip, port);
    mpRender();
  }
  function mpLeave(silent) {
    if (G.netRun) Saves.coopSave();
    if (NET.host && NET.on) NetT.send(-1, { t: 'end' });
    if (NET.client && NET.on) NetT.send(0, { t: 'bye' });
    NetT.scan(false);
    NetT.closeAfterFlush();
    const wasRun = G.netRun;
    netReset();
    if (!silent && Session.state === 'mp') mpRender();
    return wasRun;
  }
  function mpGo() {
    if (!NET.host) return;
    NET.goAt = 0; NET.rdy = false; for (const m of NET.peers.values()) m.rd = false; // к следующему разу – готовность заново
    NET.started = true; NET.seed = 1 + Math.floor(Math.random() * 2e9);
    const RS = NET.resume && NET.resume.ch === NET.ch ? NET.resume : null;
    NET.coopId = RS ? RS.id : 'c' + Date.now().toString(36);
    NET.layout = NET.ch === 8 ? Belfry.revision : RS ? RS.layout || 0 : 1;
    NET.completed = false; NET.loading = true;
    NET.checkpoint = CoopCheckpoints.strip(RS);
    NET.res = NET.checkpoint;
    if (RS) { NET.seed = RS.seed; NET.dmap = RS.map || NET.dmap; }
    NET.rush = NET.ch === 'rush' ? (RS && RS.pool || Challenges.rushPool()) : null;
    if (NET.ch === 'defense' && !TD_MAP_BY[NET.dmap]) NET.dmap = Defense.tdMapPick(Saves.loadProfile(), true).id;
    const diff = (Saves.loadProfile().settings || {}).diff || 'normal';
    NET.diff = RS && RS.diff ? RS.diff : diff;
    mpLobbyBroadcast();
    netBegin();
    if (RS) { CoopCheckpoints.restore(NET.res); Saves.coopApplyMine(RS.mine || RS); Screens.showBanner('Продолжаем вместе', CoopActivity.describe(RS)); }
    NET.loading = false;
    NetT.send(-1, netStartMsg());
    Saves.coopSave();
    NET.resume = null;
    if(NET.ch===8 && !RS) Intro.start('ch8',()=>{Screens.setState('play');Sound.music('belfry');});
  }
  function netStartMsg(inProgress = false) { return { t: 'start', layout: NET.layout, mut: typeof NET.ch === 'number' ? NET.mut || [] : [], cid: NET.coopId, res: NET.checkpoint || NET.res || null, dm: NET.dmap || '', ch: NET.ch, seed: NET.seed, diff: NET.diff, roster: NET.roster, df: inProgress ? G.defeated : null, gate: inProgress && World.gateOpen, ml: inProgress ? G.melted : [], rk: NET.rush ? NET.rush.kinds : null, rl: NET.rush ? NET.rush.levels : null }; }
  // ---------- начало главы вместе ----------
  function netBegin() {
    NET.paused = false;
    NET.lastSnap = 0; NET.wipeT = 0; NET.revBy = 0; NET.pearlReq = undefined;
    for (const map of [NET.eMap, NET.bMap, NET.hMap, NET.pMap, NET.goneB, NET.ev]) map.clear();
    for (const queue of [NET.hits, NET.bhits, NET.bcons, NET.burns, NET.fxIn, NET.meltOut, NET.killed, NET.hzCancel, NET.driftHits]) queue.length = 0;
    if (NET.host) for (const peer of NET.peers.values()) { peer.live = false; peer.down = false; peer.away = false; }
    else NET.mates.clear();
    G.netRun = true;
    const idx = Math.max(0, NET.roster.findIndex(r => r.id === NET.id));
    G.mutNext = typeof NET.ch === 'number' && NET.mut && NET.mut.length ? NET.mut.slice() : null; G.dailyNext = null; // мутаторы выбирает хозяйка
    if (NET.ch === 'rush') Challenges.startRush(NET.rush); else if (NET.ch === 'defense') Defense.startDefense(); else Chapters.newChapter(NET.ch, NET.seed, NET.layout);
    G.diffId = NET.diff || G.diffId; G.diff = DIFFS[G.diffId] || DIFFS.normal;
    // стартуем кружком, чтобы не стоять друг в друге
    const a = idx * TAU / NET_MAX; P.x += Math.cos(a) * 26 * (idx ? 1 : 0); P.y += Math.sin(a) * 26 * (idx ? 1 : 0); World.ensureWalkable(P);
    Screens.showBanner(NET.ch === 'rush' ? '⚔️ Раш · вместе' : NET.ch === 'defense' ? '🛡️ Оборона · вместе' : `Глава ${NET.ch} · вместе`, NET.roster.map(r => r.name).join(' · '));
    if (NET.client) { G.tessaAlly = null; G.enemies = []; }
  }
  function returnToRoom() {
    if (!NET.host || !G.netRun || !(G.rush && G.rush.done || Defense.defOn() && G.abyss.done)) return;
    NetT.send(-1, { t: 'regroup', cid: NET.coopId });
    openTeamRoom();
    mpLobbyBroadcast();
  }

  function openTeamRoom() {
    G.netRun = false;
    NET.started = false; NET.paused = false; NET.goAt = 0; NET.rdy = false;
    NET.coopId = null; NET.resume = null; NET.res = null; NET.savedSummary = null;
    for (const peer of NET.peers.values()) { peer.rd = false; peer.live = false; }
    // Это обычный фон карты. При G.netRun=false соединения и состав комнаты сохраняются.
    AdventureMenu.openMenu();
    openMP();
  }

  // ---------- приём сообщений ----------
  function netRecv() {
    for (const [type, cid, data] of NetT.poll()) {
      if (type === 'found') {
        const [ip, port, ...rest] = data.split('\t'), info = rest.join(' '), bar = info.indexOf('|');
        const name = bar >= 0 ? info.slice(0, bar) : info, desc = bar >= 0 ? info.slice(bar + 1) : '';
        NET.found.set(ip, { ip, port: +port || 0, name: name || 'Игра', desc, at: performance.now() });
        continue;
      }
      if (type === 'open') { if (!NET.joining) continue; NET.card = Achievements.myCard(); NetT.send(0, { t: 'hello', v: VERSION, name: NET.name, hero: NET.hero, cd: NET.card }); continue; }
      if (type === 'fail') { if (NET.joining) backToSearch('Не удалось войти. Проверь адрес комнаты и сеть Wi-Fi.'); continue; }
      if (type === 'closed') { if (NET.client) netLost('Связь с хозяином пропала'); continue; }
      if (type === 'conn') continue; // ждём «hello»
      if (type === 'drop') { netDrop(cid); continue; }
      if (type !== 'msg') continue;
      let m; try { m = JSON.parse(data); } catch (e) { continue; }
      if (NET.host) netHostMsg(cid, m); else if (NET.client) netClientMsg(m);
    }
  }
  function showRemoteShots(shots) {
    for (const f of shots) G.rfeathers.push({ x: f[0], y: f[1], vx: f[2], vy: f[3], kind: FK[f[4]] || 'feather', life: f[5] / 100 });
    if (G.rfeathers.length > 300) G.rfeathers.splice(0, G.rfeathers.length - 300);
  }
  function netLost(msg) {
    const run = G.netRun;
    if (run) Saves.coopSave();
    netReset(); NetT.close();
    if(run) G.st=null;
    RunStats.toast('📡 ' + msg);
    if (run) AdventureMenu.openMenu(); else if (Session.state === 'mp') mpRender();
  }
  // хозяин может исключить игрока: в лобби (✕ у имени) и в игре (на паузе); до конца сессии он не вернётся
  function mpKick(cid) {
    const m = NET.peers.get(cid); if (!NET.host || !m) return;
    m.kicked = true; NET.kickedNames = NET.kickedNames || new Set(); NET.kickedNames.add(m.name);
    NetT.send(cid, { t: 'kick' }); setTimeout(() => NetT.kick(cid), 300);
    netDrop(cid); RunStats.toast(`🚪 ${m.name} исключена из игры`);
    if (Session.state === 'pause') kickListSync();
  }
  function kickBtn(b, cid, label) { // первое нажатие спрашивает «Точно?», второе – исключает
    b.addEventListener('click', e => {
      e.stopPropagation(); Sound.sfx.click();
      if (b._sure) { mpKick(cid); return; }
      b._sure = true; b.textContent = 'Точно?'; b.classList.add('sure');
      setTimeout(() => { b._sure = false; b.textContent = label; b.classList.remove('sure'); }, 2500);
    });
  }
  function kickListSync() {
    const box = $('pauseKick'); if (!box) return; box.innerHTML = '';
    const on = NET.host && G.netRun && NET.peers.size > 0; box.classList.toggle('hidden', !on); if (!on) return;
    const t = document.createElement('div'); t.className = 'pkT'; t.textContent = 'Игроки'; box.appendChild(t);
    for (const [cid, m] of NET.peers) { const b = document.createElement('button'); b.className = 'btn gray pkB'; const lb = `🚪 Исключить ${m.name}`; b.textContent = lb; kickBtn(b, cid, lb); box.appendChild(b); }
  }
  function netDrop(cid) {
    const m = NET.peers.get(cid); if (!m) return;
    NET.peers.delete(cid); NET.mates.delete(cid);
    if (G.netRun && !m.kicked) RunStats.toast(`👋 ${m.name} вышла из игры`);
    mpLobbyBroadcast();
  }
  function netHostMsg(cid, m) {
    if (m.t === 'hello') {
      if (m.v !== VERSION) { NetT.send(cid, { t: 'no', why: 'ver', v: VERSION }); setTimeout(() => NetT.kick(cid), 300); return; }
      if (NET.kickedNames && NET.kickedNames.has(String(m.name || 'Гость').slice(0, 14))) { NetT.send(cid, { t: 'no', why: 'kick' }); setTimeout(() => NetT.kick(cid), 300); return; }
      if (NET.peers.size >= NET_MAX - 1) { NetT.send(cid, { t: 'no', why: 'full' }); setTimeout(() => NetT.kick(cid), 300); return; }
      const mate = { id: cid, cd: Achievements.cleanCard(m.cd), name: String(m.name || 'Гость').slice(0, 14), hero: HEROES[m.hero] ? m.hero : 'krilessa', x: P.x, y: P.y, tx: P.x, ty: P.y, face: 1, t: 0, r: 14, hp: 1, mh: 1, live: false, down: false, inv: false, mag: 110 };
      NET.peers.set(cid, mate); NET.mates.set(cid, mate);
      NetT.send(cid, { t: 'hi', id: cid, v: VERSION });
      mpLobbyBroadcast();
      if (NET.started && !(G.rush && G.rush.done) && !(G.abyss && G.abyss.done)) { Saves.coopSave(); NetT.send(cid, netStartMsg(true)); if (G.netRun) RunStats.toast(`🎉 ${mate.name} присоединилась!`); }
      return;
    }
    const mate = NET.peers.get(cid); if (!mate) return;
    if (m.t === 'rdy') { if (NET.started) return; mate.rd = !!m.v; mpLobbyBroadcast(); return; } // подруга нажала «Готова»
    if (m.t === 'me') { mate.name = String(m.name || mate.name).slice(0, 14); if (HEROES[m.hero] && m.hero !== mate.hero) mate.rd = false; if (HEROES[m.hero]) mate.hero = m.hero; if (m.cd) mate.cd = Achievements.cleanCard(m.cd); mpLobbyBroadcast(); return; }
    if (m.t === 'bye') { NetT.kick(cid); netDrop(cid); return; }
    if (!G.netRun || (m.cid && m.cid !== NET.coopId)) return;
    if (m.t === 'saveReq') { Saves.coopSave(); return; }
    if (m.t === 'pz') { const by = mate.name || 'Игрок'; Screens.netPauseApply(m.v, by); NetT.send(-1, { t: 'pz', v: m.v ? 1 : 0, by }); return; }
    if (m.t === 'bd') { if (Defense.defOn() && 'buscmf'.includes(String(m.a))) Defense.tdDo(String(m.a), m.a === 'f' ? String(m.s) : +m.s || 0, m.a === 'b' ? String(m.k) : m.a === 'm' ? m.k : +m.k || 0, cid); return; } // подруга строит, улучшает или зовёт волну
    if (m.t === 'st') {
      mate.tx = m.x; mate.ty = m.y; if (!mate.live) { mate.x = m.x; mate.y = m.y; mate.live = true; }
      mate.face = m.f; mate.mv = !!m.m; mate.dash = !!m.d; mate.inv = !!m.i; mate.down = !!m.dn; mate.hp = m.hp; mate.mh = m.mh || 1; mate.mag = m.mg || 110; mate.z = m.z || 0;
      if (HEROES[m.h]) mate.hero = m.h;
      mate.away = !!m.aw; mate.seen = performance.now(); mate.rp = +m.rp || 0; mate.ar = +m.ar || 0;
      if (m.fe && m.fe.length) { showRemoteShots(m.fe); NET.fxIn.push([cid,m.fe]); }
      if (m.hi && m.hi.length) {
        const byId = new Map(); for (const e of G.enemies) byId.set(e.nid, e);
        for (const [nid, v, crit, kx, ky, slow] of m.hi) {
          const e = byId.get(nid); if (!e || e.dead) continue;
          NET.hitBy = cid; Enemies.damageEnemy(e, { v: +v || 0, crit: !!crit }, +kx || 0, +ky || 0, false); NET.hitBy = 0;
          if (slow && !e.dead) e.slowT = Math.max(e.slowT, +slow);
        }
      }
      if (m.bu && m.bu.length) { const byId = new Map(); for (const e of G.enemies) byId.set(e.nid, e); for (const [nid, dps] of m.bu) { const e = byId.get(nid); if (e && !e.dead) { e.burnT = 2; e.burnDps = Math.max(e.burnDps || 0, +dps || 0); e.burnTick = e.burnTick || 0.4; } } }
      if (m.bh && m.bh.length) for (const [bi, v, crit, dot] of m.bh) { const b = Session.bosses[bi]; if (b) { NET.hitBy = cid; Bosses.damageBoss(b, { v: +v || 0, crit: !!crit }, !!dot, true); NET.hitBy = 0; } }
      if (m.bc && m.bc.length) { const s = new Set(m.bc); for (const b of G.ebullets) if (s.has(b.nid)) b.life = 0; }
      if (m.pl !== undefined && World.pearls[m.pl] && !World.pearls[m.pl].got) netPearl(m.pl, cid);
      if (m.ml && m.ml.length) for (const i of m.ml) Expedition.meltTile(i, true); // растопила подруга
      if (m.dh && m.dh.length) for (const [k, v] of m.dh) { const dr = World.drifts[k]; if (dr && !dr.done) { dr.hp -= +v || 0; Effects.burst(dr.x, dr.y, 10, '#ffffff', 120); if (dr.hp <= 0) Expedition.openDrift(dr); } }
      mate.hidden = !!m.hd;
      if (m.rv) { if (m.rv === 1) Achievements.life('revives'); else netEvent(m.rv, ['rv']); }
      return;
    }
  }
  function netClientMsg(m) {
    if (m.t === 'hi') { NET.id = m.id; NET.joining = null; RunStats.toast('✅ Подключено!'); Sound.sfx.superReady(); if (Session.state === 'mp') mpRender(); return; }
    if (m.t === 'no') {
      RunStats.toast(m.why === 'ver' ? `У хозяина другая версия игры (v${m.v}). Обновитесь до одной версии` : m.why === 'full' ? 'В игре уже 4 игрока 😿' : m.why === 'kick' ? 'Хозяин исключил тебя из этой игры 🚪' : 'Хозяин не пустил');
      netReset(); NetT.close(); if (Session.state === 'mp') mpRender(); return;
    }
    if (m.t === 'lobby') {
      NET.roster = m.roster || []; NET.started = !!m.started; NET.savedSummary = m.saved || null; NET.ch = m.ch || 1; NET.dmap = m.dm || ''; NET.mut = (m.mut || []).filter(id => Challenges.MUT_BY[id]); netLooks();
      const me = NET.roster.find(r => r.id === NET.id); if (me) NET.rdy = !!me.rd; // хозяйка могла сбросить готовность
      const was = NET.goAt; NET.goAt = m.go ? performance.now() + m.go * 1000 : 0; if (NET.goAt && !was) Sound.sfx.superReady();
      if (Session.state === 'mp') mpRender(); return;
    }
    if (m.t === 'start') {
      NET.ch = m.ch; NET.layout = m.layout || 0; NET.dmap = m.dm || NET.dmap; NET.seed = m.seed; NET.diff = m.diff; NET.mut = (m.mut || []).filter(id => Challenges.MUT_BY[id]); NET.roster = m.roster || NET.roster; NET.started = true; netLooks();
      NET.rush = m.rk ? { kinds: m.rk, levels: m.rl } : null;
      NET.coopId = m.cid || null; NET.completed = false; NET.loading = true;
      const me = CoopCheckpoints.localBuild(m.cid);
      NET.checkpoint = m.res || null;
      netBegin();
      if (m.res) CoopCheckpoints.restore(m.res);
      if (me) Saves.coopApplyMine(me.mine || me);
      NET.loading = false;
      if (m.res) CoopCheckpoints.accept(m.res);
      if(NET.ch===8 && !m.res && !m.df) Intro.start('ch8',()=>{Screens.setState('play');Sound.music('belfry');});
      if (m.df) {
        if (typeof NET.ch === 'number') Saves.coopApplyWorld({df: m.df});
        else G.defeated = m.df.slice();
      }
      if (m.ml && m.ml.length) { NET.applyMelt = true; for (const i of m.ml) Expedition.meltTile(i, false); NET.applyMelt = false; }
      return;
    }
    if (m.t === 'end') { netLost('Хозяин закончил игру'); return; }
    if (m.t === 'kick') { netLost('Хозяин исключил тебя из игры'); return; }
    if (m.t === 'regroup') {
      if (!G.netRun || m.cid === NET.coopId) openTeamRoom();
      return;
    }
    if (!G.netRun || (m.cid && m.cid !== NET.coopId)) return;
    if (m.t === 'pz') { Screens.netPauseApply(m.v, String(m.by || 'Игрок').slice(0, 14)); return; }
    if (m.t === 'saveWorld') { CoopCheckpoints.accept(m.world); return; }
    if (m.t === 'saveDone') { CoopCheckpoints.clear(); return; }
    if (m.t === 's') { netApply(m); return; }
    if (m.t === 'x') { for (const ev of m.x || []) netMyEvent(ev); return; }
    if (m.t === 'ml') { NET.applyMelt = true; for (const i of m.ml || []) Expedition.meltTile(i, true); NET.applyMelt = false; return; }
    if (m.t === 'hc') { for (const id of m.hc || []) { const h = NET.hMap.get(id); if (h) h.cancel = true; } return; }
    if (m.t === 'rs') { netRespawnMe(m.x, m.y); return; }
    if (m.t === 'vic') { if (!G.cutscene) Story.startVictoryCutscene(); return; }
    if (m.t === 'say') { Screens.say(m.text, m.d || 4); return; }
    if (m.t === 'spk') { Screens.speak(m.k, m.text, m.d || undefined, false); return; }
    if (m.t === 'tr') { // хозяйка (или подруга) начала испытание – все на арену
      const sh = World.shrines[m.si]; if (sh) { sh.state = 'active'; G.activeShrine = sh; }
      NET.trialRet = { x: m.rx, y: m.ry }; NET.trialT = 0;
      const i = Math.max(1, NET.roster.findIndex(r => r.id === NET.id)), a = i * TAU / NET_MAX;
      Effects.burst(P.x, P.y, 30, '#ffffff', 240);
      P.x = m.x + Math.cos(a) * 44; P.y = m.y + Math.sin(a) * 44; World.ensureWalkable(P); P.inv = Math.max(P.inv, 1.2); P.dashT = 0; P.vx = 0; P.vy = 0;
      G.ebullets = []; G.hazards = []; NET.bMap.clear();
      Screens.showBanner('⛩ ' + (m.a || 'Испытание'), 'Все на арену! Победите всех – и вернётесь с наградой');
      Sound.sfx.blink(); Sound.music('boss'); G.shake = 10;
      return;
    }
    if (m.t === 'trx') { netTrialBack(m.x, m.y, !!m.ok); return; }
    if (m.t === 'dend') { const A = G.abyss; if (!A || !A.def || A.done) return; A.wave = (m.wave || 0) + 1; A.t = m.time || A.t; if (G.core) G.core.hp = +m.hp || 0; Defense.defFinish(); Defense.defEndScreen(); return; }
    if (m.t === 'rend') {
      if (!G.rush || G.rush.done) return;
      Object.assign(G.rush, { idx: m.n, total: m.total, t: m.time, links: m.links, players: m.players });
      if (m.win) Challenges.rushRecovery(false);
      Challenges.rushFinish(!!m.win);
      if (!m.win) Screens.playerDied();
      return;
    }
    if (m.t === 'c4') { NET.c4 = m.ch; if (G.cutscene && G.victoryShown && Session.state !== 'victory') HouseChapter.finishCh4(m.ch); return; }
    if (m.t === 'ban') { Screens.showBanner(m.a, m.b || ''); return; }
  }
  // ---------- хозяин: снимки мира ----------
  function netHostTick(dt) {
    for (const m of NET.peers.values()) {
      if (!m.live) continue;
      const k = Math.min(1, dt * 16); m.x += (m.tx - m.x) * k; m.y += (m.ty - m.y) * k; m.t += dt;
      if (performance.now() - m.seen > 6000 && !m.lost) { m.lost = true; RunStats.toast(`📡 ${m.name}: плохая связь…`); }
      if (performance.now() - m.seen < 2000) m.lost = false;
    }
    netTeamWipe(dt);
    for (const m of NET.peers.values()) { // костры зажигает и подруга – тут все и возродятся
      if (!m.live || m.down) continue;
      for (const f of World.fires) if (Math.hypot(f.x - m.x, f.y - m.y) < 95 && !G.activeBoss && (G.cp.x !== f.x || G.cp.y !== f.y + 34)) { G.cp = { x: f.x, y: f.y + 34 }; if (!f.lit) { f.lit = true; Effects.floatText(f.x, f.y - 40, '🔥 Костёр зажжён', '#ffd25a', true); } }
    }
    NET.snapT -= dt;
    if (NET.snapT > 0 || !G.netRun) return;
    NET.snapT = NET_SNAP;
    for (const e of G.enemies) if (!e.nid) e.nid = ++NET.uid;
    for (const b of G.ebullets) if (!b.nid) b.nid = ++NET.uid;
    for (const p of G.pickups) if (!p.nid) p.nid = ++NET.uid;
    for (const h of G.hazards) if (!h.nid) h.nid = ++NET.uid;
    // новые выстрелы хозяйки и Тессы-помощницы
    const myFx = [];
    for (const f of G.feathers) if (!f._n) { f._n = 1; myFx.push([f.x | 0, f.y | 0, f.vx | 0, f.vy | 0, Math.max(0, FK.indexOf(f.kind)), Math.round((f.life || 0.6) * 100)]); }
    const mates = [[1, P.x | 0, P.y | 0, P.face, (P.moving ? 1 : 0) | (P.dashT > 0 ? 2 : 0) | (P.inv > 0 ? 4 : 0) | (P.down ? 8 : 0) | (Session.state !== 'play' ? 16 : 0), P.hero, Math.round(P.hp / P.maxHp * 100), (P.z || 0) | 0, P.down ? Math.round(clamp(P.revT / 2.6, 0, 1) * 100) : 0, P.down && G.td ? Math.ceil(P.tdRev || 0) : 0]];
    for (const m of NET.peers.values()) if (m.live) mates.push([m.id, m.tx | 0, m.ty | 0, m.face, (m.mv ? 1 : 0) | (m.dash ? 2 : 0) | (m.inv ? 4 : 0) | (m.down ? 8 : 0) | (m.away ? 16 : 0), m.hero, Math.round(m.hp / Math.max(1, m.mh) * 100), m.z | 0, m.rp || 0, m.ar || 0]);
    const bo = Session.bosses.map(b => [b.state === 'fight' ? 1 : b.state === 'dead' ? 2 : 0, b.x | 0, b.y | 0, (b.z || 0) | 0, Math.max(0, Math.round(b.hp / b.maxHp * 1000)), b.stage || 0, b.mode || '', Math.round((b.look || 0) * 100), Math.round((b.alpha === undefined ? 1 : b.alpha) * 100),
      (b.inv ? 1 : 0) | (b.shield ? 2 : 0) | (b.charging ? 4 : 0) | (b.stunT > 0 ? 8 : 0) | (b.flash > 0 ? 16 : 0), b.mpX || 1, Math.round(b.maxHp), b.level, b.cdmg,
      ...(b.def.belfry && b.state==='fight' ? [b.sub,b.cnt,Math.round(b.t*100),Math.round((b.stride||0)*100),Math.round((b.walk||0)*100)] : [])]);
    // разовые события – отдельными надёжными сообщениями (снимки мира могут заменять друг друга)
    for (const [cid, list] of NET.ev) if (list.length && NET.peers.has(cid)) NetT.send(cid, { t: 'x', x: list });
    if (NET.meltOut.length) NetT.send(-1, { t: 'ml', ml: NET.meltOut });
    if (NET.hzCancel.length) NetT.send(-1, { t: 'hc', hc: NET.hzCancel });
    const common = { t: 's', cid: NET.coopId, sd: World.SEED, cn: World.CHN, tm: Math.round(G.time * 10), lv: [P.level, Math.round(P.xp), P.xpNext], bo, ab: G.activeBoss ? Session.bosses.indexOf(G.activeBoss) : -1,
      df: G.defeated.map(v => v ? 1 : 0), g: World.gateOpen ? 1 : 0, al: G.tessaAlly ? [G.tessaAlly.x | 0, G.tessaAlly.y | 0, G.tessaAlly.face || 1] : 0,
      kl: NET.killed, ev: G.ev ? [G.ev.def.id, Math.round(G.ev.t * 10), (G.ev.tx || 0) | 0, (G.ev.ty || 0) | 0, G.ev.goal || 0, G.ev.kills || 0, G.ev.thief ? G.ev.thief.nid || 0 : 0] : 0, ch: World.chests.map(c => c.open ? 1 : 0).join(''), pr: World.pearls.map(q => q.got ? 1 : 0).join(''),
      bm: G.beams.map(bm => [Session.bosses.indexOf(bm.b), Math.round(bm.ang * 1000), Math.round((bm.rot || 0) * 1000), Math.round(bm.t * 100), Math.round(bm.warm * 100), Math.round(bm.dur * 100), bm.w, Math.round(bm.dmg), bm.mouth ? 1 : 0]),
      bossMusic: G.activeBoss ? Sound.current() : undefined, nv: G.nextEv ? G.nextEv.id : 0, et: Math.round((G.evT || 0) * 10),
      fh: World.holes.map(h=>h.spent ? -1 : h.angler ? [h.angler,Math.round(h.prog*100)] : 0), cf: World.clues.map(q => q.found ? 1 : 0).join(''), c5: G.clues5, fl: World.fires.map(q => q.lit ? 1 : 0).join(''), dr: World.drifts.map(q => q.done ? 1 : 0).join(''),
      sh: World.shrines.map(q => q.state === 'done' ? 'd' : q.state === 'active' ? 'a' : 'i').join(''), wx: [G.wxId || '', Math.round((G.blizzardT || 0) * 10), Math.round((G.wxT || 0) * 10)], ac: G.accused ? 1 : 0, ko: G.keys || 0, ru: Challenges.rushSnapshot(), dz: Defense.defOn() ? Defense.defSnap() : 0 };
    for (const m of NET.peers.values()) {
      const R2 = NET_AOI * NET_AOI, near = (x, y) => (x - m.tx) ** 2 + (y - m.ty) ** 2 < R2;
      const e = [], b = [], p = [], h = [];
      for (const en of G.enemies) if (!en.dead && near(en.x, en.y)) e.push([en.nid, en.type, en.x | 0, en.y | 0, Math.max(1, Math.round(en.hp / en.maxHp * 100)),
        (en.elite ? 1 : 0) | (en.spawnT > 0 ? 2 : 0) | (en.burnT > 0 ? 4 : 0) | (en.slowT > 0 ? 8 : 0) | (en.champion ? 16 : 0) | (en.charge > 0 || en.wind > 0 || en.fuse > 0 ? 32 : 0) | (en.face < 0 ? 64 : 0) | (en.thief ? 128 : 0) | (en.healing > 0 ? 256 : 0) | (en.buffT > 0 ? 512 : 0),
        Math.round((en.look || 0) * 100), en.affix || 0, Math.round(en.r)]);
      for (const bl of G.ebullets) if (bl.life > 0 && near(bl.x, bl.y)) b.push([bl.nid, bl.x | 0, bl.y | 0, bl.vx | 0, bl.vy | 0, bl.r, bl.col || '#fff', bl.emoji || 0,
        (bl.square ? 1 : 0) | (bl.saw ? 2 : 0) | (bl.bounce ? 4 : 0) | (bl.missile ? 8 : 0) | (bl.slow ? 16 : 0), Math.round(bl.life * 100), Math.round(bl.dmg), bl.hx | 0, bl.hy | 0]);
      for (const pk of G.pickups) if (near(pk.x, pk.y)) p.push([pk.nid, Math.max(0, PK.indexOf(pk.kind)), pk.x | 0, pk.y | 0, pk.sid === undefined ? -1 : pk.sid]);
      for (const hz of G.hazards) if (near(hz.x, hz.y) && !hz.cancel) { const o = {}; for (const k in hz) { const v = hz[k]; if (v !== null && typeof v === 'object' && !Array.isArray(v)) continue; if (typeof v === 'function') continue; o[k] = typeof v === 'number' ? Math.round(v * 100) / 100 : v; } h.push(o); }
      const fe = myFx.slice(); for (const [from, list] of NET.fxIn) if (from !== m.id) for (const f of list) fe.push(f);
      const msg = Object.assign({}, common, { e, b, p, h, fe, m: mates.filter(r => r[0] !== m.id) });
      NetT.send(m.id, msg);
    }
    NET.ev.clear(); NET.killed = []; NET.hzCancel = []; NET.fxIn = []; NET.meltOut = [];
  }
  // ---------- гость: применить снимок ----------
  function netProxy(r) {
    const [nid, type, x, y] = r;
    if (!ENEMIES[type]) return null;
    const bi = World.biomeMap[clamp(Math.floor(y / World.T), 0, World.MH - 1) * World.MW + clamp(Math.floor(x / World.T), 0, World.MW - 1)];
    const e = Enemies.spawnEnemy(type, x, y, bi, { instant: true, minion: true });
    e.nid = nid; e.tx = x; e.ty = y; e.proxy = true;
    return e;
  }
  function netApply(s) {
    if (s.sd !== undefined && (s.sd !== World.SEED || s.cn !== World.CHN)) return; // снимок другой главы (пришёл раньше «start») – не наш
    NET.lastSnap = performance.now();
    if(s.fh){G.fishing=null;s.fh.forEach((v,i)=>{const h=World.holes[i];if(!h)return;h.spent=v===-1;h.prog=Array.isArray(v)?v[1]/100:0;if(Array.isArray(v) && v[0]===NET.id)G.fishing=h;});}
    if (s.dz && Defense.defOn()) Defense.defNetApply(s.dz); // оборона: волна, кристалл, постройки, страж
    // общий уровень команды
    const [lv, xp, xn] = s.lv;
    if (lv > P.level) { const d = lv - P.level; P.level = lv; G.pendingLv += d; Actors.computeStats(); if (Session.state === 'play' && !G.cutscene) Screens.openLevelUp(); }
    P.xp = xp; P.xpNext = xn;
    // подруги
    const seenM = new Set();
    for (const [id, x, y, face, fl, hero, hp, z, rp, ar] of s.m) {
      seenM.add(id);
      let m = NET.mates.get(id);
      if (!m) { m = { id, x, y, t: 0, r: 14 }; NET.mates.set(id, m); }
      m.rp = rp || 0; m.ar = ar || 0; m.tx = x; m.ty = y; m.face = face; m.mv = !!(fl & 1); m.dash = !!(fl & 2); m.inv = !!(fl & 4); m.down = !!(fl & 8); m.away = !!(fl & 16); m.hero = hero; m.hpF = hp; m.z = z || 0;
      const rr = NET.roster.find(q => q.id === id); m.name = rr ? rr.name : (id === 1 ? 'Хозяйка' : 'Подруга');
    }
    for (const id of [...NET.mates.keys()]) if (!seenM.has(id)) NET.mates.delete(id);
    // мобы
    const killed = new Set((s.kl || []).map(k => k[0]));
    const seenE = new Set();
    for (const r of s.e) {
      let e = NET.eMap.get(r[0]);
      if (!e || e.dead || e.type !== r[1]) { if (e) e.dead = true; e = netProxy(r); if (!e) continue; NET.eMap.set(r[0], e); }
      seenE.add(r[0]);
      e.tx = r[2]; e.ty = r[3]; e.hp = r[4] / 100 * e.maxHp; e.netF = r[5]; e.look = r[6] / 100; e.affix = r[7] || null; e.elite = !!(r[5] & 1); e.champion = !!(r[5] & 16); e.thief = !!(r[5] & 128);
      e.spawnT = r[5] & 2 ? 0.2 : 0; e.burnT = r[5] & 4 ? 0.5 : 0; e.slowT = r[5] & 8 ? 0.5 : 0; e.healing = r[5] & 256 ? 0.3 : 0; e.buffT = r[5] & 512 ? 0.3 : 0;
      e.face = r[5] & 64 ? -1 : 1; e.r = r[8] || e.r;
      if (e.def.ai === 'exploder') e.fuse = r[5] & 32 ? 0.5 : 0; else e.charge = r[5] & 32 ? 0.3 : 0;
    }
    for (const [nid, e] of NET.eMap) {
      if (seenE.has(nid)) continue;
      if (killed.has(nid)) { Effects.burst(e.x, e.y, e.elite ? 30 : 12, e.col && e.col.startsWith('#') ? e.col : '#c77dff', 170); Sound.sfx.die(); }
      e.dead = true; NET.eMap.delete(nid);
    }
    G.enemies = G.enemies.filter(e => !e.dead);
    // вражеские снаряды
    const nb = [];
    if (NET.goneB.size > 600) NET.goneB.clear();
    for (const r of s.b) {
      if (NET.goneB.has(r[0])) continue;
      let b = NET.bMap.get(r[0]);
      if (!b) { b = { nid: r[0], rot: 0, homing: 0 }; }
      Object.assign(b, { x: r[1], y: r[2], vx: r[3], vy: r[4], spd: Math.hypot(r[3], r[4]), r: r[5], col: r[6], emoji: r[7] || null, square: !!(r[8] & 1), saw: !!(r[8] & 2), bounce: !!(r[8] & 4), missile: !!(r[8] & 8), slow: !!(r[8] & 16), life: r[9] / 100, dmg: r[10], hx: r[11], hy: r[12] });
      if (!b.gone) nb.push(b);
    }
    NET.bMap = new Map(nb.map(b => [b.nid, b])); G.ebullets = nb;
    // подбирашки – только показать (подбирает хозяин)
    const np = [];
    for (const r of s.p) { let p = NET.pMap.get(r[0]); if (!p) p = { nid: r[0], t: 0 }; p.kind = PK[r[1]] || 'xp'; p.x = r[2]; p.y = r[3]; if (r[4] >= 0) p.sid = r[4]; if (p.kind === 'xp' && !p.v) p.v = 1; np.push(p); }
    NET.pMap = new Map(np.map(p => [p.nid, p])); G.pickups = np;
    // опасные зоны: новые добавляем, свои часы у каждой зоны идут сами
    for (const o of s.h) if (!NET.hMap.has(o.nid)) { const h = Object.assign({}, o); NET.hMap.set(o.nid, h); G.hazards.push(h); CombatCues.announce(h); }
    for (const id of s.hc || []) { const h = NET.hMap.get(id); if (h) h.cancel = true; }
    if (NET.hMap.size > 400) { const live = new Set(G.hazards.map(h => h.nid)); for (const id of [...NET.hMap.keys()]) if (!live.has(id)) NET.hMap.delete(id); }
    // боссы
    s.bo.forEach((r, i) => {
      const b = Session.bosses[i]; if (!b) return;
      const st = r[0] === 1 ? 'fight' : r[0] === 2 ? 'dead' : 'sleep';
      if (st === 'dead' && b.state !== 'dead') { Effects.burst(b.x, b.y, 40, '#ffd25a', 260); }
      b.state = st; b.tx = r[1]; b.ty = r[2]; if (b.netSeen === undefined) { b.x = r[1]; b.y = r[2]; } b.netSeen = 1;
      if (r[11] > 1) b.maxHp = r[11]; b.mpX = r[10] || 1;
      b.level = r[12]; b.cdmg = r[13];
      b.z = r[3]; b.hp = r[4] / 1000 * b.maxHp; b.stage = r[5]; b.mode = r[6]; b.look = r[7] / 100; b.alpha = r[8] / 100;
      if (r.length>14) {
        b.sub=r[14]; b.cnt=r[15]; b.t=r[16]/100; b.stride=r[17]/100; b.walk=r[18]/100;
      }
      b.inv = !!(r[9] & 1); b.shield = !!(r[9] & 2); b.charging = !!(r[9] & 4); b.stunT = r[9] & 8 ? 0.3 : 0; if (r[9] & 16) b.flash = Math.max(b.flash || 0, 0.06);
    });
    const oldBoss=G.activeBoss;
    G.activeBoss = s.ab >= 0 ? Session.bosses[s.ab] : null;
    if(oldBoss!==G.activeBoss && !G.cutscene){
      if(G.activeBoss) Sound.music(s.bossMusic || (World.CFG.rush ? 'rush' : 'boss'));
      else Encounters.biomeMusic(true);
    }
    // стражи, ворота, звёзды
    s.df.forEach((v, i) => {
      if (v && !G.defeated[i]) { G.defeated[i] = true; const b = Session.bosses[i]; if (b) { Bosses.awardStar(b); b.state = 'dead'; Screens.showBanner('ПОБЕДА!', b.def.name + ' повержен'); Achievements.life('bosses'); Collection.bookKill('b', b.kind); Challenges.buzz(160); } }
    });
    World.restoreBridge();
    if (s.g && !World.gateOpen) { World.gateOpen = true; Screens.say(World.CHN===8 ? World.CFG.gateSay : 'Ворота открыты! Скорее в замок!'); }
    if (s.al) { if (!G.tessaAlly) G.tessaAlly = { x: s.al[0], y: s.al[1], face: 1, fireT: 9 }; G.tessaAlly.tx = s.al[0]; G.tessaAlly.ty = s.al[1]; G.tessaAlly.face = s.al[2]; } else G.tessaAlly = null;
    if (s.ch) for (let i = 0; i < World.chests.length && i < s.ch.length; i++) if (s.ch[i] === '1' && !World.chests[i].open) { World.chests[i].open = true; Effects.burst(World.chests[i].x, World.chests[i].y, 12, '#ffd25a', 140); }
    if (s.pr) for (let i = 0; i < World.pearls.length && i < s.pr.length; i++) if (s.pr[i] === '1' && !World.pearls[i].got) World.pearls[i].got = true;
    if (s.sh) for (let i = 0; i < World.shrines.length && i < s.sh.length; i++) { const v = s.sh[i] === 'd' ? 'done' : s.sh[i] === 'a' ? 'active' : 'idle'; World.shrines[i].state = v; if (v !== 'active' && G.activeShrine === World.shrines[i] && P.y <= World.PLAY_H * World.T) G.activeShrine = null; }
    // чужие выстрелы – просто картинка
    if (s.fe) showRemoteShots(s.fe);
    // лучи боссов – урон по себе считаем сами
    G.beams = (s.bm || []).map(r => ({ b: Session.bosses[r[0]], ang: r[1] / 1000, rot: r[2] / 1000, t: r[3] / 100, warm: r[4] / 100, dur: r[5] / 100, w: r[6], dmg: r[7], mouth: !!r[8], len: 0, x: 0, y: 0 })).filter(bm => bm.b);
    // события карты
    if (s.ev) {
      const def = EVENTS.find(e => e.id === s.ev[0]);
      if (def) {
        if (!G.ev || G.ev.def !== def) { G.ev = { def, t: 0, k: 0, kills: 0 }; if (def.id === 'song') { $('songText').textContent = SONG_TEXTS[0]; $('songBanner').classList.remove('hidden'); } }
        Object.assign(G.ev, { t: s.ev[1] / 10, tx: s.ev[2], ty: s.ev[3], goal: s.ev[4], kills: s.ev[5], thief: s.ev[6] ? NET.eMap.get(s.ev[6]) || null : null });
      }
    } else if (G.ev) { if (G.ev.def.id === 'song') $('songBanner').classList.add('hidden'); G.ev = null; }
    G.nextEv = s.nv ? EVENTS.find(e => e.id === s.nv) || null : null; G.evT = (s.et || 0) / 10;
    // улики, костры, сугробы, лёд, погода
    if (s.cf) for (let i = 0; i < World.clues.length && i < s.cf.length; i++) World.clues[i].found = s.cf[i] === '1';
    if (s.c5) G.clues5 = s.c5.slice();
    if (s.fl) for (let i = 0; i < World.fires.length && i < s.fl.length; i++) World.fires[i].lit = s.fl[i] === '1';
    if (s.dr) for (let i = 0; i < World.drifts.length && i < s.dr.length; i++) if (s.dr[i] === '1' && !World.drifts[i].done) { World.drifts[i].done = true; Effects.burst(World.drifts[i].x, World.drifts[i].y, 30, '#ffffff', 200); Sound.sfx.glass(); }
    if (s.ml && s.ml.length) { NET.applyMelt = true; for (const i of s.ml) Expedition.meltTile(i, true); NET.applyMelt = false; }
    if (s.wx) { G.wxId = s.wx[0] || null; G.blizzardT = s.wx[1] / 10; G.wxT = s.wx[2] / 10; }
    G.accused = !!s.ac; G.keys = s.ko || 0;
    if (s.ru) Challenges.applyRushSnapshot(s.ru);
    // события для меня
    if (s.x) for (const ev of s.x) netMyEvent(ev);
  }
  function netMyEvent(ev) {
    const [k, v] = ev;
    if (k === 'k') { // моя добыча
      G.kills++; Hero.addSuper(v ? 8 : 2.2); Achievements.life('kills'); if (v) Achievements.life('elites'); if (ev[2]) Collection.bookKill('e', ev[2]);
      if (G.st) { G.st.kills++; if (v) G.st.elites++; if (ev[2]) G.st.byType[ev[2]] = (G.st.byType[ev[2]] || 0) + 1; } // 1.0.11: у гостьи тоже считаются
      if (P.vamp && P.hp < P.maxHp) P.hp = Math.min(P.maxHp, P.hp + P.vamp);
      if (Encounters.hasRelic('fang') && P.hp < P.maxHp) P.hp = Math.min(P.maxHp, P.hp + P.maxHp * 0.005 * (1 + Encounters.relicLv('fang')));
    } else if (k === 'hl') {
      const h = Math.round(P.maxHp * 0.25 * (Encounters.hasRelic('heartstone') ? 1.25 + 0.25 * Encounters.relicLv('heartstone') : 1) * Math.pow(1 + 0.2, Actors.lv('c5snack')));
      P.hp = Math.min(P.maxHp, P.hp + h); Effects.floatText(P.x, P.y - 34, '+' + h, '#7dff7d'); Sound.sfx.heart();
    } else if (k === 'sp') { Hero.addSuper(v); Effects.floatText(P.x, P.y - 34, '⭐ +' + v + '% супера', '#ffe08a'); Sound.sfx.shard(); }
    else if (k === 'key') { Effects.floatText(P.x, P.y - 34, '🔑 +1 (общий)', '#ffd25a', true); Sound.sfx.clue(); }
    else if (k === 'gem') Sound.sfx.gem();
    else if (k === 'sh') {
      const s = SHARDS[v]; if (!s) return;
      const pb = World.biomeMap[clamp(Math.floor(P.y / World.T), 0, World.MH - 1) * World.MW + clamp(Math.floor(P.x / World.T), 0, World.MW - 1)];
      const val = s.id === 'hp' ? Math.max(3, Math.round(refEHP(Actors.zoneE(pb)) * 0.012)) : s.val;
      P.bonus[s.id] = (P.bonus[s.id] || 0) + val; P.shards++; Actors.computeStats();
      if (s.id === 'hp') P.hp = Math.min(P.maxHp, P.hp + val);
      Effects.floatText(P.x + rnd(-10, 10), P.y - 40, s.txt(val), s.col); Sound.sfx.shard();
    } else if (k === 'lvl') { G.pendingLv += v || 1; if (Session.state === 'play') Screens.openLevelUp(); }
    else if (k === 'relic') { if (Session.state === 'play') Encounters.openRelicChoice(); }
    else if (k === 'txt') Effects.floatText(P.x, P.y - 40, v, '#ffd25a', true);
    else if (k === 'rv') Achievements.life('revives');
    else if (k === 'dw') { if (Defense.defOn()) Defense.defWaveDone(v); }
    else if (k === 'fishHeal') { const gain=Math.min(P.maxHp-P.hp,Math.round(P.maxHp*.2));P.hp+=gain;Effects.healing(gain);Sound.sfx.clue(); }
    else if (k === 'rr' && G.rush && !G.rush.done) {
      // Награда может прийти до очередного снимка. Для карточек нужен уже следующий босс.
      if (v > (G.rush.rewardedRound || 0)) {
        G.rush.rewardedRound = v;
        G.rush.idx = Math.max(G.rush.idx, v);
        Challenges.rushRecovery(true);
      }
    } else if (k === 'rh') { P.hp = Math.min(P.maxHp, P.hp + P.maxHp * 0.5); G.pendingLv++; if (Session.state === 'play') Screens.openLevelUp(); }
    else if (k === 'inv') { G.invertT = v; Screens.showBanner('🔄 ПЕРЕВЁРНУТО', 'Управление шиворот-навыворот!'); }
    else if (k === 'stat') G.staticT = v;
  }
  // ---------- гость: своя героиня ----------
  function netClientTick(dt) {
    if (performance.now() - NET.lastSnap > 7000 && NET.lastSnap) { netLost('Связь с хозяином пропала'); return; }
    NET.stT -= dt;
    if (NET.stT > 0) return;
    NET.stT = NET_ST;
    const fe = [];
    for (const f of G.feathers) if (!f._n) { f._n = 1; fe.push([f.x | 0, f.y | 0, f.vx | 0, f.vy | 0, Math.max(0, FK.indexOf(f.kind)), Math.round((f.life || 0.6) * 100)]); }
    for (const e of G.enemies) if (e.burnT > 1.9 && e.burnDps && !e._bs) { e._bs = 1; NET.burns.push([e.nid, Math.round(e.burnDps)]); }
    const msg = { t: 'st', cid: NET.coopId, x: Math.round(P.x), y: Math.round(P.y), f: P.face, m: P.moving ? 1 : 0, d: P.dashT > 0 ? 1 : 0, i: P.inv > 0 || P.dashT > 0 ? 1 : 0, h: P.hero, hp: Math.round(P.hp), mh: P.maxHp,
      dn: P.down ? 1 : 0, mg: Math.round(P.magnet || 110), z: Math.round(P.z || 0), aw: Session.state !== 'play' ? 1 : 0,
      rp: P.down ? Math.round(clamp(P.revT / 2.6, 0, 1) * 100) : 0, ar: P.down && G.td ? Math.ceil(P.tdRev || 0) : 0 }; // как идёт подъём – видно подругам
    if (fe.length) msg.fe = fe;
    if (NET.hits.length) { msg.hi = NET.hits; NET.hits = []; }
    if (NET.bhits.length) { msg.bh = NET.bhits; NET.bhits = []; }
    if (NET.bcons.length) { msg.bc = NET.bcons; NET.bcons = []; }
    if (NET.burns.length) { msg.bu = NET.burns; NET.burns = []; }
    if (NET.pearlReq !== undefined) { msg.pl = NET.pearlReq; NET.pearlReq = undefined; }
    if (NET.meltOut.length) { msg.ml = NET.meltOut; NET.meltOut = []; }
    if (NET.driftHits.length) { msg.dh = NET.driftHits; NET.driftHits = []; }
    if (G.hidden) msg.hd = 1;
    if (NET.revBy) { msg.rv = NET.revBy; NET.revBy = 0; }
    NetT.send(0, msg);
  }
  function netProxies(dt) {
    const k = Math.min(1, dt * 14);
    for (const e of G.enemies) {
      e.t += dt; if (e.flash > 0) e.flash -= dt;
      if (e.tx === undefined) continue;
      e.x += (e.tx - e.x) * k; e.y += (e.ty - e.y) * k;
      if (e.def.ai === 'shield') e.shieldAng += clamp(angDiff(e.shieldAng, e.look || 0), -2.4 * dt, 2.4 * dt); // щит поворачивается вслед за взглядом
      if (e.spawnT > 0 || e.thief || e.fuse > 0 || P.down) continue;
      if ((P.x - e.x) ** 2 + (P.y - e.y) ** 2 < (e.r + P.r - 2) ** 2) Hero.hurtPlayer(e.dmg, e.x, e.y);
    }
    for (const b of Session.bosses) if (b.tx !== undefined && b.state !== 'dead') { b.x += (b.tx - b.x) * k; b.y += (b.ty - b.y) * k; b.anim = (b.anim || 0) + dt;
      if (b.def.belfry && b.state==='fight') {b.t-=dt; b.stride=(b.stride||0)+(b.walk||0)*dt*6.2;}
      if (b.flash > 0) b.flash -= dt; }
    const A = G.tessaAlly; if (A && A.tx !== undefined) { A.x += (A.tx - A.x) * k; A.y += (A.ty - A.y) * k; }
    for (const p of G.pickups) p.t += dt;
    const ab = G.activeBoss; // касание босса
    if (ab && ab.state === 'fight' && (ab.z || 0) < 10 && (ab.alpha === undefined || ab.alpha > 0.5) && !P.down && Math.hypot(P.x - ab.x, P.y - ab.y) < ab.r + P.r - 4) Hero.hurtPlayer(ab.charging ? ab.cdmg * 1.6 : ab.cdmg, ab.x, ab.y);
    for (const c of World.chests) if (!c.open && !c.seen && Math.hypot(P.x - c.x, P.y - c.y) < 320) c.seen = true;
    // гостья может уйти с арены сама – через выход
    if (G.activeShrine && World.ARENA && P.y > World.PLAY_H * World.T) {
      NET.trialT = (NET.trialT || 0) + dt;
      if (NET.trialT > 1.5 && !P.down && Math.hypot(P.x - World.ARENA.exit.x, P.y - World.ARENA.exit.y) < 24 && NET.trialRet) {
        G.activeShrine = null; netLeaveArena(NET.trialRet.x, NET.trialRet.y);
        Effects.floatText(P.x, P.y - 40, 'Ты ушла с испытания', '#ffe9a0', true);
      }
    }
  }
  // гостья в главе 6: костры греют, метель холодит – по-своему, но погоду решает хозяйка
  function netWinterLocal(dt) {
    if (!(World.beds.length || World.shelves.length || World.boxes.length || World.clues.length || World.CFG.dark)) { if (G.invertT > 0) G.invertT -= dt; if (G.staticT > 0) G.staticT -= dt; }
    G.nearFire = null;
    for (const f of World.fires) {
      if (Math.abs(f.x - P.x) > 120 || Math.abs(f.y - P.y) > 120 || Math.hypot(f.x - P.x, f.y - P.y) > 95) continue;
      G.nearFire = f;
      if (P.hp < P.maxHp && !P.down) P.hp = Math.min(P.maxHp, P.hp + P.maxHp * 0.05 * Math.pow(1 + 0.5, Actors.lv('c6warm')) * dt);
    }
    if (World.CFG.weathers || World.fires.length) G.blizA = lerp(G.blizA || 0, G.blizzardT > 0 ? 1 : 0, Math.min(1, dt * 1.6));
  }
  // вспомогательное
  function netLiveMates() { let n = 0; for (const m of NET.peers.values()) if (m.live) n++; return n; }
  const netCoop = () => NET.host && G.netRun && netLiveMates() > 0; // хозяйка и хотя бы одна подруга в игре
  const netXpDiv = () => netCoop() ? 1 + 0.65 * netLiveMates() : 1;
  function netLeaveArena(x, y) {
    Effects.burst(P.x, P.y, 24, '#ffffff', 200);
    P.x = x + rnd(-30, 30); P.y = y + rnd(0, 30); World.ensureWalkable(P); P.inv = Math.max(P.inv, 1);
    G.ebullets = []; G.hazards = []; NET.bMap.clear(); Terrain.revealFog(P.x, P.y, 12); Sound.sfx.blink(); Encounters.biomeMusic(true);
  }
  function netTrialBack(x, y, ok) {
    const inArena = P.y > World.PLAY_H * World.T; // награда – только тем, кто дошёл до конца
    if (G.activeShrine && G.activeShrine.state === 'active' && !ok) G.activeShrine.state = 'idle';
    G.activeShrine = null;
    if (!inArena) return;
    netLeaveArena(x, y);
    if (ok) { Achievements.life('trials'); Screens.showBanner('Испытание пройдено!', 'Награда: улучшение и осколки'); Hero.addSuper(30); G.pendingLv++; if (Session.state === 'play') Screens.openLevelUp(); Sound.sfx.win(); }
    else Effects.floatText(P.x, P.y - 40, 'Испытание провалено', '#ff8a8a', true);
  }
  function netBan(a, b) { Screens.showBanner(a, b); if (NET.host && G.netRun) NetT.send(-1, { t: 'ban', a, b: b || '' }); }
  function netNear(x, y, r) {
    if (!P.down && Math.hypot(P.x - x, P.y - y) < r) return true;
    if (NET.host) for (const m of NET.peers.values()) if (m.live && !m.down && Math.hypot(m.x - x, m.y - y) < r) return true;
    return false;
  }
  function netAnchor() {
    if (!NET.host || !NET.peers.size) return P;
    const L = [P].concat([...NET.peers.values()].filter(m => m.live && !m.down && !m.away)).filter(q => !q.down);
    return L[Math.floor(Math.random() * L.length)] || P;
  }
  function netMateInCastle() {
    if (!NET.host) return false;
    for (const m of NET.peers.values()) if (m.live && !m.down && Physics.playerInCastle(m)) return true;
    return false;
  }
  // подруги на экране – под плашкой уровня
  function netHud(c, x, y) {
    let k = 0;
    for (const m of NET.mates.values()) {
      if (m.tx === undefined) continue;
      CombatCues.rescue(c,m);
      const yy = y + k * 20, hpF = m.down ? 0 : (m.hpF !== undefined ? m.hpF / 100 : (m.hp || 0) / Math.max(1, m.mh || 1));
      c.fillStyle = 'rgba(0,0,0,0.45)'; roundRect(c, x, yy, 128, 17, 7); c.fill();
      c.fillStyle = mateCol(m.id); c.beginPath(); c.arc(x + 9, yy + 8.5, 4.5, 0, TAU); c.fill();
      c.font = 'bold 10px Krilessa Icons, sans-serif'; c.textAlign = 'left'; c.fillStyle = '#ffffff';
      c.fillText((m.down ? '💫 ' : '') + (m.name || '').slice(0, 10), x + 17, yy + 12);
      c.fillStyle = 'rgba(255,255,255,0.18)'; c.fillRect(x + 82, yy + 6, 40, 5);
      c.fillStyle = hpF > 0.5 ? '#7dff7d' : hpF > 0.25 ? '#ffd25a' : '#ff5b5b'; c.fillRect(x + 82, yy + 6, 40 * clamp(hpF, 0, 1), 5);
      k++;
    }
  }
  function netMates(dt) {
    const k = Math.min(1, dt * 15);
    for (const m of NET.mates.values()) { if (m.tx === undefined) continue; m.x += (m.tx - m.x) * k; m.y += (m.ty - m.y) * k; m.t += dt; }
    for (const f of G.rfeathers) { f.x += f.vx * dt; f.y += f.vy * dt; f.life -= dt; if (World.blocksShots(f.x, f.y)) f.life = 0; }
    G.rfeathers = G.rfeathers.filter(f => f.life > 0);
  }
  // ---------- без сил и подъём ----------
  function netDown() {
    if (P.down) return;
    Challenges.buzz(220);
    P.down = true; P.hp = 0; P.revT = 0; P.stormT = 0;
    Effects.burst(P.x, P.y, 30, '#c9b3ff', 220); Sound.sfx.hurt();
    Screens.showBanner('Без сил!', 'Подруга поднимет – пусть постоит рядом');
    G.combo = 0;
    if (G.st) { G.st.deaths++; if (G.st.cur) G.st.cur.d++; }
  }
  function netReviveTick(dt) {
    if (!P.down) return;
    P.inv = Math.max(P.inv, 0.3);
    let helper = null;
    for (const m of NET.mates.values()) if (!m.down && !m.away && (m.x - P.x) ** 2 + (m.y - P.y) ** 2 < 70 * 70) { helper = m; break; }
    if (helper) { P.revT += dt; if (Math.random() < 0.3) Effects.part(P.x + rnd(-14, 14), P.y + rnd(-10, 6), 0, -40, 0.6, 4, '#7dff9a'); }
    else P.revT = Math.max(0, P.revT - dt * 0.5);
    if (P.revT >= 2.6) {
      P.down = false; P.hp = Math.round(P.maxHp * 0.4); P.inv = 2.2; P.revT = 0;
      if (helper) { if (NET.client) NET.revBy = helper.id; else if (NET.host) netEvent(helper.id, ['rv']); } // спасибо подруге – в достижения
      Effects.burst(P.x, P.y, 26, '#7dff9a', 220); Sound.sfx.heart();
      Screens.showBanner('Снова в строю!', helper ? `${helper.name} подняла тебя 💗` : '');
    }
  }
  function netTeamWipe(dt) {
    if (!G.netRun || G.cutscene) return;
    const live = [...NET.peers.values()].filter(m => m.live && !m.away);
    const all = P.down && live.every(m => m.down);
    NET.wipeT = all ? NET.wipeT + dt : 0;
    if (NET.wipeT > 1.8) {
      NET.wipeT = 0;
      if (G.rush) { if (!G.rush.done) { Challenges.rushFinish(false); Screens.playerDied(); } return; } // в раше упали все – забег окончен
      if (Defense.defOn()) return; // в обороне все отдохнут у кристалла и вернутся сами
      Screens.showBanner('Все без сил…', 'Начинаем с последней точки');
      P.down = false; P.revT = 0;
      Screens.respawn();
      [...NET.peers.values()].forEach((m, i) => { const a = (i + 1) * TAU / NET_MAX; NetT.send(m.id, { t: 'rs', x: Math.round(G.cp.x + Math.cos(a) * 30), y: Math.round(G.cp.y + Math.sin(a) * 30) }); });
    }
  }
  function netRespawnMe(x, y) {
    P.down = false; P.revT = 0; P.x = x; P.y = y; World.ensureWalkable(P);
    P.hp = P.maxHp; P.inv = 2; P.dashT = 0; P.slowT = 0; P.lives = HEROES[P.hero].lives || 0;
    G.ebullets = []; G.hazards = []; NET.bMap.clear();
    Screens.showBanner('Ещё раз – вместе!', ''); Screens.setState('play');
  }
  function netPearl(k, cid) { // жемчужину подобрала гостья – слово для всех
    const q = World.pearls[k]; if (!q || q.got) return;
    Expedition.collectPearl(k, true);
    netEvent(cid, ['hl']);
  }
  // каждый кадр – и в меню (поиск игр), и в игре
  function netTick(dt) {
    if (!NET.on && !NET.scanning) return;
    netRecv();
    if (!NET.on) { // ищем: обновляем список раз в полсекунды
      NET.scanT -= dt; if (NET.scanT <= 0) { NET.scanT = 0.5; if (Session.state === 'mp') renderFoundRooms(); }
      return;
    }
    if (NET.joining && performance.now() - NET.joining.t > 7000 && !NET.id) {
      backToSearch('Комната не отвечает. Проверь, что оба телефона в одной сети Wi-Fi.');
      return;
    }
    if (NET.goAt && !NET.started) { // отсчёт перед стартом: все нажали «Готова»
      if (Session.state === 'mp') mpWaitText();
      if (NET.host && performance.now() >= NET.goAt) mpGo();
    }
    if (!G.netRun) return;
    if (Session.state !== 'play' && Session.state !== 'dying') P.inv = Math.max(P.inv, 0.25); // выбираешь улучшение – тебя не трогают
    netMates(dt);
    netReviveTick(dt);
    if (NET.host) netHostTick(dt); else netClientTick(dt);
  }
  // ближайшая к мобу героиня (хозяйка или подруга) – за ней он и гонится
  function netAim(x, y) {
    if (!NET.host || !NET.peers.size) return P;
    let best = P.down ? null : P, bd = P.down ? 1e18 : (P.x - x) ** 2 + (P.y - y) ** 2;
    for (const m of NET.peers.values()) { if (!m.live || m.down || m.away || m.hidden) continue; const d = (m.x - x) ** 2 + (m.y - y) ** 2; if (d < bd) { bd = d; best = m; } }
    return best || P;
  }
  // образы игроков из лобби: аура, эмблема и рамка видны подругам
  function netLooks() {
    NET.looks = new Map();
    const cards = [];
    for (const r of NET.roster || []) { const cd = Achievements.cleanCard(r.cd); if (cd) { NET.looks.set(r.id, cd); cards.push(cd); } }
    if (cards.length) try { Achievements.addFriends(cards); } catch (e) { /* ignore */ }
  }
  function drawMate(c, m) {
    const col = mateCol(m.id), y = m.y - (m.z || 0), lk = NET.looks && NET.looks.get(m.id);
    shadow(c, m.x, m.y + 10, 11, 4);
    if (lk && !m.down && !m.hidden) drawAura(c, lk.au, m.x, y, m.t || 0);
    c.strokeStyle = col; c.globalAlpha = 0.75; c.lineWidth = 2.5; c.beginPath(); c.ellipse(m.x, m.y + 10, 15, 6, 0, 0, TAU); c.stroke(); c.globalAlpha = 1;
    if (m.down) {
      c.save(); c.translate(m.x, m.y + 4); c.rotate(Math.PI / 2 * (m.face || 1)); c.globalAlpha = 0.65; Renderer.drawHeroV(m.hero, c, 0, 0, m.t, 1, 0.9, 0.65, false); c.restore(); c.globalAlpha = 1;
      c.font = '16px Krilessa Icons, sans-serif'; c.textAlign = 'center'; c.fillText('💫', m.x, m.y - 26 + Math.sin(m.t * 3) * 3);
      c.font = 'bold 10px Krilessa Icons, sans-serif'; c.fillStyle = '#ffffff'; c.fillText(m.rp > 0 ? 'поднимаем…' : 'подними!', m.x, m.y - 40);
      // полоска подъёма видна и той, кто поднимает
      c.lineWidth = 5; c.strokeStyle = 'rgba(0,0,0,0.45)'; c.beginPath(); c.arc(m.x, m.y - 4, 24, 0, TAU); c.stroke();
      if (m.rp > 0) { c.strokeStyle = '#7dff9a'; c.lineWidth = 4; c.beginPath(); c.arc(m.x, m.y - 4, 24, -Math.PI / 2, -Math.PI / 2 + TAU * clamp(m.rp / 100, 0, 1)); c.stroke(); }
      if (m.ar > 0) { c.font = 'bold 11px Krilessa Icons, sans-serif'; c.fillStyle = '#ff8ad8'; c.fillText(`💗 ${m.ar} с`, m.x, m.y + 34); }
    } else Renderer.drawHeroV(m.hero, c, m.x, y, m.t, m.face || 1, 1, m.away ? 0.55 : m.inv && Math.floor(m.t * 20) % 2 === 0 ? 0.5 : 1, m.mv || m.dash);
    // имя и здоровье
    const hpF = m.hpF !== undefined ? m.hpF / 100 : (m.hp || 0) / Math.max(1, m.mh || 1), nm = m.name || '';
    c.font = 'bold 10px Krilessa Icons, sans-serif'; c.textAlign = 'center';
    const emb = lk ? lookItem('em', lk.em) : null, fr = lk ? lookItem('fr', lk.fr) : null;
    const w = Math.max(34, c.measureText(nm).width + 10 + (emb ? 14 : 0)), ty = y - 46;
    c.fillStyle = 'rgba(10,6,20,0.7)'; roundRect(c, m.x - w / 2, ty - 10, w, 19, 6); c.fill();
    if (fr && fr.id !== 'wood') { c.strokeStyle = fr.col; c.lineWidth = 1.5; c.stroke(); }
    if (emb) { c.font = '10px Krilessa Icons, sans-serif'; c.fillText(emb.ic, m.x - w / 2 + 9, ty + 1); c.font = 'bold 10px Krilessa Icons, sans-serif'; }
    c.fillStyle = col; c.fillText(nm, m.x + (emb ? 7 : 0), ty + 1);
    c.fillStyle = 'rgba(0,0,0,0.5)'; c.fillRect(m.x - w / 2 + 4, ty + 4, w - 8, 3);
    c.fillStyle = hpF > 0.5 ? '#7dff7d' : hpF > 0.25 ? '#ffd25a' : '#ff5b5b'; c.fillRect(m.x - w / 2 + 4, ty + 4, (w - 8) * clamp(hpF, 0, 1), 3);
    if (m.away && !m.down) { c.font = '12px Krilessa Icons, sans-serif'; c.fillText('⏸', m.x + w / 2 + 6, ty + 2); }
  }

  return {
    MATE_EMO, mateCol, netEvent, openMP, mpRender, mpToggleReady, escHtml, mpName, mpHost,
    mpLobbyBroadcast, mpScan, backToSearch, mpJoin, mpLeave, mpGo, returnToRoom, kickListSync, netProxies, netWinterLocal,
    netLiveMates, netCoop, netXpDiv, netBan, netNear, netAnchor, netMateInCastle, netHud,
    netDown, netPearl, netTick, netAim, drawMate,
  };
})();
