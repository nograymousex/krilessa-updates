'use strict';

const LandscapeArt = (() => {
  // Painted once into terrain chunks. Geometry is in tile units so landmarks meet across seams.
  const ink = '#342f44',
    rope = '#dfc798';
  const voids = {
    1: ['#263d40', '#30494b', '#6c8474'],
    2: ['#302536','#443043','#ad795a'],
    3: ['#202b4b','#354766','#9ba6cb'],
    5: ['#333a35','#414a3b','#a1a77b'],
    4: ['#191a2b', '#222537', '#68627c'],
    6: ['#304157', '#394e65', '#a9c8d2'],
    8: ['#1a2428','#263338','#826e53'],
    7: ['#101f39', '#152c47', '#497485'],
  };
  function stroke(c, color, width, draw) {
    c.beginPath();
    draw();
    c.strokeStyle = color;
    c.lineWidth = width;
    c.stroke();
  }
  function path(c, points, color, outline, width = 0.075) {
    c.beginPath();
    c.moveTo(...points[0]);
    for (const p of points.slice(1)) c.lineTo(...p);
    c.closePath();
    c.fillStyle = color;
    c.fill();
    if (outline) {
      c.strokeStyle = outline;
      c.lineWidth = width;
      c.stroke();
    }
  }
  function line(c, x, y, xx, yy, color, width) {
    stroke(c, color, width, () => {
      c.moveTo(x, y);
      c.lineTo(xx, yy);
    });
  }
  function oval(c, x, y, rx, ry, color, rot = 0) {
    c.fillStyle = color;
    c.beginPath();
    c.ellipse(x, y, rx, ry, rot, 0, Math.PI * 2);
    c.fill();
  }
  function timber(c, half, broken = false) {
    for (let i = -half; i < half; i += 0.5) {
      if (broken && i >= -3.5 && i < 3.5) continue;
      const h = hash2(Math.round(i * 4) + 43, 7),
        edge = 1.32 + h * 0.12;
      path(
        c,
        [
          [i, -edge],
          [i + 0.47, -edge + 0.04],
          [i + 0.46, edge],
          [i + 0.02, edge - 0.02],
        ],
        ['#966942', '#af804d', '#b78d5a', '#9b744e'][Math.floor(h * 4) % 4],
        '#583f34',
        0.045
      );
      line(c, i + 0.1, -0.9, i + 0.13, 0.84, '#d1a973', 0.035);
      for (const y of [-1.08, 1.08]) oval(c, i + 0.21, y, 0.044, 0.056, '#554943');
    }
    for (const sign of [-1, 1]) {
      const y = sign * 1.29;
      for (let i = -half; i < half; i += 2) {
        const end = Math.min(i + 2, half);
        if (broken && i < 3.5 && end > -3.5) continue;
        stroke(c, '#574c46', 0.115, () => {
          c.moveTo(i, y - 0.14);
          c.quadraticCurveTo((i + end) / 2, y + 0.15, end, y - 0.14);
        });
        stroke(c, rope, 0.055, () => {
          c.moveTo(i, y - 0.18);
          c.quadraticCurveTo((i + end) / 2, y + 0.11, end, y - 0.18);
        });
      }
      for (const x of [-half, -half + 2, half - 2, half]) {
        oval(c, x + 0.1, y + 0.18, 0.21, 0.12, '#493b365e');
        c.fillStyle = '#644936';
        c.fillRect(x - 0.1, y - 0.42, 0.2, 0.64);
        oval(c, x, y - 0.4, 0.14, 0.075, '#d0ab78');
      }
      if (broken)
        for (const side of [-1, 1])
          path(
            c,
            [
              [side * 3.5, y * 0.9],
              [side * 2.92, y * 0.79],
              [side * 3.5, y * 0.55],
            ],
            '#b99467',
            '#73533f',
            0.045
          );
    }
  }
  function sofa(c) {
    oval(c, 0, 0.46, 1.63, 0.45, '#13132166');
    for (const x of [-1.1, 1.06]) {
      c.fillStyle = '#a77855';
      c.fillRect(x, 0.33, 0.17, 0.37);
    }
    path(
      c,
      [
        [-1.43, -0.82],
        [-1.23, -1.05],
        [1.24, -1.05],
        [1.43, -0.82],
        [1.4, 0.35],
        [-1.4, 0.35],
      ],
      '#81536f',
      ink
    );
    for (const x of [-0.93, 0.03]) {
      path(
        c,
        [
          [x, -0.57],
          [x + 0.88, -0.57],
          [x + 0.92, 0.08],
          [x - 0.04, 0.08],
        ],
        '#b77a8a',
        '#6b455c'
      );
      line(c, x + 0.08, -0.49, x + 0.77, -0.49, '#edbcaf', 0.035);
    }
    for (const x of [-1.43, 1.12]) {
      c.fillStyle = '#cd91a0';
      c.fillRect(x, -0.6, 0.31, 0.89);
    }
    oval(c, 0, 0.36, 0.53, 0.18, '#211c30');
    for (const x of [-0.16, 0.15]) oval(c, x, 0.32, 0.048, 0.05, '#f6d592');
    for (let i = 0; i < 3; i++) oval(c, ((i % 2) - 0.5) * 0.22, 0.7 + i * 0.22, 0.06, 0.09, '#d2ad94', 0.3);
  }
  function stove(c) {
    path(
      c,
      [
        [-1.35, -0.9],
        [1.35, -0.9],
        [1.35, 0.98],
        [-1.35, 0.98],
      ],
      '#749293',
      ink
    );
    path(
      c,
      [
        [-1.33, -1.08],
        [1.33, -1.08],
        [1.29, 0.03],
        [-1.29, 0.03],
      ],
      '#c1c3a5',
      ink
    );
    for (const x of [-0.69, 0.69]) {
      oval(c, x, -0.49, 0.4, 0.29, '#444957');
      oval(c, x, -0.49, 0.29, 0.2, '#c68763');
      oval(c, x, -0.49, 0.18, 0.13, '#4b4e59');
    }
    path(
      c,
      [
        [-0.96, 0.31],
        [0.96, 0.31],
        [0.96, 0.77],
        [-0.96, 0.77],
      ],
      '#344452',
      '#dbbd8f'
    );
    line(c, -0.91, 0.15, 0.91, 0.15, '#e4cda9', 0.09);
  }
  function rug(c) {
    c.save();
    c.scale(1, 0.72);
    for (const [r, color] of [
      [3.6, '#5e354f'],
      [3.45, '#c38e76'],
      [3.32, '#6f425b'],
      [3, '#945f70'],
    ]) {
      path(
        c,
        [
          [-r, 0],
          [-r * 0.76, -r * 0.65],
          [0, -r],
          [r * 0.76, -r * 0.65],
          [r, 0],
          [r * 0.75, r * 0.65],
          [0, r],
          [-r * 0.75, r * 0.65],
        ],
        color
      );
    }
    for (let i = 0; i < 8; i++) {
      c.rotate(Math.PI / 4);
      path(
        c,
        [
          [0, -2.5],
          [0.25, -1.6],
          [0, -0.95],
          [-0.25, -1.6],
        ],
        '#dcb38d'
      );
    }
    c.restore();
  }
  function summit(c) {
    path(
      c,
      [
        [-0.83, 0.49],
        [0.77, 0.51],
        [0.53, 0.15],
        [-0.44, 0.1],
      ],
      '#67768a',
      '#425369'
    );
    line(c, 0, 0.27, 0, -1.82, '#634634', 0.12);
    path(
      c,
      [
        [0, -1.79],
        [1.13, -1.49],
        [0.77, -1.28],
        [0.98, -1.05],
        [0, -1.22],
      ],
      '#b9514c',
      '#743e45'
    );
    line(c, 0.16, -1.63, 0.67, -1.48, '#f3ce89', 0.06);
  }
  function wreck(c) {
    const hull = new Path2D(
      'M -10 0 Q -8.9 -3 -5.2 -3.1 L 5.5 -3.1 Q 9 -2.5 11 0 Q 8.9 2.8 5.3 3.1 L -5.6 3.1 Q -9 2.5 -10 0 Z'
    );
    c.fillStyle = '#584c4d';
    c.fill(hull);
    c.strokeStyle = '#322f3f';
    c.lineWidth = 0.24;
    c.stroke(hull);
    c.save();
    c.clip(hull);
    for (let i = -6; i < 6; i++) {
      const y = i * 0.54;
      c.fillStyle = ['#927457', '#89694f', '#a0815e'][(i + 6) % 3];
      c.fillRect(-10, y, 21, 0.49);
      for (let x = -9 + (i % 3) * 1.1; x < 10; x += 3.4) {
        line(c, x, y, x, y + 0.49, '#55483d', 0.05);
        oval(c, x + 0.14, y + 0.19, 0.035, 0.037, '#d3b17c');
      }
    }
    for (const side of [-1, 1])
      for (let i = -6; i <= 6; i += 2) {
        const y = side * (2.9 - 0.015 * i * i);
        path(
          c,
          [
            [i - 0.14, y],
            [i + 0.09, y],
            [i + 0.18, y - side * 0.47],
            [i + 0.05, y - side * 0.71],
          ],
          '#483e40'
        );
      }
    c.restore();
    for (const x of [-5, 2.6]) {
      oval(c, x, 0, 0.55, 0.35, '#4b4141');
      oval(c, x, 0, 0.34, 0.22, '#cbad7c');
      line(c, x, 0, x + 1.9, -1.6, '#dbc49b', 0.06);
    }
    for (let i = 0; i < 4; i++) line(c, 6.25 + i * 0.19, -1.65, 6.25 + i * 0.19, 1.65, '#d1ae78', 0.14);
  }
  function paw(c) {
    oval(c, 0, 0.05, 0.18, 0.15, '#627f92');
    for (const [x, y] of [
      [-0.18, -0.06],
      [-0.08, -0.19],
      [0.07, -0.2],
      [0.18, -0.09],
    ])
      oval(c, x, y, 0.065, 0.1, '#7897a8', x);
  }
  function marks(c, bx, by, w, h) {
    const site = World.landscape;
    if (!site) return;
    const visible = (x, y, r) => x + r >= bx && x - r <= bx + w && y + r >= by && y - r <= by + h;
    c.save();
    c.scale(World.T, World.T);
    c.translate(0.5 - bx, 0.5 - by);
    for (const [kind, x, y] of site.plan.marks) {
      if (!visible(x, y, 12)) continue;
      c.save();
      c.translate(x, y);
      if (kind === 'bridge' || kind === 'broken') timber(c, 7.5, kind === 'broken' && !site.bridgeOpen);
      else if (kind === 'kiln') {
        oval(c,0,0,2.2,1.1,'#42353e'); path(c,[[-1.7,0],[-1.25,-2.4],[-.7,-3.5],[.8,-3.5],[1.55,0]],'#876853',ink);
        oval(c,0,-.55,.6,.46,'#ffbb66'); line(c,-.9,-2.65,.95,-2.65,'#c99b72',.18);
      } else if (kind === 'pylon' || kind === 'facet') {
        const glass=kind==='facet'; oval(c,0,0,1.8,.7,'#33314488');
        path(c,[[-1,.1],[-.8,-1.7],[.2,-3.3],[1,-1.4],[.7,0]],glass?'#8ea6cd':'#87627e',ink);
        path(c,[[.2,-3.3],[.3,-.7],[-1,.1],[-.8,-1.7]],glass?'#c7e5f0':'#dfbe84');
      } else if (kind === 'glasshouse') {
        path(c,[[-2,0],[-2,-1.6],[0,-3],[2,-1.6],[2,0]],'#81aaa2','#475e52',.15);
        for (const dx of [-1,0,1]) line(c,dx,-3+Math.abs(dx)*.7,dx,0,'#ecdab2',.08);
        line(c,-2,-1.4,2,-1.4,'#ecdab2',.1);
      } else if (kind === 'sofa') sofa(c);
      else if (kind === 'stove') stove(c);
      else if (kind === 'rug') rug(c);
      else if (kind === 'summit') summit(c);
      else if (kind === 'wreck') wreck(c);
      c.restore();
    }
    if (site.plan.tracks) {
      let step = 0;
      Landscapes.walkLine(site.plan.tracks, (x, y) => {
        step++;
        if (!visible(x, y, 1) || step % 2 === 0) return;
        c.save();
        c.translate(x, y + (step % 4 === 1 ? 0.22 : -0.22));
        c.rotate(1.92);
        paw(c);
        c.restore();
      });
    }
    c.restore();
  }
  function voidTile(c, tx, ty, x, y) {
    const site = World.landscape,
      w = World.MW;
    if (!site || ty >= World.PLAY_H || site.mask[ty * w + tx] !== Landscapes.OUT || World.tileAt(tx, ty) !== ROCK)
      return false;
    const [dark, mid, edge] = voids[World.CHN],
      t = World.T,
      a = hash2(tx >> 2, ty >> 2);
    c.fillStyle = dark;
    c.fillRect(x, y, t, t);
    if (World.CHN !== 4) {
      const wave = Math.sin(tx * 0.31 + ty * 0.74) * 4;
      stroke(c, mid, 1.2, () => {
        c.moveTo(x, y + 16 + wave);
        c.quadraticCurveTo(x + t * 0.52, y + 24 + wave, x + t, y + 16 + Math.sin((tx + 1) * 0.31 + ty * 0.74) * 4);
      });
      if (a > 0.75) oval(c, x + 11, y + 29, 1.8, 0.9, mid);
    }
    for (const [dx, dy, x1, y1, x2, y2] of [
      [0, -1, 0, 0, t, 0],
      [0, 1, 0, t, t, t],
      [-1, 0, 0, 0, 0, t],
      [1, 0, t, 0, t, t],
    ]) {
      const nx = tx + dx,
        ny = ty + dy;
      if (nx < 0 || ny < 0 || nx >= w || ny >= World.PLAY_H || !site.mask[ny * w + nx]) continue;
      line(c, x + x1, y + y1, x + x2, y + y2, edge, 4);
    }
    return true;
  }
  // The ground pass already painted the room or biome below. Keep its material under footsteps.
  function surface(c, tx, ty, x, y, tile) {
    const site = World.landscape,
      kind = site.mask[ty * World.MW + tx],
      T = World.T;
    if (ty >= World.PLAY_H) return false;
    if ((kind === Landscapes.RIVER || kind === Landscapes.BREAK) && tile === WATER) {
      const phase = 0.29 * tx + 0.16 * ty,
        sh = Math.sin(phase) * 2.6;
      c.fillStyle = '#3c7587';
      c.fillRect(x, y, T, T);
      for (const [offset, col] of [
        [9, '#548d99'],
        [25, '#498391'],
      ]) {
        stroke(c, col, 1.5, () => {
          c.moveTo(x, y + offset + sh);
          c.bezierCurveTo(
            x + 13,
            y + offset + sh + 3,
            x + 24,
            y + offset - 1,
            x + T,
            y + offset + Math.sin(phase + 0.29) * 2.6
          );
        });
      }
      for (const dx of [-1, 1]) {
        const n = site.mask[ty * World.MW + tx + dx];
        if (n !== Landscapes.LAND) continue;
        const xx = x + (dx < 0 ? 1 : T - 1);
        line(c, xx, y, xx, y + T, '#b5c4a3', 3);
        line(c, xx - dx * 4, y + 5, xx - dx * 4, y + T - 9, '#89b5ab', 1.5);
      }
      return true;
    }
    if (tile !== PATH) return false;
    const detail = hash2(tx * 3 + 1, ty * 7 + 4);
    if (World.CHN === 4) {
      // Doorways retain the parquet, checkerboard or carpet of the room on either side.
      if (detail < 0.2) {
        oval(c, x + 14, y + 17, 1.6, 2.1, '#c2ac8d55', -0.45);
        oval(c, x + 21, y + 13, 1.5, 1.9, '#c2ac8d44', -0.4);
      }
      return true;
    }
    if (World.CHN === 6 || World.CHN === 7) {
      const snow = World.CHN === 6;
      c.fillStyle = snow ? 'rgba(210,229,236,0.72)' : 'rgba(192,173,148,0.17)';
      c.fillRect(x, y, T, T);
      if (snow && detail < 0.24) {
        oval(c, x + 11, y + 17, 2.3, 4, '#839fac88', 0.48);
        oval(c, x + 20, y + 9, 2.2, 3.9, '#839fac7a', 0.4);
      } else if (!snow && detail < 0.48) {
        stroke(c, '#bad6bf77', 1.2, () => {
          c.moveTo(x + 7, y + 24);
          c.quadraticCurveTo(x + 16, y + 20, x + 28, y + 22);
        });
      }
      return true;
    }
    return false;
  }
  function chartRoutes(c) {
    const { plan } = World.landscape;
    c.save();
    c.lineJoin = 'round';
    c.lineCap = 'round';
    for (const route of plan.paths) {
      if (!route.length) continue;
      c.beginPath();
      c.moveTo(route[0][0] + 0.5, route[0][1] + 0.5);
      for (const [x, y] of route.slice(1)) c.lineTo(x + 0.5, y + 0.5);
      c.strokeStyle =
        World.CHN === 7 ? '#69b2bb' : World.CHN === 6 ? '#6d8290' : World.CHN === 4 ? '#b99a72' : '#d5ad75';
      c.lineWidth = World.CHN === 4 ? 0.8 : 1.2;
      c.stroke();
    }
    c.restore();
  }
  function bridgeSignal(c,x,y,half,broken,t,color) {
    c.save();c.translate(x,y);c.scale(World.T,World.T);
    if(broken){
      c.lineWidth=.08;c.strokeStyle='#e7c18e';c.beginPath();c.moveTo(-3.8,-1.25);c.quadraticCurveTo(-2,.9+Math.sin(t*1.7)*.2,-.6,.63);c.stroke();
      for(let n=0;n<2;n++){const phase=(t*.42+n*.5)%1;c.globalAlpha=1-phase;c.strokeStyle='#d6f1df';c.beginPath();c.ellipse(-.6,.68,.36+phase*1.25,.12+phase*.4,0,0,TAU);c.stroke();}
    } else for(const dir of [-1,1]){
      const gx=-dir*(half-.65), flutter=Math.sin(t*3.8+dir)*.17;
      line(c,gx,-1,gx,-2.65,'#3f3540',.13);line(c,gx-.025,-1,gx-.025,-2.65,'#dfc39a',.045);
      path(c,[[gx,-2.6],[gx+dir*.66,-2.54+flutter],[gx+dir*1.33,-2.36+flutter],[gx+dir*.64,-2.16+flutter],[gx,-2.16]],color,'#4b3f44',.05);
    } c.restore();
  }
  function valleyBridges(c,vis) {
    if(!World.landscape || !World.landscape.plan.crossings) return;
    for(const [kind,tx,ty] of World.landscape.plan.marks){
      if(kind!=='bridge' && kind!=='broken') continue;
      const x=World.tc(tx),y=World.tc(ty);if(vis(x,y,World.T*9)) bridgeSignal(c,x,y,7.5,kind==='broken'&&!World.landscape.bridgeOpen,G.time,'#e5ae63');
    }
  }
  function mapLabels(c, X, Y, zoom) {
    const site = World.landscape;
    if (!site) return;
    c.save();
    c.font = '600 ' + (zoom < 1.35 ? 10 : 12) + 'px sans-serif';
    c.textAlign = 'center';
    c.textBaseline = 'middle';
    for (const [label, tx, ty] of site.plan.labels) {
      const x = X(World.tc(tx)),
        y = Y(World.tc(ty));
      c.lineWidth = 3;
      c.strokeStyle = '#172334';
      c.strokeText(label, x, y);
      c.fillStyle = '#fff0cb';
      c.fillText(label, x, y);
    }
    c.restore();
  }
  return { valleyBridges, bridgeSignal, marks, voidTile, voids, timber, mapLabels, surface, chartRoutes };
})();
