'use strict';

const Renderer = (() => {
  // ------------------------------------------------------------------
  //  Рендер
  // ------------------------------------------------------------------
  function drawCage(c, x, y, open, t) {
    shadow(c, x, y + 32, 40, 10);
    const bob = Math.sin(t * 2) * 3 - open * 14;
    const R = 26 + open * 16;
    if (World.CFG.hostage === 'krilessa') {
      if (open > 0) { c.fillStyle = `rgba(255,210,90,${open * 0.35})`; c.beginPath(); c.arc(x, y - 6 + bob, R + 14, 0, TAU); c.fill(); }
      drawKrilessa(c, x, y + 16 + bob, t, 1, 1.6 + open * 0.4, 1, open > 0);
    } else if (ART.ryzhovaSmall) {
      if (open > 0) { c.fillStyle = `rgba(255,210,90,${open * 0.35})`; c.beginPath(); c.arc(x, y - 6 + bob, R + 14, 0, TAU); c.fill(); }
      c.save(); c.beginPath(); c.arc(x, y - 6 + bob, R, 0, TAU); c.clip();
      c.drawImage(ART.ryzhovaSmall, x - R, y - 6 - R + bob, R * 2, R * 2); c.restore();
      c.strokeStyle = '#ff7a2f'; c.lineWidth = 3; c.beginPath(); c.arc(x, y - 6 + bob, R, 0, TAU); c.stroke();
    }
    const lift = open * 90;
    c.globalAlpha = 1 - open * 0.8;
    const gold = World.CHN === 2 ? '#ff3ea5' : World.CHN === 3 ? '#bfeaff' : '#ffd25a', dark = World.CHN === 2 ? '#a0206a' : World.CHN === 3 ? '#6a8ab8' : '#d9a520';
    c.fillStyle = '#7a5a1a'; c.beginPath(); c.ellipse(x, y + 28, 38, 9, 0, 0, TAU); c.fill();
    c.fillStyle = gold; c.beginPath(); c.ellipse(x, y + 25, 38, 8, 0, 0, TAU); c.fill();
    c.strokeStyle = dark; c.lineWidth = 3;
    for (let i = 0; i < 7; i++) { const bx = x - 33 + i * 11; c.beginPath(); c.moveTo(bx, y + 25 - lift); c.lineTo(bx, y - 38 - lift); c.stroke(); }
    c.lineWidth = 4;
    c.beginPath(); c.ellipse(x, y - 38 - lift, 34, 12, 0, Math.PI, TAU); c.stroke();
    c.beginPath(); c.moveTo(x - 34, y - 38 - lift); c.lineTo(x + 34, y - 38 - lift); c.stroke();
    c.fillStyle = gold; c.beginPath(); c.arc(x, y - 52 - lift, 5, 0, TAU); c.fill();
    c.globalAlpha = 1;
  }
  // ------------------------------------------------------------------
  //  Объём: освещение «запекается» один раз на вид спрайта и направление взгляда,
  //  а каждый кадр накладывается поверх живой анимации (только на сам спрайт).
  // ------------------------------------------------------------------
  // без объёма: полупрозрачные свечения, пиксельные и «глючные» мобы, герои-фото
  const VOL_SKIP = new Set(['fan', 'tv', 'zyamabot', 'wisp', 'shade', 'frostwisp', 'glitchbug', 'errorwin', 'pixel', 'eyes', 'staticball', 'bitfly', 'reflection', 'zyama', 'zyama2', 'zyamaInf', 'zmirror']);
  const VOL = new Map(); let volArea = 0, volOn = true;
  const VOL_MAX_AREA = 6e6; // ~24 МБ на всё
  const volCv = makeCanvas(256, 256), vx = volCv.getContext('2d');
  function volBlur(a, w, h, r) {
    const o = new Float32Array(a.length), t = new Float32Array(a.length), k = 1 / (2 * r + 1);
    for (let y = 0; y < h; y++) {
      const row = y * w; let sum = 0;
      for (let x = -r; x <= r; x++) sum += a[row + Math.min(w - 1, Math.max(0, x))];
      for (let x = 0; x < w; x++) { t[row + x] = sum * k; sum += a[row + Math.min(w - 1, x + r + 1)] - a[row + Math.max(0, x - r)]; }
    }
    for (let x = 0; x < w; x++) {
      let sum = 0;
      for (let y = -r; y <= r; y++) sum += t[Math.min(h - 1, Math.max(0, y)) * w + x];
      for (let y = 0; y < h; y++) { o[y * w + x] = sum * k; sum += t[Math.min(h - 1, y + r + 1) * w + x] - t[Math.max(0, y - r) * w + x]; }
    }
    return o;
  }
  function bakeVolume(half, bakeFn, BS, core) {
    const n = Math.ceil(half * 2 * BS), cv = makeCanvas(n, n), x = cv.getContext('2d');
    x.setTransform(BS, 0, 0, BS, n / 2, n / 2); x.save(); bakeFn(x); x.restore();
    const d = x.getImageData(0, 0, n, n).data, N = n * n;
    const A = new Float32Array(N), Lm = new Float32Array(N);
    for (let i = 0; i < N; i++) {
      const a = d[i * 4 + 3] / 255, sa = clamp((a - 0.45) / 0.4, 0, 1); // полупрозрачное (свечения) не считаем телом
      A[i] = sa; Lm[i] = sa * (0.3 * d[i * 4] + 0.59 * d[i * 4 + 1] + 0.11 * d[i * 4 + 2]) / 255;
    }
    const R = Math.max(3, Math.round(n * 0.035));
    const Hm = volBlur(volBlur(volBlur(A, n, n, R), n, n, R), n, n, R), D = volBlur(volBlur(Lm, n, n, 2), n, n, 2);
    const ln = Math.hypot(-0.55, -0.65, 0.52), lx = -0.55 / ln, ly = -0.65 / ln, lz = 0.52 / ln, hn = Math.hypot(lx, ly, lz + 1);
    const out = x.createImageData(n, n), o = out.data, gk = 9 * 120 / n;
    // «ядро» для мобов: освещение только внутри тела, мягко гаснет к краям – тогда его можно
    // класть прямо поверх живого спрайта, и шевелящиеся края не пачкают землю
    const Cm = core ? volBlur(volBlur(A, n, n, Math.max(2, Math.round(n * 0.05))), n, n, Math.max(2, Math.round(n * 0.05))) : null;
    for (let y = 1; y < n - 1; y++) for (let xx = 1; xx < n - 1; xx++) {
      const i = y * n + xx; if (A[i] < 0.02) continue;
      const gx = (Hm[i + 1] - Hm[i - 1]) * gk * 10 + (D[i + 1] - D[i - 1]) * 1.4, gy = (Hm[i + n] - Hm[i - n]) * gk * 10 + (D[i + n] - D[i - n]) * 1.4;
      let nx = -gx, ny = -gy, nz = 1; const nl = Math.hypot(nx, ny, nz); nx /= nl; ny /= nl; nz /= nl;
      const dif = Math.max(0, nx * lx + ny * ly + nz * lz), spec = Math.pow(Math.max(0, (nx * lx + ny * ly + nz * (lz + 1)) / hn), 28);
      const rim = Math.pow(1 - nz, 1.6) * Math.max(0, -(nx * lx + ny * ly));
      const kf = (0.42 + 0.85 * dif) * (0.7 + 0.3 * Math.min(1, Hm[i] * 1.5));
      // свет/тень одним слоем: темнее – чёрным, светлее – белым; сверху блик и голубая кромка
      let r0, g0, b0, a0;
      if (kf < 1) { r0 = g0 = b0 = 0; a0 = (1 - kf) * 0.9; } else { r0 = g0 = b0 = 255; a0 = Math.min(0.45, (kf - 1) * 0.6); }
      const lay = (r, g, b, al) => { const na = al + a0 * (1 - al); if (na <= 0) return; r0 = (r * al + r0 * a0 * (1 - al)) / na; g0 = (g * al + g0 * a0 * (1 - al)) / na; b0 = (b * al + b0 * a0 * (1 - al)) / na; a0 = na; };
      lay(255, 255, 255, Math.min(0.8, spec * 0.75));
      lay(150, 215, 255, Math.min(0.6, rim * 0.6));
      const cm = core ? clamp((Cm[i] - 0.62) / 0.3, 0, 1) : 1;
      o[i * 4] = r0; o[i * 4 + 1] = g0; o[i * 4 + 2] = b0; o[i * 4 + 3] = Math.round(a0 * A[i] * cm * 255);
    }
    x.setTransform(1, 0, 0, 1, 0, 0); x.clearRect(0, 0, n, n); x.putImageData(out, 0, 0);
    if (!core) return cv;
    // обрезаем по непрозрачной части – меньше копировать каждый кадр
    let x0 = n, y0 = n, x1 = -1, y1 = -1;
    for (let y = 0; y < n; y++) for (let xx = 0; xx < n; xx++) if (o[(y * n + xx) * 4 + 3] > 3) { if (xx < x0) x0 = xx; if (xx > x1) x1 = xx; if (y < y0) y0 = y; if (y > y1) y1 = y; }
    if (x1 < 0) return null;
    const cw = x1 - x0 + 1, chh = y1 - y0 + 1, crop = makeCanvas(cw, chh);
    crop.getContext('2d').drawImage(cv, x0, y0, cw, chh, 0, 0, cw, chh);
    crop.ox = x0 / BS - half; crop.oy = y0 / BS - half; crop.w = cw / BS; crop.h = chh / BS;
    return crop;
  }
  function getVol(key, half, bakeFn, BS, core) {
    let ov = VOL.get(key);
    if (ov !== undefined) { VOL.delete(key); VOL.set(key, ov); return ov; } // недавно использованные – в конец
    try { ov = bakeVolume(half, bakeFn, BS, core); } catch (err) { ov = null; }
    VOL.set(key, ov);
    if (ov) volArea += ov.width * ov.height;
    while (volArea > VOL_MAX_AREA && VOL.size > 1) { const [k0, v0] = VOL.entries().next().value; VOL.delete(k0); if (v0) volArea -= v0.width * v0.height; }
    return ov;
  }
  // мобы: спрайт как раньше + одна картинка освещения сверху (дёшево, их много на экране)
  function drawVolCore(c, key, half, drawFn, bakeFn) {
    drawFn(c);
    if (!volOn) return;
    const ov = getVol(key, half, bakeFn, 2, true);
    if (ov) c.drawImage(ov, ov.ox, ov.oy, ov.w, ov.h);
  }
  // боссы: полный объём через отдельный холст (босс на экране один)
  function drawVol(c, key, half, drawFn, bakeFn, BS = 2) {
    if (!volOn) { drawFn(c); return; }
    const ov = getVol(key, half, bakeFn, BS);
    const m = c.getTransform(), ps = Math.hypot(m.a, m.b), px = Math.ceil(half * 2 * ps);
    if (!ov || px < 6 || px > 900) { drawFn(c); return; }
    if (volCv.width < px) { volCv.width = volCv.height = Math.min(960, Math.ceil(px * 1.15)); }
    vx.setTransform(1, 0, 0, 1, 0, 0); vx.globalCompositeOperation = 'source-over'; vx.globalAlpha = 1; vx.clearRect(0, 0, px, px);
    vx.save(); vx.setTransform(ps, 0, 0, ps, px / 2, px / 2); drawFn(vx); vx.restore();
    vx.globalCompositeOperation = 'source-atop'; vx.globalAlpha = 1; vx.drawImage(ov, 0, 0, ov.width, ov.height, 0, 0, px, px);
    vx.globalCompositeOperation = 'source-over';
    c.drawImage(volCv, 0, 0, px, px, -half, -half, half * 2, half * 2);
  }
  // героини: на маленьких фигурках автоматический объём делает лица тусклыми,
  // поэтому у них ручная доводка (градиенты, блики) прямо в спрайтах, а объём – выключен
  const HERO_VOL = false;
  function drawHeroV(id, c, x, y, t, face, s, alpha, moving) {
    if (!HERO_VOL || !volOn || id === 'ryzhovaya') { drawHero(id, c, x, y, t, face, s, alpha, moving); return; }
    c.save(); c.translate(x, y); c.scale(s, s); c.globalAlpha *= alpha;
    const out = id === 'tessa' ? TESSA_OUTFIT : '';
    drawVol(c, 'H|' + id + '|' + face + '|' + out, 34, cc => drawHero(id, cc, 0, 0, t, face, 1, 1, moving), xx => drawHero(id, xx, 0, 0, 0.3, face, 1, 1, false), 3);
    c.restore();
  }
  function drawBoss(c, b) {
    if (World.landscape && b.kind === 'angler' && b.state === 'sleep') return;
    const t = b.anim;
    shadow(c, b.x, b.y + b.r * 0.75, b.r * 0.9 * (1 - Math.min(0.5, b.z / 260)), b.r * 0.28);
    c.save();
    const sx = b.mode === 'trans' ? Math.sin(t * 50) * 4 : 0;
    c.translate(b.x + sx, b.y - b.z);
    c.globalAlpha = b.alpha;
    if (b.state==='fight') CombatCues.posture(c,b);
    const bsp = b.def.sprite || b.kind, face = P.x > b.x ? 1 : -1;
    if (VOL_SKIP.has(bsp)) BSPR[bsp](c, b, t, face);
    else {
      const flipK = Math.cos(b.look || 0) < 0 ? 1 : 0;
      drawVol(c, 'B|' + bsp + '|' + face + '|' + flipK + '|' + (b.stage >= 2 ? 1 : 0), b.r * 2.3, cc => BSPR[bsp](cc, b, t, face), xx => {
        const fl = b.flash; b.flash = 0; try { BSPR[bsp](xx, b, 0.3, face); } finally { b.flash = fl; }
      }, 1.5);
    }
    c.restore();
    if (b.kind === 'zyama2' || b.kind === 'zyamaInf') {
      const inf = b.kind === 'zyamaInf';
      c.save(); c.translate(b.x + 30, b.y - b.z - 74 + (inf ? Math.sin(t * 4) * 3 : 0)); c.rotate(inf ? Math.sin(t * 2) * 0.25 : 0.2);
      c.fillStyle = inf ? RAINBOW[Math.floor(t * 6) % RAINBOW.length] : '#ff3ea5'; roundRect(c, -16, -10, 32, 20, 6); c.fill();
      c.fillStyle = '#fff'; c.font = inf ? '900 18px Krilessa Icons, sans-serif' : '900 13px Krilessa Icons, sans-serif'; c.textAlign = 'center'; c.fillText(inf ? '∞' : '2.0', 0, inf ? 6 : 5);
      c.restore();
    }
    if (b.shield) {
      const g = 0.5 + Math.sin(t * 6) * 0.3;
      c.strokeStyle = `rgba(191,234,255,${0.6 + g * 0.3})`; c.lineWidth = 5;
      c.fillStyle = `rgba(191,234,255,${0.12 + g * 0.08})`;
      c.beginPath(); c.arc(b.x, b.y - b.z - 10, b.r + 26, 0, TAU); c.fill(); c.stroke();
    }
    if (b.stunT > 0) {
      for (let k = 0; k < 3; k++) { const a = t * 4 + k * TAU / 3; c.fillStyle = '#ffe04a'; star(c, b.x + Math.cos(a) * 30, b.y - b.r - 30 + Math.sin(a) * 8, 7, t); c.fill(); }
    }
    if (b.burnT > 0 && Math.random() < 0.4) Effects.part(b.x + rnd(-b.r, b.r), b.y + rnd(-b.r, b.r * 0.5), 0, -60, 0.5, 5, '#ff8a2a');
    if (b.mode === 'trans') {
      c.strokeStyle = `rgba(255,255,255,${0.4 + Math.sin(t * 20) * 0.3})`; c.lineWidth = 4;
      c.beginPath(); c.arc(b.x, b.y - b.z, b.r + 18 + Math.sin(t * 10) * 4, 0, TAU); c.stroke();
    }
  }
  const FX_COL = { dark: '199,125,255', crystal: '91,227,255', honey: '255,200,40', lava: '255,100,30', glitch: '63,240,160',
    bolt: '255,240,120', toxic: '110,255,60', rainbow: '255,120,220', cream: '255,255,255', meteor: '255,120,30' };
  function drawHazard(c, h) {
    if (h.kind === 'wavewarn') { // где будут проходы: зелёные дорожки от босса
      const a = 0.35 + 0.25 * Math.sin(h.t * 22), k = clamp(h.t / 0.25, 0, 1);
      for (const g of h.gaps) {
        c.fillStyle = `rgba(110,255,160,${0.26 * k})`;
        c.beginPath(); c.moveTo(h.x, h.y); c.arc(h.x, h.y, 520 * k, g - h.half, g + h.half); c.closePath(); c.fill();
        c.strokeStyle = `rgba(170,255,200,${(a + 0.25) * k})`; c.lineWidth = 4; c.setLineDash([14, 9]);
        for (const e of [-1, 1]) { c.beginPath(); c.moveTo(h.x + Math.cos(g + e * h.half) * 40, h.y + Math.sin(g + e * h.half) * 40); c.lineTo(h.x + Math.cos(g + e * h.half) * 520 * k, h.y + Math.sin(g + e * h.half) * 520 * k); c.stroke(); }
        c.setLineDash([]);
        for (let r = 90; r < 520 * k; r += 110) { // стрелки «сюда»
          const x = h.x + Math.cos(g) * r, y = h.y + Math.sin(g) * r;
          c.save(); c.translate(x, y); c.rotate(g); c.fillStyle = `rgba(200,255,215,${a * k})`;
          c.beginPath(); c.moveTo(10, 0); c.lineTo(-6, -8); c.lineTo(-2, 0); c.lineTo(-6, 8); c.closePath(); c.fill(); c.restore();
        }
      }
      return;
    }
    if (h.kind === 'wave') { // кольцо с проходами
      const gs = h.gaps ? h.gaps.slice().sort((x, y) => x - y) : null;
      const arcs = [];
      if (!gs) arcs.push([0, TAU]);
      else for (let i = 0; i < gs.length; i++) arcs.push([gs[i] + h.half, (i + 1 < gs.length ? gs[i + 1] : gs[0] + TAU) - h.half]);
      c.lineCap = 'round';
      c.strokeStyle = 'rgba(255,80,60,0.85)'; c.lineWidth = h.thick;
      for (const [a0, a1] of arcs) { c.beginPath(); c.arc(h.x, h.y, h.r, a0, a1); c.stroke(); }
      c.strokeStyle = 'rgba(255,230,180,0.9)'; c.lineWidth = 3;
      for (const [a0, a1] of arcs) { c.beginPath(); c.arc(h.x, h.y, h.r, a0, a1); c.stroke(); }
      c.lineCap = 'butt';
      if (gs) for (const g of gs) { // проход подсвечен зелёным
        c.strokeStyle = 'rgba(120,255,170,0.35)'; c.lineWidth = h.thick * 0.6;
        c.beginPath(); c.arc(h.x, h.y, h.r, g - h.half * 0.8, g + h.half * 0.8); c.stroke();
      }
      return;
    }
    if (h.kind === 'zone') {
      const a = clamp(h.t / 0.4, 0, 1) * clamp((h.delay + h.dur - h.t) / 0.5, 0, 1);
      const col = FX_COL[h.fx] || '255,200,40';
      c.fillStyle = `rgba(${col},${0.32 * a})`; c.beginPath(); c.arc(h.x, h.y, h.r, 0, TAU); c.fill();
      c.strokeStyle = `rgba(${col},${0.7 * a})`; c.lineWidth = 2; c.stroke();
      return;
    }
    const k = clamp(h.t / h.delay, 0, 1);
    const col = FX_COL[h.fx] || '255,40,40';
    if (!h.done) {
      c.fillStyle = `rgba(${col},0.18)`; c.strokeStyle = `rgba(${col},0.85)`; c.lineWidth = 2;
      if (h.kind === 'circle') {
        c.beginPath(); c.arc(h.x, h.y, h.r, 0, TAU); c.fill(); c.stroke();
        c.fillStyle = `rgba(${col},0.32)`; c.beginPath(); c.arc(h.x, h.y, h.r * k, 0, TAU); c.fill();
        if (h.fx === 'meteor') { const fx = h.x + 230 * (1 - k), fy = h.y - 330 * (1 - k); drawFireball(c, fx, fy, Math.atan2(330, -230), 2.4); }
        if (h.fx === 'icicle' || h.fx === 'rain') { c.fillStyle = '#e6fbff'; c.beginPath(); c.moveTo(h.x - 7, h.y - 260 * (1 - k) - 30); c.lineTo(h.x + 7, h.y - 260 * (1 - k) - 30); c.lineTo(h.x, h.y - 260 * (1 - k)); c.fill(); }
      } else {
        c.save(); c.translate(h.x, h.y); c.rotate(h.ang);
        c.fillRect(0, -h.w / 2, h.len, h.w); c.strokeRect(0, -h.w / 2, h.len, h.w);
        c.fillStyle = `rgba(${col},0.32)`; c.fillRect(0, -h.w / 2, h.len * k, h.w);
        c.restore();
      }
    } else if (h.fx === 'tongue') {
      const a = 1 - (h.t - h.delay) / 0.3;
      c.save(); c.translate(h.x, h.y); c.rotate(h.ang); c.globalAlpha = clamp(a, 0, 1);
      c.fillStyle = '#ff6f91'; c.fillRect(0, -9, h.len, 18);
      c.beginPath(); c.arc(h.len, 0, 14, 0, TAU); c.fill(); c.restore();
    } else if (h.kind === 'line') {
      const a = clamp(1 - (h.t - h.delay) / 0.3, 0, 1);
      c.save(); c.translate(h.x, h.y); c.rotate(h.ang);
      c.fillStyle = `rgba(255,255,255,${a * 0.8})`; c.fillRect(0, -h.w / 2, h.len, h.w); c.restore();
    } else if (h.kind === 'circle') {
      const a = 1 - (h.t - h.delay) / 0.3;
      c.strokeStyle = `rgba(255,255,255,${clamp(a, 0, 1) * 0.8})`; c.lineWidth = 4;
      c.beginPath(); c.arc(h.x, h.y, h.r * (1 + (1 - a) * 0.3), 0, TAU); c.stroke();
    }
  }
  function drawBeam(c, bm) {
    if (bm.x === undefined) return;
    const ca = Math.cos(bm.ang), sa = Math.sin(bm.ang);
    if (bm.t < bm.warm) {
      c.strokeStyle = `rgba(255,60,60,${0.4 + Math.sin(bm.t * 30) * 0.3})`; c.lineWidth = 2;
      c.setLineDash([10, 8]); c.beginPath(); c.moveTo(bm.x, bm.y); c.lineTo(bm.x + ca * 560, bm.y + sa * 560); c.stroke(); c.setLineDash([]);
      return;
    }
    const col = bm.rainbow ? RAINBOW[Math.floor(bm.t * 10) % 7] : bm.mouth ? '#3ff0ff' : '#ff3ea5';
    c.lineCap = 'round';
    c.beginPath(); c.moveTo(bm.x, bm.y); c.lineTo(bm.x + ca * bm.len, bm.y + sa * bm.len);
    c.strokeStyle = col; c.globalAlpha = 0.35; c.lineWidth = bm.w * 1.6; c.stroke();
    c.globalAlpha = 1; c.lineWidth = bm.w * 0.7; c.stroke();
    c.strokeStyle = '#ffffff'; c.lineWidth = bm.w * 0.25; c.stroke();
    c.lineCap = 'butt';
  }
  function drawPickup(c, p) {
    const bob = Math.sin(p.t * 5 + p.x) * 2;
    if (p.kind === 'xp') {
      const col = p.v >= 30 ? '#ffd23a' : p.v >= 10 ? '#d36bff' : p.v >= 3 ? '#4dff9a' : '#5bc8ff';
      const s = p.v >= 30 ? 9 : p.v >= 10 ? 8 : p.v >= 3 ? 6.5 : 5;
      c.fillStyle = col; c.strokeStyle = Terrain.paperOn ? 'rgba(75,46,30,.85)' : 'rgba(255,255,255,0.8)'; c.lineWidth = Terrain.paperOn ? 1.1 : 1.5;
      c.beginPath(); c.moveTo(p.x, p.y - s + bob); c.lineTo(p.x + s * 0.7, p.y + bob); c.lineTo(p.x, p.y + s + bob); c.lineTo(p.x - s * 0.7, p.y + bob); c.closePath(); c.fill(); c.stroke();
    } else if (p.kind === 'heart') {
      c.fillStyle = Terrain.paperOn ? '#e8504a' : '#ff3b5c'; c.strokeStyle = Terrain.paperOn ? '#4b2e1e' : '#fff'; c.lineWidth = Terrain.paperOn ? 1.4 : 2;
      heartPath(c, p.x, p.y + bob, 11); c.fill(); c.stroke();
    } else if (p.kind === 'shard') {
      const s = SHARDS[p.sid];
      const g = 0.5 + Math.sin(p.t * 6) * 0.3;
      c.fillStyle = s.col; c.globalAlpha = 0.3 * g; c.beginPath(); c.arc(p.x, p.y + bob, 13, 0, TAU); c.fill(); c.globalAlpha = 1;
      c.strokeStyle = '#fff'; c.lineWidth = 1.5;
      c.beginPath(); c.moveTo(p.x, p.y - 9 + bob); c.lineTo(p.x + 6, p.y - 2 + bob); c.lineTo(p.x + 3, p.y + 8 + bob); c.lineTo(p.x - 3, p.y + 8 + bob); c.lineTo(p.x - 6, p.y - 2 + bob); c.closePath(); c.fill(); c.stroke();
    } else if (p.kind === 'star') {
      c.fillStyle = `rgba(255,224,138,${0.3 + Math.sin(p.t * 6) * 0.15})`; c.beginPath(); c.arc(p.x, p.y + bob, 15, 0, TAU); c.fill();
      c.fillStyle = '#ffe08a'; c.strokeStyle = '#fff'; c.lineWidth = 2; star(c, p.x, p.y + bob, 10, p.t * 2); c.fill(); c.stroke();
    } else if (p.kind === 'key') {
      c.fillStyle = `rgba(255,210,90,${0.25 + Math.sin(p.t * 6) * 0.12})`; c.beginPath(); c.arc(p.x, p.y + bob, 14, 0, TAU); c.fill();
      const spr = emojiSprite('🔑', 18); c.drawImage(spr, p.x - spr.width / 4, p.y + bob - spr.height / 4, spr.width / 2, spr.height / 2);
    } else {
      c.fillStyle = '#5bc8ff'; c.strokeStyle = '#fff'; c.lineWidth = 2;
      star(c, p.x, p.y + bob, 11, p.t); c.fill(); c.stroke();
    }
  }
  // 1.0: обводка чернилами для предметов, которые рисуются каждый кадр (сундуки): рисуем во временный холст, обводим, переносим
  const INKED = { a: null, o: null };
  function drawInked(c, x, y, R, fn) {
    if (!Terrain.paperOn) { fn(c); return; }
    const m = c.getTransform(), sc = Math.hypot(m.a, m.b), px = Math.ceil(R * 2 * sc);
    if (px < 8 || px > 700) { fn(c); return; }
    if (!INKED.a) { INKED.a = makeCanvas(8, 8); INKED.o = makeCanvas(8, 8); }
    const a = INKED.a, o = INKED.o; if (a.width < px) { a.width = a.height = o.width = o.height = Math.ceil(px * 1.1); }
    const ac = a.getContext('2d'); ac.setTransform(1, 0, 0, 1, 0, 0); ac.clearRect(0, 0, px, px); ac.setTransform(sc, 0, 0, sc, px / 2 - x * sc, px / 2 - y * sc); fn(ac);
    const oc = o.getContext('2d'); oc.setTransform(1, 0, 0, 1, 0, 0); oc.globalCompositeOperation = 'source-over'; oc.clearRect(0, 0, px, px);
    const w = Math.max(1, 1.2 * sc);
    for (let k = 0; k < 8; k++) { const an = k * Math.PI / 4; oc.drawImage(a, 0, 0, px, px, Math.cos(an) * w, Math.sin(an) * w, px, px); }
    oc.globalCompositeOperation = 'source-in'; oc.fillStyle = 'rgba(75,46,30,.9)'; oc.fillRect(0, 0, px, px);
    oc.globalCompositeOperation = 'source-over'; oc.drawImage(a, 0, 0, px, px, 0, 0, px, px);
    c.drawImage(o, 0, 0, px, px, x - R, y - R, R * 2, R * 2);
  }
  function drawChest(c, ch) {
    const tell = ch.mimic && !ch.open && Math.sin(G.time * 1.3 + ch.x * 0.01) > 0.97;
    drawInked(c, ch.x, ch.y, 46, cc => drawChestSprite(cc, ch.x, ch.y, ch.tier || 'wood', ch.open, World.CHN, G.time, { twitch: tell, eyes: ch.mimic && !ch.open && (tell || Encounters.hasRelic('compass')) }));
  }
  function drawShrine(c, s) {
    const g = 0.5 + Math.sin(G.time * 3 + s.x) * 0.5;
    const col = s.state === 'done' ? '199,125,255' : s.state === 'active' ? '255,70,70' : '91,227,255';
    if (s.state === 'active') {
      c.strokeStyle = `rgba(255,70,70,${0.25 + g * 0.2})`; c.lineWidth = 3; c.setLineDash([12, 10]);
      c.beginPath(); c.arc(s.x, s.y, 300, 0, TAU); c.stroke(); c.setLineDash([]);
    }
    c.fillStyle = `rgba(${col},${0.15 + g * 0.15})`; c.beginPath(); c.arc(s.x, s.y, 34, 0, TAU); c.fill();
    c.fillStyle = '#6a6a7a'; c.strokeStyle = '#2a2a3a'; c.lineWidth = 2;
    c.beginPath(); c.ellipse(s.x, s.y + 6, 24, 9, 0, 0, TAU); c.fill(); c.stroke();
    c.fillStyle = '#8a8a9a'; roundRect(c, s.x - 8, s.y - 30, 16, 36, 4); c.fill(); c.stroke();
    c.fillStyle = `rgb(${col})`; star(c, s.x, s.y - 16, 6 + g * 2, G.time, 4); c.fill();
    if (s.state === 'idle') {
      c.font = 'bold 10px Krilessa Icons, sans-serif'; c.textAlign = 'center'; c.fillStyle = '#bff6ff';
      c.fillText('ИСПЫТАНИЕ', s.x, s.y - 40);
    } else if (s.state === 'done') {
      for (let k = 0; k < 3; k++) {
        const a0 = G.time * (2 + k);
        c.strokeStyle = `rgba(199,125,255,${0.55 - k * 0.13})`; c.lineWidth = 3;
        c.beginPath(); c.arc(s.x, s.y + 4, 16 + k * 8 + Math.sin(G.time * 3 + k) * 2, a0, a0 + 4.2); c.stroke();
      }
      c.font = 'bold 10px Krilessa Icons, sans-serif'; c.textAlign = 'center'; c.fillStyle = '#e0b0ff';
      c.fillText('ПОРТАЛ', s.x, s.y - 40);
    }
  }
  function drawGate(c) {
    if (World.gateOpen) return;
    const h = World.CASTLE.half, neon = World.CHN >= 2;
    let x, y, w, hh;
    if (World.CASTLE.gate === 'west') { x = (World.CASTLE.x - h) * World.T; y = (World.CASTLE.y - 1) * World.T; w = World.T; hh = World.T * 3; }
    else if (World.CASTLE.gate === 'east') { x = (World.CASTLE.x + h) * World.T; y = (World.CASTLE.y - 1) * World.T; w = World.T; hh = World.T * 3; }
    else { x = (World.CASTLE.x - 1) * World.T; y = (World.CASTLE.y + h) * World.T; w = World.T * 3; hh = World.T; }
    const iceG = BIOMES[World.CASTLE.biome].castleStyle === 'ice';
    c.fillStyle = iceG ? '#2a4a6a' : '#2a1f33'; c.fillRect(x, y, w, hh);
    c.strokeStyle = iceG ? '#bfeaff' : neon ? '#ff3ea5' : '#8a8a96'; c.lineWidth = 4;
    if (w < hh) { for (let i = 0; i < 7; i++) { c.beginPath(); c.moveTo(x + 4, y + 8 + i * 17); c.lineTo(x + w - 4, y + 8 + i * 17); c.stroke(); } }
    else { for (let i = 0; i < 7; i++) { c.beginPath(); c.moveTo(x + 8 + i * 17, y + 4); c.lineTo(x + 8 + i * 17, y + hh - 4); c.stroke(); } }
    const g = 0.5 + Math.sin(G.time * 3) * 0.3;
    c.fillStyle = iceG ? `rgba(127,216,255,${g * 0.45})` : `rgba(199,125,255,${g * 0.5})`; c.fillRect(x - 4, y - 4, w + 8, hh + 8);
    c.font = 'bold 16px Krilessa Icons, sans-serif'; c.textAlign = 'center';
    c.fillText('🔒', x + w / 2, y + hh / 2 + 6);
  }
  function drawEnemy(c, e) {
    const lift = e.fly ? 8 : 0;
    let sc = 1, alpha = 1;
    if (e.spawnT > 0) {
      const k = 1 - e.spawnT / 0.45; sc = 0.3 + 0.7 * k; alpha = k;
      c.fillStyle = `rgba(199,125,255,${(1 - k) * 0.6})`; c.beginPath(); c.ellipse(e.x, e.y + e.r * 0.6, e.r * 1.6, e.r * 0.6, 0, 0, TAU); c.fill();
    }
    if (e.blink > 0) alpha = clamp(e.blink / 0.55, 0.15, 1);
    shadow(c, e.x, e.y + e.r * 0.7, e.r * 0.85, e.r * 0.3);
    const evId = G.ev ? G.ev.def.id : null;
    if (evId === 'rage' && e.spawnT <= 0) {
      const g = 0.5 + Math.sin(e.t * 8 + (e.seed || 0)) * 0.5;
      c.fillStyle = `rgba(255,30,30,${0.2 + g * 0.2})`; c.beginPath(); c.arc(e.x, e.y - lift, e.r + 9, 0, TAU); c.fill();
    }
    if (e.elite) {
      const g = 0.5 + Math.sin(e.t * 5) * 0.5;
      c.fillStyle = `rgba(255,210,60,${0.18 + g * 0.15})`; c.beginPath(); c.arc(e.x, e.y - lift, e.r + 10, 0, TAU); c.fill();
      if (e.champion) { c.strokeStyle = `rgba(255,210,60,${0.6 + g * 0.4})`; c.lineWidth = 3; c.beginPath(); c.arc(e.x, e.y - lift, e.r + 15 + g * 3, 0, TAU); c.stroke(); }
    }
    if (e.def.ai === 'charger' && e.wind > 0) {
      c.fillStyle = `rgba(255,40,40,${0.25 + Math.sin(e.t * 30) * 0.1})`;
      c.save(); c.translate(e.x, e.y); c.rotate(e.dashAng); c.fillRect(0, -e.r, 210, e.r * 2); c.restore();
    }
    if (e.healing > 0) {
      c.strokeStyle = e.def.ai === 'buffer' ? 'rgba(255,140,198,0.8)' : 'rgba(125,255,154,0.8)'; c.lineWidth = 3;
      for (const o of e.healTargets) { if (o.dead) continue; c.beginPath(); c.moveTo(e.x, e.y); c.lineTo(o.x, o.y); c.stroke(); }
    }
    c.save(); c.translate(e.x, e.y - lift);
    if (evId === 'song' && !e.minion) { const ph = G.ev.t * 9 + (e.seed || 0); c.translate(0, -Math.abs(Math.sin(ph)) * 6); c.rotate(Math.sin(ph) * 0.3); }
    c.globalAlpha = alpha;
    const s = sc * (e.elite ? 1.35 : 1);
    if (s !== 1) c.scale(s, s);
    // объём: свой для каждого вида и направления взгляда
    if (VOL_SKIP.has(e.sprite)) ESPR[e.sprite](c, e);
    else {
      const flip = Math.cos(e.look || 0) < 0 ? 1 : 0;
      drawVolCore(c, 'E|' + e.sprite + '|' + flip + (e.sprite === 'mimic' ? '|' + e.chn : ''), Math.max(24, e.def.r * 2.5), cc => ESPR[e.sprite](cc, e), xx => {
        const t0 = e.t, l0 = e.look; e.t = 0.3; e.look = flip ? Math.PI : 0;
        try { ESPR[e.sprite](xx, e); } finally { e.t = t0; e.look = l0; }
      });
    }
    c.restore();
    if (e.def.ai === 'shield' && e.spawnT <= 0) { c.save(); c.translate(e.x, e.y - lift); drawEnemyShield(c, e, e.col); c.restore(); }
    if (e.flash > 0) { c.fillStyle = 'rgba(255,255,255,0.55)'; c.beginPath(); c.arc(e.x, e.y - lift, e.r, 0, TAU); c.fill(); }
    if (e.slowT > 0) { c.strokeStyle = 'rgba(150,220,255,0.7)'; c.lineWidth = 2; c.beginPath(); c.arc(e.x, e.y - lift, e.r + 3, 0, TAU); c.stroke(); }
    if (e.buffT > 0) { c.fillStyle = 'rgba(255,140,198,0.22)'; c.strokeStyle = 'rgba(255,140,198,0.7)'; c.lineWidth = 2; c.beginPath(); c.arc(e.x, e.y - lift, e.r + 6, 0, TAU); c.fill(); c.stroke(); }
    if (e.burnT > 0 && Math.random() < 0.25) Effects.part(e.x + rnd(-e.r, e.r) * 0.6, e.y - lift, rnd(-10, 10), -50, 0.4, 3, '#ff8a2a');
    if (e.elite) {
      const af = AFFIXES.find(a => a.id === e.affix);
      c.font = 'bold 10px Krilessa Icons, sans-serif'; c.textAlign = 'center'; c.fillStyle = af ? af.col : '#ffd25a';
      if (e.champion) { c.font = '900 12px Krilessa Icons, sans-serif'; c.fillStyle = '#ffd25a'; c.fillText('👑 Чемпион · ' + (e.name || e.def.name), e.x, e.y - e.r - 20 - lift); }
      else c.fillText('★ ' + (af ? af.name : 'ЭЛИТА'), e.x, e.y - e.r - 18 - lift);
    }
    if (e.hp < e.maxHp && e.spawnT <= 0) {
      const w = e.elite ? 36 : 24;
      c.fillStyle = 'rgba(0,0,0,0.6)'; c.fillRect(e.x - w / 2, e.y - e.r - 12 - lift, w, 4);
      c.fillStyle = e.elite ? '#ffd25a' : '#ff4d4d'; c.fillRect(e.x - w / 2, e.y - e.r - 12 - lift, w * clamp(e.hp / e.maxHp, 0, 1), 4);
    }
  }
  function drawFeather(c, x, y, a, s) {
    c.save(); c.translate(x, y); c.rotate(a); c.scale(s, s);
    c.fillStyle = 'rgba(150,225,255,0.35)'; c.beginPath(); c.ellipse(-8, 0, 10, 4, 0, 0, TAU); c.fill();
    c.fillStyle = P.frost ? '#cdf6ff' : '#ffffff'; c.strokeStyle = P.explode ? '#ff8a2a' : '#7b4dff'; c.lineWidth = 1.2;
    c.beginPath(); c.moveTo(9, 0); c.quadraticCurveTo(0, -5, -8, 0); c.quadraticCurveTo(0, 5, 9, 0); c.fill(); c.stroke();
    c.beginPath(); c.moveTo(9, 0); c.lineTo(-10, 0); c.stroke();
    c.restore();
  }
  function drawBubble(c, x, y, text, a, minX, maxX) {
    c.save(); c.globalAlpha = a; c.font = 'bold 12px Krilessa Icons, sans-serif';
    const lines = []; let ln = '';
    for (const w of text.split(' ')) { const t = ln ? ln + ' ' + w : w; if (ln && c.measureText(t).width > 180) { lines.push(ln); ln = w; } else ln = t; }
    if (ln) lines.push(ln);
    const w = Math.max(...lines.map(l => c.measureText(l).width)) + 16, h = lines.length * 15 + 9, by = y - h;
    const bx = clamp(x - w / 2, minX + 6, maxX - w - 6); x = clamp(x, bx + 12, bx + w - 12);
    c.fillStyle = 'rgba(255,255,255,0.95)'; roundRect(c, bx, by, w, h, 9); c.fill();
    c.beginPath(); c.moveTo(x - 7, y - 1); c.lineTo(x + 7, y - 1); c.lineTo(x, y + 9); c.fill();
    c.strokeStyle = '#ff3ea5'; c.lineWidth = 1.5; roundRect(c, bx, by, w, h, 9); c.stroke();
    c.fillStyle = '#3a0a3a'; c.textAlign = 'center';
    lines.forEach((l, i) => c.fillText(l, bx + w / 2, by + 16 + i * 15));
    c.restore();
  }
  function renderWorld() {
    const c = Viewport.ctx;
    const vw = Viewport.VW / Viewport.ZOOM, vh = Viewport.VH / Viewport.ZOOM;
    const shx = G.shake ? rnd(-G.shake, G.shake) * 0.6 : 0, shy = G.shake ? rnd(-G.shake, G.shake) * 0.6 : 0;
    const camX = G.cam.x + shx, camY = G.cam.y + shy;
    const s = Viewport.DPR * Viewport.ZOOM;
    c.setTransform(s, 0, 0, s, Math.round(Viewport.DPR * Viewport.VW / 2 - camX * s), Math.round(Viewport.DPR * Viewport.VH / 2 - camY * s));
    c.imageSmoothingEnabled = false;
    const x0 = camX - vw / 2, y0 = camY - vh / 2, x1 = x0 + vw, y1 = y0 + vh;
    c.fillStyle = '#0d0a14'; c.fillRect(x0 - 2, y0 - 2, vw + 4, vh + 4);
    for (let cy = Math.floor(y0 / Terrain.CHPX); cy <= Math.floor(y1 / Terrain.CHPX); cy++) {
      for (let cx = Math.floor(x0 / Terrain.CHPX); cx <= Math.floor(x1 / Terrain.CHPX); cx++) {
        if (cx < 0 || cy < 0 || cx * Terrain.CHUNK >= World.MW || cy * Terrain.CHUNK >= World.MH) continue;
        c.drawImage(Terrain.getChunk(cx, cy), cx * Terrain.CHPX, cy * Terrain.CHPX);
      }
    }
    c.imageSmoothingEnabled = true;
    if (World.CFG.currents || World.CFG.pearls) Expedition.drawSeaFloor(c, x0, y0, x1, y1);
    // заранее и понемногу строим соседние куски карты – без рывков при беге и в меню
    if (Session.state === 'play' || Session.state === 'menu') {
      if (!Terrain.chunkJob) {
        let best = null, bd = 1e9;
        const mcx = (x0 + x1) / 2 / Terrain.CHPX, mcy = (y0 + y1) / 2 / Terrain.CHPX;
        for (let cy = Math.floor(y0 / Terrain.CHPX) - 1; cy <= Math.floor(y1 / Terrain.CHPX) + 1; cy++)
          for (let cx = Math.floor(x0 / Terrain.CHPX) - 1; cx <= Math.floor(x1 / Terrain.CHPX) + 1; cx++) {
            if (cx < 0 || cy < 0 || cx * Terrain.CHUNK >= World.MW || cy * Terrain.CHUNK >= World.MH || Terrain.chunkCache.has(cx + ',' + cy)) continue;
            const d = (cx + 0.5 - mcx) ** 2 + (cy + 0.5 - mcy) ** 2;
            if (d < bd) { bd = d; best = [cx, cy]; }
          }
        if (best) Terrain.chunkJob = Terrain.newChunkJob(best[0], best[1]);
      }
      if (Terrain.chunkJob && Terrain.runChunkJob(Terrain.chunkJob, 5)) Terrain.chunkJob = null;
    }
    const vis = (x, y, m) => x > x0 - m && x < x1 + m && y > y0 - m && y < y1 + m;
    if (!World.CFG.narrative) drawGate(c);
    LandscapeArt.valleyBridges(c,vis);
    for (const sh of World.shrines) if (vis(sh.x, sh.y, 320)) drawShrine(c, sh);
    if (!World.CFG.dark && !(G.caveA > 0.5)) for (const h of G.hazards) drawHazard(c, h);
    HouseChapter.drawHouseGround(c, vis);
    if(World.CFG.narrative) NightKitchen.ground(c,vis);
    const trail = Session.state === 'menu' || G.cutscene ? null : StarTrail.view();
    if (trail) StarArt.ground(c, trail, vis, G.time);
    Encounters.drawArenaExit(c);
    for (const hl of World.holes) if (vis(hl.x, hl.y, 70)) Expedition.drawHole(c, hl, G.time);
    Expedition.drawCracks(c, vis);
    if (G.td) { DefenseView.drawDefGround(c, vis); DefenseView.drawDefFac(c, vis); }
    for (const ch of World.chests) if (vis(ch.x, ch.y, 40)) drawChest(c, ch);
    for (const p of G.pickups) if (vis(p.x, p.y, 20)) drawPickup(c, p);
    if (!World.CFG.narrative && Session.state !== 'menu' && !G.cutscene) {
      c.save(); c.setLineDash([7, 8]); c.strokeStyle = 'rgba(255,255,255,0.16)'; c.lineWidth = 1.5;
      c.beginPath(); c.arc(P.x, P.y, P.range, 0, TAU); c.stroke(); c.restore();
    }
    const items = [];
    MapScenery.sceneryItems(items,vis);
    const tx0 = Math.max(0, Math.floor(x0 / World.T) - 1), tx1 = Math.min(World.MW - 1, Math.floor(x1 / World.T) + 1);
    const ty0 = Math.max(0, Math.floor(y0 / World.T) - 1), ty1 = Math.min(World.MH - 1, Math.floor(y1 / World.T) + 3);
    for (let ty = ty0; ty <= ty1; ty++) for (let tx = tx0; tx <= tx1; tx++) {
      const ti = World.treeGrid[ty * World.MW + tx];
      if (ti) items.push({ y: World.trees[ti - 1].y, tree: World.trees[ti - 1] });
    }
    for (const e of G.enemies) if (vis(e.x, e.y, 60)) items.push({ y: e.y, e });
    if (G.td) {
      if (vis(G.core.x, G.core.y, 120)) items.push({ y: G.core.y + 14, defc: true });
      for (const sp of G.td.spots) if (sp.tw && vis(sp.x, sp.y, 70)) items.push({ y: sp.y + 9, dtw: sp.tw });
      for (const u of G.td.units) if (!u.dead && vis(u.x, u.y, 30)) items.push({ y: u.y, dun: u });
    }
    for (const b of Session.bosses) if (b.state !== 'dead' && vis(b.x, b.y, 140) && (!World.CFG.rush || !G.rush || b.id === G.rush.idx)) items.push({ y: b.y, b });
    const ally = G.finalFinal && G.finalFinal.ally;
    if (ally && Session.state !== 'menu') items.push({ y: ally.y, ally });
    const cageX = World.tc(World.CAGE.x), cageY = World.tc(World.CAGE.y);
    if (!World.CFG.noCage && vis(cageX, cageY, 80)) items.push({ y: cageY + 20, cage: true });
    if (World.CFG.team && World.CFG.hostage === 'tessa' && !G.tessaAlly && !G.cutscene && Session.state !== 'menu' && vis(cageX, cageY, 90)) items.push({ y: cageY + 20, iceCage: true });
    for (const f of World.fires) if (vis(f.x, f.y, 100)) items.push({ y: f.y + 6, fire: f });
    for (const ov of World.ovens) if (vis(ov.x, ov.y, 80)) items.push({ y: ov.y + 20, oven: ov });
    for (const dr of World.drifts) if (!dr.done && vis(dr.x, dr.y, 50)) items.push({ y: dr.y + 8, drift: dr });
    if (G.team && Session.state !== 'menu' && !G.cutscene) items.push({ y: G.team.by, buddy: true });
    if (G.tessaAlly && Session.state !== 'menu') items.push({ y: G.tessaAlly.y, tessa: G.tessaAlly });
    if (Session.state !== 'menu' && Session.state !== 'dying' && Session.state !== 'dead') items.push({ y: P.y, player: true });
    if (NET.on && G.netRun && Session.state !== 'menu') for (const m of NET.mates.values()) if (m.tx !== undefined && vis(m.x, m.y, 80)) items.push({ y: m.y, mate: m });
    items.sort((a, b) => a.y - b.y);
    for (const it of items) {
      if (it.fixture) MapScenery.furniture(c,it.fixture);
      else if (it.tree) {
        const tr = it.tree, spr = TREE_SPR[tr.kind];
        const w = 64 * tr.s, h = 84 * tr.s;
        const under = (x, y) => y < tr.y && y > tr.y - h * 0.95 && Math.abs(x - tr.x) < w * 0.5;
        const behind = Session.state !== 'menu' && (under(P.x, P.y) || (G.activeBoss && under(G.activeBoss.x, G.activeBoss.y)));
        if (behind) c.globalAlpha = 0.42;
        c.drawImage(spr, tr.x - w / 2, tr.y - h + 5 * tr.s, w, h);
        c.globalAlpha = 1;
      } else if (it.e) drawEnemy(c, it.e);
      else if (it.b) drawBoss(c, it.b);
      else if (it.cage) drawCage(c, cageX, cageY, G.cageOpen, G.time);
      else if (it.iceCage) Expedition.drawIceCage(c, cageX, cageY, G.time);
      else if (it.fire) Expedition.drawCampfire(c, it.fire, G.time);
      else if (it.oven) Expedition.drawOven(c, it.oven, G.time);
      else if (it.drift) Expedition.drawDrift(c, it.drift, G.time);
      else if (it.buddy) {
        const T6 = G.team, o = Expedition.teamOther(), ko = T6.ko[o];
        shadow(c, T6.bx, T6.by + 10, 10, 4);
        const tg = G.activeBoss || null;
        drawHeroV(o, c, T6.bx, T6.by, P.t, tg ? (tg.x > T6.bx ? 1 : -1) : P.face, 0.9, ko ? 0.45 : 0.92, P.moving);
        if (ko) { c.font = '14px Krilessa Icons, sans-serif'; c.textAlign = 'center'; c.fillText('💤', T6.bx + 12, T6.by - 34 + Math.sin(P.t * 3) * 3); }
      }
      else if (it.tessa) {
        const A = it.tessa;
        shadow(c, A.x, A.y + 10, 10, 4);
        drawHeroV('tessa', c, A.x, A.y, P.t, A.face, 0.85, 1, true);
        if (World.CFG.tessaStart) { // пузырь-шлем
          const bg = c.createRadialGradient(A.x - 6, A.y - 22, 2, A.x, A.y - 14, 20); bg.addColorStop(0, 'rgba(255,255,255,0.35)'); bg.addColorStop(0.7, 'rgba(160,230,255,0.12)'); bg.addColorStop(1, 'rgba(160,230,255,0.45)');
          c.fillStyle = bg; c.beginPath(); c.arc(A.x, A.y - 14, 19, 0, TAU); c.fill();
          c.strokeStyle = 'rgba(220,250,255,0.7)'; c.lineWidth = 1.5; c.stroke();
          c.fillStyle = 'rgba(255,255,255,0.7)'; c.beginPath(); c.ellipse(A.x - 8, A.y - 24, 4, 2.2, -0.6, 0, TAU); c.fill();
        }
      }
      else if (it.ally) {
        const A = it.ally, ab = G.activeBoss || Session.bosses[Session.bosses.length - 1];
        shadow(c, A.x, A.y + 10, 11, 4);
        c.fillStyle = `rgba(191,234,255,${0.18 + Math.sin(P.t * 5) * 0.08})`; c.beginPath(); c.arc(A.x, A.y - 6, 26, 0, TAU); c.fill();
        drawHero('krilessa', c, A.x, A.y + Math.sin(P.t * 4) * 3, P.t, ab && ab.x > A.x ? 1 : -1, 1, 1, true);
      }
      else if (it.defc) DefenseView.drawDefCore(c);
      else if (it.dtw) DefenseView.drawDefTower(c, it.dtw);
      else if (it.dun) DefenseView.drawDefUnit(c, it.dun);
      else if (it.mate) Multiplayer.drawMate(c, it.mate);
      else if (it.player && P.down) { // без сил – лежит, ждёт подругу
        shadow(c, P.x, P.y + 10, 11, 4);
        c.save(); c.translate(P.x, P.y + 4); c.rotate(Math.PI / 2 * P.face); drawHeroV(P.hero, c, 0, 0, P.t, 1, 0.9, 0.7, false); c.restore();
        c.font = '16px Krilessa Icons, sans-serif'; c.textAlign = 'center'; c.fillText('💫', P.x, P.y - 26 + Math.sin(P.t * 3) * 3);
        if (NET.on && G.netRun) { c.lineWidth = 5; c.strokeStyle = 'rgba(0,0,0,0.45)'; c.beginPath(); c.arc(P.x, P.y - 4, 24, 0, TAU); c.stroke(); }
        if (P.revT > 0) { c.strokeStyle = '#7dff9a'; c.lineWidth = 4; c.beginPath(); c.arc(P.x, P.y - 4, 24, -Math.PI / 2, -Math.PI / 2 + TAU * clamp(P.revT / 2.6, 0, 1)); c.stroke(); }
        if (G.td && P.tdRev > 0) { c.font = 'bold 11px Krilessa Icons, sans-serif'; c.textAlign = 'center'; c.fillStyle = '#ff8ad8'; c.fillText(`💗 ${Math.ceil(P.tdRev)} с`, P.x, P.y + 34); }
      }
      else if (it.player) {
        const blink = P.inv > 0 && Math.floor(P.t * 20) % 2 === 0;
        shadow(c, P.x, P.y + 10, 11, 4);
        if (NET.on && G.netRun) { c.strokeStyle = Multiplayer.mateCol(NET.id || 1); c.globalAlpha = 0.8; c.lineWidth = 2.5; c.beginPath(); c.ellipse(P.x, P.y + 10, 15, 6, 0, 0, TAU); c.stroke(); c.globalAlpha = 1; }
        if (G.myAura && G.myAura !== 'none' && !G.hidden) drawAura(c, G.myAura, P.x, P.y - (P.z || 0), P.t);
        if (!(G.hidden && P.hero === 'tessa')) drawHeroV(P.hero, c, P.x, P.y - (P.z || 0), P.t, P.face, 1, blink ? 0.4 : 1, P.moving || P.dashT > 0 || !!G.jump);
        if (P.napT > 0) { c.fillStyle = `rgba(255,220,120,${0.25 + Math.sin(P.t * 4) * 0.1})`; c.beginPath(); c.arc(P.x, P.y - 6 - (P.z || 0), 20, 0, TAU); c.fill(); }
        if (P.stormT > 0) { c.strokeStyle = 'rgba(150,225,255,0.6)'; c.lineWidth = 3; c.beginPath(); c.arc(P.x, P.y - 6, 28 + Math.sin(P.t * 20) * 4, 0, TAU); c.stroke(); }
        if (P.shieldLv && P.shieldT <= 0) {
          c.strokeStyle = `rgba(127,232,255,${0.5 + Math.sin(P.t * 4) * 0.2})`; c.lineWidth = 2;
          c.beginPath(); c.arc(P.x, P.y - 6, 22, 0, TAU); c.stroke();
        }
        if (P.slowT > 0) { c.fillStyle = 'rgba(255,220,80,0.35)'; c.beginPath(); c.ellipse(P.x, P.y + 10, 16, 6, 0, 0, TAU); c.fill(); }
      }
    }
    if (G.td) DefenseView.drawDefOver(c, vis);
    if (G.hidden) HouseChapter.drawBox(c, G.hidden, true);
    if (G.pet && Session.state !== 'menu') HouseChapter.drawPet(c);
    if (P.orbit && Session.state !== 'menu' && !G.cutscene) {
      for (let k = 0; k < P.orbit; k++) {
        const a = P.orbA + (k / P.orbit) * TAU, ox = P.x + Math.cos(a) * 62, oy = P.y + Math.sin(a) * 62;
        if (P.proj === 'fire') drawFireball(c, ox, oy, a + Math.PI / 2, 1.2);
        else if (P.proj === 'claw') { c.fillStyle = '#ff6fb5'; c.beginPath(); c.arc(ox, oy, 7, 0, TAU); c.fill(); c.strokeStyle = '#c0306a'; c.lineWidth = 1.5; c.beginPath(); c.arc(ox, oy, 7, a, a + 2.4); c.stroke(); }
        else drawFeather(c, ox, oy, a + Math.PI / 2, 1.3);
      }
    }
    for (const z of G.pzones) {
      const a = clamp((z.dur - z.t) / 0.5, 0, 1);
      c.fillStyle = `rgba(255,120,30,${0.25 * a})`; c.beginPath(); c.arc(z.x, z.y, z.r, 0, TAU); c.fill();
    }
    for (const n of G.novas) {
      if (n.star) { // золотая волна эволюций
        const a = clamp(1 - n.r / n.max, 0, 1) + 0.15;
        c.lineWidth = 12; c.strokeStyle = `rgba(255,243,160,${a})`; c.beginPath(); c.arc(n.x, n.y, n.r, 0, TAU); c.stroke();
        c.lineWidth = 3; c.strokeStyle = `rgba(255,255,255,${a})`; c.stroke();
        continue;
      }
      if (n.disco || n.life) {
        const a = clamp(1 - n.r / n.max, 0, 1) + 0.2;
        c.lineWidth = n.disco ? 7 : 14;
        c.strokeStyle = n.disco ? `hsla(${(G.time * 360) % 360},100%,70%,${a})` : `rgba(191,234,255,${a})`;
        c.beginPath(); c.arc(n.x, n.y, n.r, 0, TAU); c.stroke();
        continue;
      }
      if (n.purr) {
        c.lineWidth = 22; c.strokeStyle = 'rgba(255,140,200,0.4)'; c.beginPath(); c.arc(n.x, n.y, n.r, 0, TAU); c.stroke();
        c.lineWidth = 6; c.strokeStyle = 'rgba(255,220,240,0.9)'; c.stroke();
        for (let k = 0; k < 8; k++) { const a = k * TAU / 8 + n.r * 0.01; c.fillStyle = '#ff6fb5'; heartPath(c, n.x + Math.cos(a) * n.r, n.y + Math.sin(a) * n.r, 7); c.fill(); }
        continue;
      }
      c.lineWidth = 26; c.strokeStyle = 'rgba(255,90,20,0.45)'; c.beginPath(); c.arc(n.x, n.y, n.r, 0, TAU); c.stroke();
      c.lineWidth = 10; c.strokeStyle = 'rgba(255,220,80,0.9)'; c.stroke();
      c.lineWidth = 3; c.strokeStyle = '#ffffff'; c.stroke();
    }
    if (World.CFG.dark || Challenges.mutOn('dark')) { HouseChapter.drawDarkness(c); for (const h of G.hazards) drawHazard(c, h); }
    for (const st of G.falling) {
      const k = clamp(st.t / st.dur, 0, 1), sx = st.x + (1 - k) * 140, sy = st.y - (1 - k) * 320;
      c.strokeStyle = `rgba(255,224,138,${0.25 + k * 0.5})`; c.lineWidth = 2; c.beginPath(); c.arc(st.x, st.y, 10 + (1 - k) * 26, 0, TAU); c.stroke();
      c.strokeStyle = 'rgba(255,240,190,0.6)'; c.lineWidth = 4; c.beginPath(); c.moveTo(sx, sy); c.lineTo(sx + 40, sy - 90); c.stroke();
      c.fillStyle = '#ffe08a'; star(c, sx, sy, 9, st.t * 8); c.fill();
    }
    Expedition.drawCaveDark(c);
    Expedition.drawBlizzard(c);
    if (trail) StarArt.beacons(c, trail, vis, G.time);
    for (const bm of G.beams) drawBeam(c, bm);
    // ДРУЖБА-СУПЕР: два луча сливаются в радугу
    const cs = G.cutscene;
    if (cs && cs.kind === 'teamup' && G.finalFinal) {
      const A = G.finalFinal.ally, tb = Session.bosses[Session.bosses.length - 1];
      if (cs.t < 0.8) {
        for (const [hx, hy, col] of [[P.x, P.y - 6, '255,140,40'], [A.x, A.y - 6, '120,200,255']]) {
          c.fillStyle = `rgba(${col},${0.25 + cs.t * 0.5})`; c.beginPath(); c.arc(hx, hy, 18 + cs.t * 30 + Math.sin(cs.t * 40) * 3, 0, TAU); c.fill();
        }
      } else if (cs.t < 3.2 && tb) {
        const mx = (P.x + A.x) / 2, my = (P.y + A.y) / 2 - 30, w = 10 + Math.sin(cs.t * 30) * 3;
        c.lineCap = 'round';
        for (const [hx, hy, col] of [[P.x, P.y - 6, '#ff8a2a'], [A.x, A.y - 6, '#7fd8ff']]) {
          c.strokeStyle = col; c.lineWidth = w; c.beginPath(); c.moveTo(hx, hy); c.lineTo(mx, my); c.stroke();
        }
        const ang = Math.atan2(tb.y - tb.z - my, tb.x - mx), len = Math.hypot(tb.x - mx, tb.y - tb.z - my);
        c.save(); c.translate(mx, my); c.rotate(ang);
        RAINBOW.forEach((col, i) => { c.fillStyle = col; c.fillRect(0, (i - RAINBOW.length / 2) * (w * 0.6), len, w * 0.6); });
        c.fillStyle = 'rgba(255,255,255,0.85)'; c.fillRect(0, -w * 0.4, len, w * 0.8);
        c.restore();
        c.fillStyle = '#ffffff'; c.beginPath(); c.arc(mx, my, w * 1.6, 0, TAU); c.fill();
        c.lineCap = 'butt';
      }
    }
    for (const f of G.rfeathers || []) { // выстрелы подруг
      if (!vis(f.x, f.y, 20)) continue;
      c.save();
      const distance = Math.hypot(f.x-P.x, f.y-(P.y-P.z-14));
      c.globalAlpha *= 0.22 + 0.78*clamp((distance-18)/65,0,1);
      if (f.kind === 'fire') drawFireball(c, f.x, f.y, Math.atan2(f.vy, f.vx), 1);
      else if (f.kind === 'claw') drawClaw(c, f);
      else if (f.kind === 'pixel') { c.fillStyle = '#3ff0a0'; c.fillRect(f.x - 3, f.y - 3, 6, 6); }
      else drawFeather(c, f.x, f.y, Math.atan2(f.vy, f.vx), 1);
      c.restore();
    }
    for (const f of G.feathers) {
      if (f.kind === 'fire') drawFireball(c, f.x, f.y, Math.atan2(f.vy, f.vx), 1);
      else if (f.kind === 'claw') drawClaw(c, f);
      else if (f.kind === 'pixel') { c.fillStyle = '#3ff0a0'; c.fillRect(f.x - 3, f.y - 3, 6, 6); c.fillStyle = '#ffffff'; c.fillRect(f.x - 3, f.y - 3, 2, 2); }
      else drawFeather(c, f.x, f.y, Math.atan2(f.vy, f.vx), 1);
    }
    for (const b of G.ebullets) {
      if (!vis(b.x, b.y, 20)) continue;
      if (b.saw) {
        c.save(); c.translate(b.x, b.y); c.rotate(b.rot);
        c.fillStyle = '#9aa4b8'; c.beginPath();
        for (let k = 0; k < 16; k++) { const rr = k % 2 ? b.r * 0.75 : b.r; const a = k / 16 * TAU; c.lineTo(Math.cos(a) * rr, Math.sin(a) * rr); }
        c.closePath(); c.fill(); c.strokeStyle = '#3a3a4a'; c.lineWidth = 1.5; c.stroke();
        c.fillStyle = '#ff3b3b'; c.beginPath(); c.arc(0, 0, 3, 0, TAU); c.fill();
        c.restore(); continue;
      }
      const spr = b.emoji ? emojiSprite(b.emoji, 18) : b.square ? squareSprite(b.col, b.r * 0.85) : bulletSprite(b.col, b.r);
      const fa = b.life < Enemies.SHOT_FADE ? Math.max(0, b.life / Enemies.SHOT_FADE) : 1, sz = 0.5 * (0.55 + 0.45 * fa); // в конце полёта тает и сжимается
      if (fa < 1) c.globalAlpha = fa;
      c.drawImage(spr, b.x - spr.width * sz / 2, b.y - spr.height * sz / 2, spr.width * sz, spr.height * sz);
      if (fa < 1) c.globalAlpha = 1;
    }
    for (const b of G.bolts) {
      c.strokeStyle = `rgba(${b.col || '190,230,255'},${clamp(b.t * 4, 0, 1)})`; c.lineWidth = 3;
      c.beginPath();
      for (let i = 0; i < b.pts.length - 1; i++) {
        const [ax, ay] = b.pts[i], [bx, by] = b.pts[i + 1];
        c.moveTo(ax, ay);
        for (let k = 1; k <= 4; k++) c.lineTo(lerp(ax, bx, k / 4) + (k < 4 ? rnd(-10, 10) : 0), lerp(ay, by, k / 4) + (k < 4 ? rnd(-10, 10) : 0));
      }
      c.stroke();
    }
    for (const r of G.rings) {
      c.strokeStyle = r.col; c.globalAlpha = clamp(1 - r.t / 0.45, 0, 1); c.lineWidth = 4;
      c.beginPath(); c.arc(r.x, r.y, r.r, 0, TAU); c.stroke(); c.globalAlpha = 1;
    }
    for (const p of G.parts) {
      c.globalAlpha = clamp(p.life / p.max, 0, 1); c.fillStyle = p.col;
      c.fillRect(p.x - p.size / 2, p.y - p.size / 2, p.size, p.size);
    }
    c.globalAlpha = 1;
    c.textAlign = 'center';
    CombatCues.overlay(c);
    for (const t of G.texts) {
      const life = t.big ? 1.1 : 0.8;
      c.globalAlpha = clamp(1 - t.t / life, 0, 1);
      if (Terrain.paperOn) { // цифры – от руки: чернила с бумажной обводкой
        const col = t.col === '#ffe04a' ? '#c8342a' : HUD.lightCol(t.col) ? HUD.INK : t.col;
        c.font = (t.crit ? "italic " : "") + HUD.HAND(t.big ? 24 : 18); c.lineJoin = 'round'; c.lineWidth = 3.5; c.strokeStyle = 'rgba(251,243,224,.92)';
        c.strokeText(t.txt, t.x, t.y - t.t * 30); c.fillStyle = col; c.fillText(t.txt, t.x, t.y - t.t * 30);
        continue;
      }
      c.font = t.crit ? 'italic 900 19px Nunito, sans-serif' : t.big ? 'bold 17px Krilessa Icons, sans-serif' : 'bold 13px Krilessa Icons, sans-serif';
      c.fillStyle = '#000'; c.fillText(t.txt, t.x + 1, t.y - t.t * 30 + 1);
      c.fillStyle = t.col; c.fillText(t.txt, t.x, t.y - t.t * 30);
    }
    c.globalAlpha = 1;
    for (const b of Session.bosses) if (b.bubble && b.state === 'fight') drawBubble(c, b.x, b.y - b.z - b.r - 30, b.bubble.text, clamp(b.bubble.t / 0.3, 0, 1), x0, x1);
    if (Session.state === 'menu' || G.cutscene) return;
    if (G.ev && G.ev.def.id === 'treasure') { // метка клада: золотой крест и столб света
      const ex = G.ev.tx, ey = G.ev.ty, pu = 0.5 + 0.5 * Math.sin(G.time * 5);
      const gl = c.createLinearGradient(ex, ey - 160, ex, ey); gl.addColorStop(0, 'rgba(255,220,120,0)'); gl.addColorStop(1, `rgba(255,220,120,${0.35 + 0.2 * pu})`);
      c.fillStyle = gl; c.fillRect(ex - 16, ey - 160, 32, 160);
      c.strokeStyle = '#7a4a00'; c.lineWidth = 9; c.lineCap = 'round';
      c.beginPath(); c.moveTo(ex - 14, ey - 10); c.lineTo(ex + 14, ey + 10); c.moveTo(ex + 14, ey - 10); c.lineTo(ex - 14, ey + 10); c.stroke();
      c.strokeStyle = '#ffd25a'; c.lineWidth = 5;
      c.beginPath(); c.moveTo(ex - 14, ey - 10); c.lineTo(ex + 14, ey + 10); c.moveTo(ex + 14, ey - 10); c.lineTo(ex - 14, ey + 10); c.stroke(); c.lineCap = 'butt';
    }
    if (G.ev && G.ev.thief && !G.ev.thief.dead) { const e = G.ev.thief; c.font = '18px Krilessa Icons, sans-serif'; c.textAlign = 'center'; c.fillText('💰', e.x, e.y - e.r - 16 + Math.sin(G.time * 8) * 3); }
    const bw = 64, bx = P.x - bw / 2, by = P.y - 52;
    if (!World.CFG.narrative) {
    if (Terrain.paperOn) { // над головой – тонкая полоска от руки (цифры – в записке сверху)
      const k = clamp(P.hp / P.maxHp, 0, 1), bw2 = 44, bx2 = P.x - bw2 / 2, by2 = by + 4;
      c.fillStyle = 'rgba(251,243,224,.85)'; c.fillRect(bx2, by2, bw2, 6);
      c.fillStyle = k < 0.3 ? 'rgba(220,40,30,.8)' : 'rgba(200,60,48,.62)'; c.fillRect(bx2 + 1, by2 + 1, (bw2 - 2) * k, 4);
      c.strokeStyle = 'rgba(75,46,30,.75)'; c.lineWidth = 1; c.strokeRect(bx2, by2, bw2, 6);
      if (P.lives) HUD.handText(c, '🐾' + P.lives, P.x + bw2 / 2 + 4, by2 + 7, 13, HUD.INK, 'left');
      c.textAlign = 'center';
    } else {
    c.fillStyle = 'rgba(0,0,0,0.65)'; c.fillRect(bx - 2, by - 2, bw + 4, 13);
    c.fillStyle = P.hp < P.maxHp * 0.3 ? '#ff4d4d' : '#4cd964'; c.fillRect(bx, by, bw * clamp(P.hp / P.maxHp, 0, 1), 9);
    c.font = 'bold 9px Krilessa Icons, sans-serif'; c.fillStyle = '#fff';
    c.fillText(`${Math.ceil(P.hp)}/${P.maxHp}` + (P.lives ? ` · 🐾${P.lives}` : ''), P.x, by + 8);
    }
    }
    if (!G.activeBoss && !G.activeShrine) {
      const o = Simulation.objective();
      const dx = o.x - P.x, dy = o.y - P.y, d = Math.hypot(dx, dy);
      if (d > 170) {
        const a = Math.atan2(dy, dx), ax = P.x + Math.cos(a) * 82, ay = P.y + Math.sin(a) * 82 - 6;
        c.save(); c.translate(ax, ay); c.rotate(a);
        c.fillStyle = World.CFG.narrative ? '#dfc18b' : '#d6f03a'; c.strokeStyle = World.CFG.narrative ? '#594537' : '#4a5a00'; c.lineWidth = 2;
        c.beginPath(); c.moveTo(14, 0); c.lineTo(-8, -11); c.lineTo(-3, 0); c.lineTo(-8, 11); c.closePath(); c.fill(); c.stroke();
        c.restore();
        if (Terrain.paperOn) HUD.handText(c, `${Math.round(d / World.PX_PER_M)} м`, ax, ay + 27, 17, HUD.INK, 'center', 'rgba(251,243,224,.9)');
        else { c.font = 'bold 13px Krilessa Icons, sans-serif'; c.fillStyle = '#000'; c.fillText(`${Math.round(d / World.PX_PER_M)} м`, ax + 1, ay + 27);
        c.fillStyle = '#fff'; c.fillText(`${Math.round(d / World.PX_PER_M)} м`, ax, ay + 26); }
      }
    }
    const evT = G.ev && (G.ev.def.id === 'thief' && G.ev.thief && !G.ev.thief.dead ? G.ev.thief : G.ev.def.id === 'treasure' ? { x: G.ev.tx, y: G.ev.ty } : null);
    if (evT) { // золотая стрелка к цели события
      const dx = evT.x - P.x, dy = evT.y - P.y, d = Math.hypot(dx, dy);
      if (d > 120) {
        const a = Math.atan2(dy, dx), ax = P.x + Math.cos(a) * 104, ay = P.y + Math.sin(a) * 104 - 6, pl = 1 + 0.12 * Math.sin(G.time * 8);
        c.save(); c.translate(ax, ay); c.rotate(a); c.scale(pl, pl);
        c.fillStyle = '#ffd25a'; c.strokeStyle = '#7a4a00'; c.lineWidth = 2;
        c.beginPath(); c.moveTo(15, 0); c.lineTo(-8, -12); c.lineTo(-3, 0); c.lineTo(-8, 12); c.closePath(); c.fill(); c.stroke();
        c.restore();
        c.font = '15px Krilessa Icons, sans-serif'; c.textAlign = 'center'; c.fillText(G.ev.def.ic, ax, ay - 16);
      }
    }
    if (G.champ && !G.champ.dead && !G.activeBoss) {
      const dx = G.champ.x - P.x, dy = G.champ.y - P.y;
      if (Math.hypot(dx, dy) > 260) {
        const a = Math.atan2(dy, dx), ax = P.x + Math.cos(a) * 62, ay = P.y + Math.sin(a) * 62 - 6;
        c.font = '15px Krilessa Icons, sans-serif'; c.textAlign = 'center'; c.globalAlpha = 0.6 + 0.4 * Math.sin(G.time * 5); c.fillText('👑', ax, ay + 5); c.globalAlpha = 1;
      }
    }
  }

  return {
    VOL, drawHeroV, drawHazard, drawFeather, renderWorld,
    get volOn() { return volOn; },
    set volOn(value) { volOn = value; },
  };
})();
