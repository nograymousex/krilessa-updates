'use strict';

const NightKitchen = (() => {
  const lines = [
    [
      'На дне банки ещё лежит прошлогодняя гвоздика. Рыжовая прикрывает ключ двумя ложками сахара.',
      '«Дай мне его на минуту». Крилесса смотрит в стол. «Я только понюхаю, что она печёт».',
    ],
    [
      'Из соседнего дома выходит мужчина с пелёнкой через плечо. «У нас мальчик будет. Уже кроватку собрал».',
      'Он показывает на остывшую печь. «Я её утром затопил. Жена говорит, утра не было».',
    ],
    [
      'На обороте листа знакомый почерк. «Первый завтрак. Я успела сказать, что научилась летать».',
      '«Третий завтрак. У кузнеца выпал понедельник». На четвёртом листе написан сегодняшний адрес.',
    ],
    [
      'Рыжовая достаёт ключ. За тонкой дверью осторожно придвигают второй стул.',
      'Крилесса снимает корону и ставит её на пол. «Я помню её голос только здесь».',
    ],
  ];
  const art = {};
  function picture(name) {
    if (!art[name]) {
      art[name] = new Image();
      art[name].src = 'art/dawn-' + name + '.webp';
    }
    return art[name];
  }
  const state = () => G.kitchen || (G.kitchen = { step: 0, choice: '' });
  function snapshot() {
    return { ...state() };
  }
  function restore(s) {
    G.kitchen = {
      step: clamp(Number(s?.step) | 0, 0, 4),
      choice: s && ['keep', 'open'].includes(s.choice) ? s.choice : '',
    };
    World.gateOpen = G.kitchen.step >= 3;
  }
  function point() {
    const site = DawnChapter.sites[Math.min(3, state().step)];
    return { x: World.tc(site.x), y: World.tc(site.y) };
  }
  function near(who) {
    const p = point();
    return Math.hypot((who.tx ?? who.x) - p.x, (who.ty ?? who.y) - p.y) <= 112;
  }
  function note(n) {
    const panel = $('dawnNote');
    panel.querySelector('p').textContent = lines[n].join(' ');
    panel.classList.remove('hidden');
    Sound.sfx[n === 0 ? 'keyClink' : n === 3 ? 'doorKnock' : 'peel']();
  }
  function reset() {
    G.kitchen = null;
    $('dawnAct').classList.add('hidden');
    $('dawnNote').classList.add('hidden');
    $('dawnChoice').classList.add('hidden');
  }
  function update(dt) {
    if (Session.state !== 'play' || state().choice) return;
    const s = state(),
      choice = s.step === 4,
      reading = !$('dawnNote').classList.contains('hidden');
    const action = $('dawnAct');
    action.classList.toggle('hidden', choice || reading || !near(P));
    const label = DawnChapter.sites[Math.min(3, s.step)].label;
    if (action.textContent !== label) action.textContent = label;
    const goal = $('dawnGoal'),
      objective = choice ? 'У кухонной двери' : label;
    if (goal.textContent !== objective) goal.textContent = objective;
    const panel = $('dawnChoice');
    if (choice) {
      panel.classList.toggle('waiting', !!NET.client);
      const title = NET.client
        ? 'Рыжовая у двери. Хозяйка комнаты выбирает, что ответить.'
        : 'Что сделает Рыжовая?';
      const heading = panel.querySelector('p');
      if (heading.textContent !== title) heading.textContent = title;
    }
    panel.classList.toggle('hidden', !choice || reading);
    if (!reading && !choice) Hero.updatePlayer(dt);
    else {
      P.vx = P.vy = 0;
      P.moving = false;
    }
    StarTrail.update();
    G.fogT -= dt;
    if (G.fogT <= 0) {
      G.fogT = 0.25;
      Terrain.revealFog(P.x, P.y, 9);
    }
    if (NET.client) Multiplayer.netProxies(dt);
  }
  function store() {
    if (NET.host) NetT.send(-1, { t: 'kitchen', cid: NET.coopId, ki: snapshot() });
    Saves.saveGame();
  }
  function interact(step, who = P) {
    if (World.CHN !== 8 || !near(who) || step !== state().step || step >= 4) return;
    if (NET.client) {
      NetT.send(0, { t: 'kitchenAct', cid: NET.coopId, step });
      return;
    }
    state().step++;
    World.gateOpen = state().step >= 3;
    G.cp = pointOf(step);
    note(step);
    store();
  }
  function pointOf(n) {
    const v = DawnChapter.sites[n];
    return { x: World.tc(v.x), y: World.tc(v.y) };
  }
  function finish(choice) {
    if (!['open', 'keep'].includes(choice) || state().choice) return;
    state().choice = choice;
    G.victoryShown = true;
    const p = Saves.loadProfile();
    p.ch8Done = true;
    p.dawnChoice = choice;
    p.lastCh = 8;
    if (Saves.saveProfile(p)) {
      if (NET.on) CoopCheckpoints.clear();
      else GameStorage.remove(Saves.saveKey(8));
    }
    if (NET.host) NetT.send(-1, { t: 'kitchen', cid: NET.coopId, ki: snapshot() });
    $('dawnChoice').classList.add('hidden');
    $('dawnNote').classList.add('hidden');
    Intro.start('end8' + choice, () => Screens.showVictory('dawn'));
  }
  function sync(s) {
    if (!s || World.CHN !== 8 || state().choice) return;
    if (s.step > state().step) {
      restore({ step: s.step });
      if (s.step > 0 && !s.choice) note(s.step - 1);
    }
    if (s.choice) finish(s.choice);
  }
  function ground(c, vis) {
    const at = pointOf(Math.min(3, state().step));
    if (!vis(at.x, at.y, 170)) return;
    c.save();
    c.translate(at.x, at.y);
    const light = c.createRadialGradient(0, -16, 1, 0, -16, 110);
    light.addColorStop(0, '#ffd59c2b');
    light.addColorStop(0.6, '#f9cd8d12');
    light.addColorStop(1, '#f9cd8d00');
    c.fillStyle = light;
    c.fillRect(-112, -130, 224, 224);
    c.strokeStyle = '#f1d3a382';
    c.lineWidth = 1.5;
    c.beginPath();
    c.ellipse(0, 4, 22, 7, 0, 0, TAU);
    c.stroke();
    for (let n = 0; n < 4; n++) {
      const phase = G.time * 0.21 + n * 1.7;
      c.fillStyle = 'rgba(255,231,188,' + (0.25 + 0.17 * Math.cos(phase)) + ')';
      c.beginPath();
      c.arc(
        Math.sin(phase + n) * 37,
        -17 + ((n * 21 - ((G.time * 3) % 74) + 74) % 74) - 37,
        1.3,
        0,
        TAU,
      );
      c.fill();
    }
    c.restore();
  }
  function drawPlan(c, x, y, size) {
    const scale = (size - 12) / World.WORLD_W,
      height = World.PLAY_H * World.T * scale;
    const left = x + 6,
      top = y + (size - height) / 2;
    c.save();
    c.fillStyle = '#172623e8';
    c.strokeStyle = '#a0906b';
    c.lineWidth = 1.2;
    roundRect(c, x, y, size, size, 10);
    c.fill();
    c.stroke();
    c.clip();
    c.drawImage(Terrain.miniBase, left, top, size - 12, height);
    c.drawImage(Terrain.fog, left, top, size - 12, height);
    const X = (v) => left + v * scale,
      Y = (v) => top + v * scale;
    Navigation.draw(c, Navigation.route(), X, Y, '#edcc88', 1.1);
    for (const mate of NET.mates.values())
      if (mate.tx !== undefined) {
        c.fillStyle = '#9ec6c0';
        c.beginPath();
        c.arc(X(mate.x), Y(mate.y), 2.3, 0, TAU);
        c.fill();
      }
    c.fillStyle = '#f8da9c';
    c.beginPath();
    c.arc(X(P.x), Y(P.y), 3.2, 0, TAU);
    c.fill();
    c.restore();
  }
  function drawScene(c, w, h, sc, t) {
    const img = picture(sc.art),
      f = sc.fx || 0.5;
    c.fillStyle = '#141a1b';
    c.fillRect(0, 0, w, h);
    if (!img.naturalWidth) return;
    const portrait = h > w,
      boxH = portrait ? h * 0.63 : h,
      top = portrait ? h * 0.09 : 0,
      zoom = 1 + 0.018 * Math.min(1, t / 4);
    const k = Math.max(w / img.width, boxH / img.height) * zoom,
      dw = img.width * k,
      dh = img.height * k;
    c.save();
    c.beginPath();
    c.rect(0, top, w, boxH);
    c.clip();
    c.drawImage(img, (w - dw) * f, top + (boxH - dh) * 0.47, dw, dh);
    c.restore();
    const g = c.createLinearGradient(0, h * 0.52, 0, h);
    g.addColorStop(0, 'rgba(13,18,19,0)');
    g.addColorStop(1, '#101719');
    c.fillStyle = g;
    c.fillRect(0, h * 0.52, w, h * 0.48);
  }
  $('dawnAct').addEventListener('click', () => interact(state().step));
  $('dawnRead').addEventListener('click', () => $('dawnNote').classList.add('hidden'));
  for (const b of $('dawnChoice').querySelectorAll('button'))
    b.addEventListener('click', () => {
      if (!NET.client && state().step === 4) finish(b.dataset.choice);
    });
  return {
    reset,
    update,
    restore,
    snapshot,
    sync,
    interact,
    point,
    ground,
    drawPlan,
    drawScene,
    picture,
  };
})();
