'use strict';

// Static light, materials and architecture share the terrain cache and world coordinates.
const MapScenery = (() => {
  const images = new Map();
  const silhouettes = new Map();
  const surfaces = {
    moss: [0, 0],
    stone: [1, 0],
    glass: [2, 0],
    snow: [0, 1],
    reef: [1, 1],
    earth: [2, 1],
  };
  const cliffs = {
    1: ['#849278', '#4f6053', '#374942'],
    2: ['#c7966c', '#7e5346', '#43363c'],
    3: ['#adbad7', '#6a7293', '#3a455e'],
    4: ['#9b866e', '#534740', '#312f37'],
    5: ['#a8aa82', '#676c55', '#3f4b45'],
    6: ['#c2dae1', '#7a92a2', '#40536b'],
    7: ['#8bb1ab', '#4b777d', '#304e62'],
    8: ['#95816a', '#605046', '#333332'],
  };
  function asset(name) {
    if (!images.has(name)) {
      const img = new Image();
      img.onload = () => {
        Terrain.chunkCache.clear();
        Terrain.chunkJob = null;
      };
      images.set(name, img);
      img.src = 'art/' + name + '.webp';
    }
    const img = images.get(name);
    return img.complete && img.naturalWidth ? img : null;
  }
  function planks(c, tx, ty, x, y, cold) {
    const T = World.T,
      bw = T / 2,
      long = T * 4,
      bases = cold
        ? ['#4a484b', '#504c4e', '#49464b', '#575051']
        : ['#5b493b', '#685342', '#705947', '#604d42'];
    for (let row = 0; row < 2; row++) {
      const boardRow = ty * 2 + row,
        offset = (boardRow * 59) % long,
        worldX = tx * T + offset,
        board = Math.floor(worldX / long);
      const top = y + row * bw,
        joint = long - (worldX % long);
      const wood = (n) => bases[Math.floor(hash2(n + 13, boardRow + 29) * bases.length)];
      c.fillStyle = wood(board);
      c.fillRect(x, top, T, bw);
      if (joint < T) {
        c.fillStyle = wood(board + 1);
        c.fillRect(x + joint, top, T - joint, bw);
        c.fillStyle = '#292827';
        c.fillRect(x + joint, top, 1.3, bw);
      }
      c.fillStyle = '#241e1d8c';
      c.fillRect(x, top + bw - 1, T, 1);
      c.fillStyle = '#c8a07b33';
      c.fillRect(x, top, T, 1.2);
      c.strokeStyle = '#372b273d';
      c.lineWidth = 0.8;
      for (let k = 0; k < 2; k++) {
        const wave = (px) => 2 * Math.sin((tx * T + px) / 68 + boardRow * 1.7 + k);
        const base = top + 6 + k * 7;
        c.beginPath();
        c.moveTo(x, base + wave(0));
        c.quadraticCurveTo(x + T / 2, base + wave(T / 2), x + T, base + wave(T));
        c.stroke();
      }
      if (joint > 1 && joint < T - 2 && !(boardRow % 3)) {
        c.fillStyle = '#262421';
        c.fillRect(x + joint - 3, top + 3, 1.8, 1.8);
      }
    }
  }
  function roomTile(c, img, tx, ty, x, y) {
    const plan = World.landscape.plan;
    const inArea = (a) => tx >= a[0] && tx <= a[2] && ty >= a[1] && ty <= a[3];
    let area = plan.rooms.find(inArea),
      index = plan.rooms.indexOf(area);
    if (index === 1) index = 2;
    else if (index === 2) index = 1;
    if (!area && tx >= 26 && tx <= 34 && ty >= 23 && ty <= 39) {
      area = [26, 23, 34, 39];
      index = 3;
    }
    if (!area || !img) {
      planks(c, tx, ty, x, y, !area || index === 2);
      return;
    }
    const w = img.width / 2,
      h = img.height / 2,
      sw = w / (area[2] - area[0] + 1),
      sh = h / (area[3] - area[1] + 1);
    c.drawImage(
      img,
      (index % 2) * w + (tx - area[0]) * sw,
      Math.floor(index / 2) * h + (ty - area[1]) * sh,
      sw,
      sh,
      x,
      y,
      World.T,
      World.T,
    );
  }
  function material(bi) {
    const ch = World.CHN;
    if (ch === 6 || bi.castleStyle === 'ice' || bi.deco === 'snow') return 'snow';
    if (ch === 7 || bi.deep || bi.reef) return 'reef';
    if (ch === 3 || bi.mirror || bi.neon || bi.abyss) return 'glass';
    if (ch === 2 || bi.floor === 'paving' || bi.floor === 'tiles' || bi.deco === 'desert')
      return 'stone';
    return 'moss';
  }
  // Mirrored world-space patches meet at the same texels across tiles and chunk seams.
  function mosaic(c, img, id, tx, ty, x, y) {
    const [u, v] = surfaces[id],
      count = 12,
      T = World.T,
      tw = img.width / 3,
      th = img.height / 2;
    const flipX = Math.floor(tx / count) % 2 !== 0,
      flipY = Math.floor(ty / count) % 2 !== 0;
    const a = tx % count,
      b = ty % count,
      sw = (tw - 4) / count,
      sh = (th - 4) / count;
    c.save();
    c.translate(x + (flipX ? T : 0), y + (flipY ? T : 0));
    c.scale(flipX ? -1 : 1, flipY ? -1 : 1);
    c.drawImage(
      img,
      u * tw + 2 + (flipX ? count - 1 - a : a) * sw,
      v * th + 2 + (flipY ? count - 1 - b : b) * sh,
      sw,
      sh,
      0,
      0,
      T,
      T,
    );
    c.restore();
  }
  const masks = new Map();
  let roadLayer;
  function roadBits(tx, ty) {
    let bits = 0,
      bit = 1;
    for (let dy = -1; dy <= 1; dy++)
      for (let dx = -1; dx <= 1; dx++, bit <<= 1) {
        const t = World.tileAt(tx + dx, ty + dy);
        if (t === PATH || t === STONE || t === GATE) bits |= bit;
      }
    return bits;
  }
  // Adjacent tiles sample the same continuous field along their edges.
  function roadMask(bits) {
    if (masks.has(bits)) return masks.get(bits);
    const size = World.T,
      canvas = makeCanvas(size, size),
      ctx = canvas.getContext('2d'),
      pixels = ctx.createImageData(size, size);
    const value = (x, y) => (bits >> (y * 3 + x)) & 1;
    for (let y = 0; y < size; y++)
      for (let x = 0; x < size; x++) {
        const u = 0.5 + (x + 0.5) / size,
          v = 0.5 + (y + 0.5) / size,
          a = Math.floor(u),
          b = Math.floor(v),
          f = u - a,
          g = v - b;
        const density =
          (1 - g) * (value(a, b) * (1 - f) + value(a + 1, b) * f) +
          g * (value(a, b + 1) * (1 - f) + value(a + 1, b + 1) * f);
        const t = clamp((density - 0.15) / 0.7, 0, 1);
        pixels.data[4 * (y * size + x) + 3] = Math.round(255 * t * t * (3 - 2 * t));
      }
    ctx.putImageData(pixels, 0, 0);
    masks.set(bits, canvas);
    return canvas;
  }
  function tile(c, tx, ty, x, y, t, b) {
    if (ty >= World.PLAY_H || !(World.isGround(t) || t === FLOOR || t === PATH || t === STONE))
      return false;
    const T = World.T,
      site = World.landscape;
    if (site && site.mask[ty * World.MW + tx] === Landscapes.BRIDGE) return false;
    if (World.CFG.narrative && site) {
      roomTile(c, asset('dawn-rooms'), tx, ty, x, y);
      return true;
    }
    const bi = BIOMES[b],
      indoor =
        World.CHN === 4 ||
        (World.CHN === 5 && ['boards', 'parquet', 'checker', 'carpet'].includes(bi.floor));
    if (indoor) {
      planks(c, tx, ty, x, y, World.CHN === 4 && bi.floor !== 'carpet');
      return true;
    }
    const img = asset('terrain-materials');
    if (!img) return false;
    const ground = t === FLOOR ? (bi.mirror || bi.neon ? 'glass' : 'stone') : material(bi);
    mosaic(c, img, ground, tx, ty, x, y);
    // Preserve local biome tones under the common light direction.
    c.globalAlpha = 0.18;
    c.fillStyle = bi.ground[0];
    c.fillRect(x, y, T, T);
    c.globalAlpha = 1;
    if (t === FLOOR) return true;
    const bits = roadBits(tx, ty);
    if (!bits) return true;
    if (!roadLayer) roadLayer = makeCanvas(T, T);
    const layer = roadLayer.getContext('2d');
    const path = ground === 'moss' ? 'earth' : ground;
    mosaic(layer, img, path, tx, ty, 0, 0);
    layer.fillStyle =
      ground === 'snow'
        ? '#d6e7f13a'
        : ground === 'reef'
          ? '#d3c9a735'
          : ground === 'glass'
            ? '#ddceea20'
            : '#bea57c22';
    layer.fillRect(0, 0, T, T);
    if (bits !== 511) {
      layer.globalCompositeOperation = 'destination-in';
      layer.drawImage(roadMask(bits), 0, 0);
      layer.globalCompositeOperation = 'source-over';
    }
    c.drawImage(roadLayer, x, y);
    return true;
  }
  function exterior(c, tx, ty, x, y, t) {
    if (
      !World.CFG.narrative ||
      t !== ROCK ||
      !World.landscape ||
      World.landscape.mask[ty * World.MW + tx] !== Landscapes.OUT
    )
      return false;
    const img = asset('terrain-materials');
    if (img) mosaic(c, img, 'moss', tx, ty, x, y);
    c.fillStyle = img ? 'rgba(15,27,32,.89)' : '#1a252b';
    c.fillRect(x, y, World.T, World.T);
    return true;
  }
  function furniture(c, fixture) {
    const img = asset('dawn-rooms');
    if (!img) return;
    const area = World.landscape.plan.rooms[fixture.room],
      col = fixture.room === 2 ? 1 : 0,
      row = fixture.room === 1 ? 1 : 0;
    const w = (area[2] - area[0] + 1) * World.T,
      h = (area[3] - area[1] + 1) * World.T;
    c.save();
    c.translate(area[0] * World.T, area[1] * World.T);
    c.beginPath();
    fixture.outline.forEach(([u, v], i) => (i ? c.lineTo(u * w, v * h) : c.moveTo(u * w, v * h)));
    c.closePath();
    c.clip();
    c.drawImage(
      img,
      (col * img.width) / 2,
      (row * img.height) / 2,
      img.width / 2,
      img.height / 2,
      0,
      0,
      w,
      h,
    );
    c.restore();
  }
  function sceneryItems(list, vis) {
    if (!World.CFG.narrative) return;
    for (const fixture of DawnChapter.furniture) {
      const r = World.landscape.plan.rooms[fixture.room],
        x = ((fixture.solid[0] + fixture.solid[2] + 1) * World.T) / 2;
      const y = (r[1] + fixture.foot * (1 + r[3] - r[1])) * World.T;
      if (vis(x, y, 290)) list.push({ y, fixture });
    }
  }
  function treeShadow(c, tr, bx, by) {
    const sprite = TREE_SPR[tr.kind];
    if (!sprite) return;
    if (!silhouettes.has(tr.kind)) {
      const pic = makeCanvas(66, 86),
        p = pic.getContext('2d');
      p.drawImage(sprite, 0, 0, 66, 86);
      p.globalCompositeOperation = 'source-in';
      const ink = p.createLinearGradient(0, 0, 0, 86);
      ink.addColorStop(0, '#1723229c');
      ink.addColorStop(1, '#172322e0');
      p.fillStyle = ink;
      p.fillRect(0, 0, 66, 86);
      silhouettes.set(tr.kind, pic);
    }
    const w = 64 * tr.s,
      h = 84 * tr.s;
    c.save();
    c.translate(tr.x - bx * World.T, tr.y - by * World.T);
    c.transform(0.94, 0.06, -0.6, -0.38, 0, 0);
    c.globalAlpha = 0.43;
    c.drawImage(silhouettes.get(tr.kind), -w / 2, -h + 4 * tr.s, w, h);
    c.restore();
  }
  function chunk(c, bx, by, size) {
    const T = World.T,
      layout = World.landscape,
      tones = cliffs[World.CHN] || cliffs[2];
    const maskAt = (x, y) =>
      x >= 0 &&
      y >= 0 &&
      x < World.MW &&
      y < World.PLAY_H &&
      layout.mask[y * World.MW + x] !== Landscapes.OUT;
    for (let ty = Math.max(0, by - 2); ty < Math.min(by + size + 2, World.PLAY_H); ty++) {
      for (let tx = Math.max(0, bx - 3); tx < Math.min(bx + size + 2, World.MW); tx++) {
        const cell = ty * World.MW + tx,
          x = (tx - bx) * T,
          y = (ty - by) * T,
          n = World.tileAt(tx, ty - 1);
        if (layout && !maskAt(tx, ty) && maskAt(tx, ty - 1) && World.tiles[cell] === ROCK) {
          const h = (q) => 13 + 3 * Math.sin(q * 0.65) + 2 * Math.sin(q * 1.71),
            h0 = h(tx),
            h1 = h(tx + 1);
          const face = c.createLinearGradient(0, y, 0, y + 22);
          face.addColorStop(0, tones[1]);
          face.addColorStop(0.7, tones[2]);
          face.addColorStop(1, '#1b2631');
          c.fillStyle = face;
          c.beginPath();
          c.moveTo(x, y - 1);
          c.lineTo(x + T, y - 1);
          c.lineTo(x + T, y + h1);
          c.lineTo(x, y + h0);
          c.fill();
          c.strokeStyle = tones[0];
          c.lineWidth = 2.4;
          c.beginPath();
          c.moveTo(x, y);
          c.lineTo(x + T, y);
          c.stroke();
          c.strokeStyle = '#18202c59';
          c.lineWidth = 1;
          c.beginPath();
          c.moveTo(x + T * 0.34, y + 3);
          c.lineTo(x + T * 0.29, y + h0 * 0.77);
          c.lineTo(x + T * 0.25, y + h0);
          c.stroke();
        } else if (
          (World.isGround(World.tiles[cell]) ||
            World.tiles[cell] === PATH ||
            World.tiles[cell] === FLOOR) &&
          (n === ROCK || n === WALL)
        ) {
          const contact = c.createLinearGradient(0, y, 0, y + 13);
          contact.addColorStop(0, '#101b2482');
          contact.addColorStop(1, '#101b2400');
          c.fillStyle = contact;
          c.fillRect(x, y, T, 13);
        }
        const i = World.treeGrid[cell];
        if (i) treeShadow(c, World.trees[i - 1], bx, by);
      }
    }
  }
  return { tile, chunk, exterior, sceneryItems, furniture };
})();
