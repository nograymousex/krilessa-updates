'use strict';
// =====================================================================
//  Звук: всё синтезируется на лету через WebAudio (никаких файлов).
// =====================================================================
const Sound = (() => {
  let ctx = null, master = null, sfxBus = null, musicBus = null;
  let echoBus = null, revSend = null, dlySend = null, dly = null; // объём для музыки: реверберация и эхо
  let enabled = true;
  try { enabled = localStorage.getItem('krilessa_sound') !== 'off'; } catch (e) { /* нет хранилища */ }
  const lastPlayed = {};

  function init() {
    if (ctx) { if (ctx.state === 'suspended') ctx.resume(); return; }
    try {
      const AC = window.AudioContext || window.webkitAudioContext;
      // «balanced» – буфер чуть больше: на слабых телефонах музыка не трещит от недогруза
      try { ctx = new AC({ latencyHint: 'balanced' }); } catch (e) { ctx = new AC(); }
      master = ctx.createGain(); master.gain.value = enabled ? 0.8 : 0; master.connect(ctx.destination);
      sfxBus = ctx.createGain(); sfxBus.gain.value = 0.55; sfxBus.connect(master);
      musicBus = ctx.createGain(); musicBus.gain.value = 0.2; musicBus.connect(master);
      fxInit();
    } catch (e) { ctx = null; }
  }
  // Реверберация – свёртка с затухающим шумом (как эхо в зале), эхо – задержка с обратной связью.
  function fxInit() {
    try {
      // хвост «темнеет» со временем (как в настоящем зале): без шипящего белого шума и зерна; короче – легче для телефона
      const sr = ctx.sampleRate, len = Math.floor(sr * 1.4), pre = Math.floor(sr * 0.012), ir = ctx.createBuffer(2, len, sr);
      for (let ch = 0; ch < 2; ch++) {
        const d = ir.getChannelData(ch); let y = 0, y2 = 0;
        for (let i = pre; i < len; i++) {
          const k = (i - pre) / (len - pre), cf = 0.75 - 0.62 * Math.sqrt(k); // чем дальше – тем мягче
          y += ((Math.random() * 2 - 1) - y) * cf; y2 += (y - y2) * cf;
          d[i] = y2 * Math.pow(1 - k, 2.4) * (i - pre < 240 ? (i - pre) / 240 : 1);
        }
      }
      const conv = ctx.createConvolver(); conv.buffer = ir;
      revSend = ctx.createGain(); revSend.gain.value = 0;
      const revOut = ctx.createGain(); revOut.gain.value = 0.8;
      musicBus.connect(revSend); revSend.connect(conv); conv.connect(revOut); revOut.connect(master);
      echoBus = ctx.createGain(); echoBus.connect(musicBus);
      dly = ctx.createDelay(1.5); const fb = ctx.createGain(); fb.gain.value = 0.34;
      const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 2600;
      dlySend = ctx.createGain(); dlySend.gain.value = 0;
      echoBus.connect(dlySend); dlySend.connect(dly); dly.connect(lp); lp.connect(fb); fb.connect(dly); lp.connect(musicBus);
    } catch (e) { echoBus = musicBus; }
  }

  function throttle(name, ms) {
    const now = performance.now();
    if (lastPlayed[name] && now - lastPlayed[name] < ms) return true;
    lastPlayed[name] = now;
    return false;
  }

  function tone(freq, dur, type = 'square', vol = 0.2, slide = 0, delay = 0, bus = sfxBus) {
    if (!ctx || !enabled) return;
    const t = ctx.currentTime + delay;
    const o = ctx.createOscillator(), g = ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, t);
    if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(30, freq + slide), t + dur);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol, t + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(bus);
    o.start(t); o.stop(t + dur + 0.05);
  }

  let noiseBuf = null;
  function noise(dur, vol = 0.2, freq = 1200, delay = 0, q = 0.8) {
    if (!ctx || !enabled) return;
    if (!noiseBuf) {
      noiseBuf = ctx.createBuffer(1, ctx.sampleRate, ctx.sampleRate);
      const d = noiseBuf.getChannelData(0);
      for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    }
    const t = ctx.currentTime + delay;
    const s = ctx.createBufferSource(); s.buffer = noiseBuf;
    const f = ctx.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = freq; f.Q.value = q;
    const g = ctx.createGain();
    g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(f); f.connect(g); g.connect(sfxBus);
    s.start(t); s.stop(t + dur + 0.05);
  }

  // «мяу»: пила через полосовой фильтр, «м-я-у» = рост и спад высоты + раскрытие фильтра
  function meow() {
    if (!ctx || !enabled) return;
    const t = ctx.currentTime, dur = 0.75;
    const o = ctx.createOscillator(), o2 = ctx.createOscillator(), f = ctx.createBiquadFilter(), g = ctx.createGain();
    o.type = 'sawtooth'; o2.type = 'triangle';
    const pitch = 560 + Math.random() * 120;
    for (const osc of [o, o2]) {
      osc.frequency.setValueAtTime(pitch * 0.8, t);
      osc.frequency.exponentialRampToValueAtTime(pitch * 1.45, t + 0.22);
      osc.frequency.exponentialRampToValueAtTime(pitch * 0.95, t + 0.55);
      osc.frequency.exponentialRampToValueAtTime(pitch * 0.7, t + dur);
    }
    o2.detune.value = 8;
    f.type = 'bandpass'; f.Q.value = 3.5;
    f.frequency.setValueAtTime(700, t); f.frequency.exponentialRampToValueAtTime(2200, t + 0.25); f.frequency.exponentialRampToValueAtTime(900, t + dur);
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.35, t + 0.06);
    g.gain.setValueAtTime(0.3, t + 0.45); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(f); o2.connect(f); f.connect(g); g.connect(sfxBus);
    o.start(t); o2.start(t); o.stop(t + dur + 0.05); o2.stop(t + dur + 0.05);
  }

  const sfx = {
    shoot() { if (throttle('shoot', 70)) return; tone(1200 + Math.random() * 200, 0.06, 'triangle', 0.05, -500); },
    hit() { if (throttle('hit', 45)) return; tone(300 + Math.random() * 80, 0.07, 'square', 0.05, -150); },
    die() { if (throttle('die', 60)) return; noise(0.15, 0.12, 900); tone(500, 0.12, 'triangle', 0.06, -300); },
    gem() { if (throttle('gem', 40)) return; tone(1500 + Math.random() * 400, 0.07, 'sine', 0.06, 300); },
    heart() { tone(660, 0.1, 'sine', 0.12); tone(990, 0.15, 'sine', 0.12, 0, 0.08); },
    hurt() { if (throttle('hurt', 120)) return; tone(180, 0.2, 'sawtooth', 0.14, -90); noise(0.12, 0.12, 500); },
    dash() { noise(0.22, 0.18, 2200, 0, 0.5); tone(500, 0.18, 'sine', 0.06, 700); },
    level() { [523, 659, 784, 1047].forEach((f, i) => tone(f, 0.18, 'square', 0.08, 0, i * 0.08)); },
    chest() { [392, 523, 659, 784, 1047].forEach((f, i) => tone(f, 0.15, 'triangle', 0.1, 0, i * 0.06)); },
    roar() { tone(110, 0.8, 'sawtooth', 0.18, -60); noise(0.7, 0.16, 300, 0, 0.6); },
    boom() { noise(0.5, 0.3, 200, 0, 0.5); tone(90, 0.5, 'sine', 0.25, -50); },
    bolt() { if (throttle('bolt', 90)) return; noise(0.18, 0.14, 3000, 0, 0.4); tone(1800, 0.1, 'sawtooth', 0.04, -1400); },
    enemyShot() { if (throttle('eshot', 90)) return; tone(420, 0.09, 'sine', 0.04, -200); },
    magic() { for (let i = 0; i < 6; i++) tone(900 + i * 220, 0.25, 'sine', 0.06, 200, i * 0.07); },
    gate() { tone(80, 1.2, 'sawtooth', 0.12, 40); noise(1.0, 0.12, 400); },
    win() { [523, 659, 784, 1047, 784, 1047, 1319].forEach((f, i) => tone(f, 0.25, 'square', 0.09, 0, i * 0.13)); },
    click() { tone(1350, 0.05, 'triangle', 0.06, -450); tone(2700, 0.03, 'sine', 0.025); },
    fuse() { if (throttle('fuse', 150)) return; tone(900, 0.5, 'square', 0.05, 900); },
    block() { if (throttle('block', 80)) return; tone(1400, 0.08, 'triangle', 0.08, -600); noise(0.06, 0.08, 4000); },
    shard() { if (throttle('shard', 60)) return; tone(1100, 0.08, 'sine', 0.08, 0); tone(1650, 0.12, 'sine', 0.07, 0, 0.05); },
    stage() { tone(220, 0.6, 'sawtooth', 0.15, 220); tone(110, 0.9, 'square', 0.12, -40, 0.1); noise(0.8, 0.18, 600, 0, 0.4); },
    laser() { tone(300, 1.2, 'sawtooth', 0.07, 900); },
    fireball() { if (throttle('fireball', 90)) return; noise(0.12, 0.08, 900, 0, 0.7); tone(220, 0.1, 'triangle', 0.05, -100); },
    blink() { tone(1400, 0.15, 'sine', 0.08, -900); noise(0.15, 0.12, 2500, 0, 0.6); },
    nova() { noise(0.9, 0.3, 300, 0, 0.4); tone(70, 0.8, 'sawtooth', 0.2, 200); [523, 784, 1047].forEach((f, i) => tone(f, 0.3, 'square', 0.06, 0, 0.1 + i * 0.06)); },
    superReady() { [784, 988, 1175, 1568].forEach((f, i) => tone(f, 0.12, 'triangle', 0.08, 0, i * 0.05)); },
    event() { [392, 494, 587, 784].forEach((f, i) => tone(f, 0.14, 'sawtooth', 0.07, 0, i * 0.06)); noise(0.3, 0.1, 1200, 0.2, 0.6); },
    staticNoise() { noise(0.6, 0.3, 3000, 0, 0.2); tone(60, 0.5, 'sawtooth', 0.15, -20); },
    shatter() { for (let i = 0; i < 14; i++) tone(1500 + Math.random() * 3500, 0.3, 'sine', 0.06, -1000, i * 0.025); noise(0.9, 0.35, 6000, 0, 0.4); tone(55, 1, 'sawtooth', 0.2, -30); },
    meteor() { if (throttle('meteor', 120)) return; noise(0.5, 0.2, 300, 0, 0.5); tone(80, 0.4, 'sine', 0.2, -40); },
    meow,
    claw() { if (throttle('claw', 80)) return; noise(0.08, 0.1, 5000, 0, 1.5); tone(900 + Math.random() * 200, 0.06, 'triangle', 0.04, -500); },
    pounce() { noise(0.15, 0.14, 2500, 0, 0.8); tone(400, 0.15, 'sine', 0.08, 500); },
    purr() { for (let i = 0; i < 10; i++) tone(55 + Math.random() * 6, 0.12, 'sawtooth', 0.06, 0, i * 0.1); tone(330, 0.6, 'sine', 0.05, 220, 0.2); },
    nap() { [784, 659, 523, 659, 784].forEach((f, i) => tone(f, 0.3, 'sine', 0.07, 0, i * 0.18)); },
    clue() { [988, 1319, 1568].forEach((f, i) => tone(f, 0.12, 'triangle', 0.08, 0, i * 0.06)); },
    whisper() { if (throttle('whisper', 1500)) return; noise(1.2, 0.08, 1800, 0, 6); noise(0.9, 0.06, 900, 0.3, 8); },
    glass() { for (let i = 0; i < 6; i++) tone(2000 + Math.random() * 2500, 0.25, 'sine', 0.05, -800, i * 0.03); noise(0.4, 0.2, 5000, 0, 0.5); },
  };

  // ---------------- музыка ----------------
  const N = n => 440 * Math.pow(2, (n - 69) / 12); // MIDI -> Гц
  // ---- «живые» инструменты для главной темы ----
  function envG(g, t, a, peak, dur, rel) {
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(peak, t + a);
    g.gain.setValueAtTime(peak, t + Math.max(a, dur - rel)); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  }
  function pad(notes, dur, delay, vol) { // тёплый пэд: две чуть расстроенные пилы через мягкий фильтр
    if (!ctx || !enabled) return;
    const t = ctx.currentTime + delay, f = ctx.createBiquadFilter(), g = ctx.createGain();
    f.type = 'lowpass'; f.Q.value = 0.6;
    f.frequency.setValueAtTime(650, t); f.frequency.linearRampToValueAtTime(1250, t + dur * 0.5); f.frequency.linearRampToValueAtTime(750, t + dur);
    envG(g, t, Math.min(0.7, dur * 0.3), vol, dur, Math.min(1.0, dur * 0.4));
    f.connect(g); g.connect(musicBus);
    for (const n of notes) for (const dt of [-8, 8]) {
      const o = ctx.createOscillator(); o.type = 'sawtooth'; o.frequency.value = N(n); o.detune.value = dt;
      o.connect(f); o.start(t); o.stop(t + dur + 0.05);
    }
  }
  function bell(n, delay, vol, len = 1.3) { // музыкальная шкатулка: синус + обертоны, быстрый удар и долгое затухание
    if (!ctx || !enabled) return;
    const t = ctx.currentTime + delay, g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + 0.004); g.gain.exponentialRampToValueAtTime(0.0001, t + len);
    g.connect(echoBus || musicBus);
    for (const [m, v] of [[1, 1], [2, 0.26], [3.01, 0.1]]) {
      const o = ctx.createOscillator(), og = ctx.createGain(); o.type = 'sine'; o.frequency.value = N(n) * m; og.gain.value = v;
      o.connect(og); og.connect(g); o.start(t); o.stop(t + len + 0.05);
    }
  }
  function flute(n, dur, delay, vol) { // флейта: треугольник с вибрато и лёгким «вдохом»
    if (!ctx || !enabled) return;
    const t = ctx.currentTime + delay, f0 = N(n);
    const o = ctx.createOscillator(), o2 = ctx.createOscillator(), o2g = ctx.createGain(), lfo = ctx.createOscillator(), lg = ctx.createGain();
    const f = ctx.createBiquadFilter(), g = ctx.createGain();
    o.type = 'triangle'; o.frequency.value = f0; o2.type = 'sine'; o2.frequency.value = f0 * 2; o2g.gain.value = 0.12;
    lfo.frequency.value = 5.3; lg.gain.setValueAtTime(0, t); lg.gain.linearRampToValueAtTime(f0 * 0.011, t + Math.min(0.4, dur * 0.6));
    lfo.connect(lg); lg.connect(o.frequency); lg.connect(o2.frequency);
    f.type = 'lowpass'; f.frequency.value = 3200;
    envG(g, t, 0.07, vol, dur, Math.min(0.2, dur * 0.4));
    o.connect(f); o2.connect(o2g); o2g.connect(f); f.connect(g); g.connect(echoBus || musicBus);
    for (const x of [o, o2, lfo]) { x.start(t); x.stop(t + dur + 0.05); }
    noiseHit(0.08, 0.018, 2600, delay); // вдох
  }
  function bassNote(n, dur, delay, vol) { // мягкий бас: синус + треугольник октавой выше
    if (!ctx || !enabled) return;
    const t = ctx.currentTime + delay, g = ctx.createGain();
    envG(g, t, 0.02, vol, dur, Math.min(0.25, dur * 0.5)); g.connect(musicBus);
    for (const [m, v, ty] of [[1, 1, 'sine'], [2, 0.22, 'triangle']]) {
      const o = ctx.createOscillator(), og = ctx.createGain(); o.type = ty; o.frequency.value = N(n) * m; og.gain.value = v;
      o.connect(og); og.connect(g); o.start(t); o.stop(t + dur + 0.05);
    }
  }
  // Главная тема «Карта приключений»: ля минор, 88 ударов. 16 тактов по 8 восьмых:
  // A – шкатулка с пэдом и басом (с 5-го такта – шейкер и мягкая бочка), B – вступает флейта с мелодией.
  const CH = { Am: [57, 60, 64], F: [53, 57, 60], C: [55, 60, 64], G: [55, 59, 62], Dm: [53, 57, 62], E: [56, 59, 64], Em: [55, 59, 64] };
  const ROOT = { Am: 45, F: 41, C: 48, G: 43, Dm: 50, E: 40, Em: 40 };
  const MENU_BARS = ['Am', 'F', 'C', 'G', 'Am', 'F', 'Dm', 'E', 'F', 'G', 'Em', 'Am', 'Dm', 'G', 'C', 'E'];
  const ARP = [0, 1, 2, 3, 2, 1, 2, 1];
  const MELODY = [ // [восьмая от начала части B, нота, длина в восьмых]
    [0, 69, 2], [2, 72, 2], [4, 77, 3], [7, 76, 1], [8, 74, 3], [11, 71, 1], [12, 67, 2], [14, 71, 2],
    [16, 76, 3], [19, 74, 1], [20, 71, 2], [22, 67, 2], [24, 69, 6], [30, 72, 1], [31, 74, 1],
    [32, 77, 2], [34, 76, 2], [36, 74, 2], [38, 69, 2], [40, 71, 2], [42, 74, 2], [44, 79, 3], [47, 77, 1],
    [48, 76, 3], [51, 74, 1], [52, 72, 2], [54, 76, 2], [56, 68, 2], [58, 71, 2], [60, 76, 4]];
  const TWINKLE = [84, 86, 88, 91, 93, 96];
  function menuStep(st, d, sd) {
    const pos = st % 128, bar = pos >> 3, s8 = pos & 7, chName = MENU_BARS[bar], ch = CH[chName], root = ROOT[chName], partB = bar >= 8;
    if (s8 === 0) pad(ch, sd * 8 + 0.4, d, partB ? 0.034 : 0.03);
    // бас: корень, повтор, квинта, октава
    if (s8 === 0) bassNote(root, sd * 2.6, d, 0.3);
    if (s8 === 3) bassNote(root, sd * 0.9, d, 0.2);
    if (s8 === 4) bassNote(root + 7, sd * 1.8, d, 0.24);
    if (s8 === 6 && (bar & 1)) bassNote(root + 12, sd * 1.5, d, 0.18);
    // шкатулка: арпеджио по аккорду на две октавы выше
    const tones = [ch[0] + 12, ch[1] + 12, ch[2] + 12, ch[0] + 24];
    bell(tones[ARP[s8]], d, partB ? 0.045 : 0.07, partB ? 0.9 : 1.3);
    // перкуссия с 5-го такта
    if (bar >= 4) {
      if (s8 === 0 || (s8 === 4 && partB)) tone(92, 0.2, 'sine', 0.22, -44, d, musicBus);
      noiseHit(0.045, s8 & 1 ? 0.032 : 0.018, 6500, d);
      if (partB && s8 === 4) noiseHit(0.09, 0.05, 1800, d); // мягкий хлопок
    }
    // флейта во второй части
    if (partB) { const p = pos - 64; for (const [at, n, len] of MELODY) if (at === p) flute(n, sd * len * 0.95, d, 0.12); }
    // искорки
    if (s8 === 5 && hashStep(st) < 0.3) bell(TWINKLE[Math.floor(hashStep(st + 7) * TWINKLE.length)], d + sd * 0.5, 0.035, 2);
  }
  const hashStep = x => { const v = Math.sin(x * 127.1 + 311.7) * 43758.5453; return v - Math.floor(v); };
  const SONGS = {
    field: { bpm: 116, bass: [45, 0, 52, 0, 41, 0, 48, 0, 43, 0, 50, 0, 40, 0, 47, 0],
      lead: [69, 0, 72, 74, 76, 0, 74, 72, 69, 0, 67, 69, 72, 0, 0, 0, 65, 0, 69, 72, 74, 0, 72, 69, 67, 0, 64, 67, 69, 0, 0, 0] },
    boss: { bpm: 150, bass: [40, 40, 52, 40, 41, 41, 53, 41, 40, 40, 52, 40, 43, 43, 55, 42],
      lead: [76, 0, 75, 76, 79, 0, 76, 0, 77, 0, 76, 74, 72, 0, 71, 0, 76, 0, 75, 76, 83, 0, 79, 0, 77, 76, 74, 72, 71, 72, 74, 0] },
    menu: { bpm: 88, rich: menuStep, rev: 0.36, echo: 0.28 },
    field2: { bpm: 132, drums: true, bass: [41, 0, 41, 48, 0, 41, 46, 0, 39, 0, 39, 46, 0, 39, 44, 0],
      lead: [65, 0, 68, 70, 72, 0, 70, 68, 65, 0, 63, 65, 68, 0, 0, 0, 72, 0, 75, 72, 70, 0, 68, 70, 72, 0, 77, 75, 72, 0, 0, 0] },
    final: { bpm: 140, drums: true, disco: true, bass: [45, 57, 45, 57, 43, 55, 43, 55, 41, 53, 41, 53, 40, 52, 44, 56],
      lead: [81, 0, 79, 81, 84, 0, 81, 0, 79, 76, 0, 74, 76, 0, 0, 0, 81, 0, 84, 86, 88, 0, 86, 84, 81, 0, 79, 81, 76, 0, 0, 0] },
    field3: { bpm: 124, drums: true, bass: [38, 0, 50, 0, 41, 0, 53, 0, 43, 0, 55, 0, 45, 0, 57, 0],
      lead: [74, 77, 81, 0, 79, 77, 74, 0, 72, 74, 77, 0, 76, 74, 72, 0, 74, 77, 81, 84, 86, 0, 84, 81, 79, 0, 77, 79, 81, 0, 0, 0] },
    final2: { bpm: 152, drums: true, disco: true, bass: [40, 52, 40, 52, 43, 55, 43, 55, 45, 57, 45, 57, 47, 59, 47, 59],
      lead: [88, 0, 86, 88, 91, 0, 88, 0, 86, 83, 0, 81, 83, 0, 79, 0, 88, 91, 93, 0, 91, 88, 86, 0, 84, 86, 88, 0, 91, 0, 95, 0] },
    win: { bpm: 126, bass: [48, 0, 55, 0, 53, 0, 55, 0, 48, 0, 55, 0, 50, 0, 55, 0],
      lead: [72, 76, 79, 84, 79, 76, 72, 0, 74, 77, 81, 86, 81, 77, 74, 0, 72, 76, 79, 84, 88, 0, 84, 0, 79, 0, 84, 0, 0, 0, 0, 0] },
    // ---- тематическая музыка локаций ----
    swamp: { bpm: 92, drums: 'soft', lw: 'triangle', bw: 'sawtooth', bv: 0.22, bass: [38, 0, 0, 0, 38, 0, 45, 0, 36, 0, 0, 0, 36, 0, 43, 0],
      lead: [62, 0, 65, 0, 67, 0, 69, 0, 67, 0, 65, 0, 62, 0, 0, 0, 60, 0, 62, 0, 65, 0, 64, 0, 62, 0, 0, 0, 57, 0, 0, 0] },
    snow: { bpm: 96, drums: 'none', lw: 'sine', chime: true, lv: 0.2, bass: [52, 0, 0, 0, 0, 0, 0, 0, 49, 0, 0, 0, 0, 0, 0, 0],
      lead: [88, 0, 83, 0, 80, 0, 83, 0, 85, 0, 0, 0, 80, 0, 0, 0, 88, 0, 90, 0, 92, 0, 88, 0, 83, 0, 0, 0, 0, 0, 0, 0] },
    dark: { bpm: 100, drums: 'toms', lw: 'sawtooth', lv: 0.08, bass: [48, 0, 48, 0, 51, 0, 48, 0, 44, 0, 44, 0, 43, 0, 43, 0],
      lead: [72, 0, 71, 72, 75, 0, 72, 0, 68, 0, 67, 0, 71, 0, 0, 0, 72, 0, 74, 75, 77, 0, 75, 74, 72, 0, 71, 0, 67, 0, 0, 0] },
    meadow: { bpm: 128, drums: 'four', lw: 'square', bass: [43, 0, 50, 0, 43, 0, 50, 0, 48, 0, 55, 0, 50, 0, 57, 0],
      lead: [67, 71, 74, 0, 72, 71, 69, 0, 67, 0, 71, 0, 74, 0, 0, 0, 76, 74, 72, 0, 71, 69, 67, 0, 69, 71, 72, 0, 71, 0, 0, 0] },
    desert: { bpm: 112, drums: 'darbuka', lw: 'triangle', lv: 0.2, bass: [40, 0, 0, 40, 0, 0, 40, 0, 41, 0, 0, 41, 0, 0, 40, 0],
      lead: [64, 65, 68, 0, 69, 68, 65, 64, 0, 0, 64, 0, 71, 0, 0, 0, 72, 71, 69, 68, 0, 65, 64, 0, 65, 68, 65, 64, 0, 0, 0, 0] },
    volcano: { bpm: 144, drums: 'toms', lw: 'sawtooth', bw: 'sawtooth', lv: 0.1, bv: 0.3, bass: [38, 38, 50, 38, 38, 50, 41, 43, 38, 38, 50, 38, 36, 36, 48, 36],
      lead: [74, 0, 74, 77, 0, 74, 72, 0, 69, 0, 72, 0, 74, 0, 0, 0, 77, 0, 77, 81, 0, 77, 76, 0, 74, 72, 69, 0, 74, 0, 0, 0] },
    crystal: { bpm: 110, drums: 'soft', lw: 'sine', chime: true, lv: 0.18, bass: [54, 0, 0, 0, 0, 0, 0, 0, 52, 0, 0, 0, 0, 0, 0, 0],
      lead: [78, 82, 85, 90, 85, 82, 78, 0, 80, 84, 87, 92, 87, 84, 80, 0, 78, 82, 85, 90, 92, 90, 85, 82, 84, 0, 80, 0, 78, 0, 0, 0] },
    glitch: { bpm: 150, drums: 'chip', lw: 'square', glitch: true, stacc: true, bass: [36, 48, 36, 48, 39, 51, 39, 51, 41, 53, 41, 53, 43, 55, 43, 55],
      lead: [72, 75, 79, 72, 75, 79, 84, 0, 82, 79, 75, 0, 77, 0, 75, 0, 72, 75, 79, 84, 87, 0, 84, 79, 82, 0, 79, 0, 75, 77, 79, 0] },
    candy: { bpm: 136, drums: 'four', lw: 'sine', stacc: true, lv: 0.22, bass: [48, 0, 55, 0, 52, 0, 55, 0, 53, 0, 57, 0, 55, 0, 59, 0],
      lead: [72, 0, 76, 0, 79, 0, 84, 0, 83, 0, 79, 0, 76, 0, 0, 0, 77, 0, 81, 0, 84, 0, 86, 0, 84, 0, 79, 0, 72, 0, 0, 0] },
    sky: { bpm: 100, drums: 'soft', lw: 'sine', chime: true, lv: 0.2, bass: [53, 0, 0, 0, 0, 0, 0, 0, 55, 0, 0, 0, 0, 0, 0, 0],
      lead: [77, 0, 0, 0, 81, 0, 0, 0, 83, 0, 84, 0, 81, 0, 0, 0, 77, 0, 79, 0, 81, 0, 83, 0, 84, 0, 0, 0, 0, 0, 0, 0] },
    toxic: { bpm: 140, drums: 'trap', lw: 'square', bw: 'sawtooth', bv: 0.32, wobble: true, bass: [43, 43, 0, 43, 46, 0, 43, 0, 41, 41, 0, 41, 38, 0, 41, 0],
      lead: [67, 0, 0, 70, 0, 67, 0, 0, 74, 0, 72, 0, 70, 0, 0, 0, 67, 0, 0, 70, 0, 72, 0, 74, 75, 0, 74, 0, 72, 70, 0, 0] },
    mirror: { bpm: 132, drums: 'waltz', lw: 'sine', chime: true, lv: 0.2, bass: [45, 0, 0, 52, 0, 0, 41, 0, 0, 48, 0, 0],
      lead: [81, 0, 84, 0, 88, 0, 86, 0, 84, 0, 81, 0, 77, 0, 81, 0, 84, 0, 83, 0, 0, 0, 0, 0] },
    // ---- глава 4: ночь глитчей ----
    night4: { bpm: 84, drums: 'waltz', lw: 'sine', chime: true, lv: 0.16, bass: [45, 0, 0, 52, 0, 0, 41, 0, 0, 48, 0, 0],
      lead: [76, 0, 74, 0, 72, 0, 71, 0, 72, 0, 74, 0, 76, 0, 0, 0, 72, 0, 69, 0, 0, 0, 0, 0] },
    hall4: { bpm: 70, drums: 'soft', lw: 'triangle', lv: 0.13, bass: [40, 0, 0, 0, 0, 0, 0, 0, 41, 0, 0, 0, 0, 0, 0, 0],
      lead: [0, 0, 76, 0, 0, 0, 75, 0, 0, 0, 0, 0, 71, 0, 0, 0, 0, 0, 76, 0, 0, 0, 77, 0, 0, 0, 0, 0, 70, 0, 0, 0] },
    tv4: { bpm: 120, drums: 'chip', lw: 'square', glitch: true, stacc: true, lv: 0.1, bass: [33, 33, 0, 33, 36, 0, 33, 0, 32, 32, 0, 32, 31, 0, 32, 0],
      lead: [69, 0, 0, 72, 0, 71, 0, 0, 68, 0, 0, 0, 0, 0, 0, 0, 69, 0, 0, 72, 0, 75, 0, 74, 72, 0, 71, 0, 68, 0, 0, 0] },
    bath4: { bpm: 90, drums: 'soft', lw: 'sine', chime: true, lv: 0.16, bass: [38, 0, 0, 0, 45, 0, 0, 0, 41, 0, 0, 0, 40, 0, 0, 0],
      lead: [86, 0, 0, 81, 0, 0, 0, 0, 84, 0, 0, 79, 0, 0, 0, 0, 86, 0, 0, 81, 0, 0, 77, 0, 76, 0, 0, 0, 0, 0, 0, 0] },
    meowboss: { bpm: 160, drums: 'trap', lw: 'square', glitch: true, bw: 'sawtooth', bv: 0.3, lv: 0.1, bass: [33, 33, 45, 33, 36, 36, 48, 36, 32, 32, 44, 32, 31, 31, 43, 35],
      lead: [81, 80, 81, 84, 81, 80, 76, 0, 77, 76, 77, 81, 77, 76, 72, 0, 81, 80, 81, 84, 88, 0, 86, 84, 83, 0, 84, 0, 81, 0, 80, 0] },
    // ---- глава 5: пропавший корм ----
    morning5: { bpm: 108, drums: 'soft', lw: 'triangle', lv: 0.2, bass: [48, 0, 55, 0, 53, 0, 55, 0, 45, 0, 52, 0, 50, 0, 55, 0],
      lead: [72, 0, 76, 0, 79, 0, 76, 0, 77, 0, 74, 0, 72, 0, 0, 0, 74, 0, 77, 0, 81, 0, 79, 77, 76, 0, 74, 0, 72, 0, 0, 0] },
    detective5: { bpm: 104, drums: 'four', lw: 'triangle', stacc: true, lv: 0.18, bass: [41, 0, 44, 0, 46, 0, 47, 0, 48, 0, 46, 0, 44, 0, 43, 0],
      lead: [65, 0, 68, 0, 70, 71, 72, 0, 0, 0, 70, 0, 68, 0, 65, 0, 63, 0, 65, 0, 68, 0, 70, 0, 72, 0, 75, 0, 72, 0, 0, 0] },
    garden5: { bpm: 112, drums: 'soft', lw: 'sine', chime: true, lv: 0.18, bass: [43, 0, 0, 0, 50, 0, 0, 0, 48, 0, 0, 0, 50, 0, 0, 0],
      lead: [79, 0, 83, 86, 0, 83, 79, 0, 81, 0, 84, 88, 0, 84, 81, 0, 79, 0, 83, 86, 91, 0, 88, 86, 84, 0, 83, 0, 81, 0, 0, 0] },
    yard5: { bpm: 126, drums: 'four', lw: 'square', stacc: true, lv: 0.14, bass: [43, 0, 55, 0, 47, 0, 55, 0, 48, 0, 55, 0, 50, 0, 54, 0],
      lead: [67, 0, 71, 0, 74, 0, 71, 0, 72, 0, 76, 0, 74, 0, 0, 0, 67, 0, 71, 0, 74, 0, 79, 0, 78, 0, 74, 0, 72, 0, 0, 0] },
    final5: { bpm: 140, drums: 'disco', lw: 'square', stacc: true, bass: [48, 48, 55, 48, 53, 53, 60, 53, 55, 55, 62, 55, 53, 53, 60, 55],
      lead: [72, 0, 72, 74, 76, 0, 72, 0, 77, 0, 76, 74, 72, 0, 79, 0, 81, 0, 79, 77, 76, 0, 74, 0, 72, 76, 79, 84, 79, 0, 0, 0] },
    // ---- глава 6: зимняя сказка ----
    winter6: { bpm: 96, drums: 'waltz', lw: 'triangle', chime: true, lv: 0.18, bass: [45, 0, 0, 52, 0, 0, 43, 0, 0, 50, 0, 0, 41, 0, 0, 48, 0, 0, 40, 0, 0, 47, 0, 0],
      lead: [81, 0, 79, 76, 0, 0, 79, 0, 76, 74, 0, 0, 72, 0, 74, 76, 0, 0, 71, 0, 72, 69, 0, 0] },
    ginger6: { bpm: 126, drums: 'four', lw: 'square', stacc: true, lv: 0.14, bass: [48, 0, 55, 0, 52, 0, 55, 0, 53, 0, 57, 0, 55, 0, 59, 0],
      lead: [72, 76, 79, 76, 72, 0, 84, 0, 77, 81, 84, 81, 79, 0, 76, 0, 74, 77, 81, 77, 76, 0, 72, 0, 71, 74, 79, 74, 72, 0, 0, 0] },
    blizzard6: { bpm: 140, drums: 'toms', lw: 'sawtooth', lv: 0.09, bass: [40, 40, 0, 40, 43, 0, 41, 0, 40, 40, 0, 40, 38, 0, 39, 0],
      lead: [64, 0, 0, 67, 0, 0, 66, 0, 64, 0, 0, 62, 0, 0, 63, 0, 64, 0, 0, 71, 0, 0, 69, 0, 67, 0, 66, 0, 64, 0, 0, 0] },
    aurora6: { bpm: 80, drums: 'soft', lw: 'sine', chime: true, lv: 0.18, bass: [50, 0, 0, 0, 0, 0, 0, 0, 47, 0, 0, 0, 0, 0, 0, 0, 43, 0, 0, 0, 0, 0, 0, 0, 45, 0, 0, 0, 0, 0, 0, 0],
      lead: [86, 0, 0, 81, 0, 0, 83, 0, 0, 0, 78, 0, 0, 0, 0, 0, 79, 0, 0, 83, 0, 0, 81, 0, 0, 0, 76, 0, 0, 0, 0, 0] },
    mrakboss: { bpm: 156, drums: 'trap', lw: 'square', stacc: true, lv: 0.16, bass: [38, 38, 50, 38, 41, 41, 53, 41, 36, 36, 48, 36, 43, 43, 55, 42],
      lead: [74, 0, 77, 0, 81, 0, 80, 77, 74, 0, 72, 0, 74, 0, 0, 0, 74, 0, 77, 0, 82, 0, 81, 77, 79, 0, 77, 0, 74, 0, 73, 0] },
    // ---- глава 7: под водой ----
    reef7: { bpm: 104, drums: 'soft', lw: 'triangle', chime: true, lv: 0.17, rev: 0.3, echo: 0.2, bass: [48, 0, 55, 0, 45, 0, 52, 0, 41, 0, 48, 0, 43, 0, 50, 0],
      lead: [76, 0, 79, 0, 81, 79, 76, 0, 74, 0, 72, 0, 74, 76, 0, 0, 72, 0, 76, 0, 79, 81, 84, 0, 81, 79, 76, 0, 74, 0, 72, 0] },
    krill7: { bpm: 128, drums: 'four', lw: 'square', stacc: true, lv: 0.13, rev: 0.2, bass: [43, 55, 43, 55, 40, 52, 40, 52, 36, 48, 36, 48, 38, 50, 38, 50],
      lead: [79, 0, 79, 81, 83, 0, 81, 79, 76, 0, 79, 0, 74, 0, 0, 0, 79, 0, 79, 81, 83, 0, 86, 83, 81, 0, 79, 0, 81, 0, 0, 0] },
    ship7: { bpm: 120, drums: 'waltz', lw: 'sawtooth', lv: 0.09, rev: 0.22, bass: [38, 0, 0, 45, 0, 0, 36, 0, 0, 43, 0, 0, 34, 0, 0, 41, 0, 0, 33, 0, 0, 40, 0, 0],
      lead: [74, 0, 77, 81, 0, 77, 79, 0, 76, 72, 0, 0, 77, 0, 74, 70, 0, 74, 73, 0, 76, 69, 0, 0] },
    jelly7: { bpm: 84, drums: 'soft', lw: 'sine', chime: true, lv: 0.18, rev: 0.4, echo: 0.3, bass: [52, 0, 0, 0, 0, 0, 0, 0, 49, 0, 0, 0, 0, 0, 0, 0, 45, 0, 0, 0, 0, 0, 0, 0, 47, 0, 0, 0, 0, 0, 0, 0],
      lead: [88, 0, 0, 83, 0, 0, 85, 0, 0, 0, 80, 0, 0, 0, 0, 0, 83, 0, 0, 87, 0, 0, 85, 0, 0, 0, 81, 0, 0, 0, 0, 0] },
    abyss7: { bpm: 72, drums: 'toms', lw: 'triangle', lv: 0.15, rev: 0.45, echo: 0.25, bass: [33, 0, 0, 33, 34, 0, 0, 0, 33, 0, 0, 33, 31, 0, 0, 0],
      lead: [57, 0, 0, 0, 58, 0, 0, 0, 60, 0, 0, 58, 0, 0, 57, 0, 0, 0, 0, 0, 63, 0, 0, 0, 62, 0, 0, 60, 58, 0, 0, 0] },
    krillboss: { bpm: 160, drums: 'trap', lw: 'square', stacc: true, lv: 0.15, bass: [40, 40, 52, 40, 43, 43, 55, 43, 38, 38, 50, 38, 47, 47, 59, 46],
      lead: [76, 0, 79, 0, 83, 0, 82, 79, 76, 0, 74, 0, 76, 0, 0, 0, 76, 0, 79, 0, 84, 0, 83, 79, 81, 0, 79, 0, 76, 0, 75, 0] },
    // ---- подлянка финала ----
    zyamashow: { bpm: 118, drums: 'disco', lw: 'square', stacc: true, bass: [41, 53, 41, 53, 45, 57, 45, 57, 43, 55, 43, 55, 48, 60, 48, 60],
      lead: [77, 0, 77, 0, 81, 0, 79, 77, 0, 0, 74, 0, 72, 0, 0, 0, 77, 0, 77, 0, 84, 0, 81, 79, 77, 0, 79, 0, 81, 0, 0, 0] },
    ultimate: { bpm: 170, drums: 'trap', lw: 'sawtooth', lv: 0.12, bw: 'sawtooth', bv: 0.35, bass: [40, 40, 52, 40, 41, 41, 53, 41, 43, 43, 55, 43, 44, 44, 56, 47],
      lead: [88, 87, 88, 91, 88, 87, 85, 84, 83, 0, 84, 85, 88, 0, 91, 0, 93, 91, 88, 87, 88, 0, 91, 93, 95, 0, 93, 91, 88, 0, 87, 0] },
    truewin: { bpm: 112, drums: 'soft', lw: 'triangle', lv: 0.2, bass: [48, 0, 55, 0, 57, 0, 53, 0, 48, 0, 55, 0, 53, 0, 55, 0],
      lead: [72, 0, 76, 79, 84, 0, 83, 0, 81, 0, 79, 0, 76, 0, 0, 0, 77, 0, 81, 84, 88, 0, 86, 84, 83, 0, 84, 0, 88, 0, 0, 0] },
  };
  for (const k of ['field2', 'field3']) SONGS[k].drums = 'four';
  for (const k of ['final', 'final2']) SONGS[k].drums = 'disco';
  let song = null, songName = null, step = 0, nextTime = 0, timer = null, glitchMode = 0;
  function noiseHit(dur, vol, freq, delay) {
    if (!ctx || !enabled) return;
    if (!noiseBuf) noise(0.001, 0.0001, 1000);
    const t = ctx.currentTime + delay;
    const s = ctx.createBufferSource(); s.buffer = noiseBuf;
    const f = ctx.createBiquadFilter(); f.type = 'highpass'; f.frequency.value = freq;
    const g = ctx.createGain(); g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(f); f.connect(g); g.connect(musicBus);
    s.start(t); s.stop(t + dur + 0.05);
  }
  const kick = d => tone(120, 0.12, 'sine', 0.55, -80, d, musicBus);
  const snare = d => noiseHit(0.1, 0.25, 1800, d);
  const hat = (d, v = 0.08) => noiseHit(0.03, v, 8000, d);
  function drums(style, st, d) {
    switch (style) {
      case 'four': if (st % 4 === 0) kick(d); if (st % 8 === 4) snare(d); if (st % 2 === 1) hat(d, 0.05); break;
      case 'disco': if (st % 4 === 0) kick(d); if (st % 8 === 4) snare(d); if (st % 2 === 1) hat(d, 0.12); break;
      case 'soft': if (st % 8 === 0) tone(90, 0.15, 'sine', 0.35, -40, d, musicBus); if (st % 4 === 2) hat(d, 0.03); break;
      case 'toms':
        if (st % 4 === 0) kick(d);
        if (st % 8 === 6) tone(190, 0.14, 'sine', 0.4, -90, d, musicBus);
        if (st % 8 === 7) tone(140, 0.16, 'sine', 0.4, -70, d, musicBus);
        break;
      case 'darbuka': {
        const s8 = st % 8;
        if (s8 === 0) tone(95, 0.16, 'sine', 0.5, -40, d, musicBus);
        if (s8 === 3 || s8 === 5) noiseHit(0.04, 0.16, 3500, d);
        if (s8 === 6) noiseHit(0.05, 0.1, 2400, d);
        break;
      }
      case 'chip': if (st % 4 === 0) tone(110, 0.08, 'square', 0.12, -70, d, musicBus); if (st % 8 === 4) noiseHit(0.06, 0.18, 2500, d); hat(d, 0.03); break;
      case 'waltz': if (st % 6 === 0) tone(100, 0.15, 'sine', 0.4, -50, d, musicBus); if (st % 6 === 2 || st % 6 === 4) hat(d, 0.06); break;
      case 'trap': {
        const s16 = st % 16;
        if (s16 === 0 || s16 === 7 || s16 === 10) tone(60, 0.35, 'sine', 0.6, -25, d, musicBus);
        if (s16 === 8) snare(d);
        hat(d, 0.05);
        if (s16 >= 14) { hat(d + 0.05, 0.04); hat(d + 0.1, 0.04); }
        break;
      }
    }
  }
  function music(name) {
    if (song === SONGS[name]) return;
    song = SONGS[name] || null; songName = name; step = 0;
    if (ctx) nextTime = ctx.currentTime + 0.1;
    if (ctx && revSend) { // у каждой песни свой «зал»: главной теме – побольше воздуха и эха
      const now = ctx.currentTime;
      revSend.gain.setTargetAtTime(song ? (song.rev !== undefined ? song.rev : 0.14) : 0, now, 0.3);
      dlySend.gain.setTargetAtTime(song && song.echo ? song.echo : 0, now, 0.2);
      if (song) dly.delayTime.setValueAtTime(60 / song.bpm * 0.75, now);
    }
    if (!timer) timer = setInterval(schedule, 40);
  }
  function schedule() {
    if (!ctx || !song || !enabled || ctx.state !== 'running') return;
    if (nextTime < ctx.currentTime) nextTime = ctx.currentTime + 0.05;
    const stepDur = 60 / song.bpm / 2 * (glitchMode ? 1 + glitchMode * 0.6 : 1);
    while (nextTime < ctx.currentTime + 0.45) { // запас побольше: подлагивания экрана не рвут музыку
      const delay = nextTime - ctx.currentTime;
      const det = glitchMode ? Math.pow(2, -glitchMode * (0.5 + Math.random())) : 1;
      let st = step;
      if (song.rich) { song.rich(st, delay, stepDur); nextTime += stepDur; step++; continue; }
      if ((song.glitch && Math.random() < 0.07) || (glitchMode && Math.random() < 0.35)) st = Math.max(0, step - 1);
      const b = song.bass[st % song.bass.length];
      if (b) {
        tone(N(b) * det, stepDur * 0.9, song.bw || 'triangle', song.bv || 0.5, song.wobble ? -N(b) * 0.4 : 0, delay, musicBus);
        if (song.wobble && st % 2 === 0) tone(N(b) * det, stepDur * 0.45, 'sawtooth', 0.2, N(b) * 0.5, delay + stepDur * 0.45, musicBus);
      }
      const l = song.lead[st % song.lead.length];
      if (l) {
        const dur = song.stacc ? stepDur * 0.4 : song.chime ? stepDur * 2.5 : stepDur * 0.85;
        tone(N(l) * det, dur, song.lw || 'square', song.lv || 0.16, glitchMode ? -N(l) * 0.5 : 0, delay, musicBus);
      }
      if (song === SONGS.boss && st % 2 === 0) tone(2000, 0.03, 'square', 0.04, -1500, delay, musicBus);
      const ds = song.drums === true ? 'four' : song.drums;
      if (ds && ds !== 'none' && !glitchMode) drums(ds, st, delay);
      if (glitchMode && Math.random() < 0.3) noiseHit(0.08, 0.15, 400 + Math.random() * 4000, delay);
      nextTime += stepDur; step++;
    }
  }
  function setGlitch(v) { glitchMode = v; }

  function setEnabled(v) {
    enabled = v;
    try { localStorage.setItem('krilessa_sound', v ? 'on' : 'off'); } catch (e) { /* ignore */ }
    if (master) master.gain.value = v ? 0.8 : 0;
  }
  function suspend() { if (ctx && ctx.state === 'running') ctx.suspend(); }
  function resume() { if (ctx && ctx.state === 'suspended') ctx.resume(); }

  return { init, sfx, music, setEnabled, isEnabled: () => enabled, suspend, resume, setGlitch, current: () => songName };
})();
