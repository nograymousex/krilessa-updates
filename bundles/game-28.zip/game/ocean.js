'use strict';
// =====================================================================
//  Глава 7 «Крилевая бездна» – подводная сказка.
//  Крильятин – король всех крилей и ужасный матершинник – утащил на дно
//  все нежные слова. Крилесса и Рыжовая (смена на ходу) и Тесса в
//  пузыре-шлеме ныряют за ними. Течения, слова-жемчужины, тёмная бездна.
// =====================================================================

// ---------------- Локации ----------------
const B7 = BIOMES.length; // первая локация главы 7
while (SPAWNS.length < B7) SPAWNS.push(null);
BIOMES.push(
  { id: 'reef', name: 'Коралловый риф', ground: ['#2a8a9a', '#3298a8', '#22788a'], tree: 'coral', treeP: 0.1,
    obst: [[ROCK, 1]], path: ['#e6d2a0', '#eedaac', '#dcc692'], rock: ['#e8708a', '#f08aa0', '#d05a76'], deco: 'drops', mini: '#2a8a9a', sea: true },
  { id: 'krillfield', name: 'Крилевые луга', ground: ['#3a7aa0', '#4486aa', '#326e92'], tree: 'kelp', treeP: 0.08,
    obst: [[ROCK, 1]], path: ['#cfc49a', '#d8cca6', '#c4b88c'], rock: ['#5a9ab8', '#6aaac8', '#4a8aa8'], deco: 'flowers', mini: '#3a7aa0', sea: true },
  { id: 'wreck', name: 'Затонувший корабль', ground: ['#2a4a5a', '#324f62', '#24404e'], tree: 'kelp', treeP: 0.05,
    obst: [[ROCK, 1]], path: ['#7e7458', '#887e62', '#726a50'], rock: ['#6a4a2a', '#7a5a34', '#5a3e22'], deco: 'boards', mini: '#2a4a5a', sea: true },
  { id: 'jellywood', name: 'Медузий лес', ground: ['#2a3a7a', '#32448a', '#24326a'], tree: 'jellytree', treeP: 0.09,
    obst: [[ROCK, 1]], path: ['#9a94c0', '#a49ec8', '#8e88b4'], rock: ['#5a4a9a', '#6a5aaa', '#4a3a8a'], deco: 'sky', mini: '#2a3a7a', sea: true },
  { id: 'abyss', name: 'Светящаяся бездна', ground: ['#0a1428', '#0e1a32', '#08101f'], tree: 'glowkelp', treeP: 0.07,
    obst: [[ROCK, 1]], path: ['#2a3450', '#303a58', '#242e48'], rock: ['#1a2a4a', '#22345a', '#142240'], deco: 'gems', mini: '#0e1a32', cave: true, sea: true },
  { id: 'krillcastle', name: 'Крилевая цитадель', ground: ['#c86a8a', '#d47a98', '#b85a7a'], tree: 'coral', treeP: 0.02,
    obst: [[ROCK, 1]], path: ['#f2c8d4', '#f8d2dc', '#e8bccb'], rock: ['#e88aa8', '#f09ab4', '#d07a96'], deco: 'drops', mini: '#c86a8a', castleStyle: 'coral', sea: true },
);
BIOME_MUSIC.push('reef7', 'krill7', 'ship7', 'jelly7', 'abyss7', 'krill7');

// ---------------- Враги ----------------
Object.assign(ENEMIES, {
  krill: { name: 'Криль', hp: 24, spd: 140, dmg: 8, r: 8, xp: 1, ai: 'swarm', group: [4, 6], col: '#ff9ab0' },
  puffer: { name: 'Рыба-фугу', hp: 55, spd: 80, dmg: 28, r: 13, xp: 3, ai: 'exploder', col: '#ffd25a' },
  jelly: { name: 'Медузка', hp: 42, spd: 60, dmg: 12, r: 12, xp: 2, ai: 'bat', fly: true, col: '#c8a0ff' },
  crab: { name: 'Краб-щитник', hp: 150, spd: 58, dmg: 18, r: 15, xp: 5, ai: 'shield', col: '#ff6a4a' },
  eel: { name: 'Мурена', hp: 90, spd: 112, dmg: 18, r: 13, xp: 4, ai: 'charger', col: '#7a9a3a' },
  urchin: { name: 'Морской ёж', hp: 80, spd: 0, dmg: 10, r: 14, xp: 3, ai: 'turret', col: '#7a4ab0',
    shot: { cd: 2.4, spd: 200, dmg: 11, n: 6, spread: 1.05, col: '#c8a0ff' } },
  octo: { name: 'Осьминожка', hp: 70, spd: 70, dmg: 12, r: 13, xp: 3, ai: 'ranged', col: '#d86a9a',
    shot: { cd: 2.1, spd: 215, dmg: 12, n: 3, spread: 0.22, col: '#3a2a4a' } },
  shark: { name: 'Акулёнок', hp: 60, spd: 128, dmg: 14, r: 13, xp: 3, ai: 'chase', pack: true, group: [2, 3], col: '#8aa8c8' },
  lantern: { name: 'Фонарик-удильщик', hp: 55, spd: 62, dmg: 11, r: 12, xp: 3, ai: 'ranged', col: '#3ff0ff',
    shot: { cd: 2.2, spd: 230, dmg: 12, n: 1, burst: 3, spread: 0.05, col: '#9dffef' } },
  seahorse: { name: 'Морской конёк', hp: 50, spd: 78, dmg: 8, r: 11, xp: 4, ai: 'healer', col: '#ffb04a' },
});
SPAWNS.push(
  [['krill', 3], ['puffer', 1.5], ['jelly', 1.5], ['crab', 1]],
  [['krill', 4], ['shark', 1.5], ['seahorse', 1], ['jelly', 1.5]],
  [['eel', 2], ['octo', 2], ['crab', 1.5], ['krill', 2], ['urchin', 1]],
  [['jelly', 3], ['urchin', 1.5], ['seahorse', 1.5], ['octo', 1.5]],
  [['lantern', 3], ['eel', 2], ['jelly', 1.5], ['shark', 1.5]],
  [['krill', 3], ['crab', 2], ['octo', 2], ['puffer', 1.5], ['lantern', 1]],
);

// ---------------- Боссы ----------------
Object.assign(BOSSES, {
  crabking: {
    name: 'Краб Клешняк', sub: 'Страж Кораллового рифа', r: 44, ttk: 60, hit: 0.085, touch: 0.15, spd: 85, move: 'chase', col: '#ff6a4a',
    emojiSet: ['🫧', '🦀'],
    lines: {
      intro: 'Щёлк-щёлк! Крильятин сказал: кто тронет риф – того в клешню! А клешня у меня – во! 🦀',
      stages: ['', 'Щёлк! Вторая клешня тоже злая!', 'ЩЁЛК-ЩЁЛК-ЩЁЛК!!! Боком – это тоже вперёд!'],
      death: 'Щёлк… ладно… я просто… хотел обнимашек… клешнями…',
      taunts: ['Хожу боком – и что?', 'Клешнёй – щёлк!', 'Риф мой! И песок мой!'],
    },
    stages: [
      { attacks: [['charge', { repeat: 2 }], ['shotgun', { n: 7, waves: 2, emoji: true }], ['summon', { type: 'crab', n: 2, max: 4 }], ['stomp', { r: 140 }]] },
      { at: 0.66, spd: 1.2, attacks: [['charge', { repeat: 3 }], ['ring', { n: 16, waves: 3, emoji: true }], ['stomp', { r: 160, repeat: 2 }], ['summon', { type: 'krill', n: 6, max: 12 }]] },
      { at: 0.33, spd: 1.35, attacks: [['charge', { repeat: 4, ringN: 12 }], ['wave', { n: 2 }], ['shotgun', { n: 9, waves: 3, emoji: true }], ['stomp', { r: 180, repeat: 3 }]] },
    ],
  },
  jellyqueen: {
    name: 'Медуза Желейка', sub: 'Стража Медузьего леса', r: 40, ttk: 60, hit: 0.085, touch: 0.13, spd: 70, move: 'hover', fly: true, col: '#c8a0ff',
    lines: {
      intro: 'Бзззз! Хочешь обнимашки? Мои обнимашки – с током! ⚡🪼',
      stages: ['', 'Бзз-бзз! Щупальца, вперёд!', 'Я свечусь от злости! БЗЗЗЗЗ!'],
      death: 'Бзз… я… просто… желе…',
      taunts: ['Током – это тоже ласка!', 'Я прозрачная, но не простая!', 'Бззз!'],
    },
    stages: [
      { attacks: [['wave', { n: 2 }], ['homing', { n: 4 }], ['ring', { n: 14, waves: 2, col: '#c8a0ff' }], ['summon', { type: 'jelly', n: 4, max: 8 }]] },
      { at: 0.66, spd: 1.2, attacks: [['wave', { n: 3 }], ['laser', { beams: 2, rot: 0.85 }], ['homing', { n: 5 }], ['spiral', { arms: 3, col: '#c8a0ff' }]] },
      { at: 0.33, spd: 1.35, attacks: [['wave', { n: 4 }], ['laser', { beams: 3, rot: 1.0 }], ['spiral', { arms: 5, col: '#e0c8ff' }], ['teleport', { ringN: 14 }], ['homing', { n: 6 }]] },
    ],
  },
  captain: {
    name: 'Капитан Тинабород', sub: 'Страж Затонувшего корабля', r: 42, ttk: 62, hit: 0.09, touch: 0.14, spd: 90, move: 'chase', col: '#4a6a5a',
    emojiSet: ['💣', '⚓', '🦴'],
    lines: {
      intro: 'Йо-хо-хо и бочка крилевого рома! Тысяча крилей мне в бороду – на абордаж! 🏴‍☠️',
      stages: ['', 'Пушки к бою! Пли!', 'Свистать всех крилей наверх! ЙО-ХО-ХО!'],
      death: 'Тысяча… крилей… Корабль… тонет… опять…',
      taunts: ['Карамба!', 'Где мой попугай? А, он тоже утонул.', 'Ядро – это моя любовь!'],
    },
    stages: [
      { attacks: [['rain', { n: 10, fx: 'boom' }], ['shotgun', { n: 7, waves: 2, emoji: true }], ['summon', { type: 'eel', n: 2, max: 4 }], ['charge', { repeat: 2 }]] },
      { at: 0.66, spd: 1.2, attacks: [['rain', { n: 14, fx: 'boom' }], ['cross', {}], ['ring', { n: 18, waves: 3, emoji: true }], ['charge', { repeat: 3 }]] },
      { at: 0.33, spd: 1.35, attacks: [['rain', { n: 18, fx: 'boom' }], ['wave', { n: 3 }], ['cross', {}], ['summon', { type: 'shark', n: 3, max: 6 }], ['shotgun', { n: 9, waves: 3, emoji: true }]] },
    ],
  },
  angler: {
    name: 'Удильщик Фонарий', sub: 'Страж Светящейся бездны', r: 46, ttk: 65, hit: 0.09, touch: 0.15, spd: 95, move: 'hover', fly: true, col: '#1a2a4a',
    lines: {
      intro: 'Иди на свет… иди… ближе… ещё ближе… ХРУМ! 🔦🐟',
      stages: ['', 'Мой фонарик – самый яркий в бездне!', 'Темнота – моя подружка! ХРУМ-ХРУМ!'],
      death: 'Фонарик… гаснет… темно… страшно…',
      taunts: ['Не бойся, я не кусаюсь. Почти.', 'Посвечу – и съем!', 'Зубы – чтобы улыбаться!'],
    },
    stages: [
      { attacks: [['laser', { beams: 1, rot: 0.9, mouth: true }], ['homing', { n: 4 }], ['teleport', { ringN: 10 }], ['summon', { type: 'lantern', n: 3, max: 6 }]] },
      { at: 0.66, spd: 1.2, attacks: [['laser', { beams: 2, rot: 1.0, mouth: true }], ['wave', { n: 2 }], ['homing', { n: 6 }], ['charge', { repeat: 3 }]] },
      { at: 0.33, spd: 1.35, attacks: [['laser', { beams: 3, rot: 1.1, mouth: true }], ['teleport', { ringN: 14 }], ['spiral', { arms: 5, col: '#9dffef' }], ['wave', { n: 3 }], ['homing', { n: 7 }]] },
    ],
  },
  krillyatin: {
    name: 'Крильятин', sub: 'Король всех крилей', r: 48, ttk: 95, hit: 0.085, touch: 0.13, spd: 95, move: 'hover', fly: true, col: '#ff6a8a',
    final: true, music: 'krillboss', emojiSet: ['🤬', '💢', '🦐', '#', '@', '%', '!'],
    lines: {
      intro: 'Кто посмел нырнуть в МОЮ бездну?! Ах вы ж крилевы дети! Это МОИ слова! Мои! Я их копил с юрского периода! КРИЛЯТЬ!!! 🦐👑🤬',
      stages: ['', 'Охрилеть! Вы ещё живы?! Крильцы, В АТАКУ!', 'Ёкрилый бабай!!! Криль тебе в жабры! И тебе! И коту!', 'Крильдец вам! КРИЛЬДЕЦ!!! #@%&!!!'],
      death: 'Крил… крилять… Ладно… забирайте ваши слова… Я просто… хотел, чтобы и меня кто-нибудь… крилюбил… 🥺🦐',
      taunts: ['Иди в крильню!', 'Шо за крилня?!', 'Да чтоб тебя крилём придавило!', 'Крилебучий насос!', '#@%&!! Ой. То есть КРИЛЬ!', 'Криль вам, а не слова!', 'Ёкрилый бабай!'],
    },
    stages: [
      { attacks: [['emoji', { n: 16, waves: 3 }], ['summon', { type: 'krill', n: 8, max: 16 }], ['spiral', { arms: 4, emoji: true }], ['charge', { repeat: 2 }]] },
      { at: 0.75, spd: 1.15, attacks: [['wave', { n: 3 }], ['emoji', { n: 20, waves: 3 }], ['homing', { n: 5 }], ['rain', { n: 12, fx: 'boom' }]] },
      { at: 0.5, spd: 1.25, attacks: [['laser', { beams: 3, rot: 1.0, mouth: true }], ['spiral', { arms: 6, dur: 3.5, emoji: true }], ['summon', { type: 'puffer', n: 3, max: 5 }], ['wave', { n: 3 }], ['teleport', { ringN: 14 }]] },
      { at: 0.25, spd: 1.4, attacks: [['emoji', { n: 24, waves: 5 }], ['laser', { beams: 4, rot: 1.1, mouth: true }], ['spiral', { arms: 7, dur: 4, emoji: true }], ['homing', { n: 7 }], ['wave', { n: 4 }], ['summon', { type: 'krill', n: 10, max: 20 }]] },
    ],
  },
});

// ---------------- Глава 7 ----------------
CHAPTERS[7] = {
  id: 7, title: 'Глава 7', name: 'Крилевая бездна', seed: 7700077, MW: 210, MH: 210, blobs: 200,
  start: { x: 105, y: 198 },
  bossTiles: [{ x: 40, y: 165 }, { x: 45, y: 52 }, { x: 170, y: 48 }, { x: 172, y: 162 }, { x: 105, y: 98 }],
  bosses: ['crabking', 'jellyqueen', 'captain', 'angler', 'krillyatin'],
  castle: { x: 105, y: 100, half: 15, gate: 'south', biome: B7 + 5 }, cage: { x: 105, y: 88 }, noCage: true,
  biomeSeeds: [
    [B7, 105, 198], [B7, 70, 186], [B7, 40, 165], [B7, 140, 190],
    [B7 + 1, 28, 120], [B7 + 1, 70, 130], [B7 + 1, 150, 128], [B7 + 1, 186, 112],
    [B7 + 3, 45, 52], [B7 + 3, 18, 22], [B7 + 3, 82, 32],
    [B7 + 2, 170, 48], [B7 + 2, 196, 82], [B7 + 2, 136, 26],
    [B7 + 4, 172, 162], [B7 + 4, 196, 140], [B7 + 4, 150, 178],
    [B7 + 5, 105, 100], [B7 + 5, 105, 82], [B7 + 5, 88, 100], [B7 + 5, 122, 100],
  ],
  chests: 26, chestDist: [8, 30], shrines: 9, elite: 0.1, spawnEvery: 0.3, capBase: 22,
  zoneLevel: { [B7]: 4, [B7 + 1]: 7, [B7 + 3]: 9, [B7 + 2]: 12, [B7 + 4]: 16, [B7 + 5]: 20 }, bossLevels: [6, 10, 14, 18, 24], diff: { hp: 1.75, dmg: 1.6 },
  hero: 'krilessa', team: ['krilessa', 'ryzhovaya'], tessaStart: true, music: 'reef7', startLevel: 1,
  // течения: несут быстрее вдоль стрелок (в тайлах)
  currents: [[[100, 192], [48, 160]], [[30, 112], [40, 62]], [[62, 40], [160, 42]], [[190, 70], [186, 150]], [[160, 176], [112, 122]], [[110, 194], [170, 168]]],
  pearls: 12, noEvents: ['meteor'],
  gateSay: 'Крилять! Ворота цитадели открылись – Крильятин в тронном зале. Он там… ругается.', gateBanner: 'Крилевая цитадель открыта',
  deadText: 'Пузыри кончились… Попробуй снова –<br>уровень и улучшения сохранятся.',
};
ARENA_STYLE[7] = { name: 'Крилевая пучина', floor: ['#0a1a2e', '#0e2238'], crack: '#ff9ab0', ember: '#9dffef', wall: '#04101c', tint: '90,200,255' };
CHEST_THEME[7] = { body: '#6a4a2a', lid: '#8a6a3a', dark: '#2a1a0a', pearl: true };
// слова-жемчужины: Крильятин утащил их на дно
const PEARL_WORDS = ['Крилюблю!', 'Ты меня крилюбишь?', 'Я тебя криливирую!', 'Я тебя криляю!', 'Крилёночек мой', 'Крилесть моя',
  'Скриляю по тебе', 'Крилобнимашки!', 'Крилецелую!', 'Мы – криломанда!', 'Крилеснее тебя нет', 'Навсегда крилюблю'];

// ---------------- Графика: деревья ----------------
(() => {
  const S = 2;
  const make = fn => { const cv = makeCanvas(64 * S, 84 * S), c = cv.getContext('2d'); c.scale(S, S); shadow(c, 32, 79, 14, 4); fn(c); return cv; };
  TREE_SPR.coral = make(c => { // ветвистый коралл
    const br = (x, y, a, l, w, d) => {
      if (d > 4 || l < 4) return;
      const x2 = x + Math.cos(a) * l, y2 = y + Math.sin(a) * l;
      c.strokeStyle = d < 2 ? '#d84a6a' : '#f07a96'; c.lineWidth = w; c.lineCap = 'round';
      c.beginPath(); c.moveTo(x, y); c.lineTo(x2, y2); c.stroke();
      br(x2, y2, a - 0.45, l * 0.72, w * 0.72, d + 1); br(x2, y2, a + 0.4, l * 0.7, w * 0.72, d + 1);
      if (d === 4 || l < 7) { c.fillStyle = '#ffb4c4'; c.beginPath(); c.arc(x2, y2, 2.2, 0, TAU); c.fill(); }
    };
    br(32, 78, -Math.PI / 2, 22, 7, 0);
  });
  TREE_SPR.kelp = make(c => { // ламинария: длинные колышущиеся ленты
    for (const [x0, h, col] of [[24, 62, '#3a8a3a'], [32, 72, '#4aa04a'], [40, 58, '#2f7a32']]) {
      c.fillStyle = col; c.beginPath(); c.moveTo(x0 - 3, 78);
      for (let y = 78; y > 78 - h; y -= 6) c.quadraticCurveTo(x0 + (y % 12 ? 6 : -6), y - 3, x0 + (y % 12 ? 2 : -2), y - 6);
      c.lineTo(x0 + 2, 78 - h); for (let y = 78 - h; y < 78; y += 6) c.lineTo(x0 + 3 + (y % 12 ? 2 : -1), y + 6);
      c.closePath(); c.fill();
      c.fillStyle = 'rgba(180,255,160,0.35)'; for (let y = 74; y > 80 - h; y -= 12) { c.beginPath(); c.ellipse(x0 + 4, y, 2.5, 4, 0.4, 0, TAU); c.fill(); }
    }
  });
  TREE_SPR.jellytree = make(c => { // медузье «дерево»: купол и светящиеся щупальца
    c.strokeStyle = 'rgba(220,180,255,0.75)'; c.lineWidth = 2;
    for (let k = 0; k < 6; k++) { const x = 18 + k * 5.6; c.beginPath(); c.moveTo(x, 40); c.bezierCurveTo(x - 4, 52, x + 4, 62, x - 2, 76); c.stroke(); }
    const g = c.createRadialGradient(32, 30, 4, 32, 34, 22); g.addColorStop(0, '#f0e0ff'); g.addColorStop(1, '#9a6ae8');
    c.fillStyle = g; c.beginPath(); c.arc(32, 40, 18, Math.PI, 0); c.quadraticCurveTo(32, 46, 14, 40); c.fill();
    c.fillStyle = 'rgba(255,255,255,0.55)'; c.beginPath(); c.ellipse(26, 30, 5, 3, -0.5, 0, TAU); c.fill();
  });
  TREE_SPR.glowkelp = make(c => { // светящиеся водоросли бездны
    for (const [x0, h] of [[26, 58], [36, 66]]) {
      c.strokeStyle = '#1a5a6a'; c.lineWidth = 3; c.beginPath(); c.moveTo(x0, 78); c.bezierCurveTo(x0 - 8, 60, x0 + 8, 40, x0, 78 - h); c.stroke();
      for (let k = 0; k < 4; k++) { const y = 74 - k * (h / 4), x = x0 + Math.sin(k * 1.7) * 5; const g = c.createRadialGradient(x, y, 0, x, y, 6); g.addColorStop(0, 'rgba(160,255,240,0.95)'); g.addColorStop(1, 'rgba(60,240,255,0)'); c.fillStyle = g; c.beginPath(); c.arc(x, y, 6, 0, TAU); c.fill(); }
    }
  });
})();

// ---------------- Графика: враги ----------------
Object.assign(ESPR, {
  krill(c, e) { // розовый криль: панцирь из сегментов, усы, ножки
    c.scale(Math.cos(e.look) >= 0 ? 1 : -1, 1);
    const w = Math.sin(e.t * 16 + e.seed) * 1.3;
    c.strokeStyle = '#ff7a96'; c.lineWidth = 1;
    c.beginPath(); for (let k = 0; k < 5; k++) { c.moveTo(-5 + k * 2.6, 2); c.lineTo(-6 + k * 2.6 + w * 0.6, 6); } c.stroke();
    c.fillStyle = '#ffb0c0'; c.beginPath(); c.ellipse(0, 0, 9, 4.2, 0, 0, TAU); c.fill();
    c.fillStyle = '#ff8aa4'; for (let k = 0; k < 4; k++) { c.beginPath(); c.ellipse(-6 + k * 3.4, -0.5, 1.8, 3.6, 0, 0, TAU); c.fill(); }
    c.beginPath(); c.moveTo(-8, 0); c.lineTo(-13, -3 + w); c.lineTo(-12, 3 + w); c.closePath(); c.fill();
    c.strokeStyle = '#ffb0c0'; c.beginPath(); c.moveTo(8, -2); c.quadraticCurveTo(13, -8, 16, -6 + w); c.moveTo(8, -1); c.quadraticCurveTo(14, -4, 17, -1 - w); c.stroke();
    c.fillStyle = '#1b1030'; c.beginPath(); c.arc(6, -1.5, 1.2, 0, TAU); c.fill();
  },
  puffer(c, e) { // фугу: раздувается перед взрывом
    const inflate = e.fuse > 0 ? 1.35 + Math.sin(e.t * 30) * 0.06 : 1 + Math.sin(e.t * 4) * 0.04;
    c.scale(inflate, inflate);
    c.fillStyle = '#ffd25a'; c.strokeStyle = '#c89a2a'; c.lineWidth = 1.5;
    c.beginPath(); c.arc(0, 0, 11, 0, TAU); c.fill(); c.stroke();
    c.strokeStyle = '#a87a1a'; c.lineWidth = 1.2;
    for (let k = 0; k < 12; k++) { const a = k * TAU / 12; c.beginPath(); c.moveTo(Math.cos(a) * 10, Math.sin(a) * 10); c.lineTo(Math.cos(a) * 14, Math.sin(a) * 14); c.stroke(); }
    c.fillStyle = '#fff4c8'; c.beginPath(); c.ellipse(0, 4, 7, 4, 0, 0, TAU); c.fill();
    c.fillStyle = '#ffffff'; c.beginPath(); c.arc(-4, -3, 3, 0, TAU); c.arc(4, -3, 3, 0, TAU); c.fill();
    c.fillStyle = '#1b1030'; c.beginPath(); c.arc(-3.5, -2.5, 1.4, 0, TAU); c.arc(4.5, -2.5, 1.4, 0, TAU); c.fill();
    c.fillStyle = '#e86a4a'; c.beginPath(); c.ellipse(0, 3, 2, 1.4, 0, 0, TAU); c.fill();
  },
  jelly(c, e) { // медузка: купол и колышущиеся щупальца
    const p = Math.sin(e.t * 5 + e.seed);
    c.strokeStyle = 'rgba(220,190,255,0.85)'; c.lineWidth = 1.4;
    for (let k = 0; k < 5; k++) { const x = -6 + k * 3; c.beginPath(); c.moveTo(x, 2); c.quadraticCurveTo(x + p * 3, 9, x - p * 2, 15); c.stroke(); }
    const g = c.createRadialGradient(-2, -5, 1, 0, -2, 11); g.addColorStop(0, '#f4e8ff'); g.addColorStop(1, '#a87ae8');
    c.fillStyle = g; c.beginPath(); c.arc(0, 2, 10 + p * 0.8, Math.PI, 0); c.quadraticCurveTo(0, 6, -10 - p * 0.8, 2); c.fill();
    c.fillStyle = 'rgba(255,255,255,0.6)'; c.beginPath(); c.ellipse(-3, -4, 3, 1.8, -0.4, 0, TAU); c.fill();
    c.fillStyle = '#4a2a7a'; c.beginPath(); c.arc(-3, -1, 1, 0, TAU); c.arc(3, -1, 1, 0, TAU); c.fill();
  },
  crab(c, e) { // краб: щит-клешня смотрит на героиню
    const st = Math.sin(e.t * 14) * 1.5;
    c.strokeStyle = '#c84a2a'; c.lineWidth = 2;
    for (const s of [-1, 1]) for (let k = 0; k < 3; k++) { c.beginPath(); c.moveTo(s * 8, 4 + k * 2); c.lineTo(s * (14 + k), 8 + k * 3 + (k % 2 ? st : -st)); c.stroke(); }
    c.fillStyle = '#ff6a4a'; c.strokeStyle = '#b8402a'; c.lineWidth = 1.5;
    c.beginPath(); c.ellipse(0, 2, 13, 9, 0, 0, TAU); c.fill(); c.stroke();
    c.fillStyle = 'rgba(255,255,255,0.3)'; c.beginPath(); c.ellipse(-4, -2, 5, 2.5, -0.3, 0, TAU); c.fill();
    c.fillStyle = '#ffffff'; c.beginPath(); c.arc(-4, -8, 2.6, 0, TAU); c.arc(4, -8, 2.6, 0, TAU); c.fill();
    c.fillStyle = '#1b1030'; c.beginPath(); c.arc(-4, -8, 1.3, 0, TAU); c.arc(4, -8, 1.3, 0, TAU); c.fill();
    c.strokeStyle = '#b8402a'; c.lineWidth = 1.3; c.beginPath(); c.moveTo(-4, -5); c.lineTo(-4, -6); c.moveTo(4, -5); c.lineTo(4, -6); c.stroke();
    // клешни-щит повёрнуты к героине
    c.save(); c.rotate(e.shieldAng || 0);
    c.fillStyle = '#ff7a5a'; c.strokeStyle = '#b8402a';
    for (const s of [-1, 1]) { c.beginPath(); c.ellipse(15, s * 7, 6, 4.5, s * 0.3, 0, TAU); c.fill(); c.stroke(); c.fillStyle = '#ffd0c0'; c.beginPath(); c.moveTo(18, s * 7); c.lineTo(22, s * 5); c.lineTo(19, s * 9); c.fill(); c.fillStyle = '#ff7a5a'; }
    c.restore();
  },
  eel(c, e) { // мурена: длинное тело волной
    c.scale(Math.cos(e.look) >= 0 ? 1 : -1, 1);
    const w = e.jd > 0 ? 0.3 : 1;
    c.strokeStyle = '#5a7a2a'; c.lineWidth = 9; c.lineCap = 'round';
    c.beginPath(); for (let k = 0; k <= 8; k++) { const x = -16 + k * 3.6, y = Math.sin(e.t * 9 + k * 0.8) * 3 * w; if (k) c.lineTo(x, y); else c.moveTo(x, y); } c.stroke();
    c.strokeStyle = '#8aaa4a'; c.lineWidth = 6; c.stroke();
    c.lineCap = 'butt';
    c.fillStyle = '#8aaa4a'; c.beginPath(); c.ellipse(14, 0, 7, 5.5, 0, 0, TAU); c.fill();
    c.fillStyle = '#ffd25a'; c.beginPath(); c.arc(16, -2, 1.6, 0, TAU); c.fill();
    c.fillStyle = '#1b1030'; c.beginPath(); c.arc(16.5, -2, 0.8, 0, TAU); c.fill();
    c.strokeStyle = '#3a4a1a'; c.lineWidth = 1.2; c.beginPath(); c.moveTo(18, 2); c.lineTo(21, 1.5); c.stroke();
    if (e.wind > 0) { c.fillStyle = '#ffffff'; c.fillRect(17, 2, 1.5, 2); c.fillRect(19, 1.5, 1.5, 2); }
  },
  urchin(c, e) { // морской ёж: шар с иглами
    const pu = 1 + (e.charge > 0 ? 0.12 : 0);
    c.strokeStyle = '#4a2a7a'; c.lineWidth = 1.6;
    for (let k = 0; k < 20; k++) { const a = k * TAU / 20 + e.t * 0.3, l = (k % 2 ? 15 : 18) * pu; c.beginPath(); c.moveTo(Math.cos(a) * 8, Math.sin(a) * 8); c.lineTo(Math.cos(a) * l, Math.sin(a) * l); c.stroke(); }
    const g = c.createRadialGradient(-3, -3, 1, 0, 0, 10); g.addColorStop(0, '#b88ae8'); g.addColorStop(1, '#5a3a9a');
    c.fillStyle = g; c.beginPath(); c.arc(0, 0, 10, 0, TAU); c.fill();
    c.fillStyle = '#ffffff'; c.beginPath(); c.arc(-3, -1, 2, 0, TAU); c.arc(3, -1, 2, 0, TAU); c.fill();
    c.fillStyle = '#1b1030'; c.beginPath(); c.arc(-3, -0.5, 1, 0, TAU); c.arc(3, -0.5, 1, 0, TAU); c.fill();
  },
  octo(c, e) { // осьминожка: голова и восемь щупалец
    const p = e.t * 6 + e.seed;
    c.strokeStyle = '#c84a8a'; c.lineWidth = 3; c.lineCap = 'round';
    for (let k = 0; k < 6; k++) { const x = -8 + k * 3.2; c.beginPath(); c.moveTo(x, 3); c.quadraticCurveTo(x + Math.sin(p + k) * 4, 10, x + Math.sin(p + k + 1) * 3, 15); c.stroke(); }
    c.lineCap = 'butt';
    const g = c.createRadialGradient(-3, -7, 1, 0, -3, 12); g.addColorStop(0, '#ffb0d0'); g.addColorStop(1, '#d86a9a');
    c.fillStyle = g; c.beginPath(); c.ellipse(0, -3, 10, 10, 0, 0, TAU); c.fill();
    c.fillStyle = '#ffffff'; c.beginPath(); c.arc(-4, -3, 2.6, 0, TAU); c.arc(4, -3, 2.6, 0, TAU); c.fill();
    c.fillStyle = '#1b1030'; c.beginPath(); c.arc(-4, -2.5, 1.3, 0, TAU); c.arc(4, -2.5, 1.3, 0, TAU); c.fill();
    c.fillStyle = 'rgba(255,255,255,0.45)'; c.beginPath(); c.ellipse(-3, -9, 3, 1.6, -0.3, 0, TAU); c.fill();
    if (e.charge > 0) { c.fillStyle = '#3a2a4a'; c.beginPath(); c.arc(0, 3, 2.2, 0, TAU); c.fill(); }
  },
  shark(c, e) { // акулёнок
    c.scale(Math.cos(e.look) >= 0 ? 1 : -1, 1);
    const w = Math.sin(e.t * 12 + e.seed) * 2;
    c.fillStyle = '#6a88a8'; c.beginPath(); c.moveTo(-12, 0); c.lineTo(-19, -6 + w); c.lineTo(-18, 6 + w); c.closePath(); c.fill();
    c.fillStyle = '#8aa8c8'; c.beginPath(); c.ellipse(0, 0, 13, 6.5, 0, 0, TAU); c.fill();
    c.fillStyle = '#e8f0f8'; c.beginPath(); c.ellipse(1, 2.5, 10, 3, 0, 0, TAU); c.fill();
    c.fillStyle = '#6a88a8'; c.beginPath(); c.moveTo(-2, -5); c.lineTo(2, -12); c.lineTo(5, -5); c.fill();
    c.fillStyle = '#1b1030'; c.beginPath(); c.arc(8, -1.5, 1.3, 0, TAU); c.fill();
    c.fillStyle = '#ffffff'; for (let k = 0; k < 3; k++) { c.beginPath(); c.moveTo(7 + k * 2, 2); c.lineTo(8 + k * 2, 4); c.lineTo(9 + k * 2, 2); c.fill(); }
  },
  lantern(c, e) { // малыш-удильщик со светящимся фонариком
    c.scale(Math.cos(e.look) >= 0 ? 1 : -1, 1);
    const g0 = 0.6 + Math.sin(e.t * 6 + e.seed) * 0.3;
    const lg = c.createRadialGradient(10, -16, 0, 10, -16, 12); lg.addColorStop(0, `rgba(160,255,240,${g0})`); lg.addColorStop(1, 'rgba(60,240,255,0)');
    c.fillStyle = lg; c.beginPath(); c.arc(10, -16, 12, 0, TAU); c.fill();
    c.strokeStyle = '#2a4a6a'; c.lineWidth = 1.5; c.beginPath(); c.moveTo(2, -8); c.quadraticCurveTo(8, -20, 10, -16); c.stroke();
    c.fillStyle = '#c8fff8'; c.beginPath(); c.arc(10, -16, 2.8, 0, TAU); c.fill();
    c.fillStyle = '#1a2a4a'; c.beginPath(); c.ellipse(0, 0, 12, 9, 0, 0, TAU); c.fill();
    c.fillStyle = '#2a3a5a'; c.beginPath(); c.moveTo(-10, 0); c.lineTo(-17, -6); c.lineTo(-16, 6); c.closePath(); c.fill();
    c.fillStyle = '#ffffff'; for (let k = 0; k < 4; k++) { c.beginPath(); c.moveTo(3 + k * 2.4, 3); c.lineTo(4.2 + k * 2.4, 6); c.lineTo(5.4 + k * 2.4, 3); c.fill(); }
    c.fillStyle = '#9dffef'; c.beginPath(); c.arc(5, -3, 2, 0, TAU); c.fill();
  },
  seahorse(c, e) { // морской конёк-лекарь
    c.scale(Math.cos(e.look) >= 0 ? 1 : -1, 1);
    const b = Math.sin(e.t * 4 + e.seed) * 1.5;
    c.translate(0, b);
    c.strokeStyle = '#e8902a'; c.lineWidth = 5; c.lineCap = 'round';
    c.beginPath(); c.moveTo(0, -6); c.quadraticCurveTo(-6, 4, 0, 10); c.quadraticCurveTo(4, 14, 0, 16); c.stroke();
    c.strokeStyle = '#ffb04a'; c.lineWidth = 3; c.stroke(); c.lineCap = 'butt';
    c.fillStyle = '#ffb04a'; c.beginPath(); c.ellipse(2, -9, 5, 4, 0.3, 0, TAU); c.fill();
    c.beginPath(); c.moveTo(5, -9); c.lineTo(11, -8); c.lineTo(5, -6); c.fill();
    c.fillStyle = '#1b1030'; c.beginPath(); c.arc(2.5, -10, 1, 0, TAU); c.fill();
    c.fillStyle = '#ffd88a'; for (let k = 0; k < 3; k++) { c.beginPath(); c.moveTo(-3, -6 + k * 5); c.lineTo(-7, -4 + k * 5); c.lineTo(-3, -2 + k * 5); c.fill(); }
    if (e.healing > 0) { c.fillStyle = 'rgba(125,255,154,0.7)'; c.beginPath(); c.arc(0, 0, 16, 0, TAU); c.fill(); }
  },
});

// ---------------- Графика: боссы ----------------
Object.assign(BSPR, {
  crabking(c, b, t) { // огромный краб с короной из ракушек
    const fl = b.flash > 0, st = Math.sin(t * 10) * 3;
    c.strokeStyle = '#b8402a'; c.lineWidth = 4;
    for (const s of [-1, 1]) for (let k = 0; k < 3; k++) { c.beginPath(); c.moveTo(s * 24, 8 + k * 6); c.lineTo(s * (42 + k * 3), 22 + k * 8 + (k % 2 ? st : -st)); c.stroke(); }
    const cl = Math.sin(t * 6) * 0.25 + (b.mode === 'charge' ? 0.5 : 0);
    for (const s of [-1, 1]) {
      c.save(); c.translate(s * 34, -10); c.rotate(s * (-0.4 - cl));
      c.fillStyle = fl ? '#ffffff' : '#ff7a5a'; c.strokeStyle = '#b8402a'; c.lineWidth = 2.5;
      c.beginPath(); c.ellipse(s * 10, 0, 16, 11, 0, 0, TAU); c.fill(); c.stroke();
      c.fillStyle = '#ffd0c0'; c.beginPath(); c.moveTo(s * 20, -4); c.lineTo(s * 32, -12 - cl * 10); c.lineTo(s * 24, 2); c.fill();
      c.restore();
    }
    c.fillStyle = fl ? '#ffffff' : '#ff6a4a'; c.strokeStyle = '#b8402a'; c.lineWidth = 3;
    c.beginPath(); c.ellipse(0, 6, 34, 24, 0, 0, TAU); c.fill(); c.stroke();
    c.fillStyle = 'rgba(255,255,255,0.28)'; c.beginPath(); c.ellipse(-10, -4, 14, 6, -0.3, 0, TAU); c.fill();
    for (const s of [-1, 1]) { c.fillStyle = '#ffffff'; c.beginPath(); c.arc(s * 10, -20, 7, 0, TAU); c.fill(); c.fillStyle = '#1b1030'; c.beginPath(); c.arc(s * 10, -19, 3.4, 0, TAU); c.fill(); c.strokeStyle = '#b8402a'; c.lineWidth = 3; c.beginPath(); c.moveTo(s * 10, -13); c.lineTo(s * 10, -8); c.stroke(); }
    if (b.stage >= 1) brows(c, -10, 10, -29, 7, 0.6);
    c.strokeStyle = '#7a2a1a'; c.lineWidth = 2.5; c.beginPath(); c.arc(0, 8, 9, 0.3, Math.PI - 0.3); c.stroke();
    // корона из ракушек
    for (const [x, col] of [[-12, '#ffe0c8'], [0, '#ffd25a'], [12, '#ffe0c8']]) { c.fillStyle = col; c.beginPath(); c.moveTo(x - 6, -28); c.lineTo(x, -40); c.lineTo(x + 6, -28); c.closePath(); c.fill(); }
  },
  jellyqueen(c, b, t) { // королева медуз: светится и бьёт током
    const fl = b.flash > 0, p = Math.sin(t * 3);
    c.fillStyle = 'rgba(200,160,255,0.22)'; c.beginPath(); c.arc(0, -4, 54 + p * 5, 0, TAU); c.fill();
    c.strokeStyle = 'rgba(220,190,255,0.85)'; c.lineWidth = 3;
    for (let k = 0; k < 8; k++) { const x = -24 + k * 7; c.beginPath(); c.moveTo(x, 6); c.bezierCurveTo(x + Math.sin(t * 3 + k) * 10, 24, x - Math.sin(t * 3 + k) * 8, 38, x + Math.sin(t * 2 + k) * 6, 52); c.stroke(); }
    const g = c.createRadialGradient(-8, -18, 4, 0, -8, 38); g.addColorStop(0, fl ? '#ffffff' : '#f6eaff'); g.addColorStop(1, '#9a6ae8');
    c.fillStyle = g; c.beginPath(); c.arc(0, 6, 34 + p * 2, Math.PI, 0); c.quadraticCurveTo(0, 16, -34 - p * 2, 6); c.fill();
    c.fillStyle = 'rgba(255,255,255,0.55)'; c.beginPath(); c.ellipse(-12, -14, 10, 5, -0.4, 0, TAU); c.fill();
    c.fillStyle = '#4a2a7a'; c.beginPath(); c.ellipse(-9, -4, 3, 4, 0, 0, TAU); c.ellipse(9, -4, 3, 4, 0, 0, TAU); c.fill();
    if (b.stage >= 1) brows(c, -9, 9, -11, 5, 0.5);
    c.strokeStyle = '#4a2a7a'; c.lineWidth = 2; c.beginPath(); c.arc(0, 2, 5, 0.2, Math.PI - 0.2); c.stroke();
    // искры тока
    for (let k = 0; k < 4; k++) { const a = t * 4 + k * TAU / 4, r = 40; c.strokeStyle = '#fff6a0'; c.lineWidth = 2; c.beginPath(); c.moveTo(Math.cos(a) * r, Math.sin(a) * r - 4); c.lineTo(Math.cos(a) * (r + 8) + 3, Math.sin(a) * (r + 8) - 8); c.lineTo(Math.cos(a) * (r + 14), Math.sin(a) * (r + 14) - 2); c.stroke(); }
  },
  captain(c, b, t) { // капитан-утопленник: треуголка, борода из тины, крюк
    const fl = b.flash > 0, sx = Math.cos(b.look) >= 0 ? 1 : -1;
    c.scale(sx, 1);
    c.fillStyle = fl ? '#ffffff' : '#3a5a4a'; c.strokeStyle = '#1a2a20'; c.lineWidth = 2.5;
    c.beginPath(); c.moveTo(-22, 36); c.lineTo(-18, -4); c.lineTo(18, -4); c.lineTo(22, 36); c.closePath(); c.fill(); c.stroke();
    c.fillStyle = '#ffd25a'; for (const y of [6, 16, 26]) { c.beginPath(); c.arc(0, y, 2.5, 0, TAU); c.fill(); }
    c.fillStyle = fl ? '#ffffff' : '#a8c8b8'; c.beginPath(); c.arc(0, -18, 15, 0, TAU); c.fill(); c.stroke();
    // борода из тины
    c.fillStyle = '#3a8a3a'; c.beginPath(); c.moveTo(-14, -12); for (let k = 0; k <= 6; k++) c.lineTo(-14 + k * 4.7, -2 + (k % 2 ? 14 : 6) + Math.sin(t * 4 + k) * 2); c.lineTo(14, -12); c.closePath(); c.fill();
    c.fillStyle = '#1b1030'; c.beginPath(); c.arc(-5, -20, 2.4, 0, TAU); c.fill();
    c.fillStyle = '#1b1030'; c.beginPath(); c.ellipse(6, -20, 5, 4, 0, 0, TAU); c.fill(); c.strokeStyle = '#1b1030'; c.lineWidth = 1.5; c.beginPath(); c.moveTo(1, -23); c.lineTo(15, -28); c.stroke();
    if (b.stage >= 1) brows(c, -5, 6, -26, 5, 0.6);
    // треуголка
    c.fillStyle = '#1a1a2a'; c.beginPath(); c.moveTo(-24, -28); c.quadraticCurveTo(0, -52, 24, -28); c.quadraticCurveTo(0, -36, -24, -28); c.fill();
    c.fillStyle = '#ffffff'; c.font = 'bold 10px sans-serif'; c.textAlign = 'center'; c.fillText('☠', 0, -34);
    // крюк
    c.strokeStyle = '#c8c8d8'; c.lineWidth = 3; c.beginPath(); c.moveTo(22, 10); c.lineTo(32, 10 + Math.sin(t * 5) * 3); c.arc(32, 16 + Math.sin(t * 5) * 3, 6, -Math.PI / 2, Math.PI * 0.6); c.stroke();
  },
  angler(c, b, t) { // удильщик: огромная пасть и фонарь
    const fl = b.flash > 0, sx = Math.cos(b.look) >= 0 ? 1 : -1;
    c.scale(sx, 1);
    const g0 = 0.7 + Math.sin(t * 5) * 0.25;
    const lg = c.createRadialGradient(30, -44, 0, 30, -44, 34); lg.addColorStop(0, `rgba(170,255,240,${g0})`); lg.addColorStop(1, 'rgba(60,240,255,0)');
    c.fillStyle = lg; c.beginPath(); c.arc(30, -44, 34, 0, TAU); c.fill();
    c.strokeStyle = '#2a4a6a'; c.lineWidth = 3; c.beginPath(); c.moveTo(4, -26); c.quadraticCurveTo(20, -58, 30, -44); c.stroke();
    c.fillStyle = '#d8fff8'; c.beginPath(); c.arc(30, -44, 6, 0, TAU); c.fill();
    c.fillStyle = fl ? '#ffffff' : '#1a2a4a'; c.strokeStyle = '#0a1428'; c.lineWidth = 3;
    c.beginPath(); c.ellipse(0, 0, 40, 30, 0, 0, TAU); c.fill(); c.stroke();
    c.fillStyle = '#22345a'; c.beginPath(); c.moveTo(-34, 0); c.lineTo(-56, -18); c.lineTo(-54, 18); c.closePath(); c.fill();
    const open = b.mode === 'laser' ? 1 : 0.4 + Math.sin(t * 3) * 0.2;
    c.fillStyle = '#4a0a1a'; c.beginPath(); c.ellipse(18, 10, 18, 10 * open + 2, 0, 0, TAU); c.fill();
    c.fillStyle = '#ffffff'; for (let k = 0; k < 6; k++) { const x = 4 + k * 5.5; c.beginPath(); c.moveTo(x, 4); c.lineTo(x + 2.5, 10 + open * 4); c.lineTo(x + 5, 4); c.fill(); c.beginPath(); c.moveTo(x, 16 + open * 6); c.lineTo(x + 2.5, 10 + open * 2); c.lineTo(x + 5, 16 + open * 6); c.fill(); }
    c.fillStyle = '#9dffef'; c.beginPath(); c.arc(12, -12, 6, 0, TAU); c.fill(); c.fillStyle = '#0a1428'; c.beginPath(); c.arc(13, -12, 3, 0, TAU); c.fill();
    if (b.stage >= 1) brows(c, 12, 12, -21, 5, 0.6);
  },
  krillyatin(c, b, t) { // король крилей: огромный розовый криль в короне, красный от ярости
    const fl = b.flash > 0, rage = Math.min(1, b.stage / 3), sx = Math.cos(b.look) >= 0 ? 1 : -1;
    c.scale(sx, 1);
    const w = Math.sin(t * 10) * 3;
    const body = fl ? '#ffffff' : `rgb(${255},${Math.round(150 - 90 * rage)},${Math.round(170 - 110 * rage)})`;
    // ножки
    c.strokeStyle = '#ff6a86'; c.lineWidth = 3;
    for (let k = 0; k < 8; k++) { const x = -30 + k * 7.5; c.beginPath(); c.moveTo(x, 12); c.lineTo(x - 3 + (k % 2 ? w : -w), 30); c.stroke(); }
    // хвостовой веер
    c.fillStyle = body; c.beginPath(); c.moveTo(-40, 0); c.lineTo(-62, -16 + w); c.lineTo(-58, 0); c.lineTo(-62, 16 + w); c.closePath(); c.fill();
    // панцирь из сегментов
    c.fillStyle = body; c.strokeStyle = '#d84a6a'; c.lineWidth = 2.5;
    c.beginPath(); c.ellipse(0, 0, 44, 20, 0, 0, TAU); c.fill(); c.stroke();
    c.strokeStyle = 'rgba(200,60,90,0.6)'; c.lineWidth = 2;
    for (let k = 0; k < 6; k++) { const x = -32 + k * 11; c.beginPath(); c.moveTo(x, -18); c.quadraticCurveTo(x + 4, 0, x, 18); c.stroke(); }
    c.fillStyle = 'rgba(255,255,255,0.3)'; c.beginPath(); c.ellipse(-6, -10, 22, 5, -0.1, 0, TAU); c.fill();
    // голова, глаза навыкате, усы
    c.fillStyle = body; c.strokeStyle = '#d84a6a'; c.beginPath(); c.ellipse(40, -4, 16, 14, 0, 0, TAU); c.fill(); c.stroke();
    c.strokeStyle = '#ff9ab0'; c.lineWidth = 2;
    c.beginPath(); c.moveTo(52, -10); c.bezierCurveTo(70, -34, 84, -26, 90, -40 + w); c.moveTo(52, -6); c.bezierCurveTo(74, -18, 86, -8, 96, -14 - w); c.stroke();
    for (const [x, y] of [[40, -16], [50, -14]]) { c.fillStyle = '#ffffff'; c.beginPath(); c.arc(x, y, 6, 0, TAU); c.fill(); c.fillStyle = rage > 0.5 ? '#c8102e' : '#1b1030'; c.beginPath(); c.arc(x + 1.5, y, 2.8, 0, TAU); c.fill(); }
    brows(c, 40, 50, -24, 5, 0.3 + rage * 0.6);
    // рот орёт ругательства
    const yell = 0.5 + Math.abs(Math.sin(t * 8)) * 0.5;
    c.fillStyle = '#5a0a1a'; c.beginPath(); c.ellipse(50, 4, 6, 3 + yell * 3, 0, 0, TAU); c.fill();
    // корона
    c.fillStyle = '#ffd25a'; c.strokeStyle = '#c89a2a'; c.lineWidth = 1.5;
    c.beginPath(); c.moveTo(28, -18); c.lineTo(28, -32); c.lineTo(34, -24); c.lineTo(40, -36); c.lineTo(46, -24); c.lineTo(52, -32); c.lineTo(52, -18); c.closePath(); c.fill(); c.stroke();
    c.fillStyle = '#ff3ea5'; c.beginPath(); c.arc(40, -24, 2.5, 0, TAU); c.fill();
    // облачко ругани над головой
    if (b.state === 'fight' && Math.sin(t * 2.2) > 0.2) {
      c.save(); c.scale(sx, 1); c.font = 'bold 13px sans-serif'; c.textAlign = 'center';
      c.fillStyle = '#ff3ea5'; c.fillText(['#@%&!', 'КРИЛЬ!', '%$#@!', '🤬'][Math.floor(t * 1.1) % 4], sx * 40, -48); c.restore();
    }
  },
});
