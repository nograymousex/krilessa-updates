'use strict';

const HUD = (() => {
  // ------------------------------------------------------------------
  //  Мини-карта 2.0 «Неон-вывеска главы»: местность вокруг героини светящимися контурами,
  //  дальние цели – значками по краю, рамка с неоновыми украшениями главы.
  //  ?mm=classic – старая мини-карта (для проверки); в «Ещё» её тоже можно вернуть.
  // ------------------------------------------------------------------
  const MM_URL = (location.search.match(/[?&]mm=(\w+)/) || [])[1];
  let MM_STYLE = MM_URL || 'paper';
  const MM2 = { neon: null, sign: null, head: -Math.PI / 2, K: 3, sizeF: 0 };
  const NEON_COL = { 1: '#3dffa0', 2: '#ff3ea5', 3: '#7fd8ff', 4: '#b07dff', 5: '#ffcf4a', 6: '#9fe8ff', 7: '#3fe8ff' };
  const NEON_ACC = { 1: '#d8ff6a', 2: '#7fd8ff', 3: '#ffd25a', 4: '#9dffc8', 5: '#ff8a3a', 6: '#ffffff', 7: '#ff9ad0' };
  const neonCol = () => NEON_COL[World.CHN] || '#3ff0ff', neonAcc = () => NEON_ACC[World.CHN] || '#ffffff';
  // основа: светящиеся контуры стен, вода, дорожки и слабая заливка проходимого (3 пикселя на клетку)
  function mm2Neon() {
    if (MM2.neon) return MM2.neon;
    const K = MM2.K, cv = makeCanvas(World.MW * K, World.PLAY_H * K), c = cv.getContext('2d'), col = neonCol();
    c.fillStyle = '#06030f'; c.fillRect(0, 0, cv.width, cv.height);
    for (let ty = 0; ty < World.PLAY_H; ty++) for (let tx = 0; tx < World.MW; tx++) {
      const t = World.tiles[ty * World.MW + tx];
      if (t === WATER || t === LAVA || t === ICE) { c.fillStyle = t === LAVA ? 'rgba(255,90,40,0.35)' : 'rgba(80,180,255,0.22)'; c.fillRect(tx * K, ty * K, K, K); }
      else if (t === PATH) { c.fillStyle = 'rgba(255,255,255,0.22)'; c.fillRect(tx * K, ty * K, K, K); }
      if (!World.isSolidTile(tx, ty, false)) { c.globalAlpha = 0.07; c.fillStyle = col; c.fillRect(tx * K, ty * K, K, K); c.globalAlpha = 1; continue; }
      c.fillStyle = 'rgba(255,255,255,0.04)'; c.fillRect(tx * K, ty * K, K, K);
      c.fillStyle = col;
      if (!World.isSolidTile(tx, ty + 1, false)) c.fillRect(tx * K, ty * K + K - 1, K, 1);
      if (!World.isSolidTile(tx, ty - 1, false)) c.fillRect(tx * K, ty * K, K, 1);
      if (!World.isSolidTile(tx - 1, ty, false)) c.fillRect(tx * K, ty * K, 1, K);
      if (!World.isSolidTile(tx + 1, ty, false)) c.fillRect(tx * K + K - 1, ty * K, 1, K);
    }
    return (MM2.neon = cv);
  }
  // что показать: цели (дальние – значками по краю)
  function mm2Marks() {
    const L = [];
    const trail = StarTrail.view(), next = trail && trail.stars[trail.collected];
    if (next) L.push({ x: next.x, y: next.y, rim: true, k: 'atlas' });
    for (const b of Session.bosses) {
      if (World.CFG.rush && G.rush && b.id !== G.rush.idx) continue;
      if (G.td) { if (b.state !== 'dead' && b.state !== 'sleep') L.push({ x: b.x, y: b.y, ic: '💀', rim: true, k: 'boss' }); continue; } // в обороне босс идёт по дороге: метка – где он сейчас, убитый не отмечается
      L.push({ x: World.landscape ? b.x : b.hx, y: World.landscape ? b.y : b.hy, ic: b.def.immortal ? '♾️' : b.state === 'dead' ? '✅' : '💀', rim: b.state !== 'dead', k: 'boss' });
    }
    if (!World.CFG.noCage || (World.CFG.team && !G.tessaAlly)) L.push({ x: World.tc(World.CAGE.x), y: World.tc(World.CAGE.y), ic: '❤️', rim: true, k: 'cage' });
    if (G.champ && !G.champ.dead) L.push({ x: G.champ.x, y: G.champ.y, ic: '👑', rim: true, k: 'champ' });
    if (G.td) { L.push({ x: G.core.x, y: G.core.y, ic: '💎', rim: true, k: 'core' }); for (const ln of G.td.lanes) if (ln.from <= G.abyss.wave + 1) L.push({ x: ln.gate.x, y: ln.gate.y, ic: '🌀', k: 'gate' }); }
    if (G.ev && G.ev.def.id === 'treasure') L.push({ x: G.ev.tx, y: G.ev.ty, ic: '🧭', rim: true, k: 'ev' });
    if (G.ev && G.ev.thief && !G.ev.thief.dead) L.push({ x: G.ev.thief.x, y: G.ev.thief.y, ic: '💰', rim: true, k: 'ev' });
    for (const sh of World.shrines) L.push({ x: sh.x, y: sh.y, ic: sh.state === 'done' ? '🌀' : '⛩', k: 'shrine' });
    for (const n of World.npcs) L.push({ x: n.x, y: n.y, ic: n.def.ic, k: 'npc' });
    for (const f of World.fires) if (!f.glade || f.lit) L.push({ x: f.x, y: f.y, ic: '🔥', k: 'fire' });
    for (const bd of World.beds) L.push({ x: bd.x, y: bd.y, ic: '🛏', k: 'bed' });
    for (const q of World.pearls) if (!q.got) L.push({ x: q.x, y: q.y, ic: '💗', k: 'pearl' });
    if (NET.on && G.netRun) for (const m of NET.mates.values()) if (m.tx !== undefined) L.push({ x: m.x, y: m.y, ic: m.down ? '💫' : Multiplayer.MATE_EMO[(m.id - 1) % Multiplayer.MATE_EMO.length], rim: true, k: 'mate' });
    return L;
  }
  function mm2Heading(dt) { if (Math.hypot(P.vx, P.vy) > 20) { const a = Math.atan2(P.vy, P.vx); MM2.head += angDiff(MM2.head, a) * Math.min(1, dt * 8); } return MM2.head; }
  function drawMini2(c, mx, my, ms) {
    const col = neonCol(), cx = mx + ms / 2, cy = my + ms / 2, rr = ms / 2, R = 26 * World.T * ms / (MM2.msBase || ms), s = rr / R; // ~26 клеток вокруг; растянутое окно показывает больше
    const X = wx => cx + (wx - P.x) * s, Y = wy => cy + (wy - P.y) * s;
    const now = performance.now() / 1000, head = mm2Heading(1 / 60);
    const inBox = (x, y, m = 0) => x > mx + m && x < mx + ms - m && y > my + m && y < my + ms - m;
    const pap = MM_STYLE === 'paper';
    if (pap) { // листок бумаги на кнопке
      c.save(); c.translate(mx + ms / 2, my + ms / 2); c.rotate(0.018); c.shadowColor = 'rgba(80,50,20,.35)'; c.shadowBlur = 6 * Viewport.DPR; c.shadowOffsetY = 2 * Viewport.DPR;
      c.fillStyle = '#fbf3e0'; c.fillRect(-ms / 2 - 6, -ms / 2 - 6, ms + 12, ms + 12); c.restore();
    }
    c.save();
    c.fillStyle = pap ? '#f3e6c8' : 'rgba(6,3,15,0.9)'; roundRect(c, mx, my, ms, ms, pap ? 3 : 12); c.fill();
    roundRect(c, mx, my, ms, ms, pap ? 3 : 12); c.clip();
    if (pap) {
      const sx2 = (P.x - R) / World.T, sy2 = (P.y - R) / World.T, sw2 = R * 2 / World.T;
      c.imageSmoothingEnabled = false; c.drawImage(Terrain.miniBase, sx2, sy2, sw2, sw2, mx, my, ms, ms);
      c.globalCompositeOperation = 'multiply'; c.globalAlpha = 0.85; c.drawImage(Terrain.miniBase, sx2, sy2, sw2, sw2, mx, my, ms, ms); // краски гуще – карта читается на бумаге
      c.globalCompositeOperation = 'source-over'; c.globalAlpha = 1; c.imageSmoothingEnabled = true;
      c.globalAlpha = 0.5; c.drawImage(Terrain.fog, sx2, sy2, sw2, sw2, mx, my, ms, ms); c.globalAlpha = 1;
    } else {
    // местность вокруг героини: контуры и их мягкое свечение
    const base = mm2Neon(), K = MM2.K, sx = (P.x - R) / World.T * K, sy = (P.y - R) / World.T * K, sw = R * 2 / World.T * K;
    c.imageSmoothingEnabled = false; c.drawImage(base, sx, sy, sw, sw, mx, my, ms, ms);
    c.globalCompositeOperation = 'lighter'; c.globalAlpha = 0.45; c.imageSmoothingEnabled = true; c.drawImage(base, sx, sy, sw, sw, mx - 1, my - 1, ms + 2, ms + 2);
    c.globalAlpha = 1; c.globalCompositeOperation = 'source-over';
    const fsx = (P.x - R) / World.T, fsy = (P.y - R) / World.T, fsw = R * 2 / World.T;
    c.globalAlpha = 0.55; c.drawImage(Terrain.fog, fsx, fsy, fsw, fsw, mx, my, ms, ms); c.globalAlpha = 1;
    c.fillStyle = 'rgba(255,255,255,0.05)'; for (let y = my + ((now * 30) % 4); y < my + ms; y += 4) c.fillRect(mx, y, ms, 1); // строки развёртки
    }
    // враги, сундуки, отметки
    c.fillStyle = pap ? '#c8342a' : '#ff3e7a';
    for (const e of G.enemies) { const ex = X(e.x), ey = Y(e.y); if (!inBox(ex, ey)) continue; c.beginPath(); c.arc(ex, ey, e.elite ? 2.6 : 1.7, 0, TAU); c.fill(); }
    c.lineWidth = 1.5;
    for (const ch of World.chests) if (chestOnMap(ch)) {
      const x = X(ch.x), y = Y(ch.y); if (!inBox(x, y, 2)) continue;
      c.strokeStyle = ch.tier === 'gold' ? '#ffd25a' : ch.tier === 'silver' ? '#e0eaff' : '#c8945a';
      c.beginPath(); c.moveTo(x, y - 3.5); c.lineTo(x + 3.5, y); c.lineTo(x, y + 3.5); c.lineTo(x - 3.5, y); c.closePath(); c.stroke();
    }
    const marks = mm2Marks(), o = World.CFG.rush || World.CFG.abyss ? null : Simulation.objective(), rimList = [];
    c.font = '11px Krilessa Icons, sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle';
    for (const m of marks) {
      const x = X(m.x), y = Y(m.y);
      if (inBox(x, y, 7)) {
        if (m.k === 'atlas') StarArt.mapMark(c, x, y, 6.8, true, false);
        else c.fillText(m.ic, x, y);
      } else if (m.rim) rimList.push(m);
    }
    // героиня: светящаяся стрелка по направлению бега
    c.save(); c.translate(cx, cy); c.rotate(head); c.fillStyle = pap ? '#3a6ab0' : '#fff'; c.shadowColor = pap ? 'rgba(0,0,0,0)' : col; c.shadowBlur = 8;
    c.beginPath(); c.moveTo(7, 0); c.lineTo(-5, -5); c.lineTo(-2, 0); c.lineTo(-5, 5); c.closePath(); c.fill(); c.restore();
    c.restore();
    // рамка-вывеска (готовая картинка) + живые украшения главы
    if (pap) { c.strokeStyle = 'rgba(75,46,30,.45)'; c.lineWidth = 1; roundRect(c, mx, my, ms, ms, 3); c.stroke(); paperPin(c, mx + ms / 2, my - 3, '#3a6ab0'); } else {
    const S = mmSign(MM2.msBase || ms), fl = hash2(Math.floor(now * 12), 7) > 0.985 ? 0.45 : 1; // изредка «моргает», как настоящий неон
    const sk = ms / S.ms, sp = S.pad * sk, sW = S.W * sk;
    c.globalAlpha = fl; c.drawImage(S.cv, mx - sp, my - sp, sW, sW);
    if (S.tints && (now % 2.6) < 0.14) { // глава 4: глитч – рамка двоится розовым и голубым
      c.globalAlpha = 0.55; c.drawImage(S.tints[0], mx - sp - 2, my - sp, sW, sW); c.drawImage(S.tints[1], mx - sp + 2, my - sp + 1, sW, sW);
    }
    c.globalAlpha = 1;
    mmSignLive(c, mx, my, ms, now);
    }
    // дальние цели – по краю, не налезая друг на друга
    // значки – чуть внутри рамки: украшения главы снаружи остаются видны
    const rimAt = (a, inset = 11) => { const k = (rr - inset) / Math.max(Math.abs(Math.cos(a)), Math.abs(Math.sin(a))); return [cx + Math.cos(a) * k, cy + Math.sin(a) * k]; };
    c.textAlign = 'center'; c.textBaseline = 'middle';
    const items = rimList.map(m => ({ m, a: Math.atan2(m.y - P.y, m.x - P.x) })).sort((p1, p2) => p1.a - p2.a), gap = 20 / rr;
    for (let it = 0; it < 8 && items.length > 1; it++) for (let i = 0; i < items.length; i++) {
      const A = items[i], B = items[(i + 1) % items.length]; let d = B.a - A.a; if (i === items.length - 1) d += TAU;
      if (d < gap) { const pu2 = (gap - d) / 2; A.a -= pu2; B.a += pu2; }
    }
    for (const { m, a } of items) {
      const [x, y] = rimAt(a);
      if (m.k === 'atlas') { StarArt.mapMark(c, x, y, 8.5, true, false); continue; }
      c.fillStyle = pap ? '#fbf3e0' : 'rgba(10,8,20,0.88)'; c.beginPath(); c.arc(x, y, 9, 0, TAU); c.fill();
      c.strokeStyle = m.k === 'ev' ? (pap ? '#c8902a' : '#ffd25a') : pap ? 'rgba(75,46,30,.7)' : col; c.lineWidth = 1.5; c.stroke();
      c.font = '11px Krilessa Icons, sans-serif'; c.fillText(m.ic, x, y + 0.5);
    }
    if (o) { // куда идти: стрелка (внутри – у цели, иначе – на краю), пульсирует
      const ox = X(o.x), oy = Y(o.y), a = Math.atan2(o.y - P.y, o.x - P.x), [x, y] = inBox(ox, oy, 14) ? [ox, oy] : rimAt(a, 1), p2 = 1 + 0.2 * Math.sin(now * 7);
      c.save(); c.translate(x, y); c.rotate(a); c.scale(p2, p2);
      c.fillStyle = '#d6f03a'; c.strokeStyle = 'rgba(0,0,0,0.7)'; c.lineWidth = 1.5;
      c.beginPath(); c.moveTo(8, 0); c.lineTo(-5, -6); c.lineTo(-2, 0); c.lineTo(-5, 6); c.closePath(); c.fill(); c.stroke(); c.restore();
    }
    c.textBaseline = 'alphabetic';
    // значок «развернуть» в углу: мини-карта нажимается
    { const ex = mx + ms - 9, ey = my + ms - 9; c.save(); c.globalAlpha = 0.75; c.strokeStyle = pap ? '#4b2e1e' : col; c.lineWidth = 1.6; c.lineCap = 'round';
      c.beginPath(); c.moveTo(ex - 5, ey - 1); c.lineTo(ex - 5, ey - 5); c.lineTo(ex - 1, ey - 5); c.moveTo(ex + 5, ey + 1); c.lineTo(ex + 5, ey + 5); c.lineTo(ex + 1, ey + 5);
      c.moveTo(ex - 5, ey - 5); c.lineTo(ex - 1.5, ey - 1.5); c.moveTo(ex + 5, ey + 5); c.lineTo(ex + 1.5, ey + 1.5); c.stroke(); c.restore(); }
    if (G.mmHintT > 0 && !G.activeBoss) { // первые разы – как пользоваться
      c.globalAlpha = clamp(G.mmHintT / 0.6, 0, 1); c.font = 'bold 10px Krilessa Icons, sans-serif'; c.textAlign = 'right'; c.textBaseline = 'alphabetic';
      const ht = '👆 тап – карта · 🤏 щипок – больше', hw = c.measureText(ht).width + 14, hy = my + ms + 24;
      c.fillStyle = 'rgba(8,4,20,0.8)'; roundRect(c, mx + ms - hw + 4, hy - 12, hw, 17, 8); c.fill();
      c.fillStyle = '#fff'; c.fillText(ht, mx + ms - 3, hy); c.globalAlpha = 1;
    }
  }
  // рамка с украшениями главы: светящиеся трубки рисуются один раз в отдельный холст – каждый кадр только копируется
  function mmSign(ms) {
    ms = Math.round(ms);
    const key = World.CHN + '|' + ms + '|' + Viewport.DPR;
    if (MM2.sign && MM2.sign.key === key) return MM2.sign;
    const pad = 32, W = ms + pad * 2, d = Math.min(Viewport.DPR, 3);
    const cv = makeCanvas(Math.ceil(W * d), Math.ceil(W * d)), c = cv.getContext('2d'); c.scale(d, d);
    mmSignDraw(c, pad, pad, ms);
    let tints = null;
    if (World.CHN === 4) tints = ['#ff3ea5', '#3ff0ff'].map(colr => { const t = makeCanvas(cv.width, cv.height), tcx = t.getContext('2d'); tcx.drawImage(cv, 0, 0); tcx.globalCompositeOperation = 'source-in'; tcx.fillStyle = colr; tcx.fillRect(0, 0, t.width, t.height); return t; });
    return (MM2.sign = { key, cv, pad, W, tints, ms });
  }
  function mmSignDraw(c, mx, my, ms) {
    const col = neonCol(), acc = neonAcc(), ch = World.CHN, cx = mx + ms / 2;
    // неоновая трубка: цветное свечение и белая сердцевина
    const tube = (color, w, path, fill) => {
      c.save(); c.strokeStyle = color; c.lineWidth = w; c.lineCap = 'round'; c.lineJoin = 'round'; c.shadowColor = color; c.shadowBlur = 10;
      c.beginPath(); path(); if (fill) { c.fillStyle = fill; c.fill(); } c.stroke();
      c.shadowBlur = 0; c.globalAlpha = 0.85; c.strokeStyle = '#ffffff'; c.lineWidth = Math.max(0.6, w * 0.32); c.stroke(); c.restore();
    };
    tube(col, 2.6, () => roundRect(c, mx, my, ms, ms, 12));
    tube(col, 1, () => roundRect(c, mx - 5, my - 5, ms + 10, ms + 10, 16));
    const leaf = (x, y, a, k = 1, colr = acc) => tube(colr, 1.5, () => { c.save(); c.translate(x, y); c.rotate(a); c.scale(k, k); c.moveTo(0, 0); c.quadraticCurveTo(6, -6, 13, 0); c.quadraticCurveTo(6, 6, 0, 0); c.moveTo(1, 0); c.lineTo(11, 0); c.restore(); });
    const ears = (outer, inner) => { for (const sg of [-1, 1]) {
      const bx = cx + sg * ms * 0.3, by = my;
      tube(outer, 2, () => { c.moveTo(bx - sg * 10, by + 1); c.lineTo(bx + sg * 5, by - 14); c.lineTo(bx + sg * 11, by + 3); }, 'rgba(6,3,15,0.85)');
      tube(inner, 1.2, () => { c.moveTo(bx - sg * 3, by - 1); c.lineTo(bx + sg * 4, by - 8); c.lineTo(bx + sg * 7, by + 1); });
    } };
    const star5 = (x, y, r) => { for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + i * Math.PI / 5, rr2 = i % 2 ? r * 0.45 : r; const px = x + Math.cos(a) * rr2, py = y + Math.sin(a) * rr2; if (i) c.lineTo(px, py); else c.moveTo(px, py); } c.closePath(); };
    if (ch === 1) { // лес: листья по углам, лоза, грибок, цветок
      leaf(mx - 2, my - 2, -2.4); leaf(mx - 2, my - 2, -1.5, 0.8); leaf(mx + ms + 2, my + ms + 2, 0.75); leaf(mx + ms + 2, my + ms + 2, -0.1, 0.8);
      leaf(mx + ms + 2, my - 2, -0.75, 0.9); leaf(mx - 2, my + ms + 2, 2.4, 0.9);
      tube(acc, 1.2, () => { c.moveTo(mx + 16, my - 2); for (let x = mx + 16; x <= mx + ms - 16; x += 2) c.lineTo(x, my - 2 - Math.sin((x - mx) * 0.16) * 3); });
      for (let x = mx + 26; x < mx + ms - 20; x += 22) leaf(x, my - 2 - Math.sin((x - mx) * 0.16) * 3, -1.2 + ((x / 22) % 2) * 2.4, 0.55);
      tube('#ff6a8a', 1.6, () => { c.arc(mx + 16, my + ms + 9, 7, Math.PI, 0); c.closePath(); }, 'rgba(6,3,15,0.85)');
      tube(acc, 1.3, () => { c.moveTo(mx + 13.5, my + ms + 9); c.lineTo(mx + 14, my + ms + 16); c.lineTo(mx + 18, my + ms + 16); c.lineTo(mx + 18.5, my + ms + 9); });
      const fx = mx + ms - 14, fy = my - 9; for (let i = 0; i < 5; i++) { const a = i / 5 * TAU; tube('#ff9ad0', 1.1, () => c.arc(fx + Math.cos(a) * 3.2, fy + Math.sin(a) * 3.2, 2, 0, TAU)); } tube(acc, 1, () => c.arc(fx, fy, 1.2, 0, TAU), acc);
    } else if (ch === 2) { // Кринж-Цитадель: диско-шар, ноты, звёзды, молния
      const x = mx - 2, y = my + ms - 2, r = 10;
      tube(acc, 1.6, () => { c.moveTo(x, y - r - 10); c.lineTo(x, y - r); c.moveTo(x + r, y); c.arc(x, y, r, 0, TAU); c.moveTo(x - r, y); c.lineTo(x + r, y); c.moveTo(x, y - r); c.lineTo(x, y + r); c.ellipse(x, y, r * 0.5, r, 0, 0, TAU); }, 'rgba(6,3,15,0.9)');
      const note = (nx, ny, k) => tube('#ffffff', 1.3, () => { c.ellipse(nx, ny, 3 * k, 2.2 * k, -0.4, 0, TAU); c.moveTo(nx + 2.8 * k, ny); c.lineTo(nx + 2.8 * k, ny - 11 * k); c.quadraticCurveTo(nx + 7 * k, ny - 9 * k, nx + 6 * k, ny - 5 * k); });
      note(mx - 6, my + 22, 1); note(mx + 12, my - 8, 0.8);
      tube(acc, 1.4, () => star5(mx + ms - 8, my - 8, 7)); tube('#ffffff', 1, () => star5(mx + ms + 7, my + 14, 3.5));
      tube('#ffd25a', 1.6, () => { const lx = mx + ms + 6, ly = my + ms * 0.45; c.moveTo(lx + 2, ly - 12); c.lineTo(lx - 3, ly); c.lineTo(lx + 2, ly); c.lineTo(lx - 2, ly + 12); });
    } else if (ch === 3) { // Зеркальный дворец: корона, самоцветы, леденец
      tube(acc, 1.6, () => { c.moveTo(cx - 14, my + 1); c.lineTo(cx - 14, my - 9); c.lineTo(cx - 7, my - 3); c.lineTo(cx, my - 13); c.lineTo(cx + 7, my - 3); c.lineTo(cx + 14, my - 9); c.lineTo(cx + 14, my + 1); c.closePath(); }, 'rgba(6,3,15,0.9)');
      for (const gx of [-7, 0, 7]) tube('#ff6fb5', 1, () => c.arc(cx + gx, my - 2, 1.3, 0, TAU), '#ff6fb5');
      for (const [x, y] of [[mx - 5, my + ms / 2], [mx + ms + 5, my + ms / 2], [cx, my + ms + 5]]) tube(acc, 1.5, () => { c.moveTo(x, y - 6); c.lineTo(x + 4.5, y); c.lineTo(x, y + 6); c.lineTo(x - 4.5, y); c.closePath(); }, 'rgba(255,210,90,0.3)');
      const lx = mx + ms + 4, ly = my + ms - 16;
      tube('#ffffff', 1.5, () => { c.moveTo(lx, ly + 7); c.lineTo(lx, ly + 22); });
      tube('#ff6fb5', 1.6, () => { c.arc(lx, ly, 7, 0, TAU); for (let a = 0; a < TAU * 1.6; a += 0.3) { const r2 = 6 - a * 0.55; if (r2 < 0.5) break; c[a ? 'lineTo' : 'moveTo'](lx + Math.cos(a) * r2, ly + Math.sin(a) * r2); } }, 'rgba(6,3,15,0.85)');
    } else if (ch === 4) { // ночь глитчей: кошачьи ушки, усы, хвост, глитч-пиксели
      ears(col, '#ff9ad0');
      for (const sg of [-1, 1]) tube('#ffffff', 1, () => { const bx = sg < 0 ? mx - 3 : mx + ms + 3, by = my + ms * 0.58; for (const dy of [-5, 0, 5]) { c.moveTo(bx, by + dy * 0.4); c.lineTo(bx + sg * 13, by + dy); } });
      tube(col, 2, () => { c.moveTo(mx + ms - 4, my + ms + 4); c.bezierCurveTo(mx + ms + 18, my + ms + 6, mx + ms + 16, my + ms - 22, mx + ms + 8, my + ms - 20); });
      for (const [x, y, colr] of [[mx - 4, my + 8, '#ff3ea5'], [mx + 6, my - 5, '#3ff0ff'], [mx + ms + 2, my + ms * 0.3, '#3ff0ff'], [mx + ms * 0.2, my + ms + 3, '#ff3ea5']]) { c.save(); c.fillStyle = colr; c.shadowColor = colr; c.shadowBlur = 8; c.fillRect(x, y, 4, 4); c.fillRect(x + 5, y + 2, 2, 2); c.restore(); }
    } else if (ch === 5) { // детектив Тесса: ушки, лупа, знак вопроса
      ears(col, '#ff9ad0');
      const lx = mx - 4, ly = my + ms - 2;
      tube('#c8a040', 3, () => { c.moveTo(lx - 5, ly + 5); c.lineTo(lx - 14, ly + 14); });
      tube(acc, 1.8, () => c.arc(lx, ly, 7, 0, TAU), 'rgba(160,220,255,0.15)');
      tube('#ffffff', 1.6, () => { const qx = mx + ms + 7, qy = my + 16; c.arc(qx, qy - 4, 4.5, Math.PI * 1.1, Math.PI * 2.4); c.lineTo(qx, qy + 4); c.moveTo(qx, qy + 9); c.arc(qx, qy + 9, 0.6, 0, TAU); });
    } else if (ch === 7) { // бездна: водоросли по углам, ракушка сверху, морская звезда
      for (const [x, sg] of [[mx - 2, 1], [mx + ms + 2, -1]]) for (let k = 0; k < 2; k++) tube('#3dffa0', 1.5, () => { const x0 = x + sg * k * 6; c.moveTo(x0, my + ms + 6); c.bezierCurveTo(x0 + sg * 8, my + ms - 8, x0 - sg * 6, my + ms - 18, x0 + sg * 4, my + ms - 30 - k * 8); });
      tube(acc, 1.5, () => { const sx = cx, sy = my - 3; c.moveTo(sx - 11, sy + 2); c.quadraticCurveTo(sx, sy - 18, sx + 11, sy + 2); c.closePath(); for (let r = -8; r <= 8; r += 4) { c.moveTo(sx, sy + 2); c.lineTo(sx + r, sy - 8); } }, 'rgba(6,3,15,0.85)');
      tube('#ffb04a', 1.4, () => star5(mx + ms + 6, my + 10, 7));
    } else if (ch === 6) { // зима: снежная шапка, сосульки, снежинки
      tube('#ffffff', 1.6, () => { c.moveTo(mx + 6, my + 1); for (let i = 0, x = mx + 6; x < mx + ms - 6; i++) { const w2 = 9 + hash2(i, 9) * 8; c.quadraticCurveTo(x + w2 / 2, my - 6 - hash2(i, 4) * 5, x + w2, my + 1); x += w2; } }, 'rgba(255,255,255,0.12)');
      for (let i = 0; i < 6; i++) { const x = mx + ms * (0.1 + i * 0.16), y = my + ms + 3, l = 6 + hash2(i, 5) * 8; tube(col, 1.4, () => { c.moveTo(x - 2.5, y); c.lineTo(x, y + l); c.lineTo(x + 2.5, y); }); }
      const flake = (x, y, r) => tube(acc, 1.1, () => { for (let k = 0; k < 3; k++) { const a = k * Math.PI / 3; c.moveTo(x - Math.cos(a) * r, y - Math.sin(a) * r); c.lineTo(x + Math.cos(a) * r, y + Math.sin(a) * r); } });
      flake(mx - 4, my - 4, 6); flake(mx + ms + 4, my - 4, 5); flake(mx - 6, my + ms * 0.6, 4); flake(mx + ms + 6, my + ms * 0.5, 4.5);
    }
  }
  // живые украшения: без размытия (оно дорогое), лёгкие точки и линии
  function mmSignLive(c, mx, my, ms, now) {
    const col = neonCol(), acc = neonAcc(), ch = World.CHN, cx = mx + ms / 2, cy = my + ms / 2;
    const dot = (x, y, r, colr, a) => { c.globalAlpha = a * 0.3; c.fillStyle = colr; c.beginPath(); c.arc(x, y, r * 2.6, 0, TAU); c.fill(); c.globalAlpha = a; c.beginPath(); c.arc(x, y, r, 0, TAU); c.fill(); c.globalAlpha = 1; };
    if (ch === 1) for (let i = 0; i < 5; i++) { // светлячки вокруг рамки
      const x = cx + Math.sin(now * 0.6 + i * 1.7) * (ms / 2 + 12), y = cy + Math.cos(now * 0.8 + i * 2.3) * (ms / 2 + 12);
      if (Math.abs(x - cx) < ms / 2 - 2 && Math.abs(y - cy) < ms / 2 - 2) continue;
      dot(x, y, 1.4, acc, 0.5 + 0.5 * Math.sin(now * 4 + i));
    } else if (ch === 2) { // эквалайзер под рамкой и искорки
      const n = 9, bw = (ms - 30) / n;
      for (let i = 0; i < n; i++) { const h = 3 + Math.abs(Math.sin(now * 7 + i * 1.3) * Math.sin(now * 3.1 + i)) * 10; c.globalAlpha = 0.85; c.fillStyle = i % 2 ? col : acc; c.fillRect(mx + 22 + i * bw, my + ms + 9 - h, bw - 3, h); }
      c.globalAlpha = 1;
      for (let i = 0; i < 3; i++) { const t = (now * 0.7 + i / 3) % 1; dot(mx - 2 + Math.cos(2.2 + i) * (14 + t * 10), my + ms - 2 + Math.sin(2.2 + i) * (14 + t * 10), 1.2, '#ffffff', 1 - t); }
    } else if (ch === 3) { // огоньки бегут по рамке, как гирлянда
      const per = ms * 4;
      for (let i = 0; i < 8; i++) {
        let d = (now * 40 + i * per / 8) % per, x, y;
        if (d < ms) { x = mx + d; y = my - 5; } else if ((d -= ms) < ms) { x = mx + ms + 5; y = my + d; } else if ((d -= ms) < ms) { x = mx + ms - d; y = my + ms + 5; } else { d -= ms; x = mx - 5; y = my + ms - d; }
        dot(x, y, 1.5, acc, 0.9);
      }
    } else if (ch === 4) { // моргающие глаза под рамкой
      const bl = Math.sin(now * 1.3) > 0.95 ? 0.15 : 1;
      c.fillStyle = acc; c.globalAlpha = 0.35; for (const sg of [-1, 1]) { c.beginPath(); c.ellipse(cx + sg * 10, my + ms + 12, 6, 4 * bl, 0, 0, TAU); c.fill(); }
      c.globalAlpha = 1; for (const sg of [-1, 1]) { c.beginPath(); c.ellipse(cx + sg * 10, my + ms + 12, 3.5, 2.2 * bl, 0, 0, TAU); c.fill(); }
    } else if (ch === 5) { // лапки шагают по низу
      for (let i = 0; i < 6; i++) {
        const t = ((now * 0.35 + i / 6) % 1), x = mx + 18 + t * (ms - 26), y = my + ms + 9 + (i % 2 ? 3 : -2), a = clamp(Math.min(t, 1 - t) * 6, 0, 1) * 0.85;
        c.globalAlpha = a; c.fillStyle = acc; c.beginPath(); c.ellipse(x, y, 2.2, 1.7, 0, 0, TAU); c.fill();
        for (const [dx, dy] of [[-2.2, -2.4], [0, -3.2], [2.2, -2.4]]) { c.beginPath(); c.arc(x + dx, y + dy, 0.9, 0, TAU); c.fill(); }
      }
      c.globalAlpha = 1;
    } else if (ch === 7) { // пузырьки поднимаются и криль плывёт вдоль верха
      for (let i = 0; i < 7; i++) { const k = (now * (0.18 + hash2(i, 4) * 0.1) + hash2(4, i)) % 1, x = (i % 2 ? mx - 6 : mx + ms + 6) + Math.sin(now * 2 + i) * 3, y = my + ms + 6 - k * (ms + 20); dot(x, y, 1 + hash2(i, 9) * 1.6, '#dff8ff', 0.8 * Math.sin(k * Math.PI)); }
      const kx = mx + ((now * 30) % (ms + 40)) - 20, ky = my - 9 + Math.sin(now * 3) * 2;
      for (let j = 0; j < 3; j++) { const x = kx - j * 9; if (x < mx - 10 || x > mx + ms + 10) continue; dot(x, ky + Math.sin(now * 5 + j) * 1.5, 1.6, acc, 0.9); c.strokeStyle = acc; c.globalAlpha = 0.6; c.lineWidth = 1; c.beginPath(); c.moveTo(x - 2, ky); c.lineTo(x - 6, ky + 1.5); c.stroke(); c.globalAlpha = 1; }
    } else if (ch === 6) for (let i = 0; i < 9; i++) { // снег падает
      const k = (now * (0.08 + hash2(i, 3) * 0.06) + hash2(3, i)) % 1, x = mx - 8 + hash2(i, 8) * (ms + 16) + Math.sin(now + i) * 4, y = my - 14 + k * (ms + 34);
      dot(x, y, 1.1, '#ffffff', 0.8 * Math.sin(k * Math.PI));
    }
  }
  function drawEventFx(c) {
    const ev = G.ev; if (!ev) return;
    const d = ev.def, fade = clamp(ev.t / 0.6, 0, 1) * clamp((d.dur - ev.t) / 0.8, 0, 1);
    const pulse = d.id === 'rage' ? 0.5 + 0.25 * Math.sin(ev.t * 4) : 0.3 + 0.1 * Math.sin(ev.t * 3);
    const g = c.createRadialGradient(Viewport.VW / 2, Viewport.VH / 2, Math.min(Viewport.VW, Viewport.VH) * 0.25, Viewport.VW / 2, Viewport.VH / 2, Math.max(Viewport.VW, Viewport.VH) * 0.72);
    g.addColorStop(0, `rgba(${d.tint},0)`); g.addColorStop(1, `rgba(${d.tint},${0.55 * pulse * fade})`);
    c.fillStyle = g; c.fillRect(0, 0, Viewport.VW, Viewport.VH);
    if (d.id === 'rage') { c.fillStyle = `rgba(255,20,20,${(0.07 + 0.04 * Math.sin(ev.t * 7)) * fade})`; c.fillRect(0, 0, Viewport.VW, Viewport.VH); }
  }
  // сундуки снова видны на карте сразу; тайные (на полянах) – только когда их нашёл или с компасом
  const chestOnMap = ch => !ch.open && (ch.secret ? ch.seen || Encounters.relicLv('compass') >= 3 : !ch.glade || ch.seen || (Encounters.hasRelic('compass') && Math.hypot(ch.x - P.x, ch.y - P.y) < (Encounters.relicLv('compass') >= 2 ? 1700 : 1000)));
  // плашка с подписью слева и числом справа: ширина по тексту, чтобы ничего не налезало
  function pillFit(c, x, y, h, fill, left, right, leftFont, rightFont) {
    const maxW = Viewport.VW - Math.min(124, Viewport.VW * 0.3) - 22 - x;
    let lf = leftFont; c.font = lf; let wl = c.measureText(left).width;
    c.font = rightFont; const wr = right ? c.measureText(right).width : 0;
    let w = Math.max(156, wl + wr + (right ? 22 : 14));
    if (w > maxW) { // не влезает – чуть мельче шрифт
      const px = parseFloat(lf.match(/(\d+)px/)[1]), k = Math.max(0.75, (maxW - wr - 22) / wl);
      lf = lf.replace(/\d+px/, Math.floor(px * k) + 'px'); c.font = lf; wl = c.measureText(left).width; w = maxW;
    }
    c.fillStyle = fill; roundRect(c, x, y, w, h, 8); c.fill();
    return { w, lf };
  }
  function drawEventPill(c, x, y) {
    const ev = G.ev;
    if (ev) {
      const d = ev.def, left = Math.max(0, d.dur - ev.t);
      const lt = d.id === 'horde' ? `${d.ic} Осада · ${ev.kills}/${ev.goal}` : d.id === 'thief' ? `${d.ic} Воришка · лови!`
        : d.id === 'treasure' ? `${d.ic} Клад · ${Math.round(Math.hypot(ev.tx - P.x, ev.ty - P.y) / World.PX_PER_M)} м` : `${d.ic} ${d.name}`;
      const rt = `${Math.ceil(left)}с`;
      const { w, lf } = pillFit(c, x, y, 24, `rgba(${d.tint},0.85)`, lt, rt, '900 11px Krilessa Icons, sans-serif', '900 11px Krilessa Icons, sans-serif');
      c.fillStyle = 'rgba(0,0,0,0.35)'; c.fillRect(x + 6, y + 18, w - 12, 3);
      c.fillStyle = '#fff'; c.fillRect(x + 6, y + 18, (w - 12) * clamp(left / d.dur, 0, 1), 3);
      c.font = lf; c.textAlign = 'left'; c.fillStyle = '#fff';
      c.fillText(lt, x + 6, y + 13);
      c.font = '900 11px Krilessa Icons, sans-serif'; c.textAlign = 'right'; c.fillText(rt, x + w - 6, y + 13);
      return;
    }
    if (World.CFG.rush || G.cutscene || G.finalFinal || G.activeBoss || G.activeShrine) return;
    if (G.evT > 8) {
      const bi = Encounters.curBiome(), cm = Encounters.calmOf(bi);
      if (cm > 0) {
        const st = Encounters.calmStage(bi), n = G.calm[bi], nx = Encounters.CALM_STEPS[st + 1];
        const lt = `🕊️ Усмирение ${Encounters.ROMAN[st]} · −${Math.round(cm * 100)}%`, rt = nx ? `${n}/${nx}` : 'МАКС';
        const { w, lf } = pillFit(c, x, y, 24, 'rgba(30,110,130,0.8)', lt, rt, 'bold 11px Krilessa Icons, sans-serif', 'bold 10px Krilessa Icons, sans-serif');
        c.font = lf; c.textAlign = 'left'; c.fillStyle = '#dffaff';
        c.fillText(lt, x + 6, y + 13);
        c.textAlign = 'right'; c.font = 'bold 10px Krilessa Icons, sans-serif'; c.fillText(rt, x + w - 6, y + 13);
        c.fillStyle = 'rgba(0,0,0,0.35)'; c.fillRect(x + 6, y + 18, w - 12, 3);
        c.fillStyle = '#bff6ff'; c.fillRect(x + 6, y + 18, (w - 12) * (nx ? clamp((n - Encounters.CALM_STEPS[st]) / (nx - Encounters.CALM_STEPS[st]), 0, 1) : 1), 3);
      }
      return;
    }
    // за 8 секунд – что будет и когда
    const nx = G.nextEv, lt = nx ? `🎲 Скоро: ${nx.ic} ${nx.name}` : '🎲 Скоро событие', rt = `${Math.ceil(G.evT)}с`;
    const { w, lf } = pillFit(c, x, y, 20, 'rgba(0,0,0,0.55)', lt, rt, 'bold 11px Krilessa Icons, sans-serif', 'bold 11px Krilessa Icons, sans-serif');
    c.font = lf; c.textAlign = 'left'; c.fillStyle = Math.floor(G.evT * 2) % 2 ? '#ffd25a' : '#ffffff';
    c.fillText(lt, x + 8, y + 14);
    c.font = 'bold 11px Krilessa Icons, sans-serif'; c.textAlign = 'right'; c.fillText(rt, x + w - 7, y + 14);
  }
  // ===== 1.0: акварельная бумага поверх мира =====
  // мир рисуется как раньше, а сверху – тёплый «подъём» тёмных тонов, зерно бумаги (прилипает к миру) и виньетка
  const PAPER = { tex: null, pat: null, vig: null, vw: 0, vh: 0 };
  function paperTex() {
    const S = 384, cv = document.createElement('canvas'); cv.width = cv.height = S; const c = cv.getContext('2d');
    c.fillStyle = '#ffffff'; c.fillRect(0, 0, S, S);
    // пятна акварели – бесшовно: каждое рисуем и со сдвигом на размер плитки
    const wash = (x, y, r, col) => { for (const dx of [-S, 0, S]) for (const dy of [-S, 0, S]) { const g = c.createRadialGradient(x + dx, y + dy, 0, x + dx, y + dy, r); g.addColorStop(0, col); g.addColorStop(1, 'rgba(255,255,255,0)'); c.fillStyle = g; c.fillRect(x + dx - r, y + dy - r, r * 2, r * 2); } };
    for (let i = 0; i < 26; i++) wash(Math.random() * S, Math.random() * S, 40 + Math.random() * 90, Math.random() < 0.5 ? 'rgba(236,214,178,.35)' : 'rgba(214,196,160,.22)');
    // зерно и волокна
    const id = c.getImageData(0, 0, S, S), d = id.data;
    for (let i = 0; i < d.length; i += 4) { const n = (Math.random() - 0.5) * 22; d[i] = Math.min(255, d[i] + n); d[i + 1] = Math.min(255, d[i + 1] + n); d[i + 2] = Math.min(255, d[i + 2] + n * 1.2); }
    c.putImageData(id, 0, 0);
    c.strokeStyle = 'rgba(150,120,80,.10)'; c.lineWidth = 0.7;
    for (let i = 0; i < 90; i++) { const x = Math.random() * S, y = Math.random() * S, a = Math.random() * TAU, l = 6 + Math.random() * 14; c.beginPath(); c.moveTo(x, y); c.quadraticCurveTo(x + Math.cos(a + 0.5) * l * 0.5, y + Math.sin(a + 0.5) * l * 0.5, x + Math.cos(a) * l, y + Math.sin(a) * l); c.stroke(); }
    return cv;
  }
  const NIGHT_TINT = { dark: [96, 104, 176], neon: [110, 90, 180], crystal: [92, 116, 186], volcano: [186, 112, 96], glitch: [84, 146, 160] };
  function paperPass() {
    if (!Terrain.paperOn) return;
    const c = Viewport.ctx;
    if (!PAPER.tex) PAPER.tex = paperTex();
    if (!PAPER.pat) PAPER.pat = c.createPattern(PAPER.tex, 'repeat');
    if (PAPER.vw !== Viewport.VW || PAPER.vh !== Viewport.VH) {
      PAPER.vw = Viewport.VW; PAPER.vh = Viewport.VH; const v = document.createElement('canvas'); v.width = Math.ceil(Viewport.VW / 2); v.height = Math.ceil(Viewport.VH / 2); const vc = v.getContext('2d');
      const g = vc.createRadialGradient(v.width / 2, v.height / 2, Math.min(v.width, v.height) * 0.35, v.width / 2, v.height / 2, Math.hypot(v.width, v.height) * 0.55);
      g.addColorStop(0, 'rgba(255,255,255,1)'); g.addColorStop(1, 'rgba(226,200,160,1)'); vc.fillStyle = g; vc.fillRect(0, 0, v.width, v.height); PAPER.vig = v;
    }
    c.save(); c.setTransform(Viewport.DPR, 0, 0, Viewport.DPR, 0, 0);
    // «ночная сказка»: в тёмных краях – ночной оттенок и тёплый свет вокруг героини
    let nt = null; try { const bid = BIOMES[Encounters.curBiome()] && BIOMES[Encounters.curBiome()].id; nt = G.td ? null : NIGHT_TINT[bid] || null; } catch (e) {}
    if (nt) PAPER.nt = nt;
    PAPER.nk = (PAPER.nk || 0) + ((nt ? 1 : 0) - (PAPER.nk || 0)) * 0.04;
    if (PAPER.nk > 0.02 && PAPER.nt) {
      const [r, g, b] = PAPER.nt, k = PAPER.nk;
      c.globalCompositeOperation = 'multiply'; c.globalAlpha = k * 0.32; c.fillStyle = `rgb(${r},${g},${b})`; c.fillRect(0, 0, Viewport.VW, Viewport.VH);
      c.globalAlpha = 1; c.globalCompositeOperation = 'lighter';
      const hx = (P.x - G.cam.x) * Viewport.ZOOM + Viewport.VW / 2, hy = (P.y - 20 - G.cam.y) * Viewport.ZOOM + Viewport.VH / 2, R = Math.min(Viewport.VW, Viewport.VH) * 0.42;
      const lg = c.createRadialGradient(hx, hy, 0, hx, hy, R); lg.addColorStop(0, `rgba(255,190,110,${0.30 * k})`); lg.addColorStop(1, 'rgba(255,160,80,0)');
      c.fillStyle = lg; c.fillRect(hx - R, hy - R, R * 2, R * 2);
      c.globalCompositeOperation = 'source-over';
    }
    c.globalCompositeOperation = 'multiply';
    const k = Viewport.ZOOM, ox = -(G.cam.x * k) % 384, oy = -(G.cam.y * k) % 384;
    if (PAPER.pat.setTransform) PAPER.pat.setTransform(new DOMMatrix([k * 0.9, 0, 0, k * 0.9, ox, oy]));
    c.fillStyle = PAPER.pat; c.fillRect(0, 0, Viewport.VW, Viewport.VH);
    c.drawImage(PAPER.vig, 0, 0, Viewport.VW, Viewport.VH);
    c.restore();
  }
  // ===== 1.0: бумажный интерфейс =====
  const INK = '#4b2e1e', NOTE_C = 'rgba(251,244,226,.94)';
  const HAND = s => `400 ${s}px Krilessa Icons, Neucha, sans-serif`;
  const _lightC = new Map();
  function lightCol(col) { // светлый цвет текста на бумаге не читается – такой меняем на чернила
    let v = _lightC.get(col); if (v !== undefined) return v;
    const m = /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(col || ''); v = false;
    if (m) { let h = m[1]; if (h.length === 3) h = h.split('').map(x => x + x).join(''); const n = parseInt(h, 16); v = (0.3 * (n >> 16) + 0.59 * ((n >> 8) & 255) + 0.11 * (n & 255)) > 190; }
    _lightC.set(col, v); return v;
  }
  function paperPin(c, x, y, col) {
    c.save(); c.shadowColor = 'rgba(60,30,10,.4)'; c.shadowBlur = 3 * Viewport.DPR; c.shadowOffsetY = 1.5 * Viewport.DPR; c.fillStyle = col; c.beginPath(); c.arc(x, y, 5, 0, TAU); c.fill(); c.restore();
    c.fillStyle = 'rgba(255,255,255,.6)'; c.beginPath(); c.arc(x - 1.5, y - 1.5, 1.6, 0, TAU); c.fill();
  }
  function paperNote(c, x, y, w, h, rot) {
    c.save(); c.translate(x + w / 2, y + h / 2); c.rotate(rot); c.shadowColor = 'rgba(80,50,20,.3)'; c.shadowBlur = 6 * Viewport.DPR; c.shadowOffsetY = 2 * Viewport.DPR;
    c.fillStyle = NOTE_C; c.fillRect(-w / 2, -h / 2, w, h); c.restore();
  }
  function handText(c, t, x, y, size, col, al = 'left', stroke) {
    c.font = HAND(size); c.textAlign = al; if (stroke) { c.lineJoin = 'round'; c.lineWidth = 4; c.strokeStyle = stroke; c.strokeText(t, x, y); } c.fillStyle = col; c.fillText(t, x, y);
  }
  function inkLine(c, x1, y1, x2, y2, col, lw) { for (const [dx, dy, a] of [[0, 0, 1], [0.8, 0.6, 0.45]]) { c.globalAlpha = a; c.strokeStyle = col; c.lineWidth = lw; c.beginPath(); c.moveTo(x1 + dx, y1 + dy); c.lineTo(x2 + dx, y2 - 0.6 + dy); c.stroke(); } c.globalAlpha = 1; }
  function inkFlask(c, x, y, k) {
    const p = new Path2D(`M${x - 4},${y - 16} L${x + 4},${y - 16} L${x + 4},${y - 8} C${x + 14},${y - 4} ${x + 14},${y + 14} ${x},${y + 14} C${x - 14},${y + 14} ${x - 14},${y - 4} ${x - 4},${y - 8} Z`);
    c.fillStyle = 'rgba(255,255,255,.65)'; c.fill(p); c.save(); c.clip(p);
    const top = y + 14 - 26 * clamp(k, 0, 1); c.fillStyle = k < 0.3 ? 'rgba(232,60,40,.85)' : 'rgba(216,70,58,.75)'; c.beginPath(); c.moveTo(x - 16, top); c.quadraticCurveTo(x, top - 3, x + 16, top); c.lineTo(x + 16, y + 16); c.lineTo(x - 16, y + 16); c.fill();
    c.fillStyle = 'rgba(255,255,255,.55)'; c.fillRect(x - 7, y - 2, 2.5, 9); c.restore();
    for (const [dx, dy, a] of [[0, 0, 1], [0.8, 0.6, 0.4]]) { c.save(); c.globalAlpha = a; c.translate(dx, dy); c.strokeStyle = INK; c.lineWidth = 1.4; c.stroke(p); c.restore(); }
    c.fillStyle = '#a87a52'; c.fillRect(x - 5, y - 20, 10, 5);
  }
  function drawPaperTop(c, x0, y0, w, infoT) {
    const h = 68;
    paperNote(c, x0, y0, w, h, -0.012); paperPin(c, x0 + w * 0.55, y0 + 3, '#d8463a');
    // портрет героини в нарисованном кружке
    const px = x0 + 32, py = y0 + 32, pr = 21;
    c.save(); c.beginPath(); c.arc(px, py, pr, 0, TAU); c.fillStyle = '#f6e2c8'; c.fill(); c.clip();
    try { c.drawImage(Expedition.heroAvatar(P.hero), px - pr, py - pr, pr * 2, pr * 2); } catch (e) {}
    c.restore();
    for (const [dx, dy, a] of [[0, 0, 1], [0.8, 0.6, 0.45]]) { c.globalAlpha = a; c.strokeStyle = INK; c.lineWidth = 1.5; c.beginPath(); c.arc(px + dx, py + dy, pr + 1, 0, TAU); c.stroke(); } c.globalAlpha = 1;
    handText(c, String(P.level), px + 19, py + 26, 17, '#3a6ab0', 'center', NOTE_C);
    // здоровье – колба, опыт – синяя линия
    const k = clamp(P.hp / P.maxHp, 0, 1);
    inkFlask(c, x0 + 74, y0 + 28, k);
    handText(c, `${Math.max(0, Math.ceil(P.hp))}/${Math.round(P.maxHp)}`, x0 + 90, y0 + 27, 18, k < 0.3 ? '#c8241a' : '#8a2a1a');
    const lx1 = x0 + 90, lx2 = x0 + w - 10, ly = y0 + 41;
    inkLine(c, lx1, ly, lx2, ly, 'rgba(75,46,30,.45)', 1.1);
    c.strokeStyle = '#4a86c8'; c.lineWidth = 4; c.lineCap = 'round'; c.beginPath(); c.moveTo(lx1 + 1, ly); c.quadraticCurveTo(lx1 + (lx2 - lx1) * 0.4, ly - 2, lx1 + (lx2 - lx1) * clamp(P.xp / P.xpNext, 0.01, 1), ly - 0.5); c.stroke(); c.lineCap = 'butt';
    // строка о главе: подгоняем размер под ширину
    let fs = 14; c.font = HAND(fs); while (c.measureText(infoT).width > w - 70 && fs > 10) { fs--; c.font = HAND(fs); }
    handText(c, infoT, x0 + 64, y0 + 60, fs, 'rgba(75,46,30,.85)');
  }
  function drawTeamRush(c, y) {
    const r = G.rush, link = r.link, boss = G.activeBoss;
    const width = Math.min(290, Viewport.VW - 34), x = (Viewport.VW - width) / 2;
    const active = boss && link.active > 0, ink = active ? '#ffd88c' : '#94dcca';
    c.save();
    c.fillStyle = 'rgba(21,30,43,.94)'; c.strokeStyle = active ? '#dda95d' : '#598a87'; c.lineWidth = 1;
    roundRect(c, x, y, width, 32, 8); c.fill(); c.stroke();
    c.textAlign = 'left'; c.textBaseline = 'middle';
    c.font = '900 13px Nunito, sans-serif'; c.fillStyle = ink;
    if (!boss) {
      const next = Session.bosses[r.idx];
      if (next) {
        c.fillText(`${r.idx + 1}/${r.total} · ${next.name}`, x + 10, y + 16, width - 82);
        c.textAlign = 'right'; c.fillStyle = '#fff0ce';
        c.fillText(`Через ${Math.ceil(r.wait)} с`, x + width - 10, y + 16);
      }
    } else {
      const pips = Math.max(2, link.need);
      for (let i = 0; i < pips; i++) {
        c.fillStyle = active || i < link.hits.length ? ink : '#536373';
        c.beginPath(); c.arc(x + 12 + i * 10, y + 16, 3.5, 0, TAU); c.fill();
      }
      const left = x + 16 + pips * 10;
      let text = `Связка · ударь за 4 с (${link.hits.length}/${link.need})`;
      if (active) text = `Брешь · +25% урона · ${Math.ceil(link.active)} с`;
      else if (link.rest > 0) text = `Новая связка через ${Math.ceil(link.rest)} с`;
      else if (link.need < 2) text = 'Для связки нужны двое в бою';
      else if (link.hits.includes(NET.id)) text = `Твой удар есть · ждём команду (${link.hits.length}/${link.need})`;
      c.fillStyle = active ? '#ffe3a4' : '#ecf4f1';
      c.fillText(text, left, y + 16, x + width - left - 9);
    }
    c.restore();
  }

  function renderHUD() {
    const c = Viewport.ctx;
    c.setTransform(Viewport.DPR, 0, 0, Viewport.DPR, 0, 0);
    if (Session.state === 'play' || Session.state === 'pause' || Session.state === 'levelup') { Expedition.drawSeaFx(c); drawEventFx(c); HouseChapter.drawHouseFx(c); }
    if (G.hurtFlash > 0) {
      const g = c.createRadialGradient(Viewport.VW / 2, Viewport.VH / 2, Math.min(Viewport.VW, Viewport.VH) * 0.3, Viewport.VW / 2, Viewport.VH / 2, Math.max(Viewport.VW, Viewport.VH) * 0.7);
      g.addColorStop(0, 'rgba(255,0,0,0)'); g.addColorStop(1, `rgba(255,0,0,${G.hurtFlash})`);
      c.fillStyle = g; c.fillRect(0, 0, Viewport.VW, Viewport.VH);
    }
    const top = Viewport.SAFE_TOP + 10;
    const lx = 58;
    const topLeft = () => {
    // плашка уровня растягивается под текст (до мини-карты), при нехватке места текст чуть мельче
    const lvT = `Ур. ${P.level}`, zl = Actors.zoneE(Encounters.curBiome());
    let infoT = Defense.defOn() ? Defense.defInfo() : World.CFG.abyss && G.abyss ? `🕳️ Бездна · волна ${G.abyss.wave} · ${RunStats.fmtT(G.abyss.t)}`
      : G.daily ? `📅 ${RunStats.fmtT(G.daily.left)} · ${RunStats.fmtN(G.daily.score)} очк.${Challenges.mutIds().length ? ' ' + Challenges.mutIds().map(id => Challenges.MUT_BY[id].ic).join('') : ''}`
      : World.CFG.rush && G.rush ? `⚔️ Раш · ${Math.min(G.rush.idx + 1, G.rush.total)}/${G.rush.total} · ${RunStats.fmtT(G.rush.t)}`
      : `Гл.${World.CHN} · Б ${G.defeated.filter(Boolean).length}/${World.CFG.bosses.length} · зона ${isFinite(zl) ? zl : '–'}`;
    if (Terrain.paperOn) { // 1.0: записка на кнопке – портрет, колба здоровья, опыт, уровень
      const nw = clamp(Viewport.VW - Math.min(124, Viewport.VW * 0.3) - 34, 170, 236);
      drawPaperTop(c, 8, top - 2, nw, infoT);
      const ly = top + 78;
      if (Session.state === 'play') drawEventPill(c, lx, ly);
      if (Defense.defOn()) DefenseView.drawDefHud(c, lx, ly);
      if (NET.on && G.netRun) Multiplayer.netHud(c, lx, Defense.teamHudY(ly + (G.ev || G.nextEv ? 30 : 0)));
      return;
    }
    c.font = '900 14px Krilessa Icons, sans-serif'; const wL = c.measureText(lvT).width;
    let fI = 11; c.font = `bold ${fI}px Krilessa Icons, sans-serif`; let wI = c.measureText(infoT).width;
    const lbMax = Viewport.VW - Math.min(124, Viewport.VW * 0.3) - 24 - lx - (MM_STYLE !== 'classic' ? 14 : 0);
    let lbw = Math.max(156, wL + wI + 26);
    while (lbw > lbMax && fI > 9) { fI--; c.font = `bold ${fI}px Krilessa Icons, sans-serif`; wI = c.measureText(infoT).width; lbw = Math.max(156, wL + wI + 26); }
    if (lbw > lbMax && !World.CFG.rush) { infoT = infoT.replace(' · зона ', ' · з.'); wI = c.measureText(infoT).width; }
    lbw = Math.min(lbMax, Math.max(156, wL + wI + 26));
    c.fillStyle = 'rgba(19,31,49,.91)';
    roundRect(c, lx, top, lbw, 40, 9); c.fill();
    c.save(); c.strokeStyle = '#b49a69'; c.lineWidth = 1; c.stroke(); c.restore();
    c.font = '900 14px Krilessa Icons, sans-serif'; c.textAlign = 'left'; c.fillStyle = '#ffe0a1';
    c.fillText(lvT, lx + 8, top + 17);
    c.font = `bold ${fI}px Krilessa Icons, sans-serif`; c.fillStyle = '#fff'; c.fillText(infoT, lx + 18 + wL, top + 17);
    c.fillStyle = 'rgba(255,255,255,0.15)'; c.fillRect(lx + 8, top + 25, lbw - 16, 7);
    c.fillStyle = '#8ad8c9'; c.fillRect(lx + 8, top + 25, (lbw - 16) * clamp(P.xp / P.xpNext, 0, 1), 7);
    if (Session.state === 'play') drawEventPill(c, lx, top + 46);
    if (Defense.defOn()) DefenseView.drawDefHud(c, lx, top + 46);
    if (NET.on && G.netRun) Multiplayer.netHud(c, lx, Defense.teamHudY(top + 46 + (G.ev || G.nextEv ? 30 : 0)));
    };
    topLeft();
    // мини-карта: щипком её можно растянуть в сторону игры (в бою с боссом – обычного размера)
    const neonMM = MM_STYLE !== 'classic', mmB = MM_STYLE === 'neon' ? 22 : neonMM ? 8 : 0; // у неоновой рамки украшения сверху и снизу
    const msBase = Math.min(124, Viewport.VW * 0.3), msMax = Math.max(msBase, Math.min(Viewport.VW - 30, Viewport.VH / 2 - 78 - top)); // не наезжает на героиню в центре
    { // растянутая щипком мини-карта через пару секунд плавно возвращается к обычному размеру
      const nowT = performance.now(), dtT = Math.min(0.1, (nowT - (MM2.lastT || nowT)) / 1000); MM2.lastT = nowT;
      if (MM2.sizeF && !Controls.MMP.pinch && nowT > (MM2.relaxAt || 0)) {
        const cur = MM2.sizeF * Viewport.VW, nxt = cur + (msBase - cur) * Math.min(1, dtT * 7);
        MM2.sizeF = Math.abs(nxt - msBase) < 1.5 ? 0 : nxt / Viewport.VW;
      }
    }
    const ms = G.activeBoss || World.CFG.rush ? msBase : clamp(MM2.sizeF ? MM2.sizeF * Viewport.VW : msBase, msBase * 0.8, msMax);
    const mx = Viewport.VW - ms - 10, my = top + (MM_STYLE === 'neon' ? 8 : neonMM ? 4 : 0);
    MM2.msBase = msBase; MM2.msMax = msMax;
    G.miniRect = { x: mx, y: my, s: ms };
    if (MM_STYLE !== 'classic') drawMini2(c, mx, my, ms); else {
    c.save();
    roundRect(c, mx - 3, my - 3, ms + 6, ms + 6, 12); c.fillStyle = 'rgba(255,255,255,0.85)'; c.fill();
    roundRect(c, mx, my, ms, ms, 10); c.clip();
    c.imageSmoothingEnabled = false;
    const mapH = ms * World.PLAY_H / World.MW;
    c.fillStyle = '#152136'; c.fillRect(mx,my,ms,ms);
    c.translate(0,(ms-mapH)/2);
    c.drawImage(Terrain.miniBase, mx, my, ms, mapH);
    c.globalAlpha = 0.72; c.drawImage(Terrain.fog, mx, my, ms, mapH); c.globalAlpha = 1;
    c.imageSmoothingEnabled = true;
    const k = ms / World.WORLD_W;
    c.fillStyle = '#ff3b3b';
    for (const e of G.enemies) c.fillRect(mx + e.x * k - 1.5, my + e.y * k - 1.5, 3, 3);
    c.fillStyle = '#ffd25a';
    for (const ch of World.chests) if (chestOnMap(ch)) {
      c.fillStyle = ch.tier === 'gold' ? '#ffd25a' : ch.tier === 'silver' ? '#e0eaff' : '#c8945a';
      c.fillRect(mx + ch.x * k - 2, my + ch.y * k - 2, 4, 4);
    }
    c.fillStyle = '#5be3ff';
    const blink = 0.35 + 0.65 * Math.abs(Math.sin(performance.now() / 380));
    for (const s of World.shrines) {
      const sx = mx + s.x * k, sy = my + s.y * k;
      if (s.state === 'done') { c.fillStyle = '#c77dff'; c.beginPath(); c.arc(sx, sy, 2.4, 0, TAU); c.fill(); continue; }
      c.globalAlpha = blink; c.fillStyle = '#5be3ff'; c.fillRect(sx - 2.5, sy - 2.5, 5, 5);
      c.strokeStyle = '#5be3ff'; c.lineWidth = 1; c.beginPath(); c.arc(sx, sy, 4 + blink * 2.5, 0, TAU); c.stroke(); c.globalAlpha = 1;
    }
    for (const bd of World.beds) { c.fillStyle = '#ff9ad0'; c.fillRect(mx + bd.x * k - 1.5, my + bd.y * k - 1.5, 3, 3); }
    for (const f of World.fires) if (!f.glade || f.lit) { c.fillStyle = '#ff8a2a'; c.beginPath(); c.arc(mx + f.x * k, my + f.y * k, 2.2, 0, TAU); c.fill(); }
    for (const q of World.pearls) if (!q.got) { c.fillStyle = '#ff9ad0'; c.beginPath(); c.arc(mx + q.x * k, my + q.y * k, 2.4, 0, TAU); c.fill(); }
    for (const q of World.clues) if (!q.found && (G.clearSight || G.revealT > 0 || (G.pet && Math.hypot(q.x - P.x, q.y - P.y) < 700) || Math.hypot(q.x - P.x, q.y - P.y) < 350 * Actors.lv('c5nose'))) {
      c.globalAlpha = blink; c.fillStyle = '#ffd25a'; c.beginPath(); c.arc(mx + q.x * k, my + q.y * k, 2.5, 0, TAU); c.fill(); c.globalAlpha = 1;
    }
    for (const n of World.npcs) { c.fillStyle = '#ffffff'; c.fillRect(mx + n.x * k - 2, my + n.y * k - 2, 4, 4); }
    for (const it of World.qitems) if (it.active && !it.taken) { c.globalAlpha = blink; c.fillStyle = '#7dff7d'; c.fillRect(mx + it.x * k - 2, my + it.y * k - 2, 4, 4); c.globalAlpha = 1; }
    if (G.champ && !G.champ.dead) { c.globalAlpha = blink; c.font = '10px Krilessa Icons, sans-serif'; c.textAlign = 'center'; c.fillText('👑', mx + G.champ.x * k, my + G.champ.y * k + 4); c.globalAlpha = 1; }
    c.font = '10px Krilessa Icons, sans-serif'; c.textAlign = 'center';
    for (const b of Session.bosses) {
      if (World.CFG.rush && G.rush && b.id !== G.rush.idx) continue;
      if (G.td) { if (b.state !== 'dead' && b.state !== 'sleep') c.fillText('💀', mx + b.x * k, my + b.y * k + 4); continue; }
      c.fillText(b.def.immortal ? '♾️' : b.state === 'dead' ? '✅' : '💀', mx + (World.landscape ? b.x : b.hx) * k, my + (World.landscape ? b.y : b.hy) * k + 4);
    }
    if (!World.CFG.noCage || (World.CFG.team && !G.tessaAlly)) c.fillText('❤️', mx + World.tc(World.CAGE.x) * k, my + World.tc(World.CAGE.y) * k - 4);
    if (G.core) c.fillText('💎', mx + G.core.x * k, my + G.core.y * k + 4);
    const trail = StarTrail.view(), next = trail && trail.stars[trail.collected];
    if (next) StarArt.mapMark(c, mx + next.x * k, my + next.y * k, 6.2, true, false);
    c.strokeStyle = '#fff'; c.lineWidth = 2; c.beginPath(); c.arc(mx + P.x * k, my + P.y * k, 4, 0, TAU); c.stroke();
    c.restore();
    c.font = '11px Krilessa Icons, sans-serif'; c.textAlign = 'right'; c.globalAlpha = 0.8; c.fillText('🔍', mx + ms - 3, my + ms - 4); c.globalAlpha = 1;
    }
    if (ms > msBase * 1.1 && mx < lx + 210) topLeft(); // большая мини-карта заходит под плашку уровня – плашка остаётся сверху
    // подруга без сил: записка внизу и стрелка к ней (у края экрана, если она далеко)
    if (NET.on && G.netRun && (Session.state === 'play' || Session.state === 'pause')) {
      const downs = [...NET.mates.values()].filter(m => m.down && m.tx !== undefined && m.id !== NET.id);
      if (downs.length) {
        const m0 = downs[0], nm = (m0.name || 'Подруга') + (downs.length > 1 ? ` и ещё ${downs.length - 1}` : ''), dist = Math.round(Math.hypot(m0.x - P.x, m0.y - P.y) / World.PX_PER_M);
        const txt = `💫 ${nm} без сил – подними! · ${dist} м`, ny = Viewport.VH - 175;
        c.font = HAND(17); const tw = c.measureText(txt).width + 26;
        paperNote(c, Viewport.VW / 2 - tw / 2, ny - 18, tw, 30, -0.01); handText(c, txt, Viewport.VW / 2, ny + 3, 17, '#b8302a', 'center');
        const pu = 1 + Math.sin(G.time * 6) * 0.12;
        for (const m of downs) {
          const sx = (m.x - G.cam.x) * Viewport.ZOOM + Viewport.VW / 2, sy = (m.y - G.cam.y) * Viewport.ZOOM + Viewport.VH / 2, mg = 34;
          if (sx > mg && sx < Viewport.VW - mg && sy > top + 80 && sy < Viewport.VH - 120) { // видна – стрелка над ней
            c.save(); c.translate(sx, sy - 46 * Viewport.ZOOM - Math.abs(Math.sin(G.time * 5)) * 8); c.scale(pu, pu);
            c.fillStyle = '#e04a3a'; c.strokeStyle = INK; c.lineWidth = 1.5; c.beginPath(); c.moveTo(-9, -10); c.lineTo(9, -10); c.lineTo(0, 4); c.closePath(); c.fill(); c.stroke(); c.restore();
            continue;
          }
          const a = Math.atan2(sy - Viewport.VH / 2, sx - Viewport.VW / 2), ex = clamp(sx, mg, Viewport.VW - mg), ey = clamp(sy, top + 96, Viewport.VH - 130);
          c.save(); c.translate(ex, ey);
          c.fillStyle = 'rgba(251,244,226,.95)'; c.strokeStyle = INK; c.lineWidth = 1.5; c.beginPath(); c.arc(0, 0, 15, 0, TAU); c.fill(); c.stroke();
          c.font = '15px Krilessa Icons, sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText('💫', 0, 1); c.textBaseline = 'alphabetic';
          c.rotate(a); c.scale(pu, pu); c.fillStyle = '#e04a3a'; c.beginPath(); c.moveTo(25, 0); c.lineTo(16, -7); c.lineTo(16, 7); c.closePath(); c.fill(); c.stroke();
          c.restore();
        }
      }
    }
    // комбо
    if (G.combo >= 5) {
      const cy = top + ms + mmB + (G.activeBoss ? 70 : 30) + (G.rush && G.rush.link && G.rush.players > 1 ? 45 : 0) + (Defense.defOn() && Viewport.VH > Viewport.VW ? 150 : 0); // в обороне справа заклинания
      c.globalAlpha = clamp(G.comboT / 0.6, 0, 1); c.textAlign = 'right';
      c.font = '900 18px Krilessa Icons, sans-serif'; c.fillStyle = '#000'; c.fillText(`КОМБО x${G.combo}`, Viewport.VW - 11, cy + 1);
      c.fillStyle = G.combo >= 50 ? '#ff3ea5' : G.combo >= 20 ? '#ffd25a' : '#ffffff'; c.fillText(`КОМБО x${G.combo}`, Viewport.VW - 12, cy);
      c.font = 'bold 10px Krilessa Icons, sans-serif'; c.fillStyle = '#bff6ff'; c.fillText(`+${Math.min(G.combo, 100)}% опыта`, Viewport.VW - 12, cy + 13);
      c.globalAlpha = 1;
    }
    // босс
    const b = G.activeBoss;
    if (b && b.state === 'fight') {
      const w = Math.min(Viewport.VW - 40, 380), x = (Viewport.VW - w) / 2, y = top + ms + 12 + mmB;
      if (!Terrain.paperOn || (b.def.immortal && G.finalFinal)) { c.fillStyle = 'rgba(0,0,0,0.7)'; roundRect(c, x - 4, y - 4, w + 8, 34, 8); c.fill();
      c.fillStyle = '#3a0a0a'; c.fillRect(x, y + 13, w, 11); }
      if (b.def.immortal && G.finalFinal) {
        // бессмертный: вместо здоровья – заряд ДРУЖБА-СУПЕР
        const F = G.finalFinal, k2 = clamp(F.t / F.need, 0, 1), seg = w / RAINBOW.length;
        RAINBOW.forEach((col, i) => { c.fillStyle = col; c.fillRect(x + i * seg, y + 13, seg, 11); });
        c.fillStyle = '#ff3ea5'; c.fillRect(x, y + 13, w, 11);
        c.save(); c.beginPath(); c.rect(x, y + 13, w * k2, 11); c.clip();
        RAINBOW.forEach((col, i) => { c.fillStyle = col; c.fillRect(x + i * seg, y + 13, seg + 1, 11); });
        c.restore();
        c.font = '900 12px Krilessa Icons, sans-serif'; c.textAlign = 'center'; c.fillStyle = '#ffd25a';
        c.fillText(`${b.name.toUpperCase()} · НЕУЯЗВИМ · ПРОДЕРЖИСЬ ${Math.ceil(Math.max(0, F.need - F.t))}с`, Viewport.VW / 2, y + 8);
        c.font = '900 9px Krilessa Icons, sans-serif'; c.fillStyle = '#fff'; c.fillText(`💜 ДРУЖБА-СУПЕР ${Math.floor(k2 * 100)}%${F.bank > 0.05 ? ' ⏩' : ''}`, Viewport.VW / 2, y + 22);
      } else if (Terrain.paperOn) {
        const bw = Math.min(Viewport.VW - 70, 260), bx = (Viewport.VW - bw) / 2, ny = y + 16;
        handText(c, b.name, Viewport.VW / 2, ny, 25, INK, 'center', 'rgba(251,243,224,.88)');
        c.font = HAND(25); const nw2 = Math.min(bw, c.measureText(b.name).width + 10);
        c.strokeStyle = '#c8342a'; c.lineWidth = 1.6; c.beginPath(); c.moveTo(Viewport.VW / 2 - nw2 / 2, ny + 6); for (let q = -nw2 / 2; q <= nw2 / 2; q += 5) c.lineTo(Viewport.VW / 2 + q, ny + 6 + Math.sin(q / 3) * 1.6); c.stroke();
        const by = ny + 14, bh = 13, k2 = clamp(b.hp / b.maxHp, 0, 1);
        c.fillStyle = 'rgba(251,243,224,.75)'; c.fillRect(bx, by, bw, bh);
        c.fillStyle = b.stage >= 2 ? 'rgba(200,30,60,.62)' : b.stage === 1 ? 'rgba(220,90,40,.6)' : 'rgba(200,52,42,.58)';
        c.beginPath(); c.moveTo(bx + 2, by + 2); c.lineTo(bx + bw * k2, by + 1); c.lineTo(bx + bw * k2 - 2, by + bh - 1); c.lineTo(bx + 1, by + bh); c.fill();
        for (const [dx, dy, a] of [[0, 0, 1], [0.8, 0.6, 0.45]]) { c.globalAlpha = a; c.strokeStyle = INK; c.lineWidth = 1.3; c.beginPath(); c.moveTo(bx + dx, by + dy); c.lineTo(bx + bw + 1 + dx, by - 0.5 + dy); c.lineTo(bx + bw + dx, by + bh + 0.5 + dy); c.lineTo(bx - 1 + dx, by + bh + dy); c.closePath(); c.stroke(); } c.globalAlpha = 1;
        c.strokeStyle = INK; c.lineWidth = 1.2; for (const st of b.def.stages) if (st.at) { c.beginPath(); c.moveTo(bx + bw * st.at, by - 2); c.lineTo(bx + bw * st.at + 0.5, by + bh + 2); c.stroke(); }
        handText(c, `ур. ${b.level} · стадия ${b.stage + 1}/${b.def.stages.length}`, Viewport.VW / 2, by + bh + 16, 14, 'rgba(75,46,30,.8)', 'center', 'rgba(251,243,224,.8)');
      } else {
        c.fillStyle = b.stage >= 2 ? '#ff3b6b' : b.stage === 1 ? '#ff7a2f' : '#e53935';
        c.fillRect(x, y + 13, w * clamp(b.hp / b.maxHp, 0, 1), 11);
        c.fillStyle = '#ffffff';
        for (const st of b.def.stages) if (st.at) c.fillRect(x + w * st.at - 1, y + 11, 2, 15);
        c.font = '900 12px Krilessa Icons, sans-serif'; c.textAlign = 'center'; c.fillStyle = '#ffd25a';
        c.fillText(`${b.name.toUpperCase()} · УР. ${b.level} · СТАДИЯ ${b.stage + 1}/${b.def.stages.length}`, Viewport.VW / 2, y + 8);
      }
    }
    if (G.rush && G.rush.link && G.rush.players > 1 && !G.rush.done && Session.state === 'play') {
      drawTeamRush(c, top + ms + mmB + (b ? (Terrain.paperOn ? 80 : 47) : 18));
    } else if (World.CFG.rush && G.rush && !G.rush.done && !G.activeBoss && G.rush.wait > 0 && Session.state === 'play') {
      const nb = Session.bosses[G.rush.idx];
      if (nb) {
        c.font = '900 16px Krilessa Icons, sans-serif'; c.textAlign = 'center';
        const txt = `Следующий: ${nb.name} через ${Math.ceil(G.rush.wait)}…`;
        c.fillStyle = '#000'; c.fillText(txt, Viewport.VW / 2 + 1, top + ms + 41); c.fillStyle = '#ffa080'; c.fillText(txt, Viewport.VW / 2, top + ms + 40);
      }
    }
    if (G.activeShrine) {
      c.font = '900 14px Krilessa Icons, sans-serif'; c.textAlign = 'center'; c.fillStyle = '#000';
      c.fillText(`Испытание: осталось ${G.activeShrine.left}`, Viewport.VW / 2 + 1, top + ms + 63);
      c.fillStyle = '#ff8a8a'; c.fillText(`Испытание: осталось ${G.activeShrine.left}`, Viewport.VW / 2, top + ms + 62);
    }
    const joyOn = Controls.input.touchId !== null;
    if (joyOn || (Controls.JOY.fixed && Session.state === 'play' && !G.cutscene)) { // закреплённый виден всегда, плавающий – пока палец на экране
      const [bx, by] = joyOn ? [Controls.input.bx, Controls.input.by] : Controls.joyBase(), kx = joyOn ? Controls.input.mx : 0, ky = joyOn ? Controls.input.my : 0;
      if (Terrain.paperOn) {
        c.fillStyle = `rgba(255,248,230,${joyOn ? 0.22 : 0.14})`; c.strokeStyle = `rgba(75,46,30,${joyOn ? 0.32 : 0.2})`; c.lineWidth = 1.5;
        c.beginPath(); c.arc(bx, by, Controls.JOY_R, 0, TAU); c.fill(); c.stroke();
        c.save(); c.shadowColor = 'rgba(80,50,20,.3)'; c.shadowBlur = 6 * Viewport.DPR; c.shadowOffsetY = 2 * Viewport.DPR; c.fillStyle = `rgba(255,248,232,${joyOn ? 0.95 : 0.6})`;
        c.beginPath(); c.arc(bx + kx * Controls.JOY_R, by + ky * Controls.JOY_R, 22 * Controls.JOY.k, 0, TAU); c.fill(); c.restore();
      } else {
      c.strokeStyle = `rgba(255,255,255,${joyOn ? 0.35 : 0.22})`; c.lineWidth = 3; c.fillStyle = `rgba(255,255,255,${joyOn ? 0.08 : 0.05})`;
      c.beginPath(); c.arc(bx, by, Controls.JOY_R, 0, TAU); c.fill(); c.stroke();
      c.fillStyle = `rgba(255,255,255,${joyOn ? 0.45 : 0.25})`;
      c.beginPath(); c.arc(bx + kx * Controls.JOY_R, by + ky * Controls.JOY_R, 24 * Controls.JOY.k, 0, TAU); c.fill();
      }
    }
    if (G.hintT > 0) {
      c.globalAlpha = clamp(G.hintT, 0, 1);
      c.font = 'bold 15px Krilessa Icons, sans-serif'; c.textAlign = 'center';
      const ht = Controls.JOY.fixed ? 'Тяни джойстик, чтобы бежать' : 'Веди пальцем по экрану, чтобы бежать';
      c.fillStyle = '#000'; c.fillText(ht, Viewport.VW / 2 + 1, Viewport.VH * 0.72 + 1);
      c.fillStyle = '#fff'; c.fillText(ht, Viewport.VW / 2, Viewport.VH * 0.72);
      c.fillStyle = '#000'; c.fillText('Крилесса стреляет перьями сама!', Viewport.VW / 2 + 1, Viewport.VH * 0.72 + 23);
      c.fillStyle = '#ffd25a'; c.fillText('Крилесса стреляет перьями сама!', Viewport.VW / 2, Viewport.VH * 0.72 + 22);
      c.globalAlpha = 1;
    }
    let ry = top + (Terrain.paperOn ? 124 : 50);
    c.textAlign = 'left';
    if (G.keys > 0) { c.font = 'bold 13px Krilessa Icons, sans-serif'; c.fillStyle = '#000'; c.fillText('🔑' + G.keys, 13, ry + 14); c.fillStyle = '#ffd25a'; c.fillText('🔑' + G.keys, 12, ry + 13); ry += 22; }
    if (G.cookieT > 0) { const tx = '🍪 ' + Math.ceil(G.cookieT) + 'с'; c.font = 'bold 13px Krilessa Icons, sans-serif'; c.fillStyle = '#000'; c.fillText(tx, 13, ry + 14); c.fillStyle = '#ffd25a'; c.fillText(tx, 12, ry + 13); ry += 22; }
    if (G.wxId && G.wxT > 0) { const tx = { blizzard: '❄️', starfall: '🌠', frost: '🥶' }[G.wxId] + ' ' + Math.ceil(G.wxT) + 'с'; c.font = 'bold 13px Krilessa Icons, sans-serif'; c.fillStyle = '#000'; c.fillText(tx, 13, ry + 14); c.fillStyle = '#d8f2ff'; c.fillText(tx, 12, ry + 13); ry += 22; }
    for (const id of (G.relics || [])) { c.globalAlpha = id === 'phoenix' && G.phoenixUsed ? 0.35 : 1; c.font = '17px Krilessa Icons, sans-serif'; c.fillText(RELICS[id].ic, 14, ry + 15); const L = Encounters.relicLv(id); if (L > 1) { c.font = 'bold 10px Krilessa Icons, sans-serif'; c.fillStyle = '#000'; c.fillText(L, 34, ry + 19); c.fillStyle = '#ffd25a'; c.fillText(L, 33, ry + 18); } ry += 24; }
    c.globalAlpha = 1;
    if (Session.state === 'play' && !G.activeBoss && !G.activeShrine) {
      let near = false;
      for (const ch of World.chests) if (!ch.open && ch.glade && !ch.seen && Math.hypot(ch.x - P.x, ch.y - P.y) < 520) { near = true; break; }
      if (near) {
        c.globalAlpha = 0.6 + Math.sin(G.time * 5) * 0.35; c.font = 'bold 12px Krilessa Icons, sans-serif'; c.textAlign = 'center';
        c.fillStyle = '#000'; c.fillText('✨ Где-то рядом сокровище…', Viewport.VW / 2 + 1, Viewport.VH * 0.25 + 1); c.fillStyle = '#ffe9a0'; c.fillText('✨ Где-то рядом сокровище…', Viewport.VW / 2, Viewport.VH * 0.25);
        c.globalAlpha = 1;
      }
    }
    const nearN = Session.state === 'play' && !G.activeBoss && !!G.nearNpc;
    const nb = $('npcBtn'); if (nb._on !== nearN) { nb._on = nearN; nb.classList.toggle('hidden', !nearN); }
    const nearPortal = Session.state === 'play' && !G.activeBoss && !G.activeShrine && !G.cutscene && !World.CFG.rush && !!Encounters.portalHere();
    const pb = $('portalBtn'); if (pb._on !== nearPortal) { pb._on = nearPortal; pb.classList.toggle('hidden', !nearPortal); }
    Defense.tdPanelSync();
    const sw = $('swapBtn'), showSw = !!G.team && Session.state === 'play' && !G.cutscene;
    if (sw._on !== showSw) { sw._on = showSw; sw.classList.toggle('hidden', !showSw); }
    if (showSw) {
      const o = Expedition.teamOther(), f = G.team.f[o], ko = G.team.ko[o] || f < 0.25, cd = G.team.cd > 0;
      const key = o + Math.round(f * 60) + (ko ? 'k' : '') + (cd ? 'c' : '');
      if (sw._k !== key) {
        sw._k = key;
        if (sw._o !== o) { sw._o = o; const sc = $('swapAvatar').getContext('2d'); sc.clearRect(0, 0, 96, 96); sc.drawImage(Expedition.heroAvatar(o), 0, 0, 96, 96); $('swapName').textContent = '🔄 ' + HEROES[o].name; }
        sw.style.setProperty('--hp', Math.round(f * 360) + 'deg');
        sw.classList.toggle('ko', ko); sw.classList.toggle('cool', cd);
      }
    }
    const dashEl = $('dashBtn');
    const dashSeconds = Math.max(0, Math.ceil(P.dashCd));
    if (dashEl._seconds !== dashSeconds) {
      dashEl._seconds = dashSeconds;
      dashEl.classList.toggle('cool', dashSeconds > 0);
      $('dashStatus').textContent = dashSeconds ? dashSeconds + ' с' : 'ГОТОВ';
    }
    // Шестнадцати делений достаточно для кольца размером с большой палец.
    const dashStep = dashSeconds ? Math.round(16 * clamp(1 - P.dashCd / P.dashCdMax, 0, 1)) : 16;
    if (dashEl._step !== dashStep) {
      dashEl._step = dashStep;
      dashEl.style.setProperty('--arc', (dashStep * 22.5) + 'deg');
    }
    const supEl = $('superBtn'), sp = Math.floor(P.sp);
    if (supEl._sp !== sp) {
      supEl._sp = sp;
      supEl.style.setProperty('--sp', (sp * 3.6) + 'deg');
      supEl.classList.toggle('ready', sp >= 100);
      $('superPct').textContent = sp >= 100 ? 'ГОТОВ' : sp + '%';
    }
  }

  return {
    MM_URL, MM2, chestOnMap, PAPER, paperTex, paperPass, INK, HAND, lightCol, handText,
    renderHUD,
    get MM_STYLE() { return MM_STYLE; },
    set MM_STYLE(value) { MM_STYLE = value; },
  };
})();
