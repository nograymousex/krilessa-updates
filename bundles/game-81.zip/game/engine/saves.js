'use strict';

const Saves = (() => {
  // ------------------------------------------------------------------
  //  Прогресс: миграция старых сохранений
  // ------------------------------------------------------------------
  function migrateProfile() {
    const prof = loadProfile();
    const s2 = loadSave(2), s3 = loadSave(3);
    if (s2 || s3 || prof.ch2Done || prof.ch3Done) prof.ch1Done = true;
    if (s3 || prof.ch3Done) prof.ch2Done = true;
    if (prof.ch2Done && !prof.carry2) {
      // 0.02 не запоминала героиню после главы 2 – восстанавливаем
      if (s3) prof.carry2 = { level: s3.level, up: s3.up, bonus: s3.bonus || {}, shards: s3.shards || 0 };
      else {
        const L = Math.max(46, prof.carry ? prof.carry.level : 0), rb = refBuild(L);
        prof.carry2 = { level: L, up: rb.up, bonus: rb.bonus, shards: L * 3, restored: true };
      }
    }
    if (!prof.atlas || typeof prof.atlas !== 'object' || Array.isArray(prof.atlas)) prof.atlas = {};
    if (!prof.settings) prof.settings = { diff: 'normal' };
    // 0.10: прокачка своя в каждой главе. Звёзды – за всех уже побеждённых боссов,
    // незаконченные главы начинаются заново (старые уровни с новыми не стыкуются)
    if (!prof.prog2) {
      prof.starsGot = prof.starsGot || {};
      for (const n of [1, 2, 3, 4, 5, 6]) {
        const C = CHAPTERS[n]; if (!C) continue;
        const sv = loadSave(n);
        C.bosses.forEach((k, i) => { if (prof['ch' + n + 'Done'] || (sv && sv.defeated && sv.defeated[i])) prof.starsGot[n + ':' + i] = 1; });
        if (sv && (sv.v || 0) < 5) prof.restarted = (prof.restarted || []).concat(n);
      }
      prof.stars = Object.keys(prof.starsGot).length;
      prof.talents = prof.talents || {};
      delete prof.hero;
      prof.prog2 = true;
    }
    Achievements.gloryMigrate(prof); // 0.31: достижения 2.0 и таланты-созвездия
    if (prof.talents && prof.talents.key) { prof.talents.pick4 = 1; delete prof.talents.key; } // 0.31.3: «Отмычка» стала «Богатым выбором»
    if (!prof.relicLv) { prof.relicLv = {}; for (const id of (prof.relics || [])) if (RELICS[id]) prof.relicLv[id] = 1; } // 0.33: у реликвий есть уровни
    if (saveProfile(prof) && Array.isArray(prof.restarted)) {
      // Удаляем старые слоты только после записи наград в профиль.
      for (const ch of prof.restarted) {
        const slot = loadSave(ch);
        if (slot && (slot.v || 0) < 5) GameStorage.remove(saveKey(ch));
      }
    }
    return prof;
  }

  // ------------------------------------------------------------------
  //  Сохранения
  // ------------------------------------------------------------------
  const PROFILE_KEY = 'krilessa_profile_v2';
  const saveKey = ch => 'krilessa_save_v2_ch' + ch;
  function loadProfile() { return GameStorage.readRecord(PROFILE_KEY, {}); }
  function saveProfile(p) { return GameStorage.write(PROFILE_KEY, p); }
  // ===== сохранение игры вместе: потом можно продолжить с теми же подругами =====
  const COOP_KEY = 'krilessa_coop', COOP_ME = 'krilessa_coop_me';
  function coopLoad(k) { return GameStorage.readRecord(k); }
  function coopSave() {
    if (!NET.on || !G.netRun || typeof NET.ch !== 'number' || World.CFG.rush || World.CFG.abyss || !NET.coopId) return;
    if (Session.state === 'menu' || Session.state === 'intro' || G.cutscene || !Session.bosses.length) return;
    try {
      if (G.defeated[Session.bosses.length - 1] || G.finalFinal) { GameStorage.remove(NET.host ? COOP_KEY : COOP_ME); return; } // глава пройдена – сохранение не нужно
      const mine = { v: 1, id: NET.coopId, ch: World.CHN, level: P.level, xp: P.xp, up: P.up, bonus: P.bonus, shards: P.shards, hero: P.hero, at: Date.now() };
      if (NET.host) GameStorage.write(COOP_KEY, Object.assign(mine, { seed: World.SEED, layout: World.revision, diff: NET.diff, mut: Challenges.mutIds(), defeated: G.defeated, ml: G.melted || [], cp: G.cp, kills: G.kills, time: G.time,
        pl: World.pearls.map(p=>p.got), fl: World.fires.map(f=>f.lit),
        chests: World.chests.map(c => c.open && (!c.mimic || c.mimicDone) ? 1 : 0), keys: G.keys || 0, names: NET.roster.filter(r => r.id !== 1).map(r => r.name) }));
      else GameStorage.write(COOP_ME, mine);
    } catch (e) { /* ignore */ }
  }
  function coopApplyMine(me) { // своя прокачка из сохранения
    if (!me) return;
    P.level = me.level || P.level; P.xp = me.xp || 0; P.xpNext = Actors.xpFor(P.level); P.up = me.up || {}; P.bonus = me.bonus || {}; P.shards = me.shards || 0; G.pendingLv = 0;
    Actors.computeStats(); P.hp = P.maxHp;
  }
  function coopApplyWorld(r) { // мир из сохранения хозяйки: побеждённые стражи, растаявший лёд, место
    if (!r) return;
    if (r.df) {
      G.defeated = World.CFG.bosses.map((_, i) => !!r.df[i]);
      for (const boss of Session.bosses) if (G.defeated[boss.id]) {
        boss.state = 'dead';
        boss.hp = 0;
      }
      World.gateOpen = Bosses.guardiansDone() >= Bosses.guardiansCount();
      World.restoreBridge();
    }
    if (r.ml && r.ml.length) { NET.applyMelt = true; for (const i of r.ml) Expedition.meltTile(i, false); NET.applyMelt = false; }
    (r.ch || []).forEach((o, i) => { if (World.chests[i] && o) { World.chests[i].open = true; if (World.chests[i].mimic) World.chests[i].mimicDone = true; } });
    (r.pl || []).forEach((got,i) => { if (World.pearls[i]) World.pearls[i].got=!!got; });
    (r.fl || []).forEach((lit,i) => { if (World.fires[i]) World.fires[i].lit=!!lit; });
    if (r.cp) { G.cp = r.cp; P.x = r.cp.x + rnd(-30, 30); P.y = r.cp.y + rnd(-30, 30); World.ensureWalkable(P); Simulation.updateCamera(); }
  }
  function loadSave(ch) { return GameStorage.readRecord(saveKey(ch)); }
  function saveGame() {
    if (NET.on) { coopSave(); return; } // вместе – своё сохранение (у хозяйки – мир, у каждой – её прокачка)
    if (World.CFG.rush || World.CFG.abyss || G.daily || G.finalFinal) return; // Бездна и испытание дня не сохраняются
    if (Session.state === 'menu' || Session.state === 'intro' || Session.state === 'boot') return;
    if (G.cutscene || !Session.bosses.length || G.defeated[Session.bosses.length - 1]) return;
    const data = { v: 5, layout: World.revision, defeated: G.defeated, level: P.level, xp: P.xp, up: P.up, bonus: P.bonus, shards: P.shards, cp: G.cp, sp: P.sp,
      kills: G.kills, time: G.time, bestCombo: G.bestCombo, chests: World.chests.map(c => c.open && (!c.mimic || c.mimicDone) ? 1 : 0), cs: World.chests.map(c => c.seen ? 1 : 0), keys: G.keys || 0, ph: !!G.phoenixUsed, sw: !!G.secondUsed, shrines: World.shrines.map(s => s.state === 'done' ? 1 : 0),
      st: G.st, lowHp: G.lowHpSaid, calm: G.calm, seed: World.SEED,
      clues: World.clues.map(q => q.found ? 1 : 0), npcs: World.npcs.map(n => n.state), qi: World.qitems.map(i => (i.active ? 1 : 0) + (i.taken ? 2 : 0)), acc: !!G.accused,
      tm: Expedition.teamSnapshot(), ml: G.melted, fl: World.fires.map(f => f.lit ? 1 : 0), dr: World.drifts.map(d => d.done ? 1 : 0), gl: World.glades.map(g => g.done ? 1 : 0), pl: World.pearls.map(q => q.got ? 1 : 0), mut: Challenges.mutIds() };
    const trail = StarTrail.snapshot();
    if (trail) data.starTrail = trail;
    return GameStorage.write(saveKey(World.CHN), data);
  }

  function saveTrail() {
    const result = saveGame();
    if (result !== undefined) return result;
    // После последнего босса мир уже не сохраняется. Если есть тот же старый checkpoint,
    // фиксируем награду и здоровье команды, не сохраняя заново сам бой.
    const slot = loadSave(World.CHN);
    if (!slot || slot.seed !== World.SEED || (slot.layout || 0) !== World.revision) return true;
    slot.starTrail = StarTrail.snapshot();
    const team = Expedition.teamSnapshot();
    if (team) slot.tm = team;
    return GameStorage.write(saveKey(World.CHN), slot);
  }
  GameStorage.migrateKey('krilessa_save_v1', saveKey(1));

  return {
    migrateProfile, saveKey, loadProfile, saveProfile, COOP_KEY, COOP_ME, coopLoad, coopSave,
    coopApplyMine, coopApplyWorld, loadSave, saveGame, saveTrail,
  };
})();
