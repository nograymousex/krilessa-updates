'use strict';

const DefenseView = (() => {
  // ---------- рисование ----------
  function tdEll(c, x, y, rx, ry, col) { c.fillStyle = col; c.beginPath(); c.ellipse(x, y, rx, ry, 0, 0, TAU); c.fill(); }
  function tdEmoji(c, ch, x, y, size) { c.globalAlpha = 1; c.fillStyle = '#fff'; c.font = `${size}px Krilessa Icons, sans-serif`; c.textAlign = 'center'; c.fillText(ch, x, y); }
  function drawDefGround(c, vis) {
    const A = G.abyss, M = G.td, C = G.core, t = G.time;
    if (M.M.bridges) for (const [bx,by,half] of M.M.bridges) {
      const x=(TD_OX+bx)*World.T, y=(TD_OY+by)*World.T;
      if (!vis(x,y,half*World.T+35)) continue;
      c.save(); c.translate(x,y); c.scale(World.T,World.T*0.71);
      LandscapeArt.timber(c,half);
      const flag=bx<14?'#de8655':'#61b2c7';
      c.fillStyle=flag; c.beginPath(); c.moveTo(-0.2,-1.76);c.lineTo(0.5,-1.54);c.lineTo(-0.2,-1.29);c.fill();
      c.restore();
    }
    for (const L of M.lanes) { // входы: воронки, откуда приходят враги
      const g = L.gate; if (!vis(g.x, g.y, 110)) continue;
      const on = L.from <= A.wave + 1;
      const gr = c.createRadialGradient(g.x, g.y, 4, g.x, g.y, 58); gr.addColorStop(0, on ? 'rgba(170,60,220,0.75)' : 'rgba(90,90,110,0.5)'); gr.addColorStop(1, 'rgba(60,0,90,0)');
      c.fillStyle = gr; c.beginPath(); c.ellipse(g.x, g.y, 58, 34, 0, 0, TAU); c.fill();
      if (!on) continue;
      c.strokeStyle = 'rgba(224,160,255,0.28)'; c.lineWidth = 2; c.setLineDash([6, 9]); c.beginPath(); c.arc(g.x, g.y, 150, 0, TAU); c.stroke(); c.setLineDash([]); // зона защиты портала
      c.save(); c.translate(g.x, g.y); c.scale(1, 0.58); c.rotate(t * 1.5); c.strokeStyle = 'rgba(240,170,255,0.85)'; c.lineWidth = 3; c.setLineDash([12, 10]);
      c.beginPath(); c.arc(0, 0, 40, 0, TAU); c.stroke(); c.rotate(-t * 2.6); c.strokeStyle = 'rgba(255,255,255,0.5)'; c.beginPath(); c.arc(0, 0, 24, 0, TAU); c.stroke(); c.restore();
    }
    for (const p of M.pools) { // горящие лужи
      const a = clamp(p.t / 0.6, 0, 1);
      c.fillStyle = `rgba(255,110,20,${0.3 * a})`; c.beginPath(); c.ellipse(p.x, p.y, p.r, p.r * 0.62, 0, 0, TAU); c.fill();
      c.fillStyle = `rgba(255,210,60,${0.28 * a})`; c.beginPath(); c.ellipse(p.x, p.y, p.r * 0.6, p.r * 0.36, 0, 0, TAU); c.fill();
    }
    for (const sp of M.spots) {
      if (!vis(sp.x, sp.y, 240)) continue;
      const tw = sp.tw, cur = M.cur === sp.i;
      if (tw && tw.k === 'frost') { // холодный круг
        const S = tdStat(tw.def, tw.lvl, tw.sp);
        c.fillStyle = `rgba(150,220,255,${0.07 + 0.03 * Math.sin(tw.t * 3) + (tw.shot > 0 ? 0.08 : 0)})`; c.beginPath(); c.arc(sp.x, sp.y, S.rng, 0, TAU); c.fill();
      }
      if (cur) { // дальность выбранной башни
        const r = Defense.tdRingOf(sp);
        if (r) { c.fillStyle = 'rgba(255,255,255,0.07)'; c.beginPath(); c.arc(sp.x, sp.y, r, 0, TAU); c.fill(); c.strokeStyle = 'rgba(255,255,255,0.55)'; c.lineWidth = 2; c.setLineDash([8, 7]); c.stroke(); c.setLineDash([]); }
      }
      tdEll(c, sp.x, sp.y + 12, 27, 12, 'rgba(0,0,0,0.28)');
      tdEll(c, sp.x, sp.y + 8, 25, 11, '#77728a'); tdEll(c, sp.x, sp.y + 5, 23, 10, cur ? '#e9e2ff' : '#aaa5bd');
      if (cur) { c.strokeStyle = '#ffd25a'; c.lineWidth = 2.5; c.beginPath(); c.ellipse(sp.x, sp.y + 5, 27, 12.5, 0, 0, TAU); c.stroke(); }
      if (!tw) { c.globalAlpha = 0.55 + 0.35 * Math.sin(t * 3 + sp.i); tdEmoji(c, '🔨', sp.x, sp.y + 11 + Math.sin(t * 3 + sp.i) * 1.5, 17); c.globalAlpha = 1; }
    }
    // круг кристалла: сколько ещё выдержит
    const hpF = clamp(C.hp / TD_LIVES, 0, 1);
    c.lineWidth = 5; c.strokeStyle = 'rgba(0,0,0,0.4)'; c.beginPath(); c.ellipse(C.x, C.y + 12, 44, 15, 0, 0, TAU); c.stroke();
    c.strokeStyle = hpF > 0.5 ? '#ff8ad8' : hpF > 0.25 ? '#ffd25a' : '#ff4d4d';
    c.beginPath(); c.ellipse(C.x, C.y + 12, 44, 15, 0, -Math.PI / 2, -Math.PI / 2 + TAU * hpF); c.stroke();
    const repair = Defense.repairStatus();
    if (repair && !repair.repaired && vis(C.x, C.y, Defense.REPAIR_RADIUS + 3)) {
      c.save();
      c.beginPath(); c.arc(C.x, C.y, Defense.REPAIR_RADIUS, 0, TAU);
      c.fillStyle = 'rgba(43,169,151,.11)'; c.fill();
      c.setLineDash([6, 6]); c.lineWidth = 2.3; c.strokeStyle = '#79e4cd'; c.stroke();
      c.restore();
    }
    if (NET.on && G.netRun && G.td) { // ниточки дружбы между башнями разных игроков
      c.save(); c.setLineDash([5, 6]); c.lineDashOffset = -G.time * 12; c.lineWidth = 2;
      for (const sp of G.td.spots) { const a = sp.tw; if (!a || !a.frL) continue; for (const b of a.frL) { if (b.s < a.s) continue; const g = c.createLinearGradient(a.x, a.y, b.x, b.y); g.addColorStop(0, Multiplayer.mateCol(a.by || 1)); g.addColorStop(1, Multiplayer.mateCol(b.by || 1)); c.strokeStyle = g; c.globalAlpha = 0.75; c.beginPath(); c.moveTo(a.x, a.y + 8); c.lineTo(b.x, b.y + 8); c.stroke(); } }
      c.restore();
    }
  }
  function drawDefFac(c, vis) {
    const F = G.td.fac; if (!F || !vis((F.rx0 + F.rx1) / 2, F.my, 560)) return;
    const t = G.time, pap = Terrain.paperOn, ink = pap ? '#4b2e1e' : '#000';
    if (!F.found) { // пока не нашли – за краем поля просто камень; у лаза табличка с вопросом
      c.fillStyle = pap ? '#cdbb96' : '#16121e'; c.fillRect(F.rx0 - 4, F.fy, F.rx1 - F.rx0 + 8, F.ry1 - F.fy + 4);
      c.fillStyle = pap ? 'rgba(75,46,30,.25)' : 'rgba(255,255,255,.06)'; for (let i = 0; i < 14; i++) c.fillRect(F.rx0 + (i * 157) % (F.rx1 - F.rx0), F.fy + 20 + (i * 53) % 150, 26, 6);
    } else {
      c.fillStyle = pap ? 'rgba(150,100,60,.35)' : 'rgba(90,60,40,.55)'; c.fillRect(F.rx0, F.ry0, F.rx1 - F.rx0, F.ry1 - F.ry0); // доски пола
      c.strokeStyle = pap ? 'rgba(75,46,30,.25)' : 'rgba(0,0,0,.35)'; c.lineWidth = 1.5; c.beginPath();
      for (let y = F.ry0 + 20; y < F.ry1; y += 20) { c.moveTo(F.rx0, y); c.lineTo(F.rx1, y); } c.stroke();
      c.fillStyle = pap ? 'rgba(75,46,30,.5)' : 'rgba(0,0,0,.5)'; c.fillRect(F.rx0, F.ry0, F.rx1 - F.rx0, 8);
      // лента от станка к ящику
      const bx0 = F.mx + 46, bx1 = F.cx - 34, by = F.my + 22, run = F.work || F.workers;
      c.fillStyle = '#3a3440'; roundRect(c, bx0, by - 7, bx1 - bx0, 14, 6); c.fill(); c.strokeStyle = ink; c.lineWidth = 1.5; c.stroke();
      c.strokeStyle = '#6a6474'; c.lineWidth = 2; c.beginPath(); const off = run ? (t * 40) % 18 : 0;
      for (let x = bx0 + 4 + off; x < bx1 - 4; x += 18) { c.moveTo(x, by - 5); c.lineTo(x - 5, by + 5); } c.stroke();
      if (run) for (let k = 0; k < 3; k++) { const ph = (t * (F.work ? 0.7 : 0.35) + k / 3) % 1; tdEmoji(c, '🪙', bx0 + (bx1 - bx0) * ph, by - 2, 14); }
      // станок
      const shake = F.work ? Math.sin(t * 40) * 1.2 : 0;
      c.save(); c.translate(F.mx + shake, F.my);
      c.fillStyle = 'rgba(0,0,0,.3)'; c.beginPath(); c.ellipse(0, 36, 52, 12, 0, 0, TAU); c.fill();
      c.fillStyle = '#7a8a9a'; c.fillRect(22, -62, 16, 34); c.strokeStyle = ink; c.lineWidth = 2; c.strokeRect(22, -62, 16, 34); // труба
      c.fillStyle = '#b06a3a'; roundRect(c, -46, -30, 92, 66, 10); c.fill(); c.stroke();
      c.fillStyle = '#d8dce8'; roundRect(c, -46, -36, 92, 14, 6); c.fill(); c.stroke();
      c.fillStyle = run ? `rgba(255,214,90,${0.75 + 0.25 * Math.sin(t * 9)})` : '#4a4458'; roundRect(c, -32, -12, 30, 24, 5); c.fill(); c.stroke(); // окошко
      for (const [gx, gy, gr, sgn] of [[22, 4, 13, 1], [10, 24, 8, -1]]) { // шестерёнки
        c.save(); c.translate(gx, gy); c.rotate(t * (run ? 2.4 : 0.15) * sgn); c.fillStyle = '#e0b84a'; c.beginPath();
        for (let i = 0; i < 16; i++) { const a = i * TAU / 16, rr = i % 2 ? gr : gr + 4; c.lineTo(Math.cos(a) * rr, Math.sin(a) * rr); } c.closePath(); c.fill(); c.stroke();
        c.fillStyle = '#7a5a2a'; c.beginPath(); c.arc(0, 0, gr * 0.35, 0, TAU); c.fill(); c.restore();
      }
      c.restore();
      if (run) for (let k = 0; k < 3; k++) { const ph = (t * 0.6 + k / 3) % 1; c.fillStyle = `rgba(${pap ? '120,110,100' : '220,220,230'},${0.5 * (1 - ph)})`; c.beginPath(); c.arc(F.mx + 30 + ph * 14, F.my - 66 - ph * 50, 7 + ph * 12, 0, TAU); c.fill(); }
      // ящик с монетками
      const cap = TD_FAC.cap[F.lvl - 1], fill = clamp(F.crate / cap, 0, 1);
      c.fillStyle = 'rgba(0,0,0,.3)'; c.beginPath(); c.ellipse(F.cx, F.cy + 26, 40, 10, 0, 0, TAU); c.fill();
      if (fill > 0.02) { c.fillStyle = '#f2c13a'; c.beginPath(); c.ellipse(F.cx, F.cy - 4 - fill * 10, 28, 8 + fill * 14, 0, Math.PI, TAU); c.fill(); c.strokeStyle = ink; c.lineWidth = 1.5; c.stroke(); }
      c.fillStyle = '#c8945a'; roundRect(c, F.cx - 32, F.cy - 6, 64, 32, 5); c.fill(); c.strokeStyle = ink; c.lineWidth = 2; c.stroke();
      c.strokeStyle = '#8a5a34'; c.lineWidth = 2; c.beginPath(); c.moveTo(F.cx - 30, F.cy + 10); c.lineTo(F.cx + 30, F.cy + 10); c.stroke();
      c.font = '800 13px Krilessa Icons, Nunito, sans-serif'; c.textAlign = 'center'; c.lineWidth = 3; c.strokeStyle = pap ? '#fffaf0' : 'rgba(0,0,0,.75)'; c.fillStyle = fill >= 1 ? '#ff8a6a' : (pap ? '#7a4a12' : '#ffe08a');
      const lb = `🪙 ${Math.floor(F.crate)}/${cap}${fill >= 1 ? ' полон!' : ''}`; c.strokeText(lb, F.cx, F.cy - 40); c.fillText(lb, F.cx, F.cy - 40);
      // крильки-рабочие
      for (let i = 0; i < F.workers; i++) {
        const ph = (t * 0.22 + i / 3) % 1, tri = ph < 0.5 ? ph * 2 : 2 - ph * 2, x = F.mx + 50 + (F.cx - 40 - F.mx - 50) * tri, y = F.my + 44 + i * 7 + Math.abs(Math.sin(t * 9 + i)) * -3;
        c.save(); c.translate(x, y); if (ph >= 0.5) c.scale(-1, 1); tdEmoji(c, '🦐', 0, 0, 22); c.restore();
        if (ph < 0.5) tdEmoji(c, '🪙', x + 2, y - 16, 11);
      }
      // нора воришек
      c.fillStyle = '#1a1420'; c.beginPath(); c.ellipse(F.hx, F.hy + 6, 22, 14, 0, 0, TAU); c.fill(); c.strokeStyle = pap ? '#4b2e1e' : '#5a4a3a'; c.lineWidth = 3; c.stroke();
      if (F.thT > 0) { c.globalAlpha = 0.5 + 0.5 * Math.sin(t * 10); tdEmoji(c, '⚠️', F.hx, F.hy - 22, 20); c.globalAlpha = 1; }
      for (const e of G.enemies) if (!e.dead && (e.thief ? e.loot > 0 : NET.client && e.y > F.ry0 && e.x > F.rx0)) tdEmoji(c, '💰', e.x, e.y - (e.r || 10) - 16, 16);
      // вывеска
      const tt = `🏭 Фабрика Крилей · ур. ${F.lvl}` + (F.work ? ' · работает!' : F.workers ? ' · крильки трудятся' : '');
      c.font = `800 14px Krilessa Icons, ${pap ? 'Philosopher, serif' : 'Nunito, sans-serif'}`; c.textAlign = 'center'; c.lineWidth = 4; c.strokeStyle = pap ? '#fffaf0' : 'rgba(0,0,0,.8)'; c.fillStyle = pap ? '#7a3a1a' : '#ffd25a';
      c.strokeText(tt, F.rx0 + 740, F.ry0 + 30); c.fillText(tt, F.rx0 + 740, F.ry0 + 30);
    }
    // табличка у лаза
    const sx = F.tx1 + 22, sy = F.ty0 + 18;
    c.fillStyle = '#7a5a34'; c.fillRect(sx - 2, sy - 6, 4, 26); c.fillStyle = '#c8945a'; roundRect(c, sx - 20, sy - 22, 40, 20, 4); c.fill(); c.strokeStyle = ink; c.lineWidth = 1.5; c.stroke();
    tdEmoji(c, F.found ? '🏭' : '🦐', sx - 7, sy - 7, 12); c.font = '900 12px Krilessa Icons, Nunito, sans-serif'; c.fillStyle = ink; c.textAlign = 'center'; c.fillText(F.found ? '↓' : '?', sx + 9, sy - 7);
  }
  function drawDefCore(c) {
    const C = G.core, t = C.t, y = C.y - 30 + Math.sin(t * 2) * 4, hpF = clamp(C.hp / TD_LIVES, 0, 1);
    shadow(c, C.x, C.y + 10, 26, 8);
    const g = c.createRadialGradient(C.x, y, 4, C.x, y, 74); g.addColorStop(0, `rgba(255,140,220,${0.45 + 0.2 * Math.sin(t * 3)})`); g.addColorStop(1, 'rgba(255,140,220,0)');
    c.fillStyle = g; c.beginPath(); c.arc(C.x, y, 74, 0, TAU); c.fill();
    c.save(); c.translate(C.x, y);
    const w = 24, h = 40, fl = C.flash > 0;
    c.fillStyle = fl ? '#ffffff' : '#ff9ad8'; c.beginPath(); c.moveTo(0, -h); c.lineTo(w, -6); c.lineTo(0, h * 0.75); c.closePath(); c.fill();
    c.fillStyle = fl ? '#ffe0f0' : '#8ad8ff'; c.beginPath(); c.moveTo(0, -h); c.lineTo(-w, -6); c.lineTo(0, h * 0.75); c.closePath(); c.fill();
    c.fillStyle = 'rgba(255,255,255,0.55)'; c.beginPath(); c.moveTo(0, -h); c.lineTo(w * 0.45, -12); c.lineTo(0, -3); c.lineTo(-w * 0.45, -12); c.closePath(); c.fill();
    c.strokeStyle = 'rgba(255,255,255,0.85)'; c.lineWidth = 1.5; c.beginPath(); c.moveTo(0, -h); c.lineTo(w, -6); c.lineTo(0, h * 0.75); c.lineTo(-w, -6); c.closePath(); c.stroke();
    if (hpF < 0.5) { // трещины
      c.strokeStyle = 'rgba(60,10,40,0.75)'; c.lineWidth = 1.5; c.beginPath(); c.moveTo(-4, -26); c.lineTo(3, -14); c.lineTo(-2, -4); c.lineTo(6, 8);
      if (hpF < 0.25) { c.moveTo(10, -10); c.lineTo(4, 0); c.lineTo(12, 6); c.moveTo(-14, -6); c.lineTo(-6, 4); }
      c.stroke();
    }
    c.restore();
    for (let k = 0; k < 3; k++) { const a = t * 1.4 + k * TAU / 3; c.fillStyle = k === 1 ? '#8ad8ff' : '#ffd0f0'; c.beginPath(); c.arc(C.x + Math.cos(a) * 34, y + Math.sin(a) * 12 - 4, 2.6, 0, TAU); c.fill(); }
    const label = NET.on && G.netRun ? `💎 Кристалл · ${C.hp}/${TD_LIVES}` : `💎 ${C.hp}`;
    c.font = 'bold 13px Krilessa Icons, sans-serif'; c.textAlign = 'center'; c.fillStyle = '#000'; c.fillText(label, C.x + 1, C.y + 43);
    c.fillStyle = '#fff'; c.fillText(label, C.x, C.y + 42);
    const repair = Defense.repairStatus();
    if (repair && !repair.repaired) {
      const x = C.x, y = C.y - 121;
      const text = repair.near < 2 ? 'Встаньте в круг · ' + repair.near + '/2' : 'Ремонт · ' + repair.progress + '%';
      c.save();
      c.font = 'bold 14px Krilessa Icons, sans-serif'; c.textAlign = 'center';
      const w = Math.max(115, Math.ceil(c.measureText(text).width) + 20);
      roundRect(c, x - w / 2, y, w, 42, 7); c.fillStyle = '#19343f'; c.fill();
      c.strokeStyle = '#9ee3d2'; c.lineWidth = 1.4; c.stroke();
      c.fillStyle = '#e7fff4'; c.fillText(text, x, y + 16);
      c.font = '12px Krilessa Icons, sans-serif'; c.fillStyle = '#bee9d7'; c.fillText('+1 кристаллу за ' + Defense.REPAIR_SECONDS + ' с', x, y + 30);
      c.fillStyle = '#43676b'; c.fillRect(x - w / 2 + 8, y + 35, w - 16, 3);
      c.fillStyle = '#a3f4c7'; c.fillRect(x - w / 2 + 8, y + 35, (w - 16) * repair.progress / 100, 3);
      c.restore();
    }
  }
  function drawDefTower(c, tw) {
    const x = tw.x, y = tw.y, d = tw.def, L = tw.lvl, S = tdStat(d, L, tw.sp), top = L >= 4 ? S.ic : d.ic, sz = 20 + Math.min(L, 4) * 2, fire = tw.shot > 0;
    if (Terrain.paperOn) { // 1.0: каменная площадка с акварельной подкладкой цвета башни
      c.fillStyle = 'rgba(70,45,20,.22)'; c.beginPath(); c.ellipse(x + 3, y + 12, 25, 8.5, 0, 0, TAU); c.fill();
      c.fillStyle = '#d8ccb4'; c.beginPath(); c.ellipse(x, y + 9, 23, 8, 0, 0, TAU); c.fill();
      c.globalAlpha = 0.4; c.fillStyle = d.col; c.beginPath(); c.ellipse(x, y + 8, 19, 6, 0, 0, TAU); c.fill(); c.globalAlpha = 1;
      c.strokeStyle = HUD.INK; c.lineWidth = 1.3; c.beginPath(); c.ellipse(x, y + 9, 23, 8, 0, 0, TAU); c.stroke();
      c.strokeStyle = 'rgba(75,46,30,.35)'; c.lineWidth = 1; for (let k = 0; k < 6; k++) { const a = k * TAU / 6 + 0.3; c.beginPath(); c.moveTo(x + Math.cos(a) * 15, y + 9 + Math.sin(a) * 5); c.lineTo(x + Math.cos(a) * 23, y + 9 + Math.sin(a) * 8); c.stroke(); }
    }
    const body = (w, h, c1, c2) => { // сужающийся кверху корпус
      c.fillStyle = c2; c.beginPath(); c.moveTo(x - w, y + 8); c.lineTo(x + w, y + 8); c.lineTo(x + w * 0.72, y - h); c.lineTo(x - w * 0.72, y - h); c.closePath(); c.fill();
      if (Terrain.paperOn) { c.strokeStyle = HUD.INK; c.lineWidth = 1.4; c.lineJoin = 'round'; c.stroke(); }
      c.fillStyle = c1; c.beginPath(); c.moveTo(x - w, y + 8); c.lineTo(x - w * 0.1, y + 8); c.lineTo(x - w * 0.1, y - h); c.lineTo(x - w * 0.72, y - h); c.closePath(); c.fill();
      if (Terrain.paperOn) { c.strokeStyle = 'rgba(75,46,30,.45)'; c.lineWidth = 0.8; for (let yy = y - 4; yy > y - h + 4; yy -= 7) { c.beginPath(); c.moveTo(x - w * 0.95 + (y + 8 - yy) * (w * 0.28) / (h + 8), yy); c.lineTo(x + w * 0.95 - (y + 8 - yy) * (w * 0.28) / (h + 8), yy); c.stroke(); } }
    };
    if (tw.k === 'feather') {
      body(13, 26 + L * 2, '#9a6ad0', '#7a4fa8'); c.fillStyle = '#e0c8ff'; c.fillRect(x - 13, y - 30 - L * 2, 26, 6);
      c.save(); c.translate(x, y - 42 - L * 2); c.rotate(clamp(Math.cos(tw.aim) * 0.5, -0.5, 0.5)); if (fire) c.scale(1.2, 1.2); tdEmoji(c, top, 0, 8, sz); c.restore();
    } else if (tw.k === 'fire') {
      body(15, 16 + L, '#8a7a78', '#5f5250'); tdEll(c, x, y - 17 - L, 14, 5.5, '#2a1c1a');
      const fl = 1 + 0.08 * Math.sin(tw.t * 11) + (fire ? 0.25 : 0);
      c.save(); c.translate(x, y - 18 - L); c.scale(fl, fl); tdEmoji(c, top, 0, 0, sz + 2); c.restore();
    } else if (tw.k === 'frost') {
      body(11, 12, '#9ad8f0', '#5fa8c8');
      const g = c.createRadialGradient(x, y - 30, 2, x, y - 30, 24); g.addColorStop(0, `rgba(190,240,255,${fire ? 0.8 : 0.45})`); g.addColorStop(1, 'rgba(190,240,255,0)');
      c.fillStyle = g; c.beginPath(); c.arc(x, y - 30, 24, 0, TAU); c.fill();
      tdEmoji(c, top, x, y - 22 + Math.sin(tw.t * 2.2) * 3, sz);
    } else if (tw.k === 'disco') {
      c.fillStyle = '#4a3a6a'; c.fillRect(x - 3, y - 34, 6, 42); if (Terrain.paperOn) { c.strokeStyle = HUD.INK; c.lineWidth = 1.2; c.strokeRect(x - 3, y - 34, 6, 42); } tdEll(c, x, y + 6, 11, 4.5, '#6a5a8a');
      c.save(); c.translate(x, y - 44); c.globalAlpha = fire ? 0.9 : 0.4; c.strokeStyle = '#fff3a0'; c.lineWidth = 2;
      for (let i = 0; i < 6; i++) { const a = tw.t * 1.8 + i * TAU / 6; c.beginPath(); c.moveTo(Math.cos(a) * 14, Math.sin(a) * 14); c.lineTo(Math.cos(a) * (fire ? 30 : 21), Math.sin(a) * (fire ? 30 : 21)); c.stroke(); }
      c.restore(); c.globalAlpha = 1;
      tdEmoji(c, top, x, y - 36, sz);
    } else if (tw.k === 'wind') { // ветряк: башенка и крутящиеся лопасти
      body(11, 26 + L * 2, '#e8dcc8', '#c8b8a0');
      c.save(); c.translate(x, y - 30 - L * 2); c.rotate(tw.t * (tw.gust > 0 ? 9 : 2.5));
      for (let i = 0; i < 4; i++) { c.rotate(TAU / 4); c.fillStyle = i % 2 ? '#a8d8e8' : '#f6f0e0'; c.beginPath(); c.moveTo(0, 0); c.lineTo(5, -4); c.lineTo(22 + L, -2); c.lineTo(22 + L, 4); c.closePath(); c.fill(); if (Terrain.paperOn) { c.strokeStyle = HUD.INK; c.lineWidth = 1.1; c.stroke(); } }
      c.fillStyle = '#8a6a4a'; c.beginPath(); c.arc(0, 0, 3.5, 0, TAU); c.fill(); c.restore();
      if (L >= 4) tdEmoji(c, S.ic, x, y - 4, 13);
    } else if (tw.k === 'bank') { // копилка: свинка на подушке и выпрыгивающие монетки
      tdEll(c, x, y + 2, 15, 6, '#c86a8a'); if (Terrain.paperOn) { c.strokeStyle = HUD.INK; c.lineWidth = 1.1; c.beginPath(); c.ellipse(x, y + 2, 15, 6, 0, 0, TAU); c.stroke(); }
      c.save(); c.translate(x, y - 14 + (tw.shot > 0 ? -4 : 0)); const bs = 1 + (tw.shot > 0 ? 0.12 : 0); c.scale(bs, bs); tdEmoji(c, L >= 4 ? S.ic : d.ic, 0, 8, sz + 4); c.restore();
      if (tw.pop) { const a = clamp(tw.pop.t / 0.6, 0, 1), up = (1 - tw.pop.t / 1.2) * 26; c.globalAlpha = a; if (Terrain.paperOn) HUD.handText(c, '+' + tw.pop.v + ' 🪙', x, y - 40 - up, 15, '#b8802a', 'center', 'rgba(251,243,224,.9)'); else { c.font = 'bold 12px Krilessa Icons, sans-serif'; c.fillStyle = '#ffd25a'; c.fillText('+' + tw.pop.v + ' 🪙', x, y - 40 - up); } c.globalAlpha = 1; }
    } else if (tw.k === 'vine') { // плющ: горшок и вьющиеся стебли
      body(12, 10, '#c86a3a', '#a84a2a');
      c.strokeStyle = '#4a8a3a'; c.lineWidth = 3; c.lineCap = 'round';
      for (let i = 0; i < 3; i++) { const sw = Math.sin(tw.t * 2 + i * 2) * 4; c.beginPath(); c.moveTo(x - 6 + i * 6, y - 10); c.quadraticCurveTo(x - 12 + i * 10 + sw, y - 24, x - 8 + i * 8 + sw, y - 36 - L * 2 - i * 3); c.stroke(); }
      c.lineCap = 'butt'; tdEmoji(c, L >= 4 ? S.ic : d.ic, x, y - 30 - L * 2, sz - 2);
    } else if (tw.k === 'mortar') { // хлопушка: короткая пушка, смотрит в сторону цели
      tdEll(c, x, y + 2, 14, 6, '#7a5a3a');
      c.save(); c.translate(x, y - 8); c.rotate(clamp(Math.cos(tw.aim) * 0.6, -0.6, 0.6) - 0.5);
      c.fillStyle = '#d84a5a'; c.beginPath(); c.roundRect(-7, -26, 14, 26, 4); c.fill(); c.fillStyle = '#f2c84a'; c.fillRect(-7, -20, 14, 4); c.fillRect(-7, -10, 14, 4);
      if (Terrain.paperOn) { c.strokeStyle = HUD.INK; c.lineWidth = 1.3; c.beginPath(); c.roundRect(-7, -26, 14, 26, 4); c.stroke(); }
      if (fire) { c.fillStyle = 'rgba(255,230,120,.9)'; c.beginPath(); c.arc(0, -30, 7, 0, TAU); c.fill(); }
      c.restore(); tdEmoji(c, L >= 4 ? S.ic : d.ic, x + 14, y - 26, 13);
    } else { // кошкин дом
      c.fillStyle = '#e89a5a'; c.fillRect(x - 15, y - 16, 30, 24); c.fillStyle = '#ffb884'; c.fillRect(x - 15, y - 16, 12, 24);
      if (Terrain.paperOn) { c.strokeStyle = HUD.INK; c.lineWidth = 1.4; c.strokeRect(x - 15, y - 16, 30, 24); }
      c.fillStyle = '#b84a3a'; c.beginPath(); c.moveTo(x - 20, y - 15); c.lineTo(x, y - 34 - L); c.lineTo(x + 20, y - 15); c.closePath(); c.fill();
      if (Terrain.paperOn) { c.strokeStyle = HUD.INK; c.lineWidth = 1.4; c.lineJoin = 'round'; c.stroke(); c.strokeStyle = 'rgba(75,46,30,.4)'; c.lineWidth = 0.8; for (let k = 1; k < 4; k++) { c.beginPath(); c.moveTo(x - 20 + k * 4, y - 15 - k * 4.8 - k * L / 4); c.lineTo(x + 20 - k * 4, y - 15 - k * 4.8 - k * L / 4); c.stroke(); } }
      c.fillStyle = '#b84a3a'; c.beginPath(); c.moveTo(x - 12, y - 24); c.lineTo(x - 9, y - 36 - L); c.lineTo(x - 4, y - 28); c.closePath(); c.fill(); c.beginPath(); c.moveTo(x + 12, y - 24); c.lineTo(x + 9, y - 36 - L); c.lineTo(x + 4, y - 28); c.closePath(); c.fill();
      c.fillStyle = '#3a2218'; c.beginPath(); c.arc(x, y + 8, 7, Math.PI, 0); c.fill();
      tdEmoji(c, L >= 4 ? S.ic : '🐾', x, y - 14, 12);
    }
    if (tw.silT > 0) { c.globalAlpha = 0.65 + 0.35 * Math.sin(G.time * 6); tdEmoji(c, '💤', x + 14, y - 56 + Math.sin(G.time * 3) * 3, 16); c.globalAlpha = 1; }
    if (NET.on && G.netRun) { // флажок цвета той, кто построила
      const fx = x - 18, fy = y - 2, col = Multiplayer.mateCol(tw.by || 1), wv = Math.sin(G.time * 4 + x) * 2;
      c.strokeStyle = Terrain.paperOn ? HUD.INK : '#3a2a1a'; c.lineWidth = 1.5; c.beginPath(); c.moveTo(fx, fy + 8); c.lineTo(fx, fy - 22); c.stroke();
      c.fillStyle = col; c.beginPath(); c.moveTo(fx, fy - 22); c.quadraticCurveTo(fx + 8, fy - 20 + wv, fx + 15, fy - 17 + wv); c.lineTo(fx, fy - 12); c.closePath(); c.fill();
      if (Terrain.paperOn) { c.lineWidth = 1; c.stroke(); }
      if (tw.fr) { c.globalAlpha = 0.8 + 0.2 * Math.sin(G.time * 3); tdEmoji(c, '🤝', x + 17, y - 4, 12); c.globalAlpha = 1; }
    }
    // уровень: точки, у мастера – звезда и число усилений
    c.textAlign = 'center';
    if (L < 4) { for (let i = 0; i < L; i++) { c.fillStyle = '#3a2a10'; c.beginPath(); c.arc(x - (L - 1) * 4 + i * 8, y + 16, 3.6, 0, TAU); c.fill(); c.fillStyle = '#ffd25a'; c.beginPath(); c.arc(x - (L - 1) * 4 + i * 8, y + 16, 2.6, 0, TAU); c.fill(); } }
    else { c.font = 'bold 11px Krilessa Icons, sans-serif'; c.fillStyle = '#000'; c.fillText('★' + (tw.boost ? '+' + tw.boost : ''), x + 1, y + 21); c.fillStyle = '#ffd25a'; c.fillText('★' + (tw.boost ? '+' + tw.boost : ''), x, y + 20); }
  }
  function drawDefUnit(c, u) {
    if (u.dead) return;
    const S = Defense.tdUS(u.tw), by = u.mv ? Math.abs(Math.sin(u.t * 14)) * 3 : 0, lunge = u.hit > 0 ? u.face * 5 : 0;
    shadow(c, u.x, u.y + 6, 9, 3.5);
    if (u.temp || u.tw.temp) { c.strokeStyle = '#ff8ad8'; c.lineWidth = 2; c.beginPath(); c.ellipse(u.x, u.y + 6, 11, 4.5, 0, 0, TAU); c.stroke(); } // котоподмога – с розовым кольцом
    else if (S.armor) { c.strokeStyle = '#ffd25a'; c.lineWidth = 2; c.beginPath(); c.ellipse(u.x, u.y + 6, 11, 4.5, 0, 0, TAU); c.stroke(); }
    else if (S.dodge) { c.strokeStyle = '#b07aff'; c.lineWidth = 2; c.beginPath(); c.ellipse(u.x, u.y + 6, 11, 4.5, 0, 0, TAU); c.stroke(); }
    c.save(); c.translate(u.x + lunge, u.y + 5 - by); c.scale(-u.face, 1); // кот на картинке смотрит влево
    if (u.flash > 0) c.globalAlpha = 0.5;
    c.fillStyle = '#fff'; c.font = '19px Krilessa Icons, sans-serif'; c.textAlign = 'center'; c.fillText('🐈', 0, 0);
    c.restore(); c.globalAlpha = 1;
    if (u.hp < u.maxHp) { c.fillStyle = 'rgba(0,0,0,0.6)'; c.fillRect(u.x - 11, u.y - 20, 22, 3.5); c.fillStyle = '#7dff7d'; c.fillRect(u.x - 11, u.y - 20, 22 * clamp(u.hp / u.maxHp, 0, 1), 3.5); }
  }
  // поверх всех: снаряды, молнии и подсказки у входов
  function drawDefOver(c, vis) {
    const A = G.abyss, M = G.td, t = G.time;
    for (const s of M.shots) {
      if (s.k === 'f') { Renderer.drawFeather(c, s.x, s.y, s.a || 0, s.big ? 1.6 : 1.1); continue; }
      tdEll(c, s.x, s.y, 7, 3, 'rgba(0,0,0,0.3)');
      drawFireball(c, s.x, s.y - s.z, Math.atan2(s.ty - s.sy - Math.cos(Math.min(1, s.t / s.dur) * Math.PI) * Math.PI * (s.big ? 110 : 70), s.tx - s.sx), s.big ? 2 : 1.25);
    }
    c.lineCap = 'round'; c.lineJoin = 'round';
    for (const z of M.zaps) { // молния: ломаная из трёх колен
      const a = clamp(z.life / 0.16, 0, 1), dx = z.x1 - z.x0, dy = z.y1 - z.y0;
      if (!z.j) z.j = [rnd(-9, 9), rnd(-9, 9), rnd(-9, 9), rnd(-9, 9)];
      c.globalAlpha = a; c.beginPath(); c.moveTo(z.x0, z.y0); c.lineTo(z.x0 + dx * 0.33 + z.j[0], z.y0 + dy * 0.33 + z.j[1]); c.lineTo(z.x0 + dx * 0.66 + z.j[2], z.y0 + dy * 0.66 + z.j[3]); c.lineTo(z.x1, z.y1);
      c.strokeStyle = '#fff3a0'; c.lineWidth = 4.5; c.stroke(); c.strokeStyle = '#ffffff'; c.lineWidth = 1.5; c.stroke();
    }
    c.globalAlpha = 1; c.lineCap = 'butt'; c.lineJoin = 'miter';
    for (const e of G.enemies) { // лёд и растерянность
      if (e.dead || !vis(e.x, e.y, 40)) continue;
      if (e.ln !== undefined && Defense.tdPortal(e)) { c.strokeStyle = `rgba(224,160,255,${0.45 + 0.25 * Math.sin(t * 8 + e.x)})`; c.lineWidth = 2; c.beginPath(); c.arc(e.x, e.y - (e.fly ? 12 : 4), e.r + 6, 0, TAU); c.stroke(); }
      if (e.stunT > 0) { c.fillStyle = e.iceT > 0 ? 'rgba(170,230,255,0.5)' : 'rgba(255,240,150,0.35)'; c.beginPath(); c.arc(e.x, e.y - 4, e.r + 4, 0, TAU); c.fill(); if (!(e.iceT > 0)) tdEmoji(c, '💫', e.x, e.y - e.r - 8, 12); }
      else if (e.confT > 0) tdEmoji(c, '🌀', e.x, e.y - e.r - 8 + Math.sin(t * 9) * 2, 13);
    }
    // что идёт следующей волной – над каждым входом
    const sum = A.next && A.next.sum, wait = A.passed >= A.wave && !A.q.length && !A.spawning && !G.activeBoss;
    if (sum && wait) for (const [ln, list] of sum) {
      const L = M.lanes[ln]; if (!L || !vis(L.gate.x, L.gate.y, 140)) continue;
      const g = L.gate, sx = Math.sign(L.pts[2].x - g.x), sy = Math.sign(L.pts[2].y - g.y);
      const bx = g.x + sx * 34, by = g.y + sy * 44 - 34 + Math.sin(t * 3) * 3, tx = list.slice(0, 4).map(([tag, n]) => `${TD_TAG[tag] || '👣'}${n > 1 ? n : ''}`).join(' ');
      c.font = 'bold 14px Krilessa Icons, sans-serif'; c.textAlign = 'center';
      const w = Math.max(44, c.measureText(tx).width + 16);
      c.fillStyle = 'rgba(30,10,50,0.86)'; roundRect(c, bx - w / 2, by - 15, w, 24, 9); c.fill(); c.strokeStyle = list.some(([tg]) => tg === 'boss' || tg === 'champ') ? '#ff5b5b' : '#e0a0ff'; c.lineWidth = 2; c.stroke();
      c.fillStyle = '#fff'; c.fillText(tx, bx, by + 2);
    }
  }
  // под плашкой уровня – две крупные плашки: жизни кристалла и монетки на стройку
  function drawDefHud(c, x, y) {
    const C = G.core, A = G.abyss, hpF = clamp(C.hp / TD_LIVES, 0, 1), h = 26;
    if (A.coins !== A.coinSeen) { if (A.coinSeen !== undefined && A.coins > A.coinSeen) A.coinUpT = G.time; A.coinSeen = A.coins; }
    const up = clamp(1 - (G.time - (A.coinUpT === undefined ? -9 : A.coinUpT)) / 0.35, 0, 1), no = clamp(1 - (G.time - (A.coinNoT === undefined ? -9 : A.coinNoT)) / 0.6, 0, 1);
    // кристалл
    c.fillStyle = C.flash > 0 ? 'rgba(255,90,140,0.85)' : 'rgba(0,0,0,0.55)'; roundRect(c, x, y, 70, h, 10); c.fill();
    c.textAlign = 'left'; c.font = '14px Krilessa Icons, sans-serif'; c.fillStyle = '#fff'; c.fillText('💎', x + 7, y + 18);
    const coop = NET.on && G.netRun;
    c.font = coop ? '900 12px Krilessa Icons, sans-serif' : '900 15px Krilessa Icons, sans-serif'; c.fillStyle = hpF > 0.5 ? '#ffb0e4' : hpF > 0.25 ? '#ffd25a' : '#ff6a6a'; c.fillText(coop ? C.hp + '/' + TD_LIVES : String(C.hp), x + 29, y + 19);
    c.fillStyle = 'rgba(255,255,255,0.18)'; c.fillRect(x + 8, y + h - 5, 54, 2.5); c.fillStyle = hpF > 0.5 ? '#ff8ad8' : hpF > 0.25 ? '#ffd25a' : '#ff4d4d'; c.fillRect(x + 8, y + h - 5, 54 * hpF, 2.5);
    // монетки: вспыхивают, когда прибавились, и краснеют, когда не хватило
    const tx = String(A.coins); c.font = `900 ${15 + up * 3}px Krilessa Icons, sans-serif`;
    const w = Math.max(74, c.measureText(tx).width + 38), cx = x + 76;
    c.fillStyle = no > 0 ? `rgba(200,40,40,${0.55 + no * 0.35})` : `rgba(${Math.round(60 * up)},${Math.round(40 * up)},0,${0.55 + up * 0.25})`; roundRect(c, cx, y, w, h, 10); c.fill();
    c.strokeStyle = no > 0 ? '#ff8a8a' : '#ffd25a'; c.lineWidth = 1.5 + up; roundRect(c, cx, y, w, h, 10); c.stroke();
    c.font = '15px Krilessa Icons, sans-serif'; c.fillStyle = '#fff'; c.fillText('🪙', cx + 7, y + 19);
    c.font = `900 ${15 + up * 3}px Krilessa Icons, sans-serif`; c.fillStyle = no > 0 ? '#ffd0d0' : '#ffd25a'; c.fillText(tx, cx + 29, y + 19 + up);
  }

  return {
    drawDefGround, drawDefFac, drawDefCore, drawDefTower, drawDefUnit, drawDefOver, drawDefHud,
  };
})();
