'use strict';

const Collection = (() => {
  let relicsFrom = 'coll';

  // ---------- Кринжопедия: все встреченные мобы и боссы ----------
  const BOOK = { e: {}, b: {} };
  let bookCache = null, bookScanT = 0;
  const bookData = () => { if (!bookCache) { const pr = Saves.loadProfile(); bookCache = pr.book || { e: {}, b: {} }; } return bookCache; };
  const bookKnown = (g, k) => (bookData()[g][k] !== undefined) || BOOK[g][k] !== undefined;
  function bookSee(g, k) { if (!bookKnown(g, k)) BOOK[g][k] = 0; }
  function bookKill(g, k) { BOOK[g][k] = (BOOK[g][k] || 0) + 1; }
  let BOOK_LIST = null;
  function bookList() {
    if (BOOK_LIST) return BOOK_LIST;
    const eCh = {}, bCh = {};
    for (const n of Session.CH_NUMS) {
      const C = CHAPTERS[n];
      for (const [b] of C.biomeSeeds) if (SPAWNS[b]) for (const [t] of SPAWNS[b]) if (eCh[t] === undefined) eCh[t] = n;
      for (const k of C.bosses) if (bCh[k] === undefined) bCh[k] = n;
    }
    const es = Object.keys(ENEMIES).filter(t => ESPR[ENEMIES[t].sprite || t]).sort((a, b) => (eCh[a] || 99) - (eCh[b] || 99));
    const bs = Object.keys(BOSSES).filter(k => bCh[k] !== undefined).sort((a, b) => bCh[a] - bCh[b]);
    BOOK_LIST = { es, bs, eCh, bCh };
    return BOOK_LIST;
  }
  function bookCount() {
    const L = bookList(), D = bookData();
    const known = L.es.filter(t => D.e[t] !== undefined || BOOK.e[t] !== undefined).length + L.bs.filter(k => D.b[k] !== undefined || BOOK.b[k] !== undefined).length;
    const total = L.es.length + L.bs.length;
    return { known, total, pct: total ? Math.round(known / total * 100) : 0 };
  }
  // раз в полсекунды: кто рядом – тот «встречен»
  function bookScan(dt) {
    bookScanT -= dt; if (bookScanT > 0) return; bookScanT = 0.5;
    for (const e of G.enemies) if (!e.dead && (e.x - P.x) ** 2 + (e.y - P.y) ** 2 < 430 * 430) bookSee('e', e.type);
    if (G.activeBoss) bookSee('b', G.activeBoss.kind);
  }
  const AI_TXT = { chase: 'Бежит за тобой и кусает', swarm: 'Нападает стаей', ranged: 'Стреляет издалека и держит дистанцию', turret: 'Стоит на месте и палит',
    exploder: 'Подбегает и взрывается', bat: 'Летает зигзагами', charger: 'Разгоняется и таранит', shield: 'Прикрывается щитом спереди', healer: 'Лечит соседей',
    buffer: 'Делает соседей крепче', summoner: 'Призывает помощников', jump: 'Прыгает прямо на тебя', hop: 'Скачет к тебе', bouncer: 'Отскакивает от стен', blinker: 'Телепортируется рядом' };
  function bookThumb(g, k, size, known) {
    const cv = document.createElement('canvas'); cv.width = cv.height = size; const c = cv.getContext('2d');
    try {
      if (g === 'e') {
        const d = ENEMIES[k], e = { type: k, def: d, sprite: d.sprite || k, x: 0, y: 0, r: d.r, t: 0.4, look: 0.3, face: 1, flash: 0, col: d.col, hp: 1, maxHp: 1, charge: 0, fuse: 0, wind: 0, jd: 0, blink: 0,
          shieldAng: 0, healing: 0, buffT: 0, spawnT: 0, slowT: 0, burnT: 0, seed: 1, chn: bookList().eCh[k] || 1, elite: false, vx: 0, vy: 0, kx: 0, ky: 0, fly: !!d.fly };
        c.translate(size / 2, size * 0.58); const s = size * 0.36 / Math.max(10, d.r); c.scale(s, s); ESPR[e.sprite](c, e);
      } else {
        const d = BOSSES[k], b = { kind: k, def: d, flash: 0, stage: 0, look: 0.3, mode: 'idle', charging: false, anim: 0.5, z: 0, state: 'idle', r: d.r, alpha: 1, shield: false, hp: 1, maxHp: 1, t: 0 };
        c.translate(size / 2, size * 0.6); const s = size * 0.33 / Math.max(14, d.r); c.scale(s, s); BSPR[d.sprite || k](c, b, 0.5, 1);
      }
    } catch (e) { c.setTransform(1, 0, 0, 1, 0, 0); c.font = `${size * 0.5}px Krilessa Icons, sans-serif`; c.textAlign = 'center'; c.fillText(g === 'e' ? '👾' : '💀', size / 2, size * 0.68); }
    if (!known) { c.setTransform(1, 0, 0, 1, 0, 0); c.globalCompositeOperation = 'source-atop'; c.fillStyle = '#4a3d72'; c.fillRect(0, 0, size, size); }
    return cv;
  }
  let bookTab = 'e';
  let bookBack = 'coll';
  function openBook(tab, back) { bookTab = typeof tab === 'string' ? tab : 'e'; bookBack = back === 'home' ? 'home' : 'coll'; renderBook(); Screens.setState('book'); }
  const bookLeave = () => { if (bookBack === 'home') HomeScreen.openHome(HomeScreen.HOME.back); else openColl(); };
  const relicsLeave = () => { const f = relicsFrom; relicsFrom = 'coll'; if (f === 'home') HomeScreen.openHome(HomeScreen.HOME.back); else openColl(); };
  function renderBook() {
    Achievements.lifeFlush();
    const L = bookList(), D = bookData(), cnt = bookCount();
    $('bookHead').textContent = `Открыто ${cnt.known} из ${cnt.total} (${cnt.pct}%)`;
    $('bookTabE').classList.toggle('on', bookTab === 'e'); $('bookTabB').classList.toggle('on', bookTab === 'b'); $('bookTabV').classList.toggle('on', bookTab === 'v');
    const grid = $('bookGrid'); grid.innerHTML = ''; grid.classList.toggle('evo', bookTab === 'v');
    if (bookTab === 'v') { // эволюции: рецепт виден сразу, название – когда соберёшь
      const seen = Saves.loadProfile().evoSeen || {}, un = k => { const u = UPGRADES.find(x => x.id === k); return u ? u.ic + ' ' + u.nm : k; };
      $('bookHead').textContent = `Эволюций открыто ${EVOS.filter(e => seen[e.id]).length} из ${EVOS.length} · два улучшения на нужном уровне сливаются в одно`;
      for (const e of EVOS) {
        const got = !!seen[e.id], el = document.createElement('div'); el.className = 'bkEvo' + (got ? ' got' : '');
        el.innerHTML = `<i>${got ? e.ic : '❔'}</i><div><b>${got ? e.nm : '???'}</b><span>${got ? e.ds : 'Собери рецепт – и узнаешь'}</span><small>${e.need.map(([k, n]) => `${un(k)} ${n}+`).join(' &nbsp;+&nbsp; ')}</small></div>`;
        grid.appendChild(el);
      }
      return;
    }
    for (const k of bookTab === 'e' ? L.es : L.bs) {
      const g = bookTab, v = D[g][k], known = v !== undefined;
      const el = document.createElement('button'); el.className = 'bkCard' + (known ? '' : ' unk');
      el.appendChild(bookThumb(g, k, 64, known));
      const nm = document.createElement('b'); nm.textContent = known ? (g === 'e' ? ENEMIES[k].name : BOSSES[k].name) : '???'; el.appendChild(nm);
      if (known && v > 0) { const s = document.createElement('small'); s.textContent = '✖ ' + RunStats.fmtN(v); el.appendChild(s); }
      el.addEventListener('click', () => { if (known) bookCard(g, k); else RunStats.toast('Ещё не встречалась 👀'); });
      grid.appendChild(el);
    }
  }
  function bookCard(g, k) {
    const L = bookList(), D = bookData(), v = D[g][k] || 0, box = $('bkDetail');
    const big = $('bkBig'); big.innerHTML = ''; big.appendChild(bookThumb(g, k, 150, true));
    if (g === 'e') {
      const d = ENEMIES[k], ch = L.eCh[k];
      $('bkName').textContent = d.name;
      $('bkSub').textContent = (ch ? `Глава ${ch}` : 'Особый') + (d.fly ? ' · летает' : '');
      const lines = [AI_TXT[d.ai] || 'Ведёт себя загадочно'];
      if (d.shot) lines.push(d.shot.ring ? 'Стреляет кольцом во все стороны' : d.shot.kind === 'bolt' ? 'Бьёт молнией с неба' : 'Пуляет снарядами');
      if (d.group) lines.push(`Ходит компанией по ${d.group[0]}–${d.group[1]}`);
      if (d.split) lines.push('Если победить – распадается на малышей');
      if (d.puddle) lines.push('Оставляет ядовитую лужу');
      lines.push(v ? `Побеждено: ${RunStats.fmtN(v)}` : 'Ещё ни разу не побеждён');
      $('bkText').innerHTML = lines.map(t => '• ' + Multiplayer.escHtml(t)).join('<br>');
    } else {
      const d = BOSSES[k], ch = L.bCh[k], ln = d.lines || {};
      $('bkName').textContent = d.name;
      $('bkSub').textContent = `${d.sub || 'Босс'} · Глава ${ch}`;
      const out = [];
      if (ln.intro) out.push(`<i>«${Multiplayer.escHtml(ln.intro)}»</i>`);
      if (ln.death) out.push(`<i>«${Multiplayer.escHtml(ln.death)}»</i>`);
      out.push(v ? `Побеждён: ${RunStats.fmtN(v)} раз` : 'Ещё не побеждён');
      $('bkText').innerHTML = out.join('<br><br>');
    }
    box.classList.remove('hidden');
  }

  // ---------- хабы меню ----------
  // карточка обороны: выбор карты и рекорды
  function mdDefRender(pr, open) {
    const cur = Defense.tdMapPick(pr), best = (pr.tdBest || {})[cur.id], box = $('mdDefMaps');
    $('mdDefTx').textContent = !open ? '🔒 После главы 1' : `${cur.nm}: ${cur.ds.toLowerCase()}` + (best ? ` · рекорд: ${best.wave} ${plural(best.wave, 'волна', 'волны', 'волн')}` : '');
    box.innerHTML = '';
    if (!open) return;
    for (const M of TD_MAPS.filter(m => !m.coop)) {
      const ok = Defense.tdMapOpen(M, pr), b = document.createElement('button'), bw = ((pr.tdBest || {})[M.id] || {}).wave || 0;
      b.className = 'mdMap' + (M === cur ? ' on' : '') + (ok ? '' : ' no');
      b.innerHTML = `${ok ? M.ic : '🔒'}<small>${ok ? (bw ? bw : '–') : ''}</small>`;
      b.addEventListener('click', () => {
        if (!ok) { RunStats.toast(`🔒 «${M.nm}» откроется, когда отобьёшь 10 волн на карте «${TD_MAP_BY[M.need].nm}»`); Sound.sfx.block(); return; }
        const p2 = Saves.loadProfile(); p2.settings = p2.settings || {}; p2.settings.defMap = M.id; Saves.saveProfile(p2); Sound.sfx.click(); mdDefRender(p2, true);
      });
      box.appendChild(b);
    }
  }
  function openModes() {
    const pr = Saves.loadProfile(), open = pr.ch1Done || GameLoop.DEBUG || pr.admin;
    const hero = Challenges.rushHeroPick(pr); $('mdHero').textContent = '🔄 ' + HEROES[hero].name;
    const rb = pr.rushBest, ab = pr.abyssBest, D = Challenges.dailyInfo(), dd = pr.daily || {};
    $('mdRushTx').textContent = !open ? '🔒 После главы 1' : rb ? `Рекорд: ${rb.n}/${rb.total} за ${RunStats.fmtT(rb.time)}` : 'Все побеждённые боссы подряд, на время';
    const ck = open ? Challenges.abyssCkLoad() : null;
    $('mdAbyssTx').textContent = !open ? '🔒 После главы 1' : ck ? `Сохранено: волна ${ck.wave}` + (ab ? ` · рекорд ${ab.wave}` : '') : ab ? `Рекорд: волна ${ab.wave} · ${RunStats.fmtT(ab.time)}` : 'Волна за волной, каждая пятая – с боссом';
    mdDefRender(pr, open);
    $('mdAbyssGo').textContent = ck ? 'Дальше' : 'Нырнуть';
    $('mdAbyssNew').classList.toggle('hidden', !ck);
    $('mdDailyTx').textContent = `Глава ${D.ch} · ${D.muts.map(m => Challenges.MUT_BY[m].ic + ' ' + Challenges.MUT_BY[m].nm).join(' + ')}` +
      (dd.key === D.key ? ` · сегодня: ${dd.best} очк.` : ' · 5 минут на очки') + (dd.streak > 1 && (dd.key === D.key || dd.key === Challenges.dayKey(new Date(Date.now() - 864e5))) ? ` · 🔥${dd.streak} дн.` : '');
    for (const id of ['chapRush', 'mdAbyssGo', 'mdDefGo']) $(id).classList.toggle('locked', !open);
    Screens.setState('modes');
  }
  // ---------- коллекция реликвий: надеть, снять, посмотреть уровни ----------
  const wearMax = pr => 3 + (((pr.talents || {}).relic || 0) ? 1 : 0);
  function openRelics() { renderRelics(); Screens.setState('relics'); }
  function renderRelics() {
    const pr = Saves.loadProfile(), lvs = pr.relicLv || {}, worn = (pr.relics || []).filter(id => RELICS[id]), mx = wearMax(pr);
    const own = Object.keys(RELICS).filter(id => lvs[id] || worn.includes(id));
    $('rlHead').textContent = `Найдено ${own.length} из ${Object.keys(RELICS).length} · надето ${worn.length} из ${mx} · новые и прокачка – в золотых сундуках`;
    const box = $('rlList'); box.innerHTML = '';
    for (const id of Object.keys(RELICS).sort((a, b) => (worn.includes(b) - worn.includes(a)) || ((lvs[b] || 0) - (lvs[a] || 0)))) {
      const r = RELICS[id], L = Math.min(3, lvs[id] || (worn.includes(id) ? 1 : 0)), on = worn.includes(id);
      const el = document.createElement('div'); el.className = 'rlRow' + (on ? ' on' : '') + (L ? '' : ' no');
      el.innerHTML = `<i>${L ? r.ic : '❔'}</i><div><b>${L ? r.name : '???'}${L ? ` <u>${'★'.repeat(L)}${'☆'.repeat(3 - L)}</u>` : ''}</b><span>${L ? relicDs(id, L) : 'Ещё не найдена – ищи в золотых сундуках'}</span>${L && L < 3 ? `<small>Ур. ${L + 1}: ${relicDs(id, L + 1)}</small>` : ''}</div>`;
      if (L) {
        const b = document.createElement('button'); b.className = 'btn ' + (on ? 'gray' : ''); b.textContent = on ? 'Снять' : 'Надеть';
        b.addEventListener('click', () => {
          const p2 = Saves.loadProfile(); let w = (p2.relics || []).filter(x => RELICS[x]);
          if (w.includes(id)) w = w.filter(x => x !== id);
          else { if (w.length >= wearMax(p2)) { RunStats.toast(`Можно носить ${wearMax(p2)} – сначала сними одну`); Sound.sfx.block(); return; } w.push(id); }
          p2.relics = w; p2.relicLv = p2.relicLv || {}; if (!p2.relicLv[id]) p2.relicLv[id] = 1; Saves.saveProfile(p2); Sound.sfx.click(); renderRelics();
        });
        el.appendChild(b);
      }
      box.appendChild(el);
    }
  }
  function openColl() {
    Achievements.lifeFlush();
    const pr = Saves.loadProfile(), n = Achievements.ACHS.filter(a => (pr.ach || {})[a.id]).length, cnt = bookCount();
    $('clAchN').textContent = `${n} / ${Achievements.ACHS.length}`; $('clBookN').textContent = `${cnt.known} / ${cnt.total}`;
    const g = Achievements.gloryOf(pr); $('clHallN').textContent = `${g.rank.ic} ${g.rank.nm} · ✨ ${RunStats.fmtN(g.fame)}`;
    let own = 0, all = 0; for (const k in LOOK_SETS) for (const it of LOOK_SETS[k]) { all++; if (lookOwned(it, pr.ach, g.rk)) own++; }
    $('clLookN').textContent = `наград ${own} / ${all}`;
    $('clRelicN').textContent = `${Object.keys(RELICS).filter(id => (pr.relicLv || {})[id] || (pr.relics || []).includes(id)).length} / ${Object.keys(RELICS).length}`;
    $('btnWardrobe').classList.toggle('hidden', !(pr.ch3Done || GameLoop.DEBUG || pr.admin));
    Screens.setState('coll');
  }
  // экраны итогов для Бездны и испытания дня
  function victoryExtras(mode) {
    if (mode === 'daily' && G.daily) {
      const D = G.daily;
      $('victoryTitle').textContent = '📅 Время вышло!';
      $('victoryStats').innerHTML = `Очков: <b>${RunStats.fmtN(D.score)}</b>${D.better ? ' · 🏆 лучший результат дня!' : ''}<br>Лучший сегодня: <b>${RunStats.fmtN(D.best)}</b> · подряд дней: <b>${D.streak}</b> 🔥<br>Уровень ${P.level} · Врагов: ${G.kills}`;
      $('victoryTeaser').innerHTML = 'Завтра – новая карта и новые правила!'; $('victoryTeaser').classList.remove('hidden');
      $('victoryNext').classList.add('hidden');
      const vc = $('victoryPortrait').getContext('2d'); vc.clearRect(0, 0, 300, 300); vc.drawImage(heroPortrait(P.hero, 300), 0, 0, 300, 300);
    } else if (G.mutEarned !== undefined && Challenges.mutIds().length && typeof World.CHN === 'number' && !G.daily) {
      $('victoryStats').insertAdjacentHTML('beforeend', `<br>🧪 Мутаторы: ${Challenges.mutIds().map(id => Challenges.MUT_BY[id].ic).join('')}${G.mutEarned ? ` · <b>+${G.mutEarned} ⭐</b>` : ''}`);
    }
  }

  return {
    BOOK, bookData, bookKill, bookList, bookCount, bookScan, bookThumb, openBook, bookLeave,
    relicsLeave, renderBook, openModes, openRelics, openColl, victoryExtras,
    get relicsFrom() { return relicsFrom; },
    set relicsFrom(value) { relicsFrom = value; },
    get bookCache() { return bookCache; },
    set bookCache(value) { bookCache = value; },
    get bookTab() { return bookTab; },
    set bookTab(value) { bookTab = value; },
    get bookBack() { return bookBack; },
  };
})();
