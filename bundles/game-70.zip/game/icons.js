'use strict';
// =====================================================================
//  1.0: свои иконки вместо эмодзи – чернильный контур и акварельная заливка.
//  Эмодзи из словаря EMO сами превращаются в эти иконки:
//  на холсте (fillText/strokeText) и в тексте интерфейса (наблюдатель за DOM).
//  В интерфейсе символ остаётся в тексте (прозрачным), поверх – картинка: textContent не меняется.
// =====================================================================
const ICON = (() => {
  const I = '#4b2e1e', W = 2.4;
  const st = (w = W) => `stroke="${I}" stroke-width="${w}"`;
  const hl = (x, y, rx, ry, r = -30) => `<ellipse cx="${x}" cy="${y}" rx="${rx}" ry="${ry}" fill="#fff" opacity=".75" transform="rotate(${r} ${x} ${y})"/>`;
  const star5 = (cx, cy, R, r) => { let p = ''; for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + i * Math.PI / 5, q = i % 2 ? r : R; p += (i ? 'L' : 'M') + (cx + Math.cos(a) * q).toFixed(1) + ' ' + (cy + Math.sin(a) * q).toFixed(1); } return p + 'Z'; };
  const S = {
    coin: `<circle cx="36" cy="38" r="22" fill="#f2c13a" ${st()}/><circle cx="36" cy="38" r="14" fill="none" stroke="#c88a18" stroke-width="2"/><path d="M36 28v20M30 33h9a4 4 0 0 1 0 8h-9" fill="none" stroke="#a86a10" stroke-width="2.6"/>${hl(27, 29, 5, 3)}`,
    gem: `<path d="M36 10l17 20-17 32-17-32z" fill="#9ad8f0" ${st()}/><path d="M19 30h34M36 10l-7 20 7 32 7-32z" fill="none" stroke="#4a8ab8" stroke-width="1.6"/><path d="M28 21l4-6" stroke="#fff" stroke-width="2.6"/>`,
    heart: `<path d="M36 60C11 43 13 21 26 19c6-1 9 3 10 7 1-4 4-8 10-7 13 2 15 24-10 41z" fill="#e8504a" ${st()}/><path d="M23 28c1-3 4-5 7-4" stroke="#fff" stroke-width="2.6" fill="none"/>`,
    heartp: `<path d="M36 60C11 43 13 21 26 19c6-1 9 3 10 7 1-4 4-8 10-7 13 2 15 24-10 41z" fill="#f28ab4" ${st()}/><path d="M23 28c1-3 4-5 7-4" stroke="#fff" stroke-width="2.6" fill="none"/>`,
    heartb: `<path d="M36 60C11 43 13 21 26 19c6-1 9 3 10 7 1-4 4-8 10-7 13 2 15 24-10 41z" fill="#e8504a" ${st()}/><path d="M36 26l-5 9 7 5-5 10" fill="none" stroke="#fffaf0" stroke-width="3.2"/><path d="M36 26l-5 9 7 5-5 10" fill="none" ${st(1.4)}/>`,
    star: `<path d="${star5(36, 38, 25, 11)}" fill="#f2c13a" ${st()}/><path d="M32 24l3-6" stroke="#fff" stroke-width="2.6"/>`,
    sparkle: `<path d="M36 8c3 16 8 21 24 26-16 4-21 9-24 26-3-17-8-22-24-26 16-5 21-10 24-26z" fill="#f6dc6a" ${st()}/><path d="M56 10c1 5 3 7 8 8-5 1-7 3-8 8-1-5-3-7-8-8 5-1 7-3 8-8z" fill="#fff3b0" ${st(1.6)}/>`,
    shoot: `<path d="${star5(50, 22, 12, 5)}" fill="#f2c13a" ${st(2)}/><path d="M40 32L12 60M34 25L16 43M47 40L30 57" stroke="#9ad0f0" stroke-width="4"/>`,
    dizzy: `<path d="M36 14a22 22 0 1 1-20 13" fill="none" stroke="#a68af0" stroke-width="5"/><path d="M36 14a22 22 0 1 1-20 13" fill="none" ${st(1.4)}/><path d="${star5(17, 24, 9, 4)}" fill="#f2c13a" ${st(1.6)}/><circle cx="36" cy="36" r="5" fill="#f2c13a" ${st(1.6)}/>`,
    fire: `<path d="M36 8c10 12 17 21 13 33-2 9-8 13-13 13s-11-4-13-13c-2-8 4-15 8-19 0 6 2 9 4 9 2-8 0-15 1-23z" fill="#f2a03a" ${st()}/><path d="M36 30c4 6 6 10 4 16-1 3-3 4-4 4s-3-1-4-4c-1-4 2-7 4-16z" fill="#ffe08a" ${st(1.6)}/>`,
    lock: `<path d="M24 32v-8a12 12 0 0 1 24 0v8" fill="none" ${st(4)}/><path d="M24 32v-8a12 12 0 0 1 24 0v8" fill="none" stroke="#b8c0c8" stroke-width="2"/><rect x="16" y="31" width="40" height="28" rx="5" fill="#f2c13a" ${st()}/><path d="M36 40v8" ${st(3.4)}/><circle cx="36" cy="40" r="3.4" fill="${I}"/>`,
    paw: `<ellipse cx="36" cy="44" rx="11" ry="10" fill="#4a4658" ${st()}/><circle cx="21" cy="30" r="5.5" fill="#4a4658" ${st(2)}/><circle cx="31" cy="21" r="5.5" fill="#4a4658" ${st(2)}/><circle cx="43" cy="21" r="5.5" fill="#4a4658" ${st(2)}/><circle cx="52" cy="30" r="5.5" fill="#4a4658" ${st(2)}/><ellipse cx="36" cy="46" rx="5" ry="4" fill="#f0a0b8"/>`,
    swords: `<path d="M16 16l30 30M56 16L26 46" ${st(6)}/><path d="M16 16l30 30M56 16L26 46" stroke="#d8dce8" stroke-width="3"/><path d="M40 52l12-12M20 40l12 12" ${st(4)}/><path d="M48 52l8 8M24 52l-8 8" ${st(5)}/><path d="M48 52l8 8M24 52l-8 8" stroke="#a86a3a" stroke-width="2.6"/>`,
    crown: `<path d="M12 50l4-28 12 12 8-18 8 18 12-12 4 28z" fill="#f2c13a" ${st()}/><rect x="12" y="50" width="48" height="8" rx="2" fill="#e0a020" ${st(2)}/><circle cx="36" cy="40" r="3.6" fill="#e8504a" ${st(1.4)}/><circle cx="24" cy="44" r="2.6" fill="#6ab0e8" ${st(1.2)}/><circle cx="48" cy="44" r="2.6" fill="#6ab04a" ${st(1.2)}/>`,
    shield: `<path d="M36 10l22 8v16c0 14-10 24-22 30-12-6-22-16-22-30V18z" fill="#6a9ad8" ${st()}/><path d="M36 16v42c9-5 16-13 16-24V22z" fill="#9ac0ec"/><path d="M36 10l22 8v16c0 14-10 24-22 30-12-6-22-16-22-30V18z" fill="none" ${st()}/>`,
    snow: `<path d="M36 10v52M13 23l46 26M59 23L13 49" ${st(5)}/><path d="M36 10v52M13 23l46 26M59 23L13 49" stroke="#9ad8f0" stroke-width="2.6"/><circle cx="36" cy="36" r="5" fill="#fff" ${st(2)}/>`,
    refresh: `<path d="M54 30A19 19 0 0 0 19 26" fill="none" stroke="#6ab04a" stroke-width="6"/><path d="M18 42a19 19 0 0 0 35 4" fill="none" stroke="#6ab04a" stroke-width="6"/><path d="M14 16l4 12 12-4M58 56l-4-12-12 4" fill="none" ${st(3)}/>`,
    box: `<path d="M12 26l24-10 24 10v28L36 64 12 54z" fill="#d8a46a" ${st()}/><path d="M12 26l24 10 24-10M36 36v28" fill="none" ${st()}/><path d="M24 21l24 10v8" fill="none" stroke="#a87a42" stroke-width="3"/>`,
    trophy: `<path d="M22 14h28v14a14 14 0 0 1-28 0z" fill="#f2c13a" ${st()}/><path d="M22 18h-8c0 10 4 14 10 14M50 18h8c0 10-4 14-10 14" fill="none" ${st(2.2)}/><path d="M32 42h8v8h-8zM24 50h24v8H24z" fill="#e0a020" ${st(2)}/>${hl(29, 22, 3, 6, 0)}`,
    map: `<path d="M10 18l16-6 20 6 16-6v42l-16 6-20-6-16 6z" fill="#f2e2bc" ${st()}/><path d="M26 12v42M46 18v42" ${st(1.6)}/><path d="M16 40c6-8 12 4 18-4s12 2 16-6" fill="none" stroke="#c8342a" stroke-width="2.2" stroke-dasharray="3 3"/><path d="M50 28l4 4m0-4l-4 4" ${st(2)}/>`,
    check: `<path d="M14 38l14 14 30-32" fill="none" ${st(9)}/><path d="M14 38l14 14 30-32" fill="none" stroke="#6ab04a" stroke-width="5"/>`,
    target: `<circle cx="36" cy="36" r="24" fill="#fffaf0" ${st()}/><circle cx="36" cy="36" r="16" fill="#e8504a" ${st(2)}/><circle cx="36" cy="36" r="8" fill="#fffaf0" ${st(2)}/><circle cx="36" cy="36" r="3" fill="#e8504a"/>`,
    hole: `<ellipse cx="36" cy="40" rx="26" ry="14" fill="#2a1a3a" ${st()}/><ellipse cx="36" cy="42" rx="18" ry="8" fill="#140a1e"/><path d="M20 36c6-4 26-4 32 0" fill="none" stroke="#7a5ab0" stroke-width="2"/>`,
    house: `<path d="M12 36L36 14l24 22" fill="#c84a3a" ${st()}/><path d="M18 34v26h36V34" fill="#f2c890" ${st()}/><path d="M31 60V46h10v14" fill="#8a5a34" ${st(2)}/><rect x="42" y="38" width="7" height="6" fill="#9ad8f0" ${st(1.6)}/>`,
    swirl: `<path d="M36 36m-4 0a4 4 0 1 1 8 0a8 8 0 1 1-16 0a12 12 0 1 1 24 0a16 16 0 1 1-32 0a20 20 0 1 1 40 0" fill="none" stroke="#6ab0e8" stroke-width="4.4"/><path d="M36 36m-4 0a4 4 0 1 1 8 0a8 8 0 1 1-16 0a12 12 0 1 1 24 0a16 16 0 1 1-32 0a20 20 0 1 1 40 0" fill="none" ${st(1.2)}/>`,
    bolt: `<path d="M40 8L18 40h14l-6 24 24-34H36z" fill="#f6dc6a" ${st()}/>`,
    mirror: `<ellipse cx="36" cy="32" rx="16" ry="20" fill="#c8a060" ${st()}/><ellipse cx="36" cy="32" rx="11" ry="15" fill="#cfe8f6" ${st(1.6)}/><path d="M36 52v12M28 64h16" ${st(3)}/><path d="M30 24l4-6" stroke="#fff" stroke-width="2.6"/>`,
    skull: `<path d="M16 34c0-14 9-22 20-22s20 8 20 22c0 7-3 11-7 13v9H23v-9c-4-2-7-6-7-13z" fill="#f2ecdc" ${st()}/><circle cx="28" cy="34" r="5.5" fill="${I}"/><circle cx="44" cy="34" r="5.5" fill="${I}"/><path d="M36 40l-3 6h6z" fill="${I}"/><path d="M30 56v-6M36 56v-6M42 56v-6" ${st(1.8)}/>`,
    rainbow: `<path d="M8 54a28 28 0 0 1 56 0" fill="none" stroke="#e8504a" stroke-width="6"/><path d="M14 54a22 22 0 0 1 44 0" fill="none" stroke="#f2c13a" stroke-width="6"/><path d="M20 54a16 16 0 0 1 32 0" fill="none" stroke="#6ab04a" stroke-width="6"/><path d="M26 54a10 10 0 0 1 20 0" fill="none" stroke="#6ab0e8" stroke-width="6"/><path d="M5 54a31 31 0 0 1 62 0M29 54a7 7 0 0 1 14 0" fill="none" ${st(1.6)}/>`,
    key: `<circle cx="26" cy="30" r="11" fill="#f2c13a" ${st()}/><circle cx="26" cy="30" r="4" fill="#fffaf0" ${st(1.6)}/><path d="M34 38l18 18M46 50l5-5M50 54l4-4" fill="none" ${st(5)}/><path d="M34 38l18 18M46 50l5-5M50 54l4-4" fill="none" stroke="#f2c13a" stroke-width="2.4"/>`,
    gift: `<rect x="12" y="28" width="48" height="12" rx="2" fill="#e8504a" ${st()}/><rect x="16" y="40" width="40" height="22" fill="#e8504a" ${st()}/><path d="M36 28v34" stroke="#f2c13a" stroke-width="6"/><path d="M36 28c-8-12-20-8-14 0zM36 28c8-12 20-8 14 0z" fill="#f2c13a" ${st(2)}/>`,
    magnifier: `<circle cx="30" cy="30" r="16" fill="#cfe8f6" ${st()}/><path d="M42 42l16 16" ${st(7)}/><path d="M42 42l16 16" stroke="#a86a3a" stroke-width="3.6"/><path d="M22 24c2-4 6-6 9-5" stroke="#fff" stroke-width="2.6" fill="none"/>`,
    note: `<path d="M28 50V16l26-6v34" fill="none" ${st(3.4)}/><ellipse cx="22" cy="50" rx="8" ry="6" fill="#a68af0" ${st()}/><ellipse cx="48" cy="44" rx="8" ry="6" fill="#a68af0" ${st()}/><path d="M28 24l26-6" ${st(3.4)}/>`,
    calendar: `<rect x="12" y="16" width="48" height="44" rx="5" fill="#fffaf0" ${st()}/><path d="M12 28h48" ${st()}/><rect x="12" y="16" width="48" height="12" rx="5" fill="#e8504a" ${st()}/><path d="M24 10v12M48 10v12" ${st(3)}/><path d="M22 38h6M33 38h6M44 38h6M22 48h6M33 48h6" ${st(3)}/>`,
    scroll: `<path d="M20 14h30a6 6 0 0 1 0 12H20z" fill="#f2e2bc" ${st()}/><path d="M20 14c-6 0-6 12 0 12v34h30V26" fill="#fbf0d4" ${st()}/><path d="M26 36h18M26 44h18M26 52h12" ${st(1.8)}/>`,
    bubbles: `<circle cx="28" cy="40" r="14" fill="#cfeefa" ${st()}/><circle cx="48" cy="24" r="9" fill="#cfeefa" ${st(2)}/><circle cx="50" cy="48" r="5" fill="#cfeefa" ${st(1.6)}/>${hl(23, 34, 4, 2.5)}${hl(45, 20, 2.5, 1.6)}`,
    dove: `<path d="M12 40c10-2 18-12 22-22 4 8 4 16 0 22 8-4 16-4 26 2-10 6-22 12-36 10z" fill="#fffaf0" ${st()}/><path d="M34 18l6-4" ${st(2)}/><circle cx="44" cy="36" r="1.8" fill="${I}"/><path d="M58 42l6 2-6 2" fill="#f2c13a" ${st(1.4)}/>`,
    gate: `<path d="M10 20h52M14 28h44" ${st(5)}/><path d="M10 20h52M14 28h44" stroke="#e8504a" stroke-width="2.6"/><path d="M20 20v42M52 20v42" ${st(6)}/><path d="M20 20v42M52 20v42" stroke="#e8504a" stroke-width="3"/>`,
    shrimp: `<path d="M50 18c-20-4-34 10-32 28 1 8 8 14 16 14" fill="none" stroke="#f28a5a" stroke-width="10"/><path d="M50 18c-20-4-34 10-32 28 1 8 8 14 16 14" fill="none" ${st(1.6)}/><path d="M34 60l8 4-2-8" fill="#f28a5a" ${st(1.8)}/><circle cx="48" cy="20" r="2" fill="${I}"/><path d="M52 16c6-6 10-6 12-4M52 20c6 0 10 2 10 6" fill="none" ${st(1.4)}/>`,
    fish: `<path d="M12 36c10-14 30-14 40 0-10 14-30 14-40 0z" fill="#6ab0e8" ${st()}/><path d="M52 36l12-10v20z" fill="#6ab0e8" ${st()}/><circle cx="24" cy="33" r="2.4" fill="${I}"/><path d="M34 26c4 6 4 14 0 20" fill="none" stroke="#3a7ab8" stroke-width="1.8"/>`,
    moneybag: `<path d="M26 22h20l-4 6c10 4 16 12 16 22 0 8-8 12-22 12s-22-4-22-12c0-10 6-18 16-22z" fill="#d8b46a" ${st()}/><path d="M26 22l-2-8 6 4 6-6 6 6 6-4-2 8" fill="#d8b46a" ${st(2)}/><path d="M36 38v16M31 42h7a3.5 3.5 0 0 1 0 7h-7" fill="none" stroke="#8a5a14" stroke-width="2.4"/>`,
    wind: `<path d="M10 28h32a8 8 0 1 0-8-8M10 40h42a8 8 0 1 1-8 8M10 52h22" fill="none" stroke="#9ad0e8" stroke-width="4.4"/><path d="M10 28h32a8 8 0 1 0-8-8M10 40h42a8 8 0 1 1-8 8M10 52h22" fill="none" ${st(1.2)}/>`,
    compass: `<circle cx="36" cy="36" r="24" fill="#fffaf0" ${st()}/><path d="M36 16l7 20-7 20-7-20z" fill="#e8504a" ${st(1.8)}/><path d="M36 36l7 0-7 20-7-20z" fill="#d8dce8" ${st(1.8)}/><circle cx="36" cy="36" r="3" fill="${I}"/>`,
    boom: `<path d="M36 8l6 14 14-6-6 14 14 6-14 6 6 14-14-6-6 14-6-14-14 6 6-14-14-6 14-6-6-14 14 6z" fill="#f2a03a" ${st()}/><path d="M36 22l3 8 8-3-3 8 8 3-8 3 3 8-8-3-3 8-3-8-8 3 3-8-8-3 8-3-3-8 8 3z" fill="#ffe08a"/>`,
    potion: `<path d="M30 10h12v14c10 4 16 12 16 22a22 22 0 0 1-44 0c0-10 6-18 16-22z" fill="#fffaf0" ${st()}/><path d="M16 44a20 20 0 0 0 40 0c0-3-1-6-2-8-6 4-12-4-18 0s-12 4-18 0c-1 2-2 5-2 8z" fill="#6ad0a8"/><path d="M30 10h12v14c10 4 16 12 16 22a22 22 0 0 1-44 0c0-10 6-18 16-22z" fill="none" ${st()}/><rect x="28" y="6" width="16" height="6" rx="2" fill="#a87a52" ${st(1.6)}/>`,
    book: `<path d="M10 20c8-4 18-4 26 2v38c-8-6-18-6-26-2z" fill="#fbf3e0" ${st()}/><path d="M62 20c-8-4-18-4-26 2v38c8-6 18-6 26-2z" fill="#fff7e8" ${st()}/><path d="M16 30c5-2 10-2 14 0M16 38c5-2 10-2 14 0M42 30c5-2 10-2 14 0M42 38c5-2 10-2 14 0" stroke="#b89a70" stroke-width="1.6" fill="none"/>`,
    feather: `<path d="M52 10C30 16 20 36 18 60c14-6 30-20 34-50z" fill="#c8a8f0" ${st()}/><path d="M50 14C36 28 26 44 20 58" ${st(1.8)} fill="none"/>`,
    wave: `<path d="M8 42c8-14 18-14 26 0s18 14 26 0" fill="none" stroke="#4a9ad8" stroke-width="6"/><path d="M8 54c8-10 18-10 26 0s18 10 26 0" fill="none" stroke="#9ad0f0" stroke-width="5"/><path d="M8 42c8-14 18-14 26 0s18 14 26 0" fill="none" ${st(1.4)}/>`,
    disco: `<circle cx="36" cy="38" r="20" fill="#d8dce8" ${st()}/><path d="M16 38h40M20 28h32M20 48h32M36 18v40M26 20c-4 12-4 24 0 36M46 20c4 12 4 24 0 36" stroke="#8a90a8" stroke-width="1.4" fill="none"/><path d="M36 18v-8" ${st(2)}/><path d="M27 29l6-4" stroke="#fff" stroke-width="3"/>`,
    moon: `<path d="M44 12a24 24 0 1 0 16 36A20 20 0 0 1 44 12z" fill="#f6dc6a" ${st()}/>`,
    friends: `<circle cx="26" cy="26" r="9" fill="#ffe0cc" ${st()}/><circle cx="46" cy="26" r="9" fill="#ffe0cc" ${st()}/><path d="M34 52c0-7 4-12 12-12s14 6 14 18H36z" fill="#9ad0f0" ${st()}/><path d="M12 58c0-12 6-18 14-18s14 6 14 18z" fill="#f0a0b8" ${st()}/>`,
    blossom: `<g ${st(2)}>${[0, 72, 144, 216, 288].map(a => `<ellipse cx="36" cy="22" rx="9" ry="13" fill="#f6b0c8" transform="rotate(${a} 36 36)"/>`).join('')}</g><circle cx="36" cy="36" r="6" fill="#f2c13a" ${st(1.8)}/>`,
    leaf: `<path d="M36 62C34 44 40 30 36 12" fill="none" stroke="#4a8a3a" stroke-width="3.5"/><path d="M36 50c-10 0-16-6-16-12 8-2 14 2 16 12zM37 38c10-2 16-8 15-14-8 0-14 4-15 14zM36 26c-6-2-10-8-8-14 6 2 9 8 8 14z" fill="#7ac06a" ${st(2)}/>`,
    zzz: `<path d="M14 20h14L14 36h14M34 30h12L34 44h12M50 42h10L50 54h10" fill="none" stroke="#6a8ad8" stroke-width="4"/>`,
    gamepad: `<path d="M14 34c0-8 6-12 12-12h20c6 0 12 4 12 12l2 12c1 6-6 9-10 4l-4-5H26l-4 5c-4 5-11 2-10-4z" fill="#a68af0" ${st()}/><path d="M24 31v8M20 35h8" ${st(2.6)}/><circle cx="45" cy="32" r="2.6" fill="#e8504a" ${st(1.2)}/><circle cx="50" cy="37" r="2.6" fill="#6ab04a" ${st(1.2)}/>`,
    party: `<path d="M16 60l14-40 22 22z" fill="#d84a5a" ${st()}/><path d="M22 46l12-4M27 34l10-3" stroke="#f2c84a" stroke-width="3"/><circle cx="50" cy="16" r="3" fill="#f2c13a" ${st(1.2)}/><circle cx="58" cy="26" r="2.5" fill="#6ab0e8" ${st(1.2)}/><path d="M44 10l3 4M60 18l-4 2" stroke="#e8504a" stroke-width="2.4"/>`,
    save: `<path d="M14 14h38l8 8v36H14z" fill="#6a9ad8" ${st()}/><rect x="22" y="14" width="24" height="16" fill="#fffaf0" ${st(2)}/><rect x="22" y="40" width="28" height="18" fill="#fffaf0" ${st(2)}/><rect x="38" y="17" width="5" height="10" fill="${I}"/>`,
    chart: `<path d="M12 60h48" ${st()}/><rect x="16" y="38" width="10" height="22" fill="#6ab0e8" ${st(2)}/><rect x="31" y="26" width="10" height="34" fill="#f2c13a" ${st(2)}/><rect x="46" y="16" width="10" height="44" fill="#e8504a" ${st(2)}/>`,
    handshake: `<path d="M8 32l12-8 10 4 6-4 10 2 10-4 8 10-10 12-6 2-14 6-10-6-8-6z" fill="#ffd8b8" ${st()}/><path d="M30 28l-6 8c2 3 6 3 8 0l6-6M36 40l6 5M32 44l5 4M28 47l4 3" fill="none" ${st(2)}/>`,
    tree: `<path d="M36 8L18 32h8L14 48h14v14h16V48h14L46 32h8z" fill="#5aa84a" ${st()}/><path d="M32 62h8V50h-8z" fill="#8a5a34" ${st(2)}/>`,
    clover: `<g fill="#6ab04a" ${st(2)}><circle cx="28" cy="26" r="9"/><circle cx="44" cy="26" r="9"/><circle cx="28" cy="40" r="9"/><circle cx="44" cy="40" r="9"/></g><path d="M36 34c2 12 6 20 14 26" fill="none" ${st(3)}/>`,
    pig: `<ellipse cx="36" cy="40" rx="22" ry="16" fill="#f2b0c0" ${st()}/><path d="M28 26l-4-8 8 4M44 26l4-8-8 4" fill="#f2b0c0" ${st(2)}/><ellipse cx="54" cy="40" rx="5" ry="6" fill="#e890a8" ${st(2)}/><path d="M28 54v6M44 54v6" ${st(4)}/><path d="M30 28h12" ${st(2.6)}/><circle cx="44" cy="36" r="1.8" fill="${I}"/>`,
    gear: `<path d="M36 12l5 2 2 6 6 1 3 4-3 5 3 5-3 4-6 1-2 6-5 2-5-2-2-6-6-1-3-4 3-5-3-5 3-4 6-1 2-6z" fill="#b8c0c8" ${st()}/><circle cx="36" cy="37" r="7" fill="#fbf3e0" ${st()}/>`,
    bat: `<path d="M36 30c-6-8-18-12-28-6 6 2 8 8 8 12 4-4 8-2 10 2 2-2 6-2 10 0 4-2 8-2 10 0 2-4 6-6 10-2 0-4 2-10 8-12-10-6-22-2-28 6z" fill="#7a5ab0" ${st()}/><circle cx="36" cy="34" r="8" fill="#9a7ad0" ${st(2)}/><circle cx="33" cy="33" r="1.6" fill="#f2c13a"/><circle cx="39" cy="33" r="1.6" fill="#f2c13a"/>`,
    pause: `<circle cx="36" cy="36" r="24" fill="#fbf3e0" ${st()}/><path d="M29 26v20M43 26v20" ${st(5)}/>`,
    play: `<circle cx="36" cy="36" r="24" fill="#d6ecae" ${st()}/><path d="M30 24l16 12-16 12z" fill="${I}"/>`,
    ffwd: `<path d="M12 22l20 14-20 14zM34 22l20 14-20 14z" fill="#6ab04a" ${st()}/>`,
    timer: `<circle cx="36" cy="40" r="20" fill="#fffaf0" ${st()}/><path d="M36 40V28M36 40l8 6" ${st(3)}/><path d="M30 12h12M36 12v8" ${st(3)}/>`,
    hourglass: `<path d="M20 12h32M20 60h32M24 12c0 14 24 14 24 24s-24 10-24 24M48 12c0 14-24 14-24 24s24 10 24 24" fill="none" ${st()}/><path d="M28 54c4-6 12-6 16 0z" fill="#f2c13a"/><path d="M30 20h12c-2 5-10 5-12 0z" fill="#f2c13a"/>`,
    door: `<rect x="18" y="10" width="36" height="52" rx="3" fill="#a8784a" ${st()}/><rect x="24" y="16" width="24" height="18" fill="#c8945a" ${st(1.6)}/><circle cx="46" cy="40" r="2.6" fill="#f2c13a" ${st(1.2)}/>`,
    muscle: `<path d="M14 50c0-14 8-26 18-32l6 6-6 8c8-4 18-2 22 6 4 10-4 16-14 16H22c-4 0-8-1-8-4z" fill="#f2c890" ${st()}/><path d="M36 44c4-4 10-4 14 0" fill="none" ${st(1.8)}/>`,
    hammer: `<path d="M14 22l14-10 12 10-14 10z" fill="#b8c0c8" ${st()}/><path d="M32 26l26 30" ${st(7)}/><path d="M32 26l26 30" stroke="#a87a42" stroke-width="3.6"/>`,
    medal: `<path d="M24 10l12 18 12-18h-8l-4 6-4-6z" fill="#6ab0e8" ${st(2)}/><circle cx="36" cy="44" r="16" fill="#f2c13a" ${st()}/><path d="${star5(36, 44, 9, 4)}" fill="#fff3b0" ${st(1.4)}/>`,
    palette: `<path d="M36 10c-16 0-26 12-26 26s10 26 24 26c4 0 6-4 4-8s0-8 4-8h6c8 0 14-6 14-12 0-14-12-24-26-24z" fill="#f2e2bc" ${st()}/><circle cx="24" cy="30" r="4.6" fill="#e8504a" ${st(1.4)}/><circle cx="34" cy="20" r="4.6" fill="#f2c13a" ${st(1.4)}/><circle cx="46" cy="22" r="4.6" fill="#6ab04a" ${st(1.4)}/><circle cx="24" cy="44" r="4.6" fill="#6ab0e8" ${st(1.4)}/>`,
    comet: `<circle cx="48" cy="24" r="10" fill="#f2a03a" ${st()}/><path d="M40 32L12 60M38 26L18 40M46 34L32 54" stroke="#f2c84a" stroke-width="4.4"/><path d="M44 20l4-4" stroke="#fff" stroke-width="2.4"/>`,
    drop: `<path d="M36 10c10 16 18 24 18 34a18 18 0 0 1-36 0c0-10 8-18 18-34z" fill="#c8202a" ${st()}/><path d="M28 40c0-4 2-8 4-10" stroke="#fff" stroke-width="2.6" fill="none"/>`,
    ice: `<path d="M16 22l20-10 20 10v26L36 60 16 48z" fill="#bfe5f4" ${st()}/><path d="M16 22l20 10 20-10M36 32v28" fill="none" ${st(1.8)}/><path d="M22 28l6 3" stroke="#fff" stroke-width="3"/>`,
    bank: `<path d="M10 28L36 12l26 16z" fill="#d8dce8" ${st()}/><rect x="12" y="52" width="48" height="8" fill="#d8dce8" ${st(2)}/><path d="M18 30v20M30 30v20M42 30v20M54 30v20" ${st(5)}/><path d="M18 30v20M30 30v20M42 30v20M54 30v20" stroke="#fffaf0" stroke-width="2.2"/>`,
    cat: `<path d="M18 30l-2-16 12 8h16l12-8-2 16c4 6 4 14 0 20-6 8-30 8-36 0-4-6-4-14 0-20z" fill="#4a4658" ${st()}/><ellipse cx="28" cy="38" rx="4" ry="5" fill="#c8ff6a" ${st(1.2)}/><ellipse cx="44" cy="38" rx="4" ry="5" fill="#c8ff6a" ${st(1.2)}/><path d="M34 46h4l-2 3z" fill="#f0a0b8"/>`,
    mushroom: `<path d="M10 34c0-14 12-22 26-22s26 8 26 22z" fill="#e8504a" ${st()}/><path d="M28 34h16v20c0 4-16 4-16 0z" fill="#f6ecd8" ${st()}/><circle cx="24" cy="24" r="3.6" fill="#fff"/><circle cx="40" cy="20" r="3" fill="#fff"/><circle cx="50" cy="28" r="3" fill="#fff"/>`,
    music: `<path d="M24 52V20l28-6v32" fill="none" ${st(3.4)}/><ellipse cx="18" cy="52" rx="8" ry="6" fill="#f28ab4" ${st()}/><ellipse cx="46" cy="46" rx="8" ry="6" fill="#f28ab4" ${st()}/>`,
    sun: `<circle cx="36" cy="36" r="13" fill="#f6dc6a" ${st()}/><path d="M36 8v10M36 54v10M8 36h10M54 36h10M16 16l7 7M49 49l7 7M56 16l-7 7M23 49l-7 7" stroke="#e0a020" stroke-width="4"/>`,
    bulb: `<path d="M36 10a17 17 0 0 0-10 31c2 2 3 4 3 7h14c0-3 1-5 3-7a17 17 0 0 0-10-31z" fill="#f6dc6a" ${st()}/><path d="M29 52h14M30 58h12" ${st(3)}/><path d="M28 24c2-4 5-6 9-6" stroke="#fff" stroke-width="2.6" fill="none"/>`,
    snowman: `<circle cx="36" cy="46" r="15" fill="#fff" ${st()}/><circle cx="36" cy="22" r="10" fill="#fff" ${st()}/><path d="M36 22l9 3-9 1z" fill="#f2a03a" ${st(1.2)}/><circle cx="33" cy="19" r="1.6" fill="${I}"/><circle cx="36" cy="42" r="2" fill="${I}"/><circle cx="36" cy="50" r="2" fill="${I}"/><path d="M27 31h18" stroke="#e8504a" stroke-width="4"/>`,
    cookie: `<circle cx="36" cy="36" r="24" fill="#d8a46a" ${st()}/><circle cx="28" cy="28" r="3.6" fill="#5a3420"/><circle cx="44" cy="30" r="3" fill="#5a3420"/><circle cx="34" cy="44" r="3.4" fill="#5a3420"/><circle cx="46" cy="46" r="2.6" fill="#5a3420"/>`,
    tv: `<rect x="10" y="20" width="52" height="36" rx="6" fill="#a68af0" ${st()}/><rect x="16" y="26" width="34" height="24" rx="3" fill="#cfe8f6" ${st(2)}/><path d="M28 10l8 10 8-10" fill="none" ${st(2.2)}/><circle cx="56" cy="32" r="2.4" fill="${I}"/><circle cx="56" cy="42" r="2.4" fill="${I}"/>`,
    speech: `<path d="M12 18h48v30H32l-12 10v-10h-8z" fill="#fffaf0" ${st()}/><circle cx="26" cy="33" r="2.6" fill="${I}"/><circle cx="36" cy="33" r="2.6" fill="${I}"/><circle cx="46" cy="33" r="2.6" fill="${I}"/>`,
    mic: `<rect x="28" y="10" width="16" height="30" rx="8" fill="#b8c0c8" ${st()}/><path d="M20 32a16 16 0 0 0 32 0M36 48v12M28 60h16" fill="none" ${st(2.6)}/>`,
    masks: `<path d="M10 18c10 4 20 4 28 0v18c0 10-6 16-14 16S10 46 10 36z" fill="#fffaf0" ${st()}/><path d="M34 26c10 4 20 4 28 0v18c0 10-6 16-14 16s-14-6-14-16z" fill="#f2c13a" ${st()}/><path d="M16 30h6M27 30h6M41 38h6M51 38h6" ${st(2.4)}/><path d="M18 40c3 3 9 3 12 0M42 52c3-3 9-3 12 0" fill="none" ${st(2)}/>`,
    backpack: `<path d="M18 30c0-10 8-16 18-16s18 6 18 16v28c0 3-2 4-4 4H22c-2 0-4-1-4-4z" fill="#e8784a" ${st()}/><rect x="24" y="38" width="24" height="14" rx="3" fill="#f2a06a" ${st(2)}/><path d="M28 14c0-6 16-6 16 0" fill="none" ${st(2.4)}/>`,
    dice: `<rect x="14" y="14" width="44" height="44" rx="9" fill="#fffaf0" ${st()}/><circle cx="26" cy="26" r="3.6" fill="#e8504a"/><circle cx="36" cy="36" r="3.6" fill="#e8504a"/><circle cx="46" cy="46" r="3.6" fill="#e8504a"/>`,
    shell: `<path d="M36 60L12 30c6-14 42-14 48 0z" fill="#f6c8b0" ${st()}/><path d="M36 60L22 22M36 60V18M36 60l14-38" fill="none" stroke="#d8906a" stroke-width="2"/><path d="M28 60h16" ${st(3)}/>`,
    question: `<circle cx="36" cy="36" r="24" fill="#fbf3e0" ${st()}/><path d="M28 28a8 8 0 1 1 12 7c-3 2-4 4-4 7" fill="none" ${st(4)}/><circle cx="36" cy="50" r="2.8" fill="${I}"/>`,
    phone: `<rect x="22" y="8" width="28" height="56" rx="6" fill="#4a4658" ${st()}/><rect x="26" y="16" width="20" height="36" rx="2" fill="#cfe8f6"/><circle cx="36" cy="58" r="2.4" fill="#fffaf0"/>`,
    clipboard: `<rect x="16" y="14" width="40" height="48" rx="4" fill="#d8a46a" ${st()}/><rect x="22" y="20" width="28" height="36" fill="#fffaf0" ${st(1.6)}/><rect x="28" y="10" width="16" height="8" rx="2" fill="#b8c0c8" ${st(2)}/><path d="M27 30h18M27 38h18M27 46h12" ${st(1.8)}/>`,
    cross: `<path d="M18 18l36 36M54 18L18 54" ${st(10)}/><path d="M18 18l36 36M54 18L18 54" stroke="#e8504a" stroke-width="5.6"/>`,
    bow: `<path d="M36 36L14 24c-4 0-6 4-6 12s2 12 6 12zM36 36l22-12c4 0 6 4 6 12s-2 12-6 12z" fill="#f28ab4" ${st()}/><path d="M32 38l-6 20 6-4 2 6 2-20" fill="#f28ab4" ${st(2)}/><circle cx="36" cy="36" r="6" fill="#e86a9a" ${st()}/>`,
    infinity: `<path d="M36 36c-6-8-10-12-16-12a12 12 0 0 0 0 24c6 0 10-4 16-12s10-12 16-12a12 12 0 0 1 0 24c-6 0-10-4-16-12z" fill="none" stroke="#a68af0" stroke-width="6"/><path d="M36 36c-6-8-10-12-16-12a12 12 0 0 0 0 24c6 0 10-4 16-12s10-12 16-12a12 12 0 0 1 0 24c-6 0-10-4-16-12z" fill="none" ${st(1.4)}/>`,
    bell: `<path d="M36 10c-12 0-18 10-18 22v10l-6 8h48l-6-8V32c0-12-6-22-18-22z" fill="#f2c13a" ${st()}/><circle cx="36" cy="56" r="5" fill="#e0a020" ${st(2)}/><path d="M28 24c2-4 5-6 8-6" stroke="#fff" stroke-width="2.6" fill="none"/>`,
    warning: `<path d="M36 10l28 50H8z" fill="#f6dc6a" ${st()}/><path d="M36 28v16" ${st(5)}/><circle cx="36" cy="52" r="3" fill="${I}"/>`,
    bomb: `<circle cx="32" cy="42" r="20" fill="#4a4658" ${st()}/><path d="M44 26l6-6" ${st(5)}/><path d="M50 20c4-4 8-2 10-6" fill="none" stroke="#a87a42" stroke-width="2.4"/><path d="M60 8l2 4 4 1-4 2-1 4-2-4-4-1 4-2z" fill="#f2a03a"/><path d="M22 36c2-5 6-8 10-8" stroke="#fff" stroke-width="3" fill="none" opacity=".7"/>`,
    bandage: `<rect x="8" y="26" width="56" height="20" rx="10" fill="#f2c890" ${st()} transform="rotate(-30 36 36)"/><rect x="26" y="28" width="20" height="16" fill="#fbe4c0" ${st(1.6)} transform="rotate(-30 36 36)"/>`,
    up: `<path d="M36 10L14 34h14v28h16V34h14z" fill="#6ab04a" ${st()}/>`,
    down: `<path d="M36 62L14 38h14V10h16v28h14z" fill="#e8784a" ${st()}/>`,
    pencil: `<path d="M14 58l4-14 32-32 10 10-32 32z" fill="#f2c13a" ${st()}/><path d="M18 44l10 10M44 18l10 10" ${st(2)}/><path d="M14 58l4-14 10 10z" fill="#f2d8b0" ${st(1.6)}/>`,
    picture: `<rect x="10" y="14" width="52" height="44" rx="3" fill="#c8945a" ${st()}/><rect x="16" y="20" width="40" height="32" fill="#cfe8f6" ${st(1.6)}/><path d="M16 52l14-16 10 10 6-6 10 12z" fill="#6ab04a" ${st(1.6)}/><circle cx="46" cy="28" r="4" fill="#f6dc6a"/>`,
    rod: `<path d="M12 60L52 12" ${st(5)}/><path d="M12 60L52 12" stroke="#a87a42" stroke-width="2.4"/><path d="M52 12c6 10 6 24 2 36" fill="none" stroke="#7a7a8a" stroke-width="1.6"/><path d="M54 48c-3 0-4 4-2 6s5 0 4-3" fill="none" ${st(2)}/>`,
    sofa: `<rect x="14" y="22" width="44" height="18" rx="6" fill="#a68af0" ${st()}/><rect x="8" y="34" width="56" height="18" rx="6" fill="#b8a0f4" ${st()}/><path d="M14 52v6M58 52v6" ${st(4)}/>`,
    heartg: `<path d="M36 60C11 43 13 21 26 19c6-1 9 3 10 7 1-4 4-8 10-7 13 2 15 24-10 41z" fill="#6ab04a" ${st()}/><path d="M23 28c1-3 4-5 7-4" stroke="#fff" stroke-width="2.6" fill="none"/>`,
    heartv: `<path d="M36 60C11 43 13 21 26 19c6-1 9 3 10 7 1-4 4-8 10-7 13 2 15 24-10 41z" fill="#a68af0" ${st()}/><path d="M23 28c1-3 4-5 7-4" stroke="#fff" stroke-width="2.6" fill="none"/>`,
    heartk: `<path d="M36 60C11 43 13 21 26 19c6-1 9 3 10 7 1-4 4-8 10-7 13 2 15 24-10 41z" fill="#4a4658" ${st()}/><path d="M23 28c1-3 4-5 7-4" stroke="#aaa" stroke-width="2.6" fill="none"/>`,
    unlock: `<path d="M24 32v-8a12 12 0 0 1 23-5" fill="none" ${st(4)}/><path d="M24 32v-8a12 12 0 0 1 23-5" fill="none" stroke="#b8c0c8" stroke-width="2"/><rect x="16" y="31" width="40" height="28" rx="5" fill="#f2c13a" ${st()}/><path d="M36 40v8" ${st(3.4)}/>`,
    water: `<path d="M36 10c10 16 18 24 18 34a18 18 0 0 1-36 0c0-10 8-18 18-34z" fill="#6ab0e8" ${st()}/><path d="M28 40c0-4 2-8 4-10" stroke="#fff" stroke-width="2.6" fill="none"/>`,
    autumn: `<path d="M36 62V40M36 40L18 30l6-4-8-10 12 2 4-10 4 10 4-10 4 10 12-2-8 10 6 4z" fill="#e8784a" ${st()}/>`,
    dotg: `<circle cx="36" cy="36" r="20" fill="#6ab04a" ${st()}/>`,
    dotr: `<circle cx="36" cy="36" r="20" fill="#e8504a" ${st()}/>`,
    eye: `<path d="M8 36c14-18 42-18 56 0-14 18-42 18-56 0z" fill="#fffaf0" ${st()}/><circle cx="36" cy="36" r="10" fill="#6ab0e8" ${st(2)}/><circle cx="36" cy="36" r="4.6" fill="${I}"/>`,
  };
  // эмодзи → иконка (с вариантами без/с U+FE0F)
  const MAP = {
    '🪙': 'coin', '💎': 'gem', '❤️': 'heart', '❤': 'heart', '💗': 'heartp', '💖': 'heartp', '💕': 'heartp', '💞': 'heartp', '💔': 'heartb', '⭐': 'star', '🌟': 'star', '★': 'star',
    '✨': 'sparkle', '✦': 'sparkle', '🌠': 'shoot', '💫': 'dizzy', '🔥': 'fire', '🔒': 'lock', '🐾': 'paw', '⚔️': 'swords', '⚔': 'swords', '👑': 'crown',
    '🛡️': 'shield', '🛡': 'shield', '❄️': 'snow', '❄': 'snow', '🔄': 'refresh', '📦': 'box', '🏆': 'trophy', '🗺️': 'map', '🗺': 'map', '✓': 'check', '✅': 'check',
    '🎯': 'target', '🕳️': 'hole', '🕳': 'hole', '🏠': 'house', '🌀': 'swirl', '⚡': 'bolt', '🪞': 'mirror', '💀': 'skull', '☠️': 'skull', '☠': 'skull', '🌈': 'rainbow',
    '🔑': 'key', '🗝️': 'key', '🗝': 'key', '🎁': 'gift', '🔎': 'magnifier', '🔍': 'magnifier', '🎵': 'note', '🎶': 'music', '📅': 'calendar', '🗓️': 'calendar', '📜': 'scroll', '🫧': 'bubbles',
    '🕊️': 'dove', '🕊': 'dove', '⛩': 'gate', '⛩️': 'gate', '🦐': 'shrimp', '🐟': 'fish', '🐠': 'fish', '💰': 'moneybag', '💨': 'wind', '🌬️': 'wind', '🌬': 'wind', '🧭': 'compass', '💥': 'boom',
    '🧪': 'potion', '📖': 'book', '📚': 'book', '🪶': 'feather', '🌊': 'wave', '🪩': 'disco', '🌙': 'moon', '👥': 'friends', '👭': 'friends', '🌸': 'blossom', '🌿': 'leaf',
    '💤': 'zzz', '🎮': 'gamepad', '🕹️': 'gamepad', '🎉': 'party', '🎊': 'party', '💾': 'save', '📊': 'chart', '🤝': 'handshake', '🌲': 'tree', '🌳': 'tree', '🍀': 'clover', '🐷': 'pig',
    '⚙️': 'gear', '⚙': 'gear', '🦇': 'bat', '⏸': 'pause', '⏸️': 'pause', '▶': 'play', '▶️': 'play', '⏩': 'ffwd', '⏱': 'timer', '⏱️': 'timer', '⏳': 'hourglass', '⌛': 'hourglass',
    '🚪': 'door', '💪': 'muscle', '🔨': 'hammer', '🏅': 'medal', '🎨': 'palette', '☄️': 'comet', '☄': 'comet', '🩸': 'drop', '🧊': 'ice', '🏦': 'bank', '🐱': 'cat', '🐈': 'cat',
    '💡': 'bulb', '⛄': 'snowman', '☃️': 'snowman', '🍪': 'cookie', '📺': 'tv', '💬': 'speech', '🗨️': 'speech', '🎤': 'mic', '🎭': 'masks', '🎒': 'backpack', '🎲': 'dice', '🐚': 'shell',
    '❔': 'question', '❓': 'question', '📱': 'phone', '📲': 'phone', '📋': 'clipboard', '✖': 'cross', '✖️': 'cross', '❌': 'cross', '🎀': 'bow', '♾️': 'infinity', '♾': 'infinity', '🔔': 'bell',
    '⚠️': 'warning', '⚠': 'warning', '💣': 'bomb', '🩹': 'bandage', '⬆️': 'up', '⬆': 'up', '⬇️': 'down', '⬇': 'down', '✏️': 'pencil', '✏': 'pencil', '🖼️': 'picture', '🖼': 'picture',
    '🎣': 'rod', '🛋️': 'sofa', '🛋': 'sofa', '💚': 'heartg', '💜': 'heartv', '🖤': 'heartk', '♥': 'heart', '🔓': 'unlock', '🔐': 'lock', '💧': 'water', '🍂': 'autumn', '🍁': 'autumn',
    '🟢': 'dotg', '🔴': 'dotr', '🌼': 'blossom', '🌹': 'blossom', '👣': 'paw', '🗡️': 'swords', '🗡': 'swords', '🕵️': 'magnifier', '🕵': 'magnifier',
    '🍄': 'mushroom', '☀️': 'sun', '☀': 'sun', '👁️': 'eye', '👁': 'eye', '👀': 'eye',
  };
  const src = name => 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 72 72" stroke-linejoin="round" stroke-linecap="round">${S[name]}</svg>`);
  const SRC = {}, IMG = {}; let loaded = 0; const total = Object.keys(S).length;
  const listeners = [];
  for (const k in S) { SRC[k] = src(k); const im = new Image(); im.onload = () => { if (++loaded === total) listeners.forEach(f => { try { f(); } catch (e) {} }); }; im.src = SRC[k]; IMG[k] = im; }
  // ключи словаря, длинные – раньше (чтобы «❤️» не распадалось на «❤» + селектор)
  const keys = Object.keys(MAP).sort((a, b) => b.length - a.length);
  const RE = new RegExp('(' + keys.map(k => k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|') + ')', 'g');
  const QUICK = /[⌀-⯿☀-➿\uD83C-\uD83E]/;
  return { S, MAP, SRC, IMG, RE, QUICK, ready: () => loaded === total, onReady: f => { if (loaded === total) f(); else listeners.push(f); }, has: ch => !!MAP[ch] };
})();
let ICONS_ON = true; // игра выключает, если книжный стиль отключён

// ---------- холст: эмодзи из словаря рисуются иконками ----------
(() => {
  const P = CanvasRenderingContext2D.prototype, fill0 = P.fillText, stroke0 = P.strokeText, measure0 = P.measureText;
  const fontPx = c => { const m = /(\d+(?:\.\d+)?)px/.exec(c.font); return m ? +m[1] : 10; };
  const split = t => { ICON.RE.lastIndex = 0; return t.split(ICON.RE); };
  function draw(c, t, x, y, mw, stroke) {
    const parts = split(String(t)), sz = fontPx(c), iw = sz * 1.08;
    let total = 0; const ws = parts.map(p => { const w = ICON.MAP[p] ? iw : p ? measure0.call(c, p).width : 0; total += w; return w; });
    const al = c.textAlign; let x0 = al === 'center' ? x - total / 2 : al === 'right' || al === 'end' ? x - total : x;
    const bl = c.textBaseline, top = bl === 'middle' ? y - iw / 2 : bl === 'top' || bl === 'hanging' ? y : bl === 'bottom' || bl === 'ideographic' ? y - iw : y - iw * 0.82;
    c.textAlign = 'left';
    try {
      parts.forEach((p, i) => {
        if (!p) return;
        const nm = ICON.MAP[p];
        if (nm) { if (!stroke) { const im = ICON.IMG[nm]; if (im.complete && im.naturalWidth) c.drawImage(im, x0, top, iw, iw); else fill0.call(c, p, x0, y); } }
        else if (stroke) stroke0.call(c, p, x0, y); else fill0.call(c, p, x0, y);
        x0 += ws[i];
      });
    } finally { c.textAlign = al; }
  }
  P.fillText = function (t, x, y, mw) { if (!ICONS_ON || typeof t !== 'string' || !ICON.QUICK.test(t) || !ICON.ready()) return mw === undefined ? fill0.call(this, t, x, y) : fill0.call(this, t, x, y, mw); ICON.RE.lastIndex = 0; if (!ICON.RE.test(t)) return mw === undefined ? fill0.call(this, t, x, y) : fill0.call(this, t, x, y, mw); draw(this, t, x, y, mw, false); };
  P.strokeText = function (t, x, y, mw) { if (!ICONS_ON || typeof t !== 'string' || !ICON.QUICK.test(t) || !ICON.ready()) return mw === undefined ? stroke0.call(this, t, x, y) : stroke0.call(this, t, x, y, mw); ICON.RE.lastIndex = 0; if (!ICON.RE.test(t)) return mw === undefined ? stroke0.call(this, t, x, y) : stroke0.call(this, t, x, y, mw); draw(this, t, x, y, mw, true); };
})();

// ---------- текст интерфейса: эмодзи из словаря → картинки ----------
const iconize = (() => {
  const SKIP = new Set(['SCRIPT', 'STYLE', 'TEXTAREA', 'INPUT', 'CANVAS', 'svg', 'OPTION', 'PRE']);
  function textNode(n) {
    const t = n.nodeValue; if (!t || !ICON.QUICK.test(t)) return;
    ICON.RE.lastIndex = 0; if (!ICON.RE.test(t)) return;
    const p = n.parentNode; if (!p || SKIP.has(p.nodeName) || (p.classList && p.classList.contains('emoi')) || (p.closest && p.closest('[data-noicon],pre,textarea'))) return;
    ICON.RE.lastIndex = 0; const parts = t.split(ICON.RE), fr = document.createDocumentFragment();
    for (const s of parts) {
      if (!s) continue;
      const nm = ICON.MAP[s];
      if (nm) { const im = document.createElement('span'); im.className = 'emoi'; im.style.backgroundImage = 'url("' + ICON.SRC[nm] + '")'; im.textContent = s; fr.appendChild(im); }
      else fr.appendChild(document.createTextNode(s));
    }
    p.replaceChild(fr, n);
  }
  function walk(root) {
    if (!ICONS_ON || !root) return;
    if (root.nodeType === 3) { textNode(root); return; }
    if (root.nodeType !== 1 || SKIP.has(root.nodeName)) return;
    const tw = document.createTreeWalker(root, NodeFilter.SHOW_TEXT), list = [];
    while (tw.nextNode()) list.push(tw.currentNode);
    for (const n of list) textNode(n);
  }
  function start() {
    walk(document.body);
    new MutationObserver(ms => { if (!ICONS_ON) return; for (const m of ms) { if (m.type === 'characterData') textNode(m.target); else for (const n of m.addedNodes) walk(n); } })
      .observe(document.body, { childList: true, subtree: true, characterData: true });
  }
  if (document.body) start(); else document.addEventListener('DOMContentLoaded', start);
  return walk;
})();
