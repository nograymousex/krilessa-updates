'use strict';

// Coordinates are tile centres. These plans describe the playable ground, crossings and encounters.
// Saved runs without a plan revision keep the original seeded generator.
const Landscapes = (() => {
  const OUT = 0,
    LAND = 1,
    RIVER = 2,
    LAKE = 3,
    BRIDGE = 4,
    BREAK = 5,
    HULL = 6;
  const upperBank = [
    [65, 65],
    [55, 53],
    [39, 45],
    [38, 32],
    [56, 22],
    [72, 28],
    [92, 28],
    [110, 37],
  ];
  const lowerBank = [
    [65, 65],
    [55, 79],
    [64, 89],
    [76, 88],
    [93, 88],
    [111, 88],
    [128, 77],
    [131, 58],
    [110, 37],
  ];
  const kitchen = [
    [41, 84],
    [60, 81],
    [60, 56],
    [40, 56],
    [40, 40],
    [43, 33],
    [43, 23],
  ];
  const hall = [
    [40, 56],
    [62, 56],
    [82, 56],
    [104, 53],
    [122, 62],
    [122, 81],
    [133, 85],
  ];
  const warmTrail = [
    [66, 96],
    [58, 77],
    [40, 68],
    [35, 52],
    [50, 40],
    [69, 39],
    [80, 45],
    [94, 43],
    [106, 51],
    [112, 62],
  ];
  const lakeTrail = [
    [66, 96],
    [78, 88],
    [89, 81],
    [100, 72],
    [112, 62],
  ];
  const reef = [
    [82, 105],
    [56, 99],
    [35, 84],
    [32, 65],
    [47, 47],
    [71, 35],
    [95, 35],
    [108, 36],
    [125, 49],
    [134, 66],
    [125, 87],
    [105, 101],
    [82, 105],
  ];
  const pearlCreek = [
    [134, 66],
    [147, 69],
    [154, 79],
    [147, 87],
    [125, 87],
  ];

  const plans = {
    1: {
      name: 'Долина двух бродов',
      size: [151, 110],
      start: [65, 65],
      castle: [109, 65, 10, 'west', 3],
      cage: [109, 60],
      bosses: [
        [38, 32],
        [64, 89],
        [110, 37],
        [110, 66],
      ],
      seeds: [
        [0, 44, 35],
        [0, 60, 58],
        [0, 62, 68],
        [1, 65, 88],
        [1, 110, 90],
        [2, 109, 36],
        [2, 81, 25],
        [3, 110, 65],
        [3, 132, 66],
      ],
      paths: [
        upperBank,
        lowerBank,
        [
          [110, 37],
          [98, 41],
          [92, 49],
          [94, 59],
          [96, 65],
        ],
        [
          [65, 65],
          [77, 65],
        ],
        [
          [89, 65],
          [96, 65],
        ],
      ],
      radius: 11,
      pockets: [
        [40, 41, 26, 24],
        [63, 82, 22, 21],
        [108, 35, 29, 19],
        [120, 77, 24, 22],
      ],
      crossings: [28, 88, 65],
      labels: [
        ['Грибная роща', 37, 19],
        ['Жабья топь', 62, 100],
        ['Перевал Йети', 113, 25],
        ['Старый мост', 78, 59],
      ],
      marks: [
        ['bridge', 82, 28],
        ['bridge', 82, 88],
        ['broken', 82, 65],
        ['summit', 111, 30],
      ],
    },
    2: {
      name: 'Три уступа Цитадели', size: [180,126], start: [26,94],
      castle: [112,63,12,'west',8], cage: [116,60],
      bosses: [[52,94],[81,54],[122,28],[143,87],[112,63]],
      seeds: [[4,27,90],[5,55,96],[5,74,88],[4,80,53],[4,53,57],[6,118,29],[6,151,44],[7,144,84],[7,109,102],[8,112,63]],
      paths: [
        [[26,94],[42,99],[52,94],[72,92],[90,99],[112,100],[132,96],[143,87]],
        [[48,96],[41,83],[48,70],[65,61],[81,54],[94,42],[108,33],[122,28]],
        [[122,28],[147,36],[154,52],[151,72],[143,87]],
        [[72,92],[82,79],[89,68],[97,63]]
      ], radius: 9, pockets: [[47,92,25,16],[78,54,20,15],[121,31,24,17],[139,87,20,16]],
      labels: [['Янтарный карьер',50,105],['Пчелиный уступ',78,47],['Горн голема',121,19],['Паучьи террасы',143,98]],
      marks: [['kiln',119,33],['pylon',83,58],['pylon',92,69]]
    },
    3: {
      name: 'Осколки Зазеркалья', size: [180,136], start: [31,101],
      castle: [87,73,12,'east',13], cage: [84,68],
      bosses: [[57,102],[44,60],[95,28],[139,71],[87,73]],
      seeds: [[9,31,100],[9,59,102],[10,44,60],[10,47,83],[11,95,28],[11,72,39],[12,139,71],[12,141,102],[13,87,73]],
      paths: [
        [[31,101],[44,110],[57,102],[69,113],[94,113],[115,101],[128,88],[139,71]],
        [[44,110],[29,87],[35,69],[44,60],[57,51],[67,39],[82,31],[95,28]],
        [[95,28],[113,35],[125,44],[140,50],[149,59],[139,71]],
        [[128,88],[116,85],[107,75],[102,73]]
      ], radius: 8, pockets: [[56,101,22,15],[43,62,18,21],[95,29,26,14],[140,74,21,19]],
      labels: [['Лес помех',54,111],['Сахарная коса',43,52],['Облачная дуга',95,20],['Свалка машин',143,81]],
      marks: [['facet',113,36],['facet',67,103],['facet',139,59]]
    },
    5: {
      name: 'Двор за оранжереей', size: [166,119], start: [34,84],
      castle: [110,53,10,'south',25], cage: [110,49],
      bosses: [[50,83],[63,46],[100,30],[129,79],[110,53]],
      seeds: [[20,38,84],[20,54,81],[22,30,56],[21,63,46],[21,69,34],[23,100,30],[23,123,33],[24,130,79],[24,104,89],[25,110,53]],
      paths: [
        [[34,84],[50,83],[67,89],[81,85],[99,83],[115,84],[129,79]],
        [[34,84],[27,72],[30,57],[43,51],[63,46],[79,45],[87,35],[100,30],[118,28]],
        [[118,28],[135,36],[144,49],[139,65],[129,79]],
        [[81,85],[79,66],[79,45]], [[99,83],[107,73],[110,66]]
      ], radius: 8, pockets: [[46,82,24,15],[40,54,22,16],[65,45,17,17],[102,30,24,13],[127,79,22,16]],
      labels: [['Кухонное крыльцо',46,92],['Гостиная',60,39],['Оранжерея',98,22],['Голубиный двор',129,89]],
      marks: [['stove',47,79],['glasshouse',95,28],['sofa',61,50]]
    },
    4: {
      name: 'Квартира Тессы',
      size: [162, 111],
      start: [41, 84],
      castle: [92, 19, 10, 'south', 19],
      cage: [92, 14],
      bosses: [
        [62, 56],
        [43, 23],
        [104, 53],
        [133, 85],
        [92, 19],
      ],
      seeds: [
        [14, 41, 82],
        [15, 56, 56],
        [16, 41, 24],
        [17, 104, 50],
        [18, 132, 85],
        [19, 92, 19],
      ],
      rooms: [
        [20, 72, 65, 97],
        [17, 40, 54, 67],
        [23, 10, 65, 33],
        [80, 37, 128, 70],
        [110, 75, 150, 99],
        [82, 9, 102, 29],
      ],
      halls: [
        [56, 54, 65, 85],
        [41, 52, 115, 60],
        [38, 27, 46, 44],
        [118, 65, 126, 81],
        [88, 27, 96, 43],
      ],
      paths: [
        kitchen,
        hall,
        [
          [104, 53],
          [92, 45],
          [92, 32],
        ],
      ],
      tunnel: [
        [54, 80],
        [86, 66],
      ],
      labels: [
        ['Прихожая', 38, 89],
        ['Кухня', 33, 48],
        ['Музыкальная', 44, 16],
        ['Гостиная', 105, 43],
        ['Зазеркалье', 132, 91],
      ],
      marks: [
        ['stove', 32, 52],
        ['sofa', 54, 80],
        ['sofa', 86, 66],
        ['rug', 104, 53],
        ['rug', 43, 23],
      ],
    },
    6: {
      name: 'Волчий перевал',
      size: [174, 134],
      start: [34, 111],
      castle: [140, 22, 11, 'south', 32],
      cage: [140, 16],
      bosses: [
        [54, 101],
        [69, 39],
        [117, 64],
        [147, 90],
        [140, 22],
      ],
      seeds: [
        [27, 42, 107],
        [27, 68, 100],
        [29, 43, 69],
        [29, 51, 53],
        [28, 70, 39],
        [28, 88, 81],
        [33, 85, 35],
        [30, 117, 64],
        [31, 146, 90],
        [31, 150, 64],
        [32, 140, 22],
      ],
      paths: [
        [
          [34, 111],
          [43, 108],
          [54, 101],
          [66, 96],
        ],
        warmTrail,
        lakeTrail,
        [
          [112, 62],
          [117, 64],
          [133, 74],
          [147, 90],
        ],
        [
          [117, 64],
          [128, 55],
          [137, 46],
          [140, 36],
        ],
      ],
      radius: 12,
      pockets: [
        [44, 101, 25, 20],
        [40, 61, 28, 21],
        [73, 39, 25, 20],
        [114, 63, 23, 18],
        [144, 87, 22, 24],
      ],
      lake: [90, 80, 24, 10, -0.59],
      fires: [
        [57, 79],
        [40, 65],
        [40, 47],
        [58, 39],
        [83, 44],
        [101, 48],
        [50, 105],
        [62, 92],
        [31, 54],
        [65, 36],
        [75, 40],
        [91, 43],
        [112, 58],
        [128, 76],
        [149, 94],
        [134, 50],
      ],
      holes: [
        [70, 42],
        [63, 37],
        [87, 79],
        [98, 77],
        [81, 88],
      ],
      glades: [
        [22, 106, 27],
        [67, 22, 28],
        [146, 108, 31],
        [109, 92, 28],
      ],
      gladePaths: [
        [
          [38, 108],
          [22, 106],
        ],
        [
          [69, 39],
          [67, 22],
        ],
        [
          [147, 90],
          [146, 108],
        ],
        [
          [98, 74],
          [109, 92],
        ],
      ],
      tracks: [
        [103, 57],
        [108, 60],
        [114, 63],
        [121, 66],
      ],
      labels: [
        ['Застава', 41, 117],
        ['Тропа костров', 42, 58],
        ['Звонкий лёд', 89, 85],
        ['Седловина', 117, 56],
        ['Логово дракона', 145, 99],
      ],
      marks: [
        ['summit', 117, 54],
        ['summit', 69, 29],
      ],
    },
    8: BELFRY_MAP,
    9: HARBOUR_MAP,
    7: {
      name: 'Кольцо рифа',
      size: [174, 135],
      start: [80, 116],
      castle: [82, 64, 10, 'south', B7 + 5],
      cage: [82, 60],
      bosses: [
        [55, 98],
        [47, 47],
        [100, 35],
        [119, 85],
        [82, 64],
      ],
      seeds: [
        [B7, 65, 106],
        [B7, 80, 116],
        [B7 + 1, 31, 76],
        [B7 + 1, 146, 77],
        [B7 + 3, 47, 46],
        [B7 + 2, 98, 36],
        [B7 + 4, 119, 85],
        [B7 + 5, 82, 64],
      ],
      paths: [
        reef,
        [
          [80, 116],
          [82, 105],
          [82, 91],
          [82, 77],
        ],
        pearlCreek,
        [
          [125, 87],
          [119, 85],
          [114, 84],
        ],
      ],
      radius: 10,
      pockets: [
        [51, 98, 25, 19],
        [47, 48, 22, 17],
        [96, 36, 27, 15],
        [121, 85, 18, 17],
      ],
      currents: reef.slice(1).map((p, i) => [reef[i], p]),
      pearls: [
        [73, 114],
        [52, 107],
        [39, 91],
        [26, 72],
        [44, 58],
        [51, 39],
        [73, 28],
        [92, 41],
        [119, 45],
        [131, 74],
        [151, 81],
        [105, 99],
      ],
      lure: [114, 84],
      labels: [
        ['Сад медуз', 47, 37],
        ['Остов «Ласточки»', 99, 25],
        ['Жемчужный рукав', 147, 93],
        ['Зев бездны', 81, 81],
      ],
      marks: [['wreck', 97, 35]],
    },
  };

  function create(chapter, revision) {
    if (chapter === 8) revision = Belfry.revision;
    const plan = (revision === 1 || (chapter === 8 && revision === Belfry.revision)) && plans[chapter];
    if (!plan) return null;
    const [w, h] = plan.size,
      mask = new Uint8Array(w * h);
    const paint = (x0, y0, x1, y1, kind, test) => {
      for (let y = Math.max(2, Math.floor(y0)); y <= Math.min(h - 3, Math.ceil(y1)); y++)
        for (let x = Math.max(2, Math.floor(x0)); x <= Math.min(w - 3, Math.ceil(x1)); x++)
          if (!test || test(x, y)) mask[y * w + x] = kind;
    };
    const rect = (area, kind) => paint(...area, kind);
    const oval = (cx, cy, rx, ry, angle = 0, kind = LAND) => {
      const r = Math.max(rx, ry),
        c = Math.cos(angle),
        s = Math.sin(angle);
      paint(cx - r, cy - r, cx + r, cy + r, kind, (x, y) => {
        const dx = x - cx,
          dy = y - cy;
        return ((dx * c + dy * s) / rx) ** 2 + ((dy * c - dx * s) / ry) ** 2 <= 1;
      });
    };
    function stroke(path, r, kind) {
      for (let i = 1; i < path.length; i++) {
        const [x, y] = path[i - 1],
          [ex, ey] = path[i],
          dx = ex - x,
          dy = ey - y;
        paint(
          Math.min(x, ex) - r,
          Math.min(y, ey) - r,
          Math.max(x, ex) + r,
          Math.max(y, ey) + r,
          kind,
          (tx, ty) => {
            const u = clamp(((tx - x) * dx + (ty - y) * dy) / (dx * dx + dy * dy), 0, 1);
            return (tx - x - dx * u) ** 2 + (ty - y - dy * u) ** 2 <= r * r;
          }
        );
      }
    }
    if (plan.rooms) {
      for (const area of plan.rooms.concat(plan.halls)) rect(area, LAND);
    } else {
      for (const path of plan.paths) stroke(path, plan.radius, LAND);
      for (const p of plan.pockets) oval(...p);
    }
    const [cx, cy, half, gate, biome] = plan.castle;
    if (chapter === 8) oval(cx,cy,half+3,half+3);
    else rect([cx - half - 3, cy - half - 3, cx + half + 3, cy + half + 3], LAND);
    if (plan.crossings) {
      stroke(
        [
          [80, 0],
          [82, 28],
          [77, 45],
          [82, 65],
          [82, 88],
          [87, h],
        ],
        4.6,
        RIVER
      );
      for (const y of plan.crossings) {
        rect([75, y - 1, 89, y + 1], BRIDGE);
        if (y === 65) rect([79, y - 1, 85, y + 1], BREAK);
      }
    }
    for (const [x,y] of plan.spans || []) {
      stroke([[x-1,y-12],[x+1,y+12]],4,RIVER);
      rect([x-7,y-1,x+7,y+1],BRIDGE);
      rect([x-3,y-1,x+3,y+1],BREAK);
    }
    if (plan.glades) {
      for (const path of plan.gladePaths) stroke(path, 4, LAND);
      for (const [x, y] of plan.glades) oval(x, y, 8, 8);
    }
    if (plan.lake) oval(...plan.lake, LAKE);
    if (plan.lure) {
      // Raised ribs bracket the deck. The stern and bow remain open on the route.
      rect([89, 32, 104, 32], HULL);
      rect([89, 38, 104, 38], HULL);
    }
    const xy = ([x, y]) => ({ x, y });
    const cfg = {
      ...CHAPTERS[chapter],
      MW: w,
      MH: h,
      start: xy(plan.start),
      bossTiles: plan.bosses.map(xy),
      castle: { x: cx, y: cy, half, gate, biome },
      cage: xy(plan.cage),
      biomeSeeds: plan.seeds,
      blobs: 0,
      slides: null,
      currents: plan.currents,
    };
    let rooms;
    if (plan.rooms) {
      rooms = new Uint8Array(w * h);
      const types = plan.roomTypes || [14, 16, 16, 17, 18, 19];
      const fillRoom = ([left, top, right, bottom], b) => {
        for (let y = top; y <= bottom; y++) rooms.fill(b, y * w + left, y * w + right + 1);
      };
      for (const hall of plan.halls) fillRoom(hall, plan.hallType || 15);
      plan.rooms.forEach((room, i) => fillRoom(room, types[i]));
    }
    const reserved = new Uint8Array(w * h);
    function reserve(sites, radius) {
      for (const [x, y] of sites || [])
        for (let yy = y - radius; yy <= y + radius; yy++)
          for (let xx = x - radius; xx <= x + radius; xx++)
            if ((xx - x) ** 2 + (yy - y) ** 2 <= radius ** 2) reserved[yy * w + xx] = 1;
    }
    reserve(plan.glades, 9);
    for (const group of [plan.fires, plan.holes, plan.tunnel, plan.pearls]) reserve(group, 2);
    return { plan, mask, rooms, reserved, cfg, revision, bridgeOpen: false };
  }

  function walkLine(path, visit) {
    for (let i = 1; i < path.length; i++) {
      const [ax, ay] = path[i - 1],
        [bx, by] = path[i],
        n = Math.max(Math.abs(bx - ax), Math.abs(by - ay));
      for (let j = i === 1 ? 0 : 1; j <= n; j++)
        visit(Math.round(ax + ((bx - ax) * j) / n), Math.round(ay + ((by - ay) * j) / n));
    }
  }
  function ground(kind, biome) {
    if (kind === OUT || kind === HULL) return ROCK;
    if (kind === RIVER || kind === BREAK) return WATER;
    if (kind === BRIDGE) return STONE;
    if (kind === LAKE) return ICE;
    return biome;
  }
  return { create, walkLine, ground, OUT, LAND, RIVER, LAKE, BRIDGE, BREAK, HULL };
})();
