'use strict';

const StarTrail = (() => {
  const COUNT = 3;
  const HEALTH_PERCENT_PER_SIGN = 5;
  const DAMAGE_PERCENT_PER_SIGN = 4;
  const HEAL_PERCENT = 30;
  const directions = [[0, -1], [-1, 0], [1, 0], [0, 1]];
  let trail = null;
  let recorded = false;
  let pendingHeal = false, pendingSaved = false, retryAt = 0;
  let activeBonus = bonuses(null);

  function bonuses(profile) {
    const atlas = profile && profile.atlas;
    let count = 0;
    if (atlas && typeof atlas === 'object' && !Array.isArray(atlas)) {
      for (let chapter = 1; chapter <= 9; chapter++) if (atlas[chapter] === true) count++;
    }
    return { count, healthPercent: count * HEALTH_PERCENT_PER_SIGN, damagePercent: count * DAMAGE_PERCENT_PER_SIGN };
  }

  function placeStars() {
    const width = World.MW, height = World.PLAY_H;
    const reserved = new Set();
    for (const group of [World.chests, World.shrines, World.shelves, World.boxes, World.beds,
      World.lamps, World.npcs, World.clues, World.qitems, World.drifts, World.fires,
      World.holes, World.ovens, World.pearls, World.glades]) {
      for (const object of group) reserved.add(Math.floor(object.y / World.T) * width + Math.floor(object.x / World.T));
    }

    const {x: sx, y: sy} = World.START;
    const origin = sy * width + sx;
    const rnd = mulberry32(World.SEED ^ Math.imul(World.CHN, 1664525));
    const turn = Math.floor(rnd() * 4);
    const parent = new Int32Array(width * height).fill(-1);
    const queue = new Int32Array(parent.length), steps = new Uint16Array(parent.length);
    queue[0] = origin; parent[origin] = origin;
    let count = 1, span = 0;
    for (let i = 0; i < count; i++) {
      const key = queue[i], x = key % width, y = Math.floor(key / width);
      span = Math.max(span, Math.hypot(x - sx, y - sy));
      for (let side = 0; side < 4; side++) {
        const [dx, dy] = directions[(side + turn) % 4], nx = x + dx, ny = y + dy;
        if (nx < 0 || nx >= width || ny < 0 || ny >= height) continue;
        const next = ny * width + nx;
        if (parent[next] !== -1 || World.treeGrid[next]) continue;
        const tile = World.tileAt(nx, ny);
        if (tile === GATE || tile === FLOOR || World.isSolidTile(nx, ny, false)) continue;
        queue[count++] = next;
        parent[next] = key; steps[next] = steps[key] + 1;
      }
    }
    const last = queue[count - 1], far = steps[last];
    if (far < COUNT) return [];
    let end = last, choices = 0;
    for (let i = 1; i < count; i++) {
      const key = queue[i];
      if (steps[key] < far * .72 || Math.hypot(key % width - sx, Math.floor(key / width) - sy) < span * .70) continue;
      if (rnd() < 1 / ++choices) end = key;
    }

    const path = [];
    for (let key = end; key !== origin; key = parent[key]) path.push(key);
    path.reverse();
    const result = [], anchors = [[.34, .49], [.57, .74], [.83, 1]];
    for (const [lo, hi] of anchors) {
      const target = (lo + (hi - lo) * rnd()) * (path.length - 1);
      let best = null, bestScore = Infinity;
      for (let i = Math.floor(lo * (path.length - 1)); i <= Math.ceil(hi * (path.length - 1)); i++) {
        const key = path[i], x = key % width, y = Math.floor(key / width);
        if (reserved.has(key)) continue;
        const nearStart = Math.max(0, Math.min(32, span * .32) - Math.hypot(x - sx, y - sy));
        const lastStar = result[result.length - 1];
        const gap = lastStar ? Math.hypot(x - lastStar.x, y - lastStar.y) : Infinity;
        const nearStar = Math.max(0, Math.min(22, span * .18) - gap);
        const nearBoss = World.CFG.bossTiles.some(p => (p.x-x)**2 + (p.y-y)**2 < 36);
        const score = Math.abs(i - target) + 10 * (nearStart + nearStar) + (nearBoss ? 35 : 0);
        if (score < bestScore) { bestScore = score; best = {x, y}; }
      }
      if (!best) return [];
      result.push(best); reserved.add(best.y * width + best.x);
    }
    return result.map(({x, y}) => ({x: World.tc(x), y: World.tc(y)}));
  }

  function reset() {
    trail = null;
    recorded = false;
    pendingHeal = false;
    pendingSaved = false;
    retryAt = 0;
    activeBonus = bonuses(null);
  }

  function recordSign(updateStats) {
    if (recorded) return true;
    const profile = Saves.loadProfile();
    if (!profile.atlas || typeof profile.atlas !== 'object' || Array.isArray(profile.atlas)) profile.atlas = {};
    if (profile.atlas[World.CHN] !== true) {
      profile.atlas[World.CHN] = true;
      if (!Saves.saveProfile(profile)) return false;
    }
    recorded = true;
    const previous = activeBonus.count;
    activeBonus = bonuses(profile);
    if (updateStats && previous !== activeBonus.count) Actors.computeStats(false);
    return true;
  }

  function start(saved) {
    reset();
    if (NET.on || G.daily || (G.mut && Object.keys(G.mut).length) || !Session.CH_NUMS.includes(World.CHN)) return;
    activeBonus = bonuses(Saves.loadProfile());
    const stars = placeStars();
    if (stars.length !== COUNT) return;
    const step = saved && saved.collected;
    const collected = Number.isInteger(step) && step >= 0 && step <= COUNT ? step : 0;
    trail = { stars, collected };
    // В слотах 1.1 три собранные звезды уже означали выданную награду.
    if (collected === COUNT) {
      pendingHeal = saved.pendingHeal === true;
      pendingSaved = true;
      recordSign(false);
    }
  }

  function view() { return G.inMenu || NET.on ? null : trail; }

  function snapshot() {
    if (!trail) return null;
    return pendingHeal ? { collected: trail.collected, pendingHeal: true } : { collected: trail.collected };
  }

  // Сначала фиксируем касание в слоте, затем постоянный знак в профиле.
  // Лечение и снятие pendingHeal пишутся вместе (в том числе здоровье команды главы 6).
  function finish() {
    retryAt = G.time + 1;
    if (pendingHeal && !pendingSaved) {
      if (!Saves.saveTrail()) return;
      pendingSaved = true;
    }
    if (!recordSign(true) || !pendingHeal) return;
    const before = P.hp;
    P.hp = Math.min(P.maxHp, before + Math.round(P.maxHp * HEAL_PERCENT / 100));
    const gain = P.hp - before;
    pendingHeal = false;
    if (!Saves.saveTrail()) {
      P.hp = before;
      pendingHeal = true;
      return;
    }
    const star = trail.stars[COUNT - 1];
    StarArt.collected(star.x, star.y);
    Sound.sfx.atlasStar(COUNT);
    if (gain > 0) Effects.floatText(P.x, P.y - 34, '+' + Math.round(gain) + ' здоровья', '#96f0bd', true);
    RunStats.toast('Созвездие собрано! Бонус атласа: +' + activeBonus.healthPercent + '% здоровья и +' +
      activeBonus.damagePercent + '% урона.');
  }

  function update() {
    if (!view() || Session.state !== 'play' || P.down || G.jump || G.hidden || G.activeShrine) return;
    if (trail.collected === COUNT) {
      if ((!recorded || pendingHeal) && G.time >= retryAt) finish();
      return;
    }
    const star = trail.stars[trail.collected];
    if (Math.hypot(P.x - star.x, P.y - star.y) > P.r + 18) return;
    trail.collected++;
    if (trail.collected === COUNT) {
      pendingHeal = true;
      finish();
      return;
    }
    Saves.saveGame();
    StarArt.collected(star.x, star.y);
    Sound.sfx.atlasStar(trail.collected);
    Effects.floatText(star.x, star.y - 24, '✦ ' + trail.collected + ' / ' + COUNT, '#ffe5a2', true);
  }

  return { HEALTH_PERCENT_PER_SIGN, DAMAGE_PERCENT_PER_SIGN, HEAL_PERCENT, bonuses,
    reset, start, update, view, snapshot, get activeBonus() { return activeBonus; } };
})();
