'use strict';

const MenuActions = (() => {
  const kb = v => v >= 1048576 ? (v / 1048576).toFixed(1) + ' МБ' : Math.max(1, Math.round(v / 1024)) + ' КБ';
  function showUpdate() {
    const box = $('updBox'), u = G.update;
    if (!u || u.hiddenByUser || !['found', 'progress', 'ready', 'apk', 'loading', 'perm', 'installer', 'error'].includes(u.type)) { box.classList.add('hidden'); return; }
    const ic = $('updIc'), bar = $('updBar'), fill = $('updFill'), btns = box.querySelector('.updBtns');
    const quote = u.title ? `«${u.title}»` : '';
    let title = '', text = '', icon = '🔄', anim = 'spin', go = '', later = false, pct = -1;
    if (u.type === 'found' || u.type === 'progress') {
      title = `Обновление v${u.version}`;
      pct = u.total > 0 ? Math.min(100, Math.round(u.done / u.total * 100)) : -1;
      text = (quote ? quote + ' · ' : '') + (pct >= 0 ? `скачиваю ${pct}% · ${kb(u.done)} из ${kb(u.total)}` : 'скачиваю…');
    } else if (u.type === 'ready') {
      title = `Обновление v${u.version} готово!`; text = quote || 'Перезапусти – и играй в новой версии'; icon = '✨'; anim = 'bounce'; go = 'Перезапустить'; later = true; pct = 100;
    } else if (u.type === 'apk') {
      title = `Новая версия приложения v${u.version}`; text = (quote ? quote + ' · ' : '') + 'нужна переустановка, это быстро'; icon = '📦'; anim = 'bounce'; go = 'Скачать и установить'; later = true;
    } else if (u.type === 'loading') {
      title = 'Скачиваю приложение'; icon = '⬇️'; anim = 'bounce';
      pct = u.total > 0 ? Math.min(100, Math.round(u.done / u.total * 100)) : -1;
      text = pct >= 0 ? `${pct}% · ${kb(u.done)} из ${kb(u.total)}` : 'подожди немного…';
    } else if (u.type === 'perm') {
      title = 'Нужно разрешение'; text = 'Разреши установку приложений для Крилессы, вернись и нажми ещё раз'; icon = '🔐'; anim = ''; go = 'Установить';
    } else if (u.type === 'installer') {
      title = 'Почти готово'; text = 'Подтверди установку в окне Android'; icon = '📦'; anim = 'bounce'; go = 'Открыть ещё раз';
    } else {
      title = 'Не получилось скачать'; text = 'Проверь интернет и попробуй ещё раз'; icon = '⚠️'; anim = ''; go = 'Ещё раз'; later = true;
    }
    ic.textContent = icon; ic.className = anim;
    $('updTitle').textContent = title; $('updText').textContent = text;
    bar.classList.toggle('hidden', pct === -1 && !['found', 'progress', 'loading'].includes(u.type));
    bar.classList.toggle('indet', pct < 0);
    if (pct >= 0) fill.style.width = pct + '%';
    $('updGo').textContent = go; $('updGo').classList.toggle('hidden', !go); $('updLater').classList.toggle('hidden', !later);
    btns.classList.toggle('hidden', !go && !later);
    box.classList.remove('hidden');
  }
  window.krUpdate = u => {
    if (!u || !u.type) return;
    const prev = G.update;
    if (u.type === 'fail') { G.update = null; showUpdate(); if (prev) RunStats.toast('⚠️ Обновление не скачалось – попробую в следующий раз'); return; }
    if (['found', 'progress', 'ready', 'apk', 'loading'].includes(u.type)) G.update = Object.assign({ base: u.type === 'loading' ? 'apk' : undefined }, prev && u.type === 'loading' ? { version: prev.version, title: prev.title } : {}, u);
    else if (prev) G.update = Object.assign({}, prev, { type: u.type, base: prev.base || prev.type });
    showUpdate();
    // в игре не мешаем – только короткая подсказка
    if (!['menu', 'chapSheet', 'splash', 'whatsnew'].includes(Session.state)) {
      if (u.type === 'found' && !(prev && prev.type === 'found')) RunStats.toast(`⬇️ Скачивается обновление v${u.version}…`);
      if (u.type === 'ready' && !(prev && prev.type === 'ready')) RunStats.toast(`✨ Обновление v${u.version} готово – перезапусти в меню`);
      if (u.type === 'apk' && !(prev && prev.type === 'apk')) RunStats.toast(`📦 Вышла новая версия приложения v${u.version}`);
    }
  };
  function settingValue(id, value) {
    $(id).querySelector('.settingValue').textContent = value;
  }
  function switchValue(id, enabled, value = enabled ? 'Вкл.' : 'Выкл.') {
    $(id).setAttribute('aria-checked', String(enabled));
    settingValue(id, value);
  }
  function updateSoundButtons() {
    const enabled = Sound.isEnabled();
    switchValue('btnSound', enabled);
    switchValue('btnSound2', enabled);
  }
  const onTap = (id, fn) => $(id).addEventListener('click', () => { Sound.init(); Sound.sfx.click(); fn(); });
  const introOpen = n => { const pr = Saves.loadProfile(); return GameLoop.DEBUG || !!pr.admin || !!pr['ch' + n + 'Done']; };
  for (const button of document.querySelectorAll('#intros button[id^="btnIntro"]')) {
    const chapter = Number(button.id.slice('btnIntro'.length)) || 1;
    onTap(button.id, () => {
      if (introOpen(chapter)) Intro.start('ch' + chapter, () => Screens.setState('intros'));
      else RunStats.toast(`🔒 Интро ${chapter} откроется после главы ${chapter}`);
    });
  }
  onTap('btnTalents', Achievements.openTalents);
  // стартовый экран
  onTap('spMap', () => {
    if (!AdventureMenu.SP.firstJourney) {
      AdventureMenu.openMenu();
      return;
    }
    Intro.start('ch1', () => {
      const profile = Saves.loadProfile();
      profile.seenPrologue = true;
      Saves.saveProfile(profile);
      AdventureMenu.openMenu();
    });
  });
  $('splashCv').addEventListener('pointerdown', e => { // тап по героине – прыжок с сердечками
    Sound.init();
    const r = $('splashCv').getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top;
    for (const id of AdventureMenu.SP.heroes) {
      const p = AdventureMenu.SP.heroX && AdventureMenu.SP.heroX[id]; if (!p || Math.abs(x - p[0]) > 50 || Math.abs(y - p[1]) > 80) continue;
      if (AdventureMenu.SP.jump[id] > 0) continue;
      AdventureMenu.SP.jump[id] = 1; Achievements.life('toss'); Achievements.lifeSoon();
      for (let k = 0; k < 6; k++) AdventureMenu.SP.hearts.push({ x: p[0] + rnd(-24, 24), y: p[1] - 20, t: -k * 0.08, col: pick(['#ff5b8a', '#ff9ad8', '#ffd25a']) });
      if (id === 'tessa' && Sound.sfx.meow) Sound.sfx.meow(); else Sound.sfx.blink();
    }
  });
  onTap('updGo', () => {
    const A = window.KrilessaAndroid, u = G.update; if (!A || !u) return;
    const kind = u.base || u.type;
    if (kind === 'ready') {
      $('updOverlay').classList.remove('hidden'); Sound.sfx.superReady();
      setTimeout(() => { if (A.applyUpdate) A.applyUpdate(); }, 900);
      setTimeout(() => $('updOverlay').classList.add('hidden'), 6000);
    } else if (A.installApk) A.installApk();
  });
  onTap('updLater', () => { if (G.update) G.update.hiddenByUser = true; showUpdate(); RunStats.toast('Хорошо! Обновление включится само при следующем запуске'); });
  // главный экран: карточка главы, панель, настройки
  onTap('shClose', AdventureMenu.closeSheet);
  $('shBack').addEventListener('click', AdventureMenu.closeSheet);
  onTap('shPlay', () => {
    if (AdventureMenu.sheetCh === 'rush') { const pr = Saves.loadProfile(); if (GameLoop.DEBUG || pr.admin || pr.ch1Done) Challenges.startRush(); else RunStats.toast('🔒 Босс-раш откроется после главы 1'); return; }
    if (!Chapters.chapterOpen(AdventureMenu.sheetCh)) { RunStats.toast(`🔒 Сначала пройди главу ${AdventureMenu.sheetCh - 1}`); return; }
    Chapters.startChapter(AdventureMenu.sheetCh);
  });
  onTap('shNew', () => { const n = AdventureMenu.sheetCh; GameStorage.remove(Saves.saveKey(n)); Chapters.startChapter(n); });
  onTap('shIntro', () => { const n = AdventureMenu.sheetCh; Intro.start('ch' + n, () => AdventureMenu.openChapterSheet(n)); });
  onTap('chapRush', () => AdventureMenu.openChapterSheet('rush'));
  onTap('mStars', Achievements.openTalents);
  onTap('btnGear', () => Screens.setState('settings'));
  onTap('setBack', AdventureMenu.openMenu);
  const volLabel = () => switchValue('btnVol', Renderer.volOn);
  // Настройка джойстика: режим, размер и место на экране.
  function joyLabel() {
    const mode = Controls.JOY.fixed ? 'Закреплён' : 'Плавающий';
    settingValue('btnJoy', mode);
    settingValue('btnJoy2', mode);
  }
  let joyBack = 'settings';
  function saveJoy() { ControlLayout.save(); joyLabel(); }
  function joyEditPaint() {
    const el = $('jeStick'), r = Controls.JOY_R;
    el.style.width = el.style.height = r * 2 + 'px'; el.style.left = (Controls.JOY.x * Viewport.VW - r) + 'px'; el.style.top = (Controls.JOY.y * Viewport.VH - r) + 'px';
    el.querySelector('i').style.width = el.querySelector('i').style.height = 48 * Controls.JOY.k + 'px';
    el.classList.toggle('float', !Controls.JOY.fixed);
    for (const b of document.querySelectorAll('#jeMode button')) b.classList.toggle('on', (b.dataset.m === 'fixed') === Controls.JOY.fixed);
    for (const b of document.querySelectorAll('#jeSize button')) b.classList.toggle('on', +b.dataset.k === Controls.JOY.k);
    $('jeHint').textContent=(ControlLayout.orientation()==='portrait'?'Вертикально. ':'Горизонтально. ')+'Перетащи круги управления. Поворот экрана открывает вторую раскладку.';
    ControlLayout.paint();
  }
  function openJoyEdit() { joyBack = Session.state; Screens.setState('joyedit'); joyEditPaint(); }
  function closeJoyEdit() { saveJoy(); Screens.setState(joyBack); }
  (() => {
    const el = $('jeStick'); let drag = null;
    el.addEventListener('pointerdown', e => { e.preventDefault(); drag = { id: e.pointerId, dx: e.clientX - Controls.JOY.x * Viewport.VW, dy: e.clientY - Controls.JOY.y * Viewport.VH }; try { el.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ } el.classList.add('drag'); if (!Controls.JOY.fixed) { Controls.JOY.fixed = true; } joyEditPaint(); });
    el.addEventListener('pointermove', e => {
      if (!drag || e.pointerId !== drag.id) return;
      const r = Controls.JOY_R + 6;
      Controls.JOY.x = clamp(e.clientX - drag.dx, r, Viewport.VW - r) / Viewport.VW; Controls.JOY.y = clamp(e.clientY - drag.dy, Viewport.VH * 0.3, Viewport.VH - r) / Viewport.VH; joyEditPaint();
    });
    const end = e => { if (drag && e.pointerId === drag.id) { drag = null; el.classList.remove('drag'); saveJoy(); } };
    el.addEventListener('pointerup', end); el.addEventListener('pointercancel', end);
    for (const b of document.querySelectorAll('#jeMode button')) b.addEventListener('click', () => { Sound.sfx.click(); Controls.JOY.fixed = b.dataset.m === 'fixed'; joyEditPaint(); saveJoy(); });
    for (const b of document.querySelectorAll('#jeSize button')) b.addEventListener('click', () => { Sound.sfx.click(); Controls.JOY.k = +b.dataset.k; Controls.JOY_R = 55 * Controls.JOY.k; joyEditPaint(); saveJoy(); });
  })();
  onTap('btnJoy', openJoyEdit); onTap('btnJoy2', openJoyEdit);
  onTap('jeDone', closeJoyEdit);
  onTap('jeReset', () => { ControlLayout.reset(); joyEditPaint(); joyLabel(); });
  const miniLabel = () => settingValue('btnMini', { classic: 'Классика', paper: 'Листок', neon: 'Неон' }[HUD.MM_STYLE]);
  onTap('btnMini', () => {
    HUD.MM_STYLE = HUD.MM_STYLE === 'paper' ? 'neon' : HUD.MM_STYLE === 'neon' ? 'classic' : 'paper'; const pr = Saves.loadProfile(); pr.settings = pr.settings || {}; pr.settings.mini = HUD.MM_STYLE; pr.settings.miniV = 2; Saves.saveProfile(pr); miniLabel();
    RunStats.toast(HUD.MM_STYLE === 'classic' ? 'Классическая мини-карта – вся карта целиком' : HUD.MM_STYLE === 'paper' ? 'Мини-карта на листочке – местность вокруг и цели по краю 📜' : 'Неоновая мини-карта – местность вокруг и цели по краю ✨');
  });
  const styleLabel = () => settingValue('btnStyle', Terrain.paperOn ? 'Акварель' : 'Классика');
  onTap('btnStyle', () => {
    const pr = Saves.loadProfile(); pr.settings = pr.settings || {}; pr.settings.style = Terrain.paperOn ? 'classic' : 'paper';
    if (pr.settings.miniV !== 2) pr.settings.mini = pr.settings.style === 'paper' ? 'paper' : 'neon';
    Saves.saveProfile(pr); settingValue('btnStyle', pr.settings.style === 'paper' ? 'Акварель' : 'Классика'); RunStats.toast(pr.settings.style === 'paper' ? 'Книжная акварель – перезапускаю…' : 'Классический стиль – перезапускаю…');
    setTimeout(() => location.reload(), 700);
  });
  onTap('btnVol', () => {
    Renderer.volOn = !Renderer.volOn; const pr = Saves.loadProfile(); pr.settings = pr.settings || {}; pr.settings.vol = Renderer.volOn; Saves.saveProfile(pr); volLabel();
    RunStats.toast(Renderer.volOn ? 'Объём включён ✨' : 'Объём выключен – так быстрее на слабых телефонах');
  });
  // ---------- режим админа: 5 касаний по номеру версии в меню ----------
  const ADMIN_HASH = 'xa5467';
  const passHash = str => { let x = 5381; for (const ch of str) x = ((x * 33) ^ ch.codePointAt(0)) >>> 0; return x.toString(36); };
  let verTaps = 0, verT = 0;
  $('menu').querySelector('.version').addEventListener('click', () => {
    const now = performance.now(); verTaps = now - verT < 1500 ? verTaps + 1 : 1; verT = now;
    if (verTaps >= 5) { verTaps = 0; openAdmin(); }
  });
  function openAdmin() {
    const on = !!Saves.loadProfile().admin;
    $('adminHint').className = 'hint';
    $('adminHint').textContent = on ? 'Режим админа включён ✅ Все главы, интро и босс-раш открыты' : 'Введи пароль – откроются все главы, интро и босс-раш';
    $('adminPass').classList.toggle('hidden', on); $('adminPass').value = '';
    $('adminOk').textContent = on ? 'Выключить' : 'Войти';
    Screens.setState('admin');
    if (!on) setTimeout(() => $('adminPass').focus(), 50);
  }
  function adminSubmit() {
    const pr = Saves.loadProfile();
    if (pr.admin) { delete pr.admin; LOOK_ALL = false; Saves.saveProfile(pr); RunStats.toast('🔒 Режим админа выключен'); AdventureMenu.openMenu(); return; }
    if (passHash($('adminPass').value.trim().toLowerCase()) !== ADMIN_HASH) {
      $('adminHint').className = 'hint bad'; $('adminHint').textContent = 'Неверный пароль'; $('adminPass').value = ''; Sound.sfx.hurt(); return;
    }
    pr.admin = true; LOOK_ALL = true; Saves.saveProfile(pr); Sound.sfx.superReady();
    RunStats.toast('🔓 Открыты все главы, интро и босс-раш'); AdventureMenu.openMenu();
  }
  onTap('adminOk', adminSubmit);
  onTap('adminBack', () => Screens.leaveList('menu'));
  $('adminPass').addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); adminSubmit(); } });
  onTap('talBack', () => Screens.leaveList('menu'));
  onTap('talReset', () => {
    const pr = Saves.loadProfile(); if (!talentSpent(pr.talents || {})) return;
    pr.talents = {};
    if ((pr.relics || []).length > 3) { pr.relics = pr.relics.slice(0, 3); RunStats.toast('🎒 Четвёртый карман пуст – последняя реликвия убрана'); }
    Saves.saveProfile(pr); Achievements.renderTalents();
  });
  onTap('rushHero', () => {
    const pr = Saves.loadProfile(); pr.settings = pr.settings || {};
    const list = ['krilessa', 'ryzhovaya'].concat(pr.ch4Done || GameLoop.DEBUG || pr.admin ? ['tessa'] : []);
    pr.settings.rushHero = list[(list.indexOf(pr.settings.rushHero || 'krilessa') + 1) % list.length]; Saves.saveProfile(pr); AdventureMenu.openChapterSheet('rush');
  });
  // ---------- ориентация экрана (в приложении 0.20+; в браузере экран и так поворачивается) ----------
  const ORIENT = { auto: 'Авто', portrait: 'Вертикально', landscape: 'Горизонтально' };
  const orientBridge = () => { const A = window.KrilessaAndroid; return A && A.setOrientation ? A : null; };
  function orientMode() { const A = orientBridge(); try { return A ? A.orientation() || 'auto' : 'auto'; } catch (e) { return 'auto'; } }
  function orientLabel() { settingValue('btnOrient', ORIENT[orientMode()] || ORIENT.auto); }
  onTap('btnOrient', () => {
    const A = orientBridge();
    if (!A) { RunStats.toast(window.KrilessaAndroid ? '📲 Поворот экрана появится после обновления приложения (APK)' : '🔄 В браузере экран поворачивается сам'); return; }
    const order = ['auto', 'landscape', 'portrait'], next = order[(order.indexOf(orientMode()) + 1) % order.length];
    try { A.setOrientation(next); } catch (e) { /* ignore */ }
    setTimeout(orientLabel, 60); settingValue('btnOrient', ORIENT[next]);
    RunStats.toast(next === 'auto' ? '🔄 Экран поворачивается вместе с телефоном' : next === 'landscape' ? '📺 Всегда горизонтально' : '📱 Всегда вертикально');
  });
  // подсказка в начале главы: игру можно перевернуть (пока игрок сам ни разу не играл лёжа)
  let rotHintT = 0;
  function rotHintMaybe(tries = 0) {
    if (Session.state !== 'play') { if (tries < 12 && (Session.state === 'levelup' || Session.state === 'relic' || Session.state === 'pause')) setTimeout(() => rotHintMaybe(tries + 1), 1200); return; } // сначала выбор улучшения
    const pr = Saves.loadProfile();
    if (pr.rotSeen || Viewport.VW > Viewport.VH || orientMode() !== 'auto') return;
    if (window.KrilessaAndroid && !orientBridge()) return; // старое приложение – экран заперт вертикально
    const el = $('rotHint'); el.classList.remove('hidden', 'out');
    clearTimeout(rotHintT); rotHintT = setTimeout(rotHintHide, 4200);
  }
  function rotHintHide() { const el = $('rotHint'); if (el.classList.contains('hidden') || el.classList.contains('out')) return; el.classList.add('out'); clearTimeout(rotHintT); rotHintT = setTimeout(() => el.classList.add('hidden'), 420); }
  $('rotHint').addEventListener('pointerdown', ev => { ev.stopPropagation(); rotHintHide(); });
  window.addEventListener('resize', () => {
    if (Viewport.VW <= Viewport.VH || Session.state !== 'play') return;
    rotHintHide();
    const pr = Saves.loadProfile(); if (!pr.rotSeen) { pr.rotSeen = true; Saves.saveProfile(pr); }
  });
  // ---------- уведомления «Вышла новая версия» (только в приложении 0.11+) ----------
  function notifyLabel(st) {
    const A = window.KrilessaAndroid, bt = $('btnNotify');
    if (!A || !A.notifyState) { bt.classList.add('hidden'); return; }
    try { st = st || A.notifyState(); } catch (e) { st = 'off'; }
    bt.classList.remove('hidden');
    switchValue('btnNotify', st === 'on', st === 'blocked' ? 'Запрещены' : undefined);
  }
  window.krNotify = st => notifyLabel(st);
  onTap('btnNotify', () => {
    const A = window.KrilessaAndroid; if (!A || !A.setNotify) return;
    const st = A.notifyState();
    A.setNotify(st !== 'on');
    if (st === 'on') RunStats.toast('🔕 Уведомления о новых версиях выключены');
    else if (st === 'blocked') RunStats.toast('Разреши уведомления для Крилессы в настройках Android');
  });
  const difficultyAppearance = {
    easy: ['🍵', 'У врагов меньше здоровья и урона.'],
    normal: ['⚔️', 'Обычное здоровье и урон врагов.'],
    hard: ['😈', 'Враги сильнее, элита встречается чаще.'],
  };
  function paintDiff() {
    const saved = (Saves.loadProfile().settings || {}).diff;
    const level = Object.prototype.hasOwnProperty.call(difficultyAppearance, saved) ? saved : 'normal';
    const [symbol, description] = difficultyAppearance[level];
    $('btnDiff').dataset.level = level;
    settingValue('btnDiff', DIFFS[level].name);
    $('diffSymbol').textContent = symbol;
    $('diffDetails').textContent = description;
  }
  onTap('btnDiff', () => {
    const pr = Saves.loadProfile(); pr.settings = pr.settings || {};
    const order = ['easy', 'normal', 'hard'], cur = pr.settings.diff || 'normal';
    pr.settings.diff = order[(order.indexOf(cur) + 1) % 3]; Saves.saveProfile(pr);
    paintDiff();
    RunStats.toast(pr.settings.diff === 'hard' ? 'Кринж-хардкор: враги злее, элита чаще 😈' : pr.settings.diff === 'easy' ? 'Лёгкий режим: можно расслабиться 🍵' : 'Нормальная сложность');
  });
  for (const id of ['btnStats', 'btnStats2', 'btnStats3', 'btnStats4']) onTap(id, RunStats.openStats);
  onTap('statsShare', () => RunStats.shareText(RunStats.buildReport()));
  onTap('statsCopy', () => RunStats.copyText(RunStats.buildReport()));
  onTap('statsBack', () => { if (RunStats.statsBack === 'menu') AdventureMenu.openMenu(); else Screens.setState(RunStats.statsBack); });
  onTap('btnWhatsNew', () => Story.openWhatsNew(null));
  onTap('wnClose', Story.closeWhatsNew);
  onTap('ch4Riddle', Story.openTeaser);
  onTap('relicMelt', () => { for (let i = 0; i < 12; i++) Effects.dropShard(P.x + rnd(-40, 40), P.y + rnd(-40, 40)); Screens.setState('play'); RunStats.toast('💎 Реликвия переплавлена в 12 осколков'); });
  onTap('mapClose', () => Screens.setState('play'));
  ChapterMap.initMapGestures(onTap);
  $('mapCanvas').addEventListener('click', () => Screens.setState('play'));
  onTap('btnIntros', () => Screens.setState('intros'));
  onTap('btnMP', Multiplayer.openMP);
  onTap('btnStarAtlas', StarAtlas.open);
  onTap('atlasBack', AdventureMenu.openMenu);
  onTap('atlasTravel', StarAtlas.travel);
  onTap('btnModes', Collection.openModes); onTap('btnColl', Collection.openColl);
  onTap('modesBack', AdventureMenu.openMenu); onTap('collBack', AdventureMenu.openMenu);
  onTap('mdDefGo', () => Defense.startDefense());
  onTap('mdAbyssGo', () => Challenges.startAbyss(Challenges.abyssCkLoad())); onTap('mdAbyssNew', () => Challenges.startAbyss()); onTap('mdDailyGo', Challenges.startDaily);
  onTap('mdHero', () => { const pr = Saves.loadProfile(); pr.settings = pr.settings || {}; const list = ['krilessa', 'ryzhovaya'].concat(pr.ch4Done || GameLoop.DEBUG || pr.admin ? ['tessa'] : []);
    pr.settings.rushHero = list[(list.indexOf(Challenges.rushHeroPick(pr)) + 1) % list.length]; Saves.saveProfile(pr); Collection.openModes(); });
  onTap('btnAch', () => { Achievements.lifeFlush(); Achievements.achCat = 'all'; Achievements.renderAch(); Screens.setState('ach'); }); onTap('achBack', Collection.openColl);
  // слава: доска почёта и образ
  function lookDone() { cancelAnimationFrame(Achievements.lookRaf); Screens.leaveList('coll'); }
  onTap('btnHall', () => Achievements.openHall('rec'));
  onTap('btnRelics', () => { Collection.relicsFrom = 'coll'; Collection.openRelics(); }); onTap('relicsBack', () => Collection.relicsLeave());
  onTap('btnHome', () => HomeScreen.openHome('coll')); onTap('mHome', () => HomeScreen.openHome('menu'));
  onTap('homeBack', () => { if (HomeScreen.HOME.edit) { $('homeEditBtn').click(); return; } cancelAnimationFrame(HomeScreen.HOME.raf); if (HomeScreen.HOME.back === 'menu') AdventureMenu.openMenu(); else Collection.openColl(); });
  onTap('homeEditBtn', () => { HomeScreen.HOME.edit = !HomeScreen.HOME.edit; $('homeEdit').classList.toggle('hidden', !HomeScreen.HOME.edit); $('homeEditBtn').textContent = HomeScreen.HOME.edit ? '✓ Готово' : '✏️ Обставить'; if (HomeScreen.HOME.edit) HomeScreen.renderHomeEdit(); });
  for (const k of ['furn', 'pets', 'wall']) onTap('heT_' + k, () => { HomeScreen.HOME.tab = k; HomeScreen.renderHomeEdit(); });
  $('homeCv').addEventListener('pointerdown', HomeScreen.homeTap);
  onTap('seasonBar', () => { if (!Seasons.SEASON_OFF) Seasons.openSeason(); });
  onTap('seasonBack', AdventureMenu.openMenu);
  onTap('btnLook', Achievements.openLook);
  onTap('mEmb', Achievements.openLook);
  onTap('mRank', () => Achievements.openHall('rec'));
  onTap('hallBack', () => Screens.leaveList('coll'));
  onTap('lookBack', lookDone);
  for (const [id, tab] of [['hlTabR', 'rec'], ['hlTabF', 'fr']]) {
    onTap(id, () => {
      Achievements.hallTab = tab;
      Sound.sfx.click();
      Achievements.renderHall();
    });
  }
  for (const k of ['em', 'fr', 'ti', 'au']) onTap('lkT_' + k, () => { Achievements.lookTab = k; Sound.sfx.click(); Achievements.renderLook(); });
  $('lkName').addEventListener('change', () => {
    const pr = Saves.loadProfile(), v = ($('lkName').value || '').trim().slice(0, 14);
    pr.mp = Object.assign({ hero: 'krilessa' }, pr.mp || {}, { name: v || HEROES.krilessa.name }); Saves.saveProfile(pr); Achievements.renderLook();
  });
  onTap('hlShare', () => {
    const code = Achievements.cardCode(Achievements.myCard());
    $('hlCode').value = code;
    try { if (window.KrilessaAndroid && window.KrilessaAndroid.share) { window.KrilessaAndroid.share('Моя карточка в Крилессе 🏅 Добавь меня на доску почёта:\n' + code); return; } } catch (e) { /* ignore */ }
    RunStats.fallbackCopy(code); RunStats.toast('📋 Код карточки скопирован – отправь подруге');
  });
  onTap('hlAdd', () => {
    const c = Achievements.readCode($('hlCode').value);
    if (!c) { RunStats.toast('Код не подошёл 🤔 Скопируй его целиком, начиная с KR1-'); Sound.sfx.block(); return; }
    if (c.id === Saves.loadProfile().pid) { RunStats.toast('Это твоя карточка 😄'); return; }
    Achievements.addFriends([c]); $('hlCode').value = ''; RunStats.toast(`🎉 ${c.nm} теперь на доске почёта!`); Sound.sfx.superReady(); Achievements.renderHall();
  });
  onTap('btnBook', () => Collection.openBook('e')); onTap('bookBack', () => {
    if ($('bkDetail').classList.contains('hidden')) Collection.bookLeave();
    else $('bkDetail').classList.add('hidden');
  });
  for (const tab of ['e', 'b', 'v']) {
    onTap('bookTab' + tab.toUpperCase(), () => {
      Collection.bookTab = tab;
      Collection.renderBook();
    });
  }
  onTap('bkClose', () => $('bkDetail').classList.add('hidden'));
  onTap('shMut', () => Challenges.openMuts(AdventureMenu.sheetCh)); onTap('mutGo', Challenges.mutGo); onTap('mutBack', () => { if (Challenges.mutNet) { Screens.setState('mp'); Multiplayer.mpRender(); } else AdventureMenu.openChapterSheet(Challenges.mutCh); });
  $('vibStrength').addEventListener('change',()=>{ const pr=Saves.loadProfile(); pr.settings=pr.settings||{}; pr.settings.vibStrength=Number($('vibStrength').value); Saves.saveProfile(pr); Challenges.vibLabel(); Challenges.buzz(52); });
  onTap('btnVib', () => { const pr = Saves.loadProfile(); pr.settings = pr.settings || {}; Challenges.vibOn = !((pr.settings.vib !== false)); pr.settings.vib = Challenges.vibOn; Saves.saveProfile(pr); Challenges.vibLabel(); if (Challenges.vibOn) Challenges.buzz(60); });
  onTap('mpHostBtn', Multiplayer.mpHost);
  onTap('mpContinue', CoopActivity.continueRoom);
  onTap('btnCoopSave', CoopCheckpoints.manual);
  onTap('mpJoinBtn', Multiplayer.mpScan);
  onTap('mpGo', Multiplayer.mpGo);
  onTap('mpMut', CoopActivity.openMutators);
  onTap('mpResume', CoopActivity.toggleResume);
  onTap('mpReady', Multiplayer.mpToggleReady);
  onTap('mpBack', mpBack);
  $('mp').addEventListener('keydown', event => {
    // Поля и нативные списки лобби используют собственную клавиатурную навигацию.
    event.stopPropagation();
    if (event.key === 'Escape') {
      event.preventDefault();
      mpBack();
    } else if (event.key === 'Enter' && !event.isComposing && event.target === $('mpIp')) {
      event.preventDefault();
      $('mpIpGo').click();
    }
  });
  onTap('mpCopy', () => { if (NET.host && NET.ips && NET.ips.length) RunStats.copyText(NET.ips[0]); });
  onTap('mpIpGo', () => {
    const parts = $('mpIp').value.trim().match(/^(\d{1,3}(?:\.\d{1,3}){3})(?::(\d{1,5}))?$/);
    if (!parts || parts[1].split('.').some(octet => Number(octet) > 255) ||
        (parts[2] && (Number(parts[2]) < 1 || Number(parts[2]) > 65535))) {
      RunStats.toast('Введи адрес из комнаты, например 192.168.1.5 или 192.168.1.5:47822');
      return;
    }
    Multiplayer.mpName();
    Multiplayer.mpJoin(parts[1].split('.').map(Number).join('.'), Number(parts[2] || 0));
  });
  $('mpName').addEventListener('change', () => { Multiplayer.mpName(); if (NET.client) { NET.card = Achievements.myCard(); NetT.send(0, { t: 'me', name: NET.name, hero: NET.hero, cd: NET.card }); } if (NET.host) Multiplayer.mpLobbyBroadcast(); });
  function mpBack() {
    if (NET.joining) { Multiplayer.backToSearch(); return; }
    if (NET.host || NET.client || NET.scanning) {
      Multiplayer.mpLeave();
      return;
    }
    AdventureMenu.openMenu();
  }
  onTap('introsBack', () => Screens.leaveList('coll'));
  onTap('choiceGood', () => HouseChapter.finishCh4('good'));
  onTap('choiceKind', () => HouseChapter.finishCh4('kind'));
  onTap('boardGo', () => { Screens.setState('play'); if (G.pendingLv > 0) Screens.openLevelUp(); });
  onTap('npcBtn', () => HouseChapter.openNpc(G.nearNpc));
  onTap('btnWardrobe', HouseChapter.openWardrobe);
  onTap('wardBack', () => { if (HouseChapter.wardBack === 'menu') AdventureMenu.openMenu(); else Screens.setState(HouseChapter.wardBack); });
  onTap('harbourHatch', () => Harbour.travel());
  onTap('portalBtn', Encounters.openPortals);
  onTap('portalBack', () => Screens.setState('play'));
  onTap('teaserBack', Story.closeTeaser);
  onTap('krillBack', Story.closeKrill);
  $('krillCanvas').addEventListener('pointerdown', e => {
    Sound.init();
    const r = $('krillCanvas').getBoundingClientRect(), x = (e.clientX - r.left) / r.width * 480, y = (e.clientY - r.top) / r.height * 640;
    Story.KT.tap = { x, y, t: 0.35 }; Achievements.life('krillTap'); Achievements.lifeSoon();
    Story.KT.pops.push({ x, y, t: 0, text: pick(Story.KRILL_SAY) });
    for (let k = 0; k < 6; k++) Story.KT.bubbles.push({ x: x + rnd(-20, 20), y: y + rnd(-10, 10), r: rnd(2, 5), v: rnd(60, 120) });
    Sound.sfx.shard();
  });
  $('teaserCanvas').addEventListener('pointerdown', () => { Sound.init(); Sound.sfx.meow(); Story.teaserGlow = 1; });
  onTap('zmPlay', () => Story.zmReact('Браво мне! БРАВО! Но спектакль ещё не окончен! 😈', true));
  onTap('zmLike', () => Story.zmReact('Роза?! Мне?! ...Спасибо, зайка. Но тебя это не спасёт! 🌹😈', true));
  onTap('zmDonate', () => Story.zmReact('ПОМИДОР?! В мою лучшую корону?! Ну всё!!! 🍅😤', true));
  $('zmExit').addEventListener('pointerdown', e => {
    e.preventDefault(); Sound.init(); Sound.sfx.click();
    if (!G.zm) return;
    G.zm.tries++;
    const el = $('zmExit');
    el.style.transform = `translate(${rnd(-110, 110)}px, ${rnd(-140, 60)}px) rotate(${rnd(-25, 25)}deg)`;
    el.textContent = ['✖ Выйти', 'Куда?! 😏', 'Не-не-не!', 'Выхода нет 😈'][Math.min(3, G.zm.tries)];
    if (G.zm.tries >= 3) { Story.zmReact('Из театра не уходят посреди спектакля! Второй акт! 😈', true); Achievements.lifeMax('escape', 1); }
  });
  // пасхалка: потыкай портрет в меню
  let portraitTaps = 0;
  $('menuPortrait').addEventListener('click', () => {
    portraitTaps++;
    if (portraitTaps % 7 === 0) {
      const c = $('menuPortrait').getContext('2d');
      if (Session.IMG.zyama) c.drawImage(Session.IMG.zyama.cartoon, 0, 0, 240, 320);
      Sound.init(); Sound.sfx.roar();
      RunStats.toast('Зямочкккк: Эй! Не трогай её! Я ей, между прочим, стих посвятил! 😤');
      Achievements.lifeMax('poke', 1); Achievements.lifeSoon();
      setTimeout(AdventureMenu.drawMenuPortrait, 2200);
    }
  });
  function toggleSound() {
    Sound.setEnabled(!Sound.isEnabled());
    updateSoundButtons();
  }
  onTap('btnSound', toggleSound);
  onTap('btnSound2', toggleSound);
  function saveAndOpenMenu() {
    Saves.saveGame();
    AdventureMenu.openMenu();
  }
  onTap('btnResume', Screens.resumeGame);
  onTap('btnToMenu', saveAndOpenMenu);
  onTap('btnRetry', Screens.respawn);
  onTap('btnDeadMenu', saveAndOpenMenu);
  onTap('btnVictoryMenu', AdventureMenu.openMenu);
  onTap('btnDeadRoom', Multiplayer.returnToRoom);
  onTap('btnVictoryRoom', Multiplayer.returnToRoom);
  onTap('victoryNext', () => {
    if (NET.on && G.netRun) { if (NET.host && CHAPTERS[World.CHN + 1]) { NET.ch = World.CHN + 1; Multiplayer.mpGo(); } else if (NET.client) RunStats.toast('Следующую главу запустит хозяйка 🏠'); return; } // вместе: следующую главу запускает хозяйка
    Chapters.startChapter(World.CHN + 1);
  });
  for (const el of document.querySelectorAll('.version')) el.textContent = 'v' + VERSION;

  // Кнопка в шапке и системная кнопка Android выполняют одно действие.
  const menuBackButtons = {
    mp: 'mpBack', book: 'bookBack', relics: 'relicsBack', home: 'homeBack', ach: 'achBack',
    hall: 'hallBack', look: 'lookBack', season: 'seasonBack', modes: 'modesBack', coll: 'collBack',
    starAtlas: 'atlasBack', muts: 'mutBack', stats: 'statsBack', whatsnew: 'wnClose',
    teaser: 'teaserBack', krill: 'krillBack', mapscr: 'mapClose', intros: 'introsBack',
    talents: 'talBack', admin: 'adminBack', joyedit: 'jeDone', chapSheet: 'shClose',
    settings: 'setBack', wardrobe: 'wardBack', portal: 'portalBack',
  };
  for (const page of document.querySelectorAll('.menuPage, #chapSheet')) {
    page.addEventListener('keydown', event => {
      // Tab, пробел и стрелки здесь принадлежат меню.
      event.stopPropagation();
      if (event.key === 'Escape') {
        event.preventDefault();
        window.krBack();
      }
    });
  }
  window.krBack = () => {
    const back = menuBackButtons[Session.state];
    if (back) { $(back).click(); return 'handled'; }
    if (Session.state === 'choice' || Session.state === 'relic') return 'handled';
    if (Session.state === 'board') { if (G.accused) { Screens.setState('play'); if (G.pendingLv > 0) Screens.openLevelUp(); } return 'handled'; }
    if (Session.state === 'npc') { Screens.setState('play'); return 'handled'; }
    if (Session.state === 'zmenu') { Story.zmReact('Кнопка «Назад» тоже моя! Сидеть и смотреть! 😈', true); Achievements.lifeMax('escape', 1); return 'handled'; }
    if (Session.state === 'victory' && $('victoryButtons').classList.contains('hidden')) return 'handled';
    if (Session.state === 'play') { Screens.pauseGame(); return 'handled'; }
    if (Session.state === 'pause') { Screens.resumeGame(); return 'handled'; }
    if (Session.state === 'levelup') return 'handled';
    if (Session.state === 'intro') { Intro.skip(); return 'handled'; }
    if (Session.state === 'dead' || Session.state === 'victory') { AdventureMenu.openMenu(); return 'handled'; }
    return 'exit';
  };
  function pauseApp() {
    if (NET.on && G.netRun) Saves.coopSave();
    if (Session.state === 'play') Screens.pauseGame();
    Sound.suspend();
    if (GameLoop.inRun()) GameLoop.liveWrite(true);
  }
  function resumeApp() {
    Sound.resume();
    if (GameLoop.inRun()) GameLoop.liveWrite(false);
  }
  window.krPause = pauseApp;
  window.krResume = resumeApp;
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) pauseApp();
    else resumeApp();
  });

  return {
    showUpdate, updateSoundButtons, volLabel, joyLabel, joyEditPaint, miniLabel, styleLabel,
    orientLabel, rotHintMaybe, rotHintHide, notifyLabel, paintDiff, switchValue,
  };
})();
