'use strict';

const HarbourArt = (() => {
  const cache = new Map();
  function picture(name) {
    if (!cache.has(name)) {
      const img = new Image();
      img.src = 'art/harbour/' + name + '.webp';
      cache.set(name, img);
    }
    return cache.get(name);
  }
  async function portraits() {
    await Promise.all(
      ['cast', 'keel', 'bycatch', 'tackle'].map((name) => {
        const img = picture(name);
        if (img.complete) return;
        return new Promise((resolve) => {
          img.addEventListener('load', resolve, { once: true });
          img.addEventListener('error', resolve, { once: true });
        });
      }),
    );
  }
  function warm() {
    for (const name of ['districts', 'cast', 'keel', 'actors', 'bycatch', 'tackle', 'zyama']) picture(name);
  }
  function line(c, x, y, xx, yy, color, w = 2) {
    c.beginPath();
    c.moveTo(x, y);
    c.lineTo(xx, yy);
    c.strokeStyle = color;
    c.lineWidth = w;
    c.stroke();
  }
  function oval(c, x, y, rx, ry, col) {
    c.beginPath();
    c.ellipse(x, y, rx, ry, 0, 0, Math.PI * 2);
    c.fillStyle = col;
    c.fill();
  }
  function cell(c, name, col, row, cols, rows, x, y, w, h) {
    const im = picture(name);
    if (!im.naturalWidth) return false;
    const sw = im.naturalWidth / cols,
      sh = im.naturalHeight / rows;
    c.drawImage(im, col * sw, row * sh, sw, sh, x, y, w, h);
    return true;
  }

  const districts = [
    [33, 77, 0, 29, 31],
    [55, 58, 2, 22, 27],
    [44, 34, 3, 23, 28],
    [96, 39, 4, 25, 28],
    [110, 85, 5, 19, 24],
    [124, 22, 6, 20, 23],
  ];
  function passage(c, point, down) {
    const { x, y } = Harbour.tilePoint(point);
    c.save();
    c.translate(x, y);
    c.transform(1, 0, -0.26, 0.68, 0, 0);
    c.fillStyle = '#323e40';
    c.fillRect(-29, -34, 58, 68);
    c.lineWidth = 4;
    c.strokeStyle = down ? '#90795f' : '#d3ac88';
    c.strokeRect(-29, -34, 58, 68);
    c.fillStyle = down && !G.defeated[0] ? '#586468' : '#221e21';
    c.fillRect(-25, -30, 50, 60);
    for (let z = -24; z < 30; z += 11) line(c, -19, z, 19, z, down && !G.defeated[0] ? '#768484' : '#a98c78');
    if (down && G.defeated[0]) {
      c.fillStyle = '#7f5c4c';
      c.fillRect(-29, -50, 58, 14);
    }
    c.restore();
  }
  function gate(c) {
    const x = World.tc(World.CASTLE.x),
      y = World.tc(World.CASTLE.y + World.CASTLE.half);
    for (const dx of [-78, 78]) {
      oval(c, x + dx, y + 4, 13, 7, '#293638');
      c.fillStyle = '#655d53';
      c.fillRect(x + dx - 8, y - 26, 16, 28);
      oval(c, x + dx, y - 26, 11, 5, '#ac9b7c');
    }
    c.strokeStyle = World.gateOpen ? '#886e54' : '#d8aa71';
    c.lineWidth = 4;
    c.setLineDash([6, 3]);
    c.beginPath();
    c.moveTo(x - 78, y - 18);
    if (World.gateOpen) c.quadraticCurveTo(x - 56, y + 24, x - 27, y + 12);
    else c.quadraticCurveTo(x, y + 25, x + 78, y - 18);
    c.stroke();
    c.setLineDash([]);
  }
  const propsFor = { netmender: 'net', projector: 'screen', pilot: 'bollard', understudy: 'lamp' };
  function prop(c, x, y, kind, dim) {
    c.save();
    c.translate(x, y);
    oval(c, 5, 3, 17, 5, '#18222873');
    if (kind === 'net') {
      c.strokeStyle = '#b9ae85';
      c.lineWidth = 3;
      c.beginPath();
      c.ellipse(0, 0, 19, 10, -0.4, 0, TAU);
      c.stroke();
      line(c, 14, -7, 23, -19, '#9b916c', 3);
    } else if (kind === 'screen') {
      c.fillStyle = '#30363d';
      c.fillRect(-15, -31, 30, 35);
      line(c, -17, -31, 15, -33, '#c2b393', 3);
      line(c, -15, -29, -15, 8, '#8e8071', 3);
    } else if (kind === 'bollard') {
      c.fillStyle = '#665c4e';
      c.fillRect(-9, -20, 18, 23);
      oval(c, 0, -20, 12, 5, '#c8a67a');
      line(c, -8, -11, 8, -14, '#a7a196', 2);
    } else {
      line(c, 0, 4, 0, -22, '#555055', 4);
      oval(c, 0, -25, 9, 7, '#483f43');
      oval(c, -2, -26, 6, 4, dim ? '#737060' : '#f5d594');
      if (!dim) {
        c.fillStyle = '#ffde9b20';
        c.beginPath();
        c.moveTo(1, -23);
        c.lineTo(-36, 17);
        c.lineTo(34, 13);
        c.fill();
      }
    }
    c.restore();
  }
  // Along the ordinary streets, warm windows and the ferry lights reflect in the asphalt.
  // These facades sit outside the walkable shoreline. Street furniture stays on its shoulder.
  const houses = [
    [17, 82, 3],
    [16, 77, 3],
    [18, 60, 2],
    [34, 63, 2],
    [49, 72, 1],
    [68, 61, 1],
    [29, 42, 2],
    [56, 28, 2],
    [65, 46, 1],
    [84, 51, 1],
    [109, 34, 1],
  ];
  const lampPosts = [
    [26, 82],
    [36, 66],
    [51, 59],
    [32, 49],
    [56, 38],
    [67, 52],
    [80, 44],
    [94, 47],
    [110, 43],
    [119, 34],
  ];
  function streets(c, vis) {
    for (const [tx, ty, floors] of houses) {
      const x = World.tc(tx),
        y = World.tc(ty);
      if (!vis(x, y, 180)) continue;
      const wide = floors === 1 ? 102 : 137,
        tall = floors * 20 + 14;
      c.save();
      c.translate(x, y);
      c.fillStyle = '#17252c55';
      c.beginPath();
      c.moveTo(0, 1);
      c.lineTo(wide, 18);
      c.lineTo(wide + 37, 1);
      c.lineTo(33, -12);
      c.fill();
      c.fillStyle = floors === 1 ? '#4b5252' : '#68716c';
      c.fillRect(-wide / 2, -tall, wide, tall);
      c.fillStyle = '#414d4d';
      c.beginPath();
      c.moveTo(wide / 2, -tall);
      c.lineTo(wide / 2 + 26, -tall - 17);
      c.lineTo(wide / 2 + 26, -17);
      c.lineTo(wide / 2, 0);
      c.fill();
      c.fillStyle = tx % 2 ? '#566465' : '#655951';
      c.beginPath();
      c.moveTo(-wide / 2 - 3, -tall);
      c.lineTo(-wide / 2 + 18, -tall - 19);
      c.lineTo(wide / 2 + 29, -tall - 19);
      c.lineTo(wide / 2 + 3, -tall);
      c.fill();
      for (let col = 0; col < 5; col++) {
        const xx = -wide / 2 + 9 + (col * (wide - 18)) / 5;
        line(c, xx, -tall - 1, xx + 18, -tall - 17, '#a9aca252', 1.1);
        for (let row = 0; row < floors; row++) {
          c.fillStyle = '#394448';
          c.fillRect(xx, -tall + 7 + row * 18, 12, 10);
          c.fillStyle = (row + col + tx) % 4 === 0 ? '#c4a173' : '#84918b';
          c.fillRect(xx + 2, -tall + 9 + row * 18, 8, 6);
        }
      }
      c.restore();
    }
    for (const [tx, ty] of lampPosts) {
      const x = World.tc(tx),
        y = World.tc(ty);
      if (!vis(x, y, 140)) continue;
      oval(c, x + 7, y + 6, 13, 3, '#18202355');
      line(c, x, y, x - 2, y - 64, '#404b4b', 3.5);
      line(c, x - 2, y - 64, x + 13, y - 70, '#77827a', 2.7);
      oval(c, x + 14, y - 69, 6, 2.6, '#e2bd81');
      oval(c, x + 13, y - 68, 12, 5, '#f8ca7329');
      oval(c, x + 15, y + 6, 6, 1.8, '#bda88058');
    }
  }

  function ground(c, vis) {
    const im = picture('districts'),
      T = World.T;
    for (const [tx, ty, id, w, h] of districts) {
      const x = World.tc(tx),
        y = World.tc(ty);
      if (!im.naturalWidth || !vis(x, y, T * h * 0.68)) continue;
      const left = x - (w * T) / 2,
        top = y - h * T * 0.62;
      let night = 0;
      if (id === 0) {
        if (G.defeated[0]) night = 1;
        else if (G.activeBoss?.kind === 'keel') {
          const hull = G.activeBoss;
          if (hull.darkAt == null) hull.darkAt = G.time;
          night = clamp((G.time - hull.darkAt) / 2.1, 0, 1);
        }
      }
      if (night < 1)
        c.drawImage(im, (id % 4) * 560, Math.floor(id / 4) * 720, 560, 720, left, top, w * T, h * T);
      if (night > 0) {
        c.save();
        c.globalAlpha *= night;
        c.drawImage(im, 560, 0, 560, 720, left, top, w * T, h * T);
        c.restore();
      }
    }
    streets(c, vis);
    for (const [label, tx, ty] of [
      ['ул. Сахалинская', 45, 65],
      ['ул. Шутова', 69, 52],
      ['Дом культуры', 49, 41],
      ['Причал', 106, 42],
    ]) {
      const x = World.tc(tx),
        y = World.tc(ty);
      if (!vis(x, y, 90)) continue;
      line(c, x, y, x, y - 31, '#4a5558', 4);
      c.fillStyle = '#31474b';
      c.fillRect(x - 44, y - 46, 88, 20);
      c.strokeStyle = '#9baba3';
      c.lineWidth = 1;
      c.strokeRect(x - 44, y - 46, 88, 20);
      c.font = '600 11px sans-serif';
      c.textAlign = 'center';
      c.fillStyle = '#f0e5c8';
      c.fillText(label, x, y - 32);
      c.textAlign = 'start';
    }
    for (const b of Session.bosses) {
      const kind = propsFor[b.kind];
      if (!kind || b.state === 'dead' || !vis(b.hx, b.hy, 230)) continue;
      for (const p of Harbour.props(b, kind)) prop(c, p.x, p.y, kind, b.stunT > 0);
    }
    if (vis(World.tc(43), World.tc(79), 100)) passage(c, HARBOUR_MAP.hatch, true);
    if (vis(World.tc(110), World.tc(94), 100)) passage(c, HARBOUR_MAP.ladder, false);
    if (vis(World.tc(124), World.tc(31), 130)) gate(c);
  }

  const castRow = { netmender: 0, projector: 1, pilot: 2, understudy: 3 };
  function figure(c, b, t, face) {
    const a = b.mode !== 'idle' && b.mode !== 'trans',
      wind = Math.sin(t * 2.2),
      stride = Math.sin(b.stride || 0) * (b.walk || 0);
    const row = castRow[b.kind],
      action = a && (b.charging || b.sub === 1 || (b.cnt || 0) % 2 === 1);
    c.save();
    c.translate(stride * 2, Math.abs(stride) * -3 + wind * 1.3);
    c.scale(face < 0 ? -1 : 1, 1);
    c.rotate(stride * 0.055 + wind * 0.017 + (b.charging ? 0.12 : 0));
    const size = b.kind === 'netmender' ? 119 : 111;
    cell(c, 'cast', action ? 1 : 0, row, 2, 4, -size / 2, -size * 0.74, size, size);
    if (b.kind === 'netmender' && action) {
      c.strokeStyle = '#aeb69ccc';
      c.lineWidth = 1.7;
      for (let j = 0; j < 4; j++) {
        c.beginPath();
        c.moveTo(22, -34 + j * 3);
        c.quadraticCurveTo(38, 3 + j * 3, 53 + wind * 7, -6 + j * 5);
        c.stroke();
      }
    } else if (b.kind === 'projector') {
      const x = action ? 14 : 0,
        y = -42;
      oval(c, x, y, action ? 4 : 2.5, 3, '#ffdda5');
      if (action) {
        c.fillStyle = '#fff1c923';
        c.beginPath();
        c.moveTo(x, y);
        c.lineTo(73, -56);
        c.lineTo(68, -17);
        c.fill();
      }
    } else if (b.kind === 'pilot') {
      line(c, 21, -24, 25 + wind * 4, -3, '#b9a988', 1.5);
      oval(c, 25 + wind * 4, -2, 4, 5, '#efbd74');
    } else if (b.kind === 'understudy' && action) {
      for (let i = 0; i < 4; i++) {
        const f = (t * 0.64 + i * 0.25) % 1;
        c.save();
        c.translate(18 + f * 45, -34 + Math.sin(f * 6) * 12);
        c.rotate(f * 5);
        c.fillStyle = '#ded3ae';
        c.fillRect(-3, -1.5, 6, 3);
        c.restore();
      }
    }
    c.restore();
  }
  for (const kind of Object.keys(castRow)) BSPR[kind] = figure;
  BSPR.keel = (c, b, t) => {
    const im = picture('keel');
    c.save();
    c.rotate(Math.sin(t * 1.65) * 0.048);
    c.translate(0, Math.sin(t * 2.2) * 2.2);
    if (im.naturalWidth) c.drawImage(im, -85, -72, 170, 114);
    const swing = Math.sin(t * 2.1) * 6,
      open = b.mode === 'dropAnchor' && b.sub === 3;
    line(c, 44, 3, 46 + swing, open ? 26 : 17, '#d2bc93', 2);
    cell(c, 'tackle', open ? 1 : 0, 0, 2, 2, 37 + swing, open ? 22 : 12, 18, 18);
    oval(c, 4, 14, 2.8, 2, open ? '#f7d08f' : '#b9aba1');
    c.restore();
  };
  BSPR.bycatch = (c, b, t) => {
    const open = b.mode === 'bloodPulse' && b.sub === 3,
      breath = Math.sin(t * (open ? 3.8 : 1.9));
    c.save();
    c.translate(0, 2 * breath);
    c.scale(1 + breath * 0.024, 1 - breath * 0.018);
    cell(c, 'bycatch', open ? 1 : 0, 0, 2, 1, -75, -86, 150, 128);
    if (open) oval(c, 4, -31, 4 + 1.5 * breath, 3.7, '#efbbb1');
    c.restore();
  };
  function paintedActor(c, row, x, y, t, face, size, moving, attack) {
    const frame = attack ? 3 : moving ? [0, 1, 0, 2][Math.floor(t * 8) % 4] : 0;
    const bob = moving ? Math.abs(Math.sin(t * 8)) * 2 : Math.sin(t * 2) * 0.7;
    c.save();
    c.translate(x, y - bob);
    c.scale(face < 0 ? -1 : 1, 1);
    const h = size * (row === 0 ? 1.12 : 1.44);
    const ok = cell(
      c,
      'actors',
      frame,
      row,
      4,
      2,
      -h * 0.375,
      -h * (row === 0 ? 0.9 : 0.81) + size * 0.19,
      h * 0.75,
      h,
    );
    c.restore();
    return ok;
  }
  ESPR.saltDiver = (c, e) => paintedActor(c, 1, 0, 0, e.t || 0, Math.cos(e.look || 0), 45, true, e.flash > 0);
  ESPR.ticketShade = (c, e) => {
    const t = e.t || 0;
    c.save();
    c.rotate(Math.sin(t * 3) * 0.22);
    c.translate(0, Math.sin(t * 5) * 3);
    for (let k = 2; k >= 0; k--) {
      c.fillStyle = ['#d6c3a2', '#a69887', '#726776'][k];
      c.fillRect(-12 + k * 5, -10 + k * 5, 23, 11);
    }
    line(c, -8, -5, 4, -5, '#73675e', 1.5);
    line(c, -8, -2, 1, -2, '#73675e', 1);
    c.restore();
  };
  const colors = {
    anchorFall: '#e9c48e',
    netLine: '#c5d49c',
    pilotWake: '#b6e1e2',
    filmLight: '#ffe2a4',
    echoFoot: '#deb8c9',
    bloodTide: '#f39385',
  };
  function warning(c, h) {
    const color = colors[h.fx];
    if (!color || (h.kind !== 'line' && h.kind !== 'circle')) return false;
    const t = clamp(h.t / Math.max(0.01, h.delay), 0, 1);
    c.save();
    c.translate(h.x, h.y);
    c.strokeStyle = color;
    c.fillStyle = color + (h.done ? '77' : '29');
    c.lineWidth = h.done ? 4 : 2;
    if (h.kind === 'circle') {
      c.beginPath();
      c.arc(0, 0, h.r, 0, TAU);
      c.fill();
      c.stroke();
      c.beginPath();
      c.arc(0, 0, Math.max(3, h.r * (1 - t)), 0, TAU);
      c.stroke();
      if (h.fx === 'anchorFall') {
        const y = -(1 - t) * 80;
        line(c, 0, y - 35, 0, y, color, 2);
        cell(c, 'tackle', 0, 0, 2, 2, -17, y - 15, 34, 34);
      }
    } else {
      c.rotate(h.ang);
      c.fillRect(0, -h.w / 2, h.len, h.w);
      line(c, 0, -h.w / 2, h.len, -h.w / 2, color);
      line(c, 0, h.w / 2, h.len, h.w / 2, color);
      for (let x = 12; x < h.len; x += 31) {
        const y = Math.sin(x * 0.09 + h.t * 6) * 3;
        if (h.fx === 'netLine') {
          line(c, x, -h.w / 2, Math.min(x + 20, h.len), h.w / 2, color + 'a0', 1);
        } else if (h.fx === 'bloodTide') {
          const side = x < h.len / 2 ? 1 : -1;
          line(c, x - side * 6, y - 4, x, y, color, 2);
          line(c, x, y, x - side * 6, y + 4, color, 2);
        } else if (h.fx === 'echoFoot') {
          oval(c, x, y, 4, 2, color);
        } else line(c, x, y, Math.min(h.len, x + 9 + t * 7), y, color + 'b0', 1.6);
      }
    }
    c.restore();
    return true;
  }
  return { portraits, warm, ground, warning, paintedActor, face: () => picture('zyama') };
})();
