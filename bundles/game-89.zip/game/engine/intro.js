'use strict';

// ------------------------------------------------------------------
//  Интро (две истории)
// ------------------------------------------------------------------
const Intro = (() => {
  const cv = $('introCanvas'), c = cv.getContext('2d');
  const STORIES = {
    ch1: {
      wipe: [2.9, 5.2], end: 14.6,
      scenes: [
        { at: 0, text: 'Это Рыжовая.<br>Самая обычная девушка…' },
        { at: 2.6, text: '…пока на неё не упала<br><b>волшебная искра</b>!', sfx: 'magic' },
        { at: 5.4, text: 'Теперь она – <b>мультяшная</b>!', sfx: 'level', flash: true },
        { at: 7.8, text: 'Но злой колдун <b>Мрак</b> похитил её<br>и запер в Тёмном замке!', sfx: 'roar' },
        { at: 11.0, text: 'Спасти её может только<br>отважная крылатая <b>Крилесса</b>!', music: 'menu' },
      ],
    },
    ch2: {
      wipe: [6.3, 8.4], end: 18.2,
      scenes: [
        { at: 0, text: 'Рыжовая спасена! Крилесса и Рыжовая<br>пьют какао и смотрят на звёзды…', music: 'menu' },
        { at: 3.0, text: '…как вдруг небо треснуло,<br>и из портала вылез <b>ОН</b>.', sfx: 'roar' },
        { at: 6.0, text: 'Мультяшная магия сделала его…<br><b>ещё кринжовее</b>!', sfx: 'magic' },
        { at: 8.6, text: '«Трепещите, зайки! Я – <b>ЗЯМОЧКККК</b>,<br>Император Кринжа!» 💅', sfx: 'level', flash: true, music: 'final' },
        { at: 11.8, text: '«Рыжовая будет слушать мои стихи.<br><b>ВЕЧНО!</b>»', sfx: 'gate' },
        { at: 14.8, text: '<b>Глава 2: Кринж-Цитадель</b><br>Крилесса, вперёд! Спаси её снова!' },
      ],
    },
    ch4: {
      end: 17,
      scenes: [
        { at: 0, text: 'Три часа ночи. Весь дом спит.<br>Тесса спит <b>двадцать часов в сутки</b>…', music: 'night4' },
        { at: 3.4, text: '…но этой ночью её разбудил<br><b>странный звук</b>.', sfx: 'staticNoise' },
        { at: 6.6, text: 'Лампочки мигают. Телевизор включился сам.<br>Из экрана смотрят <b>зелёные глаза</b>.', sfx: 'whisper' },
        { at: 10, text: '«Мяу. Я – <b>Мяу.exe</b>.<br>Теперь это <b>мой</b> дом.»', sfx: 'roar', flash: true, music: 'tv4' },
        { at: 13.4, text: '<b>Глава 4: Ночь глитчей</b><br>Тесса одна. Но она видит всё.', sfx: 'meow' },
      ],
    },
    ch5: {
      end: 16,
      scenes: [
        { at: 0, text: 'Утро. Солнце. Пахнет блинчиками…', music: 'morning5' },
        { at: 3.2, text: 'Тесса идёт к миске и видит…<br><b>ПУСТОТУ</b>.', sfx: 'roar' },
        { at: 6.4, text: 'Корм пропал. Из <b>всех</b> мисок в доме!', sfx: 'staticNoise' },
        { at: 9.4, text: 'Тесса надевает шапку детектива.<br>Это дело – для неё. 🕵️', sfx: 'magic', flash: true },
        { at: 12.6, text: '<b>Глава 5: Пропавший корм</b><br>Ищи улики. Допрашивай подозреваемых.', sfx: 'meow', music: 'detective5' },
      ],
    },
    ch6: {
      end: 16,
      scenes: [
        { at: 0, text: 'Лето. Банкет в честь Тессы.<br>Торт, музыка, все друзья вместе. 🎉', music: 'truewin' },
        { at: 3.2, text: 'И вдруг… пошёл снег.<br><b>В июле.</b>', sfx: 'whisper' },
        { at: 6.4, text: '«Новый сезон, – прошептал Мрак. –<br>Вечная <b>зима</b>.» 👑❄️', sfx: 'roar', flash: true, music: 'mrakboss' },
        { at: 9.6, text: 'Лёд сковал Тессу – и Мрак унёс её<br>в свой Ледяной замок!', sfx: 'shatter' },
        { at: 12.8, text: '<b>Глава 6: Мрак – новый сезон</b><br>Крилесса и Рыжовая – вместе! Меняйтесь кнопкой 🔄', sfx: 'magic', music: 'winter6' },
      ],
    },
    ch7: {
      end: 16,
      scenes: [
        { at: 0, text: 'Зима позади. Все трое – на море!<br>Тёплый песок, волны, мороженое. 🏖️', music: 'reef7' },
        { at: 3.2, text: 'И вдруг из-под воды раздалось:<br><b>«КРИЛЯТЬ!!!»</b> 🤬', sfx: 'roar', flash: true, music: 'krillboss' },
        { at: 6.4, text: 'Миллиарды розовых крилей утащили<br>на дно все <b>слова любви</b>. 💗', sfx: 'whisper' },
        { at: 9.6, text: 'Тесса надевает пузырь-шлем.<br>Ныряем! 🫧', sfx: 'magic' },
        { at: 12.8, text: '<b>Глава 7: Крилевая бездна</b><br>Течения, жемчужины – и кто-то очень ругучий на дне', sfx: 'level', flash: true, music: 'reef7' },
      ],
    },
    // финал главы 7: пляж на закате, Крильятин уплывает к солнцу
    end7: {
      end: 18,
      scenes: [
        { at: 0, text: 'Бездна затихла.<br>Все слова любви вернулись наверх… 💗', music: 'jelly7' },
        { at: 3.4, text: 'Подруги вынырнули у берега<br>как раз к <b>закату</b>. 🌅', sfx: 'magic' },
        { at: 6.8, text: '– Я просто хотел, чтобы меня<br><b>крилюбили</b>… – шмыгнул Крильятин.' },
        { at: 10.2, text: '– Мы тебя крилюбим! 💗<br>Крильятин покраснел – от смущения.', sfx: 'heart' },
        { at: 13.6, text: 'Король крилей уплыл в закат.<br>Впервые – без ругательств. 🌅', music: 'truewin' },
      ],
    },
    ch3: {
      wipe: [12.8, 14.8], end: 19,
      scenes: [
        { at: 0, text: 'Прошла неделя. Крилесса и Рыжовая –<br>теперь лучшие подруги.', music: 'menu' },
        { at: 3.0, text: 'Но вдруг из всех зеркал мира<br>раздалось: «<b>Трепещите, зайки!</b>»', sfx: 'roar' },
        { at: 6.2, text: '<b>Зямочкккк</b> сдержал слово и вернулся<br>в версии 0.03. Теперь он – <b>2.0</b>!', sfx: 'level', flash: true, music: 'final2' },
        { at: 9.2, text: 'Он затянул Крилессу в свой<br><b>Зеркальный Зямоверс</b>!', sfx: 'gate' },
        { at: 12.4, text: 'Но у Рыжовой есть секрет:<br>её волосы – <b>настоящий огонь</b>!', sfx: 'magic' },
        { at: 15.6, text: '<b>Глава 3: Рыжовая спешит на помощь</b><br>Теперь ты играешь за неё!', sfx: 'level', flash: true },
      ],
    },
  };
  Object.assign(STORIES,Belfry.scenes,Harbour.scenes);
  let story = null, t = 0, last = 0, scene = -1, running = false, done = null, raf = 0, sparks = [], flash = 0, lightning = 0;
  function start(which, cb) {
    document.body.classList.toggle('belfryFilm', !!STORIES[which].scenes[0].art);
    story = STORIES[which]; story.id = which; Screens.Dialog.clear(); $('introTap').classList.remove('ready');
    if (story.scenes[0].art) BelfryArt.preload(story.scenes);
    done = cb; t = 0; scene = -1; sparks = []; flash = 0; running = true;
    Screens.setState('intro');
    last = performance.now();
    cancelAnimationFrame(raf); raf = requestAnimationFrame(frame);
  }
  function skip() { if (running) finish(); }
  function finish() { running = false; cancelAnimationFrame(raf); if (done) done(); }
  // интро листается по касанию: сцена доигрывает анимацию и ждёт
  function boundary() { for (const s of story.scenes) if (s.at > t + 0.02) return s.at; return story.end; }
  function next() { t = boundary(); $('introTap').classList.remove('ready'); }
  cv.addEventListener('pointerdown', () => { Sound.init(); if (running) next(); });
  $('introSkip').addEventListener('click', () => { Sound.init(); skip(); });
  $('filmNext').addEventListener('click', () => {Sound.init();if(running) next();});
  let textTimer;
  function setText(html) {
    clearTimeout(textTimer);
    const el = $('introText');
    el.style.opacity = 0;
    textTimer=setTimeout(() => { el.innerHTML = html; el.style.opacity = 1; }, 200);
  }
  function frame(now) {
    if (!running) return;
    const dt = Math.min(0.05, (now - last) / 1000); last = now;
    if (t >= story.end) { finish(); return; }
    const lim = boundary() - 0.06;
    if (t + dt < lim) t += dt; else { t = Math.max(t, lim); $('introTap').classList.add('ready'); }
    let s = 0; for (let i = 0; i < story.scenes.length; i++) if (t >= story.scenes[i].at) s = i;
    if (s !== scene) {
      scene = s; const sc = story.scenes[s];
      if (sc.art) {
        const speaker=sc.speaker ? '<span class="filmSpeaker">'+sc.speaker+'</span>' : '';
        setText(speaker+sc.text);
        $('filmNext').textContent=s===story.scenes.length-1 ? (story.id==='ch8'?'На берег':story.id==='ch9'?'Выйти во двор':'Завершить') : 'Дальше';
        $('filmProgress').replaceChildren(...story.scenes.map((_,i)=>{
          const mark=document.createElement('i');if(i<=s)mark.className='seen';return mark;
        }));
      } else setText(sc.text);
      if (sc.sfx) Sound.sfx[sc.sfx]();
      if (sc.flash) flash = 1;
      if (sc.music) Sound.music(sc.music);
      if (sc.sfx === 'roar') lightning = 0.6;
    }
    if(story.scenes[s].art) {const [w,h]=setup();BelfryArt.drawScene(c,w,h,story.scenes[s],t-story.scenes[s].at);}
    else if (story.id === 'ch1') drawCh1(dt); else if (story.id === 'ch2') drawCh2(dt); else if (story.id === 'ch4') drawCh4(dt); else if (story.id === 'ch5') drawCh5(dt); else if (story.id === 'ch6') drawCh6(dt); else if (story.id === 'ch7') drawCh7(dt); else if (story.id === 'end7') drawEnd7(dt); else drawCh3(dt);
    if (Terrain.paperOn) try { // интро – как иллюстрации в книге: зерно бумаги и тёплые края
      if (!HUD.PAPER.tex) HUD.PAPER.tex = HUD.paperTex();
      c.save(); c.setTransform(1, 0, 0, 1, 0, 0); c.globalCompositeOperation = 'multiply'; c.fillStyle = c.createPattern(HUD.PAPER.tex, 'repeat'); c.fillRect(0, 0, cv.width, cv.height);
      const vg = c.createRadialGradient(cv.width / 2, cv.height / 2, Math.min(cv.width, cv.height) * 0.38, cv.width / 2, cv.height / 2, Math.hypot(cv.width, cv.height) * 0.56);
      vg.addColorStop(0, 'rgba(255,255,255,1)'); vg.addColorStop(1, 'rgba(214,180,136,1)'); c.fillStyle = vg; c.fillRect(0, 0, cv.width, cv.height); c.restore();
    } catch (e) {}
    if (flash > 0) { c.setTransform(1, 0, 0, 1, 0, 0); c.fillStyle = `rgba(255,255,255,${flash})`; c.fillRect(0, 0, cv.width, cv.height); flash -= dt * 2; }
    raf = requestAnimationFrame(frame);
  }
  function setup() {
    const W = window.innerWidth, H = window.innerHeight, dpr = Math.min(window.devicePixelRatio || 1, 2);
    if (cv.width !== Math.round(W * dpr) || cv.height !== Math.round(H * dpr)) { cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr); }
    c.setTransform(dpr, 0, 0, dpr, 0, 0);
    return [W, H];
  }
  function bg(W, H, top, bottom) {
    const g = c.createLinearGradient(0, 0, 0, H);
    g.addColorStop(0, top); g.addColorStop(1, bottom);
    c.fillStyle = g; c.fillRect(0, 0, W, H);
    for (let i = 0; i < 60; i++) {
      const x = hash2(i, 1) * W, y = hash2(i, 2) * H, tw = 0.5 + 0.5 * Math.sin(t * 2 + i);
      c.fillStyle = `rgba(255,255,255,${0.15 + tw * 0.35})`; c.fillRect(x, y, 2, 2);
    }
  }
  // Полароид с фото; wipe 0..1 – превращение в мультик
  function card(img, cx, cy, cw, sc, rot, alpha, wipe, caption, cageK, sparkCols, dt) {
    const ch = cw * 4 / 3;
    c.save();
    c.translate(cx, cy); c.rotate(rot); c.scale(sc, sc);
    c.globalAlpha = alpha;
    c.fillStyle = 'rgba(0,0,0,0.4)'; c.fillRect(-cw / 2 - 4, -ch / 2 - 2, cw + 28, ch + 60);
    c.fillStyle = '#fff8ee'; c.fillRect(-cw / 2 - 12, -ch / 2 - 12, cw + 24, ch + 64);
    c.drawImage(wipe >= 1 ? img.cartoon : img.photo, -cw / 2, -ch / 2, cw, ch);
    const toX = u => -cw / 2 + u * cw, toY = v => -ch / 2 + v * ch;
    if (wipe > 0 && wipe < 1) {
      const dl = -0.12 + wipe * 1.24;
      c.save(); c.beginPath();
      c.moveTo(toX(2 * dl + 10), toY(-10)); c.lineTo(toX(-10), toY(2 * dl + 10)); c.lineTo(toX(-40), toY(-40)); c.closePath();
      c.clip(); c.drawImage(img.cartoon, -cw / 2, -ch / 2, cw, ch); c.restore();
      for (let k = 0; k < 4; k++) {
        const u = Math.random(), v = 2 * dl - u;
        if (v >= 0 && v <= 1) sparks.push({ x: toX(u), y: toY(v), vx: rnd(-40, 40), vy: rnd(-60, 20), life: rnd(0.4, 0.9), r: rnd(3, 8), rot: rnd(0, TAU), col: pick(sparkCols) });
      }
      c.save(); c.beginPath(); c.rect(-cw / 2, -ch / 2, cw, ch); c.clip();
      c.strokeStyle = 'rgba(255,240,180,0.9)'; c.lineWidth = 4;
      c.beginPath(); c.moveTo(toX(2 * dl), toY(0)); c.lineTo(toX(0), toY(2 * dl)); c.stroke();
      c.restore();
    }
    c.fillStyle = '#5a2a10'; c.textAlign = 'center';
    c.font = `bold ${Math.round(cw * 0.1)}px Krilessa Icons, "Comic Sans MS", "Trebuchet MS", sans-serif`;
    c.fillText(caption, 0, ch / 2 + 36);
    if (cageK > 0) {
      const off = (1 - cageK) * -ch * 1.3;
      c.strokeStyle = '#3a3a48'; c.lineWidth = Math.max(5, cw * 0.03);
      for (let i = 0; i <= 6; i++) { const x = -cw / 2 - 6 + i * (cw + 12) / 6; c.beginPath(); c.moveTo(x, -ch / 2 - 16 + off); c.lineTo(x, ch / 2 + 50 + off); c.stroke(); }
      c.strokeStyle = '#ffd25a'; c.lineWidth = Math.max(7, cw * 0.04);
      c.beginPath(); c.moveTo(-cw / 2 - 16, -ch / 2 - 16 + off); c.lineTo(cw / 2 + 16, -ch / 2 - 16 + off); c.stroke();
      c.beginPath(); c.moveTo(-cw / 2 - 16, ch / 2 + 50 + off); c.lineTo(cw / 2 + 16, ch / 2 + 50 + off); c.stroke();
    }
    c.globalCompositeOperation = 'lighter';
    for (const s of sparks) {
      s.x += s.vx * dt; s.y += s.vy * dt; s.life -= dt; s.rot += dt * 4;
      c.globalAlpha = clamp(s.life, 0, 1); c.fillStyle = s.col;
      star(c, s.x, s.y, s.r, s.rot); c.fill();
    }
    sparks = sparks.filter(s => s.life > 0);
    c.globalCompositeOperation = 'source-over';
    c.restore();
  }
  function title(W, k, main, sub, col = '#ffd25a', glow = '#7a2a00') {
    c.globalAlpha = k; c.textAlign = 'center';
    const fs = Math.min(W * 0.12, 56);
    c.font = `900 ${fs}px Krilessa Icons, "Trebuchet MS", sans-serif`;
    c.fillStyle = glow; c.fillText(main, W / 2, Viewport.SAFE_TOP + fs + 50);
    c.fillStyle = col; c.fillText(main, W / 2, Viewport.SAFE_TOP + fs + 46);
    if (sub) { c.font = `bold ${fs * 0.42}px Krilessa Icons, "Trebuchet MS", sans-serif`; c.fillStyle = '#ffe8d0'; c.fillText(sub, W / 2, Viewport.SAFE_TOP + fs * 1.6 + 50); }
    c.globalAlpha = 1;
  }
  function drawCh1(dt) {
    const [W, H] = setup();
    const dark = clamp((t - 7.6) / 0.8, 0, 1) * (1 - clamp((t - 11) / 1, 0, 1));
    bg(W, H, `rgb(${lerp(70, 15, dark) | 0},${lerp(30, 8, dark) | 0},${lerp(100, 30, dark) | 0})`, `rgb(${lerp(20, 5, dark) | 0},${lerp(8, 3, dark) | 0},${lerp(30, 10, dark) | 0})`);
    if (t > 7.8 && t < 11 && Math.random() < 0.02) lightning = 0.5;
    if (lightning > 0) { c.fillStyle = `rgba(200,170,255,${lightning * 0.6})`; c.fillRect(0, 0, W, H); lightning -= dt * 2; }
    const cw = Math.min(W * 0.7, H * 0.42 * 0.75), ch = cw * 4 / 3;
    let cx = W / 2, cy = H * 0.42, sc = 1;
    if (t < 0.9) sc = 0.85 + 0.15 * ease(t / 0.9);
    if (t >= 5.4 && t < 7.8) sc = 1 + 0.07 * Math.sin((t - 5.4) * 12) * Math.exp(-(t - 5.4) * 2.5);
    if (t > 8.6 && t < 9.4) cx += Math.sin(t * 60) * 6 * (9.4 - t);
    const titleK = ease((t - 11) / 1.0);
    cy -= titleK * H * 0.06; sc *= 1 - titleK * 0.22;
    const wipe = clamp((t - story.wipe[0]) / (story.wipe[1] - story.wipe[0]), 0, 1);
    card(Session.IMG.ryzhova, cx, cy, cw, sc, -0.035, clamp(t / 0.8, 0, 1), wipe, t >= 5.4 ? '★ Рыжовая ★' : 'Рыжовая', ease((t - 8.1) / 0.5), ['#ffe066', '#ffb03a', '#fff3b0'], dt);
    if (t > 7.8 && t < 11.4) {
      const a = clamp((t - 7.8) / 0.6, 0, 1) * (1 - clamp((t - 10.8) / 0.6, 0, 1));
      c.fillStyle = `rgba(255,91,240,${a})`;
      const ey = H * 0.09 + Viewport.SAFE_TOP;
      c.beginPath(); c.ellipse(W / 2 - 30, ey, 16, 7, 0.25, 0, TAU); c.ellipse(W / 2 + 30, ey, 16, 7, -0.25, 0, TAU); c.fill();
    }
    if (titleK > 0) {
      title(W, titleK, 'Крилесса', 'Спасение Рыжовой');
      const kx = lerp(-60, W * 0.78, ease((t - 11.2) / 1.4)), ky = cy + ch * sc * 0.66 + Math.sin(t * 3) * 8;
      drawKrilessa(c, kx, ky, t, 1, Math.min(4, W / 110), titleK, true);
    }
  }
  function drawCh2(dt) {
    const [W, H] = setup();
    const neon = clamp((t - 8.4) / 0.6, 0, 1);
    bg(W, H, neon > 0 ? `rgb(${lerp(42, 60, neon) | 0},${lerp(22, 10, neon) | 0},${lerp(64, 90, neon) | 0})` : '#2a1640', '#0a0614');
    if (lightning > 0) { c.fillStyle = `rgba(255,120,220,${lightning * 0.5})`; c.fillRect(0, 0, W, H); lightning -= dt * 2; }
    if (neon > 0) {
      for (let k = 0; k < 6; k++) {
        const a = t * 0.6 + k * TAU / 6;
        c.strokeStyle = k % 2 ? `rgba(255,62,165,${0.18 * neon})` : `rgba(63,240,255,${0.18 * neon})`; c.lineWidth = 30;
        c.beginPath(); c.moveTo(W / 2, H * 0.4); c.lineTo(W / 2 + Math.cos(a) * H, H * 0.4 + Math.sin(a) * H); c.stroke();
      }
    }
    const cw = Math.min(W * 0.62, H * 0.38 * 0.75);
    const ks = Math.min(4, W / 110);
    // Рыжовая (празднует, потом попадает в клетку)
    const move = ease((t - 11.8) / 1.2);
    const ryzX = lerp(W * 0.32, W * 0.5, move), ryzY = lerp(H * 0.62, H * 0.66, move);
    const ryzR = Math.min(W, H) * 0.13;
    if (t < 3.2 || t > 11.6) {
      const a = t < 3.2 ? 1 - clamp((t - 2.6) / 0.6, 0, 1) : clamp((t - 11.6) / 0.4, 0, 1);
      c.save(); c.globalAlpha = a;
      if (Session.AVATAR.ryzhovaBig) { c.save(); c.beginPath(); c.arc(ryzX, ryzY, ryzR, 0, TAU); c.clip(); c.drawImage(Session.AVATAR.ryzhovaBig, ryzX - ryzR, ryzY - ryzR, ryzR * 2, ryzR * 2); c.restore(); }
      c.strokeStyle = '#ff7a2f'; c.lineWidth = 5; c.beginPath(); c.arc(ryzX, ryzY, ryzR, 0, TAU); c.stroke();
      if (t > 12.6) {
        const k = ease((t - 12.6) / 0.5), off = (1 - k) * -H * 0.5;
        c.strokeStyle = '#ff3ea5'; c.lineWidth = 6;
        for (let i = 0; i <= 5; i++) { const x = ryzX - ryzR - 6 + i * (ryzR * 2 + 12) / 5; c.beginPath(); c.moveTo(x, ryzY - ryzR - 14 + off); c.lineTo(x, ryzY + ryzR + 10 + off); c.stroke(); }
        c.strokeStyle = '#3ff0ff'; c.lineWidth = 8; c.beginPath(); c.moveTo(ryzX - ryzR - 12, ryzY - ryzR - 14 + off); c.lineTo(ryzX + ryzR + 12, ryzY - ryzR - 14 + off); c.stroke();
      }
      c.restore();
    }
    if (t < 3.2) {
      const r0 = 1 - clamp((t - 2.6) / 0.6, 0, 1);
      drawKrilessa(c, W * 0.7, H * 0.64 + Math.sin(t * 3) * 6, t, -1, ks, r0, true);
      c.globalAlpha = r0;
      for (let i = 0; i < 6; i++) { c.fillStyle = '#ff5b8a'; heartPath(c, W * 0.5 + Math.sin(t * 2 + i) * 60, H * 0.55 - ((t * 40 + i * 30) % 140), 8); c.fill(); }
      c.globalAlpha = 1;
    }
    // портал
    const pk = clamp((t - 2.8) / 0.8, 0, 1) * (1 - clamp((t - 8.4) / 0.8, 0, 1));
    if (pk > 0) {
      const pr = Math.min(W, H) * 0.34 * pk;
      for (let k = 0; k < 5; k++) {
        c.strokeStyle = k % 2 ? 'rgba(255,62,165,0.8)' : 'rgba(63,240,255,0.8)'; c.lineWidth = 6;
        c.beginPath(); c.ellipse(W / 2, H * 0.38, pr * (1 - k * 0.15), pr * 0.75 * (1 - k * 0.15), t * (k % 2 ? 2 : -2), 0, TAU * 0.85); c.stroke();
      }
    }
    // карточка Зямочкккк
    if (t > 3.4 && t < 15.2) {
      const appear = ease((t - 3.4) / 1.4);
      let sc = 0.2 + 0.8 * appear;
      if (t >= 8.6 && t < 11) sc *= 1 + 0.08 * Math.sin((t - 8.6) * 12) * Math.exp(-(t - 8.6) * 2.5);
      let cy = H * 0.4;
      if (t > 11.8) { sc *= 1 - 0.3 * move; cy -= move * H * 0.12; }
      const fade = 1 - clamp((t - 14.6) / 0.6, 0, 1);
      const wipe = clamp((t - story.wipe[0]) / (story.wipe[1] - story.wipe[0]), 0, 1);
      card(Session.IMG.zyama, W / 2, cy, cw, sc, 0.04 * Math.sin(t * 2), appear * fade, wipe, t >= 8.6 ? '★ ЗЯМОЧКККК ★' : '???', 0, ['#ff3ea5', '#3ff0ff', '#ffe04a'], dt);
      if (t >= 8.6) {
        c.save(); c.translate(W / 2, cy - cw * 4 / 3 * sc / 2 - 6); c.rotate(-0.15);
        const s = sc * cw / 140; c.scale(s, s); c.globalAlpha = fade;
        c.fillStyle = '#ffd25a'; c.strokeStyle = '#b8860b'; c.lineWidth = 3;
        c.beginPath(); c.moveTo(-36, 4); c.lineTo(-36, -28); c.lineTo(-18, -10); c.lineTo(0, -36); c.lineTo(18, -10); c.lineTo(36, -28); c.lineTo(36, 4); c.closePath(); c.fill(); c.stroke();
        c.fillStyle = '#ff3ea5'; c.beginPath(); c.arc(0, -8, 5, 0, TAU); c.fill();
        c.restore();
      }
    }
    if (t > 8.6 && t < 15) {
      for (let i = 0; i < 10; i++) {
        const spr = emojiSprite(ZYAMA_EMOJI[i % ZYAMA_EMOJI.length], 26);
        const a = t * 0.8 + i * TAU / 10, rr = Math.min(W, H) * 0.42;
        c.globalAlpha = 0.85; c.drawImage(spr, W / 2 + Math.cos(a) * rr - 20, H * 0.4 + Math.sin(a) * rr * 0.8 - 20, 40, 40); c.globalAlpha = 1;
      }
    }
    if (t >= 8.6 && t < 11.8) title(W, ease((t - 8.6) / 0.6), 'ЗЯМОЧКККК', 'Император Кринжа', '#ff3ea5', '#3a0a3a');
    if (t >= 14.8) {
      const k = ease((t - 14.8) / 0.8);
      title(W, k, 'Глава 2', 'Кринж-Цитадель', '#3ff0ff', '#0a2a4a');
      drawKrilessa(c, lerp(-60, W * 0.5, ease((t - 15) / 1.4)), H * 0.5 + Math.sin(t * 3) * 8, t, 1, Math.min(4.5, W / 100), k, true);
    }
  }
  let flames = [];

  // ---------- глава 4: ночь, телевизор сам включился ----------
  function drawCh4(dt) {
    const [W, H] = setup();
    bg(W, H, '#0a0a1e', '#020208');
    c.fillStyle = '#141432'; c.fillRect(W * 0.08, H * 0.12, W * 0.3, H * 0.2);
    c.fillStyle = '#e8e8ff'; c.beginPath(); c.arc(W * 0.23, H * 0.2, Math.min(W, H) * 0.035, 0, TAU); c.fill();
    c.strokeStyle = '#2a2a4a'; c.lineWidth = 4; c.strokeRect(W * 0.08, H * 0.12, W * 0.3, H * 0.2);
    c.beginPath(); c.moveTo(W * 0.23, H * 0.12); c.lineTo(W * 0.23, H * 0.32); c.stroke();
    const tvOn = t > 3.4, tx = W * 0.72, ty = H * 0.28, tw = Math.min(W * 0.4, 190), th = tw * 0.7;
    c.fillStyle = '#111'; roundRect(c, tx - tw / 2 - 8, ty - th / 2 - 8, tw + 16, th + 16, 10); c.fill();
    if (tvOn) {
      for (let i = 0; i < 240; i++) { const v = Math.random() * 255 | 0; c.fillStyle = `rgb(${v},${v},${v})`; c.fillRect(tx - tw / 2 + Math.random() * (tw - 5), ty - th / 2 + Math.random() * (th - 3), 5, 3); }
      c.fillStyle = 'rgba(255,255,255,0.06)'; c.beginPath(); c.moveTo(tx - tw / 2, ty + th / 2); c.lineTo(tx + tw / 2, ty + th / 2); c.lineTo(W, H); c.lineTo(0, H); c.closePath(); c.fill();
      if (t > 6.6) {
        const a = clamp((t - 6.6) / 1, 0, 1), bl = Math.sin(t * 3) > 0.95 ? 0.1 : 1;
        c.fillStyle = `rgba(63,240,160,${a})`; c.beginPath();
        c.ellipse(tx - tw * 0.17, ty, tw * 0.08, th * 0.15 * bl, 0, 0, TAU); c.ellipse(tx + tw * 0.17, ty, tw * 0.08, th * 0.15 * bl, 0, 0, TAU); c.fill();
        c.fillStyle = '#000'; c.fillRect(tx - tw * 0.18, ty - th * 0.13 * bl, 3, th * 0.26 * bl); c.fillRect(tx + tw * 0.16, ty - th * 0.13 * bl, 3, th * 0.26 * bl);
      }
    } else { c.fillStyle = '#06060c'; c.fillRect(tx - tw / 2, ty - th / 2, tw, th); }
    const bx = W * 0.5, by = H * 0.62, ks = Math.min(5, W / 70);
    c.fillStyle = '#4a2240'; c.beginPath(); c.ellipse(bx, by + ks * 3, ks * 16, ks * 6, 0, 0, TAU); c.fill();
    c.fillStyle = '#7a3a60'; c.beginPath(); c.ellipse(bx, by + ks * 2, ks * 12, ks * 4, 0, 0, TAU); c.fill();
    const awake = t > 3.4;
    drawTessa(c, bx, by, awake ? t : 0.4, awake && t > 6.6 ? 1 : -1, ks, 1, false);
    if (!awake) { c.fillStyle = '#bfd8ff'; c.font = `bold ${Math.round(14 + ks * 2)}px Krilessa Icons, sans-serif`; c.textAlign = 'center'; c.fillText('z', bx + 30 + Math.sin(t * 2) * 6, by - 40 - (t * 20) % 40); c.fillText('Z', bx + 46, by - 64 - (t * 16) % 50); }
    if (t > 6.6 && Math.random() < 0.07) { c.fillStyle = 'rgba(0,0,0,0.65)'; c.fillRect(0, 0, W, H); }
    if (t > 10 && t < 13.4) {
      const a = clamp((t - 10) / 0.6, 0, 1) * clamp((13.4 - t) / 0.6, 0, 1), sz = Math.min(W, H) * 0.55;
      if (!Session.AVATAR.glitchcat) Session.AVATAR.glitchcat = bossPortrait('glitchcat');
      c.globalAlpha = a; c.drawImage(Session.AVATAR.glitchcat, W / 2 - sz / 2 + (Math.random() < 0.2 ? rnd(-12, 12) : 0), H * 0.4 - sz / 2, sz, sz); c.globalAlpha = 1;
      for (let i = 0; i < 8; i++) { c.fillStyle = Math.random() < 0.5 ? 'rgba(63,240,160,0.25)' : 'rgba(255,62,165,0.25)'; c.fillRect(0, Math.random() * H, W, rnd(3, 18)); }
    }
    if (t > 13.4) { c.fillStyle = 'rgba(90,184,255,0.15)'; c.beginPath(); c.arc(bx + ks * 8, by - ks * 7, ks * 10 + Math.sin(t * 4) * 4, 0, TAU); c.fill(); }
  }
  // ---------- глава 5: утро, миски пусты ----------
  function drawCh5(dt) {
    const [W, H] = setup();
    const g = c.createLinearGradient(0, 0, 0, H); g.addColorStop(0, '#ffe9b8'); g.addColorStop(1, '#f2b880'); c.fillStyle = g; c.fillRect(0, 0, W, H);
    c.fillStyle = '#9ad8ff'; c.fillRect(W * 0.58, H * 0.1, W * 0.32, H * 0.2);
    c.fillStyle = '#ffe04a'; c.beginPath(); c.arc(W * 0.72, H * 0.18, Math.min(W, H) * 0.045 + Math.sin(t * 2) * 2, 0, TAU); c.fill();
    c.strokeStyle = '#ffffff'; c.lineWidth = 6; c.strokeRect(W * 0.58, H * 0.1, W * 0.32, H * 0.2);
    for (let i = 0; i < 12; i++) for (let j = 0; j < 6; j++) { c.fillStyle = (i + j) % 2 ? '#e8dcc8' : '#d0c4ae'; c.fillRect(i * W / 12, H * 0.62 + j * H * 0.07, W / 12 + 1, H * 0.07 + 1); }
    const ks = Math.min(5, W / 70), empty = t > 3.2;
    for (let k = 0; k < 3; k++) {
      const x = W * (0.22 + k * 0.28), y = H * 0.76;
      c.fillStyle = ['#ff6a8a', '#6ac8ff', '#ffd25a'][k]; c.beginPath(); c.ellipse(x, y, 34, 13, 0, 0, TAU); c.fill();
      c.fillStyle = empty ? '#3a2a20' : '#c87a3a'; c.beginPath(); c.ellipse(x, y - 3, 25, 8, 0, 0, TAU); c.fill();
      if (!empty) { c.fillStyle = '#a05a2a'; for (let m = 0; m < 6; m++) { c.beginPath(); c.arc(x - 12 + m * 5, y - 6 + (m % 2) * 2, 3, 0, TAU); c.fill(); } }
    }
    const det = t > 9.4;
    drawTessa(c, W * 0.5, H * 0.58, t, t > 6.4 && t < 9.4 ? (Math.sin(t * 2) > 0 ? 1 : -1) : 1, ks, 1, false, TESSA_PAL, det ? 'hat' : 'none');
    if (empty && !det) { c.fillStyle = '#5a2a10'; c.font = `900 ${Math.round(18 + ks * 4)}px Krilessa Icons, sans-serif`; c.textAlign = 'center'; c.fillText('?!', W * 0.5 + 10, H * 0.58 - ks * 16); }
    if (t > 12.6) {
      const lx = W * 0.5 + Math.sin(t * 1.5) * W * 0.25, ly = H * 0.42 + Math.cos(t * 1.2) * 20;
      c.strokeStyle = '#6a4a2a'; c.lineWidth = 8; c.beginPath(); c.moveTo(lx + 26, ly + 26); c.lineTo(lx + 56, ly + 56); c.stroke();
      c.strokeStyle = '#d8a050'; c.lineWidth = 6; c.beginPath(); c.arc(lx, ly, 34, 0, TAU); c.stroke(); c.fillStyle = 'rgba(200,240,255,0.35)'; c.fill();
    }
  }
  function drawCh6(dt) {
    const [W, H] = setup();
    const ks = Math.min(4.2, W / 90), night = clamp((t - 3.2) / 3, 0, 1);
    const mix = (a, b) => `rgb(${a.map((v, i) => Math.round(lerp(v, b[i], night))).join(',')})`;
    const g = c.createLinearGradient(0, 0, 0, H); g.addColorStop(0, mix([255, 196, 140], [10, 20, 52])); g.addColorStop(1, mix([255, 150, 110], [30, 46, 90]));
    c.fillStyle = g; c.fillRect(0, 0, W, H);
    if (lightning > 0) { c.fillStyle = `rgba(190,234,255,${lightning * 0.5})`; c.fillRect(0, 0, W, H); lightning -= dt * 2; }
    // северное сияние
    if (night > 0.3) for (let k = 0; k < 3; k++) {
      c.strokeStyle = ['rgba(90,255,180,', 'rgba(120,200,255,', 'rgba(200,120,255,'][k] + (0.25 * night) + ')'; c.lineWidth = 26 - k * 6;
      c.beginPath(); for (let x = 0; x <= W; x += 20) { const y = H * (0.14 + k * 0.06) + Math.sin(x * 0.012 + t * 0.8 + k) * 22; if (x) c.lineTo(x, y); else c.moveTo(x, y); } c.stroke();
    }
    // земля: трава превращается в снег
    c.fillStyle = mix([110, 190, 90], [236, 244, 252]); c.fillRect(0, H * 0.7, W, H * 0.3);
    // банкет
    if (t < 9.6) {
      const tx = W * 0.5, ty = H * 0.66;
      c.fillStyle = '#c8945a'; c.fillRect(tx - W * 0.28, ty, W * 0.56, 10);
      c.fillStyle = '#ffffff'; c.fillRect(tx - 30, ty - 30, 60, 30); c.fillStyle = '#ff6fb5'; c.fillRect(tx - 30, ty - 30, 60, 8);
      c.fillStyle = '#ffd25a'; for (let k = -2; k <= 2; k++) c.fillRect(tx + k * 11 - 1, ty - 42, 3, 12);
      if (night < 0.5) for (let k = -2; k <= 2; k++) { c.fillStyle = '#ff8a2a'; c.beginPath(); c.arc(tx + k * 11, ty - 45 + Math.sin(t * 10 + k) * 1.5, 3, 0, TAU); c.fill(); }
    }
    const tY = t < 9.6 ? H * 0.6 : lerp(H * 0.6, H * 0.12, ease(clamp((t - 9.6) / 2.4, 0, 1)));
    if (t < 12.8) {
      drawTessa(c, W * 0.5, tY, t, 1, ks * 0.8, 1, false, TESSA_PAL, 'none');
      if (t >= 9.6) { c.fillStyle = 'rgba(170,220,255,0.5)'; c.strokeStyle = '#ffffff'; c.lineWidth = 2; roundRect(c, W * 0.5 - ks * 13, tY - ks * 26, ks * 26, ks * 30, 8); c.fill(); c.stroke(); }
    }
    // Мрак в ледяной короне
    if (t >= 6.4 && t < 12.8) {
      const a = clamp((t - 6.4) / 0.8, 0, 1) * (1 - clamp((t - 12) / 0.8, 0, 1));
      c.save(); c.globalAlpha = a; c.translate(W * 0.5, H * 0.24 + Math.sin(t * 2) * 6); c.scale(ks * 0.42, ks * 0.42);
      BSPR.mrak2(c, { kind: 'mrak2', flash: 0, stage: 2, look: 1.57, mode: 'idle', charging: false, anim: t, z: 0 }, t, 1);
      c.restore();
    }
    // героини
    const sep = t < 12.8 ? 0.3 : 0.2;
    drawHero('krilessa', c, W * (0.5 - sep), H * 0.66, t, 1, ks * 0.9, 1, t > 12.8);
    drawHero('ryzhovaya', c, W * (0.5 + sep), H * 0.66, t, -1, ks * 0.9, 1, t > 12.8);
    if (t < 3.2) for (let i = 0; i < 5; i++) { c.fillStyle = '#ff5b8a'; heartPath(c, W * 0.5 + Math.sin(t * 2 + i) * 70, H * 0.5 - ((t * 40 + i * 30) % 140), 7); c.fill(); }
    if (t >= 12.8) { c.font = `900 ${Math.round(24 + ks * 4)}px Krilessa Icons, sans-serif`; c.textAlign = 'center'; c.fillStyle = '#ffffff'; c.fillText('🔄', W * 0.5, H * 0.6 + Math.sin(t * 4) * 4); }
    // снег
    if (t >= 3.2) {
      c.fillStyle = '#ffffff';
      for (let i = 0; i < 90; i++) {
        const x = (hash2(i, 1) * W + Math.sin(t + i) * 20 + t * 15) % W, y = (hash2(i, 2) * H + t * (40 + hash2(i, 3) * 60)) % H;
        c.globalAlpha = 0.5 + hash2(i, 4) * 0.5; c.beginPath(); c.arc(x, y, 1.5 + hash2(i, 5) * 2, 0, TAU); c.fill();
      }
      c.globalAlpha = 1;
    }
  }
  function drawCh7(dt) {
    const [W, H] = setup();
    const ks = Math.min(4.2, W / 90), dive = ease(clamp((t - 9.6) / 2.6, 0, 1)), dark = clamp((t - 3.2) / 1.2, 0, 1) * (1 - dive * 0.4);
    const shake = t >= 3.2 && t < 4.6 ? Math.sin(t * 60) * 5 * (4.6 - t) : 0;
    c.save(); c.translate(shake, 0);
    // небо и море; при нырке камера уходит под воду
    const sea = H * lerp(0.46, -0.1, dive);
    const g = c.createLinearGradient(0, 0, 0, H); g.addColorStop(0, `rgb(${lerp(255, 40, dark) | 0},${lerp(190, 60, dark) | 0},${lerp(140, 110, dark) | 0})`); g.addColorStop(1, `rgb(${lerp(255, 20, dark) | 0},${lerp(220, 40, dark) | 0},${lerp(180, 80, dark) | 0})`);
    c.fillStyle = g; c.fillRect(-10, 0, W + 20, H);
    if (lightning > 0) { c.fillStyle = `rgba(255,90,120,${lightning * 0.45})`; c.fillRect(-10, 0, W + 20, H); lightning -= dt * 2; }
    const wg = c.createLinearGradient(0, sea, 0, H); wg.addColorStop(0, '#1ab0d8'); wg.addColorStop(0.5, '#0a5a9a'); wg.addColorStop(1, '#03204a');
    c.fillStyle = wg; c.beginPath(); c.moveTo(-10, H); for (let x = -10; x <= W + 10; x += 10) c.lineTo(x, sea + Math.sin(x * 0.03 + t * 2) * 5); c.lineTo(W + 10, H); c.closePath(); c.fill();
    // лучи света под водой
    for (let k = 0; k < 4; k++) { const x0 = W * (0.15 + k * 0.25) + Math.sin(t * 0.5 + k) * 16; c.fillStyle = `rgba(180,240,255,${0.06 + dive * 0.06})`; c.beginPath(); c.moveTo(x0 - 10, Math.max(0, sea)); c.lineTo(x0 + 10, Math.max(0, sea)); c.lineTo(x0 + 70, H); c.lineTo(x0 - 50, H); c.closePath(); c.fill(); }
    // песок пляжа (уезжает вверх при нырке)
    const sandY = H * lerp(0.7, -0.3, dive);
    if (sandY > -40) { c.fillStyle = '#f0d49a'; c.beginPath(); c.moveTo(-10, sandY); c.quadraticCurveTo(W * 0.5, sandY - 30, W + 10, sandY + 10); c.lineTo(W + 10, sandY + 80); c.lineTo(-10, sandY + 80); c.closePath(); c.fill(); }
    // дно с кораллами – появляется при нырке
    if (dive > 0) {
      const fy = H * lerp(1.2, 0.8, dive);
      c.fillStyle = '#c8a46a'; c.beginPath(); c.moveTo(-10, H); c.lineTo(-10, fy); for (let x = 0; x <= W + 10; x += 20) c.lineTo(x, fy + Math.sin(x * 0.05) * 8); c.lineTo(W + 10, H); c.closePath(); c.fill();
      for (let k = 0; k < 6; k++) { const x = W * (0.08 + k * 0.17), h2 = 30 + hash2(k, 7) * 40; c.strokeStyle = ['#ff6f9a', '#ffa24a', '#c86aff'][k % 3]; c.lineWidth = 6; c.lineCap = 'round'; c.beginPath(); c.moveTo(x, fy + 6); c.quadraticCurveTo(x + Math.sin(t + k) * 10, fy - h2 / 2, x + 6, fy - h2); c.stroke(); }
    }
    // стая криля уносит сердечки-слова
    if (t >= 3.2) {
      const a = clamp((t - 3.2) / 1, 0, 1);
      for (let i = 0; i < 46; i++) {
        const ph = hash2(i, 21) * TAU, r = 30 + hash2(21, i) * 90, cx = W * 0.5 + Math.sin(t * 0.7) * W * 0.18, cy = Math.max(sea + 40, H * 0.62) + Math.cos(t * 0.5) * 30;
        const x = cx + Math.cos(ph + t * 1.1) * r, y = cy + Math.sin(ph * 1.7 + t * 1.3) * r * 0.5;
        c.globalAlpha = a; Story.drawKrill(c, x, y, ph + t * 1.1 + Math.PI / 2, 0.9 + hash2(i, 22) * 0.5, t + ph); c.globalAlpha = 1;
      }
      if (t >= 6.4 && t < 9.6) for (let i = 0; i < 7; i++) { const k = clamp((t - 6.4 - i * 0.2) / 2.6, 0, 1); c.globalAlpha = 1 - k * 0.7; c.fillStyle = '#ff5b8a'; heartPath(c, W * (0.2 + i * 0.1), lerp(H * 0.4, H * 0.95, k), 8); c.fill(); c.globalAlpha = 1; }
    }
    // ругательство со дна
    if (t >= 3.2 && t < 6.4) {
      const a = Math.min(1, (t - 3.2) * 3) * (1 - clamp((t - 5.8) / 0.6, 0, 1));
      c.globalAlpha = a; c.font = `900 ${Math.round(22 + ks * 5)}px Krilessa Icons, sans-serif`; c.textAlign = 'center'; c.fillStyle = '#ff3b5b'; c.strokeStyle = '#3a0010'; c.lineWidth = 5;
      c.strokeText('КРИЛЯТЬ!!!', W * 0.5, H * 0.3); c.fillText('КРИЛЯТЬ!!!', W * 0.5, H * 0.3); c.globalAlpha = 1;
    }
    // героини: на песке, потом плывут
    const hy = dive > 0 ? lerp(sandY - 10, H * 0.5, dive) : sandY - 10, bob = dive * Math.sin(t * 2) * 8;
    drawHero('krilessa', c, W * 0.28, hy + bob, t, 1, ks * 0.85, 1, t > 12.8);
    drawHero('ryzhovaya', c, W * 0.72, hy - bob, t, -1, ks * 0.85, 1, t > 12.8);
    drawTessa(c, W * 0.5, hy + 4 + Math.sin(t * 2.4) * 6 * dive, t, 1, ks * 0.7, 1, false, TESSA_PAL, 'none');
    if (t >= 9.6) { // пузырь-шлем
      const a = clamp((t - 9.6) / 0.5, 0, 1), R = ks * 13;
      c.globalAlpha = a; c.strokeStyle = 'rgba(220,250,255,0.9)'; c.lineWidth = 2.5; c.fillStyle = 'rgba(170,230,255,0.18)';
      c.beginPath(); c.arc(W * 0.5, hy - ks * 9, R, 0, TAU); c.fill(); c.stroke();
      c.fillStyle = 'rgba(255,255,255,0.7)'; c.beginPath(); c.ellipse(W * 0.5 - R * 0.45, hy - ks * 9 - R * 0.45, R * 0.18, R * 0.1, -0.7, 0, TAU); c.fill(); c.globalAlpha = 1;
    }
    // пузыри
    if (dive > 0) { c.strokeStyle = 'rgba(220,250,255,0.7)'; c.lineWidth = 1.4; for (let i = 0; i < 40; i++) { const k = (t * (0.12 + hash2(i, 31) * 0.15) + hash2(31, i)) % 1, x = hash2(i, 32) * W + Math.sin(t * 2 + i) * 6; c.beginPath(); c.arc(x, H * (1 - k), 1.5 + hash2(i, 33) * 4, 0, TAU); c.stroke(); } }
    c.restore();
  }
  function drawEnd7(dt) {
    const [W, H] = setup();
    const land = W > H, ks = Math.min(4.2, Math.min(W, H * 0.6) / 90), hor = H * (land ? 0.33 : 0.42), shore = H * (land ? 0.5 : 0.64), PW = Math.min(W, H * 0.62); // лёжа – всё выше, над текстом
    const R = Math.min(W, H) * 0.15, sunX = W * 0.5, sunY = hor - R * 0.35 + Math.min(t, 18) * R * 0.022; // солнце медленно садится
    // небо заката
    const g = c.createLinearGradient(0, 0, 0, hor);
    g.addColorStop(0, '#1c1046'); g.addColorStop(0.35, '#5a2470'); g.addColorStop(0.7, '#d8587a'); g.addColorStop(1, '#ffb46a');
    c.fillStyle = g; c.fillRect(0, 0, W, hor + 2);
    for (let i = 0; i < 26; i++) { c.fillStyle = `rgba(255,255,255,${(0.2 + 0.4 * Math.abs(Math.sin(t * 1.3 + i))) * (1 - hash2(i, 3) * 0.6)})`; c.fillRect(hash2(i, 1) * W, hash2(i, 2) * hor * 0.35, 1.6, 1.6); }
    // солнце и его сияние
    const sg = c.createRadialGradient(sunX, sunY, R * 0.6, sunX, sunY, R * 3.2); sg.addColorStop(0, 'rgba(255,210,120,0.55)'); sg.addColorStop(1, 'rgba(255,120,90,0)');
    c.fillStyle = sg; c.fillRect(0, 0, W, hor);
    const sd = c.createLinearGradient(0, sunY - R, 0, sunY + R); sd.addColorStop(0, '#fff6b0'); sd.addColorStop(1, '#ff7a4a');
    c.save(); c.beginPath(); c.rect(0, 0, W, hor); c.clip(); c.fillStyle = sd; c.beginPath(); c.arc(sunX, sunY, R, 0, TAU); c.fill(); c.restore();
    // облака, подсвеченные снизу
    for (let k = 0; k < 5; k++) {
      const cx = ((hash2(k, 5) * W * 1.4 + t * (6 + k * 2)) % (W * 1.4)) - W * 0.2, cy = hor * (0.25 + hash2(5, k) * 0.5), cw = W * (0.18 + hash2(k, 6) * 0.2);
      const cg = c.createLinearGradient(0, cy - 8, 0, cy + 8); cg.addColorStop(0, 'rgba(120,50,120,0.55)'); cg.addColorStop(1, 'rgba(255,150,140,0.75)');
      c.fillStyle = cg; c.beginPath(); c.ellipse(cx, cy, cw, 6 + hash2(k, 7) * 5, 0, 0, TAU); c.ellipse(cx + cw * 0.4, cy - 5, cw * 0.5, 5, 0, 0, TAU); c.fill();
    }
    // чайки
    c.strokeStyle = 'rgba(40,16,50,0.75)'; c.lineWidth = 2; c.lineCap = 'round';
    for (let k = 0; k < 4; k++) { const bx = ((t * (22 + k * 6) + hash2(k, 8) * W) % (W + 60)) - 30, by = hor * (0.2 + k * 0.12) + Math.sin(t * 2 + k) * 6, f = Math.sin(t * 7 + k) * 3, s2 = 5 + k; c.beginPath(); c.moveTo(bx - s2, by - f); c.quadraticCurveTo(bx - s2 * 0.4, by - 3, bx, by); c.quadraticCurveTo(bx + s2 * 0.4, by - 3, bx + s2, by - f); c.stroke(); }
    // море
    const sea = c.createLinearGradient(0, hor, 0, shore); sea.addColorStop(0, '#ff9a72'); sea.addColorStop(0.25, '#b05a8a'); sea.addColorStop(1, '#3a3a86');
    c.fillStyle = sea; c.fillRect(0, hor, W, shore - hor + 30);
    // солнечная дорожка и блики
    for (let y = hor + 2; y < shore; y += 4) {
      const k = (y - hor) / (shore - hor), half = R * (0.4 + k * 1.8), n = 3;
      for (let j = 0; j < n; j++) {
        const ph = hash2(Math.floor(y), j), x = sunX + (ph - 0.5) * 2 * half + Math.sin(t * 2 + y * 0.3 + j) * 6, a = (0.35 + 0.5 * Math.abs(Math.sin(t * 3 + y + j * 2))) * (1 - k * 0.5);
        c.fillStyle = `rgba(255,${220 - k * 60 | 0},${150 - k * 40 | 0},${a})`; c.fillRect(x - (4 + k * 10), y, 8 + k * 20, 1.6);
      }
    }
    c.strokeStyle = 'rgba(255,200,180,0.18)'; c.lineWidth = 1;
    for (let k = 0; k < 7; k++) { const y = hor + (shore - hor) * (0.15 + k * 0.12); c.beginPath(); for (let x = 0; x <= W; x += 12) { const yy = y + Math.sin(x * 0.04 + t * 1.5 + k) * 1.5; if (x) c.lineTo(x, yy); else c.moveTo(x, yy); } c.stroke(); }
    // Крильятин: у берега, потом уплывает к солнцу и тает вдали
    const away = ease(clamp((t - 13.6) / 4.2, 0, 1));
    const kx = lerp(W * 0.74, sunX - R * 0.1, away), ky = lerp(shore - 18, hor + 3, Math.pow(away, 0.8)) + Math.sin(t * 2.2) * 3 * (1 - away), ksc = ks * 0.3 * lerp(1, 0.12, away);
    const jumpK = clamp((away - 0.6) / 0.32, 0, 1), jump = Math.sin(jumpK * Math.PI); // напоследок – прыжок сквозь солнце
    if (jumpK > 0 && jumpK < 1) for (const k2 of [0, 1]) { const rk = Math.abs(jumpK - k2); if (rk < 0.25) { c.strokeStyle = `rgba(255,240,220,${0.8 * (1 - rk / 0.25)})`; c.lineWidth = 1.2; c.beginPath(); c.ellipse(kx + (k2 ? -6 : 6), ky + 2, 6 + (0.25 - rk) * 60, 2 + (0.25 - rk) * 6, 0, 0, TAU); c.stroke(); } }
    if (away > 0) { // след на воде
      c.strokeStyle = `rgba(255,230,200,${0.5 * (1 - away * 0.6)})`; c.lineWidth = 1.5;
      for (let k = 1; k <= 4; k++) { const d = (k * 14 + 6) * lerp(1, 0.15, away); c.beginPath(); c.moveTo(kx + d * 1.6, ky + d * 0.5); c.lineTo(kx, ky + 2); c.lineTo(kx + d * 0.4, ky + d * 0.9); c.stroke(); }
    }
    // стайка криля плывёт за королём
    for (let i = 0; i < 14; i++) { const a = t * 1.4 + i * 0.9, x = kx + ksc * 90 + Math.cos(a) * 20 * (1 - away * 0.8) + i * 3 * (1 - away), y = ky + 6 + Math.sin(a * 1.3) * 8 * (1 - away * 0.8); c.fillStyle = 'rgba(255,140,170,0.9)'; c.beginPath(); c.ellipse(x, y, 2.6 * (1 - away * 0.7), 1.2 * (1 - away * 0.7), a, 0, TAU); c.fill(); }
    c.save(); c.translate(kx, ky - jump * R * 1.05); c.scale(ksc, ksc);
    if (jump > 0) c.rotate((0.5 - jumpK) * 1.3); // нос вверх – нос вниз
    c.save();
    if (jump < 0.02) { c.beginPath(); c.rect(-140, -120, 280, 126); c.clip(); } // по пояс в воде
    const sil = clamp((away - 0.35) * 1.8, 0, 1); // у солнца – тёмный силуэт
    if (sil > 0) c.filter = `brightness(${lerp(1, 0.18, sil).toFixed(2)})`;
    BSPR.krillyatin(c, { kind: 'krillyatin', flash: 0, stage: 0, look: Math.PI, mode: 'idle', state: 'end', happy: t >= 10.2, anim: t, z: 0 }, t, 1);
    c.filter = 'none'; c.restore(); c.restore();
    if (jump < 0.02 && away < 1) { c.strokeStyle = 'rgba(255,240,220,0.7)'; c.lineWidth = 1.5; c.beginPath(); c.ellipse(kx, ky + 4, ksc * 70, 4 * (1 - away * 0.7), 0, 0, TAU); c.stroke(); }
    // берег: мокрый песок, пена, сухой песок
    const foam = shore + Math.sin(t * 0.9) * 7;
    const sand = c.createLinearGradient(0, shore, 0, H); sand.addColorStop(0, '#e8a872'); sand.addColorStop(0.3, '#f2c08a'); sand.addColorStop(1, '#b8785a');
    c.fillStyle = '#c8886a'; c.beginPath(); c.moveTo(0, foam + 4); for (let x = 0; x <= W; x += 10) c.lineTo(x, foam + 4 + Math.sin(x * 0.05 + t) * 3); c.lineTo(W, H); c.lineTo(0, H); c.closePath(); c.fill();
    c.fillStyle = sand; c.beginPath(); c.moveTo(0, shore + 16); c.quadraticCurveTo(W * 0.5, shore + 4, W, shore + 18); c.lineTo(W, H); c.lineTo(0, H); c.closePath(); c.fill();
    c.strokeStyle = 'rgba(255,255,255,0.85)'; c.lineWidth = 2.5; c.beginPath(); for (let x = 0; x <= W; x += 8) { const y = foam + Math.sin(x * 0.06 + t * 1.7) * 2.5; if (x) c.lineTo(x, y); else c.moveTo(x, y); } c.stroke();
    // ракушки и морская звезда
    for (const [fx, fy, e] of [[0.12, 0.86, '🐚'], [0.86, 0.8, '⭐'], [0.62, 0.93, '🐚']]) { c.font = `${Math.round(10 + ks * 3)}px Krilessa Icons, sans-serif`; c.textAlign = 'center'; c.fillText(e, W * fx, H * fy); }
    // пальма-силуэт
    const px = land ? W * 0.12 : W * 0.08, py = H * 0.9, sw = Math.sin(t * 0.8) * 4, ph2 = land ? H * 0.5 : H * 0.34;
    c.strokeStyle = '#3a1634'; c.lineWidth = 7 + ks; c.lineCap = 'round'; c.beginPath(); c.moveTo(px, py); c.quadraticCurveTo(px + PW * 0.06, py - ph2 * 0.6, px + PW * 0.1 + sw, py - ph2); c.stroke();
    c.fillStyle = '#3a1634';
    for (let k = 0; k < 6; k++) { const a = -Math.PI / 2 + (k - 2.5) * 0.55 + Math.sin(t + k) * 0.04, tx = px + PW * 0.1 + sw, ty = py - ph2, L = PW * 0.16; c.beginPath(); c.moveTo(tx, ty); c.quadraticCurveTo(tx + Math.cos(a - 0.4) * L * 0.6, ty + Math.sin(a - 0.4) * L * 0.6 - 8, tx + Math.cos(a) * L, ty + Math.sin(a) * L + L * 0.25); c.quadraticCurveTo(tx + Math.cos(a + 0.3) * L * 0.5, ty + Math.sin(a + 0.3) * L * 0.5, tx, ty); c.fill(); }
    // подруги на песке машут вслед
    const hy = H * (land ? 0.6 : 0.71), hs = land ? H * 0.0046 : Math.min(ks * 0.58, H * 0.0034), wave = t >= 10.2 ? Math.sin(t * 6) * 3 : 0;
    for (const [id, fx2, face, ph] of [['krilessa', land ? 0.38 : 0.26, 1, 0], ['ryzhovaya', land ? 0.62 : 0.74, -1, 1.3]]) {
      c.fillStyle = 'rgba(60,20,40,0.28)'; c.beginPath(); c.ellipse(W * fx2, hy + 8, 20, 5, 0, 0, TAU); c.fill();
      drawHero(id, c, W * fx2, hy - Math.abs(t >= 10.2 ? Math.sin(t * 6 + ph) * 3 : 0), t, face, hs, 1, t >= 10.2);
    }
    c.fillStyle = 'rgba(60,20,40,0.28)'; c.beginPath(); c.ellipse(W * 0.5, hy + 14, 18, 4, 0, 0, TAU); c.fill();
    drawTessa(c, W * 0.5, hy + 6 - Math.abs(wave) * 0.5, t, 1, hs * 0.8, 1, false, TESSA_PAL, 'none');
    // сердечки летят к Крильятину
    if (t >= 10.2) for (let i = 0; i < 6; i++) { const k = ((t - 10.2) * 0.35 + i / 6) % 1; c.globalAlpha = Math.sin(k * Math.PI) * 0.9; c.fillStyle = i % 2 ? '#ff5b8a' : '#ff9ad0'; heartPath(c, lerp(W * (0.26 + (i % 3) * 0.24), kx, k) + Math.sin(t * 3 + i) * 10, lerp(hy - 50, ky - 20, k) - Math.sin(k * Math.PI) * 50, (6 + i % 3) * (1 - k * 0.5)); c.fill(); }
    c.globalAlpha = 1;
    // мягкая виньетка и проявление из темноты
    const vg = c.createRadialGradient(W / 2, H * 0.45, Math.min(W, H) * 0.3, W / 2, H / 2, Math.max(W, H) * 0.75); vg.addColorStop(0, 'rgba(0,0,0,0)'); vg.addColorStop(1, 'rgba(30,10,40,0.55)');
    c.fillStyle = vg; c.fillRect(0, 0, W, H);
    if (t < 1.2) { c.fillStyle = `rgba(6,20,40,${1 - t / 1.2})`; c.fillRect(0, 0, W, H); }
  }
  function drawCh3(dt) {
    const [W, H] = setup();
    const ks = Math.min(4, W / 110);
    const mir = clamp((t - 6) / 1, 0, 1) * (1 - clamp((t - 12.2) / 0.8, 0, 1));
    const fire = clamp((t - 12.2) / 0.8, 0, 1);
    const top = fire > 0 ? `rgb(${lerp(42, 110, fire) | 0},${lerp(30, 30, fire) | 0},${lerp(70, 20, fire) | 0})`
      : mir > 0 ? `rgb(${lerp(42, 70, mir) | 0},${lerp(22, 80, mir) | 0},${lerp(64, 120, mir) | 0})` : '#2a1640';
    bg(W, H, top, '#0a0614');
    if (lightning > 0) { c.fillStyle = `rgba(255,120,220,${lightning * 0.5})`; c.fillRect(0, 0, W, H); lightning -= dt * 2; }
    const cw = Math.min(W * 0.62, H * 0.38 * 0.75);
    // подруги вместе
    if (t < 3.4) {
      const a = 1 - clamp((t - 2.8) / 0.6, 0, 1), R = Math.min(W, H) * 0.12;
      c.globalAlpha = a;
      if (Session.AVATAR.ryzhovaBig) { c.save(); c.beginPath(); c.arc(W * 0.32, H * 0.56, R, 0, TAU); c.clip(); c.drawImage(Session.AVATAR.ryzhovaBig, W * 0.32 - R, H * 0.56 - R, R * 2, R * 2); c.restore(); }
      c.strokeStyle = '#ff7a2f'; c.lineWidth = 5; c.beginPath(); c.arc(W * 0.32, H * 0.56, R, 0, TAU); c.stroke();
      for (let i = 0; i < 6; i++) { c.fillStyle = '#ff5b8a'; heartPath(c, W * 0.5 + Math.sin(t * 2 + i) * 60, H * 0.5 - ((t * 40 + i * 30) % 140), 8); c.fill(); }
      c.globalAlpha = 1;
      drawKrilessa(c, W * 0.7, H * 0.6 + Math.sin(t * 3) * 6, t, -1, ks, a, true);
    }
    // зеркала
    if (t >= 3 && t < 6.4) {
      const k = ease((t - 3) / 0.6), out = 1 - clamp((t - 5.8) / 0.6, 0, 1);
      for (let i = 0; i < 6; i++) {
        const px = W * (0.2 + (i % 3) * 0.3), py = H * (0.24 + Math.floor(i / 3) * 0.3) + Math.sin(t * 6 + i) * 4;
        const pw = Math.min(W * 0.2, 90) * k, ph = pw * 1.8;
        c.save(); c.globalAlpha = out; c.translate(px, py); c.rotate(Math.sin(i * 2.1) * 0.2);
        c.fillStyle = '#d9a640'; c.beginPath(); c.ellipse(0, 0, pw / 2 + 5, ph / 2 + 5, 0, 0, TAU); c.fill();
        c.strokeStyle = '#7a4a10'; c.lineWidth = 2; c.stroke();
        if (pw > 4) {
          const g = Math.random() < 0.1 ? rnd(-4, 4) : 0;
          c.save(); c.beginPath(); c.ellipse(0, 0, pw / 2, ph / 2, 0, 0, TAU); c.clip();
          const mg = c.createLinearGradient(-pw / 2, -ph / 2, pw / 2, ph / 2); mg.addColorStop(0, '#bfe6ff'); mg.addColorStop(0.5, '#ff9ad8'); mg.addColorStop(1, '#6a4aa0');
          c.fillStyle = mg; c.fillRect(-pw / 2, -ph / 2, pw, ph);
          if (ART.zyamaFace) c.drawImage(ART.zyamaFace, -pw / 2 + 2 + g, -pw / 2 + ph * 0.18, pw - 4, pw - 4);
          c.fillStyle = 'rgba(255,255,255,0.35)'; c.beginPath(); c.ellipse(-pw * 0.18, -ph * 0.25, pw * 0.08, ph * 0.18, 0.4, 0, TAU); c.fill();
          c.restore();
        }
        c.restore();
      }
      c.globalAlpha = out; c.font = `900 ${Math.min(W * 0.09, 40)}px Krilessa Icons, "Trebuchet MS", sans-serif`; c.textAlign = 'center';
      c.fillStyle = '#3a0a3a'; c.fillText('«Трепещите, зайки!»', W / 2 + 2, H * 0.84 + 2);
      c.fillStyle = '#ff3ea5'; c.fillText('«Трепещите, зайки!»', W / 2, H * 0.84);
      c.globalAlpha = 1;
    }
    // Зямочкккк 2.0
    if (t >= 6.2 && t < 12.6) {
      const ap = ease((t - 6.2) / 0.8), fade = 1 - clamp((t - 12) / 0.6, 0, 1);
      let sc = 0.3 + 0.7 * ap;
      if (t < 8) sc *= 1 + 0.08 * Math.sin((t - 6.2) * 12) * Math.exp(-(t - 6.2) * 2.5);
      const cy = t < 9.2 ? H * 0.42 : lerp(H * 0.42, H * 0.3, ease((t - 9.2) / 0.8));
      for (let k = 0; k < 8; k++) {
        const a = t * 1.2 + k * TAU / 8, rr = cw * 0.95;
        c.save(); c.globalAlpha = 0.8 * fade; c.translate(W / 2 + Math.cos(a) * rr, cy + Math.sin(a) * rr * 0.9); c.rotate(a);
        c.fillStyle = '#bfeaff'; c.beginPath(); c.moveTo(0, -14); c.lineTo(9, 0); c.lineTo(0, 14); c.lineTo(-9, 0); c.closePath(); c.fill();
        c.strokeStyle = '#fff'; c.lineWidth = 2; c.stroke(); c.restore();
      }
      card(Session.IMG.zyama, W / 2, cy, cw * (t < 9.2 ? 1 : 0.8), sc, 0.04 * Math.sin(t * 2), ap * fade, 1, '★ ЗЯМОЧКККК 2.0 ★', 0, ['#bfeaff'], dt);
      if (t < 9.2) title(W, ease((t - 6.2) / 0.6), 'ЗЯМОЧКККК 2.0', 'Зеркальный Император', '#bfeaff', '#2a3a6a');
    }
    // Крилессу затягивает в зеркало
    if (t >= 9.2 && t < 12.6) {
      const k = ease((t - 9.6) / 2.2), out = 1 - clamp((t - 12) / 0.6, 0, 1);
      const mx = W / 2, my = H * 0.7, mr = Math.min(W, H) * 0.16;
      c.globalAlpha = out;
      c.fillStyle = '#ffd25a'; c.beginPath(); c.ellipse(mx, my, mr + 10, mr * 1.3 + 10, 0, 0, TAU); c.fill();
      const gr = c.createLinearGradient(mx - mr, my - mr, mx + mr, my + mr); gr.addColorStop(0, '#ffffff'); gr.addColorStop(0.5, '#9ad8f8'); gr.addColorStop(1, '#7a5aff');
      c.fillStyle = gr; c.beginPath(); c.ellipse(mx, my, mr, mr * 1.3, 0, 0, TAU); c.fill();
      for (let i = 0; i < 4; i++) { c.strokeStyle = `rgba(255,255,255,${0.5 - i * 0.1})`; c.lineWidth = 3; c.beginPath(); c.ellipse(mx, my, mr * (0.8 - i * 0.18), mr * 1.3 * (0.8 - i * 0.18), t * (i % 2 ? 2 : -2), 0, TAU * 0.8); c.stroke(); }
      c.globalAlpha = 1;
      c.save(); c.translate(lerp(W * 0.15, mx, k), lerp(my, my, k)); c.rotate(k * 6);
      drawKrilessa(c, 0, 0, t, 1, ks * (1 - k * 0.9), (1 - k * 0.8) * out, true);
      c.restore();
    }
    // огненное превращение Рыжовой
    if (t >= 12.2) {
      const ap = ease((t - 12.2) / 0.6);
      const tk = ease((t - 15.6) / 0.8);
      const cy = H * 0.42 - tk * H * 0.04, sc = (0.6 + 0.4 * ap) * (1 - tk * 0.2);
      if (Math.random() < 0.8) flames.push({ x: W / 2 + rnd(-cw * 0.6, cw * 0.6), y: cy + cw * 0.6, vy: rnd(-160, -60), r: rnd(6, 16), life: 1 });
      for (const f of flames) { f.y += f.vy * dt; f.life -= dt * 0.9; f.r *= 0.995; }
      flames = flames.filter(f => f.life > 0);
      c.globalCompositeOperation = 'lighter';
      for (const f of flames) { c.fillStyle = `rgba(255,${(120 + f.life * 100) | 0},40,${f.life * 0.5})`; c.beginPath(); c.arc(f.x, f.y, f.r, 0, TAU); c.fill(); }
      c.globalCompositeOperation = 'source-over';
      const wipe = clamp((t - story.wipe[0]) / (story.wipe[1] - story.wipe[0]), 0, 1);
      card(Session.IMG.ryzhova, W / 2, cy, cw, sc, -0.03, ap, wipe, '🔥 Рыжовая 🔥', 0, ['#ff8a2a', '#ffd23a', '#ff4a1a'], dt);
      if (t >= 15.6) {
        title(W, tk, 'Глава 3', 'Рыжовая спешит на помощь', '#ff9a3a', '#5a1a00');
        drawRyzhovaya(c, lerp(-60, W * 0.76, ease((t - 15.8) / 1.4)), cy + cw * 4 / 3 * sc * 0.62 + Math.sin(t * 3) * 6, t, 1, ks * 1.1, tk, true);
      }
    }
  }
  return { start, skip };
})();
