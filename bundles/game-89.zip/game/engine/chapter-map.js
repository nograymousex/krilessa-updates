'use strict';

const ChapterMap = (() => {
  // ------------------------------------------------------------------
  //  Большая карта (нажми на мини-карту)
  // ------------------------------------------------------------------
  // большая карта: приближение двумя пальцами (или «+ / −», двойной тап), перетаскивание одним пальцем
  const MV = { z: 1, cx: 0, cy: 0, S: 0, ptrs: new Map(), pinch: null, lastTap: 0, raf: 0 };
  function openMap() {
    Screens.setState('mapscr'); Sound.sfx.click();
    const cv = $('mapCanvas'), d = Math.min(window.devicePixelRatio || 1, 2);
    const land = Viewport.VW > Viewport.VH && Viewport.VH < 540; // лёжа: карта слева во всю высоту, легенда справа
    const S = Math.max(160, Math.floor(land ? Math.min(Viewport.VH - 36, Viewport.VW - 420) : Math.min(Viewport.VW - 24, Viewport.VH - 240)));
    cv.style.width = S + 'px'; cv.style.height = S + 'px'; cv.width = Math.round(S * d); cv.height = Math.round(S * d);
    MV.S = S; MV.d = d; MV.ptrs.clear(); MV.pinch = null;
    MV.cx = P.x; MV.cy = P.y; // приближение сохраняется, а смотрим туда, где героиня
    clampMapView(); drawMap();
    $('mapTitle').textContent = `🗺️ ${World.CFG.title || ''} · ${World.landscape ? World.landscape.plan.name : World.CFG.name}`;
    buildMapLegend();
    // подсказка про жесты – плашкой на карте, сама пропадает (первые три раза)
    MV.hintN = (MV.hintN || 0) + 1; const hint = $('mapHint');
    hint.classList.remove('show'); if (MV.hintN <= 3) { void hint.offsetWidth; hint.classList.add('show'); }
  }
  function clampMapView() {
    MV.z = clamp(MV.z, 1, 4);
    const half = span()/2, w=World.WORLD_W, h=World.PLAY_H*World.T;
    MV.cx = w <= half*2 ? w/2 : clamp(MV.cx,half,w-half);
    MV.cy = h <= half*2 ? h/2 : clamp(MV.cy,half,h-half);
  }
  // точка на карте (пиксели холста) ↔ точка мира
  const span = () => Math.max(World.WORLD_W,World.PLAY_H*World.T) / MV.z;
  const mapK = () => MV.S / span();
  const mapX0 = () => MV.cx - span()/2, mapY0 = () => MV.cy - span()/2;
  function mapZoomAt(px, py, f) {
    const k = mapK(), wx = mapX0() + px / k, wy = mapY0() + py / k;
    MV.z = clamp(MV.z * f, 1, 4);
    const k2 = mapK();
    MV.cx = wx - px / k2 + span()/2; MV.cy = wy - py / k2 + span()/2;
    clampMapView(); requestMapDraw();
  }
  function requestMapDraw() { if (!MV.raf) MV.raf = requestAnimationFrame(() => { MV.raf = 0; if (Session.state === 'mapscr') drawMap(); }); }
  function drawMap() {
    const cv = $('mapCanvas'), S = MV.S, c = cv.getContext('2d');
    c.setTransform(MV.d, 0, 0, MV.d, 0, 0); c.clearRect(0, 0, S, S);
    const k = mapK(), x0 = mapX0(), y0 = mapY0(), mw = span()/World.T, mh = mw;
    c.fillStyle = '#152136'; c.fillRect(0,0,S,S);
    c.imageSmoothingEnabled = false;
    c.drawImage(Terrain.miniBase, x0 / World.T, y0 / World.T, mw, mh, 0, 0, S, S);
    c.globalAlpha = World.landscape ? 0.44 : 0.85; c.drawImage(Terrain.fog, x0 / World.T, y0 / World.T, mw, mh, 0, 0, S, S); c.globalAlpha = 1; c.imageSmoothingEnabled = true;
    const zs = Math.min(1.9, 1 + (MV.z - 1) * 0.3); // значки чуть крупнее при приближении
    const X = x => (x - x0) * k, Y = y => (y - y0) * k;
    LandscapeArt.mapLabels(c,X,Y,MV.z);
    const pos = MV.pos = {}, at = (kind, x, y) => (pos[kind] = pos[kind] || []).push([X(x), Y(y)]);
    const icon = (ch, x, y, sz = 14, kind) => { if (kind) at(kind, x, y); c.font = Math.round(sz * zs) + 'px Krilessa Icons, sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(ch, X(x), Y(y)); };
    for (const ch of World.chests) if (HUD.chestOnMap(ch)) { // сундучок: тёмная обводка, цвет – дерево, серебро или золото
      at('chest', ch.x, ch.y);
      const cx = X(ch.x), cy = Y(ch.y), u = zs;
      c.fillStyle = '#1a1020'; c.fillRect(cx - 4.5 * u, cy - 3.5 * u, 9 * u, 7 * u);
      c.fillStyle = ch.tier === 'gold' ? '#ffd25a' : ch.tier === 'silver' ? '#e0eaff' : '#c8945a'; c.fillRect(cx - 3.5 * u, cy - 2.5 * u, 7 * u, 5 * u);
      c.fillStyle = 'rgba(0,0,0,0.45)'; c.fillRect(cx - 3.5 * u, cy - 0.5 * u, 7 * u, u);
    }
    for (const sh of World.shrines) icon(sh.state === 'done' ? '🌀' : '⛩', sh.x, sh.y, 13, sh.state === 'done' ? 'portal' : 'shrine');
    for (const bd of World.beds) icon('🛏', bd.x, bd.y, 11, 'bed');
    for (const f of World.fires) if (!f.glade) icon('🔥', f.x, f.y, 12, 'fire');
    for (const hl of World.holes) if (!hl.spent) icon('🎣', hl.x, hl.y, 12, 'hole');
    for (const ov of World.ovens) icon('🍪', ov.x, ov.y, 12, 'oven');
    for (const q of World.pearls) if (!q.got) icon('💗', q.x, q.y, 12, 'pearl');
    if (NET.on && G.netRun) for (const m of NET.mates.values()) if (m.tx !== undefined) icon(m.down ? '💫' : Multiplayer.MATE_EMO[(m.id - 1) % Multiplayer.MATE_EMO.length], m.x, m.y, 14, 'mate');
    for (const g of World.glades) if (g.seen) icon(g.open ? '🌲' : '✨', g.x, g.y, 13, 'glade');
    for (const n of World.npcs) icon(n.def.ic, n.x, n.y, 13, 'npc');
    for (const q of World.clues) if (!q.found && (G.clearSight || G.revealT > 0 || (G.pet && Math.hypot(q.x - P.x, q.y - P.y) < 700) || Math.hypot(q.x - P.x, q.y - P.y) < 350 * Actors.lv('c5nose'))) icon('🔎', q.x, q.y, 11, 'clue');
    for (const it of World.qitems) if (it.active && !it.taken) icon(NPCS5[it.ni].item.ic, it.x, it.y, 12, 'npc');
    for (const b of Session.bosses) { if (Harbour.hiddenBoss(b)) continue; if (World.CFG.rush && G.rush && b.id !== G.rush.idx) continue; icon(b.def.immortal ? '♾️' : b.state === 'dead' ? '✅' : '💀', World.landscape ? b.x : b.hx, World.landscape ? b.y : b.hy, 15, 'boss'); }
    if (!World.CFG.noCage || (World.CFG.team && !G.tessaAlly)) icon('❤️', World.tc(World.CAGE.x), World.tc(World.CAGE.y), 13, 'cage');
    if (!World.CFG.rush) icon('🏠', World.tc(World.START.x), World.tc(World.START.y), 13, 'start');
    if (G.champ && !G.champ.dead) icon('👑', G.champ.x, G.champ.y, 15, 'champ');
    if (G.ev && G.ev.def.id === 'treasure') icon('❌', G.ev.tx, G.ev.ty, 14, 'treasure');
    if (!World.CFG.rush) {
      const o = Simulation.objective(); at('goal', o.x, o.y);
    }
    c.fillStyle = '#ffffff'; c.strokeStyle = '#000000'; c.lineWidth = 2; c.beginPath(); c.arc(X(P.x), Y(P.y), 6 * Math.min(1.5, zs), 0, TAU); c.fill(); c.stroke();
    at('you', P.x, P.y);
    c.textBaseline = 'alphabetic';
    // нажали на плитку легенды – эти места пульсируют кольцами 3 секунды
    if (MV.hl) {
      const t = (performance.now() - MV.hl.t0) / 1000;
      if (t < 3) {
        for (const [x, y] of pos[MV.hl.kind] || []) for (let k = 0; k < 2; k++) {
          const ph = (t * 1.4 + k * 0.5) % 1;
          c.strokeStyle = `rgba(255,225,120,${1 - ph})`; c.lineWidth = 3 - ph * 2; c.beginPath(); c.arc(x, y, 8 + ph * 18, 0, TAU); c.stroke();
        }
        requestMapDraw();
      } else MV.hl = null;
    }
    $('mapZoomOut').disabled = MV.z <= 1.01; $('mapZoomIn').disabled = MV.z >= 3.99;
    $('mapZoomLbl').textContent = MV.z > 1.01 ? `×${MV.z.toFixed(1).replace('.0', '')}` : '';
  }
  // легенда: плитки «значок · название · сколько», только то, что есть в главе; нажатие подсвечивает места на карте
  function buildMapLegend() {
    const box = $('mapLegend'); box.innerHTML = '';
    const items = [];
    const live = Session.bosses.filter(b => !Harbour.hiddenBoss(b) && !(World.CFG.rush && G.rush && b.id !== G.rush.idx));
    if (live.length) items.push(['boss', '💀', World.CFG.rush ? 'Босс' : 'Стражи', World.CFG.rush ? '' : `${live.filter(b => b.state === 'dead').length}/${live.length}`]);
    if (!World.CFG.noCage || (World.CFG.team && !G.tessaAlly)) items.push(['cage', '❤️', World.CFG.team ? 'Тесса' : 'Клетка', '']);
    const nc = World.chests.filter(HUD.chestOnMap).length;
    if (nc) items.push(['chest', '<i class="lgChest"><b class="w"></b><b class="s"></b><b class="g"></b></i>', 'Сундуки', String(nc)]);
    const open = World.shrines.filter(sh => sh.state !== 'done').length, done = World.shrines.length - open;
    if (open) items.push(['shrine', '⛩', 'Испытания', String(open)]);
    if (done) items.push(['portal', '🌀', 'Порталы', String(done)]);
    if (World.beds.length) items.push(['bed', '🛏', 'Лежанки', String(World.beds.length)]);
    if (World.fires.some(f => !f.glade)) items.push(['fire', '🔥', 'Костры', '']);
    const availableHoles = World.holes.filter(h => !h.spent).length;
    if (availableHoles) items.push(['hole', '🎣', 'Проруби', String(availableHoles)]);
    if (World.ovens.length) items.push(['oven', '🍪', 'Печки', '']);
    if (World.pearls.length) items.push(['pearl', '💗', 'Слова', `${World.pearls.filter(q => q.got).length}/${World.pearls.length}`]);
    if (World.glades.some(g => g.seen)) items.push(['glade', '✨', 'Поляны', '']);
    if (World.npcs.length) items.push(['npc', '🙂', 'Жители', '']);
    if (World.clues.some(q => !q.found)) items.push(['clue', '🔎', 'Улики', '']);
    if (G.champ && !G.champ.dead) items.push(['champ', '👑', 'Чемпион', '']);
    if (G.ev && G.ev.def.id === 'treasure') items.push(['treasure', '❌', 'Клад', '']);
    if (!World.CFG.rush) items.push(['goal', '<i class="lgGoal"></i>', 'Цель', '']);
    if (!World.CFG.rush) items.push(['start', '🏠', 'Старт', '']);
    items.push(['you', '<i class="lgYou"></i>', 'Ты', '']);
    for (const [kind, ic, name, n] of items) {
      const b = document.createElement('button'); b.className = 'lg';
      b.innerHTML = `<span class="lgIc">${ic}</span><span class="lgTx">${name}</span>${n ? `<em>${n}</em>` : ''}`;
      b.addEventListener('click', () => {
        Sound.sfx.click();
        if (kind === 'you') { MV.cx = P.x; MV.cy = P.y; clampMapView(); }
        MV.hl = { kind, t0: performance.now() }; requestMapDraw();
        for (const o of box.children) o.classList.toggle('on', o === b);
        setTimeout(() => b.classList.remove('on'), 3000);
      });
      box.appendChild(b);
    }
  }
  function mapPos(e) { const r = $('mapCanvas').getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; }
  function initMapGestures(onTap) {
    const cv = $('mapCanvas');
    cv.addEventListener('pointerdown', e => {
      try { cv.setPointerCapture(e.pointerId); } catch (err) { /* не страшно – двигаем и без захвата */ }
      const p = mapPos(e); MV.ptrs.set(e.pointerId, p);
      if (MV.ptrs.size === 2) { const [a, b] = [...MV.ptrs.values()]; MV.pinch = { d: Math.hypot(a.x - b.x, a.y - b.y) || 1, mx: (a.x + b.x) / 2, my: (a.y + b.y) / 2 }; }
      else if (MV.ptrs.size === 1) { // двойной тап – приблизить (или вернуть всю карту)
        const now = performance.now();
        if (now - MV.lastTap < 300) { if (MV.z >= 3.9) { MV.z = 1; clampMapView(); requestMapDraw(); } else mapZoomAt(p.x, p.y, 2); MV.lastTap = 0; }
        else MV.lastTap = now;
      }
    });
    cv.addEventListener('pointermove', e => {
      if (!MV.ptrs.has(e.pointerId)) return;
      const prev = MV.ptrs.get(e.pointerId), p = mapPos(e); MV.ptrs.set(e.pointerId, p);
      if (MV.ptrs.size >= 2 && MV.pinch) {
        const [a, b] = [...MV.ptrs.values()], d = Math.hypot(a.x - b.x, a.y - b.y) || 1, mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2;
        const k = mapK(); MV.cx -= (mx - MV.pinch.mx) / k; MV.cy -= (my - MV.pinch.my) / k; // двигаем вместе с пальцами
        mapZoomAt(mx, my, d / MV.pinch.d);
        MV.pinch = { d, mx, my };
      } else if (MV.ptrs.size === 1 && MV.z > 1) {
        const k = mapK(); MV.cx -= (p.x - prev.x) / k; MV.cy -= (p.y - prev.y) / k; clampMapView(); requestMapDraw();
      }
    });
    const up = e => { MV.ptrs.delete(e.pointerId); if (MV.ptrs.size < 2) MV.pinch = null; };
    cv.addEventListener('pointerup', up); cv.addEventListener('pointercancel', up);
    cv.addEventListener('wheel', e => { e.preventDefault(); const p = mapPos(e); mapZoomAt(p.x, p.y, e.deltaY < 0 ? 1.25 : 0.8); }, { passive: false });
    onTap('mapZoomIn', () => mapZoomAt(MV.S / 2, MV.S / 2, 1.6));
    onTap('mapZoomOut', () => mapZoomAt(MV.S / 2, MV.S / 2, 1 / 1.6));
  }

  return {
    openMap, initMapGestures,
  };
})();
