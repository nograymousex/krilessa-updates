'use strict';

const Challenges = (() => {
  // ------------------------------------------------------------------
  //  Босс-раш
  // ------------------------------------------------------------------
  function knownGuardian(pr,n,k,i) {
    return !BOSSES[k]?.optional || GameLoop.DEBUG || pr.admin || !!pr.starsGot?.[n+':'+i];
  }
  function rushPool() {
    const prof = Saves.loadProfile(), kinds = [], levels = [];
    for (const n of Session.CH_NUMS) if (CHAPTERS[n] && (prof['ch' + n + 'Done'] || GameLoop.DEBUG || prof.admin)) CHAPTERS[n].bosses.forEach((k, i) => { if (!knownGuardian(prof,n,k,i)) return; kinds.push(k); levels.push(CHAPTERS[n].bossLevels[i]); });
    return { kinds, levels };
  }
  function startRush(pool) {
    const prof = Saves.loadProfile();
    const { kinds, levels } = pool && pool.kinds ? pool : rushPool(); // вместе список боссов присылает хозяйка
    if (!kinds.length) return;
    const R = CHAPTERS.rush;
    R.bosses = kinds; R.bossLevels = levels; R.bossTiles = kinds.map(() => ({ x: 30, y: 24 }));
    R.hero = NET.on && G.netRun ? NET.hero : rushHeroPick(prof);
    Chapters.loadChapter('rush'); Chapters.resetRun();
    // у всех одинаковая героиня 24 уровня (плюс свои таланты и реликвии) – рекорды честные
    { const rb = refBuild(24); P.level = 24; P.up = rb.up; P.bonus = rb.bonus; P.shards = 0; }
    P.xpNext = Actors.xpFor(P.level);
    Chapters.beginPlay();
    World.gateOpen = true;
    const players = NET.on && G.netRun ? NET.roster.length : 1;
    G.rush = { idx: 0, wait: 2.5, t: 0, total: kinds.length, done: false, players, links: 0,
      link: NET.on && G.netRun ? newLink(players) : null };
    G.st = RunStats.newRunStats();
    Screens.showBanner('⚔️ Босс-раш', `${kinds.length} боссов подряд. Время пошло!`);
    Sound.music('rush');
  }
  const LINK_WINDOW = 4, LINK_TIME = 3, LINK_REST = 3, LINK_BONUS = 0.25;

  function newLink(players) {
    return { hits: [], need: players, active: 0, rest: 0, marks: new Map() };
  }

  function rushBossScale() {
    const r = G.rush;
    if (!r.link || !NET.host) return 1;
    // Фиксируем здоровье до первого удара. Вход или выход во время боя его не меняет.
    const size = 1 + NET.peers.size;
    r.link = newLink(size);
    return [1, 1.9, 2.8, 3.7][size - 1];
  }

  function refreshLink(r) {
    const link = r.link, available = [];
    if (!P.down && Session.state === 'play') available.push(1);
    for (const mate of NET.peers.values()) {
      if (mate.live && !mate.down && !mate.away) available.push(mate.id);
    }
    for (const [id, when] of link.marks) {
      if (r.t - when >= LINK_WINDOW || !available.includes(id)) link.marks.delete(id);
    }
    link.hits = Array.from(link.marks.keys());
    link.need = available.length;
    return available;
  }

  function rushDamageFactor(dot, attacker) {
    const r = G.rush, link = r && r.link;
    if (!link || r.done) return 1;
    if (link.active > 0) return 1 + LINK_BONUS;
    if (!NET.host) return 1;
    if (dot || link.rest > 0) return 1;
    const available = refreshLink(r);
    if (available.length < 2 || !available.includes(attacker)) return 1;
    link.marks.set(attacker, r.t);
    link.hits = Array.from(link.marks.keys());
    if (link.hits.length < link.need) return 1;
    r.links++;
    link.active = LINK_TIME;
    link.marks.clear();
    return 1 + LINK_BONUS;
  }

  function tickRush(dt) {
    const r = G.rush;
    if (!r || r.done || NET.client) return;
    if (!r.link && Session.state !== 'play') return;
    if (r.link) r.players = Math.max(r.players, 1 + NET.peers.size);
    r.t += dt;
    r.wait = Math.max(0, r.wait - dt);
    const link = r.link;
    if (!link || !G.activeBoss) return;
    if (link.active > 0) {
      link.active = Math.max(0, link.active - dt);
      if (!link.active) link.rest = LINK_REST;
    } else {
      link.rest = Math.max(0, link.rest - dt);
      refreshLink(r);
    }
  }

  function rushSnapshot() {
    const r = G.rush;
    if (!r || !r.link) return null;
    const link = r.link;
    return { round: r.idx, total: r.total, time: Math.round(r.t * 10), wait: Math.ceil(r.wait * 10),
      players: r.players, links: r.links, hits: link.hits, need: link.need,
      active: Math.ceil(link.active * 10), rest: Math.ceil(link.rest * 10) };
  }

  function applyRushSnapshot(s) {
    const r = G.rush;
    if (!r || !r.link || r.done || s.round < (r.rewardedRound || 0)) return;
    r.idx = s.round; r.total = s.total; r.t = s.time / 10; r.wait = s.wait / 10;
    r.players = s.players; r.links = s.links;
    Object.assign(r.link, { hits: s.hits, need: s.need, active: s.active / 10, rest: s.rest / 10 });
  }

  function rushRecovery(pickUpgrade) {
    if (P.down) { P.down = false; P.revT = 0; P.inv = Math.max(P.inv, 1.2); }
    P.hp = Math.min(P.maxHp, P.hp + P.maxHp * 0.5);
    if (pickUpgrade) {
      G.pendingLv++;
      if (Session.state === 'play') Screens.openLevelUp();
      else if (Session.state === 'levelup') Screens.refreshLevelHint();
    }
  }

  function rushBossDown() {
    const R = G.rush;
    R.idx++;
    const next = R.idx < R.total;
    for (const e of G.enemies) if (e.minion) e.dead = true;
    if (!next) { rushRecovery(false); rushFinish(true); return; }
    if (NET.host) for (const m of NET.peers.values()) Multiplayer.netEvent(m.id, ['rr', R.idx]);
    R.wait = R.link ? 5 : 3.5;
    if (R.link) R.link = newLink(1 + NET.peers.size);
    Screens.showBanner(`Босс ${R.idx}/${R.total} повержен!`, `Время ${RunStats.fmtT(R.t)}`);
    rushRecovery(true);
    if (NET.host) Saves.coopSave();
  }

  function rushFinish(win) {
    const R = G.rush, prof = Saves.loadProfile();
    if (R.done) return;
    R.done = true;
    const res = { n: R.idx, total: R.total, time: Math.round(R.t), hero: P.hero };
    const coop = NET.on && G.netRun, bk = coop ? 'rushBestCoop' : 'rushBest', best = prof[bk]; // вместе – свой рекорд
    if (coop) { res.players = R.players; res.links = R.links; }
    R.better = !best || res.n > best.n || (res.n === best.n && res.time < best.time);
    if (R.better) { prof[bk] = res; Saves.saveProfile(prof); }
    if (win) Achievements.life('rush');
    if (NET.host && G.netRun) NetT.send(-1, { t: 'rend', win: win ? 1 : 0, n: R.idx, total: R.total, time: Math.round(R.t), links: R.links, players: R.players });
    RunStats.recordRunEnd(win ? 'босс-раш пройден' : `босс-раш ${R.idx}/${R.total}`);
    if (win) {
      Sound.music('win');
      setTimeout(() => { if (G.rush === R && R.done && Session.state !== 'mp') Screens.showVictory('rush'); }, 1500);
    }
  }

  // ------------------------------------------------------------------
  //  0.30: вибрация, мутаторы, Бездна, испытание дня, достижения, Кринжопедия
  // ------------------------------------------------------------------
  // ---------- вибрация ----------
  let vibOn = null, buzzT = 0, strength = 1;
  function buzz(ms) {
    if (vibOn === null) vibOn = (Saves.loadProfile().settings || {}).vib !== false;
    if (!vibOn) return;
    const now = performance.now(); if (now - buzzT < 80) return; buzzT = now;
    ms = Math.max(6, Math.round(ms * strength));
    const A = window.KrilessaAndroid;
    try { if (A && A.vibrate) A.vibrate(ms | 0); else if (navigator.vibrate) navigator.vibrate(ms | 0); } catch (e) { /* ignore */ }
  }
  function signal(kind) {
    if (Session.state!=='play' || document.hidden) return;
    buzz(kind==='ram'?42:16);
    if(kind==='ram') {const boss=G.activeBoss;setTimeout(()=>{if(boss && G.activeBoss===boss && Session.state==='play' && !document.hidden) buzz(48);},125);}
  }
  function vibLabel() {
    strength=(Saves.loadProfile().settings || {}).vibStrength || 1;
    $('vibStrength').value=String(strength);
    $('vibStrength').disabled=(Saves.loadProfile().settings || {}).vib===false;
    if (vibOn === null) vibOn = (Saves.loadProfile().settings || {}).vib !== false;
    MenuActions.switchValue('btnVib', vibOn);
  }

  // ---------- мутаторы: пройденная глава заново, но с подвохом – за смелость звёзды ----------
  const MUTS = [
    { id: 'ng', ic: '💪', nm: 'Новая игра+', ds: 'Враги и боссы на 60% крепче и больнее бьют', pts: 2 },
    { id: 'fast', ic: '⚡', nm: 'Шустрые', ds: 'Враги бегают на 30% быстрее', pts: 1 },
    { id: 'boom', ic: '💥', nm: 'Взрывные', ds: 'Побеждённые враги взрываются – не стой рядом', pts: 1 },
    { id: 'dark', ic: '🌑', nm: 'Тьма', ds: 'Видно только вокруг героини', pts: 1 },
    { id: 'noheart', ic: '💔', nm: 'Без сердечек', ds: 'Сердечки не выпадают совсем', pts: 2 },
    { id: 'elite', ic: '👑', nm: 'Элита', ds: 'Элитных врагов втрое больше', pts: 1 },
    { id: 'glass', ic: '🩸', nm: 'Стеклянная пушка', ds: 'Урон ×1,5, но здоровье вдвое меньше', pts: 1 },
  ];
  const MUT_BY = indexById(MUTS);
  const mutOn = id => !!(G.mut && G.mut[id]);
  const mutIds = () => G.mut ? Object.keys(G.mut).filter(k => G.mut[k]) : [];
  let mutCh = 1, mutSel = new Set();
  let mutNet = false;
  function openMuts(n, net) {
    mutCh = n; mutNet = !!net; const pr = Saves.loadProfile();
    mutSel = new Set((net ? NET.mut || [] : pr.mutSel || []).filter(id => MUT_BY[id]));
    renderMuts(); Screens.setState('muts');
  }
  function renderMuts() {
    const pr = Saves.loadProfile(), got = pr.starsGot || {};
    $('mutTitle').textContent = `🧪 Мутаторы · Глава ${mutCh}`;
    const box = $('mutList'); box.innerHTML = '';
    let pts = 0, newPts = 0;
    for (const m of MUTS) {
      const on = mutSel.has(m.id), earned = got[`m:${mutCh}:${m.id}:0`];
      if (on) { pts += m.pts; if (!earned) newPts += m.pts; }
      const el = document.createElement('button'); el.className = 'mutRow' + (on ? ' on' : '');
      el.innerHTML = `<i>${m.ic}</i><div><b>${m.nm}</b><span>${m.ds}</span></div><em>${earned ? '✓' : '+' + m.pts + '⭐'}</em>`;
      el.addEventListener('click', () => { if (mutSel.has(m.id)) mutSel.delete(m.id); else mutSel.add(m.id); Sound.sfx.click(); renderMuts(); });
      box.appendChild(el);
    }
    $('mutGo').textContent = mutNet ? (mutSel.size ? `✓ Играть вместе с мутаторами (${mutSel.size})` : '✓ Без мутаторов') : mutSel.size ? `▶ Играть с мутаторами (${mutSel.size})` : 'Выбери хотя бы один';
    $('mutGo').classList.toggle('gray', !mutSel.size && !mutNet);
    $('mutInfo').textContent = mutSel.size ? (newPts ? `Пройдёшь главу – получишь +${newPts} ⭐ для талантов` : 'За эти мутаторы звёзды уже получены – играй ради рекорда!') : 'Звёзды за каждый мутатор даются один раз за главу';
  }
  function mutGo() {
    if (mutNet) {
      if (NET.started) return;
      if (!NET.host || NET.ch !== mutCh) { Screens.setState('mp'); Multiplayer.mpRender(); return; }
      const pr = Saves.loadProfile(); pr.mutSel = [...mutSel]; Saves.saveProfile(pr);
      Screens.setState('mp');
      CoopActivity.selectMutators([...mutSel]);
      return;
    }
    if (!mutSel.size) return;
    const pr = Saves.loadProfile(); pr.mutSel = [...mutSel]; Saves.saveProfile(pr);
    GameStorage.remove(Saves.saveKey(mutCh));
    G.mutNext = [...mutSel];
    Chapters.startChapter(mutCh);
  }
  // награда за пройденную с мутаторами главу
  function mutReward() {
    G.mutEarned = 0;
    const ids = mutIds(); if (!ids.length || typeof World.CHN !== 'number' || G.daily) return;
    const pr = Saves.loadProfile(); pr.starsGot = pr.starsGot || {};
    for (const id of ids) { const m = MUT_BY[id]; for (let k = 0; k < m.pts; k++) { const key = `m:${World.CHN}:${id}:${k}`; if (!pr.starsGot[key]) { pr.starsGot[key] = 1; G.mutEarned++; } } }
    pr.stars = Object.keys(pr.starsGot).length; Saves.saveProfile(pr);
    Achievements.lifeMax('mutMax', ids.length);
  }

  // ---------- Бездна: волна за волной на арене ----------
  CHAPTERS.abyss = Object.assign({}, CHAPTERS.rush, { id: 'abyss', title: 'Бездна', name: 'Бездна', rush: false, abyss: true,
    bosses: [], bossTiles: [], bossLevels: [], spawnEvery: 9999, capBase: 0, music: 'abyss7' });
  const rushHeroPick = pr => { const rhs = (pr.settings || {}).rushHero; return rhs === 'tessa' && (pr.ch4Done || GameLoop.DEBUG || pr.admin) ? 'tessa' : rhs === 'ryzhovaya' && (pr.ch3Done || GameLoop.DEBUG || pr.admin) ? 'ryzhovaya' : 'krilessa'; };
  function abyssPool(pr) {
    const types = new Set(), kinds = [];
    for (const n of Session.CH_NUMS) {
      const C = CHAPTERS[n], done = pr['ch' + n + 'Done'] || GameLoop.DEBUG || pr.admin;
      if (!done && !Chapters.chapterOpen(n)) continue;
      for (const [b] of C.biomeSeeds) if (b !== C.castle.biome && SPAWNS[b]) for (const [t] of SPAWNS[b]) if (ENEMIES[t]) types.add(t);
      if (done) C.bosses.slice(0, -1).forEach((k,i) => { if (BOSSES[k] && !BOSSES[k].immortal && knownGuardian(pr,n,k,i)) kinds.push(k); });
    }
    if (!kinds.length) kinds.push(...CHAPTERS[1].bosses.slice(0, -1));
    return { types: [...types], kinds };
  }
  // Бездна сохраняется после каждой пройденной волны: после вылета или выхода в меню можно продолжить
  const ABYSS_CK = 'krilessa_abyss_ck';
  function abyssCkLoad() {
    const c = GameStorage.readRecord(ABYSS_CK);
    return c && c.v === 1 && c.wave > 0 && typeof c.hero === 'string' && Object.prototype.hasOwnProperty.call(HEROES, c.hero) ? c : null;
  }
  function abyssCkClear() { GameStorage.remove(ABYSS_CK); }
  function abyssCkSave() {
    const A = G.abyss; if (!A || A.done) return;
    const ck = { v: 1, wave: A.wave, t: Math.round(A.t), kills: G.kills, hero: P.hero, level: P.level, xp: P.xp, up: P.up, bonus: P.bonus, shards: P.shards,
      hpF: P.maxHp ? clamp(P.hp / P.maxHp, 0, 1) : 1, sp: P.sp || 0, pend: G.pendingLv || 0, ph: !!G.phoenixUsed, sw: !!G.secondUsed, combo: G.bestCombo || 0, better: !!A.better, at: Date.now() };
    GameStorage.write(ABYSS_CK, ck);
  }
  // рекорд пишется сразу после волны – вылет его уже не сотрёт
  function abyssRecord(wave) {
    const A = G.abyss, pr = Saves.loadProfile(), best = pr.abyssBest;
    if (!best || wave > best.wave || (wave === best.wave && A.t < best.time)) { pr.abyssBest = { wave, time: Math.round(A.t), hero: P.hero, kills: G.kills }; Saves.saveProfile(pr); A.better = true; }
  }
  // музыка Бездны: спокойные треки всех открытых глав в перемешанном порядке, а у стражей – разные боевые темы
  const ABYSS_SKIP = new Set(['boss', 'menu', 'win', 'truewin', 'zyamashow', 'ultimate', 'final', 'final2', 'final5', 'meowboss', 'mrakboss', 'krillboss']);
  function abyssDecks(pr) {
    const amb = new Set(['abyss7']), boss = ['boss'];
    for (const n of Session.CH_NUMS) {
      const C = CHAPTERS[n], done = pr['ch' + n + 'Done'] || GameLoop.DEBUG || pr.admin;
      if (!done && !Chapters.chapterOpen(n)) continue;
      for (const id of [C.music, C.castle ? BIOME_MUSIC[C.castle.biome] : '', ...C.biomeSeeds.map(([bm]) => BIOME_MUSIC[bm])]) if (id && Sound.has(id) && !ABYSS_SKIP.has(id)) amb.add(id);
      if (!done) continue;
      const fin = BOSSES[C.bosses[C.bosses.length - 1]] || {}; // финальная тема главы – в награду тем, кто её прошёл
      const fm = fin.music || (n === 3 ? 'final2' : 'final');
      if (Sound.has(fm) && !boss.includes(fm)) boss.push(fm);
    }
    return { amb: [...amb], boss };
  }
  function abyssNextTrack() {
    if (Defense.defOn()) {
      G.abyss.track = G.abyss.map === 'banks' ? 'banks' : 'defense';
      G.abyss.trackT = 0;
      if (!G.activeBoss) Sound.music(G.abyss.track);
      return;
    }
    const A = G.abyss; if (!A || !A.mus) return;
    if (!A.bag || !A.bag.length) { // мешок: каждый трек прозвучит, прежде чем какой-то повторится
      A.bag = A.mus.amb.slice();
      for (let i = A.bag.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [A.bag[i], A.bag[j]] = [A.bag[j], A.bag[i]]; }
      if (A.bag.length > 1 && A.bag[A.bag.length - 1] === A.track) A.bag.unshift(A.bag.pop());
    }
    A.track = A.bag.pop(); A.trackT = 0;
    if (!G.activeBoss) Sound.music(A.track);
  }
  function abyssBossTrack() {
    const A = G.abyss, d = A.mus.boss;
    let t = d[Math.floor(Math.random() * d.length)];
    if (d.length > 1 && t === A.bossTrack) t = d[(d.indexOf(t) + 1 + Math.floor(Math.random() * (d.length - 1))) % d.length];
    A.bossTrack = t; return t;
  }
  function startAbyss(ck) {
    const pr = Saves.loadProfile();
    if (!(pr.ch1Done || GameLoop.DEBUG || pr.admin)) { RunStats.toast('🔒 Бездна откроется после главы 1'); return; }
    if (!ck) abyssCkClear(); // новый забег – старое сохранение больше не нужно
    const A = CHAPTERS.abyss; A.bosses = []; A.bossTiles = []; A.bossLevels = []; A.hero = ck ? ck.hero : rushHeroPick(pr);
    Chapters.loadChapter('abyss'); Chapters.resetRun();
    Chapters.beginPlay();
    World.gateOpen = true;
    G.abyss = { wave: 0, rest: 2.5, t: 0, state: 'rest', pool: abyssPool(pr) };
    G.st = RunStats.newRunStats();
    if (ck) {
      P.level = ck.level || 1; P.xp = ck.xp || 0; P.xpNext = Actors.xpFor(P.level); P.up = ck.up || {}; P.bonus = ck.bonus || {}; P.shards = ck.shards || 0;
      Actors.computeStats(); P.hp = Math.max(1, Math.round(P.maxHp * clamp(+ck.hpF || 1, 0.05, 1))); P.sp = ck.sp || 0;
      G.kills = ck.kills || 0; G.phoenixUsed = !!ck.ph; G.secondUsed = !!ck.sw; G.bestCombo = ck.combo || 0; G.pendingLv = ck.pend || 0;
      G.abyss.wave = ck.wave; G.abyss.t = ck.t || 0; G.abyss.rest = 3.5; G.abyss.better = !!ck.better;
      Screens.showBanner('🕳️ Бездна', `Продолжаем: впереди волна ${ck.wave + 1}`);
      if (G.pendingLv > 0) setTimeout(() => { if (Session.state === 'play' && G.abyss) Screens.openLevelUp(); }, 700);
    } else Screens.showBanner('🕳️ Бездна', 'Волна за волной – как долго продержишься?');
    G.abyss.mus = abyssDecks(pr); abyssNextTrack();
  }
  function abyssSpot(minR, maxR) {
    for (let k = 0; k < 40; k++) {
      const a = rnd(0, TAU), r = rnd(minR, maxR), x = P.x + Math.cos(a) * r, y = P.y + Math.sin(a) * r;
      const tx = Math.floor(x / World.T), ty = Math.floor(y / World.T);
      if (Math.abs(tx - World.CASTLE.x) < World.CASTLE.half - 1 && Math.abs(ty - World.CASTLE.y) < World.CASTLE.half - 1 && Physics.walkable(x, y, false)) return { x, y };
    }
    return { x: World.tc(World.CASTLE.x) + rnd(-200, 200), y: World.tc(World.CASTLE.y) + rnd(-200, 200) };
  }
  function abyssWave() {
    const A = G.abyss; A.wave++; A.state = 'fight';
    const E = Math.round(3 + A.wave * 1.25), n = Math.min(44, 6 + A.wave * 2), boss = A.wave % 5 === 0;
    for (let i = 0; i < (boss ? Math.ceil(n / 3) : n); i++) {
      const type = pick(A.pool.types), s = abyssSpot(260, 520);
      Enemies.spawnEnemy(type, s.x, s.y, World.CASTLE.biome, { E, elite: Math.random() < 0.04 + A.wave * 0.008 });
    }
    if (boss) {
      const kind = pick(A.pool.kinds), s = abyssSpot(220, 300);
      World.CFG.bosses = [kind]; World.CFG.bossLevels = [E + 2]; World.CFG.bossTiles = [{ x: Math.floor(s.x / World.T), y: Math.floor(s.y / World.T) }]; G.defeated = [false];
      Bosses.makeBosses(); const b = Session.bosses[0]; b.x = b.hx = s.x; b.y = b.hy = s.y;
      Bosses.startBossFight(b);
      Screens.showBanner(`🕳️ Волна ${A.wave}`, `${b.name} поднимается из бездны!`);
    } else Screens.showBanner(`🕳️ Волна ${A.wave}`, A.wave === 1 ? 'Поехали!' : `Врагов: ${n}`);
    Sound.sfx.event(); buzz(40);
  }
  function abyssUpdate(dt) {
    const A = G.abyss; if (!A || G.cutscene) return;
    if (Session.state === 'play') { A.t += dt; A.trackT = (A.trackT || 0) + dt; }
    if (A.state === 'rest') { if (Session.state === 'play') { A.rest -= dt; if (A.rest <= 0) abyssWave(); } return; }
    if (!G.activeBoss && !G.enemies.some(e => !e.dead)) {
      A.state = 'rest'; A.rest = 3.5;
      P.hp = Math.min(P.maxHp, P.hp + P.maxHp * 0.15);
      Screens.showBanner(`Волна ${A.wave} пройдена!`, 'Передышка… +15% ❤️');
      Achievements.lifeMax('abyss', A.wave);
      abyssRecord(A.wave); abyssCkSave(); Achievements.life('abyssW'); Achievements.life('spts', Seasons.weekEv('abyss') ? 6 : 3);
      if (A.trackT > 50) abyssNextTrack(); // трек играл уже долго – на передышке ставим следующий
      try { Achievements.lifeFlush(); } catch (e) { /* ignore */ }
    }
  }
  function abyssBossDown() {
    abyssNextTrack(); // страж повержен – после боевой темы новый трек
    const dcoin = Defense.defOn() ? 80 + G.abyss.wave * 4 : 0;
    Screens.showBanner(Defense.defOn() ? 'Страж повержен!' : 'Страж бездны повержен!', Defense.defOn() ? `Улучшение, +${dcoin} 🪙 и +2 💎 кристаллу` : 'Награда: улучшение и лечение');
    P.hp = Math.min(P.maxHp, P.hp + P.maxHp * 0.4);
    if (Defense.defOn()) { G.abyss.coins += dcoin; G.core.hp = Math.min(TD_LIVES, G.core.hp + 2); G.abyss.bossLn = undefined; if (NET.host && G.netRun) for (const m of NET.peers.values()) Multiplayer.netEvent(m.id, ['rh']); }
    G.pendingLv++; Screens.openLevelUp();
  }
  function abyssFinish() {
    const A = G.abyss; if (!A || A.done) return; A.done = true;
    abyssCkClear(); // забег окончен – продолжать нечего
    const pr = Saves.loadProfile(), best = pr.abyssBest, wave = A.state === 'rest' ? A.wave : Math.max(0, A.wave - 1);
    const better = !best || wave > best.wave || (wave === best.wave && A.t < best.time);
    if (better) { pr.abyssBest = { wave, time: Math.round(A.t), hero: P.hero, kills: G.kills }; Saves.saveProfile(pr); }
    A.better = A.better || better;
    Achievements.lifeMax('abyss', wave);
    RunStats.recordRunEnd(`бездна: волна ${A.wave}`);
  }

  // ---------- испытание дня: одна карта и одни правила на день ----------
  const DAILY_LEN = 300;
  function dayKey(d = new Date()) { return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; }
  function dailyInfo() {
    const key = dayKey();
    const h = fnv1a32(key);
    const open = Session.CH_NUMS.filter(n => Chapters.chapterOpen(n)), ch = open[h % open.length] || 1;
    const muts = []; let k = h;
    while (muts.length < 2) { k = Math.imul(k ^ (k >>> 13), 1274126177) >>> 0; const id = MUTS[(k >>> 7) % MUTS.length].id; if (!muts.includes(id)) muts.push(id); }
    return { key, seed: 1 + (h % 2000000000), ch, muts };
  }
  function startDaily() {
    const D = dailyInfo();
    G.mutNext = D.muts; G.dailyNext = { key: D.key, left: DAILY_LEN, score: 0, ch: D.ch };
    Chapters.newChapter(D.ch, D.seed);
    Screens.showBanner('📅 Испытание дня', `5 минут · ${D.muts.map(m => MUT_BY[m].ic + ' ' + MUT_BY[m].nm).join(' · ')}`);
  }
  const dailyAdd = v => { if (G.daily && !G.daily.done) G.daily.score += v; };
  function dailyUpdate(dt) {
    const D = G.daily; if (!D || D.done || G.cutscene) return;
    if (Session.state === 'play') { D.left -= dt; if (D.left <= 0) { D.left = 0; dailyFinish(true); } }
  }
  function dailyFinish(timeUp) {
    const D = G.daily; if (!D || D.done) return; D.done = true;
    D.score += P.level * 20;
    const pr = Saves.loadProfile(), dd = pr.daily || {};
    const yest = dayKey(new Date(Date.now() - 864e5));
    if (dd.key !== D.key) { dd.streak = dd.key === yest ? (dd.streak || 0) + 1 : 1; dd.best = 0; dd.plays = 0; dd.key = D.key; }
    dd.plays = (dd.plays || 0) + 1; D.better = D.score > (dd.best || 0); if (D.better) dd.best = D.score;
    dd.total = (dd.total || 0) + 1;
    pr.daily = dd; Saves.saveProfile(pr);
    D.best = dd.best; D.streak = dd.streak;
    Achievements.lifeMax('dStreak', dd.streak); Achievements.life('daily'); Achievements.lifeMax('dBest', D.score); Achievements.life('spts', 20);
    RunStats.recordRunEnd(`испытание дня: ${D.score}`);
    if (timeUp) { Sound.music('win'); G.enemies.length = 0; G.ebullets.length = 0; setTimeout(() => Screens.showVictory('daily'), 900); }
  }

  return {
    rushPool, startRush, rushBossDown, rushFinish, rushRecovery, rushBossScale, rushDamageFactor,
    tickRush, rushSnapshot, applyRushSnapshot, signal, buzz, vibLabel, MUTS, MUT_BY, mutOn, mutIds,
    openMuts, mutGo, mutReward, rushHeroPick, abyssPool, abyssCkLoad, abyssDecks, abyssNextTrack,
    abyssBossTrack, startAbyss, abyssWave, abyssUpdate, abyssBossDown, abyssFinish, dayKey,
    dailyInfo, startDaily, dailyAdd, dailyUpdate, dailyFinish,
    get vibOn() { return vibOn; },
    set vibOn(value) { vibOn = value; },
    get mutCh() { return mutCh; },
    get mutNet() { return mutNet; },
  };
})();
