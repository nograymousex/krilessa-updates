'use strict';

(() => {
  // Касание фона и клавиатура тоже разблокируют WebAudio в браузере с запретом автозапуска.
  for (const event of ['pointerup', 'keydown']) {
    window.addEventListener(event, () => { if (Sound.isEnabled()) Sound.init(); }, { capture: true, passive: true });
  }

  function fallbackPortrait() {
    const portrait = makeCanvas(480, 640);
    const c = portrait.getContext('2d');
    c.fillStyle = '#2a1238'; c.fillRect(0, 0, 480, 640);
    c.fillStyle = '#ff6a1f'; c.beginPath(); c.ellipse(240, 330, 190, 260, 0, 0, TAU); c.fill();
    c.fillStyle = '#ffe0cc'; c.beginPath(); c.ellipse(240, 290, 120, 150, 0, 0, TAU); c.fill();
    c.fillStyle = '#111'; c.fillRect(0, 500, 480, 140);
    return { photo: portrait, cartoon: portrait, face: { x: 0.5, y: 0.45, r: 0.36 } };
  }

  async function preparePortraits() {
    const { IMG, AVATAR } = Session;
    const painting = name => Cartoon.loadImage('art/' + name + '.webp').catch(error => {
      console.warn('Не удалось загрузить рисунок ' + name, error);
      return null;
    });
    [ART.ryzhovaPortrait, ART.ryzhovaSprite, IMG.zyama, ART.harbourFace] = await Promise.all([
      painting('ryzhovaya-portrait'), painting('ryzhovaya-sprite'),
      Cartoon.make('zyama').catch(error => {
        console.warn('Не удалось обработать фото Зямочкккк', error);
        return fallbackPortrait();
      }),
      painting('harbour/zyama'), HarbourArt.portraits(),
    ]);
    const portrait = ryzFacePortrait(360, 480);
    IMG.ryzhova = { photo: portrait, cartoon: portrait };
    AVATAR.ryzhova = ryzFacePortrait(116);
    AVATAR.ryzhovaBig = ryzFacePortrait(300);
    ART.zyamaFace = ART.harbourFace || Cartoon.avatar(IMG.zyama.cartoon, 160, IMG.zyama.face);
    ART.zyamaSmall = ART.harbourFace || Cartoon.avatar(IMG.zyama.cartoon, 48, IMG.zyama.face);
    AVATAR.zyama = ART.zyamaFace;
    AVATAR.krilessa = heroPortrait('krilessa');
    for (const [id, boss] of Object.entries(BOSSES)) {
      if (!AVATAR[id]) AVATAR[id] = boss.avatar ? AVATAR[boss.avatar] : bossPortrait(id);
    }

    // Базовый портрет доступен, пока обрабатывается фотография.
    AVATAR.tessa = heroPortrait('tessa');
    AVATAR.tessaBig = heroPortrait('tessa', 300);
    Cartoon.make('tessa').then(img => {
      IMG.tessa = img;
      AVATAR.tessa = Cartoon.avatar(img.cartoon, 116, img.face);
      AVATAR.tessaBig = Cartoon.avatar(img.cartoon, 300, img.face);
    }).catch(error => console.warn('Не удалось обработать фото Тессы', error));
  }

  function applyPreferences(profile) {
    const settings = profile.settings || {};
    Renderer.volOn = settings.vol !== false;
    LOOK_ALL = !!profile.admin;
    TESSA_OUTFIT = (profile.wardrobe && profile.wardrobe.on) || 'none';
    if (document.fonts && document.fonts.load) {
      for (const font of [HUD.HAND(16), '700 16px Philosopher', '800 16px Nunito']) {
        document.fonts.load(font, 'Яя12').catch(() => {});
      }
    }
    if (!HUD.MM_URL) {
      const knownStyle = ['classic', 'neon', 'paper'].includes(settings.mini);
      if (settings.miniV === 2 && knownStyle) HUD.MM_STYLE = settings.mini;
      else if (settings.mini === 'classic') HUD.MM_STYLE = 'classic';
      else HUD.MM_STYLE = Terrain.paperOn ? 'paper' : 'neon';
    }
    HUD.MM2.sizeF = 0;
    ControlLayout.read(settings);
    MenuActions.volLabel();
    MenuActions.miniLabel();
    MenuActions.styleLabel();
    MenuActions.joyLabel();
  }

  function rememberVersion(profile, previousChapters) {
    // Ранний выпуск обороны недолго носил номер 0.37.
    if (profile.lastVersion === '0.37 stable') {
      profile.lastVersion = '0.35 stable';
      Saves.saveProfile(profile);
    }
    if (profile.lastVersion === VERSION) return;
    const [first, second, third] = previousChapters;
    if (profile.lastVersion) G.pendingWhatsNew = profile.lastVersion;
    else if (profile.ch3Done || third) G.pendingWhatsNew = '0.03 beta';
    else if (profile.ch2Done || second || profile.carry) G.pendingWhatsNew = '0.02 beta';
    else if (profile.ch1Done || first) G.pendingWhatsNew = true;
    else {
      profile.lastVersion = VERSION;
      Saves.saveProfile(profile);
    }
  }

  function notifyAfterRestart() {
    const previous = GameLoop.liveCheck();
    const rendererRestarted = /[?&]rgone=1/.test(location.search);
    if (!rendererRestarted && !previous) return;
    const tail = Challenges.abyssCkLoad() ? 'Бездну можно продолжить в «Режимах»' : 'Прогресс глав сохранён';
    if (rendererRestarted) {
      GameLoop.logErr('Android: процесс отрисовки упал, игра перезапущена', 'android');
      GameLoop.bootToast('😵 Игра перезапустилась после сбоя. ' + tail);
    } else if (previous.bg) GameLoop.bootToast('💤 Игра закрылась, пока была свёрнута. ' + tail);
    else GameLoop.bootToast('😵 Похоже, игра закрылась посреди боя. ' + tail);
  }

  function showFirstScreen(profile) {
    const returning = profile.seenPrologue || profile.ch1Done || profile.lastCh || Session.CH_NUMS.some(Saves.loadSave);
    AdventureMenu.openSplash(!returning);
    if (!returning) return;
    if (G.pendingWhatsNew) {
      const from = G.pendingWhatsNew;
      G.pendingWhatsNew = null;
      Story.openWhatsNew(from === true ? null : from);
    }
  }

  async function boot() {
    // Ждём начертание до первого портрета, спрайта с подписью и игрового кадра.
    if (document.fonts && document.fonts.load) {
      try {
        await document.fonts.load('16px "Krilessa Icons"', '⭐');
      } catch (error) {
        console.warn('Не удалось загрузить шрифт игровых значков', error);
      }
    }
    Sound.init();
    Chapters.loadChapter(1);
    Chapters.resetRun();
    Bosses.makeBosses();
    Actors.computeStats();

    Terrain.paperOn = (Saves.loadProfile().settings || {}).style === 'paper';
    document.body.classList.toggle('paper', Terrain.paperOn);
    await preparePortraits();
    // Миграция старых глав может удалить слоты после переноса наград в профиль.
    const previousChapters = [1, 2, 3].map(chapter => !!Saves.loadSave(chapter));
    const profile = Saves.migrateProfile();
    applyPreferences(profile);
    rememberVersion(profile, previousChapters);
    RunStats.startSession();
    requestAnimationFrame(GameLoop.loop);
    notifyAfterRestart();

    showFirstScreen(profile);
    // Подтверждение загрузки управляет откатом скачанного комплекта на Android.
    try {
      if (window.KrilessaAndroid && KrilessaAndroid.booted) KrilessaAndroid.booted();
    } catch (error) { /* Браузерная версия работает без Android-моста. */ }
  }

  boot();
})();
