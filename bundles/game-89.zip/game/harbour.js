'use strict';

const B9 = registerBiomes(
  {
    id: 'kurilYards',
    name: 'Дворы у Сахалинской',
    ground: ['#4d5759', '#545d5e', '#465053'],
    path: ['#76796f', '#85867d', '#737970'],
    rock: ['#424b4d', '#646c6b', '#344043'],
    treeP: 0,
    mini: '#737d79',
    obst: [[ROCK, 1]],
    deco: 'boards',
    music: 'harbour',
    spawns: [
      ['saltDiver', 4],
      ['bat', 1],
    ],
  },
  {
    id: 'kurilHall',
    name: 'Дом культуры',
    ground: ['#665348', '#69584f', '#5c4b46'],
    path: ['#7f6b58', '#917561', '#806958'],
    rock: ['#3a3540', '#595059', '#352d37'],
    treeP: 0,
    mini: '#986e61',
    obst: [[ROCK, 1]],
    deco: 'boards',
    music: 'mirror',
    spawns: [
      ['ticketShade', 4],
      ['wisp', 1],
    ],
  },
  {
    id: 'kurilPort',
    name: 'Портовый ковш',
    ground: ['#506068', '#53646c', '#4e5c60'],
    path: ['#8c7f67', '#918575', '#817564'],
    rock: ['#384952', '#626b70', '#37444c'],
    treeP: 0,
    mini: '#627e89',
    obst: [[ROCK, 1]],
    deco: 'boards',
    music: 'harbour',
    spawns: [
      ['saltDiver', 3],
      ['ticketShade', 2],
    ],
  },
  {
    id: 'redHold',
    name: 'Красный трюм',
    ground: ['#593638', '#603f3b', '#523639'],
    path: ['#765352', '#775755', '#795653'],
    rock: ['#493539', '#76534a', '#423239'],
    treeP: 0,
    mini: '#733d45',
    obst: [[ROCK, 1]],
    deco: 'drops',
    music: 'redHold',
    spawns: [
      ['crab', 3],
      ['saltDiver', 1],
    ],
  },
);

const HARBOUR_MAP = {
  name: 'Северо-Курильск',
  size: [150, 110],
  start: [26, 85],
  castle: [124, 22, 9, 'south', B9 + 2],
  cage: [124, 21],
  bosses: [
    [35, 74],
    [55, 58],
    [44, 34],
    [96, 39],
    [110, 85],
    [124, 22],
  ],
  seeds: [
    [B9, 26, 85],
    [B9, 35, 71],
    [B9, 56, 59],
    [B9 + 1, 43, 34],
    [B9 + 1, 56, 36],
    [B9 + 2, 82, 49],
    [B9 + 2, 99, 37],
    [B9 + 2, 124, 22],
    [B9 + 3, 110, 85],
  ],
  radius: 4.6,
  paths: [
    [
      [26, 85],
      [35, 75],
      [39, 68],
      [52, 63],
      [55, 58],
      [54, 48],
      [44, 34],
    ],
    [
      [30, 79],
      [22, 71],
      [26, 56],
      [34, 46],
      [44, 34],
      [57, 34],
      [70, 40],
      [83, 43],
      [96, 39],
    ],
    [
      [55, 58],
      [66, 54],
      [73, 49],
      [83, 43],
    ],
    [
      [96, 39],
      [105, 43],
      [115, 41],
      [124, 35],
      [124, 33],
    ],
  ],
  pockets: [
    [32, 78, 13, 15, -0.3],
    [54, 57, 12, 12],
    [43, 34, 12, 13],
    [95, 39, 13, 11, -0.22],
    [110, 85, 9, 12],
  ],
  labels: [
    ['60 лет Октября', 30, 91],
    ['Сахалинская', 47, 66],
    ['Шутова', 71, 55],
    ['Дом культуры', 44, 24],
    ['Портовый ковш', 116, 12],
  ],
  marks: [],
  hatch: [43, 79],
  ladder: [110, 94],
};

const Harbour = {
  scenes: {
    ch9: {
      end: 18,
      scenes: [
        {
          at: 0,
          art: 'harbour/arrival',
          focus: [0.48, 0.58],
          music: 'harbour',
          speaker: 'Рыжовая',
          text: 'Когда я здесь жила, последний автобус ночевал у гаражей. Зям, а ты как внутрь попал?',
        },
        {
          at: 6,
          art: 'harbour/window',
          focus: [0.49, 0.39],
          speaker: 'Зямочкккк',
          text: 'Насть, я уже третий раз мимо этих окон еду. На причале встреть меня, ладно?',
        },
        {
          at: 12,
          art: 'harbour/night',
          focus: [0.46, 0.4],
          speaker: 'Из динамика',
          text: 'Уважаемые пассажиры, оставайтесь на местах. Артист выйдет на поклон ещё раз.',
        },
      ],
    },
    end9: {
      end: 19,
      scenes: [
        {
          at: 0,
          art: 'harbour/pier',
          focus: [0.46, 0.39],
          music: 'harbour',
          speaker: 'Рыжовая',
          text: 'Всё. Дверь держу. Давай руку.',
        },
        {
          at: 6,
          art: 'harbour/curtain',
          focus: [0.42, 0.46],
          speaker: 'Зямочкккк',
          text: 'Сначала её. Она со мной села, а потом всё боялась, что мы проедем мамину остановку.',
        },
        {
          at: 12,
          art: 'harbour/curtain',
          focus: [0.28, 0.51],
          text: 'Девочка спрыгивает на причал. Зяма выходит следом. За стеклом его двойник всё ещё кланяется пустым креслам. До дома они с Настей идут пешком.',
        },
      ],
    },
  },
  insideHold(x, y) {
    return World.CHN === 9 && Math.hypot(x / World.T - 110.5, y / World.T - 85.5) < 18;
  },
  hiddenBoss(b) {
    return World.CHN === 9 && b.kind === 'bycatch' && !G.defeated[b.id] && !this.insideHold(P.x, P.y);
  },
  tilePoint([x, y]) {
    return { x: World.tc(x), y: World.tc(y) };
  },
  near(point, r) {
    return Math.hypot(P.x - World.tc(point[0]), P.y - World.tc(point[1])) < r;
  },
  props(b, kind) {
    const offsets = {
      net: [
        [-105, 60],
        [100, -42],
      ],
      screen: [
        [-98, -62],
        [124, 46],
      ],
      bollard: [
        [-130, 56],
        [116, -66],
      ],
      lamp: [
        [-130, -60],
        [120, -82],
        [36, 120],
      ],
    };
    return offsets[kind].map(([x, y]) => ({ x: b.hx + x, y: b.hy + y }));
  },
  onLine(h, x, y, margin) {
    const dx = x - h.x,
      dy = y - h.y,
      ca = Math.cos(h.ang),
      sa = Math.sin(h.ang),
      along = dx * ca + dy * sa;
    return along >= 0 && along <= h.len && Math.abs(dy * ca - dx * sa) < h.w / 2 + margin;
  },
  dash(dx, dy) {
    P.harbourDash = { dx, dy };
    if (G.defeated[0])
      for (const e of G.enemies) {
        const x = P.x - e.x,
          y = P.y - e.y,
          d = Math.hypot(x, y);
        if (d > 1 && d < 190 && !e.dead)
          Enemies.damageEnemy(e, { v: P.dmg * 0.35, crit: false }, (x * 330) / d, (y * 330) / d, false);
      }
    if (G.defeated[4] && P.hp < P.maxHp) {
      const hp = P.hp;
      P.hp = Math.min(P.maxHp, hp + Math.ceil(P.maxHp * 0.08));
      Effects.floatText(P.x, P.y - 40, '+' + Math.round(P.hp - hp), '#ddc2be');
    }
  },
  portal() {
    if (World.CHN !== 9 || !G.defeated[0] || G.activeBoss || P.down || G.cutscene) return null;
    if (this.near(HARBOUR_MAP.hatch, 90)) return 'down';
    if (this.near(HARBOUR_MAP.ladder, 94)) return 'up';
    return null;
  },
  travel() {
    const dir = this.portal();
    if (!dir || Session.state !== 'play') return;
    const pos = this.tilePoint(dir === 'down' ? HARBOUR_MAP.ladder : HARBOUR_MAP.hatch);
    P.x = pos.x;
    P.y = pos.y + (dir === 'down' ? 0 : 30);
    P.inv = Math.max(1, P.inv);
    Simulation.updateCamera();
    Terrain.revealFog(P.x, P.y, 9);
    Encounters.biomeMusic(true);
    if (dir === 'down') Screens.showBanner('Красный трюм', 'Под настилом что-то дышит');
    Sound.sfx.gate();
  },
};

const portBase = {
  harbour: true,
  openingAttack: true,
  music: 'harbour',
  hit: 0.121,
  touch: 0.142,
  move: 'chase',
};
function portStage(name, at, attacks, spd = 1) {
  return { name, at, attacks, spd };
}
Object.assign(BOSSES, {
  keel: {
    ...portBase,
    name: 'Киль',
    sub: 'Последний автобус',
    r: 52,
    ttk: 51,
    spd: 43,
    fly: true,
    col: '#c19964',
    lines: { intro: null, stages: [null, null, null], death: 'Скоба твоя. Берегись сетей у гаражей.' },
    stages: [
      portStage('Якорь', 1, [['dropAnchor']]),
      portStage('Лебёдка', 0.68, [['dropAnchor', { crew: 2 }], ['chainSweep']], 1.1),
      portStage(
        'Последняя скоба',
        0.34,
        [
          ['dropAnchor', { crew: 3 }],
          ['tidalRun', { fx: 'sluiceChain', passes: 2 }],
        ],
        1.22,
      ),
    ],
  },
  netmender: {
    ...portBase,
    name: 'Сетевяз',
    sub: 'Рыбацкие гаражи',
    r: 42,
    ttk: 53,
    spd: 78,
    col: '#a6b186',
    lines: {
      intro: null,
      stages: [null, 'Тяни, пока мокрая!', null],
      death: 'Слышишь хлопки? В Доме культуры зал пустой, а они всё хлопают.',
    },
    stages: [
      portStage('Свободная петля', 1, [['netHaul']]),
      portStage(
        'Двойной узел',
        0.67,
        [
          ['netHaul', { lines: 2 }],
          ['shotgun', { n: 4, col: '#b8c899' }],
        ],
        1.12,
      ),
      portStage(
        'Мёртвый узел',
        0.32,
        [
          ['netHaul', { lines: 3 }],
          ['tidalRun', { fx: 'netLine' }],
        ],
        1.24,
      ),
    ],
  },
  projector: {
    ...portBase,
    name: 'Киномеханик',
    sub: 'Дом культуры',
    r: 35,
    ttk: 56,
    spd: 86,
    move: 'hover',
    col: '#e2c1a5',
    lines: {
      intro: 'Аншлаг. Я же вижу, все места заняты.',
      stages: [null, null, 'Кто выключил свет?'],
      death: 'Пока зал хлопает, автобус ходит по кругу. Выключи прожекторы на причале.',
    },
    stages: [
      portStage('Первый сеанс', 1, [['shutter']]),
      portStage(
        'Тень из зала',
        0.66,
        [
          ['shutter', { copies: 2 }],
          ['aimed', { count: 4, col: '#edd7ae' }],
        ],
        1.12,
      ),
      portStage(
        'Засветка',
        0.33,
        [
          ['shutter', { copies: 3 }],
          ['spiral', { arms: 2, dur: 1.4, col: '#ecd4cb' }],
        ],
        1.22,
      ),
    ],
  },
  pilot: {
    ...portBase,
    name: 'Слепой лоцман',
    sub: 'Плавучие сходни',
    r: 44,
    ttk: 58,
    spd: 89,
    col: '#e2ac77',
    lines: {
      intro: 'Слышу шаги. Кто там на сходнях?',
      stages: [null, null, null],
      death: 'Я держу сходни. Успеешь к автобусу, беги.',
    },
    stages: [
      portStage('Подход', 1, [['blindTurn']]),
      portStage(
        'Боковой ветер',
        0.66,
        [
          ['blindTurn', { backwash: 1 }],
          ['ring', { waves: 1, n: 9, col: '#bddada' }],
        ],
        1.12,
      ),
      portStage(
        'Навал',
        0.31,
        [
          ['blindTurn', { backwash: 2 }],
          ['tidalRun', { fx: 'pilotWake', passes: 2 }],
        ],
        1.23,
      ),
    ],
  },
  bycatch: {
    ...portBase,
    name: 'Прилов',
    sub: 'Красный трюм',
    r: 49,
    ttk: 48,
    spd: 0,
    optional: true,
    music: 'redHold',
    col: '#b7646b',
    lines: { intro: null, stages: [null, null, null], death: null },
    stages: [
      portStage('Первый пульс', 1, [['bloodPulse']]),
      portStage('Две жилы', 0.67, [['bloodPulse', { lanes: 2 }]]),
      portStage('Двойной пульс', 0.34, [['bloodPulse', { lanes: 2, double: true }]]),
    ],
  },
  understudy: {
    ...portBase,
    name: 'Дублёр Зямочкккка',
    sub: 'Последний причал',
    final: true,
    r: 43,
    ttk: 72,
    spd: 104,
    move: 'hover',
    col: '#dfaf92',
    lines: {
      intro: 'Вот вы где. Я уже дважды вышел на поклон.',
      stages: [null, 'Смотри, они тебя повторяют.', null, 'Насть. Хоть ты похлопай.'],
      death: null,
    },
    stages: [
      portStage('Выход на сцену', 1, [['encore']]),
      portStage('Репетиция', 0.75, [['encore', { copies: 2 }], ['shutter']], 1.1),
      portStage(
        'Полный зал',
        0.5,
        [
          ['encore', { copies: 3 }],
          ['shutter', { copies: 2 }],
        ],
        1.17,
      ),
      portStage(
        'Последний поклон',
        0.25,
        [
          ['encore', { copies: 3, repeat: true }],
          ['ring', { waves: 2, n: 10, col: '#d2c7a3' }],
        ],
        1.25,
      ),
    ],
  },
});
Object.assign(ENEMIES, {
  saltDiver: { ...ENEMIES.crab, name: 'Солёный водолаз', sprite: 'saltDiver', col: '#aca58b' },
  ticketShade: { ...ENEMIES.bat, name: 'Оторванный билет', sprite: 'ticketShade', col: '#edd3a5' },
});
const portTile = ([x, y]) => ({ x, y });
CHAPTERS[9] = {
  id: 9,
  title: 'Глава 9',
  name: 'Последний рейс',
  seed: 91345,
  MW: 150,
  MH: 110,
  blobs: 0,
  start: portTile(HARBOUR_MAP.start),
  castle: { x: 124, y: 22, half: 9, gate: 'south', biome: B9 + 2 },
  cage: portTile(HARBOUR_MAP.cage),
  biomeSeeds: HARBOUR_MAP.seeds,
  bosses: ['keel', 'netmender', 'projector', 'pilot', 'bycatch', 'understudy'],
  bossTiles: HARBOUR_MAP.bosses.map(portTile),
  bossLevels: [5, 8, 12, 16, 15, 21],
  requiredGuardians: 4,
  zoneLevel: { [B9]: 4, [B9 + 1]: 10, [B9 + 2]: 15, [B9 + 3]: 13 },
  chests: 23,
  chestDist: [3, 12],
  shrines: 5,
  noEvents: ['song', 'hearts', 'gold'],
  spawnEvery: 0.65,
  capBase: 12,
  elite: 0.055,
  diff: { hp: 1.48, dmg: 1.31 },
  hero: 'ryzhovaya',
  startLevel: 1,
  noCage: true,
  music: 'harbour',
  gateSay: 'На причале загорелись прожекторы. Зяма ещё в автобусе.',
  gateBanner: 'Сходни опущены',
  deadText: 'Рыжовая открывает глаза у последней остановки.',
};
ARENA_STYLE[9] = {
  name: 'Старый причал',
  floor: ['#4b5559', '#565d5e'],
  crack: '#8f806e',
  ember: '#b5a07b',
  wall: '#40484d',
  tint: '109,130,142',
};
CHEST_THEME[9] = { body: '#43535a', lid: '#817e65', dark: '#303537' };
