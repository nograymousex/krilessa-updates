'use strict';
// =====================================================================
//  Контент игры: версия, герои, локации, враги, боссы, главы, баланс.
//  Хочешь поменять баланс или реплики – меняй здесь.
// =====================================================================
const VERSION = '0.10.4 beta';

// ---------------- Тайлы ----------------
// Земля = номер биома (0..25), остальное – особые тайлы
const PATH = 50, STONE = 51, WATER = 52, ROCK = 53, WALL = 54, GATE = 55, LAVA = 56, FLOOR = 57, ICE = 58;

// ---------------- Герои ----------------
// Рыжовая стреляет огненными шарами (взрыв + поджог), вместо рывка – вспышка.
const HEROES = {
  krilessa: {
    name: 'Крилесса', proj: 'feather', dmg: 14, fireInt: 0.55, range: 200, speed: 165, hp: 100, projSpd: 480,
    dash: 'РЫВОК', super: 'storm', superName: 'Перьевой ураган', names: {},
  },
  ryzhovaya: {
    name: 'Рыжовая', proj: 'fire', dmg: 21, fireInt: 0.72, range: 215, speed: 160, hp: 115, projSpd: 400,
    splash: 38, burn: 0.35, dash: 'ВСПЫШКА', blink: true, super: 'nova', superName: 'Огненная ярость',
    names: {
      dmg: ['🔥', 'Жаркое пламя', '+25% урона'],
      rate: ['⚡', 'Быстрые искры', '+18% скорость атаки'],
      multi: ['☄️', 'Огненный залп', '+1 огненный шар за выстрел'],
      pierce: ['🌋', 'Прожигание', 'Шар пробивает +1 врага'],
      range: ['👁️', 'Дальний огонь', '+15% радиус атаки'],
      hp: ['❤️‍🔥', 'Горячее сердце', '+30 к здоровью и лечение'],
      orbit: ['🔥', 'Огненное кольцо', '+1 огонёк кружит вокруг тебя'],
      bolt: ['☄️', 'Метеоры', 'Метеоры бьют врагов цепочкой'],
      explode: ['💥', 'Большой бабах', 'Взрывы шаров шире и сильнее'],
      frost: ['🌫️', 'Удушливый дым', 'Шары замедляют врагов'],
      shield: ['🛡️', 'Огненный щит', 'Щит блокирует удар (перезарядка)'],
      dash: ['✨', 'Мастер вспышки', '-20% перезарядка вспышки'],
      vamp: ['🩸', 'Пламя жизни', '+1 HP за каждого побеждённого'],
      regen: ['🌿', 'Тёплый пепел', '+1 HP в секунду'],
    },
  },
};

// ---------------- Локации (биомы) ----------------
const BIOMES = [
  { id: 'forest', name: 'Лес', ground: ['#1d3a21', '#244629', '#18321c'], tree: 'oak', treeP: 0.15,
    obst: [[ROCK, 0.4], [WATER, 0.6]], deco: 'grass', mini: '#2d5a33' },
  { id: 'swamp', name: 'Болото', ground: ['#36442b', '#3e4e31', '#2e3a24'], tree: 'willow', treeP: 0.08,
    obst: [[WATER, 0.75], [ROCK, 0.25]], water: ['#4f7f6c', '#5b8e78', '#46725f'], deco: 'reeds', mini: '#4c5c38' },
  { id: 'snow', name: 'Ледяные вершины', ground: ['#dde7f0', '#e9f0f7', '#cdd9e6'], tree: 'pine', treeP: 0.1,
    obst: [[ROCK, 0.55], [ICE, 0.45]], deco: 'snow', mini: '#e6edf5' },
  { id: 'dark', name: 'Тёмные земли', ground: ['#2b2236', '#33293f', '#231c2c'], tree: 'dead', treeP: 0.06,
    obst: [[LAVA, 0.5], [ROCK, 0.5]], deco: 'bones', mini: '#3b3049' },
  { id: 'meadow', name: 'Цветочные луга', ground: ['#3d7a39', '#468a41', '#346a31'], tree: 'blossom', treeP: 0.09,
    obst: [[WATER, 0.55], [ROCK, 0.45]], deco: 'flowers', mini: '#55963f' },
  { id: 'desert', name: 'Пустыня Миражей', ground: ['#e0bf78', '#e9cb86', '#d4b067'], tree: 'cactus', treeP: 0.045,
    obst: [[ROCK, 0.78], [WATER, 0.22]], rock: ['#c48a4a', '#d39a5a', '#b37a3c'], water: ['#4fc3d9', '#6fd3e6', '#3fb0c6'],
    deco: 'desert', mini: '#e6c682' },
  { id: 'volcano', name: 'Вулкан Пылающий', ground: ['#3a2a28', '#45312d', '#2f2220'], tree: 'burnt', treeP: 0.05,
    obst: [[LAVA, 0.62], [ROCK, 0.38]], rock: ['#2c2428', '#372d32', '#221b1f'], deco: 'embers', mini: '#4d3430' },
  { id: 'crystal', name: 'Кристальные пещеры', ground: ['#28284a', '#303058', '#22223e'], tree: 'crystal', treeP: 0.08,
    obst: [[ROCK, 0.7], [WATER, 0.3]], rock: ['#7a5ad6', '#9070ea', '#6648c0'], water: ['#3fe0d0', '#66f0e0', '#2fc8b8'],
    deco: 'gems', mini: '#3a3a66' },
  { id: 'neon', name: 'Кринж-Цитадель', ground: ['#1b1132', '#231742', '#150d28'], tree: 'neonpalm', treeP: 0.05,
    obst: [[ROCK, 1]], rock: ['#3a1f5c', '#44256a', '#30184e'], deco: 'neon', mini: '#2b1b4b', neon: true },
  // ---- Глава 3: Зеркальный Зямоверс ----
  { id: 'glitch', name: 'Глитч-лес', ground: ['#123a3a', '#174646', '#0e3030'], tree: 'glitchtree', treeP: 0.1,
    obst: [[ROCK, 0.6], [WATER, 0.4]], rock: ['#2a2a4a', '#353560', '#20203a'], water: ['#03080c', '#071218', '#010406'],
    deco: 'glitch', mini: '#1f5050' },
  { id: 'candy', name: 'Сахарные холмы', ground: ['#f4b0cf', '#f9c2da', '#ec9fc2'], tree: 'lollipop', treeP: 0.07,
    obst: [[ROCK, 0.55], [WATER, 0.45]], rock: ['#fdf2f8', '#ff8cc6', '#f2dcea'], water: ['#6b3a1f', '#7a4526', '#5a301a'],
    path: ['#e8b878', '#f0c488', '#dca868'], deco: 'sprinkles', mini: '#f2aacb', candy: true },
  { id: 'sky', name: 'Облачные острова', ground: ['#e6f0ff', '#f4f9ff', '#d8e6fa'], tree: 'cloudtree', treeP: 0.05,
    obst: [[WATER, 0.8], [ROCK, 0.2]], rock: ['#c0c8e0', '#d0d8ee', '#b0b8d0'], water: ['#16225e', '#1e2c70', '#101a4e'],
    deco: 'sky', mini: '#dce8ff', rainbow: true },
  { id: 'toxic', name: 'Токсичная свалка', ground: ['#3a4030', '#444a38', '#30362a'], tree: 'junk', treeP: 0.05,
    obst: [[WATER, 0.55], [ROCK, 0.45]], rock: ['#4a4a52', '#5a3a2a', '#3a3a5a'], water: ['#5cf02a', '#7aff4a', '#46d81e'],
    path: ['#5a5a50', '#646458', '#4e4e46'], deco: 'trash', mini: '#4a5440' },
  { id: 'mirror', name: 'Зеркальный дворец', ground: ['#c4c4de', '#d0d0e8', '#b8b8d4'], tree: 'mirrorshard', treeP: 0.05,
    obst: [[ROCK, 1]], rock: ['#9ad8f8', '#bfeaff', '#7cc4ec'], deco: 'mirror', mini: '#bcbcd8', mirror: true },
];

// Тематическая музыка каждой локации (мелодии – в audio.js)
const BIOME_MUSIC = ['field', 'swamp', 'snow', 'dark', 'meadow', 'desert', 'volcano', 'crystal', 'field2', 'glitch', 'candy', 'sky', 'toxic', 'mirror'];

// ---------------- Враги ----------------
// hp/dmg/xp – относительные, реальные значения считает баланс (см. ниже)
// ai: chase | hop | bat | jump | ranged | healer | shield | exploder | swarm | turret | charger | bouncer | blinker | buffer | summoner
const ENEMIES = {
  slime: { name: 'Слизень', hp: 22, spd: 58, dmg: 8, r: 13, xp: 1, ai: 'hop', col: '#63d65a' },
  bat: { name: 'Нетопырь', hp: 12, spd: 112, dmg: 6, r: 10, xp: 1, ai: 'bat', fly: true, dodge: true, col: '#6b4a8f' },
  shroom: { name: 'Грибочек', hp: 36, spd: 50, dmg: 10, r: 14, xp: 2, ai: 'chase', col: '#e0403a' },
  pumpkin: { name: 'Тыквобомба', hp: 34, spd: 96, dmg: 26, r: 14, xp: 2, ai: 'exploder', col: '#ff8a1f' },
  frog: { name: 'Прыгуша', hp: 40, spd: 0, dmg: 12, r: 14, xp: 2, ai: 'jump', col: '#58b84a' },
  wisp: { name: 'Огонёк', hp: 30, spd: 58, dmg: 8, r: 11, xp: 2, ai: 'ranged', fly: true, col: '#b6ff7a',
    shot: { cd: 2.3, spd: 175, dmg: 9, n: 1, spread: 0, col: '#b6ff7a' } },
  shaman: { name: 'Болотный шаман', hp: 48, spd: 52, dmg: 8, r: 13, xp: 4, ai: 'healer', col: '#7dbd5a' },
  wolf: { name: 'Снежный волк', hp: 46, spd: 124, dmg: 12, r: 14, xp: 3, ai: 'chase', dodge: true, pack: true, col: '#cfe3f2' },
  snowman: { name: 'Снеговик', hp: 60, spd: 38, dmg: 12, r: 15, xp: 3, ai: 'ranged', col: '#ffffff',
    shot: { cd: 2.1, spd: 225, dmg: 12, n: 1, spread: 0, col: '#ffffff' } },
  iceguard: { name: 'Ледяной страж', hp: 95, spd: 46, dmg: 14, r: 16, xp: 4, ai: 'shield', col: '#8fd8ff' },
  shade: { name: 'Тень', hp: 70, spd: 78, dmg: 15, r: 14, xp: 4, ai: 'blinker', fly: true, col: '#3c145a' },
  imp: { name: 'Бесёнок', hp: 52, spd: 66, dmg: 12, r: 12, xp: 4, ai: 'ranged', fly: true, dodge: true, col: '#e0482a',
    shot: { cd: 2.0, spd: 235, dmg: 13, n: 3, spread: 0.18, col: '#ff7b2e' } },
  // ---- Глава 2 ----
  bee: { name: 'Пчёлка', hp: 18, spd: 155, dmg: 8, r: 9, xp: 1, ai: 'swarm', fly: true, group: [4, 6], col: '#ffd23a' },
  flower: { name: 'Плевунец', hp: 75, spd: 0, dmg: 10, r: 15, xp: 3, ai: 'turret', col: '#ff6fb5',
    shot: { cd: 2.3, spd: 250, dmg: 12, n: 1, burst: 3, spread: 0.06, col: '#ff6fb5' } },
  beetle: { name: 'Жук-щитоносец', hp: 115, spd: 54, dmg: 16, r: 17, xp: 4, ai: 'shield', col: '#3a7bd5' },
  scorpion: { name: 'Скорпион', hp: 72, spd: 72, dmg: 18, r: 15, xp: 3, ai: 'charger', col: '#c0703a' },
  tumble: { name: 'Перекати-поле', hp: 30, spd: 175, dmg: 10, r: 12, xp: 2, ai: 'bouncer', col: '#b08a4a' },
  mummy: { name: 'Мумик', hp: 125, spd: 42, dmg: 18, r: 16, xp: 4, ai: 'chase', split: 'mummini', col: '#e8dcc0' },
  mummini: { name: 'Мумичек', hp: 40, spd: 74, dmg: 10, r: 11, xp: 1, ai: 'chase', col: '#e8dcc0', sprite: 'mummy' },
  magma: { name: 'Магмовый слизень', hp: 92, spd: 62, dmg: 16, r: 16, xp: 3, ai: 'hop', split: 'magmini', col: '#ff6a22', sprite: 'slime' },
  magmini: { name: 'Искорка', hp: 30, spd: 92, dmg: 10, r: 10, xp: 1, ai: 'hop', col: '#ffb03a', sprite: 'slime' },
  firebomb: { name: 'Бомбастик', hp: 45, spd: 104, dmg: 40, r: 14, xp: 3, ai: 'exploder', col: '#3a3a3a', sprite: 'bomb' },
  fireimp: { name: 'Огненный бес', hp: 60, spd: 70, dmg: 14, r: 12, xp: 4, ai: 'ranged', fly: true, dodge: true, col: '#ff3b1f', sprite: 'imp',
    shot: { cd: 1.8, spd: 255, dmg: 14, n: 3, spread: 0.16, col: '#ffcc33' } },
  spiderling: { name: 'Паучок', hp: 22, spd: 145, dmg: 9, r: 10, xp: 1, ai: 'swarm', group: [3, 5], col: '#a68cff', sprite: 'spider' },
  cshaman: { name: 'Кристальный шаман', hp: 85, spd: 56, dmg: 10, r: 14, xp: 5, ai: 'healer', col: '#5be3ff' },
  cguard: { name: 'Кристальный страж', hp: 160, spd: 50, dmg: 20, r: 17, xp: 5, ai: 'shield', col: '#b18cff' },
  cringebot: { name: 'Кринж-бот', hp: 95, spd: 62, dmg: 14, r: 14, xp: 5, ai: 'ranged', col: '#ff3ea5', sprite: 'bot',
    shot: { cd: 1.8, spd: 235, dmg: 14, n: 5, spread: 0.2, emoji: true } },
  hater: { name: 'Ворчун', hp: 75, spd: 150, dmg: 18, r: 13, xp: 5, ai: 'blinker', dodge: true, col: '#222222' },
  fan: { name: 'Мини-Зямочкккк', hp: 60, spd: 115, dmg: 14, r: 13, xp: 3, ai: 'chase', col: '#ffffff' },
  zclone: { name: 'Клон Зямочкккк', hp: 900, spd: 0, dmg: 14, r: 20, xp: 0, ai: 'turret', col: '#ffffff', sprite: 'fan', noDrop: true,
    shot: { cd: 1.6, spd: 200, dmg: 16, n: 10, ring: true, emoji: true } },
  // ---- Глава 3 ----
  glitchbug: { name: 'Глитч-жук', hp: 34, spd: 125, dmg: 12, r: 11, xp: 2, ai: 'blinker', fly: true, col: '#3ff0a0' },
  errorwin: { name: 'Окно ошибки', hp: 95, spd: 0, dmg: 12, r: 16, xp: 5, ai: 'summoner', summons: 'pixel', col: '#3a6ad6',
    shot: { cd: 2.4, spd: 210, dmg: 12, n: 4, ring: true, col: '#ff3ea5', square: true } },
  pixel: { name: 'Пиксель', hp: 10, spd: 150, dmg: 6, r: 7, xp: 0.5, ai: 'swarm', group: [4, 6], col: '#3ff0ff' },
  virus: { name: 'Вирус', hp: 36, spd: 112, dmg: 30, r: 13, xp: 2, ai: 'exploder', col: '#7dff4a' },
  gummy: { name: 'Мармеладный мишка', hp: 75, spd: 60, dmg: 14, r: 15, xp: 3, ai: 'hop', split: 'gummini', col: '#ff4a6a' },
  gummini: { name: 'Мармеладик', hp: 25, spd: 95, dmg: 8, r: 10, xp: 1, ai: 'hop', col: '#ffb03a', sprite: 'gummy' },
  cupcake: { name: 'Кекс-поддержка', hp: 60, spd: 55, dmg: 8, r: 13, xp: 4, ai: 'buffer', col: '#ff8cc6' },
  candycane: { name: 'Леденцовый рыцарь', hp: 70, spd: 70, dmg: 18, r: 14, xp: 3, ai: 'charger', col: '#ff3b5c' },
  lollipop: { name: 'Чупа-турель', hp: 85, spd: 0, dmg: 10, r: 15, xp: 3, ai: 'turret', col: '#b18cff',
    shot: { cd: 1.5, spd: 190, dmg: 11, n: 6, ring: true, spin: true, col: '#ff6fb5' } },
  cloudling: { name: 'Грозовое облачко', hp: 55, spd: 60, dmg: 14, r: 14, xp: 3, ai: 'ranged', fly: true, col: '#9aa8c8',
    shot: { cd: 2.6, kind: 'bolt', dmg: 18 } },
  pegasus: { name: 'Пегасик', hp: 60, spd: 95, dmg: 16, r: 14, xp: 3, ai: 'charger', fly: true, col: '#f0e8ff' },
  starfall: { name: 'Падучая звезда', hp: 30, spd: 135, dmg: 34, r: 12, xp: 2, ai: 'exploder', fly: true, col: '#ffe04a' },
  harpy: { name: 'Гарпия', hp: 45, spd: 128, dmg: 12, r: 12, xp: 2, ai: 'bat', fly: true, dodge: true, col: '#c08aff' },
  trashbot: { name: 'Мусоробот', hp: 150, spd: 48, dmg: 20, r: 17, xp: 5, ai: 'shield', col: '#7a8a9a' },
  commenter: { name: 'Сплетник', hp: 70, spd: 64, dmg: 13, r: 13, xp: 4, ai: 'ranged', col: '#ffffff',
    shot: { cd: 1.9, spd: 240, dmg: 13, n: 3, spread: 0.18, emoji: true, emojiSet: ['💬', '🤬', '💢', '🙄'] } },
  rat: { name: 'Крыска', hp: 20, spd: 158, dmg: 9, r: 9, xp: 0.7, ai: 'swarm', group: [4, 7], col: '#8a8a8a' },
  sludge: { name: 'Слизь-токсик', hp: 90, spd: 58, dmg: 15, r: 16, xp: 3, ai: 'hop', split: 'sludgelet', puddle: true, col: '#6cff3a', sprite: 'slime' },
  sludgelet: { name: 'Слизнячок', hp: 30, spd: 90, dmg: 9, r: 10, xp: 1, ai: 'hop', col: '#a8ff7a', sprite: 'slime' },
  mknight: { name: 'Зеркальный рыцарь', hp: 170, spd: 52, dmg: 20, r: 17, xp: 5, ai: 'shield', col: '#9ad8f8' },
  reflection: { name: 'Отражение', hp: 80, spd: 70, dmg: 14, r: 13, xp: 5, ai: 'ranged', dodge: true, col: '#ffa04a',
    shot: { cd: 1.7, spd: 260, dmg: 15, n: 2, spread: 0.12, col: '#ff8a3a' } },
  shardling: { name: 'Осколочек', hp: 24, spd: 150, dmg: 10, r: 9, xp: 0.8, ai: 'swarm', fly: true, group: [3, 5], col: '#bfeaff' },
  zmirror: { name: 'Волшебное зеркало', hp: 1, spd: 0, dmg: 14, r: 22, xp: 0, ai: 'turret', col: '#bfeaff', noDrop: true, bossPart: true,
    shot: { cd: 1.9, spd: 200, dmg: 15, n: 8, ring: true, col: '#bfeaff' } },
};
const SPAWNS = [
  [['slime', 5], ['bat', 3], ['shroom', 2], ['pumpkin', 0.7]],
  [['frog', 4], ['wisp', 3], ['bat', 2], ['shaman', 1]],
  [['wolf', 4], ['snowman', 3], ['bat', 2], ['iceguard', 1.2]],
  [['shade', 3], ['imp', 3], ['bat', 2], ['pumpkin', 1.5]],
  [['bee', 2.5], ['flower', 2], ['beetle', 1.5], ['slime', 2], ['pumpkin', 1]],
  [['scorpion', 3], ['tumble', 3], ['mummy', 2]],
  [['magma', 3], ['fireimp', 3], ['firebomb', 2]],
  [['spiderling', 3], ['cguard', 2], ['cshaman', 1.2], ['bat', 2]],
  [['cringebot', 3], ['hater', 3], ['fan', 3]],
  [['glitchbug', 3], ['errorwin', 1.2], ['pixel', 2.5], ['virus', 1.5]],
  [['gummy', 3], ['cupcake', 1.2], ['candycane', 2.5], ['lollipop', 1.5]],
  [['cloudling', 3], ['pegasus', 2.5], ['starfall', 2], ['harpy', 2.5]],
  [['trashbot', 2], ['commenter', 3], ['rat', 2.5], ['sludge', 2.5]],
  [['mknight', 2], ['reflection', 3], ['shardling', 2.5], ['fan', 2]],
];

// Элитные приставки: элита получает одну случайную
const AFFIXES = [
  { id: 'fast', name: 'Быстрый', col: '#4dff9a' },
  { id: 'armored', name: 'Бронированный', col: '#b8c4d8' },
  { id: 'volatile', name: 'Взрывной', col: '#ff8a2a' },
  { id: 'vampiric', name: 'Вампир', col: '#ff3b5c' },
  { id: 'frenzied', name: 'Бешеный', col: '#ffd23a' },
];

// ---------------- Боссы ----------------
// ttk – сколько секунд должен длиться бой на "ожидаемом" уровне,
// hit/touch – доля здоровья героя, которую снимает снаряд/касание.
// Реальные HP и урон подстраиваются под силу игрока (см. Баланс).
const BOSSES = {
  shroom: {
    name: 'Гриб-Громила', sub: 'Страж Леса', r: 38, ttk: 40, hit: 0.07, touch: 0.12, spd: 62, move: 'chase', col: '#d8322b',
    lines: {
      intro: 'Я Гриб-Громила! Споры – это мой язык любви! 🍄',
      stages: ['', 'Ты меня ранила... А я ведь просто хотел обнимашек! СПОРО-ДЭНС!', 'Всё! Я больше не шампиньон! Я – МУХОМОР! Бойся!'],
      death: 'Передайте маме... я был хорошим грибочком...',
    },
    stages: [
      { attacks: [['ring', { n: 14, waves: 3 }], ['stomp', { r: 140 }], ['summon', { type: 'shroom', n: 2 }]] },
      { at: 0.66, spd: 1.2, attacks: [['ring', { n: 18, waves: 4, spd: 165 }], ['stomp', { r: 150, repeat: 2 }], ['rain', { n: 6 }], ['summon', { type: 'shroom', n: 3 }]] },
      { at: 0.33, spd: 1.35, attacks: [['spiral', { arms: 4, dur: 3 }], ['stomp', { r: 170, repeat: 3 }], ['ring', { n: 22, waves: 5, spd: 175 }], ['wave', { n: 2 }]] },
    ],
  },
  toad: {
    name: 'Жаба-Королева', sub: 'Страж Болота', r: 42, ttk: 45, hit: 0.075, touch: 0.13, spd: 70, move: 'chase', col: '#4caf50',
    lines: {
      intro: 'Ква! На колени перед королевой! 👑',
      stages: ['', 'Ты испортила мне маникюр!!! ЖАБА-ДЭНС, все в круг!', 'Квааааа! Корона съехала! Это ВОЙНА!'],
      death: 'Ква... я просто хотела... принца...',
    },
    stages: [
      { attacks: [['leap', { r: 100 }], ['lash', {}], ['shotgun', { n: 5, waves: 3 }], ['summon', { type: 'frog', n: 2 }]] },
      { at: 0.66, spd: 1.2, attacks: [['leap', { r: 110, repeat: 2 }], ['lash', { repeat: 2 }], ['shotgun', { n: 7, waves: 4 }], ['wave', { n: 1 }]] },
      { at: 0.33, spd: 1.35, attacks: [['leap', { r: 120, repeat: 3, ringN: 16 }], ['lash', { repeat: 3, fan: 3 }], ['rain', { n: 8 }], ['homing', { n: 4 }], ['summon', { type: 'frog', n: 3 }]] },
    ],
  },
  yeti: {
    name: 'Ледяной Йети', sub: 'Страж Вершин', r: 42, ttk: 50, hit: 0.08, touch: 0.14, spd: 80, move: 'chase', col: '#eef6ff',
    lines: {
      intro: 'Я не толстый, я ПУШИСТЫЙ! ❄️',
      stages: ['', 'Брррр-вайб активирован! Чиллим ЖЁСТКО!', 'Мне жарко от злости! Я ТАЮ, НО НЕ СДАЮСЬ!'],
      death: 'Я... превращаюсь... в лужицу... 💧',
    },
    stages: [
      { attacks: [['charge', { repeat: 2 }], ['aimed', { count: 10 }], ['rain', { n: 7, fx: 'icicle' }]] },
      { at: 0.66, spd: 1.2, attacks: [['charge', { repeat: 3 }], ['aimed', { count: 14 }], ['rain', { n: 10, fx: 'icicle' }], ['summon', { type: 'wolf', n: 2 }]] },
      { at: 0.33, spd: 1.35, attacks: [['charge', { repeat: 4, ringN: 12 }], ['ring', { n: 20, waves: 3, col: '#ffffff' }], ['rain', { n: 14, rate: 0.18, fx: 'icicle' }], ['wave', { n: 3 }]] },
    ],
  },
  mrak: {
    name: 'Колдун Мрак', sub: 'Повелитель Тёмного замка', r: 34, ttk: 70, hit: 0.08, touch: 0.12, spd: 80, move: 'hover', fly: true, col: '#2a1240',
    lines: {
      intro: 'Я тёмный, как мой кофе и мои стихи... 🖤',
      stages: ['', 'Ты не понимаешь мою боль! Я слушаю грустные треки с 2007-го!', 'ФИНАЛЬНАЯ ФОРМА: ЭМО-КОЛДУН! Чёлка на оба глаза!'],
      death: 'Это... не конец... это просто... финал сезона...',
    },
    stages: [
      { attacks: [['spiral', { arms: 3 }], ['teleport', {}], ['summon', { type: 'shade', n: 3 }], ['rain', { n: 10, fx: 'dark' }]] },
      { at: 0.66, spd: 1.2, attacks: [['spiral', { arms: 4 }], ['teleport', { ringN: 16 }], ['homing', { n: 4 }], ['laser', { beams: 2, rot: 0.8 }]] },
      { at: 0.33, spd: 1.3, attacks: [['spiral', { arms: 6, dur: 3.5 }], ['laser', { beams: 3, rot: 1.05 }], ['homing', { n: 6 }], ['cross', {}], ['wave', { n: 3 }]] },
    ],
  },
  // ---------------- Глава 2 ----------------
  cactus: {
    name: 'Кактус Обнимус', sub: 'Страж Пустыни', r: 40, ttk: 50, hit: 0.08, touch: 0.14, spd: 72, move: 'chase', col: '#3fae4a',
    lines: {
      intro: 'Обнимашки? ОБНИМАШКИ!!! 🌵🤗 Иди ко мне!',
      stages: ['', 'Почему все убегают?! Я колючий только СНАРУЖИ!', 'Ладно. Раз никто не обнимает – обниму ВСЕХ ИГЛАМИ!'],
      death: 'Наконец-то... кто-то... подошёл близко...',
    },
    stages: [
      { attacks: [['ring', { n: 16, waves: 3, spd: 190, col: '#c6ff7a' }], ['charge', { repeat: 2 }], ['summon', { type: 'tumble', n: 3 }], ['shotgun', { n: 7, waves: 3 }]] },
      { at: 0.66, spd: 1.2, attacks: [['ring', { n: 22, waves: 4, spd: 200, col: '#c6ff7a' }], ['charge', { repeat: 3, ringN: 10 }], ['rain', { n: 10 }], ['aimed', { count: 12 }]] },
      { at: 0.33, spd: 1.4, attacks: [['spiral', { arms: 5, col: '#c6ff7a' }], ['charge', { repeat: 4, ringN: 14 }], ['ring', { n: 28, waves: 5, spd: 210, col: '#c6ff7a' }], ['wave', { n: 3 }], ['summon', { type: 'tumble', n: 4 }]] },
    ],
  },
  bee: {
    name: 'Кибер-Пчела Жужа', sub: 'Страж Лугов', r: 34, ttk: 50, hit: 0.08, touch: 0.12, spd: 120, move: 'hover', fly: true, col: '#ffd23a',
    lines: {
      intro: 'Бзззз! Жужа прилетела! Мой мёд – самый липкий в мире, проверим? 🐝',
      stages: ['', 'Ты не заплатила за мёд?! Отправляю РОЙ КОЛЛЕКТОРОВ!', 'Режим ОВЕРКЛОК! Мои крылья жужжат на МАКСИМУМ!!! ⚡'],
      death: 'Бз... бз... батарейка... 1%...',
    },
    stages: [
      { attacks: [['aimed', { count: 12, spd: 300, col: '#ffd23a' }], ['honey', { n: 4 }], ['summon', { type: 'bee', n: 6, max: 12 }], ['charge', { repeat: 2, spd: 700 }]] },
      { at: 0.66, spd: 1.2, attacks: [['homing', { n: 6 }], ['honey', { n: 6 }], ['charge', { repeat: 3, spd: 720 }], ['shotgun', { n: 9, waves: 3 }]] },
      { at: 0.33, spd: 1.35, attacks: [['spiral', { arms: 4, col: '#ffd23a' }], ['charge', { repeat: 4, spd: 780 }], ['summon', { type: 'bee', n: 8, max: 14 }], ['laser', { beams: 2, rot: 0.9 }], ['rain', { n: 12 }]] },
    ],
  },
  golem: {
    name: 'Лавовый Голем', sub: 'Страж Вулкана', r: 50, ttk: 55, hit: 0.085, touch: 0.15, spd: 56, move: 'chase', col: '#3a2a2a',
    lines: {
      intro: 'Я ГОРЯЧИЙ! Не в том смысле... хотя и в том тоже 🔥😏',
      stages: ['', 'Ты меня остудила?! Сейчас я ВЗОРВУСЬ ОТ ЧУВСТВ!', 'ИЗВЕРЖЕНИЕ ЭМОЦИЙ! Все в укрытие!!! 🌋'],
      death: 'Я... остываю... как твои чувства ко мне...',
    },
    stages: [
      { attacks: [['stomp', { r: 170 }], ['erupt', { n: 8 }], ['aimed', { count: 6, r: 13, spd: 240, col: '#ff8a3a' }]] },
      { at: 0.66, spd: 1.15, attacks: [['stomp', { r: 190, repeat: 2 }], ['erupt', { n: 12 }], ['wave', { n: 2 }], ['ring', { n: 20, waves: 3, col: '#ff8a3a' }]] },
      { at: 0.33, spd: 1.3, attacks: [['wave', { n: 4 }], ['erupt', { n: 16 }], ['stomp', { r: 220, repeat: 3 }], ['cross', {}], ['summon', { type: 'firebomb', n: 3 }]] },
    ],
  },
  spider: {
    name: 'Кристальный Паук', sub: 'Страж Пещер', r: 44, ttk: 60, hit: 0.085, touch: 0.14, spd: 92, move: 'chase', col: '#8f70ea',
    lines: {
      intro: 'Восемь ног, восемь глаз... и ноль друзей. 🕷️💎',
      stages: ['', 'Ты разбила мне кристалл и СЕРДЕЧКО! ПАУТИНА БОЛИ!', 'Добро пожаловать в мою паутину... в мой ВНУТРЕННИЙ МИР!'],
      death: 'Хоть кто-то... со мной... поиграл...',
    },
    stages: [
      { attacks: [['web', { n: 5 }], ['summon', { type: 'spiderling', n: 6, max: 12 }], ['laser', { beams: 1, rot: 0.7 }], ['leap', { r: 110 }]] },
      { at: 0.66, spd: 1.2, attacks: [['web', { n: 7, waves: 2 }], ['mines', { n: 12 }], ['laser', { beams: 2, rot: 0.85 }], ['summon', { type: 'spiderling', n: 8, max: 14 }], ['ring', { n: 20, waves: 3 }]] },
      { at: 0.33, spd: 1.35, attacks: [['laser', { beams: 4, rot: 0.95 }], ['mines', { n: 16 }], ['spiral', { arms: 5 }], ['leap', { r: 130, repeat: 3, ringN: 14 }], ['web', { n: 9, waves: 3 }]] },
    ],
  },
  zyama: {
    name: 'Зямочкккк', sub: 'Император Кринжа', r: 46, ttk: 95, hit: 0.085, touch: 0.12, spd: 95, move: 'hover', fly: true, col: '#ffffff', final: true,
    lines: {
      intro: 'Трепещите, зайки! Я – ЗЯМОЧКККК, Император Кринжа! Сейчас прочту вам стих… атаками! 💅',
      stages: ['',
        'Ой, ты меня поцарапала! Это была моя ЛУЧШАЯ поза! Активирую БЛЕСК БРЕКЕТОВ! ✨🦷',
        'Окей. Окей. Надеваю очки. Включаю режим СИГМЫ. 🗿 Не пиши мне больше.',
        'ВСЁ! Это мой ПОСЛЕДНИЙ ТАНЕЦ! Оркестр, туш! Я ухожу красиво!!! 😭🔥'],
      death: 'Это была... шутка... 😢 Аплодисменты... Зямочкккк вернётся в версии 0.03...',
      taunts: ['Похлопай, если тебе больно! 👏', 'Ты видела мой новый танец?! Смотри ещё раз! 💃', 'Это не кринж, это ИСКУССТВО! 💅',
        'Мои брекеты стоят дороже твоих крыльев!', 'Крилесса, хочешь автограф? Со скидкой!', 'Сейчас будет кульминация!!!',
        'Я не проигрываю, я делаю сюжетный поворот!'],
    },
    stages: [
      { attacks: [['emoji', { n: 14, waves: 3 }], ['homing', { n: 5, heart: true }], ['summon', { type: 'fan', n: 4, max: 8 }], ['shotgun', { n: 9, waves: 3, emoji: true }]] },
      { at: 0.75, spd: 1.15, attacks: [['laser', { beams: 2, rot: 0.9, mouth: true }], ['charge', { repeat: 2, spd: 700 }], ['emoji', { n: 18, waves: 4 }], ['rain', { n: 12, fx: 'dark' }]] },
      { at: 0.5, spd: 1.25, attacks: [['teleport', { ringN: 20 }], ['clones', { n: 3 }], ['spiral', { arms: 5, emoji: true }], ['cross', {}], ['laser', { beams: 3, rot: 1.0, mouth: true }]] },
      { at: 0.25, spd: 1.4, attacks: [['wave', { n: 4 }], ['spiral', { arms: 7, dur: 4, emoji: true }], ['laser', { beams: 4, rot: 1.15, mouth: true }], ['homing', { n: 8, heart: true }], ['rain', { n: 16, fx: 'dark' }], ['emoji', { n: 24, waves: 5 }]] },
    ],
  },
  // ---------------- Глава 3 ----------------
  glitchcat: {
    name: 'Мяу.exe', sub: 'Страж Глитч-леса', r: 38, ttk: 55, hit: 0.09, touch: 0.14, spd: 105, move: 'chase', col: '#3ff0a0',
    lines: {
      intro: 'Мяу! Загрузка злости... 99%... 🐱💻',
      stages: ['', 'Error 404: доброта не найдена. Мяу.', 'Мяу.exe не отвечает. ЗАВЕРШИТЬ ПРОЦЕСС? НИКОГДА!!!'],
      death: 'Мяу... синий экран... нажмите любую клавишу...',
    },
    stages: [
      { attacks: [['pixels', { n: 1 }], ['glitch', { n: 3 }], ['aimed', { count: 12, col: '#3ff0a0', r: 8, square: true }], ['summon', { type: 'pixel', n: 6, max: 12 }]] },
      { at: 0.66, spd: 1.2, attacks: [['pixels', { n: 2 }], ['glitch', { n: 4 }], ['spiral', { arms: 4, col: '#3ff0a0', square: true }], ['laser', { beams: 2, rot: 0.9 }]] },
      { at: 0.33, spd: 1.35, attacks: [['pixels', { n: 3, both: true }], ['glitch', { n: 5 }], ['cross', {}], ['ring', { n: 24, waves: 4, col: '#ff3ea5', square: true }], ['summon', { type: 'virus', n: 3 }]] },
    ],
  },
  cakequeen: {
    name: 'Королева Глазурия', sub: 'Страж Сахарных холмов', r: 44, ttk: 56, hit: 0.085, touch: 0.14, spd: 64, move: 'chase', col: '#ff8cc6',
    lines: {
      intro: 'Ты слишком НЕсладкая для моего королевства! 🧁👑',
      stages: ['', 'Мой крем – мои правила! Взбиваю ЯРОСТЬ!', 'Кто съел мой последний кусочек?! ТОРТ-ВОЙНА!!!'],
      death: 'Я... таю... как мороженое в июле... 🍦',
    },
    stages: [
      { attacks: [['sprinkles', { dur: 2 }], ['cream', { n: 4 }], ['summon', { type: 'gummy', n: 3 }], ['shotgun', { n: 7, waves: 3, col: '#ff6fb5' }]] },
      { at: 0.66, spd: 1.2, attacks: [['sprinkles', { dur: 2.2 }], ['leap', { r: 120 }], ['cream', { n: 6 }], ['ring', { n: 20, waves: 3, col: '#ff6fb5' }]] },
      { at: 0.33, spd: 1.35, attacks: [['leap', { r: 130, repeat: 3, ringN: 16 }], ['sprinkles', { dur: 2.6 }], ['wave', { n: 3 }], ['summon', { type: 'lollipop', n: 2, max: 3 }], ['homing', { n: 6, heart: true }]] },
    ],
  },
  unicorn: {
    name: 'Громовая Радужка', sub: 'Страж Облачных островов', r: 40, ttk: 60, hit: 0.09, touch: 0.15, spd: 110, move: 'hover', fly: true, col: '#ffffff',
    lines: {
      intro: 'Я единорог, а значит – я ЛУЧШЕ ВСЕХ! 🦄🌈',
      stages: ['', 'Радуга – это не цвета. Это ОРУЖИЕ!', 'Блёстки в глаза! Ослепительная стадия!!! ✨✨✨'],
      death: 'Радуга... стала... серой...',
    },
    stages: [
      { attacks: [['charge', { repeat: 2, spd: 720, trail: true }], ['lightning', { n: 6 }], ['aimed', { count: 10, col: '#fff04a' }]] },
      { at: 0.66, spd: 1.2, attacks: [['charge', { repeat: 3, spd: 740, trail: true }], ['lightning', { n: 9 }], ['laser', { beams: 1, rot: 1.1, rainbow: true }], ['summon', { type: 'starfall', n: 3 }]] },
      { at: 0.33, spd: 1.35, attacks: [['charge', { repeat: 4, spd: 780, trail: true, ringN: 14 }], ['lightning', { n: 14, rate: 0.15 }], ['spiral', { arms: 6, rainbow: true }], ['laser', { beams: 3, rot: 1.0, rainbow: true }]] },
    ],
  },
  trashbot: {
    name: 'Робот-Ворчун Хламушка', sub: 'Страж Свалки', r: 46, ttk: 65, hit: 0.095, touch: 0.15, spd: 66, move: 'chase', col: '#7a8a9a',
    lines: {
      intro: 'ВСЁ ПЛОХО. ВСЁ ПЛОХО. ВСЁ ПЛОХО. 🤖💢',
      stages: ['', 'Анализ: ты слишком милая. Запускаю ПРОТОКОЛ ВОРЧАНИЯ.', 'КРИТИЧЕСКАЯ ОШИБКА: я тоже хочу, чтобы меня обняли... 🥺 АТАКА!!!'],
      death: 'Ворчание... выключено... 💔',
    },
    stages: [
      { attacks: [['comments', { waves: 3 }], ['missiles', { n: 4 }], ['toxic', { n: 4 }], ['saws', { n: 2 }]] },
      { at: 0.66, spd: 1.2, attacks: [['saws', { n: 4 }], ['missiles', { n: 6 }], ['charge', { repeat: 2 }], ['comments', { waves: 4 }], ['summon', { type: 'rat', n: 6, max: 12 }]] },
      { at: 0.33, spd: 1.35, attacks: [['saws', { n: 6 }], ['toxic', { n: 8 }], ['laser', { beams: 2, rot: 0.9 }], ['wave', { n: 3 }], ['missiles', { n: 8 }]] },
    ],
  },
  zyama2: {
    name: 'Зямочкккк 2.0', sub: 'Зеркальный Император', r: 48, ttk: 88, hit: 0.082, touch: 0.12, spd: 100, move: 'hover', fly: true, col: '#ffffff', final: true,
    sprite: 'zyama', avatar: 'zyama',
    lines: {
      intro: 'Трепещите, зайки! Я же обещал вернуться в 0.03! Встречайте – ЗЯМОЧКККК 2.0! 💅✨',
      stages: ['',
        'Зеркало, зеркало, кто на свете всех кринжовее? ПРАВИЛЬНО – Я! 🪞',
        'Очки сигмы 2.0. Теперь с RGB-подсветкой. 🗿🌈',
        'Дуэт с самим собой – лучший дуэт в истории! 👯👯',
        'Финальный акт... Оркестр, это мой ПОСЛЕДНИЙ ШАНС!!! 😭🔥🔥'],
      death: 'Рыжовая... ты... круче, чем я думал... Можно твой автограф?.. 🥲',
      taunts: ['Рыжовая, твои волосы горят ярче моей короны! 🔥', 'Она что, реально меня бьёт?!',
        'Крилесса в клетке слушает мои стихи, кстати! 📜', 'Похлопай, если ты огненная! 👏',
        'Это не поражение, это АНТРАКТ!', 'Зеркальце, скажи, я всё ещё сигма? 🗿', 'Версия 2.0 – значит в два раза кринжовее!'],
    },
    stages: [
      { attacks: [['emoji', { n: 16, waves: 3 }], ['homing', { n: 5, heart: true }], ['summon', { type: 'fan', n: 4, max: 8 }], ['aimed', { count: 12, emoji: true }]] },
      { at: 0.8, spd: 1.1, attacks: [['mirrors', { n: 4 }], ['emoji', { n: 20, waves: 3 }], ['rain', { n: 10, fx: 'dark' }], ['shotgun', { n: 9, waves: 3, emoji: true }]] },
      { at: 0.6, spd: 1.2, attacks: [['laser', { beams: 4, rot: 1.0, mouth: true, rainbow: true }], ['charge', { repeat: 3, spd: 760 }], ['cross', {}], ['pixels', { n: 2 }]] },
      { at: 0.4, spd: 1.3, attacks: [['clones', { n: 3 }], ['spiral', { arms: 5, emoji: true }], ['teleport', { ringN: 22 }], ['glitch', { n: 4 }], ['sprinkles', { dur: 2.5 }]] },
      { at: 0.2, spd: 1.45, attacks: [['wave', { n: 4 }], ['laser', { beams: 4, rot: 1.1, mouth: true, rainbow: true }], ['spiral', { arms: 6, dur: 3.5, emoji: true }], ['homing', { n: 7, heart: true }], ['rain', { n: 12, fx: 'dark' }], ['mirrors', { n: 3 }]] },
    ],
  },
};

// Финальная подлянка главы 3: бессмертный Зямочкккк – нужно продержаться
BOSSES.zyamaInf = {
  name: 'Зямочкккк ∞', sub: 'Бесконечный бис', r: 56, ttk: 999, hit: 0.075, touch: 0.12, spd: 115, move: 'hover', fly: true,
  col: '#ff3ea5', final: true, sprite: 'zyama', avatar: 'zyama', immortal: true, survive: 40,
  lines: {
    intro: 'Вы думали, это конец? Это был только АНТРАКТ! Режим ∞ АКТИВИРОВАН! 😈♾️',
    stages: [''],
    death: 'Ладно... ладно... вы победили. По-настоящему. Даже я аплодирую 👏❤️',
    taunts: ['Я бессмертный, у меня абонемент в вечность! 🎫', 'Крилесса, ты что, ей помогаешь?! Это нечестно!',
      'Ещё чуть-чуть – и я спою на бис! 🎤', 'Дружба? Фу, как кринжово... ой, кринж – это же я.', 'Спектакль. Не. Остановить!!!'],
  },
  stages: [{ attacks: [['spiral', { arms: 6, emoji: true }], ['laser', { beams: 3, rot: 1.1, mouth: true, rainbow: true }],
    ['emoji', { n: 22, waves: 3 }], ['rain', { n: 12, fx: 'dark' }], ['wave', { n: 3 }], ['pixels', { n: 2, both: true }], ['homing', { n: 6, heart: true }]] }],
};
// Подколки для всех боссов (кринж во время боя)
const BOSS_TAUNTS = {
  shroom: ['Я модный! Грибы сейчас – это ЭСТЕТИКА! 🍄', 'Не наступай на мою шляпку!', 'Мухомор – не диагноз, а стиль!'],
  toad: ['Ква-ква, где мой принц?!', 'Я квакаю в тональности ля-минор, между прочим!', 'Корона натирает, но я терплю – я КОРОЛЕВА!'],
  yeti: ['Я не бегу, я делаю кардио! ❄️', 'Снежок в лицо – это мой язык любви!', 'Холодно? Надень шапку, кринжуля!'],
  mrak: ['Меня никто не понимает... кроме моего плейлиста.', 'Тьма – это просто свет, который выключили 🖤', 'Я не грустный, я ЗАДУМЧИВЫЙ!'],
  cactus: ['Ну давай обнимемся, тебе жалко, что ли?! 🌵', 'Колючки – это просто защитный механизм!', 'Я поливаю себя раз в месяц. СЕГОДНЯ!'],
  bee: ['Бзз! Твой мёд просрочен!', 'Жужа – не пчела, Жужа – ЛЕГЕНДА! 🐝', 'Мёд кончился, остался только ЯД!'],
  golem: ['Мне жарко, но я не жалуюсь. Жалуюсь! 🔥', 'Лава в моих венах – это не метафора!', 'Обнимешь – и ты тоже вулкан 😏'],
  spider: ['Я написал тебе в паутину. Почему не отвечаешь?!', 'Восемь ног – и все левые 🕷️', 'Кристаллы – это мои слёзы. Красиво, да?'],
  glitchcat: ['Мяу.exe: обнаружен вирус ДРУЖБЫ. Удалить?', 'Лаги – это фича, мяу!', 'Перезагрузите меня... пожалуйста... мяу.'],
  cakequeen: ['Ты на диете? Я тоже. Я ем ВРАГОВ! 🧁', 'Посыпка – моё всё!', 'В моём королевстве калории не считаются!'],
  unicorn: ['Мой рог светится в темноте, а твой?', 'Радуга сама себя не покакает! 🌈', 'Я на 80% блёстки и на 20% злость!'],
  trashbot: ['ЗАГРУЗКА ВОРЧАНИЯ... 47%...', 'Твоя улыбка не засчитана. Повторите позже.', 'Я переработан, но не перевоспитан! 🤖'],
};
for (const k in BOSS_TAUNTS) BOSSES[k].lines.taunts = BOSS_TAUNTS[k];

// ---------------- Главы ----------------
// zoneLevel – ожидаемый уровень героя в локации, bossLevels – у каждого босса.
// Прокачка своя в каждой главе: всегда с 1 уровня, к финалу ~25.
const CHAPTERS = {
  1: {
    id: 1, title: 'Глава 1', name: 'Спасение Рыжовой', seed: 20261102, MW: 120, MH: 120, blobs: 66,
    start: { x: 60, y: 108 },
    bossTiles: [{ x: 22, y: 80 }, { x: 24, y: 24 }, { x: 96, y: 22 }, { x: 92, y: 89 }],
    bosses: ['shroom', 'toad', 'yeti', 'mrak'],
    castle: { x: 92, y: 86, half: 12, gate: 'west', biome: 3 },
    cage: { x: 92, y: 78 },
    biomeSeeds: [
      [0, 40, 92], [0, 62, 106], [0, 55, 62], [0, 18, 66], [0, 70, 80],
      [1, 22, 26], [1, 45, 22], [1, 10, 44], [1, 40, 42],
      [2, 96, 22], [2, 74, 16], [2, 106, 44], [2, 78, 42],
      [3, 92, 86], [3, 104, 66], [3, 88, 104],
    ],
    chests: 12, chestDist: [9, 22], shrines: 3, elite: 0.04, spawnEvery: 0.42, capBase: 14,
    zoneLevel: { 0: 4, 1: 9, 2: 14, 3: 19 }, bossLevels: [6, 11, 16, 21], diff: { hp: 1, dmg: 1 },
    hero: 'krilessa', hostage: 'ryzhova', music: 'field', startLevel: 1,
  },
  2: {
    id: 2, title: 'Глава 2', name: 'Кринж-Цитадель', seed: 7770002, MW: 180, MH: 180, blobs: 120,
    start: { x: 90, y: 171 },
    bossTiles: [{ x: 30, y: 140 }, { x: 30, y: 52 }, { x: 150, y: 28 }, { x: 154, y: 118 }, { x: 90, y: 86 }],
    bosses: ['cactus', 'bee', 'golem', 'spider', 'zyama'],
    castle: { x: 90, y: 82, half: 16, gate: 'south', biome: 8 },
    cage: { x: 90, y: 71 },
    biomeSeeds: [
      [4, 90, 165], [4, 120, 172], [4, 62, 152], [4, 90, 128], [4, 30, 62], [4, 52, 40], [4, 10, 82], [4, 60, 95],
      [5, 30, 140], [5, 12, 112], [5, 52, 120], [5, 20, 170],
      [6, 150, 28], [6, 120, 14], [6, 172, 58], [6, 128, 44], [6, 100, 30],
      [7, 154, 118], [7, 172, 148], [7, 130, 140], [7, 172, 95], [7, 140, 165],
      [8, 90, 82], [8, 90, 56], [8, 114, 82], [8, 66, 78],
    ],
    chests: 20, chestDist: [10, 26], shrines: 7, elite: 0.07, spawnEvery: 0.34, capBase: 20,
    zoneLevel: { 4: 4, 5: 5, 6: 12, 7: 16, 8: 21 }, bossLevels: [6, 10, 14, 18, 23], diff: { hp: 1.15, dmg: 1.2 },
    hero: 'krilessa', hostage: 'ryzhova', music: 'field2', startLevel: 1,
  },
  3: {
    id: 3, title: 'Глава 3', name: 'Рыжовая спешит на помощь', seed: 3300033, MW: 200, MH: 200, blobs: 150,
    start: { x: 100, y: 190 },
    bossTiles: [{ x: 38, y: 162 }, { x: 34, y: 70 }, { x: 100, y: 24 }, { x: 166, y: 72 }, { x: 100, y: 112 }],
    bosses: ['glitchcat', 'cakequeen', 'unicorn', 'trashbot', 'zyama2'],
    castle: { x: 100, y: 104, half: 17, gate: 'east', biome: 13 },
    cage: { x: 100, y: 93 },
    biomeSeeds: [
      [9, 100, 186], [9, 70, 176], [9, 132, 182], [9, 40, 160], [9, 160, 170], [9, 135, 150], [9, 65, 140],
      [10, 34, 70], [10, 16, 100], [10, 56, 48], [10, 24, 128], [10, 60, 90],
      [11, 100, 24], [11, 70, 14], [11, 134, 18], [11, 80, 44], [11, 124, 44],
      [12, 166, 72], [12, 186, 110], [12, 172, 140], [12, 150, 54], [12, 186, 36], [12, 145, 96],
      [13, 100, 104], [13, 100, 80], [13, 124, 104], [13, 78, 108], [13, 100, 128],
    ],
    chests: 24, chestDist: [10, 28], shrines: 9, elite: 0.1, spawnEvery: 0.3, capBase: 24,
    zoneLevel: { 9: 4, 10: 8, 11: 12, 12: 16, 13: 21 }, bossLevels: [6, 10, 14, 18, 24], diff: { hp: 1.4, dmg: 1.3 },
    hero: 'ryzhovaya', hostage: 'krilessa', music: 'field3', startLevel: 1,
  },
};

// Босс-раш: арена, где по очереди выходят все побеждённые боссы
CHAPTERS.rush = {
  id: 'rush', title: 'Босс-раш', name: 'Босс-раш', seed: 424242, MW: 60, MH: 60, blobs: 0, rush: true,
  start: { x: 30, y: 38 }, castle: { x: 30, y: 30, half: 26, gate: 'south', biome: 8 }, cage: { x: 30, y: 6 }, noCage: true,
  biomeSeeds: [[8, 30, 30]], chests: 0, chestDist: [0, 0], shrines: 0, elite: 0, spawnEvery: 99, capBase: 0,
  bosses: [], bossTiles: [], bossLevels: [], zoneLevel: { 8: 30 }, diff: { hp: 1.3, dmg: 1.3 },
  hero: 'krilessa', hostage: null, music: 'boss', startLevel: 1,
};

// ---------------- Сложность ----------------
const DIFFS = {
  easy: { name: 'Лёгко', hp: 0.7, dmg: 0.65, elite: 0.6, event: 1.1 },
  normal: { name: 'Нормально', hp: 1, dmg: 1, elite: 1, event: 1 },
  hard: { name: 'Кринж-хардкор', hp: 1.3, dmg: 1.35, elite: 1.6, event: 0.8 },
};

// ---------------- События на карте (раз в ~3 минуты) ----------------
const EVENTS = [
  { id: 'rage', ic: '😡', name: 'Ярость монстров', desc: 'Враги на 40% сильнее и быстрее!', dur: 20, tint: '255,30,30', w: 3 },
  { id: 'gold', ic: '💰', name: 'Золотая лихорадка', desc: 'Опыт ×2, осколки падают вдвое чаще', dur: 20, tint: '255,200,40', w: 2 },
  { id: 'horde', ic: '👹', name: 'Нашествие', desc: 'Враги лезут отовсюду!', dur: 20, tint: '150,60,255', w: 2 },
  { id: 'meteor', ic: '☄️', name: 'Метеоритный дождь', desc: 'Береги голову – и бей метеорами врагов!', dur: 18, tint: '255,120,30', w: 2 },
  { id: 'song', ic: '🎤', name: 'Концерт Зямочкккк', desc: 'Зямочкккк запел! Враги замерли и танцуют!', dur: 9, tint: '255,62,165', w: 1.5 },
  { id: 'hearts', ic: '💖', name: 'Сердечный дождь', desc: 'Лови сердечки!', dur: 12, tint: '255,90,140', w: 1.5 },
  { id: 'fog', ic: '🌫️', name: 'Кринж-туман', desc: 'Ничего не видно... но врагам тоже!', dur: 18, tint: '40,30,60', w: 1.5 },
];
const EVENT_EVERY = 180;
const SONG_TEXTS = ['🎵 Я – Зямочкккк, я – кринж, я – звезда-а-а! 🎵', '🎵 Брекеты блестят, как звёзды в ночи-и-и! ✨🦷',
  '🎵 Ла-ла-ла, я император, а вы – не-е-ет! 👑', '🎵 Стихи мои – огонь, а танцы – пожа-а-ар! 🔥💃',
  '🎵 Рыжовая, вернись, я сочинил куплет! 🎶', '🎵 Кто не танцует – тот не Зямочкккк! 🕺'];

// ---------------- Что нового (показывается после обновления) ----------------
const CHANGELOG = [
  { v: '0.10.4 beta', title: 'Сквозь деревья', items: [
    ['🌳', 'Деревья не мешают', 'Сквозь деревья теперь можно проходить – больше никаких тупиков между деревом и скалой. Крона просвечивает, когда ты под ней'],
    ['🐱', 'Карточки глав снова с характером', 'Глаза кошки в темноте у четвёртой главы вернулись. У других – светлячки, прожекторы, искры, следы лап и снегопад'],
    ['🎥', 'Фон меню снова живой', 'Карта под меню опять плывёт быстро и в разные стороны'],
    ['⚡', 'Без рывков', 'Карта достраивается понемногу, заранее – меню и бег по карте стали плавнее'],
  ] },
  { v: '0.10.3 beta', title: 'Живая карта', items: [
    ['⚡', 'Меню плавнее', 'Главный экран больше не проседает: убраны тяжёлые размытия, фон под меню рисуется экономнее'],
    ['👀', 'Глаза вернулись', 'Кто-то снова смотрит из темноты у четвёртой главы. А у других глав – свои чудеса: светлячки, диско-лучи, искры, следы лап и снег'],
    ['👆', 'Сбивай украшения', 'Тапни по снежинке, огоньку или любому значку на карте – он отлетит с искрами. Тапай быстро – будет множитель. Через пару секунд значки возвращаются'],
  ] },
  { v: '0.10.2 beta', title: 'Автообновление и новый главный экран', items: [
    ['🔄', 'Автообновление', 'Игра сама находит новые версии при запуске. Видно, как идёт загрузка, а когда всё готово – одна кнопка «Перезапустить». Без интернета играть можно, как раньше'],
    ['📦', 'Новые версии приложения', 'Если обновлению нужна новая версия приложения, игра предложит скачать её и сама откроет установку'],
    ['🛡️', 'Надёжно', 'Каждое обновление подписано – подменить его нельзя. Если новая версия не запустится, игра вернётся к прежней. Сохранения не трогаются'],
    ['🗺️', 'Карта приключений', 'Новый главный экран: главы стоят на извилистой дороге, героиня ждёт у текущей главы, у пройденных горят звёзды боссов. Нажми на главу – откроется её карточка'],
    ['🧭', 'Всё под рукой', 'Внизу – босс-раш, таланты, гардероб, интро и настройки. Звёзды – в правом верхнем углу'],
    ['👑', 'Чемпион не убегает', 'Если героиня погибла, чемпион остаётся на карте с тем же здоровьем – можно вернуться и добить'],
  ] },
  { v: '0.10.1 beta', title: 'Мягкий старт', items: [
    ['🌱', 'Глава разгоняется постепенно', 'В первых локациях главы враги как в главе 1, к последним – в полную силу. Первые стражи тоже мягче'],
    ['⭐', 'Меньше элиты в начале', 'В стартовых локациях элитные враги встречаются почти в 3 раза реже'],
    ['👥', 'Меньше толпы', 'Пока героиня слабая, врагов вокруг меньше – толпа растёт вместе с уровнем'],
    ['🐾', 'Стаи', 'Стаи быстрых врагов реже, меньше и медленнее – от них снова можно убежать рывком'],
  ] },
  { v: '0.10 beta', title: 'Каждая глава – с нуля', items: [
    ['🌱', 'Прокачка в каждой главе своя', 'Глава начинается с 1 уровня, улучшения больше не кончаются – каждый уровень снова что-то даёт, а сборки получаются разные'],
    ['⭐', 'Звёзды и таланты', 'За каждого побеждённого босса – звезда. В меню «Таланты»: больше урона и здоровья, стартовые улучшения, четвёртый карман для реликвий и ещё 9. Можно сбросить и раздать заново. За уже пройденные главы звёзды начислены'],
    ['✨', 'Особые улучшения глав', 'В каждой главе свои редкие карточки, которые выпадают только там: лепестки, диско-шар, зеркальный двойник, ночник, чуткий нос и другие'],
    ['⚖️', 'Баланс', 'Враги чуть меньше подстраиваются под силу героини – прокачка заметнее. Но есть ограничитель: перекачаться и сломать игру нельзя. В начале глав 2+ врагов меньше, толпа нарастает с уровнем'],
    ['⚔️', 'Босс-раш', 'У всех одинаковая героиня 24 уровня плюс твои таланты и реликвии – рекорды честные'],
    ['💾', 'Сохранения', 'Пройденные главы, реликвии, гардероб и статистика на месте. Незаконченная глава начнётся заново – по новым правилам'],
    ['❄️', '???', 'После пятой главы стало подозрительно холодно…'],
  ] },
  { v: '0.09 beta', title: 'Сундуки по-новому', items: [
    ['📦', 'Редкость', 'Деревянные, серебряные и золотые сундуки – чем реже, тем богаче. Видно по окантовке и блеску'],
    ['😱', 'Мимики', 'Некоторые сундуки кусаются! Мимика можно заметить: он иногда вздрагивает. За победу – двойная награда'],
    ['🔑', 'Ключи', 'Золотые сундуки заперты. Ключи дают стражи, чемпионы, испытания, мимики и иногда элита'],
    ['🗝️', 'Реликвии', 'В золотом сундуке – выбор из трёх реликвий: перо феникса, подкова-магнит, грозовая банка и ещё 10. Носить можно три, они переходят из главы в главу'],
    ['✨', 'Спрятанные сундуки', 'На мини-карте сундук появляется, только когда ты его увидишь. «Где-то рядом сокровище…» – подсказка, что пора поискать'],
    ['🎨', 'Свои сундуки в каждой главе', 'Сундук, неоновый кейс, глючный сундук, коробка с игрушками, корзинка для пикника'],
  ] },
  { v: '0.08 beta', title: 'Снова сложно', items: [
    ['⚔️', 'Баланс', 'Игра стала заметно сложнее, особенно в поздних главах: боссы крепче и больнее бьют, мобы сильнее, перекачка помогает меньше'],
    ['⛩', 'Испытания – в иной мир', 'Алтарь переносит в маленькую арену, своя в каждой главе: Пекло Мрака, Кринж-бездна, Глитч-изнанка и другие. Враги больше не разлетаются, добыча возвращается с тобой'],
    ['🚪', 'Выход с арены', 'Можно уйти через руну выхода внизу арены – но испытание будет провалено'],
    ['❤️', 'Меньше халявы', 'Сердечки в бою с боссом падают реже, чемпионы крепче'],
  ] },
  { v: '0.07 beta', title: 'Тсс… 🤫', items: [
    ['🐾', '???', 'Кое-кто проснулся посреди ночи. Пройди главу 3 – и загляни в меню. Мяу.'],
    ['🔒', 'Ещё две главы', 'Что в них – секрет. Подсказка: не всё, что светится в темноте, – лампочка.'],
    ['🗺️', 'Большая карта', 'Нажми на мини-карту – откроется карта на весь экран с метками и пунктиром «куда идти»'],
    ['🎨', 'Красивее поверхность', 'Озёра, камни и дорожки со скруглёнными краями, мягкие пятна и травинки на земле, без «квадратиков»'],
    ['🌳', 'Деревья не мешают', 'Не растут вплотную к дорожкам, ствол тоньше, крона просвечивает, если под ней ты или босс'],
    ['⚖️', 'Баланс', 'Сложность – на 10% мягче версии 0.04: больше мобов, стражи снова опаснее, но сердечки в бою с боссом остались'],
    ['⬆️', 'Уровни быстрее', 'Опыта за врагов и боссов на 30% больше'],
    ['🎬', 'Интро – в отдельной вкладке', 'Все интро теперь в меню «🎬 Интро» и листаются по касанию, а не сами'],
    ['🔥', 'Исправлено', 'Огненные шары Рыжовой теперь правда огненные: взрываются и поджигают. Огоньки в главе 1 больше не убегают так далеко'],
  ] },
  { v: '0.06 beta', title: 'Карты и реиграбельность', items: [
    ['🗺️', 'Новая карта каждый раз', 'Каждое новое прохождение главы – своя раскладка: скалы, озёра, деревья, дороги, сундуки и алтари на новых местах'],
    ['🌀', 'Порталы', 'Пройденный алтарь становится порталом: встань на него и перенесись к другому алтарю, на старт или к воротам замка'],
    ['👑', 'Чемпионы', 'Раз в 2,5–3,5 минуты рядом появляется чемпион – очень сильный моб с короной. За победу – улучшение, осколки и сердечко'],
    ['🕊️', 'Усмирение по ступеням', 'Локация побеждённого стража слабеет ступенями I–V: −10% … −30%. Ступени за 120 / 350 / 700 / 1200 убийств, за каждую – награда, на IV и V – улучшение'],
    ['⛩', 'Алтари мигают на мини-карте', 'Непройденные – мигающий голубой значок, порталы – фиолетовые точки'],
  ] },
  { v: '0.05 beta', title: 'Баланс по твоей статистике', items: [
    ['💬', 'Боссы говорят – игра ждёт', 'Пока босс говорит, всё на паузе: коснись экрана, чтобы продолжить. Подколки в бою – облачком над боссом'],
    ['❤️', 'Больше сердечек', 'В бою с боссом сердечки падают сами каждые 9–16 с и на каждой новой стадии. Чем меньше здоровья, тем чаще они выпадают из врагов'],
    ['🧹', 'Меньше толпы и спама', 'Во время боя с боссом обычные мобы не появляются, свиты меньше, снарядов на экране меньше'],
    ['🕊️', 'Фарм', 'Локация побеждённого стража сразу слабеет на 15% и дальше – до 30%. Перекачка теперь ощутимо облегчает бои'],
    ['⛩', 'Алтари испытаний', 'Круг испытания больше не залезает в стены и деревья'],
    ['🪞', 'Зямочкккк 2.0 и Королева Глазурия', 'Стали честнее: меньше снарядов и урона на последних стадиях'],
    ['📊', 'Статистика точнее', 'Видно сложность и сколько сердечек подобрано в каждом бою с боссом'],
  ] },
  { v: '0.04 beta', title: 'Подлянка, события и статистика', items: [
    ['🎲', 'События на карте', 'Каждые 3 минуты: Ярость монстров (всё горит красным!), Золотая лихорадка, Нашествие, Метеоритный дождь, Концерт Зямочкккк и другие'],
    ['🎵', 'Своя музыка в каждой локации', '14 тематических мелодий: от болотного блюза до глитч-чиптюна и зеркального вальса'],
    ['📊', 'Статистика', 'Игра сама всё записывает. Жми «Отправить» и присылай разработчику'],
    ['⚔️', 'Босс-раш', 'Все побеждённые боссы подряд на время, с рекордом. Открывается после главы 1'],
    ['🎚️', 'Выбор сложности', 'Лёгко, Нормально или Кринж-хардкор'],
    ['🔒', 'Главы по порядку', 'Следующая глава и просмотр интро открываются только после прохождения'],
    ['💾', 'Прогресс не теряется', 'Сила героини всегда переходит в следующую главу'],
    ['🗣️', 'Рыжовая меньше переживает', 'Совет про сердечки звучит только один раз'],
    ['🎭', 'Зямочкккк сменил амплуа', 'Никаких стримов: теперь он театральный Император Кринжа – стихи, песни и танцы'],
    ['😈', '???', 'В финале главы 3 кое-кто не умеет проигрывать... 👀'],
  ] },
  { v: '0.03 beta', title: 'Рыжовая в деле', items: [
    ['🔥', 'Глава 3', 'Играешь за Рыжовую: огненные шары и Вспышка'],
    ['⚖️', 'Новый баланс', 'Враги и боссы подстраиваются под силу героини'],
    ['🌟', 'Супер-удары', 'Перьевой ураган и Огненная ярость'],
  ] },
  { v: '0.02 beta', title: 'Кринж-Цитадель', items: [
    ['👑', 'Глава 2 и Зямочкккк', 'Боссы со стадиями и кринжовыми речами'],
    ['💎', 'Осколки силы', 'Враги роняют прибавки к HP, урону и криту'],
  ] },
];
const STATS_KEY = 'krilessa_stats_v1';

// ---------------- Улучшения ----------------
const UPGRADES = [
  { id: 'dmg', ic: '🪶', nm: 'Острые перья', ds: '+25% урона', max: 12 },
  { id: 'rate', ic: '💨', nm: 'Быстрые крылья', ds: '+18% скорость атаки', max: 8 },
  { id: 'multi', ic: '✨', nm: 'Веер перьев', ds: '+1 перо за выстрел', max: 5 },
  { id: 'pierce', ic: '🏹', nm: 'Пронзающие перья', ds: 'Перо пробивает +1 врага', max: 4 },
  { id: 'range', ic: '👁️', nm: 'Зоркий глаз', ds: '+15% радиус атаки', max: 5 },
  { id: 'hp', ic: '❤️', nm: 'Сердце героини', ds: '+30 к здоровью и лечение', max: 12 },
  { id: 'speed', ic: '👟', nm: 'Лёгкость', ds: '+8% скорость бега', max: 5 },
  { id: 'regen', ic: '🌿', nm: 'Целебная пыльца', ds: '+1 HP в секунду', max: 8 },
  { id: 'orbit', ic: '🌀', nm: 'Вихрь перьев', ds: '+1 перо кружит вокруг тебя', max: 8 },
  { id: 'bolt', ic: '⚡', nm: 'Гром небес', ds: 'Молния бьёт врагов цепочкой', max: 7 },
  { id: 'magnet', ic: '🧲', nm: 'Магнит', ds: '+50% радиус сбора', max: 3 },
  { id: 'armor', ic: '🛡️', nm: 'Броня феи', ds: '-8% получаемого урона', max: 6 },
  { id: 'dash', ic: '🌪️', nm: 'Мастер рывка', ds: '-20% перезарядка рывка', max: 3 },
  { id: 'crit', ic: '🎯', nm: 'Меткость', ds: '+6% шанс крита', max: 8 },
  { id: 'critdmg', ic: '💥', nm: 'Сокрушение', ds: '+40% урона крита', max: 6 },
  { id: 'vamp', ic: '🩸', nm: 'Вампирские перья', ds: '+1 HP за каждого побеждённого', max: 5 },
  { id: 'explode', ic: '🎆', nm: 'Взрывные перья', ds: 'Перья взрываются при попадании', max: 4 },
  { id: 'frost', ic: '❄️', nm: 'Ледяные перья', ds: 'Перья замедляют врагов', max: 4 },
  { id: 'shield', ic: '🫧', nm: 'Пузырь-щит', ds: 'Щит блокирует удар (перезарядка)', max: 4 },
  { id: 'super', ic: '🌟', nm: 'Суперзаряд', ds: 'Супер-удар копится на 25% быстрее', max: 4 },
  // особые улучшения: выпадают только в своей главе
  { id: 'c1petal', ch: 1, ic: '🌸', nm: 'Лепестки', ds: 'Враги чаще роняют сердечки (+4%)', max: 3 },
  { id: 'c1guard', ch: 1, ic: '⚔️', nm: 'Гроза стражей', ds: '+12% урона по боссам', max: 3 },
  { id: 'c2disco', ch: 2, ic: '🪩', nm: 'Диско-шар', ds: 'Каждые 6 с вокруг вспыхивает кольцо света', max: 3 },
  { id: 'c2combo', ch: 2, ic: '🎶', nm: 'Кринж-комбо', ds: '+1% урона за каждые 10 комбо', max: 3 },
  { id: 'c3twin', ch: 3, ic: '🪞', nm: 'Зеркальный двойник', ds: '+10% шанс выстрелить дважды', max: 3 },
  { id: 'c3glitch', ch: 3, ic: '👾', nm: 'Глитч-рывок', ds: 'После рывка неуязвима дольше (+0,3 с)', max: 3 },
  { id: 'c4lamp', ch: 4, ic: '💡', nm: 'Ночник', ds: 'Свет вокруг тебя на 20% шире', max: 3 },
  { id: 'c4life', ch: 4, ic: '😼', nm: 'Девятая жизнь', ds: 'Потеря жизни – взрывная волна вокруг', max: 3 },
  { id: 'c5nose', ch: 5, ic: '👃', nm: 'Чуткий нос', ds: 'Улики рядом видны на карте (+350)', max: 3 },
  { id: 'c5snack', ch: 5, ic: '🐟', nm: 'Вкусняшка', ds: 'Сердечки лечат на 20% больше', max: 3 },
  { id: 'c6warm', ch: 6, ic: '🔥', nm: 'Тёплое сердце', ds: 'Костры лечат на 50% быстрее, метель не замедляет', max: 3 },
  { id: 'c6ice', ch: 6, ic: '⛏️', nm: 'Ледокол', ds: 'Лёд тает быстрее, перья тоже колют лёд', max: 2 },
  { id: 'c6duo', ch: 6, ic: '💞', nm: 'Дружная пара', ds: 'Подруга стреляет на 30% чаще и быстрее отдыхает', max: 3 },
];
const UPGRADE_MAX = Object.fromEntries(UPGRADES.map(u => [u.id, u.max]));

// ---------------- Звёзды и таланты (навсегда, между главами) ----------------
// Звезда – за каждого побеждённого босса (один раз). Таланты можно сбросить и раздать заново.
const TALENTS = [
  { id: 'start', ic: '🎁', nm: 'Стартовый набор', ds: '+1 улучшение на выбор в начале главы', max: 3, cost: 2 },
  { id: 'dmg', ic: '🗡️', nm: 'Сила дружбы', ds: '+5% урона', max: 4, cost: 1 },
  { id: 'hp', ic: '❤️', nm: 'Крепкое здоровье', ds: '+6% здоровья', max: 4, cost: 1 },
  { id: 'crit', ic: '🎯', nm: 'Глаз-алмаз', ds: '+3% шанс крита', max: 3, cost: 1 },
  { id: 'xp', ic: '📚', nm: 'Ученица', ds: '+8% опыта', max: 3, cost: 1 },
  { id: 'speed', ic: '👟', nm: 'Быстрые ножки', ds: '+4% скорость бега', max: 2, cost: 1 },
  { id: 'super', ic: '🌟', nm: 'Заряд с собой', ds: 'Супер-удар в начале главы и после возрождения +25%', max: 2, cost: 1 },
  { id: 'luck', ic: '🍀', nm: 'Везунчик', ds: '+15% осколков и сердечек', max: 2, cost: 1 },
  { id: 'magnet', ic: '🧲', nm: 'Длинные руки', ds: '+25% радиус сбора', max: 2, cost: 1 },
  { id: 'heal', ic: '🩹', nm: 'Передышка', ds: 'После победы над стражем – полное здоровье', max: 1, cost: 2 },
  { id: 'key', ic: '🗝️', nm: 'Отмычка', ds: 'Каждая глава начинается с ключом', max: 1, cost: 2 },
  { id: 'relic', ic: '🎒', nm: 'Четвёртый карман', ds: 'Можно носить 4 реликвии', max: 1, cost: 5 },
];
const talentSpent = t => TALENTS.reduce((s, d) => s + (t[d.id] || 0) * d.cost, 0);

// ---------------- Осколки (выпадают из врагов) ----------------
const SHARDS = [
  { id: 'hp', col: '#ff3b5c', txt: v => `+${v} макс. HP`, val: 3, w: 4 },
  { id: 'dmg', col: '#ff8a1f', txt: () => '+2% урона', val: 0.02, w: 3 },
  { id: 'rate', col: '#ffe04a', txt: () => '+1.5% скор. атаки', val: 0.015, w: 2 },
  { id: 'crit', col: '#c77dff', txt: () => '+1% крит', val: 0.01, w: 1.5 },
  { id: 'speed', col: '#4dff9a', txt: () => '+1% скорость', val: 0.01, w: 1 },
];
const SHARD_CHANCE = 0.12;

// =====================================================================
//  БАЛАНС
//  1) Для каждого уровня строим "эталонного" героя (разумный набор улучшений
//     и осколков) и считаем его урон в секунду (DPS) и запас здоровья (EHP).
//  2) Враги и боссы локации рассчитаны на эталон её ожидаемого уровня:
//     HP босса = ttk × DPS эталона, урон = доля от EHP эталона.
//  3) Если игрок сильнее эталона (перекачался), враги усиливаются почти
//     пропорционально – бой остаётся опасным, но чуть легче, чем "по плану".
//     Если слабее – немного ослабевают. Опыт за "лёгких" врагов уменьшается.
// =====================================================================
const BAL = {
  eff: 0.42,          // какая доля теоретического DPS реально попадает в босса
  mobHpK: 1.6, mobDmgK: 1.55, bossDmgK: 1.2,
  bossHpExp: 0.82, bossDmgExp: 0.78, mobHpExp: 0.8, mobDmgExp: 0.75,
  metaK: 1.04,         // таланты и реликвии дают силу сверх эталона – чуть поднимаем базу
  xpDiv: 52,           // опыт за врага = вес × опыт уровня / xpDiv
};
// Осколки: каждый следующий даёт чуть меньше (мягкий потолок)
const SHARD_CAP = { dmg: 1.2, rate: 0.6, crit: 0.25, speed: 0.25, hp: 700 };
function softcap(x, c) { return c * (1 - Math.exp(-x / c)); }
function statsFor(up, bonus, heroId) {
  const H = HEROES[heroId] || HEROES.krilessa;
  const lv = k => up[k] || 0, b = k => (SHARD_CAP[k] ? softcap(bonus[k] || 0, SHARD_CAP[k]) : (bonus[k] || 0));
  const s = {};
  s.dmg = H.dmg * (1 + 0.25 * lv('dmg')) * (1 + b('dmg'));
  s.fireInt = H.fireInt / ((1 + 0.18 * lv('rate')) * (1 + b('rate')));
  s.shots = 1 + lv('multi');
  s.pierce = lv('pierce') + (H.pierce || 0);
  s.range = H.range * (1 + 0.15 * lv('range'));
  s.maxHp = Math.round(H.hp + 30 * lv('hp') + b('hp'));
  s.speed = H.speed * (1 + 0.08 * lv('speed')) * (1 + b('speed'));
  s.regen = lv('regen');
  s.orbit = lv('orbit');
  s.bolt = lv('bolt');
  s.magnet = 85 * (1 + 0.5 * lv('magnet'));
  s.armor = Math.min(0.6, 0.08 * lv('armor'));
  s.dashCdMax = (H.blink ? 1.6 : 1.4) * (1 - 0.2 * lv('dash'));
  s.crit = Math.min(0.75, 0.05 + 0.06 * lv('crit') + b('crit'));
  s.critMul = 1.75 + 0.4 * lv('critdmg');
  s.vamp = lv('vamp');
  s.explode = lv('explode');
  s.frost = lv('frost');
  s.shieldLv = lv('shield');
  s.shieldCd = 16 - 2.5 * s.shieldLv;
  s.superGain = 1 + 0.25 * lv('super');
  s.splash = H.splash ? H.splash * (1 + 0.25 * lv('explode')) : 0;
  s.burn = H.burn || 0;
  s.projSpd = H.projSpd;
  s.proj = H.proj || 'feather';
  return s;
}
// DPS по одной цели (для боссов) и "поток" одного снаряда (для мобов)
function estDPS(s) {
  const cf = 1 + s.crit * (s.critMul - 1);
  const shots = Math.min(s.shots, 3) + 0.35 * Math.max(0, s.shots - 3);
  let d = s.dmg * cf * shots / s.fireInt;
  if (s.burn) d += s.dmg * s.burn;
  if (s.bolt) d += s.dmg * 1.6 * cf / Math.max(1, 2.8 - s.bolt * 0.28);
  if (s.orbit) d += s.dmg * 0.7 * cf / 0.3 * 0.25;
  return d;
}
function estMobDPS(s) {
  const cf = 1 + s.crit * (s.critMul - 1);
  return s.dmg * cf / s.fireInt + (s.burn ? s.dmg * s.burn : 0);
}
function estEHP(s) { return s.maxHp / (1 - s.armor) + s.regen * 6; }

const REF_W = { dmg: 3, rate: 2, multi: 1.5, crit: 1.5, critdmg: 1, hp: 2.5, armor: 1.2, pierce: 0.8, range: 0.8, bolt: 0.8,
  orbit: 0.8, regen: 0.8, speed: 0.6, magnet: 0.4, dash: 0.4, vamp: 0.5, explode: 0.5, frost: 0.4, shield: 0.5, super: 0.4 };
function refBuild(L) {
  const up = {};
  for (let i = 1; i < L; i++) {
    let best = null, bv = 1e9;
    for (const k in REF_W) { const l = up[k] || 0; if (l >= UPGRADE_MAX[k]) continue; const v = (l + 1) / REF_W[k]; if (v < bv) { bv = v; best = k; } }
    if (!best) break;
    up[best] = (up[best] || 0) + 1;
  }
  const n = 3 * L; // примерно столько осколков собирает игрок к этому уровню
  const bonus = { hp: n * 4 / 11.5 * 3, dmg: n * 3 / 11.5 * 0.02, rate: n * 2 / 11.5 * 0.015, crit: n * 1.5 / 11.5 * 0.01 };
  return { up, bonus };
}
const REF = (() => {
  const N = 130, dps = [0], mob = [0], ehp = [0];
  for (let L = 1; L <= N; L++) {
    const r = refBuild(L), s = statsFor(r.up, r.bonus, 'krilessa');
    dps.push(Math.log(estDPS(s))); mob.push(Math.log(estMobDPS(s))); ehp.push(Math.log(estEHP(s)));
  }
  // сглаживание и монотонность
  const smooth = arr => {
    const out = arr.slice();
    for (let L = 1; L <= N; L++) {
      let s = 0, c = 0;
      for (let k = -3; k <= 3; k++) { const j = clamp(L + k, 1, N); s += arr[j]; c++; }
      out[L] = s / c;
    }
    for (let L = 2; L <= N; L++) out[L] = Math.max(out[L], out[L - 1]);
    return out.map(Math.exp);
  };
  return { N, dps: smooth(dps), mob: smooth(mob), ehp: smooth(ehp) };
})();
function refAt(arr, L) { L = clamp(L, 1, REF.N); const a = Math.floor(L), b = Math.min(REF.N, a + 1), t = L - a; return arr[a] * (1 - t) + arr[b] * t; }
const refDPS = L => refAt(REF.dps, L), refMobDPS = L => refAt(REF.mob, L), refEHP = L => refAt(REF.ehp, L);
// Множители для перекачанного/недокачанного героя
// Перекачалась на 20–50% – игра заметно, но не сильно легче. Дальше ограничитель:
// лишняя сила (фарм, гора реликвий) почти целиком уходит во врагов.
const SCALE_CAP = 1.5;
function scaleUp(ratio, exp, floor) {
  if (ratio < 1) return Math.max(floor, Math.pow(ratio, 0.7));
  if (ratio <= SCALE_CAP) return Math.pow(ratio, exp);
  return Math.pow(SCALE_CAP, exp) * Math.pow(ratio / SCALE_CAP, 0.97);
}
function xpGap(L, E) { return clamp(1 - 0.045 * (L - E), 0.25, 1.75); }
