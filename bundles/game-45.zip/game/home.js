'use strict';
// =====================================================================
//  Домик героинь: мебель по местам, обои и пол, питомцы.
//  Мебель выпадает из сундуков и с дороги сезона, питомцы – за главы,
//  достижения и сезоны.
// =====================================================================
// места в комнате: k – какая мебель туда встаёт
const HOME_SLOTS = [
  { id: 'wallL', k: 'wall', nm: 'Стена слева' },
  { id: 'wallR', k: 'wall', nm: 'Стена справа' },
  { id: 'sill', k: 'sill', nm: 'Подоконник' },
  { id: 'lamp', k: 'lamp', nm: 'Свет' },
  { id: 'plant', k: 'plant', nm: 'Уголок' },
  { id: 'floorL', k: 'big', nm: 'Слева' },
  { id: 'center', k: 'center', nm: 'Посередине' },
  { id: 'floorR', k: 'big', nm: 'Справа' },
];
// мебель: def – есть с самого начала; m – сезонная (номер месяца)
const FURNITURE = [
  { id: 'pic', k: 'wall', ic: '🖼️', nm: 'Картина', def: true },
  { id: 'mirror', k: 'wall', ic: '🪞', nm: 'Зеркало' },
  { id: 'clock', k: 'wall', ic: '🕰️', nm: 'Часы с кукушкой' },
  { id: 'tv', k: 'wall', ic: '📺', nm: 'Телевизор' },
  { id: 'map', k: 'wall', ic: '🗺️', nm: 'Карта сокровищ' },
  { id: 'darts', k: 'wall', ic: '🎯', nm: 'Дартс' },
  { id: 'guitar', k: 'wall', ic: '🎸', nm: 'Гитара' },
  { id: 'sofa', k: 'big', ic: '🛋️', nm: 'Диван', def: true },
  { id: 'bed', k: 'big', ic: '🛏️', nm: 'Кровать' },
  { id: 'piano', k: 'big', ic: '🎹', nm: 'Пианино' },
  { id: 'chair', k: 'big', ic: '🪑', nm: 'Кресло' },
  { id: 'tent', k: 'big', ic: '⛺', nm: 'Палатка-шалаш' },
  { id: 'drawer', k: 'big', ic: '🗄️', nm: 'Комод' },
  { id: 'yarn', k: 'center', ic: '🧶', nm: 'Клубок', def: true },
  { id: 'cake', k: 'center', ic: '🍰', nm: 'Торт' },
  { id: 'console', k: 'center', ic: '🎮', nm: 'Приставка' },
  { id: 'puzzle', k: 'center', ic: '🧩', nm: 'Пазл' },
  { id: 'dice', k: 'center', ic: '🎲', nm: 'Кубики' },
  { id: 'skate', k: 'center', ic: '🛹', nm: 'Скейт' },
  { id: 'potplant', k: 'plant', ic: '🪴', nm: 'Растение', def: true },
  { id: 'cactus', k: 'plant', ic: '🌵', nm: 'Кактус' },
  { id: 'sunflower', k: 'plant', ic: '🌻', nm: 'Подсолнух' },
  { id: 'palm', k: 'plant', ic: '🌴', nm: 'Пальма' },
  { id: 'bulb', k: 'lamp', ic: '💡', nm: 'Лампочка', def: true },
  { id: 'candles', k: 'lamp', ic: '🕯️', nm: 'Свечи' },
  { id: 'lantern', k: 'lamp', ic: '🏮', nm: 'Фонарик' },
  { id: 'disco', k: 'lamp', ic: '🪩', nm: 'Диско-шар' },
  { id: 'nightlamp', k: 'lamp', ic: '🌙', nm: 'Ночник' },
  { id: 'teddy', k: 'sill', ic: '🧸', nm: 'Мишка', def: true },
  { id: 'aquarium', k: 'sill', ic: '🐠', nm: 'Аквариум' },
  { id: 'books', k: 'sill', ic: '📚', nm: 'Книжки' },
  { id: 'flowers', k: 'sill', ic: '🌸', nm: 'Цветочки' },
  { id: 'crystal', k: 'sill', ic: '🔮', nm: 'Шар предсказаний' },
  // сезонные – с дороги сезона (3-й уровень)
  { id: 'sz0', k: 'sill', ic: '⛄', nm: 'Снеговик-статуэтка', m: 0 },
  { id: 'sz1', k: 'sill', ic: '💝', nm: 'Коробка конфет', m: 1 },
  { id: 'sz2', k: 'plant', ic: '🌷', nm: 'Тюльпаны', m: 2 },
  { id: 'sz3', k: 'lamp', ic: '🎈', nm: 'Шарики', m: 3 },
  { id: 'sz4', k: 'plant', ic: '🌼', nm: 'Ромашки', m: 4 },
  { id: 'sz5', k: 'center', ic: '🏐', nm: 'Пляжный мяч', m: 5 },
  { id: 'sz6', k: 'big', ic: '🔭', nm: 'Телескоп', m: 6 },
  { id: 'sz7', k: 'center', ic: '🍉', nm: 'Арбуз', m: 7 },
  { id: 'sz8', k: 'sill', ic: '🎒', nm: 'Рюкзак', m: 8 },
  { id: 'sz9', k: 'plant', ic: '🎃', nm: 'Тыква', m: 9 },
  { id: 'sz10', k: 'wall', ic: '🍂', nm: 'Осенний венок', m: 10 },
  { id: 'sz11', k: 'plant', ic: '🎄', nm: 'Ёлочка', m: 11 },
];
const FURN_BY = Object.fromEntries(FURNITURE.map(f => [f.id, f]));
// обои и пол: def – с начала, остальные выпадают как мебель
const WALLPAPERS = [
  { id: 'stripes', nm: 'Полоски', c: ['#5a3a8a', '#6a4a9a'], def: true },
  { id: 'dots', nm: 'Горошек', c: ['#2a5a7a', '#9ad8ff'] },
  { id: 'stars', nm: 'Звёзды', c: ['#1a1a4a', '#ffe08a'] },
  { id: 'hearts', nm: 'Сердечки', c: ['#7a2a5a', '#ff9ad8'] },
  { id: 'waves', nm: 'Волны', c: ['#1a4a6a', '#6ae0ff'] },
  { id: 'bricks', nm: 'Кирпичи', c: ['#7a3a2a', '#a05a3a'] },
];
const FLOORS = [
  { id: 'wood', nm: 'Паркет', c: ['#8a5a30', '#a06a3a'], def: true },
  { id: 'tiles', nm: 'Плитка', c: ['#c8c8d8', '#9a9ab0'] },
  { id: 'carpet', nm: 'Ковролин', c: ['#6a2a4a', '#8a3a6a'] },
  { id: 'grass', nm: 'Травка', c: ['#3a8a3a', '#5aa04a'] },
];
// питомцы: src – откуда (как у вещей образа): a:<достижение>, ch:<глава>, w:<концовка гл. 4>, a:ss_<месяц>_pet – сезон
const PETS = [
  { id: 'meow', ic: '😼', nm: 'Мяу.exe', src: 'w:kind' },
  { id: 'owl', ic: '🦉', nm: 'Совёнок', src: 'a:s_night', fly: true },
  { id: 'dragon', ic: '🐲', nm: 'Дракончик', src: 'a:bosses3', fly: true },
  { id: 'snowman', ic: '⛄', nm: 'Снеговичок', src: 'ch:6' },
  { id: 'crab', ic: '🦀', nm: 'Крабик', src: 'ch:7' },
  { id: 'ghost', ic: '👻', nm: 'Привидение', src: 'a:u_untouch', fly: true },
  { id: 'sp0', ic: '🦌', nm: 'Олешек', src: 'a:ss_0_pet' },
  { id: 'sp1', ic: '🐻', nm: 'Мишка-валентинка', src: 'a:ss_1_pet' },
  { id: 'sp2', ic: '🐰', nm: 'Зайчик', src: 'a:ss_2_pet' },
  { id: 'sp3', ic: '🐸', nm: 'Лягушонок', src: 'a:ss_3_pet' },
  { id: 'sp4', ic: '🐝', nm: 'Пчёлка', src: 'a:ss_4_pet', fly: true },
  { id: 'sp5', ic: '🦩', nm: 'Фламинго', src: 'a:ss_5_pet' },
  { id: 'sp6', ic: '🦄', nm: 'Единорожка', src: 'a:ss_6_pet' },
  { id: 'sp7', ic: '🦔', nm: 'Ёжик', src: 'a:ss_7_pet' },
  { id: 'sp8', ic: '🐿️', nm: 'Бельчонок', src: 'a:ss_8_pet' },
  { id: 'sp9', ic: '🦇', nm: 'Летучая мышка', src: 'a:ss_9_pet', fly: true },
  { id: 'sp10', ic: '🦊', nm: 'Лисёнок', src: 'a:ss_10_pet' },
  { id: 'sp11', ic: '🐧', nm: 'Пингвинёнок', src: 'a:ss_11_pet' },
];
const PET_BY = Object.fromEntries(PETS.map(p => [p.id, p]));
const HOME_PETS_MAX = 3;
// что говорят героини дома
const HOME_LINES = {
  krilessa: ['Уютненько! ✨', 'Тут пахнет печеньками…', 'Перья надо почистить 🪶', 'Ещё одну главу?', 'Рыжовая, не трогай мой торт!'],
  ryzhovaya: ['Кто опять съел печеньки?', 'Мне бы зеркало побольше 🪞', 'Огонь в камине – это я 🔥', 'Скучно без приключений!', 'Крилесса, пошли гулять!'],
  tessa: ['Мяу.', 'Мур-р-р… 😺', '*спит на диване*', 'Где мой корм?!', 'Мяу! (это значит «привет»)'],
};
