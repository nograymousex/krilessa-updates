'use strict';
// =====================================================================
//  Слава: редкость достижений, звания, эмблемы, рамки, титулы и ауры.
//  Откуда берётся награда: src 'a:<id достижения>' или 'k:<номер звания>'.
// =====================================================================
const RARITY = {
  c: { nm: 'Обычное', col: '#c8d2e6', fame: 10, st: 1 },
  r: { nm: 'Редкое', col: '#5bc8ff', fame: 25, st: 1 },
  e: { nm: 'Эпическое', col: '#c77dff', fame: 60, st: 2 },
  l: { nm: 'Легендарное', col: '#ffb43a', fame: 150, st: 3 },
  u: { nm: 'Ультра', col: '#ff5bd6', fame: 400, st: 5 },
};
const RAR_ORDER = ['c', 'r', 'e', 'l', 'u'];
// звания по славе
const RANKS = [
  { nm: 'Новенькая', ic: '🌱', at: 0 },
  { nm: 'Искательница', ic: '🧭', at: 100 },
  { nm: 'Героиня', ic: '🗡️', at: 400 },
  { nm: 'Чемпионка', ic: '🏆', at: 1000 },
  { nm: 'Легенда', ic: '🌟', at: 2200 },
  { nm: 'Миф', ic: '🪐', at: 5200 },
];
const rankOf = fame => { let i = 0; while (i + 1 < RANKS.length && fame >= RANKS[i + 1].at) i++; return i; };

// эмблема – значок в кружке рядом с именем
const EMBLEMS = [
  { id: 'star', ic: '⭐', bg: '#4a3a8a', src: '' },
  { id: 'ch1', ic: '🌲', bg: '#1f6a2a', src: 'a:ch1' },
  { id: 'ch2', ic: '🪩', bg: '#6a2ad8', src: 'a:ch2' },
  { id: 'ch3', ic: '🪞', bg: '#c03a10', src: 'a:ch3' },
  { id: 'ch4', ic: '🌙', bg: '#141a40', src: 'a:ch4' },
  { id: 'ch5', ic: '🔎', bg: '#d8782a', src: 'a:ch5' },
  { id: 'ch6', ic: '❄️', bg: '#3a6ac8', src: 'a:ch6' },
  { id: 'ch7', ic: '🦐', bg: '#062a5a', src: 'a:ch7' },
  { id: 'crown', ic: '👑', bg: '#a0700a', src: 'a:season' },
  { id: 'truth', ic: '💫', bg: '#5a1a8a', src: 'a:truewin' },
  { id: 'mask', ic: '🎭', bg: '#3a2a5a', src: 'a:ends4' },
  { id: 'pearl', ic: '💗', bg: '#8a2a5a', src: 'a:pearls' },
  { id: 'skull', ic: '💀', bg: '#3a3a4a', src: 'a:kills3' },
  { id: 'comet', ic: '☄️', bg: '#8a3a0a', src: 'a:kills4' },
  { id: 'boom', ic: '💥', bg: '#8a2a1a', src: 'a:elites2' },
  { id: 'dragon', ic: '🐉', bg: '#1a6a4a', src: 'a:bosses2' },
  { id: 'rosette', ic: '🏵️', bg: '#8a4a1a', src: 'a:champs2' },
  { id: 'flame', ic: '🔥', bg: '#a02a0a', src: 'a:combo2' },
  { id: 'bolt', ic: '⚡', bg: '#5a5a0a', src: 'a:supers2' },
  { id: 'shield', ic: '🛡️', bg: '#2a4a7a', src: 'a:nohit1' },
  { id: 'chest', ic: '📦', bg: '#7a4a1a', src: 'a:chests2' },
  { id: 'mimic', ic: '😱', bg: '#5a3a1a', src: 'a:mimics1' },
  { id: 'gate', ic: '⛩️', bg: '#8a1a1a', src: 'a:trials2' },
  { id: 'key', ic: '🗝️', bg: '#6a5a1a', src: 'a:relics' },
  { id: 'book', ic: '📖', bg: '#3a2a6a', src: 'a:book2' },
  { id: 'sword', ic: '⚔️', bg: '#4a4a5a', src: 'a:rush1' },
  { id: 'hole', ic: '🕳️', bg: '#1a1030', src: 'a:abyss1' },
  { id: 'galaxy', ic: '🌌', bg: '#1a1a5a', src: 'a:abyss3' },
  { id: 'cal', ic: '📅', bg: '#2a5a8a', src: 'a:dstreak1' },
  { id: 'flask', ic: '🧪', bg: '#2a6a3a', src: 'a:mut1' },
  { id: 'duo', ic: '👥', bg: '#2a5a6a', src: 'a:coop1' },
  { id: 'angel', ic: '😇', bg: '#6a6a9a', src: 'a:revive2' },
  { id: 'devil', ic: '😈', bg: '#6a0a2a', src: 'a:hc1' },
  { id: 'dove', ic: '🕊️', bg: '#5a7a9a', src: 'a:clean1' },
  { id: 'timer', ic: '⏱️', bg: '#3a5a3a', src: 'a:speed1' },
  { id: 'owl', ic: '🦉', bg: '#2a2a4a', src: 'a:s_night' },
  { id: 'target', ic: '🎯', bg: '#7a1a2a', src: 'a:s_deco' },
  { id: 'hearts', ic: '💞', bg: '#8a2a6a', src: 'a:s_toss' },
  { id: 'bubble', ic: '🫧', bg: '#1a5a7a', src: 'a:s_krill' },
  { id: 'r1', ic: '🧭', bg: '#3a5a6a', src: 'k:1' },
  { id: 'r2', ic: '🗡️', bg: '#6a2a3a', src: 'k:2' },
  { id: 'r3', ic: '🏆', bg: '#7a5a0a', src: 'k:3' },
  { id: 'r4', ic: '🌟', bg: '#6a4a0a', src: 'k:4' },
  { id: 'r5', ic: '🪐', bg: '#2a1a5a', src: 'k:5' },
  { id: 'mad', ic: '☠️', bg: '#3a0a1a', src: 'a:u_madness' },
  { id: 'ghost', ic: '👻', bg: '#4a4a7a', src: 'a:u_untouch' },
  { id: 'diamond', ic: '💎', bg: '#1a4a7a', src: 'a:u_perfect' },
  { id: 'eye', ic: '👁️', bg: '#14002a', src: 'a:u_abyss' },
  { id: 'legend', ic: '🌈', bg: '#2a0a4a', src: 'a:u_legend' },
];
// рамка вокруг портрета и аватарки: b – заливка (цвет или градиент), a – вращающийся слой у живых рамок
const FRAMES = [
  { id: 'wood', nm: 'Деревянная', col: '#a0703a', b: 'linear-gradient(135deg,#c08a4a,#6a4018)', src: '' },
  { id: 'silver', nm: 'Серебряная', col: '#d8e0f0', b: 'linear-gradient(135deg,#ffffff,#9aa6c0,#e8eef8)', src: 'k:1' },
  { id: 'ruby', nm: 'Рубиновая', col: '#ff4a6a', b: 'linear-gradient(135deg,#ff8aa0,#c0102a,#ff4a6a)', src: 'k:2' },
  { id: 'neon', nm: 'Неоновая', col: '#3affd8', b: 'linear-gradient(135deg,#3affd8,#3a8aff,#d83aff)', glow: '#3affd8', src: 'k:3' },
  { id: 'stars', nm: 'Звёздная', col: '#ffe08a', b: '#2a1a5a', a: 'conic-gradient(#ffe08a,#2a1a5a 15%,#fff7c0 30%,#2a1a5a 45%,#ffe08a 60%,#2a1a5a 75%,#fff7c0 90%,#ffe08a)', src: 'k:4' },
  { id: 'myth', nm: 'Мифическая', col: '#b08aff', b: '#100828', a: 'conic-gradient(#6a3aff,#ff5bd6,#3affd8,#6a3aff)', glow: '#b08aff', src: 'k:5' },
  { id: 'gold', nm: 'Золотая', col: '#ffd25a', b: 'linear-gradient(135deg,#fff3a0,#e0902a,#ffd25a,#a0600a)', src: 'a:season' },
  { id: 'ice', nm: 'Ледяная', col: '#bfeaff', b: 'linear-gradient(135deg,#ffffff,#8ad8ff,#3a6ac8,#d8f2ff)', src: 'a:ch6' },
  { id: 'coral', nm: 'Коралловая', col: '#ff8a7a', b: 'linear-gradient(135deg,#ffb0a0,#ff5a6a,#ffd0a0)', src: 'a:ch7' },
  { id: 'toxic', nm: 'Токсичная', col: '#9aff3a', b: 'linear-gradient(135deg,#d8ff6a,#3a8a0a,#9aff3a)', glow: '#9aff3a', src: 'a:mut2' },
  { id: 'blood', nm: 'Хардкорная', col: '#ff2a3a', b: 'linear-gradient(135deg,#ff2a3a,#2a0008,#ff2a3a)', glow: '#ff2a3a', src: 'a:hcall' },
  { id: 'fire', nm: 'Огненная', col: '#ff8a2a', b: '#3a0a00', a: 'conic-gradient(#ff3a0a,#ffd25a,#ff7a2f,#ff3a0a,#ffd25a,#ff3a0a)', glow: '#ff7a2f', src: 'a:combo4' },
  { id: 'rainbow', nm: 'Радужная', col: '#ff5bd6', b: '#000', a: 'conic-gradient(#ff3a3a,#ffb43a,#fff03a,#3aff6a,#3ad8ff,#6a3aff,#ff3ad8,#ff3a3a)', glow: '#ffffff', src: 'a:u_perfect' },
  { id: 'abyss', nm: 'Бездна', col: '#7a3aff', b: '#000', a: 'conic-gradient(#000,#4a0a8a,#000,#7a3aff,#000,#2a0a5a,#000)', glow: '#7a3aff', src: 'a:u_abyss' },
  { id: 'legend', nm: 'Легенда', col: '#ffd25a', b: '#2a1a00', a: 'conic-gradient(#ffd25a,#ff5bd6,#fff3a0,#3affd8,#ffd25a)', glow: '#ffd25a', src: 'a:u_legend' },
];
// титул под именем; 'rank' – просто звание
const TITLES = [
  { id: 'rank', nm: '', src: '' },
  { id: 'savior', nm: 'Спасительница', src: 'a:season' },
  { id: 'truth', nm: 'Видящая правду', src: 'a:truewin' },
  { id: 'hunter', nm: 'Бич кринжа', src: 'a:kills4' },
  { id: 'slayer', nm: 'Кошмар стражей', src: 'a:bosses3' },
  { id: 'combo', nm: 'Комбо-королева', src: 'a:combo4' },
  { id: 'rich', nm: 'Сундучный магнат', src: 'a:chests3' },
  { id: 'scholar', nm: 'Кринжевед', src: 'a:book2' },
  { id: 'diver', nm: 'Покорительница Бездны', src: 'a:abyss4' },
  { id: 'will', nm: 'Железная воля', src: 'a:dstreak2' },
  { id: 'mutant', nm: 'Мутантка', src: 'a:mut2' },
  { id: 'friend', nm: 'Ангел-хранитель', src: 'a:revive2' },
  { id: 'hard', nm: 'Хардкорщица', src: 'a:hcall' },
  { id: 'speed', nm: 'Молния', src: 'a:speed2' },
  { id: 'cosmos', nm: 'Звездочёт', src: 'a:talall' },
  { id: 'owl', nm: 'Сова', src: 'a:s_night' },
  { id: 'sniper', nm: 'Снайперша меню', src: 'a:s_sniper' },
  { id: 'clutch', nm: 'На волоске', src: 'a:s_clutch' },
  { id: 'mad', nm: 'Безумица', src: 'a:u_madness' },
  { id: 'ghost', nm: 'Неприкасаемая', src: 'a:u_untouch' },
  { id: 'flawless', nm: 'Безупречная', src: 'a:u_perfect' },
  { id: 'abyssq', nm: 'Королева Бездны', src: 'a:u_abyss' },
  { id: 'legend', nm: 'Легенда Крилессы', src: 'a:u_legend' },
];
// аура вокруг героини – видна и подругам в игре вместе
const AURAS = [
  { id: 'none', nm: 'Без ауры', ic: '∅', src: '' },
  { id: 'sparks', nm: 'Искры', ic: '✨', src: 'a:bosses2' },
  { id: 'petals', nm: 'Лепестки', ic: '🌸', src: 'a:clean1' },
  { id: 'hearts', nm: 'Сердечки', ic: '💗', src: 'a:revive2' },
  { id: 'snow', nm: 'Снежинки', ic: '❄️', src: 'a:ch6' },
  { id: 'bubbles', nm: 'Пузырьки', ic: '🫧', src: 'a:ch7' },
  { id: 'fire', nm: 'Пламя', ic: '🔥', src: 'a:combo3' },
  { id: 'stars', nm: 'Звёзды', ic: '⭐', src: 'k:4' },
  { id: 'rainbow', nm: 'Радуга', ic: '🌈', src: 'a:u_untouch' },
  { id: 'void', nm: 'Тьма Бездны', ic: '🌑', src: 'a:u_abyss' },
  { id: 'gold', nm: 'Золотое сияние', ic: '👑', src: 'a:u_legend' },
];
const LOOK_SETS = { em: EMBLEMS, fr: FRAMES, ti: TITLES, au: AURAS };
const LOOK_DEF = { em: 'star', fr: 'wood', ti: 'rank', au: 'none' };
const lookItem = (k, id) => LOOK_SETS[k].find(x => x.id === id) || LOOK_SETS[k][0];
// открыта ли награда: по достижению или по званию
function lookOwned(it, ach, rank) {
  if (!it.src) return true;
  const [t, v] = it.src.split(':');
  return t === 'k' ? rank >= +v : !!(ach && ach[v]);
}
// аватарка: эмблема в кружке, вокруг – рамка (живые рамки крутятся)
function avatarHtml(look, size) {
  const em = lookItem('em', look && look.em), fr = lookItem('fr', look && look.fr);
  return `<span class="av2${fr.a ? ' live' : ''}" style="--s:${size || 40}px;--fb:${fr.b};${fr.a ? '--fa:' + fr.a + ';' : ''}${fr.glow ? '--fg:' + fr.glow + ';' : ''}"><i style="background:radial-gradient(circle at 35% 30%,${em.bg}cc,${em.bg} 60%,#0008)">${em.ic}</i></span>`;
}

// ауры из значков (сезонные): g – значок, m – fall / rise / orbit
const AURA_FX = {};
function drawGlyphAura(c, fx, x, y, t) {
  c.save(); c.textAlign = 'center'; c.textBaseline = 'middle';
  const n = fx.m === 'orbit' ? 5 : 6;
  for (let k = 0; k < n; k++) {
    let px, py, a = 1, sz = 11;
    if (fx.m === 'orbit') {
      const ang = t * 1.4 + k * Math.PI * 2 / n; px = x + Math.cos(ang) * 26; py = y - 8 + Math.sin(ang) * 11;
      a = 0.55 + 0.45 * Math.sin(ang); sz = 9 + 3 * (0.5 + 0.5 * Math.sin(ang));
    } else {
      const ph = (t * 0.45 + k / n) % 1, sx = Math.sin(k * 7.3) * 22 + Math.sin(t * 1.3 + k) * 5;
      px = x + sx; py = fx.m === 'rise' ? y + 8 - ph * 50 : y - 44 + ph * 52; a = Math.sin(ph * Math.PI);
    }
    c.globalAlpha = Math.max(0, a) * 0.9; c.font = `${sz}px sans-serif`; c.fillText(fx.g, px, py);
  }
  c.restore();
}
// ауры рисуются под героиней на холсте игры
function drawAura(c, id, x, y, t) {
  if (!id || id === 'none') return;
  if (AURA_FX[id]) { drawGlyphAura(c, AURA_FX[id], x, y, t); return; }
  const TAU2 = Math.PI * 2;
  c.save();
  if (id === 'sparks' || id === 'stars') {
    for (let k = 0; k < 7; k++) {
      const a = t * (id === 'stars' ? 0.9 : 1.6) + k * TAU2 / 7, r = 26 + Math.sin(t * 2 + k) * 4;
      const px = x + Math.cos(a) * r, py = y - 8 + Math.sin(a) * r * 0.45, tw = 0.5 + 0.5 * Math.sin(t * 6 + k * 1.7);
      c.globalAlpha = 0.35 + tw * 0.6; c.fillStyle = id === 'stars' ? '#ffe08a' : '#fff3a0';
      if (id === 'stars') { c.font = `${8 + tw * 5}px sans-serif`; c.textAlign = 'center'; c.fillText('★', px, py + 4); }
      else { c.beginPath(); c.arc(px, py, 1.5 + tw * 2, 0, TAU2); c.fill(); }
    }
  } else if (id === 'petals' || id === 'snow' || id === 'hearts' || id === 'bubbles') {
    const n = id === 'hearts' ? 5 : 8, rise = id === 'hearts' || id === 'bubbles';
    for (let k = 0; k < n; k++) {
      const ph = (t * (rise ? 0.55 : 0.4) + k / n) % 1, sx = Math.sin(k * 7.3) * 22 + Math.sin(t * 1.5 + k) * 5;
      const py = rise ? y + 10 - ph * 52 : y - 42 + ph * 52, px = x + sx;
      c.globalAlpha = Math.sin(ph * Math.PI) * 0.85;
      if (id === 'snow') { c.fillStyle = '#ffffff'; c.beginPath(); c.arc(px, py, 2.2, 0, TAU2); c.fill(); }
      else if (id === 'petals') { c.fillStyle = k % 2 ? '#ffb0d0' : '#ffd8e8'; c.beginPath(); c.ellipse(px, py, 3.5, 2, t * 2 + k, 0, TAU2); c.fill(); }
      else if (id === 'bubbles') { c.strokeStyle = 'rgba(200,245,255,0.9)'; c.lineWidth = 1.2; c.beginPath(); c.arc(px, py, 2.5 + (k % 3), 0, TAU2); c.stroke(); }
      else { c.fillStyle = k % 2 ? '#ff5b8a' : '#ff9ad8'; c.font = '9px sans-serif'; c.textAlign = 'center'; c.fillText('♥', px, py); }
    }
  } else if (id === 'fire') {
    for (let k = 0; k < 9; k++) {
      const ph = (t * 1.6 + k / 9) % 1, px = x + Math.sin(k * 4.1) * 13, py = y + 10 - ph * 34;
      c.globalAlpha = (1 - ph) * 0.7; c.fillStyle = ph < 0.4 ? '#ffd25a' : '#ff5a1a';
      c.beginPath(); c.arc(px, py, 5 * (1 - ph) + 1, 0, TAU2); c.fill();
    }
  } else if (id === 'rainbow' || id === 'gold' || id === 'void') {
    const g = c.createRadialGradient(x, y - 6, 4, x, y - 6, 34);
    if (id === 'void') { g.addColorStop(0, 'rgba(60,0,120,0.55)'); g.addColorStop(1, 'rgba(0,0,0,0)'); }
    else if (id === 'gold') { g.addColorStop(0, 'rgba(255,220,100,0.45)'); g.addColorStop(1, 'rgba(255,200,60,0)'); }
    else { g.addColorStop(0, `hsla(${(t * 120) % 360},100%,70%,0.4)`); g.addColorStop(1, 'rgba(255,255,255,0)'); }
    c.fillStyle = g; c.beginPath(); c.arc(x, y - 6, 34, 0, TAU2); c.fill();
    c.lineWidth = 2.5;
    for (let k = 0; k < (id === 'void' ? 3 : 1); k++) {
      c.strokeStyle = id === 'void' ? `rgba(140,60,255,${0.5 - k * 0.12})` : id === 'gold' ? 'rgba(255,225,120,0.8)' : `hsl(${(t * 160 + k * 60) % 360},100%,65%)`;
      c.beginPath(); c.ellipse(x, y + 10, 18 + k * 5 + Math.sin(t * 3 + k) * 2, 6 + k * 2, 0, 0, TAU2); c.stroke();
    }
    if (id === 'gold') for (let k = 0; k < 6; k++) { const a = t * 0.8 + k * TAU2 / 6; c.globalAlpha = 0.5; c.strokeStyle = '#fff3a0'; c.lineWidth = 1.5; c.beginPath(); c.moveTo(x + Math.cos(a) * 20, y - 6 + Math.sin(a) * 20); c.lineTo(x + Math.cos(a) * 32, y - 6 + Math.sin(a) * 32); c.stroke(); }
    if (id === 'void') for (let k = 0; k < 6; k++) { const ph = (t * 0.7 + k / 6) % 1, a = k * 2.1 + t; c.globalAlpha = (1 - ph) * 0.8; c.fillStyle = '#1a0030'; c.beginPath(); c.arc(x + Math.cos(a) * 30 * (1 - ph), y - 6 + Math.sin(a) * 22 * (1 - ph), 3, 0, TAU2); c.fill(); }
  }
  c.restore();
}
