'use strict';

const Actors = (() => {
  // ------------------------------------------------------------------
  //  Улучшения и характеристики
  // ------------------------------------------------------------------
  const lv = id => P.up[id] || 0;
  const talent = id => (G.tal && G.tal[id]) || 0;
  const relicMax = () => 3 + talent('relic');
  // Адаптивные противники учитывают обычный билд. Награда атласа остаётся преимуществом героини.
  let powerBeforeAtlas = null;
  function computeStats(fillGrowth = true) {
    const oldMax = P.maxHp;
    Object.assign(P, statsFor(P.up, P.bonus, P.hero));
    { const so = statsFor(P.up, P.bonus, P.hero, true); P.oldK = estMobDPS(so) / estMobDPS(P); P.oldKb = estDPS(so) / estDPS(P); } // 1.0.15: во сколько раз её урон по прежнему расчёту меньше – для обороны
    if (Encounters.hasRelic('boots')) { P.speed *= 1.1 + 0.05 * Encounters.relicLv('boots'); P.dashCdMax *= 0.8 - 0.05 * Encounters.relicLv('boots'); }
    if (Encounters.hasRelic('horseshoe')) P.magnet *= 2 + Encounters.relicLv('horseshoe');
    if (Encounters.hasRelic('hourglass')) P.superGain *= 1.2 + 0.2 * Encounters.relicLv('hourglass');
    if (Encounters.hasRelic('clover')) P.crit = Math.min(0.85, P.crit + 0.06 + 0.04 * Encounters.relicLv('clover'));
    if (Encounters.hasRelic('heartstone')) P.maxHp = Math.round(P.maxHp * (1.15 + 0.1 * Encounters.relicLv('heartstone')));
    if (Encounters.hasRelic('crown')) P.dmg *= 1.15 + 0.1 * Encounters.relicLv('crown');
    // эволюции
    if (lv('evBlood')) P.critMul += 0.5;
    if (lv('evAegis') && P.shieldLv) P.shieldCd *= 0.5;
    if (lv('evComet')) P.dashCdMax *= 0.5;
    if (lv('evNova')) P.superGain *= 1.5;
    // таланты (звёзды)
    if (talent('dmg')) P.dmg *= Math.pow(1 + 0.04, talent('dmg'));
    if (talent('hp')) P.maxHp = Math.round(P.maxHp * Math.pow(1 + 0.06, talent('hp')));
    if (talent('crit')) P.crit = Math.min(0.85, P.crit + 0.03 * talent('crit'));
    if (talent('speed')) P.speed *= Math.pow(1 + 0.04, talent('speed'));
    if (talent('magnet')) P.magnet *= Math.pow(1 + 0.25, talent('magnet'));
    if (talent('critdmg')) P.critMul += 0.12 * talent('critdmg');
    if (talent('rate')) P.fireInt /= Math.pow(1 + 0.04, talent('rate'));
    if (talent('armor')) P.armor = Math.min(0.7, P.armor + 0.03 * talent('armor'));
    if (talent('dashcd')) P.dashCdMax *= Math.pow(1 - 0.12, talent('dashcd'));
    if (Challenges.mutOn('glass')) { P.dmg *= 1.5; P.maxHp = Math.round(P.maxHp * 0.5); }
    if (talent('regen')) P.regen += P.maxHp * 0.004 * talent('regen');
    const atlas = StarTrail.activeBonus;
    powerBeforeAtlas = null;
    if (atlas.count) {
      powerBeforeAtlas = { mob: estMobDPS(P), boss: estDPS(P), health: estEHP(P) };
      P.dmg *= 1 + atlas.damagePercent / 100;
      P.maxHp = Math.round(P.maxHp * (1 + atlas.healthPercent / 100));
    }
    if (fillGrowth && P.maxHp > oldMax) P.hp += P.maxHp - oldMax;
    P.hp = Math.min(P.hp, P.maxHp);
  }
  const xpFor = l => 5 + l * 4 + Math.floor(l * l * 0.35);
  // ---------- Баланс: всё подстраивается под силу героя ----------
  function nextBossIdx() { for (let i = 0; i < Session.bosses.length; i++) if (!G.defeated[i]) return i; return Session.bosses.length - 1; }
  function zoneE(biome) {
    const keys = Object.keys(World.CFG.zoneLevel);
    const zl = World.CFG.zoneLevel[biome] !== undefined ? World.CFG.zoneLevel[biome] : World.CFG.zoneLevel[keys[0]];
    const prog = Session.bosses.length ? World.CFG.bossLevels[nextBossIdx()] - 3 : zl;
    return Math.max(zl, prog);
  }
  // Сложность главы набирает силу постепенно: на старте (ур. 4) мобы как в главе 1,
  // к локациям 16-го уровня – полный множитель главы. Глава всегда начинается с 1 уровня.
  function chDiff(E) {
    const k = World.CFG.rush ? 1 : clamp((E - 4) / 12, 0, 1);
    return { hp: 1 + (World.CFG.diff.hp - 1) * k, dmg: 1 + (World.CFG.diff.dmg - 1) * k, k };
  }
  function mobScale(E) {
    const key = Math.round(E);
    const cached = G.scaleCache[key];
    if (cached) return cached;
    const Rm = (powerBeforeAtlas ? powerBeforeAtlas.mob : estMobDPS(P)) / refMobDPS(E);
    const Q = (powerBeforeAtlas ? powerBeforeAtlas.health : estEHP(P)) / refEHP(E), cd = chDiff(E);
    const sc = {
      hp: BAL.mobHpK * BAL.metaK * refMobDPS(E) / refMobDPS(4) * cd.hp * G.diff.hp * scaleUp(Rm, BAL.mobHpExp, 0.6),
      dmg: BAL.mobDmgK * BAL.metaK * refEHP(E) / refEHP(4) * cd.dmg * G.diff.dmg * scaleUp(Q, BAL.mobDmgExp, 0.7),
      xp: xpFor(E) / BAL.xpDiv * xpGap(P.level, E),
    };
    G.scaleCache[key] = sc;
    return sc;
  }
  function bossStats(b) {
    const E = World.CFG.bossLevels[b.id] !== undefined ? World.CFG.bossLevels[b.id] : World.CFG.bossLevels[World.CFG.bossLevels.length - 1] + 2;
    const tdB = !!(G.td && G.abyss);
    const dps = powerBeforeAtlas ? powerBeforeAtlas.boss : estDPS(P);
    const Rb = tdB ? dps * (P.oldKb || 1) / refDPSOld(E) : dps / refDPS(E);
    const Q = (powerBeforeAtlas ? powerBeforeAtlas.health : estEHP(P)) / refEHP(E);
    b.E = E;
    const cd = chDiff(E);
    b.maxHp = b.hp = b.def.ttk * (tdB ? refDPSOld(E) : refDPS(E)) * BAL.eff * BAL.metaK * cd.hp * G.diff.hp * scaleUp(Rb, BAL.bossHpExp, 0.6);
    const dm = refEHP(E) * BAL.bossDmgK * BAL.metaK * cd.dmg * G.diff.dmg * scaleUp(Q, BAL.bossDmgExp, 0.7);
    b.dmg = b.def.hit * dm; b.cdmg = b.def.touch * dm;
    b.level = E + Math.max(0, Math.round((P.level - E) * 0.7));
    b.aggro = 1 + clamp((P.level - E) * 0.02, 0, 0.3);
    if (G.mut && G.mut.ng) { b.maxHp *= 1.6; b.hp = b.maxHp; b.dmg *= 1.6; b.cdmg *= 1.6; }
  }
  function rollHit(base) {
    const crit = Math.random() < P.crit;
    if (crit && lv('evBlood') && (G.bloodT || 0) <= 0 && P.hp < P.maxHp && !P.down) { G.bloodT = 0.3; P.hp = Math.min(P.maxHp, P.hp + P.maxHp * 0.01); } // кровавая луна
    const combo = P.up.c2combo ? 1 + 0.01 * P.up.c2combo * Math.min(G.combo, 100) / 10 : 1;
    const rage = talent('berserk') && P.hp < P.maxHp * 0.35 ? Math.pow(1 + 0.15, talent('berserk')) : 1;
    return { v: base * (crit ? P.critMul : 1) * rnd(0.9, 1.1) * (P.napT > 0 ? 1.2 : 1) * combo * (G.cookieT > 0 ? 1.25 : 1) * rage, crit };
  }

  return { lv, talent, relicMax, computeStats, xpFor, zoneE, chDiff, mobScale, bossStats, rollHit };
})();
