'use strict';

const CoopActivity = (() => {
  const goals = {
    1: 'Победите трёх стражей, откройте Тёмный замок и освободите Рыжовую.',
    2: 'Одолейте четырёх стражей и проберитесь в Кринж-Цитадель за Рыжовой.',
    3: 'Откройте путь в Зеркальный дворец и спасите Крилессу.',
    4: 'Держитесь света ламп, найдите источник сбоев и решите судьбу ночной квартиры.',
    5: 'Собирайте улики, расспрашивайте подозреваемых и узнайте, кто украл корм.',
    6: 'Зажигайте костры и победите стражей, чтобы попасть в Ледяной замок.',
    7: 'Найдите жемчужины со словами любви и пройдите через течения к Крилевому замку.',
  };

  function chapterName(ch) { return 'Глава ' + ch + ' · ' + CHAPTERS[ch].name; }
  function isChapter(ch) { return Session.CH_NUMS.includes(ch); }
  function editable() { return NET.host && !NET.started; }
  function modesOpen(profile) { return !!(profile.ch1Done || profile.admin || GameLoop.DEBUG); }
  function canMutate(profile) {
    return editable() && isChapter(NET.ch) && !!(profile['ch' + NET.ch + 'Done'] || profile.admin || GameLoop.DEBUG);
  }

  function mutators(values) {
    return Array.isArray(values) ? Challenges.MUTS.map(m => m.id).filter(id => values.includes(id)) : [];
  }

  function validSave(save) {
    return save && isChapter(save.ch) && typeof save.id === 'string' && save.id.length > 0 && Number.isFinite(save.seed);
  }

  function resumeSummary(save) {
    if (!validSave(save)) return null;
    const done = Array.isArray(save.defeated) ? save.defeated.filter(Boolean).length : 0;
    return { ch: save.ch, level: Math.max(1, save.level | 0), done: Math.min(CHAPTERS[save.ch].bosses.length, done) };
  }

  function settingsKey() {
    return JSON.stringify([NET.ch, NET.ch === 'defense' ? NET.dmap : '',
      isChapter(NET.ch) ? mutators(NET.mut) : [], NET.resume ? NET.resume.id : '']);
  }

  // Частые сетевые обновления списка игроков не должны прерывать выбор в открытом select.
  function showChoices(select, choices, selected) {
    const unchanged = choices.length === select.options.length && choices.every((choice, i) => {
      const option = select.options[i];
      return option.value === String(choice.value) && option.text === choice.label && option.disabled === !!choice.locked;
    });
    if (!unchanged) {
      select.options.length = 0;
      for (const choice of choices) {
        const option = new Option(choice.label, String(choice.value));
        option.disabled = !!choice.locked;
        select.add(option);
      }
    }
    if (select.value !== String(selected)) select.value = String(selected);
  }

  function render() {
    const profile = NET.host ? Saves.loadProfile() : {};
    const story = isChapter(NET.ch), defense = NET.ch === 'defense';
    const hostChooses = editable();
    const map = TD_MAP_BY[NET.dmap] || TD_MAPS[0];
    const name = story ? chapterName(NET.ch) : defense ? 'Оборона' : 'Босс-раш';
    $('mpChName').textContent = name;
    $('mpChName').classList.toggle('hidden', hostChooses);
    $('mpChs').classList.toggle('hidden', !hostChooses);
    if (hostChooses) {
      const choices = Session.CH_NUMS.filter(ch => Chapters.chapterOpen(ch, profile) || (NET.resume && NET.resume.ch === ch))
        .map(ch => ({ value: ch, label: chapterName(ch) }));
      const locked = !modesOpen(profile), suffix = locked ? ' · после главы 1' : '';
      choices.push({ value: 'rush', label: 'Босс-раш' + suffix, locked },
        { value: 'defense', label: 'Оборона' + suffix, locked });
      showChoices($('mpChapter'), choices, NET.ch);
    }
    $('mpActivityGoal').textContent = story ? goals[NET.ch] : defense ?
      'Стройте башни и защищайте кристалл. Между волнами чините его вместе. ' + map.ds + '.' :
      'Победите подряд боссов из глав хозяйки. Удары разных героинь по одному боссу усиливают команду. В зачёт идёт общее время.';
    $('mpMapRow').classList.toggle('hidden', !defense || !hostChooses);
    $('mpMapName').classList.toggle('hidden', !defense || hostChooses);
    if (defense) {
      $('mpMapName').textContent = 'Карта · ' + map.nm;
      if (hostChooses) {
        const choices = TD_MAPS.map(m => {
          const locked = !Defense.tdMapOpen(m, profile);
          const hint = locked ? ' · пройдите волну 10 на карте «' + TD_MAP_BY[m.need].nm + '»' : '';
          return { value: m.id, label: m.nm + hint, locked };
        });
        showChoices($('mpDefenseMap'), choices, map.id);
      }
    }

    const mods = mutators(NET.mut), canEdit = canMutate(profile);
    const mb = $('mpMut');
    mb.classList.toggle('hidden', !story || (!canEdit && !mods.length));
    mb.disabled = !canEdit;
    mb.classList.toggle('on', mods.length > 0);
    mb.textContent = mods.length ? 'Мутаторы · ' + mods.map(id => Challenges.MUT_BY[id].nm).join(', ') : 'Выбрать мутаторы';

    const slot = hostChooses && story ? Saves.coopLoad(Saves.COOP_KEY) : null;
    const rb = $('mpResume');
    rb.classList.toggle('hidden', !validSave(slot));
    rb.setAttribute('aria-pressed', String(!!NET.resume));
    if (validSave(slot)) rb.textContent = NET.resume ? 'Выбрать новое прохождение' : 'Продолжить · ' + chapterName(slot.ch);
    const summary = NET.host ? resumeSummary(NET.resume) : NET.savedSummary;
    const active = story && summary && summary.ch === NET.ch;
    $('mpActivitySaved').classList.toggle('hidden', !active);
    $('mpActivitySaved').textContent = active ? 'Из сохранения · уровень ' + summary.level +
      ' · побед над боссами ' + summary.done + ' из ' + CHAPTERS[NET.ch].bosses.length : '';
  }

  function selectActivity() {
    if (!editable()) return;
    const value = $('mpChapter').value, ch = /^\d+$/.test(value) ? Number(value) : value;
    const profile = Saves.loadProfile();
    if (ch === NET.ch || (isChapter(ch) ? !Chapters.chapterOpen(ch) : !['rush', 'defense'].includes(ch) || !modesOpen(profile))) return;
    NET.ch = ch;
    NET.resume = null;
    NET.mut = [];
    if (ch === 'defense' && (!TD_MAP_BY[NET.dmap] || !Defense.tdMapOpen(TD_MAP_BY[NET.dmap], profile))) {
      NET.dmap = Defense.tdMapPick(profile).id;
    }
    Sound.sfx.click();
    Multiplayer.mpLobbyBroadcast();
  }

  function selectMap() {
    if (!editable() || NET.ch !== 'defense') return;
    const map = TD_MAP_BY[$('mpDefenseMap').value];
    if (!map || map.id === NET.dmap || !Defense.tdMapOpen(map, Saves.loadProfile())) return;
    NET.dmap = map.id;
    Sound.sfx.click();
    Multiplayer.mpLobbyBroadcast();
  }

  function toggleResume() {
    if (!editable() || !isChapter(NET.ch)) return;
    const slot = Saves.coopLoad(Saves.COOP_KEY);
    if (!validSave(slot)) return;
    if (NET.resume) {
      NET.resume = null;
      NET.mut = [];
      if (!Chapters.chapterOpen(NET.ch)) NET.ch = 1;
    } else {
      NET.ch = slot.ch;
      NET.resume = slot;
      NET.mut = mutators(slot.mut);
    }
    Multiplayer.mpLobbyBroadcast();
  }

  function openMutators() {
    if (!canMutate(Saves.loadProfile())) return;
    if (NET.rdy) Multiplayer.mpToggleReady();
    Challenges.openMuts(NET.ch, true);
  }

  function selectMutators(values) {
    if (!canMutate(Saves.loadProfile())) return;
    const next = mutators(values);
    if (String(next) !== String(mutators(NET.mut))) NET.resume = null;
    NET.mut = next;
    Multiplayer.mpLobbyBroadcast();
  }

  $('mpChapter').addEventListener('change', selectActivity);
  $('mpDefenseMap').addEventListener('change', selectMap);
  return { render, resumeSummary, settingsKey, toggleResume, openMutators, selectMutators };
})();
