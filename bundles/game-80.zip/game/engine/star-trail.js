'use strict';

const StarTrail = (() => {
  const COUNT = 3;
  const ROUTE_LENGTH = 32;
  const HEALTH_PERCENT_PER_SIGN = 5;
  const DAMAGE_PERCENT_PER_SIGN = 4;
  const HEAL_PERCENT = 30;
  const directions = [[0, -1], [-1, 0], [1, 0], [0, 1]];
  let trail = null;
  let recorded = false;
  let pendingHeal = false, pendingSaved = false, retryAt = 0;
  let activeBonus = bonuses(null);

  function bonuses(profile) {
    const atlas = profile && profile.atlas;
    let count = 0;
    if (atlas && typeof atlas === 'object' && !Array.isArray(atlas)) {
      for (let chapter = 1; chapter <= 7; chapter++) if (atlas[chapter] === true) count++;
    }
    return { count, healthPercent: count * HEALTH_PERCENT_PER_SIGN, damagePercent: count * DAMAGE_PERCENT_PER_SIGN };
  }

  // Находим короткий путь по соседним проходимым клеткам в сторону первого стража.
  // Используем исходную карту с закрытыми воротами, до восстановления растаявшего льда.
  function placeStars() {
    const reserved = new Set();
    for (const group of [World.chests, World.shrines, World.shelves, World.boxes, World.beds,
      World.lamps, World.npcs, World.clues, World.qitems, World.drifts, World.fires,
      World.holes, World.ovens, World.pearls]) {
      for (const object of group) reserved.add(Math.floor(object.y / World.T) * World.MW + Math.floor(object.x / World.T));
    }
    const start = World.START, guardian = World.CFG.bossTiles[0];
    const origin = { x: start.x, y: start.y, depth: 0, road: 0, parent: null };
    const queue = [origin], seen = new Map([[start.y * World.MW + start.x, origin]]);
    let best = origin, bestScore = Infinity;
    for (let i = 0; i < queue.length; i++) {
      const node = queue[i];
      const score = Math.hypot(node.x - guardian.x, node.y - guardian.y) - node.road;
      if (node.depth > best.depth || (node.depth === best.depth && score < bestScore)) {
        best = node;
        bestScore = score;
      }
      if (node.depth === ROUTE_LENGTH) continue;
      for (const [dx, dy] of directions) {
        const x = node.x + dx, y = node.y + dy;
        if (!World.inMap(x, y) || y >= World.PLAY_H) continue;
        const key = y * World.MW + x;
        const existing = seen.get(key), depth = node.depth + 1;
        if ((existing && existing.depth < depth) || reserved.has(key) || World.treeGrid[key]) continue;
        const tile = World.tileAt(x, y);
        if (tile === FLOOR || tile === GATE || World.isSolidTile(x, y, false)) continue;
        // На равноценных пеших маршрутах предпочитаем дорогу, которую проложил генератор этой главы.
        const road = node.road + (tile === PATH || tile === STONE ? 1 : 0);
        if (!existing) {
          const next = { x, y, parent: node, depth, road };
          seen.set(key, next);
          queue.push(next);
        } else if (road > existing.road) {
          existing.road = road;
          existing.parent = node;
        }
      }
    }
    const route = [];
    for (let node = best; node.parent; node = node.parent) route.push(node);
    route.reverse();
    if (route.length < COUNT) return [];
    // Обычно это 4, 17 и 32 пеших шага от старта. Поддерживаем и короткие маршруты.
    const first = Math.min(3, Math.floor(route.length / 6));
    return [first, Math.floor(route.length / 2), route.length - 1].map(i => ({
      x: World.tc(route[i].x), y: World.tc(route[i].y),
    }));
  }

  function reset() {
    trail = null;
    recorded = false;
    pendingHeal = false;
    pendingSaved = false;
    retryAt = 0;
    activeBonus = bonuses(null);
  }

  function recordSign(updateStats) {
    if (recorded) return true;
    const profile = Saves.loadProfile();
    if (!profile.atlas || typeof profile.atlas !== 'object' || Array.isArray(profile.atlas)) profile.atlas = {};
    if (profile.atlas[World.CHN] !== true) {
      profile.atlas[World.CHN] = true;
      if (!Saves.saveProfile(profile)) return false;
    }
    recorded = true;
    const previous = activeBonus.count;
    activeBonus = bonuses(profile);
    if (updateStats && previous !== activeBonus.count) Actors.computeStats(false);
    return true;
  }

  function start(saved) {
    reset();
    if (NET.on || G.daily || (G.mut && Object.keys(G.mut).length) || !Session.CH_NUMS.includes(World.CHN)) return;
    activeBonus = bonuses(Saves.loadProfile());
    const stars = placeStars();
    if (stars.length !== COUNT) return;
    const step = saved && saved.collected;
    const collected = Number.isInteger(step) && step >= 0 && step <= COUNT ? step : 0;
    trail = { stars, collected };
    // В слотах 1.1 три собранные звезды уже означали выданную награду.
    if (collected === COUNT) {
      pendingHeal = saved.pendingHeal === true;
      pendingSaved = true;
      recordSign(false);
    }
  }

  function view() { return G.inMenu || NET.on ? null : trail; }

  function snapshot() {
    if (!trail) return null;
    return pendingHeal ? { collected: trail.collected, pendingHeal: true } : { collected: trail.collected };
  }

  // Сначала фиксируем касание в слоте, затем постоянный знак в профиле.
  // Лечение и снятие pendingHeal пишутся вместе (в том числе здоровье команды главы 6).
  function finish() {
    retryAt = G.time + 1;
    if (pendingHeal && !pendingSaved) {
      if (!Saves.saveTrail()) return;
      pendingSaved = true;
    }
    if (!recordSign(true) || !pendingHeal) return;
    const before = P.hp;
    P.hp = Math.min(P.maxHp, before + Math.round(P.maxHp * HEAL_PERCENT / 100));
    const gain = P.hp - before;
    pendingHeal = false;
    if (!Saves.saveTrail()) {
      P.hp = before;
      pendingHeal = true;
      return;
    }
    const star = trail.stars[COUNT - 1];
    StarArt.collected(star.x, star.y);
    Sound.sfx.atlasStar(COUNT);
    if (gain > 0) Effects.floatText(P.x, P.y - 34, '+' + Math.round(gain) + ' здоровья', '#96f0bd', true);
    RunStats.toast('Созвездие собрано! Бонус атласа: +' + activeBonus.healthPercent + '% здоровья и +' +
      activeBonus.damagePercent + '% урона.');
  }

  function update() {
    if (!view() || Session.state !== 'play' || P.down || G.jump || G.hidden || G.activeShrine) return;
    if (trail.collected === COUNT) {
      if ((!recorded || pendingHeal) && G.time >= retryAt) finish();
      return;
    }
    const star = trail.stars[trail.collected];
    if (Math.hypot(P.x - star.x, P.y - star.y) > P.r + 18) return;
    trail.collected++;
    if (trail.collected === COUNT) {
      pendingHeal = true;
      finish();
      return;
    }
    Saves.saveGame();
    StarArt.collected(star.x, star.y);
    Sound.sfx.atlasStar(trail.collected);
    Effects.floatText(star.x, star.y - 24, '✦ ' + trail.collected + ' / ' + COUNT, '#ffe5a2', true);
  }

  return { HEALTH_PERCENT_PER_SIGN, DAMAGE_PERCENT_PER_SIGN, HEAL_PERCENT, bonuses,
    reset, start, update, view, snapshot, get activeBonus() { return activeBonus; } };
})();
