'use strict';

const Story = (() => {
  // ------------------------------------------------------------------
  //  Подлянка финала главы 3
  // ------------------------------------------------------------------
  let trickTimers = [];
  const later = (ms, fn) => trickTimers.push(setTimeout(fn, ms));
  const Trick = { cv: null, c: null, raf: 0, t0: 0, mode: '', cracks: [], shards: [] };
  function trickSetup() {
    Trick.cv = $('trickCanvas'); Trick.c = Trick.cv.getContext('2d');
    const d = Math.min(window.devicePixelRatio || 1, 2);
    Trick.cv.width = Math.round(Viewport.VW * d); Trick.cv.height = Math.round(Viewport.VH * d);
    Trick.c.setTransform(d, 0, 0, d, 0, 0);
    Trick.cv.classList.remove('hidden');
  }
  function trickLoop(now) {
    const c = Trick.c, t = (now - Trick.t0) / 1000;
    c.clearRect(0, 0, Viewport.VW, Viewport.VH);
    if (Trick.mode === 'crack') {
      const k = clamp(t / 0.9, 0, 1);
      c.strokeStyle = 'rgba(255,255,255,0.9)'; c.lineWidth = 2; c.shadowColor = '#ff3ea5'; c.shadowBlur = 8;
      for (const cr of Trick.cracks) {
        const n = Math.floor(cr.length * k);
        c.beginPath(); c.moveTo(cr[0][0], cr[0][1]);
        for (let i = 1; i < n; i++) c.lineTo(cr[i][0], cr[i][1]);
        c.stroke();
      }
      c.shadowBlur = 0;
    } else if (Trick.mode === 'shatter') {
      c.fillStyle = `rgba(10,4,20,${clamp(t / 0.3, 0, 1)})`; c.fillRect(0, 0, Viewport.VW, Viewport.VH);
      for (const s of Trick.shards) {
        s.vy += 900 * (1 / 60); s.x += s.vx / 60; s.y += s.vy / 60; s.a += s.va / 60;
        c.save(); c.translate(s.x, s.y); c.rotate(s.a);
        c.globalAlpha = clamp(1.6 - t, 0, 1);
        const g = c.createLinearGradient(-30, -30, 30, 30); g.addColorStop(0, '#5a2a4a'); g.addColorStop(0.5, '#ffb347'); g.addColorStop(1, '#2a1238');
        c.fillStyle = g; c.beginPath(); s.pts.forEach(([x, y], i) => i ? c.lineTo(x, y) : c.moveTo(x, y)); c.closePath(); c.fill();
        c.strokeStyle = 'rgba(255,255,255,0.8)'; c.lineWidth = 1.5; c.stroke();
        c.restore();
      }
      c.globalAlpha = 1;
    }
    Trick.raf = requestAnimationFrame(trickLoop);
  }
  function startTrick() {
    if (Session.state !== 'victory' || World.CHN !== 3 || G.trueWin) return;
    const vic = $('victory'); vic.classList.add('glitching');
    Sound.setGlitch(1); Sound.sfx.staticNoise();
    const title = $('victoryTitle'), orig = title.textContent, glyphs = '█▓▒░#@%&?!ЗЯМОЧКККК';
    let n = 0;
    const scr = setInterval(() => { n++; title.textContent = orig.split('').map(ch => Math.random() < n * 0.05 ? glyphs[Math.floor(Math.random() * glyphs.length)] : ch).join(''); }, 90);
    later(900, () => Sound.sfx.staticNoise());
    later(1800, () => { Sound.sfx.staticNoise(); G.shake = 20; });
    later(2200, () => {
      trickSetup(); Trick.mode = 'crack'; Trick.t0 = performance.now(); Trick.cracks = [];
      const cx = Viewport.VW * 0.5, cy = Viewport.VH * 0.38;
      for (let i = 0; i < 16; i++) {
        let a = (i / 16) * TAU + rnd(-0.2, 0.2), x = cx, y = cy; const pts = [[x, y]];
        for (let k = 0; k < 10; k++) { a += rnd(-0.5, 0.5); const l = rnd(25, 70); x += Math.cos(a) * l; y += Math.sin(a) * l; pts.push([x, y]); }
        Trick.cracks.push(pts);
      }
      Sound.sfx.glass();
      cancelAnimationFrame(Trick.raf); Trick.raf = requestAnimationFrame(trickLoop);
    });
    later(3200, () => {
      clearInterval(scr);
      Trick.mode = 'shatter'; Trick.t0 = performance.now(); Trick.shards = [];
      const cols = 6, rows = 10, w = Viewport.VW / cols, h = Viewport.VH / rows;
      for (let i = 0; i < cols; i++) for (let j = 0; j < rows; j++) {
        const x0 = i * w, y0 = j * h;
        for (const tri of [[[0, 0], [w, 0], [0, h]], [[w, 0], [w, h], [0, h]]]) {
          const cxs = (tri[0][0] + tri[1][0] + tri[2][0]) / 3, cys = (tri[0][1] + tri[1][1] + tri[2][1]) / 3;
          const px = x0 + cxs, py = y0 + cys, da = Math.atan2(py - Viewport.VH * 0.38, px - Viewport.VW / 2);
          Trick.shards.push({ x: px, y: py, pts: tri.map(([a, b]) => [a - cxs, b - cys]), vx: Math.cos(da) * rnd(80, 300), vy: Math.sin(da) * rnd(80, 300) - 200, a: 0, va: rnd(-6, 6) });
        }
      }
      Sound.sfx.shatter(); G.shake = 25;
      vic.classList.add('hidden'); vic.classList.remove('glitching');
    });
    later(4300, () => {
      cancelAnimationFrame(Trick.raf); Trick.cv.classList.add('hidden');
      Sound.setGlitch(0); Sound.music('zyamashow'); openZyamaMenu();
    });
  }
  function openZyamaMenu() {
    Screens.setState('zmenu');
    const ac = $('zmAvatar').getContext('2d'); ac.clearRect(0, 0, 160, 160);
    if (ART.zyamaFace) ac.drawImage(ART.zyamaFace, 0, 0, 160, 160);
    $('zmSay').textContent = 'Ой. Вы что, правда думали, что победили? 😏';
    const ex = $('zmExit'); ex.style.transform = ''; ex.textContent = '✖ Выйти';
    G.zm = { tries: 0, go: false };
    later(9500, zyamaMenuGo);
  }
  function zmReact(text, go) { $('zmSay').textContent = text; Sound.sfx.click(); if (go) later(1900, zyamaMenuGo); }
  function zyamaMenuGo() {
    if (!G.zm || G.zm.go) return;
    G.zm.go = true;
    $('zmSay').textContent = 'Вы думали, это конец? Это был только АНТРАКТ! 😈';
    Sound.sfx.roar(); G.shake = 20;
    later(2300, startFinalFinal);
  }
  function startFinalFinal() {
    trickTimers.forEach(clearTimeout); trickTimers = [];
    const d = BOSSES.zyamaInf, hx = World.tc(World.CASTLE.x), hy = World.tc(World.CASTLE.y);
    const b = {
      id: Session.bosses.length, kind: 'zyamaInf', def: d, name: d.name, sub: d.sub, r: d.r, maxHp: 1, hp: 1, spd: d.spd, dmg: 0, cdmg: 0,
      E: 0, level: 0, aggro: 1, shield: false, stunT: 0, burnT: 0, burnDps: 0, burnTick: 0,
      fly: true, move: d.move, hx, hy, x: hx, y: hy - 80, state: 'sleep', mode: 'idle', t: 0, flash: 0, z: 0, last: null, stage: 0, vstage: 3,
      sub: 0, cnt: 0, anim: 0, alpha: 1, ang: 0, tx: 0, ty: 0, sx: 0, sy: 0, dist: 0, charging: false, dur: 0, inv: false, final: true, look: 0, p: null,
      speedMul: 1, tauntT: 6, orbCd: 0,
    };
    Session.bosses.push(b);
    G.cutscene = null; G.cageOpen = 1;
    P.x = hx; P.y = hy + 210; P.hp = P.maxHp; P.inv = 2;
    G.cp = { x: P.x, y: P.y };
    G.finalFinal = { t: 0, bank: 0, need: d.survive, ally: { x: P.x - 55, y: P.y - 20, fireT: 0 }, said: {} };
    G.enemies.length = 0; G.ebullets.length = 0; G.hazards.length = 0; G.beams.length = 0;
    Screens.setState('play');
    Bosses.startBossFight(b);
    later(2600, () => Screens.showBanner('ЗЯМОЧКККК ∞', 'Продержись 40 секунд! Попадания ускоряют ДРУЖБА-СУПЕР'));
  }
  function updateFinalFinal(dt) {
    const F = G.finalFinal;
    if (!F || G.cutscene) return;
    const A = F.ally, b = G.activeBoss;
    A.x = lerp(A.x, P.x - 55 * P.face, Math.min(1, dt * 4)); A.y = lerp(A.y, P.y - 26, Math.min(1, dt * 4));
    A.fireT -= dt;
    if (b && A.fireT <= 0) {
      A.fireT = 0.25;
      const a = Math.atan2(b.y - A.y, b.x - A.x);
      G.feathers.push({ x: A.x, y: A.y, vx: Math.cos(a) * 480, vy: Math.sin(a) * 480, dmg: P.dmg * 0.5, pierce: 3, life: 1.2, hit: [], kind: 'feather', ally: true });
    }
    if (!b) return;
    const extra = Math.min(F.bank, dt * 0.6); F.bank -= extra;
    F.t += dt + extra;
    const lines = [[3, 'Рыжовая, держись! Я заряжаю ДРУЖБА-СУПЕР! 💜'], [16, 'Он бессмертный, но дружба сильнее! Ещё немного!'], [29, 'Почти готово!!! Не сдавайся!'], [36, 'На счёт три... раз... два...']];
    for (const [tt, text] of lines) if (F.t >= tt && !F.said[tt]) { F.said[tt] = 1; Screens.say(text, 3.2); }
    if (F.t >= F.need) startTeamUp();
  }
  function startTeamUp() {
    G.cutscene = { t: 0, kind: 'teamup' };
    G.ebullets.length = 0; G.hazards.length = 0; G.beams.length = 0;
    // без опыта: окно улучшений не должно выскакивать посреди сцены
    for (const e of G.enemies) Effects.burst(e.x, e.y, 8, '#ffffff', 100);
    G.enemies.length = 0;
    Screens.showBanner('ДРУЖБА-СУПЕР!', 'Крилесса + Рыжовая');
    Sound.sfx.nova(); Sound.sfx.magic(); G.shake = 12;
  }
  function updateTeamUp(dt, cs) {
    const b = Session.bosses[Session.bosses.length - 1], A = G.finalFinal.ally;
    A.x = lerp(A.x, P.x - 46, Math.min(1, dt * 3)); A.y = lerp(A.y, P.y - 6, Math.min(1, dt * 3));
    P.t += dt;
    if (cs.t > 0.8 && cs.t < 3.2) { G.shake = Math.max(G.shake, 5); if (Math.random() < 0.9) Effects.part(b.x + rnd(-40, 40), b.y + rnd(-40, 40), rnd(-220, 220), rnd(-220, 220), 0.5, 6, pick(RAINBOW)); }
    if (cs.t >= 3.2 && !cs.boom) {
      cs.boom = true; b.state = 'dead'; G.activeBoss = null;
      Effects.burst(b.x, b.y, 120, '#ffd25a', 520); Effects.burst(b.x, b.y, 80, '#ff3ea5', 420); Effects.burst(b.x, b.y, 60, '#3ff0ff', 360);
      Effects.shockRing(b.x, b.y, '#ffffff', 650); G.shake = 30; Sound.sfx.boom(); Sound.sfx.win();
      Screens.speak('zyamaInf', b.def.lines.death, 4.5);
      Sound.music('truewin');
      if (G.st && G.st.cur) { const c = G.st.cur; G.st.bosses.push({ k: c.k, n: c.n, pl: c.pl, bl: c.bl, t: Math.round(G.st.time - c.t0), d: c.d, h: c.h || 0, df: c.df || G.diffId }); G.st.cur = null; }
    }
    if (cs.boom && Math.random() < 0.4) Effects.part(P.x + rnd(-80, 80), P.y + rnd(-90, 10), 0, -50, 1.4, 6, '#ff5b8a');
    if (cs.t > 8.5 && !G.trueWin) {
      G.trueWin = true;
      const prof = Saves.loadProfile(); prof.trueWin = true; Saves.saveProfile(prof);
      RunStats.recordRunEnd('настоящая победа');
      Screens.showVictory('true');
    }
  }

  // ------------------------------------------------------------------
  //  Что нового (после обновления)
  // ------------------------------------------------------------------
  let wnBack = 'menu';
  const versionParts = version => (String(version).match(/\d+/g) || []).map(Number);
  function newerVersion(version, previous) {
    const a = versionParts(version), b = versionParts(previous);
    for (let i = 0; i < Math.max(a.length, b.length); i++) {
      const difference = (a[i] || 0) - (b[i] || 0);
      if (difference) return difference > 0;
    }
    return false;
  }

  function showRelease() {
    const release = CHANGELOG[$('wnVersions').value];
    $('wnHeading').textContent = release.title;
    const notes = document.createDocumentFragment();
    for (const [symbol, name, description] of release.items) {
      const note = document.createElement('li');
      const icon = document.createElement('span');
      icon.className = 'wnIcon';
      icon.setAttribute('aria-hidden', 'true');
      icon.textContent = symbol;
      const text = document.createElement('div');
      const title = document.createElement('h3');
      title.textContent = name;
      const detail = document.createElement('p');
      detail.textContent = description;
      text.append(title, detail);
      note.append(icon, text);
      notes.appendChild(note);
    }
    const list = $('wnList');
    list.textContent = '';
    list.appendChild(notes);
    $('wnReader').scrollTop = 0;
  }

  $('wnVersions').addEventListener('change', showRelease);
  $('whatsnew').addEventListener('keydown', event => {
    // Клавиатура в журнале управляет книгой независимо от боевых горячих клавиш.
    event.stopPropagation();
    if (event.key === 'Escape') {
      event.preventDefault();
      closeWhatsNew();
    } else if (event.key === 'Tab') {
      const toFirst = !event.shiftKey && event.target === $('wnReader');
      const toLast = event.shiftKey && (event.target === $('wnClose') || event.target === $('wnTitle'));
      if (toFirst || toLast) {
        event.preventDefault();
        $(toFirst ? 'wnClose' : 'wnReader').focus();
      }
    }
  });

  function openWhatsNew(fromVer) {
    const versions = $('wnVersions');
    versions.textContent = '';
    CHANGELOG.forEach((release, i) => {
      if (!fromVer || newerVersion(release.v, fromVer)) versions.add(new Option(release.v, i));
    });
    // Даже у более новой сборки или удалённого номера есть доступ к актуальной записи.
    if (!versions.length) versions.add(new Option(CHANGELOG[0].v, 0));
    $('wnSince').textContent = fromVer && newerVersion(VERSION, fromVer) ? 'После версии ' + fromVer : '';
    if (Session.state !== 'whatsnew') wnBack = Session.state;
    Screens.setState('whatsnew');
    showRelease();
    $('wnTitle').focus({ preventScroll: true });
    Sound.sfx.win();
  }

  function closeWhatsNew() {
    const prof = Saves.loadProfile(); prof.lastVersion = VERSION; Saves.saveProfile(prof);
    if (wnBack === 'menu') AdventureMenu.openMenu();
    else if (wnBack === 'splash') AdventureMenu.openSplash();
    else Screens.setState(wnBack);
    if (wnBack === 'settings') $('btnWhatsNew').focus({ preventScroll: true });
  }

  // ------------------------------------------------------------------
  //  Глава 4: загадка
  // ------------------------------------------------------------------
  let teaserBack = 'menu', teaserRaf = 0, teaserImg = null, teaserT0 = 0, teaserGlow = 0;
  const TEASER_LINES = ['Хорошая… или добрая?..', 'Спит двадцать часов в сутки – но видит всё.', 'Голубые глаза. Мягкие лапки. Острые коготки.',
    'Говорят, она знает, где Зямочкккк прячет корм.', 'Глава 4. Скоро.', 'Мяу.'];
  function teaserLoop(now) {
    const cv = $('teaserCanvas'), c = cv.getContext('2d'), t = (now - teaserT0) / 1000;
    c.clearRect(0, 0, 480, 640);
    const br = 1 + Math.sin(t * 1.4) * 0.012;
    c.save(); c.translate(240, 320); c.scale(br, br); c.translate(-240, -320);
    c.filter = `brightness(${(0.42 + teaserGlow * 0.6).toFixed(2)}) blur(${Math.max(0, 1.4 - teaserGlow * 1.4).toFixed(2)}px)`;
    if (teaserImg) c.drawImage(teaserImg, 0, 0, 480, 640);
    c.filter = 'none';
    c.restore();
    const vg = c.createRadialGradient(240, 300, 120, 240, 320, 400);
    vg.addColorStop(0, 'rgba(0,0,0,0)'); vg.addColorStop(1, 'rgba(0,0,0,0.85)');
    c.fillStyle = vg; c.fillRect(0, 0, 480, 640);
    const g = (0.25 + 0.2 * Math.sin(t * 2)) + teaserGlow;
    for (const [ex, ey] of [[0.345, 0.322], [0.555, 0.322]]) {
      const x = ex * 480, y = ey * 640;
      const gr = c.createRadialGradient(x, y, 0, x, y, 26);
      gr.addColorStop(0, `rgba(120,200,255,${clamp(g, 0, 1) * 0.55})`); gr.addColorStop(1, 'rgba(120,200,255,0)');
      c.fillStyle = gr; c.fillRect(x - 30, y - 30, 60, 60);
      c.strokeStyle = `rgba(180,230,255,${clamp(g, 0, 1) * 0.8})`; c.lineWidth = 2.5;
      c.beginPath(); c.ellipse(x, y, 12, 2.4, 0, 0, TAU); c.stroke();
    }
    teaserGlow = Math.max(0, teaserGlow - 0.02);
    teaserRaf = requestAnimationFrame(teaserLoop);
  }
  let teaserNext = null; // окошко-загадка в начале главы: «Дальше» ведёт в интро
  function openTeaser(next) {
    teaserNext = typeof next === 'function' ? next : null;
    $('teaserBack').textContent = teaserNext ? 'Дальше »' : 'Назад';
    teaserBack = Session.state === 'teaser' ? teaserBack : Session.state;
    Screens.setState('teaser');
    const box = $('teaserLines'); box.innerHTML = '';
    TEASER_LINES.forEach((ln, i) => {
      const el = document.createElement('div'); el.className = 'tline' + (i === TEASER_LINES.length - 1 ? ' meow' : '');
      el.textContent = ln; el.style.animationDelay = (0.6 + i * 1.15) + 's'; box.appendChild(el);
    });
    if (!teaserImg) { teaserImg = new Image(); teaserImg.src = 'ch4_shadow.jpg'; }
    teaserT0 = performance.now(); cancelAnimationFrame(teaserRaf); teaserRaf = requestAnimationFrame(teaserLoop);
    Sound.music(null);
    setTimeout(() => { if (Session.state === 'teaser') { Sound.sfx.meow(); teaserGlow = 0.6; } }, (0.6 + (TEASER_LINES.length - 1) * 1.15) * 1000);
  }
  function closeTeaser() { cancelAnimationFrame(teaserRaf); if (teaserNext) { const nx = teaserNext; teaserNext = null; nx(); } else if (teaserBack === 'menu') AdventureMenu.openMenu(); else Screens.setState(teaserBack); }

  // ------------------------------------------------------------------
  //  Глава 7: загадка из глубины
  // ------------------------------------------------------------------
  const KRILL_LINES = ['Где-то в глубине стало подозрительно тихо…', 'Их миллиарды. Они розовые. Они криляют.', '– Ты меня крилюбишь?..',
    'А на самом дне кто-то ругается так, что краснеют даже креветки.', 'Глава 7. Скоро.', 'Крилять.'];
  const KRILL_SAY = ['криль!', 'крилюблю!', 'криляю!', 'кривет!', 'крилюбишь?', 'кри-кри!', 'криливирую!'];
  const BOSS_SAY = ['Крилять!', 'Ах ты ж крил…', 'Ёкрилый бабай!', '#@%&!!', 'Крилец вам всем!', 'Шо за крилня?!'];
  const KT = { raf: 0, t0: 0, swarm: [], bubbles: [], pops: [], tap: null, red: 0, say: null, sayT: 4 };
  function drawKrill(c, x, y, a, s, t) {
    c.save(); c.translate(x, y); c.rotate(a); c.scale(s, s);
    const w = Math.sin(t * 14) * 1.2;
    c.strokeStyle = 'rgba(255,170,190,0.75)'; c.lineWidth = 0.8;
    c.beginPath(); for (let k = 0; k < 4; k++) { c.moveTo(-3 + k * 2.5, 2); c.lineTo(-4 + k * 2.5 + w * 0.5, 5.5); } c.stroke();
    c.fillStyle = 'rgba(255,110,145,0.92)'; c.beginPath(); c.ellipse(-1, 0, 8, 3, 0, 0, TAU); c.fill();
    c.fillStyle = 'rgba(255,175,195,0.95)'; c.beginPath(); c.ellipse(5, -0.4, 4, 2.6, 0, 0, TAU); c.fill();
    c.fillStyle = 'rgba(255,95,130,0.9)'; c.beginPath(); c.moveTo(-8, 0); c.lineTo(-13, -3.5 + w * 0.3); c.lineTo(-11.5, 0); c.lineTo(-13, 3.5 - w * 0.3); c.closePath(); c.fill();
    c.fillStyle = '#1a0a10'; c.beginPath(); c.arc(7.2, -1.2, 1.1, 0, TAU); c.fill();
    c.strokeStyle = 'rgba(255,200,210,0.6)'; c.beginPath(); c.moveTo(8.5, -1.5); c.quadraticCurveTo(14, -6 + w, 21, -3); c.moveTo(8.5, -0.5); c.quadraticCurveTo(14, -2 - w, 20, 1); c.stroke();
    c.restore();
  }
  function krillLoop(now) {
    if (Session.state !== 'krill') { KT.raf = 0; return; }
    const cv = $('krillCanvas'), c = cv.getContext('2d'), W = 480, H = 640, t = (now - KT.t0) / 1000, dt = Math.min(0.05, (now - (KT.last || now)) / 1000); KT.last = now;
    const g = c.createLinearGradient(0, 0, 0, H); g.addColorStop(0, '#0e4a7a'); g.addColorStop(0.45, '#062a4a'); g.addColorStop(1, '#01060e');
    c.fillStyle = g; c.fillRect(0, 0, W, H);
    for (let k = 0; k < 5; k++) { // лучи света сверху
      const x = 60 + k * 95 + Math.sin(t * 0.4 + k) * 20;
      const rg = c.createLinearGradient(0, 0, 0, H * 0.7); rg.addColorStop(0, 'rgba(160,230,255,0.16)'); rg.addColorStop(1, 'rgba(160,230,255,0)');
      c.fillStyle = rg; c.beginPath(); c.moveTo(x - 14, 0); c.lineTo(x + 14, 0); c.lineTo(x + 70, H * 0.7); c.lineTo(x - 30, H * 0.7); c.closePath(); c.fill();
    }
    // силуэт на дне
    const sx = W / 2 + Math.sin(t * 0.3) * 10, sy = H - 40;
    c.fillStyle = 'rgba(30,4,18,0.92)';
    c.beginPath(); c.ellipse(sx, sy, 190, 70, 0, Math.PI, TAU); c.fill();
    c.beginPath(); c.moveTo(sx - 170, sy - 10); c.quadraticCurveTo(sx - 230, sy - 120, sx - 150, sy - 160); c.lineTo(sx - 140, sy - 150); c.quadraticCurveTo(sx - 200, sy - 110, sx - 150, sy - 30); c.closePath(); c.fill();
    c.strokeStyle = 'rgba(30,4,18,0.9)'; c.lineWidth = 4;
    c.beginPath(); c.moveTo(sx + 120, sy - 50); c.quadraticCurveTo(sx + 200, sy - 200 + Math.sin(t) * 10, sx + 120, sy - 300); c.moveTo(sx + 100, sy - 54); c.quadraticCurveTo(sx + 160, sy - 180 - Math.sin(t) * 10, sx + 60, sy - 260); c.stroke();
    KT.red = Math.min(1, Math.max(KT.red, (t - 5) / 2)); KT.red = Math.max(0, KT.red - dt * 0.05);
    if (KT.red > 0.02) {
      const bl = Math.sin(t * 1.1) > 0.96 ? 0.15 : 1;
      for (const ex of [sx + 50, sx + 100]) {
        const eg = c.createRadialGradient(ex, sy - 46, 0, ex, sy - 46, 30); eg.addColorStop(0, `rgba(255,40,60,${0.5 * KT.red})`); eg.addColorStop(1, 'rgba(255,40,60,0)');
        c.fillStyle = eg; c.fillRect(ex - 30, sy - 76, 60, 60);
        c.fillStyle = `rgba(255,90,100,${KT.red})`; c.beginPath(); c.ellipse(ex, sy - 46, 11, 4 * bl, -0.2, 0, TAU); c.fill();
      }
    }
    // бормотание со дна
    if (t > 7) { KT.sayT -= dt; if (KT.sayT <= 0) { KT.sayT = rnd(3, 5); KT.say = { text: pick(BOSS_SAY), t: 0 }; } }
    if (KT.say) {
      KT.say.t += dt; const a = Math.min(1, KT.say.t * 3) * Math.max(0, 1 - (KT.say.t - 1.6) * 2);
      if (a <= 0 && KT.say.t > 1.6) KT.say = null;
      else { c.globalAlpha = a; c.fillStyle = 'rgba(0,0,0,0.6)'; roundRect(c, sx - 10, sy - 150, 190, 40, 14); c.fill(); c.font = '900 22px Krilessa Icons, sans-serif'; c.textAlign = 'center'; c.fillStyle = '#ff8aa8'; c.fillText(KT.say.text, sx + 85, sy - 122); c.globalAlpha = 1; }
    }
    // пузыри
    if (Math.random() < 0.25) KT.bubbles.push({ x: rnd(10, W - 10), y: H + 10, r: rnd(2, 6), v: rnd(30, 70) });
    c.strokeStyle = 'rgba(200,240,255,0.6)'; c.lineWidth = 1.5;
    for (const b of KT.bubbles) { b.y -= b.v * dt; b.x += Math.sin(t * 2 + b.r) * 0.3; c.beginPath(); c.arc(b.x, b.y, b.r, 0, TAU); c.stroke(); }
    KT.bubbles = KT.bubbles.filter(b => b.y > -10);
    // стая криля
    const tx = W / 2 + Math.sin(t * 0.55) * 140, ty = H * 0.42 + Math.sin(t * 0.8) * 90;
    for (const k of KT.swarm) {
      const ox = Math.cos(k.ph + t * 0.7) * k.rad, oy = Math.sin(k.ph * 1.7 + t * 0.9) * k.rad * 0.6;
      k.vx += (tx + ox - k.x) * 0.9 * dt; k.vy += (ty + oy - k.y) * 0.9 * dt;
      if (KT.tap) { const dx = k.x - KT.tap.x, dy = k.y - KT.tap.y, d = Math.hypot(dx, dy) || 1; if (d < 140) { k.vx += dx / d * 900 * dt * (1 - d / 140) * 6; k.vy += dy / d * 900 * dt * (1 - d / 140) * 6; } }
      const sp = Math.hypot(k.vx, k.vy), mx = 220; if (sp > mx) { k.vx *= mx / sp; k.vy *= mx / sp; }
      k.vx *= 0.985; k.vy *= 0.985; k.x += k.vx * dt; k.y += k.vy * dt;
      drawKrill(c, k.x, k.y, Math.atan2(k.vy, k.vx), k.s, t + k.ph);
    }
    if (KT.tap) { KT.tap.t -= dt; if (KT.tap.t <= 0) KT.tap = null; }
    for (const pp of KT.pops) { pp.t += dt; c.globalAlpha = Math.max(0, 1 - pp.t); c.font = '900 20px Krilessa Icons, sans-serif'; c.textAlign = 'center'; c.fillStyle = '#ffb0c4'; c.fillText(pp.text, pp.x, pp.y - pp.t * 40); c.globalAlpha = 1; }
    KT.pops = KT.pops.filter(pp => pp.t < 1);
    // виньетка
    const vg = c.createRadialGradient(W / 2, H * 0.45, 140, W / 2, H / 2, 420); vg.addColorStop(0, 'rgba(0,0,0,0)'); vg.addColorStop(1, 'rgba(0,0,0,0.75)');
    c.fillStyle = vg; c.fillRect(0, 0, W, H);
    KT.raf = requestAnimationFrame(krillLoop);
  }
  let krillBack = 'menu';
  let krillNext = null;
  function openKrillTeaser(next) {
    krillNext = typeof next === 'function' ? next : null;
    $('krillBack').textContent = krillNext ? 'Дальше »' : 'Назад';
    krillBack = Session.state === 'krill' ? krillBack : Session.state;
    Screens.setState('krill');
    const box = $('krillLines'); box.innerHTML = '';
    const lines = KRILL_LINES.map(ln => ln === 'Глава 7. Скоро.' ? (krillNext ? 'Глава 7. Крилевая бездна.' : CHAPTERS[7] ? 'Глава 7. Ждёт за зимой.' : ln) : ln);
    lines.forEach((ln, i) => {
      const el = document.createElement('div'); el.className = 'tline' + (i === KRILL_LINES.length - 1 ? ' krilf' : '');
      el.textContent = ln; el.style.animationDelay = (0.6 + i * 1.15) + 's'; box.appendChild(el);
    });
    KT.swarm = [];
    for (let i = 0; i < 70; i++) KT.swarm.push({ x: rnd(80, 400), y: rnd(120, 400), vx: rnd(-40, 40), vy: rnd(-40, 40), ph: rnd(0, TAU), rad: rnd(20, 110), s: rnd(0.8, 1.4) });
    KT.bubbles = []; KT.pops = []; KT.tap = null; KT.red = 0; KT.say = null; KT.sayT = 2;
    KT.t0 = performance.now(); KT.last = 0; cancelAnimationFrame(KT.raf); KT.raf = requestAnimationFrame(krillLoop);
    Sound.music(null); Sound.sfx.whisper();
    setTimeout(() => { if (Session.state === 'krill') { Sound.sfx.roar(); KT.red = 1; KT.say = { text: 'КРИЛЯТЬ!!!', t: 0 }; } }, (0.6 + (KRILL_LINES.length - 1) * 1.15) * 1000);
  }
  function closeKrill() { cancelAnimationFrame(KT.raf); if (krillNext) { const nx = krillNext; krillNext = null; nx(); } else if (krillBack === 'menu') AdventureMenu.openMenu(); else Screens.setState(krillBack); }

  // ------------------------------------------------------------------
  //  Финальная сцена
  // ------------------------------------------------------------------
  function startVictoryCutscene() {
    if (NET.host) NetT.send(-1, { t: 'vic' }); // победа – у всех сразу
    if (NET.on && G.netRun) Achievements.life('coop'); Challenges.mutReward(); // мутаторы вместе – звёзды получает каждая
    if (G.daily) { Challenges.dailyAdd(1000); Challenges.dailyFinish(false); }
    try { Achievements.gloryWin(); } catch (e) { /* ignore */ }
    if (!G.daily) Achievements.life('spts', 30); // глава пройдена – искры сезона
    RunStats.recordRunEnd('глава пройдена');
    G.cutscene = { t: 0 };
    G.enemies.forEach(e => Effects.burst(e.x, e.y, 8, '#fff', 100));
    G.enemies.length = 0; G.ebullets.length = 0; G.hazards.length = 0; G.beams.length = 0;
    Screens.showBanner('ПОБЕДА!', Session.bosses[Session.bosses.length - 1].name + ' повержен');
    Sound.music('win');
    const prof = Saves.loadProfile();
    const build = { level: P.level, up: P.up, bonus: P.bonus, shards: P.shards };
    prof['ch' + World.CHN + 'Done'] = true;
    prof[World.CHN === 1 ? 'carry' : 'carry' + World.CHN] = build;
    Saves.saveProfile(prof);
    if (!NET.on) GameStorage.remove(Saves.saveKey(World.CHN));
  }
  function updateCutscene(dt) {
    const cs = G.cutscene; cs.t += dt;
    if (cs.kind === 'teamup') { updateTeamUp(dt, cs); return; }
    if (World.CFG.noCage) {
      P.moving = false; P.t += dt;
      if (Math.random() < 0.3) Effects.part(P.x + rnd(-60, 60), P.y + rnd(-70, 10), 0, -40, 1.4, 6, World.CHN === 4 ? '#3ff0a0' : '#ffd25a');
      if (cs.t > 3.5 && !G.victoryShown) { G.victoryShown = true; if (World.CHN === 4) { if (NET.client) { RunStats.toast('💭 Хозяйка выбирает концовку…'); if (NET.c4) HouseChapter.finishCh4(NET.c4); } else HouseChapter.openChoice(); } else if (World.CHN === 7) Intro.start('end7', () => Screens.showVictory()); else Screens.showVictory(); }
      return;
    }
    const cx = World.tc(World.CAGE.x), cy = World.tc(World.CAGE.y);
    const dx = cx - 80 - P.x, dy = cy + 30 - P.y, d = Math.hypot(dx, dy);
    if (cs.t > 4 && d > 4) { const s = Math.min(d, 220 * dt); P.x += dx / d * s; P.y += dy / d * s; P.moving = true; P.face = dx > 0 ? 1 : -1; }
    else { P.moving = false; if (cs.t > 4) P.face = 1; }
    P.t += dt;
    if (cs.t > 5.5 && G.cageOpen < 1) {
      G.cageOpen = Math.min(1, G.cageOpen + dt / 1.5);
      if (Math.random() < 0.5) Effects.part(cx + rnd(-30, 30), cy + rnd(-40, 20), rnd(-30, 30), rnd(-90, -30), 1, 4, pick(['#ffd25a', '#ff7a2f', '#ff9db5']));
      if (G.cageOpen >= 1) { Screens.say(['', 'Спасибо, Крилесса! Ты меня спасла! ❤', 'Крилесса, ты лучшая! Больше никаких кринж-стихов! ❤', 'Рыжовая, ты меня спасла! Теперь мы квиты! ❤🔥'][World.CHN], 5); Sound.sfx.win(); }
    }
    if (G.cageOpen >= 1 && Math.random() < 0.3) Effects.part(cx + rnd(-60, 60), cy + rnd(-60, 20), 0, -40, 1.4, 6, '#ff5b8a');
    if (cs.t > 11 && !G.victoryShown) { G.victoryShown = true; Screens.showVictory(); }
  }

  return {
    later, startTrick, zmReact, startFinalFinal, updateFinalFinal, openWhatsNew, closeWhatsNew,
    openTeaser, closeTeaser, KRILL_SAY, KT, drawKrill, openKrillTeaser, closeKrill,
    startVictoryCutscene, updateCutscene,
    get trickTimers() { return trickTimers; },
    set trickTimers(value) { trickTimers = value; },
    get teaserGlow() { return teaserGlow; },
    set teaserGlow(value) { teaserGlow = value; },
  };
})();
