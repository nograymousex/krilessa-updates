'use strict';

const StarAtlas = (() => {
  // Точки в координатах небесного диска. Три опорные звезды загораются по мере прохождения тропы.
  const signs = [
    { title: 'Серебряное крыло', lore: 'Если сложить три лесных огонька, получится крыло Крилессы. На старых картах им отмечали дорогу домой.',
      points: [[-72,39],[-45,-2],[28,-42],[77,-48],[52,-13],[22,8],[44,3],[19,28],[-18,40],[-1,34],[-38,49]], strokes: [[0,1,2,3,4,5,6,7,8,9,10,0],[1,4],[0,5]], anchors: [0,3,7] },
    { title: 'Корона Зямы', lore: 'Зяма настаивает, что его корона первой появилась на небе. Звёзды от комментариев воздерживаются.',
      points: [[-70,-24],[-37,-4],[-5,-48],[29,-3],[68,-25],[47,34],[-49,34],[-38,18],[37,18]], strokes: [[0,1,2,3,4,5,6,0],[7,8]], anchors: [0,2,4] },
    { title: 'За зеркалом', lore: 'В Зямоверсе даже звёзды смотрят на своё отражение. Рыжовая узнала настоящее небо по одной лишней искре.',
      points: [[-28,-47],[28,-56],[54,-23],[31,17],[-22,27],[-49,-4],[-28,-47],[-6,26],[-29,54],[-40,49],[-18,25],[26,-36],[4,-6],[19,-9],[-4,10]], strokes: [[0,1,2,3,4,5,6],[7,8,9,10],[11,12,13,14]], anchors: [0,2,8] },
    { title: 'Ночная кошка', lore: 'Тесса уверена, что тёмное пятно на Луне — не кратер. Это место, где небесная кошка свернулась клубком.',
      points: [[-62,14],[-53,-42],[-22,-24],[17,-26],[46,-48],[61,-1],[45,27],[0,48],[-41,32],[-62,14],[-18,3],[18,0],[1,17]], strokes: [[0,1,2,3,4,5,6,7,8,9],[10,12,11]], anchors: [1,4,7] },
    { title: 'Фонарь сыщика', lore: 'Когда в доме пропадает корм, Тесса зажигает фонарь. С этой высоты прекрасно видно, кто второй раз подошёл к миске.',
      points: [[-40,-22],[0,-40],[40,-22],[29,34],[0,46],[-29,34],[-40,-22],[40,-22],[-14,-32],[-14,-48],[0,-57],[14,-48],[14,-33],[0,-9],[9,10],[0,22],[-9,10]], strokes: [[0,1,2,3,4,5,6,7],[8,9,10,11,12],[13,14,15,16,13]], anchors: [10,3,5] },
    { title: 'Полярная лиса', lore: 'В метель её хвост похож на северное сияние. Лиса обходит тонкий лёд, даже если спешит к костру.',
      points: [[-75,-9],[-47,-43],[-36,-22],[-13,-36],[-4,-5],[24,-2],[65,-32],[73,-4],[43,27],[9,37],[-23,27],[-44,41],[-31,13],[-54,6],[-75,-9]], strokes: [[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14],[5,8]], anchors: [1,6,11] },
    { title: 'Золотой криль', lore: 'В самой глубокой воде криль увидел звезду и пошёл за ней. Так у океана появилась собственная комета.',
      points: [[-71,-31],[-28,-13],[-42,-39],[-9,-20],[22,-16],[46,2],[47,27],[23,43],[-12,38],[-36,23],[-70,36],[-52,12],[-73,8],[-36,23],[-17,17],[6,21],[21,13],[22,-16]], strokes: [[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17],[6,16]], anchors: [1,5,10] },
  ];
  let chapter = 1;

  function drawSign(c, sign, progress) {
    const lit = progress === 3;
    c.lineCap = 'round';
    c.lineJoin = 'round';
    c.lineWidth = 1.45;
    c.strokeStyle = lit ? '#e4bf7d' : '#8798b9';
    for (const stroke of sign.strokes) {
      c.beginPath();
      for (let i = 0; i < stroke.length; i++) {
        const [x, y] = sign.points[stroke[i]];
        if (i === 0) c.moveTo(x, y);
        else c.lineTo(x, y);
      }
      c.stroke();
    }
    for (const [x, y] of sign.points) {
      c.beginPath(); c.arc(x, y, 1.75, 0, TAU);
      c.fillStyle = lit ? '#fff0bd' : '#b9c4d8'; c.fill();
    }
    sign.anchors.forEach((point, i) => {
      const [x, y] = sign.points[point];
      c.fillStyle = i < progress ? '#ffe4a1' : '#bbc9e5';
      c.beginPath();
      c.moveTo(x, y - 5.9); c.quadraticCurveTo(x + 1, y - 1, x + 4.7, y);
      c.quadraticCurveTo(x + 1, y + 1, x, y + 5.9);
      c.quadraticCurveTo(x - 1, y + 1, x - 4.7, y);
      c.quadraticCurveTo(x - 1, y - 1, x, y - 5.9); c.fill();
      if (i < progress) {
        c.strokeStyle = 'rgba(255,221,149,.4)'; c.lineWidth = 0.75;
        c.beginPath(); c.arc(x, y, 9, 0, TAU); c.stroke();
      }
    });
  }

  function drawChart(sign, progress) {
    const canvas = $('atlasChart'), c = canvas.getContext('2d');
    const w = canvas.width, h = canvas.height;
    c.clearRect(0, 0, w, h);
    c.save();
    c.translate(w / 2, h / 2);
    c.scale(w / 300, h / 204);
    const sky = c.createRadialGradient(0, 0, 2, 0, 0, 110);
    sky.addColorStop(0, progress === 3 ? '#243947' : '#202944');
    sky.addColorStop(1, 'rgba(14,22,41,0)');
    c.fillStyle = sky; c.fillRect(-150, -102, 300, 204);
    c.lineWidth = 0.6; c.strokeStyle = 'rgba(149,181,194,.27)';
    for (const r of [48, 78, 88]) { c.beginPath(); c.arc(0, 0, r, 0, TAU); c.stroke(); }
    for (let i = 0; i < 72; i++) {
      const a = TAU * i / 72, r = i % 6 === 0 ? 81 : 85;
      c.beginPath(); c.moveTo(r * Math.cos(a), r * Math.sin(a));
      c.lineTo(88 * Math.cos(a), 88 * Math.sin(a)); c.stroke();
    }
    c.strokeStyle = 'rgba(123,164,181,.15)';
    c.beginPath(); c.ellipse(0, 0, 120, 49, -0.39, 0, TAU); c.stroke();
    c.beginPath(); c.moveTo(-146, 0); c.lineTo(146, 0); c.moveTo(0, -100); c.lineTo(0, 100); c.stroke();
    const random = mulberry32(1010 + chapter);
    for (let i = 0; i < 100; i++) {
      const x = random() * 296 - 148, y = random() * 200 - 100;
      c.globalAlpha = 0.14 + random() * 0.5;
      c.beginPath(); c.arc(x, y, 0.25 + random() * 0.65, 0, TAU); c.fillStyle = '#d3ecf2'; c.fill();
    }
    c.globalAlpha = 1;
    c.fillStyle = '#baac8b'; c.font = '6px Krilessa Icons, serif'; c.textAlign = 'center';
    c.fillText('С', 0, -92); c.fillText('Ю', 0, 97);
    c.fillText('З', -96, 2); c.fillText('В', 96, 2);
    drawSign(c, sign, progress);
    c.restore();
  }

  function render() {
    const profile = Saves.loadProfile(), found = profile.atlas || {};
    const {count, healthPercent, damagePercent} = StarTrail.bonuses(profile);
    const discovered = found[chapter] === true, sign = signs[chapter - 1];
    const canPlay = Chapters.chapterOpen(chapter);
    const save = Saves.loadSave(chapter), step = save && save.starTrail && save.starTrail.collected;
    const progress = discovered ? 3 : Number.isInteger(step) ? clamp(step, 0, 2) : 0;
    $('atlasCount').textContent = count + ' / ' + signs.length;
    $('atlasHealth').textContent = '+' + healthPercent + '%';
    $('atlasDamage').textContent = '+' + damagePercent + '%';
    $('atlasNext').textContent = count === signs.length ? 'Открыты все семь созвездий.' :
      'Следующее созвездие доведёт бонусы до +' + (healthPercent + StarTrail.HEALTH_PERCENT_PER_SIGN) +
      '% к здоровью и +' + (damagePercent + StarTrail.DAMAGE_PERCENT_PER_SIGN) + '% к урону.';
    $('atlasChapter').textContent = 'Глава ' + chapter + (canPlay || discovered ? ' · ' + CHAPTERS[chapter].name : '');
    $('atlasTitle').textContent = sign.title;
    $('atlasStory').textContent = discovered ? sign.lore : 'Пройди по звёздной тропе и собери три звезды по порядку, чтобы открыть созвездие.';
    $('atlasHeal').textContent = 'Третья звезда восполняет до ' + StarTrail.HEAL_PERCENT + '% максимального здоровья даже при повторном прохождении.';
    $('atlasStatus').textContent = discovered ? 'Созвездие открыто' : 'Найдено звёзд: ' + progress + ' из 3';
    $('atlasTravel').disabled = !canPlay;
    $('atlasTravel').textContent = canPlay ? 'К главе ' + chapter + '  →' : 'Откроется после главы ' + (chapter - 1);
    $('starAtlas').classList.toggle('is-found', discovered);
    drawChart(sign, progress);
    for (const button of $('atlasChapters').children) {
      const n = Number(button.dataset.chapter);
      button.setAttribute('aria-pressed', String(n === chapter));
      button.classList.toggle('is-found', found[n] === true);
      button.setAttribute('aria-label', 'Глава ' + n + ', ' + signs[n - 1].title + (found[n] === true ? ', открыто' : ', предстоит найти'));
    }
  }

  function open() {
    const profile = Saves.loadProfile();
    chapter = Session.CH_NUMS.includes(profile.lastCh) ? profile.lastCh : 1;
    if (!$('atlasChapters').childElementCount) {
      signs.forEach((sign, i) => {
        const button = document.createElement('button');
        button.type = 'button'; button.dataset.chapter = String(i + 1);
        const glyph = makeCanvas(120, 76), ink = glyph.getContext('2d');
        glyph.setAttribute('aria-hidden', 'true');
        ink.translate(60, 38); ink.scale(0.65, 0.65); drawSign(ink, sign, 0);
        const label = document.createElement('span'); label.textContent = 'Гл. ' + (i + 1);
        button.appendChild(glyph); button.appendChild(label);
        button.addEventListener('click', () => { chapter = i + 1; Sound.sfx.click(); render(); });
        $('atlasChapters').appendChild(button);
      });
    }
    Screens.setState('starAtlas');
    $('starAtlas').scrollTop = 0;
    render();
  }

  return { open, travel() { AdventureMenu.openChapterSheet(chapter); } };
})();
