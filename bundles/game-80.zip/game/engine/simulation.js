'use strict';

const Simulation = (() => {
  // ------------------------------------------------------------------
  //  Мир: спавн, снаряды, опасности, подбор
  // ------------------------------------------------------------------
  function spawnEnemies(dt) {
    G.spawnT -= dt;
    if (G.spawnT > 0) return;
    G.spawnT = World.CFG.spawnEvery * 0.8 * (G.ev && G.ev.def.id === 'horde' ? 0.35 : 1);
    if (G.activeShrine || World.CFG.rush || World.CFG.abyss || G.finalFinal) return;
    // вместе: мобы появляются то у одной, то у другой героини
    let A = P;
    if (NET.host && NET.peers.size) { const L = [P].concat([...NET.peers.values()].filter(m => m.live && !m.down)).filter(q => !q.down); A = L[Math.floor(Math.random() * L.length)] || P; }
    const ptx = Math.floor(A.x / World.T), pty = Math.floor(A.y / World.T);
    if (Math.hypot(ptx - World.START.x, pty - World.START.y) < 7) return;
    const pb = World.biomeMap[clamp(pty, 0, World.MH - 1) * World.MW + clamp(ptx, 0, World.MW - 1)];
    const zi = Math.max(0, Object.keys(World.CFG.zoneLevel).indexOf(String(pb)));
    let cap = World.CFG.capBase * 1.3 + zi * 2 + Math.min(8, Math.max(0, P.level - Actors.zoneE(pb)) * 0.3);
    if (World.CHN !== 1) cap *= clamp(0.5 + P.level * 0.035, 0.5, 1); // глава начинается с 1 уровня – толпа нарастает постепенно
    if (G.activeBoss) return;
    if (G.ev && G.ev.def.id === 'horde') cap *= 1.8;
    cap *= Multiplayer.netXpDiv(); // вместе мобов больше (опыт с них – во столько же раз меньше)
    if (G.enemies.length >= cap) return;
    const vw = Viewport.VW / Viewport.ZOOM, vh = Viewport.VH / Viewport.ZOOM;
    const inCastle = Math.abs(ptx - World.CASTLE.x) < World.CASTLE.half && Math.abs(pty - World.CASTLE.y) < World.CASTLE.half;
    for (let k = 0; k < 8; k++) {
      const R = inCastle ? rnd(240, 420) : Math.hypot(vw, vh) / 2 + 50;
      const a = rnd(0, TAU), x = A.x + Math.cos(a) * R, y = A.y + Math.sin(a) * R;
      const tx = Math.floor(x / World.T), ty = Math.floor(y / World.T);
      if (!World.inMap(tx, ty) || ty >= World.PLAY_H) continue; // ниже карты – пустота и арена
      if (inCastle && World.tiles[ty * World.MW + tx] !== FLOOR) continue;
      const biome = inCastle ? World.CASTLE.biome : World.biomeMap[ty * World.MW + tx];
      if (!SPAWNS[biome]) continue;
      const type = weighted(SPAWNS[biome]);
      if (!Physics.walkable(x, y, ENEMIES[type].fly)) continue;
      if (Session.bosses.some(b => b.state === 'sleep' && Math.hypot(x - b.hx, y - b.hy) < 300)) continue;
      const elite = Math.random() < World.CFG.elite * G.diff.elite * (0.35 + 0.65 * Actors.chDiff(Actors.zoneE(biome)).k) * (Challenges.mutOn('elite') ? 3 : 1); // элита в начале главы реже
      Enemies.spawnEnemy(type, x, y, biome, { elite, instant: !inCastle });
      const grp = ENEMIES[type].group;
      if (grp) { const n = grp[0] + Math.floor(Math.random() * (grp[1] - grp[0] + 1)) - 1; for (let i = 0; i < n; i++) Enemies.spawnEnemy(type, x + rnd(-30, 30), y + rnd(-30, 30), biome, { instant: !inCastle }); }
      return;
    }
  }
  function updateProjectiles(dt) {
    for (const f of G.feathers) {
      f.x += f.vx * dt; f.y += f.vy * dt; f.life -= dt;
      if (World.blocksShots(f.x, f.y)) { f.life = 0; Effects.burst(f.x, f.y, 3, '#fff', 60); if (!Expedition.tryCrack(f) && World.CFG.slippery) Expedition.tryMelt(f); continue; }
      if (World.drifts.length && !f.ally && Expedition.hitDrift(f)) continue;
      for (const e of G.enemies) {
        if (e.dead || e.spawnT > 0 || f.hit.includes(e)) continue;
        if ((e.x - f.x) ** 2 + (e.y - f.y) ** 2 < (e.r + 5) ** 2) {
          f.hit.push(e);
          if (e.def.ai === 'shield' && Math.abs(angDiff(e.shieldAng, Math.atan2(f.y - e.y, f.x - e.x))) < 1.05) {
            f.life = 0; Effects.burst(f.x, f.y, 6, '#bfefff', 120); if (Math.random() < 0.3) Effects.floatText(e.x, e.y - e.r - 8, 'блок', '#bfefff'); Sound.sfx.block(); break;
          }
          Enemies.damageEnemy(e, Actors.rollHit(f.dmg), f.vx * 0.25, f.vy * 0.25, true);
          Hero.onProjHit(f, e);
          if (f.pierce-- <= 0) { f.life = 0; break; }
        }
      }
      const b = G.activeBoss;
      if (f.life > 0 && b && !f.hit.includes(b) && (b.x - f.x) ** 2 + (b.y - b.z - f.y) ** 2 < (b.r + 5) ** 2) {
        f.hit.push(b);
        if (Bosses.damageBoss(b, Actors.rollHit(f.dmg))) { Sound.sfx.hit(); Effects.burst(f.x, f.y, 4, '#ffd25a', 90); Hero.onProjHit(f, b); }
        else if (b.def.immortal && G.finalFinal && !f.ally) { G.finalFinal.bank = Math.min(0.5, G.finalFinal.bank + 0.1); Effects.burst(f.x, f.y, 3, '#ff8ad8', 70); }
        if (f.pierce-- <= 0) f.life = 0;
      }
    }
    G.feathers = G.feathers.filter(f => f.life > 0);
    for (const b of G.ebullets) {
      if (b.homing) {
        const Q = NET.host ? Multiplayer.netAim(b.x, b.y) : P, want = Math.atan2(Q.y - b.y, Q.x - b.x), cur = Math.atan2(b.vy, b.vx);
        const na = cur + clamp(angDiff(cur, want), -b.homing * dt, b.homing * dt);
        b.vx = Math.cos(na) * b.spd; b.vy = Math.sin(na) * b.spd;
      }
      if (b.bounce) {
        const nx = b.x + b.vx * dt, ny = b.y + b.vy * dt;
        if (World.blocksShots(nx, b.y) || Math.abs(nx - b.hx) > 430) b.vx = -b.vx;
        if (World.blocksShots(b.x, ny) || Math.abs(ny - b.hy) > 430) b.vy = -b.vy;
        b.rot += dt * 12;
      }
      if (b.missile && Math.random() < 0.4) Effects.part(b.x, b.y, rnd(-10, 10), rnd(-10, 10), 0.5, 4, 'rgba(160,160,160,0.6)');
      b.x += b.vx * dt; b.y += b.vy * dt; b.life -= dt;
      if (!b.bounce && World.blocksShots(b.x, b.y)) { b.life = 0; Bosses.shotPuff(b, 3); continue; }
      if (b.life <= 0) { Bosses.shotPuff(b, 4); if (NET.client) NET.goneB.add(b.nid); continue; } // выдохся – рассеялся облачком
      if (!P.down && b.life > Enemies.SHOT_FADE * 0.4 && (P.x - b.x) ** 2 + (P.y - 6 - b.y) ** 2 < (b.r + P.r - 3) ** 2) { // почти растаявший уже не ранит
        if (P.inv <= 0 && P.dashT <= 0) { Hero.hurtPlayer(b.dmg); if (b.slow) P.slowT = 1.6; b.life = 0; if (NET.client) { NET.bcons.push(b.nid); NET.goneB.add(b.nid); } }
      }
    }
    G.ebullets = G.ebullets.filter(b => b.life > 0);
    // лазеры
    for (const bm of G.beams) {
      bm.t += dt;
      if (bm.b.state !== 'fight' || bm.b.mode === 'trans') { bm.t = 1e9; continue; }
      const o = bm.mouth ? bossMouth(bm.b) : { x: bm.b.x, y: bm.b.y - bm.b.z };
      bm.x = o.x; bm.y = o.y;
      if (bm.t > bm.warm) {
        bm.ang += bm.rot * dt;
        const ca = Math.cos(bm.ang), sa = Math.sin(bm.ang);
        let len = 0;
        for (len = 0; len < 560; len += 20) if (World.blocksShots(bm.x + ca * len, bm.y + sa * len)) break;
        bm.len = len;
        const dx = P.x - bm.x, dy = P.y - bm.y;
        const along = dx * ca + dy * sa, perp = Math.abs(-dx * sa + dy * ca);
        if (along > 0 && along < bm.len && perp < bm.w / 2 + P.r * 0.4) Hero.hurtPlayer(bm.dmg);
      }
    }
    G.beams = G.beams.filter(bm => bm.t < bm.warm + bm.dur);
  }
  function updatePlayerFx(dt) {
    for (const z of G.pzones) {
      z.t += dt; z.tick -= dt;
      if (Math.random() < 0.4) Effects.part(z.x + rnd(-z.r, z.r) * 0.6, z.y + rnd(-z.r, z.r) * 0.6, 0, -50, 0.5, 4, pick(['#ff8a2a', '#ffd23a', '#ff4a1a']));
      if (z.tick <= 0) {
        z.tick = 0.35;
        for (const e of G.enemies) if (!e.dead && e.spawnT <= 0 && (e.x - z.x) ** 2 + (e.y - z.y) ** 2 < (z.r + e.r) ** 2) Enemies.damageEnemy(e, { v: z.dmg, crit: false }, 0, 0, false);
        const b = G.activeBoss;
        if (b && (b.x - z.x) ** 2 + (b.y - z.y) ** 2 < (z.r + b.r) ** 2) Bosses.damageBoss(b, { v: z.dmg, crit: false }, true);
      }
    }
    G.pzones = G.pzones.filter(z => z.t < z.dur);
    for (const n of G.novas) {
      n.r += (n.disco ? 520 : 900) * dt;
      for (const e of G.enemies) {
        if (e.dead || e.spawnT > 0 || n.hit.has(e)) continue;
        const d = Math.hypot(e.x - n.x, e.y - n.y);
        if (Math.abs(d - n.r) < 36 + e.r) {
          n.hit.add(e);
          if (n.k) Enemies.damageEnemy(e, Actors.rollHit(P.dmg * n.k), (e.x - n.x) / d * 160, (e.y - n.y) / d * 160, false);
          else if (n.purr) { Enemies.damageEnemy(e, Actors.rollHit(P.dmg * 4), (e.x - n.x) / d * 260, (e.y - n.y) / d * 260, false); e.slowT = Math.max(e.slowT || 0, 2.5); }
          else { Enemies.damageEnemy(e, Actors.rollHit(P.dmg * 6), (e.x - n.x) / d * 300, (e.y - n.y) / d * 300, false); e.burnT = 3; e.burnDps = P.dmg * 0.6; }
        }
      }
      const b = G.activeBoss;
      if (b && !n.hit.has(b) && Math.abs(Math.hypot(b.x - n.x, b.y - n.y) - n.r) < 40 + b.r) {
        n.hit.add(b);
        if (n.k) Bosses.damageBoss(b, Actors.rollHit(P.dmg * n.k * 1.5));
        else if (n.purr) { Bosses.damageBoss(b, Actors.rollHit(P.dmg * 9)); if (!b.def.immortal) b.stunT = Math.max(b.stunT, 1.2); }
        else { Bosses.damageBoss(b, Actors.rollHit(P.dmg * 12)); b.burnT = 3; b.burnDps = P.dmg * 0.6; }
      }
      if (!n.disco) for (const bl of G.ebullets) if ((bl.x - n.x) ** 2 + (bl.y - n.y) ** 2 < n.r * n.r) bl.life = 0;
    }
    G.novas = G.novas.filter(n => n.r < n.max);
  }
  const WAVE_GAP = 0.32; // половина прохода в кольце, рад (~37° на проход)
  const inWaveGap = (h, a) => !h.gaps || h.gaps.some(g => Math.abs(angDiff(a, g)) < h.half); // angDiff из util.js – со знаком
  function updateHazards(dt) {
    for (const h of G.hazards) {
      h.t += dt;
      if (h.cancel) { h.t = 1e9; h.r = 1e9; continue; }
      if (h.kind === 'wavewarn') continue;
      if (h.kind === 'wave') {
        h.r += h.spd * dt;
        const d = Math.hypot(P.x - h.x, P.y - h.y);
        if (!h.hit && Math.abs(d - h.r) < h.thick / 2 + P.r * 0.4 && P.inv <= 0 && P.dashT <= 0 && !inWaveGap(h, Math.atan2(P.y - h.y, P.x - h.x))) { Hero.hurtPlayer(h.dmg); h.hit = true; }
        continue;
      }
      if (h.kind === 'zone') {
        if (h.t > h.delay && Math.hypot(P.x - h.x, P.y - h.y) < h.r) {
          if (h.slow) P.slowT = Math.max(P.slowT, 0.25);
          if (h.dot) { h.tick = (h.tick || 0) - dt; if (h.tick <= 0) { h.tick = 0.5; Hero.hurtPlayer(h.dot); } }
        }
        continue;
      }
      if (!h.done && h.t >= h.delay) {
        h.done = true;
        let hit = false;
        if (h.kind === 'circle') hit = Math.hypot(P.x - h.x, P.y - h.y) < h.r + P.r * 0.5;
        else {
          const dx = P.x - h.x, dy = P.y - h.y, ca = Math.cos(h.ang), sa = Math.sin(h.ang);
          const along = dx * ca + dy * sa, perp = Math.abs(-dx * sa + dy * ca);
          hit = along > -10 && along < h.len && perp < h.w / 2 + P.r * 0.5;
        }
        if (hit && h.dmg && !P.down) Hero.hurtPlayer(h.dmg);
        if (h.fx === 'stomp') { Effects.burst(h.x, h.y, 26, '#c9a46b', 260); G.shake = Math.max(G.shake, 9); Sound.sfx.boom(); }
        else if (h.fx === 'meteor') {
          Effects.burst(h.x, h.y, 26, h.star ? '#9fb4ff' : '#ff8a2a', 260); Effects.burst(h.x, h.y, 10, '#ffd23a', 160); G.shake = Math.max(G.shake, 6); Sound.sfx.meteor();
          if (!NET.client && !h.td) { // звездопад обороны бьёт сам – по своим правилам
            if (h.star && Physics.walkable(h.x, h.y, false)) Effects.dropShard(h.x, h.y);
            for (const e of G.enemies) if (!e.dead && e.spawnT <= 0 && (e.x - h.x) ** 2 + (e.y - h.y) ** 2 < (h.r + e.r) ** 2) Enemies.damageEnemy(e, { v: P.dmg * 4, crit: false }, 0, 0, false);
          }
        }
        else if (h.fx === 'icicle') { Effects.burst(h.x, h.y, 14, '#bfefff', 200); Sound.sfx.hit(); }
        else if (h.fx === 'dark') Effects.burst(h.x, h.y, 16, '#c77dff', 200);
        else if (h.fx === 'crystal') Effects.burst(h.x, h.y, 16, '#5be3ff', 200);
        else if (h.fx === 'rain') Effects.burst(h.x, h.y, 12, '#ffffff', 160);
        else if (h.fx === 'boom') { Effects.burst(h.x, h.y, 30, '#ff8a2a', 280); G.shake = Math.max(G.shake, 8); }
        else if (h.fx === 'bolt') { G.bolts.push({ pts: [[h.x + rnd(-30, 30), h.y - 340], [h.x, h.y]], t: 0.3, col: '255,240,120' }); Effects.burst(h.x, h.y, 14, '#fff04a', 200); Sound.sfx.bolt(); }
        else if (h.fx === 'glitch') { Effects.burst(h.x, h.y, 18, '#3ff0a0', 220); Effects.burst(h.x, h.y, 10, '#ff3ea5', 180); }
        else if (h.fx === 'erupt') {
          Effects.burst(h.x, h.y, 22, '#ff6a22', 260);
          if (!NET.client) G.hazards.push({ kind: 'zone', x: h.x, y: h.y, r: 46, t: 0, delay: 0, dur: 2.6, dot: h.dmg * 0.25, fx: 'lava' });
        }
      }
    }
    G.hazards = G.hazards.filter(h => {
      if (h.kind === 'wave') return h.r < h.max;
      if (h.kind === 'zone') return h.t < h.delay + h.dur;
      return h.t < h.delay + 0.3;
    });
  }
  function updatePickups(dt) {
    for (const p of G.pickups) {
      p.t += dt;
      // вместе: подбирашка летит к ближайшей героине
      let Q = P;
      if (NET.host && NET.peers.size) { let bd = P.down ? 1e18 : (P.x - p.x) ** 2 + (P.y - p.y) ** 2; for (const m of NET.peers.values()) { if (!m.live || m.down || m.away) continue; const d2 = (m.x - p.x) ** 2 + (m.y - p.y) ** 2; if (d2 < bd) { bd = d2; Q = m; } } if (Q === P && P.down) continue; }
      const dx = Q.x - p.x, dy = Q.y - p.y, d = Math.hypot(dx, dy) || 1, mag = Q === P ? P.magnet : (Q.mag || 110);
      if (d < mag || p.pull || (G.td && p.kind === 'xp' && p.t > 0.7)) { // в обороне опыт сам летит к героине через всё поле
        p.pull = true;
        const s = 260 + p.t * 120;
        p.x += (dx / d) * Math.min(d, s * dt); p.y += (dy / d) * Math.min(d, s * dt);
      }
      if (Q !== P && d < (Q.r || 13) + 8) { // подобрала подруга
        p.got = true;
        if (p.kind === 'xp') { Hero.gainXp(p.v); Multiplayer.netEvent(Q.id, ['gem']); }
        else if (p.kind === 'heart') Multiplayer.netEvent(Q.id, ['hl']);
        else if (p.kind === 'star') Multiplayer.netEvent(Q.id, ['sp', 10]);
        else if (p.kind === 'key') { G.keys = (G.keys || 0) + 1; Multiplayer.netEvent(Q.id, ['key']); Effects.floatText(P.x, P.y - 34, '🔑 +1 (общий)', '#ffd25a'); }
        else if (p.kind === 'magnet') { for (const q of G.pickups) if (q.kind !== 'heart') q.pull = true; }
        else if (p.kind === 'shard') Multiplayer.netEvent(Q.id, ['sh', p.sid]);
        continue;
      }
      if (Q === P && d < P.r + 8) {
        p.got = true;
        if (p.kind === 'xp') { Hero.gainXp(p.v); Sound.sfx.gem(); }
        else if (p.kind === 'heart') { const h = Math.round(P.maxHp * 0.25 * (Encounters.hasRelic('heartstone') ? 1.25 + 0.25 * Encounters.relicLv('heartstone') : 1) * Math.pow(1 + 0.2, Actors.lv('c5snack'))), gain = Math.max(0, Math.min(h, P.maxHp - P.hp)); if (G.st) { G.st.hearts = (G.st.hearts || 0) + 1; G.st.healed = (G.st.healed || 0) + (isFinite(gain) ? gain : 0); if (G.st.cur) G.st.cur.h = (G.st.cur.h || 0) + 1; } P.hp = Math.min(P.maxHp, P.hp + h); Effects.floatText(P.x, P.y - 34, '+' + h, '#7dff7d'); Sound.sfx.heart(); }
        else if (p.kind === 'star') { Hero.addSuper(10); Effects.floatText(P.x, P.y - 34, '⭐ +10% супера', '#ffe08a'); Sound.sfx.shard(); }
        else if (p.kind === 'key') { G.keys = (G.keys || 0) + 1; Effects.floatText(P.x, P.y - 34, '🔑 +1', '#ffd25a', true); Sound.sfx.clue(); }
        else if (p.kind === 'magnet') { for (const q of G.pickups) if (q.kind !== 'heart') q.pull = true; Sound.sfx.heart(); }
        else if (p.kind === 'shard') {
          const s = SHARDS[p.sid];
          const pb = World.biomeMap[clamp(Math.floor(P.y / World.T), 0, World.MH - 1) * World.MW + clamp(Math.floor(P.x / World.T), 0, World.MW - 1)];
          const val = s.id === 'hp' ? Math.max(3, Math.round(refEHP(Actors.zoneE(pb)) * 0.012)) : s.val;
          P.bonus[s.id] = (P.bonus[s.id] || 0) + val; P.shards++;
          Actors.computeStats();
          if (s.id === 'hp') P.hp = Math.min(P.maxHp, P.hp + val);
          Effects.floatText(P.x + rnd(-10, 10), P.y - 40, s.txt(val), s.col);
          if (G.st) G.st.shards++;
          Sound.sfx.shard();
        }
      }
    }
    G.pickups = G.pickups.filter(p => !p.got);
    for (const c of World.chests) {
      if (c.open) continue;
      const dd = Math.hypot(P.x - c.x, P.y - c.y);
      if (dd < 320) c.seen = true; // спрятанные сундуки появляются на карте, только когда их увидишь
      if (dd < 34 && !P.down) Encounters.openChest(c);
      else if (NET.host) for (const m of NET.peers.values()) if (m.live && !m.down && Math.hypot(m.x - c.x, m.y - c.y) < 34) { Encounters.openChest(c, m); break; }
    }
  }
  function updateShrines() {
    for (const s of World.shrines) {
      if (s.state === 'done') continue;
      const d = Math.hypot(P.x - s.x, P.y - s.y);
      if (s.state === 'idle') {
        if (G.activeBoss || G.activeShrine || G.jump || !World.ARENA) continue;
        let on = d < 36 && !P.down;
        if (!on && NET.host) for (const m of NET.peers.values()) if (m.live && !m.down && Math.hypot(m.x - s.x, m.y - s.y) < 36) { on = true; break; } // встала подруга
        if (on) Encounters.enterTrial(s);
      } else if (s.state === 'active') {
        G.trialT = (G.trialT || 0) + 1 / 60;
        // хозяйка без сил, а на арене никого, кто поднимет, – испытание проиграно, все возвращаются
        let helper = false; if (P.down && NET.host) for (const m of NET.peers.values()) if (m.live && !m.down && m.y > World.PLAY_H * World.T) { helper = true; break; }
        G.trialDownT = P.down && !helper ? (G.trialDownT || 0) + 1 / 60 : 0;
        if (G.trialDownT > 2) { G.trialDownT = 0; Encounters.failTrial(s); }
        else if (G.trialT > 1.5 && !P.down && Math.hypot(P.x - World.ARENA.exit.x, P.y - World.ARENA.exit.y) < 24) Encounters.failTrial(s);
        else if (s.left <= 0) Encounters.completeTrial(s);
      }
    }
  }
  function updateParticles(dt) {
    for (const p of G.parts) { p.x += p.vx * dt; p.y += p.vy * dt; p.vx *= 0.92; p.vy = p.vy * 0.92 + p.grav * dt; p.life -= dt; }
    G.parts = G.parts.filter(p => p.life > 0);
    for (const t of G.texts) t.t += dt;
    G.texts = G.texts.filter(t => t.t < (t.big ? 1.1 : 0.8));
    for (const b of G.bolts) b.t -= dt;
    G.bolts = G.bolts.filter(b => b.t > 0);
    for (const r of G.rings) { r.t += dt; r.r += (r.max - r.r) * Math.min(1, dt * 8); }
    G.rings = G.rings.filter(r => r.t < 0.45);
  }
  function updateTriggers(dt) {
    G.gateMsgT -= dt; G.lowHpT -= dt;
    if (G.comboT > 0) { G.comboT -= dt; if (G.comboT <= 0) G.combo = 0; }
    if (!World.gateOpen && G.gateMsgT <= 0 && Math.hypot(P.x - World.tc(World.GATE_FRONT.x), P.y - World.tc(World.GATE_FRONT.y)) < 180) {
      Screens.say(`Ворота заперты магией! Победи стражей: ${Bosses.guardiansDone()}/${Bosses.guardiansCount()}.`);
      G.gateMsgT = 12;
    }
    G.fogT -= dt;
    if (G.fogT <= 0) { G.fogT = 0.25; Terrain.revealFog(P.x, P.y, 9); }
    G.scaleT = (G.scaleT || 0) - dt;
    if (G.scaleT <= 0) { G.scaleT = 1; G.scaleCache = {}; }
    if (G.hintT > 0) G.hintT -= dt;
    if (G.mmHintT > 0) G.mmHintT -= dt;
  }
  function objective() {
    if (World.CFG.abyss) return { x: P.x, y: P.y }; // в Бездне и обороне идти некуда – враги сами придут
    for (let i = 0; i < Bosses.guardiansCount(); i++) if (!G.defeated[i]) {
      if (World.CFG.detective && (G.clues5[i] || 0) < 3) {
        let best = null, bd = 1e12;
        for (const q of World.clues) if (q.i === i && !q.found) { const d = (q.x - P.x) ** 2 + (q.y - P.y) ** 2; if (d < bd) { bd = d; best = q; } }
        if (best) return { x: best.x, y: best.y };
      }
      return { x: Session.bosses[i].hx, y: Session.bosses[i].hy };
    }
    const fin = Session.bosses[Session.bosses.length - 1];
    if (!G.defeated[fin.id]) {
      if (!Physics.playerInCastle()) return { x: World.tc(World.GATE_FRONT.x), y: World.tc(World.GATE_FRONT.y) };
      return { x: fin.hx, y: fin.hy };
    }
    return { x: World.tc(World.CAGE.x), y: World.tc(World.CAGE.y) };
  }
  function update(dt) {
    G.time += dt;
    if (G.cutscene) Story.updateCutscene(dt);
    else if (NET.client) { // гостья: мир присылает хозяин, своя только героиня
      Hero.updatePlayer(dt);
      Multiplayer.netProxies(dt);
      updateProjectiles(dt);
      updatePlayerFx(dt);
      updateHazards(dt);
      updateTriggers(dt);
      Expedition.updateSea(dt);
      if (World.CFG.house || World.beds.length || World.shelves.length || World.boxes.length || World.clues.length || World.CFG.dark) HouseChapter.updateHouse(dt);
      Multiplayer.netWinterLocal(dt);
      if (Defense.defOn()) Defense.defClientTick(dt);
      Encounters.updateRelics(dt);
      Encounters.updateMusic(dt);
    } else {
      Hero.updatePlayer(dt);
      StarTrail.update();
      Enemies.updateEnemies(dt);
      for (const b of Session.bosses) Bosses.updateBoss(b, dt);
      Session.AIM = P;
      updateProjectiles(dt);
      updatePlayerFx(dt);
      updateHazards(dt);
      updatePickups(dt);
      updateShrines();
      spawnEnemies(dt);
      updateTriggers(dt);
      Encounters.updateEvents(dt);
      Story.updateFinalFinal(dt);
      Encounters.updateBossHearts(dt);
      Encounters.updateChampions(dt);
      HouseChapter.updateHouse(dt);
      Expedition.updateWinter(dt);
      Expedition.updateSea(dt);
      Encounters.updateRelics(dt);
      Encounters.updateMusic(dt);
      if (G.abyss) { if (G.abyss.def) Defense.defUpdate(dt); else Challenges.abyssUpdate(dt); }
      if (G.daily) Challenges.dailyUpdate(dt);
    }
    Collection.bookScan(dt);
    Achievements.lifeT -= dt; if (Achievements.lifeT <= 0) { Achievements.lifeT = 10; Achievements.lifeFlush(); }
    if (G.st && Session.state === 'play') G.st.time += dt;
    if (G.rush) Challenges.tickRush(dt);
    updateParticles(dt);
    Screens.Dialog.update(dt);
    if (G.shake > 0) G.shake = Math.max(0, G.shake - dt * 30);
    if (G.hurtFlash > 0) G.hurtFlash -= dt;
    updateCamera();
  }
  function updateCamera() {
    const vw = Viewport.VW / Viewport.ZOOM, vh = Viewport.VH / Viewport.ZOOM;
    let tx = P.x, ty = P.y;
    if (Session.state === 'menu') { G.menuT = performance.now() / 1000; tx = World.tc(World.START.x) + Math.sin(G.menuT * 0.12) * 900 - 500; ty = World.tc(World.START.y) - 600 + Math.cos(G.menuT * 0.09) * 500; }
    if (G.td && Session.state !== 'menu') {
      const B = G.td.bounds, cl = (v, lo, hi, half) => hi - lo <= half * 2 ? (lo + hi) / 2 : clamp(v, lo + half, hi - half);
      G.cam.x = cl(tx, B.x0 - 60, B.x1 + 60, vw / 2); G.cam.y = cl(ty, B.y0 - 250, (B.y2 && G.td.fac && G.td.fac.found && ty > B.y1 - 200 ? B.y2 : B.y1) + 110, vh / 2); // 1.0.14: в цеху камера опускается к фабрике // сверху запас побольше: входы не должны прятаться под плашками
      return;
    }
    G.cam.x = clamp(tx, vw / 2, World.WORLD_W - vw / 2);
    const inArena = Session.state !== 'menu' && P.y > World.PLAY_H * World.T;
    G.cam.y = clamp(ty, (inArena ? World.PLAY_H * World.T : 0) + vh / 2, (inArena ? World.WORLD_H : World.PLAY_H * World.T) - vh / 2);
  }

  return {
    WAVE_GAP, objective, update, updateCamera,
  };
})();
