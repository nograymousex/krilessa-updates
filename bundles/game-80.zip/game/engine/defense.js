'use strict';

const Defense = (() => {
  // ---------- оборона: дороги, площадки, башни с мастерствами, коты-заслон, бесконечные волны ----------
  let TD_HIT = false; // урон сейчас наносит башня или кот, а не героиня
  function defOn() { return !!(G.abyss && G.abyss.def && G.core && G.td); }
  function defPlayers() { return 1 + (NET.host && G.netRun ? Multiplayer.netLiveMates() : 0); }
  const tdE = n => 2 + n + (Math.max(0, n - 12) + Math.max(0, n - 24) + Math.max(0, n - 36)) * 0.5; // уровень врагов на волне: чем дальше, тем круче растёт
  // в обороне сила врагов не подстраивается под героиню – иначе башни перестали бы справляться
  function tdScale(E) {
    const A = G.abyss, w = A ? A.wave : 1;
    return {
      // первые волны мягче: здоровье набирает полную силу к 25-й; после 18-й враги крепчают всё быстрее – бесконечная оборона должна когда-то закончиться
      // plK – сколько героинь: вместе враги крепче; 1.08 – подобрано ботами так, чтобы с дальнобойными башнями 0.35.4 было примерно на 10% легче, чем в 0.35.3
      hp: 1.08 * (1 + Math.min(0.5, w * 0.02)) * Math.pow(1.045, Math.max(0, w - 18)) * refMobOld(E) / refMobOld(4) * G.diff.hp * ((A && A.plK) || 1), // 1.0.15: башни не растут вместе с героиней – враги обороны крепчают по прежнему расчёту
      dmg: BAL.mobDmgK * BAL.metaK * refEHP(E) / refEHP(4) * G.diff.dmg,
      // опыт привязан к номеру волны: героиня растёт примерно на уровень за волну и не обгоняет волну больше чем на несколько уровней
      xp: 0.5 * Actors.xpFor(E) / BAL.xpDiv * clamp(1 - 0.22 * (P.level - (w + 2)), 0, 1.5),
    };
  }
  // в обороне главная сила – башни: прокачка героини (таланты, реликвии, осколки) почти не добавляет ей урона по врагам на дорогах,
  // иначе одна героиня проходила бы волны сама. Множитель урона героини: 1 у обычной, меньше – у прокачанной
  function tdHeroK() {
    const L = clamp(P.level, 1, REF.N), k = P.oldK || 1, R = estMobDPS(P) * k / refMobOld(L);
    return Math.pow(clamp(R, 1, 4), -0.75) * k; // 1.0.15: в обороне урон героини – по прежнему расчёту
  }
  const tdTypHp = () => 40 * tdScale(G.abyss.E).hp; // здоровье обычного врага этой волны – мерило для заклинаний
  const tdTwist = id => !!(G.abyss && G.abyss.twist === id);
  // у входа враги под защитой портала: героиня бьёт их вчетверо слабее – башни бьют как обычно
  function tdPortal(e) {
    if (!G.td || e.ln === undefined) return false;
    for (const L of G.td.lanes) if ((e.x - L.gate.x) ** 2 + (e.y - L.gate.y) ** 2 < 150 * 150) return true;
    return false;
  }
  function tdCat(type) {
    const d = ENEMIES[type];
    if (d.fly) return 'fly';
    if (d.ai === 'exploder') return 'boom';
    if (d.ai === 'healer' || d.ai === 'buffer') return 'sup';
    if (d.ai === 'shield' || d.hp >= 110) return 'tank';
    if (d.ai === 'swarm' || d.spd >= 140) return 'run';
    if (d.ai === 'ranged') return 'shoot';
    return 'grunt';
  }
  // враги открытых глав, разложенные по ролям; стоячие (турели, призыватели) в оборону не идут
  function defPool(pr) {
    const p = Challenges.abyssPool(pr), by = { grunt: [], run: [], tank: [], fly: [], boom: [], shoot: [], sup: [] };
    for (const t of p.types) { const d = ENEMIES[t]; if (!d || d.ai === 'turret' || d.ai === 'summoner' || d.noDrop) continue; by[tdCat(t)].push(t); }
    if (!by.grunt.length) by.grunt = ['slime'];
    p.by = by;
    return p;
  }
  const tdMapOpen = (M, pr) => !M.need || GameLoop.DEBUG || pr.admin || (((pr.tdBest || {})[M.need] || {}).wave || 0) >= 10;
  function tdMapPick(pr) { const id = (pr.settings || {}).defMap, M = TD_MAP_BY[id]; return M && tdMapOpen(M, pr) ? M : TD_MAPS[0]; }

  // ---------- карта: трава, дороги, пруды и деревья ----------
  function tdBuildMap(M) {
    const bi = M.biome, x0 = TD_OX, y0 = TD_OY, x1 = TD_OX + TD_W, y1 = TD_OY + TD_H, rs = mulberry32(7000 + TD_MAPS.indexOf(M) * 131);
    World.trees.length = World.chests.length = World.shrines.length = 0;
    World.treeGrid.fill(0);
    for (let ty = 0; ty < World.PLAY_H; ty++) for (let tx = 0; tx < World.MW; tx++) {
      const i = ty * World.MW + tx, qx = (tx + 0.5 - (x0 + x1) / 2) / (TD_W / 2), qy = (ty + 0.5 - (y0 + y1) / 2) / (TD_H / 2);
      World.biomeMap[i] = bi; World.tiles[i] = tx >= x0 && tx < x1 && ty >= y0 && ty < y1 && qx ** 8 + qy ** 8 <= 1.08 ? bi : ROCK;
    }
    const road = new Uint8Array(World.MW * World.MH);
    const pave = (gx, gy) => { for (let oy = -1; oy <= 0; oy++) for (let ox = -1; ox <= 0; ox++) { const tx = x0 + gx + ox, ty = y0 + gy + oy; if (tx > 1 && ty > 1 && tx < World.MW - 2 && ty < World.PLAY_H - 2) { World.tiles[ty * World.MW + tx] = PATH; road[ty * World.MW + tx] = 1; } } };
    const lanes = M.lanes.map(L => {
      const g = L.pts.slice(), a = g[0], b = g[1], sx = Math.sign(a[0] - b[0]), sy = Math.sign(a[1] - b[1]);
      g.unshift([a[0] + sx * 2, a[1] + sy * 2]); // дорога уходит за край поля – оттуда и приходят враги
      for (let i = 1; i < g.length; i++) {
        let [x, y] = g[i - 1]; const [ex, ey] = g[i];
        pave(x, y); while (x !== ex || y !== ey) { x += Math.sign(ex - x); y += Math.sign(ey - y); pave(x, y); }
      }
      const pts = L.pts.map(([gx, gy]) => ({ x: (x0 + gx) * World.T, y: (y0 + gy) * World.T }));
      pts.unshift({ x: pts[0].x + sx * 56, y: pts[0].y + sy * 56 });
      const cum = [0]; for (let i = 1; i < pts.length; i++) cum.push(cum[i - 1] + Math.hypot(pts[i].x - pts[i - 1].x, pts[i].y - pts[i - 1].y));
      return { pts, cum, total: cum[cum.length - 1], from: L.from || 1, side: !!L.side, gate: pts[1] };
    });
    const spots = M.spots.map(([sx, sy], i) => ({ i, x: World.tc(x0 + sx), y: World.tc(y0 + sy), tx: x0 + sx, ty: y0 + sy, tw: null }));
    const core = { x: (x0 + M.core[0]) * World.T, y: (y0 + M.core[1]) * World.T };
    const free = (tx, ty, m) => { // рядом нет ни дороги, ни площадки, ни кристалла
      for (let oy = -m; oy <= m; oy++) for (let ox = -m; ox <= m; ox++) if (road[(ty + oy) * World.MW + tx + ox]) return false;
      for (const s of spots) if (Math.abs(s.tx - tx) <= m + 1 && Math.abs(s.ty - ty) <= m + 1) return false;
      return Math.hypot(World.tc(tx) - core.x, World.tc(ty) - core.y) > 150;
    };
    // 1.0.14: тайная фабрика Крилей – лаз слева снизу и цех под полем
    const FT = TD_FAC.tunnel, FR = TD_FAC.room;
    for (const [gx, gy, w, h] of [FT, FR]) for (let ty = y0 + gy; ty < y0 + gy + h; ty++) for (let tx = x0 + gx; tx < x0 + gx + w; tx++) if (tx > 0 && ty > 0 && tx < World.MW - 1 && ty < World.PLAY_H - 1) World.tiles[ty * World.MW + tx] = PATH;
    const fac = { lvl: 1, workers: 0, crate: 0, found: false, work: 0, made: 0, th: [], thT: 0, thN: 0, puff: 0, gain: 0, fy: y1 * World.T,
      rx0: (x0 + FR[0]) * World.T, ry0: (y0 + FR[1]) * World.T, rx1: (x0 + FR[0] + FR[2]) * World.T, ry1: (y0 + FR[1] + FR[3]) * World.T,
      tx0: (x0 + FT[0]) * World.T, ty0: (y0 + FT[1]) * World.T, tx1: (x0 + FT[0] + FT[2]) * World.T, ty1: (y0 + FT[1] + FT[3]) * World.T };
    fac.my = (fac.ry0 + fac.ry1) / 2 - 6; fac.mx = fac.rx0 + 250; fac.cx = fac.rx0 + 540; fac.cy = fac.my + 8; fac.hx = fac.rx1 - 56; fac.hy = fac.my + 10;
    for (const [px, py, rx, ry] of M.ponds || []) for (let ty = y0 + py - ry; ty <= y0 + py + ry; ty++) for (let tx = x0 + px - rx; tx <= x0 + px + rx; tx++) {
      if (tx < x0 || tx >= x1 || ty < y0 || ty >= y1 || World.tiles[ty * World.MW + tx] !== bi) continue;
      if (((tx - x0 - px) / (rx + 0.4)) ** 2 + ((ty - y0 - py) / (ry + 0.4)) ** 2 <= 1 && free(tx, ty, 1)) World.tiles[ty * World.MW + tx] = M.pond;
    }
    for (let ty = y0; ty < y1; ty++) for (let tx = x0; tx < x1; tx++) {
      if (World.tiles[ty * World.MW + tx] !== bi || !free(tx, ty, 1)) continue;
      if (rs() < Math.min(0.09, BIOMES[bi].treeP * 0.6 * (0.5 + vnoise(tx * 0.2 + 3, ty * 0.2 + 7)))) { World.trees.push({ x: tx * World.T + 10 + rs() * 20, y: ty * World.T + 14 + rs() * 20, kind: BIOMES[bi].tree, s: 0.8 + rs() * 0.3 }); World.treeGrid[ty * World.MW + tx] = World.trees.length; }
    }
    World.START = { x: x0 + M.core[0], y: y0 + M.core[1] + 2 };
    Terrain.rebuildMap();
    Terrain.fog.getContext('2d').clearRect(0, 0, World.MW, World.MH); // всё поле видно сразу
    return { M, lanes, spots, core, units: [], temp: [], stars: [], spcd: { star: 0, cats: 0 }, aim: '', shots: [], zaps: [], pools: [], sel: -1, selT: 0, pick: '', uid: 0, fac, bounds: { x0: x0 * World.T, y0: y0 * World.T, x1: x1 * World.T, y1: y1 * World.T, y2: fac.ry1 + 190 } };
  }
  const tdLaneOf = e => G.td.lanes[e.ln];
  // точка дороги на расстоянии d от входа; пишет px, py и номер отрезка прямо в переданный объект
  function tdLanePt(L, d, o) {
    d = clamp(d, 0, L.total); let i = o.seg || 1; const n = L.pts.length - 1;
    if (i > n) i = n;
    while (i < n && L.cum[i] < d) i++;
    while (i > 1 && L.cum[i - 1] > d) i--;
    const a = L.pts[i - 1], b = L.pts[i], k = (d - L.cum[i - 1]) / (L.cum[i] - L.cum[i - 1] || 1);
    o.seg = i; o.px = a.x + (b.x - a.x) * k; o.py = a.y + (b.y - a.y) * k;
    return o;
  }
  function startDefense(mapId) {
    const pr = Saves.loadProfile(), net = NET.on && G.netRun;
    if (!net && !(pr.ch1Done || GameLoop.DEBUG || pr.admin)) { RunStats.toast('🔒 Оборона откроется после главы 1'); return; }
    const M = net ? (TD_MAP_BY[NET.dmap] || TD_MAPS[0]) : (TD_MAP_BY[mapId] && tdMapOpen(TD_MAP_BY[mapId], pr) ? TD_MAP_BY[mapId] : tdMapPick(pr));
    const A = CHAPTERS.abyss; A.bosses = []; A.bossTiles = []; A.bossLevels = []; A.hero = net ? NET.hero : Challenges.rushHeroPick(pr);
    Chapters.loadChapter('abyss');
    const td = tdBuildMap(M);
    Chapters.resetRun();
    G.td = td; Viewport.setZoomFactor(0.75);
    G.core = { x: td.core.x, y: td.core.y, r: 30, hp: TD_LIVES, vx: 0, vy: 0, flash: 0, t: 0 };
    G.abyss = { def: true, map: M.id, wave: 0, passed: 0, rest: 30, t: 0, coins: TD_START, q: [], wt: 0, E: tdE(1), bw: 0, pool: defPool(pr), seed: Math.floor(Math.random() * 1e6), leaks: 0, built: 0 };
    Chapters.beginPlay();
    World.gateOpen = true;
    G.abyss.next = NET.client ? null : tdMakeWave(1);
    G.st = RunStats.newRunStats(); G.st.ch = 'def';
    Screens.showBanner(`🛡️ ${M.nm}`, 'Нажми на площадку 🔨 – построим башню. Не пускай врагов к кристаллу');
    G.abyss.mus = Challenges.abyssDecks(pr); Challenges.abyssNextTrack();
    if (!pr.td2Seen) { pr.td2Seen = 1; Saves.saveProfile(pr); setTimeout(() => { if (defOn() && Session.state === 'play') Screens.say('Нажми на каменную площадку 🔨 – вокруг неё появятся башни на выбор. Заклинания – справа!', 6); }, 2200); }
  }

  // ---------- волны ----------
  // [роль, сколько (доля от обычного отряда), дорога (номер, 'all' – по всем, 's' – боковая), задержка в секундах]
  const TD_FIRST = [
    [['grunt', 1, 0, 0]],
    [['grunt', 0.7, 0, 0], ['grunt', 0.7, 1, 2]],
    [['grunt', 0.8, 1, 0], ['run', 0.8, 0, 3]],
    [['fly', 0.8, 0, 0], ['grunt', 0.9, 1, 1]],
    [['champ', 1, 0, 0], ['grunt', 1, 'all', 2]],
    [['tank', 1, 0, 0], ['shoot', 0.8, 1, 2], ['run', 0.6, 's', 5]],
    [['run', 1, 'all', 0], ['grunt', 0.6, 0, 6]],
    [['boom', 0.8, 0, 0], ['grunt', 0.9, 1, 1], ['sup', 1, 1, 4], ['fly', 0.5, 2, 6]],
    [['fly', 1, 'all', 0], ['tank', 0.8, 0, 3], ['run', 0.6, 's', 5]],
    [['boss', 1, 0, 0], ['grunt', 0.8, 'all', 4], ['run', 0.5, 's', 8]],
  ];
  const TD_LOOP = [
    [['boss', 1, 0, 0], ['grunt', 1, 'all', 4], ['tank', 0.5, 1, 7], ['run', 0.6, 's', 9]],
    [['grunt', 1, 'all', 0], ['run', 0.7, 0, 4], ['shoot', 0.5, 1, 6]],
    [['fly', 0.9, 'all', 0], ['grunt', 0.9, 1, 2], ['run', 0.5, 's', 6]],
    [['tank', 1, 'all', 0], ['sup', 1, 0, 3], ['grunt', 0.6, 1, 6]],
    [['run', 1.2, 'all', 0], ['boom', 0.8, 0, 3], ['run', 0.6, 's', 5]],
    [['champ', 1, 0, 0], ['champ', 1, 1, 6], ['grunt', 1, 'all', 2], ['shoot', 0.6, 1, 5]],
    [['shoot', 1, 'all', 0], ['tank', 0.8, 0, 2], ['fly', 0.6, 1, 6]],
    [['fly', 1.4, 'all', 0], ['run', 0.6, 's', 4]],
    [['boom', 1, 'all', 0], ['run', 0.9, 1, 2], ['sup', 1, 0, 4], ['tank', 0.5, 0, 6]],
    [['grunt', 0.9, 'all', 0], ['tank', 0.6, 'all', 3], ['fly', 0.7, 'all', 5], ['run', 0.7, 's', 7], ['sup', 1, 1, 8]],
  ];
  const TD_SPAWN = { grunt: [0.85, 1], run: [0.38, 1.3], tank: [1.7, 0.4], fly: [0.65, 0.75], boom: [0.95, 0.5], shoot: [1.05, 0.6], sup: [2.4, 0.12] }; // [пауза между врагами, сколько их в отряде]
  function tdMakeWave(n) {
    const A = G.abyss, M = G.td, by = A.pool.by, mult = 1 + 0.5 * (defPlayers() - 1);
    const open = M.lanes.map((L, i) => i).filter(i => M.lanes[i].from <= n);
    const main = open.filter(i => !M.lanes[i].side), side = open.filter(i => M.lanes[i].side);
    if (!main.length) main.push(0);
    const rs = mulberry32(9100 + n * 77 + A.seed);
    const n0 = (7 + n * 1.35) * mult, gk = Math.max(0.55, 1 - n * 0.011), eliteP = Math.min(0.3, 0.02 + n * 0.006);
    const tw = n >= 7 && n % 7 === 0 ? TD_TWISTS[Math.floor(rs() * TD_TWISTS.length)].id : ''; // каждая седьмая – особая
    const q = [], sum = new Map();
    const note = (ln, tag, cnt) => { if (!sum.has(ln)) sum.set(ln, {}); const o = sum.get(ln); o[tag] = (o[tag] || 0) + cnt; };
    const group = (cat, k, ln, at) => {
      const list = by[cat] && by[cat].length ? by[cat] : by.grunt, type = list[Math.floor(rs() * list.length)], c = tdCat(type), [gap, share] = TD_SPAWN[c];
      const cnt = Math.max(c === 'sup' ? 1 : 2, Math.round(n0 * share * k));
      for (let i = 0; i < cnt; i++) q.push({ at: at + i * gap * gk, type, ln, elite: rs() < eliteP });
      note(ln, c, cnt);
    };
    let plan = n <= TD_FIRST.length ? TD_FIRST[n - 1] : TD_LOOP[n % 10];
    if (tw === 'raid' && by.fly.length) plan = plan.map(([cat, k, where, at]) => [cat === 'boss' || cat === 'champ' ? cat : 'fly', cat === 'boss' || cat === 'champ' ? k : k * 1.1, where, at]); // налёт: почти все летят
    for (const [cat, k, where, at] of plan) {
      if (cat === 'sup') continue; // лекарей в обороне нет: с ними поздние волны становились нечестными
      if (cat === 'boss') { const ln = main[Math.floor(rs() * main.length)]; q.push({ at, boss: true, ln }); note(ln, 'boss', 1); continue; }
      if (cat === 'champ') {
        if (where > 0 && (n < 25 || main.length < 2)) continue; // второй чемпион – только на поздних волнах
        const ln = main[where % main.length], list = by.tank.concat(by.grunt).filter(t => ENEMIES[t].ai !== 'swarm'), type = list[Math.floor(rs() * list.length)] || by.grunt[0];
        q.push({ at, champ: true, type, ln }); note(ln, 'champ', 1); continue;
      }
      if (where === 'all') main.forEach((ln, i) => group(cat, k / main.length * 1.15, ln, at + i * 1.3));
      else if (where === 's') group(cat, k, side.length ? side[Math.floor(rs() * side.length)] : main[(n + 1) % main.length], at);
      else group(cat, k, main[where % main.length], at);
    }
    q.sort((a, b) => a.at - b.at);
    return { n, q, tw, pl: defPlayers(), sum: [...sum.entries()].map(([ln, o]) => [ln, Object.entries(o).sort((a, b) => b[1] - a[1])]) };
  }
  function tdSpawn(type, ln, o = {}) {
    const A = G.abyss, d = ENEMIES[type], L = G.td.lanes[ln];
    const e = Enemies.spawnEnemy(type, L.pts[0].x, L.pts[0].y, G.td.M.biome, { E: A.E, elite: !!o.elite, sc: tdScale(A.E), instant: true });
    e.ln = ln; e.dist = 0; e.seg = 1; e.ox = rnd(-15, 15); e.oy = rnd(-15, 15); e.cat = tdCat(type); e.run = e.cat === 'run'; e.agCd = 0; e.cd = rnd(1, 3);
    e.lspd = clamp(d.spd || 60, 44, 150) * 0.72 * rnd(0.94, 1.06) * (e.affix === 'fast' ? 1.35 : 1) * (1 + Math.min(0.3, A.wave * 0.006));
    e.hp = e.maxHp = 40 * Math.pow(d.hp / 40, 0.6) * e.maxHp / d.hp; // толстые и хлипкие враги ближе друг к другу: оборона одинаково честна с любым набором открытых глав
    if (o.champ) { e.champion = true; e.hp = e.maxHp = e.maxHp * 5; e.dmg *= 1.2; e.r *= 1.25; e.xp *= 3; e.name = d.name; e.lspd *= 0.85; }
    tdLanePt(L, 0, e); e.x = e.px + e.ox; e.y = e.py + e.oy; e.lpx = e.px; e.rem = L.total;
    return e;
  }
  function tdBossSpawn(ln) {
    const A = G.abyss, L = G.td.lanes[ln], kind = pick(A.pool.kinds), g = L.gate;
    World.CFG.bosses = [kind]; World.CFG.bossLevels = [Math.round(A.E) + 2]; World.CFG.bossTiles = [{ x: Math.floor(g.x / World.T), y: Math.floor(g.y / World.T) }]; G.defeated = [false];
    Bosses.makeBosses(); const b = Session.bosses[0]; b.x = b.hx = g.x; b.y = b.hy = g.y; A.bw = A.wave; A.bossLn = ln; A.bossD = L.cum[1] + 30; A.bossT = 0; A.bossP = {};
    Bosses.startBossFight(b);
  }
  // страж идёт по дороге: его «дом» ползёт к кристаллу, а дойдя, страж начинает его крошить
  function tdBoss(dt) {
    const A = G.abyss, b = G.activeBoss; if (!b || b.state !== 'fight' || A.bossLn === undefined) return;
    const L = G.td.lanes[A.bossLn];
    A.bossD = Math.min(L.total - 80, A.bossD + 20 * dt); tdLanePt(L, A.bossD, A.bossP); b.hx = A.bossP.px; b.hy = A.bossP.py;
    A.silT = (A.silT === undefined ? 6 : A.silT) - dt;
    if (A.silT <= 0) { // волна сна: башни рядом со стражем засыпают на 2 секунды
      A.silT = 9; let n = 0;
      for (const sp of G.td.spots) if (sp.tw && (sp.x - b.x) ** 2 + (sp.y - b.y) ** 2 < 200 * 200) { sp.tw.silT = 2; n++; }
      Effects.shockRing(b.x, b.y, '#9a6aff', 200); if (n) { Effects.floatText(b.x, b.y - b.r - 30, '💤 Башни уснули!', '#c9b3ff', true); Sound.sfx.whisper(); }
    }
    if (A.bossD >= L.total - 81 && Math.hypot(b.x - G.core.x, b.y - G.core.y) < 260) { A.bossT += dt; if (A.bossT >= 1.6) { A.bossT = 0; tdCoreHit(1); } }
  }
  function defWave() {
    const A = G.abyss; if (A.wave > 0) tdSurvived(A.wave);
    A.repair = null;
    A.wave++; A.E = tdE(A.wave); A.votes = new Set(); A.rest = TD_GAP - Math.min(8, A.wave * 0.4); A.wt = 0; // поначалу между волнами больше времени
    const W = A.next && A.next.n === A.wave && A.next.pl === defPlayers() ? A.next : tdMakeWave(A.wave); // подруга зашла или вышла – волну пересчитываем
    A.q = W.q; A.sum = W.sum; A.twist = W.tw || ''; A.heroK = tdHeroK(); A.plK = 1 + 0.25 * (defPlayers() - 1); A.next = tdMakeWave(A.wave + 1);
    { const F = G.td.fac; if (F && F.found && A.wave >= TD_FAC.thiefFrom && (A.wave - TD_FAC.thiefFrom) % TD_FAC.thiefEvery === 0) { F.thT = 8; F.thN = 1 + Math.floor((A.wave - TD_FAC.thiefFrom) / 12); } }
    const tags = new Set(); for (const [, list] of W.sum) for (const [t] of list) tags.add(t);
    const seen = A.seenTag || (A.seenTag = {});
    let sub = `Врагов: ${W.q.filter(x => !x.boss).length}`;
    if (A.twist) { const X = TD_TWIST_BY[A.twist]; Multiplayer.netBan(`${X.ic} Волна ${A.wave}: ${X.nm}!`, X.ds); Sound.sfx.event(); Challenges.buzz(60); return; }
    if (tags.has('boss')) sub = 'Страж идёт к кристаллу – остановите его!';
    else if (tags.has('champ')) sub = '👑 С ними чемпион – бейте все вместе';
    else if (tags.has('fly') && !seen.fly) sub = '🦇 Летят! Их достают Перьемёт, Диско-шар и Морозилка';
    else if (tags.has('tank') && !seen.tank) sub = '🛡️ Крепкие враги – им нужны сильные башни';
    else if (tags.has('run') && !seen.run) sub = '💨 Бегуны проскакивают мимо героини – ставь котов и Морозилку';
    for (const t of tags) seen[t] = 1;
    Multiplayer.netBan(`🛡️ Волна ${A.wave}`, sub);
    Sound.sfx.event(); Challenges.buzz(40);
  }

  function tdSpawnQ(it) {
    if (it.boss) tdBossSpawn(it.ln);
    else tdSpawn(it.type, it.ln, { elite: it.elite || it.champ, champ: it.champ });
  }
  function defUpdate(dt) {
    const A = G.abyss, C = G.core; if (!A || A.done || G.cutscene) return;
    A.t += dt; A.trackT = (A.trackT || 0) + dt;
    C.t += dt; if (C.flash > 0) C.flash -= dt;
    tdHeroTick(dt); tdSpellTick(dt);
    tdTowers(dt, true); tdUnits(dt); tdShots(dt); tdPools(dt); tdBoss(dt); KrillFactory.tdFacTick(dt);
    if (C.hp <= 0) { defLose(); return; }
    if (A.q.length) { A.wt += dt; while (A.q.length && A.q[0].at <= A.wt) tdSpawnQ(A.q.shift()); }
    if (A.votes && A.votes.size) tdVoteCheck();
    const hold = !!G.activeBoss;
    if (A.wave > 0 && A.passed < A.wave && !A.q.length && !hold && !G.enemies.some(e => !e.dead && e.ln !== undefined)) tdSurvived(A.wave);
    if (NET.host && G.netRun) updateRepair(dt);
    if (!A.q.length && !hold && A.passed >= A.wave) { A.rest -= dt; if (A.rest <= 0) defWave(); } // 1.0.11: пока волну не добили – следующая не идёт
    if (A.trackT > 150 && !G.activeBoss) Challenges.abyssNextTrack();
  }
  const REPAIR_RADIUS = 110, REPAIR_SECONDS = 2;

  function repairStatus() {
    return defOn() && NET.on && G.netRun ? G.abyss.repair || null : null;
  }

  function repairFx() {
    const C = G.core;
    Effects.shockRing(C.x, C.y, '#8ff1da', REPAIR_RADIUS);
    Effects.floatText(C.x, C.y - 75, '+1 кристаллу', '#a9ffdd', true);
    Sound.sfx.heart();
  }

  function updateRepair(dt) {
    const A = G.abyss, C = G.core;
    if (NET.paused) return;
    if (!A.wave || A.passed !== A.wave || A.rest <= 0 || A.q.length || G.activeBoss || C.hp <= 0 ||
        (C.hp >= TD_LIVES && A.repairedWave !== A.wave) || !Multiplayer.netLiveMates()) {
      A.repair = null;
      return;
    }
    const r = A.repair || (A.repair = { near: 0, progress: 0, elapsed: 0, repaired: A.repairedWave === A.wave });
    if (r.repaired) { r.progress = 100; return; }
    const inside = (x, y) => (x - C.x) ** 2 + (y - C.y) ** 2 <= REPAIR_RADIUS ** 2;
    let near = Session.state === 'play' && !P.down && inside(P.x, P.y) ? 1 : 0;
    const now = performance.now();
    for (const m of NET.peers.values()) {
      if (m.live && !m.down && !m.away && now - m.seen < 1500 && inside(m.tx, m.ty)) near++;
    }
    r.near = Math.min(near, 2);
    r.elapsed = near >= 2 ? r.elapsed + Math.min(dt, A.rest) : 0;
    r.progress = Math.min(100, Math.floor(100 * r.elapsed / REPAIR_SECONDS));
    if (r.progress < 100) return;
    A.repairedWave = A.wave;
    r.repaired = true;
    C.hp = Math.min(TD_LIVES, C.hp + 1);
    repairFx();
  }
  // волна отбита: поле чистое или уже пошла следующая
  function tdSurvived(w) {
    const A = G.abyss; if (w <= A.passed) return; A.passed = w;
    if (w === A.wave) A.rest = Math.min(A.rest, TD_CLEAR_REST); // поле чистое – короткая передышка на стройку
    A.coins += 12 + w * 2;
    defWaveDone(w);
    if (NET.host && G.netRun) for (const m of NET.peers.values()) Multiplayer.netEvent(m.id, ['dw', w]);
  }
  // у каждой героини свой рекорд, свои звёзды и свои искры сезона
  function defWaveDone(w) {
    const A = G.abyss, id = A.map, M = TD_MAP_BY[id];
    Achievements.lifeMax('defWave', w); Achievements.life('spts', Seasons.weekEv('abyss') ? 6 : 3);
    const pr = Saves.loadProfile(); pr.tdBest = pr.tdBest || {}; pr.starsGot = pr.starsGot || {};
    const best = pr.tdBest[id], n = NET.on && G.netRun ? Math.max(1, NET.roster.length) : 1;
    if (!best || w > best.wave) { pr.tdBest[id] = { wave: w, time: Math.round(A.t), hero: P.hero, n }; A.better = true; }
    for (const m of TD_MILE) if (w >= m && !pr.starsGot[`d:${id}:${m}`]) {
      pr.starsGot[`d:${id}:${m}`] = 1; if (G.st) G.st.stars = (G.st.stars || 0) + 1;
      setTimeout(() => { if (defOn()) { Screens.showBanner(`⭐ ${m} волн отбито!`, `${M.nm}: звезда для талантов`); Sound.sfx.win(); } }, 900);
      if (m === 10) { const nx = TD_MAPS.find(q => q.need === id); if (nx) setTimeout(() => RunStats.toast(`${nx.ic} Открыта карта «${nx.nm}»`), 3200); }
    }
    pr.stars = Object.keys(pr.starsGot).length; Saves.saveProfile(pr);
    if (TD_MAPS.every(q => ((pr.tdBest[q.id] || {}).wave || 0) >= 10)) Achievements.lifeMax('defMaps', 1);
    if (w >= 20 && n >= 4) Achievements.lifeMax('defCoop4', 1);
    try { Achievements.lifeFlush(); } catch (e) { /* ignore */ }
  }
  function tdCallBonus() { const A = G.abyss; return A.wave > 0 ? Math.round(Math.max(0, A.rest) * (1 + A.wave * 0.08)) : 0; }
  function tdCall() {
    const A = G.abyss; if (A.q.length || G.activeBoss || A.passed < A.wave || A.rest <= 0.4) return false;
    const b = tdCallBonus(); A.coins += b; A.rest = 0;
    if (b) Multiplayer.netBan('⏩ Волна раньше срока', `+${b} 🪙 за смелость`);
    return true;
  }
  function tdLeak(e) {
    e.dead = true; if (e.haz) e.haz.cancel = true;
    tdCoreHit(e.champion ? 5 : e.elite ? 2 : 1);
  }
  function tdCoreHit(n) {
    const C = G.core, A = G.abyss; if (!A || A.done || C.hp <= 0) return;
    C.hp = Math.max(0, C.hp - n); A.leaks += n; tdCoreFx(n);
    if (C.hp > 0 && C.hp <= 5 && !A.warn5) { A.warn5 = true; Multiplayer.netBan('💎 Кристалл на волоске!', `Осталось всего ${C.hp}`); }
  }
  function tdCoreFx(n) {
    const C = G.core; C.flash = 0.35;
    Effects.burst(C.x, C.y - 24, 16, '#ff5b8a', 200); Effects.floatText(C.x, C.y - 80, `−${n} 💎`, '#ff8ab0', true); G.shake = Math.max(G.shake, 7); Sound.sfx.glass(); Challenges.buzz(70);
  }

  // ---------- враги на дороге ----------
  function tdNearHero(e, r) {
    let best = null, bd = r * r;
    if (!P.down) { const d = (P.x - e.x) ** 2 + (P.y - e.y) ** 2; if (d < bd) { bd = d; best = P; } }
    if (NET.host) for (const m of NET.peers.values()) { if (!m.live || m.down || m.away) continue; const d = (m.x - e.x) ** 2 + (m.y - e.y) ** 2; if (d < bd) { bd = d; best = m; } }
    return best;
  }
  function tdTouch(e) { if (!P.down && (P.x - e.x) ** 2 + (P.y - e.y) ** 2 < (e.r + P.r - 2) ** 2) Hero.hurtPlayer(e.dmg, e.x, e.y); }
  // true – враг идёт по дороге (или стоит в заслоне) и своим умом в этот кадр не пользуется
  function tdEnemyTick(e, dt) {
    if (e.thief) return KrillFactory.tdThiefTick(e, dt); // 1.0.14: воришки с фабрики
    if (e.ln === undefined) return false; // свита стража – обычным умом
    if (e.agCd > 0) e.agCd -= dt;
    if (e.frailT > 0) e.frailT -= dt;
    if (e.stunT > 0) { e.stunT -= dt; if (e.flash > 0) e.flash -= dt; return true; }
    if (e.ag) { // отвлеклась на героиню: гонится, пока та рядом, но не дольше пяти секунд
      const q = e.ag; e.agT -= dt;
      const busy = e.fuse > 0 || e.blink > 0 || e.jd > 0 || e.wind > 0;
      const leash = (e.x - e.px) ** 2 + (e.y - e.py) ** 2 < 140 * 140; // далеко от дороги не уходит
      if (busy || (leash && !q.down && (q === P || q.live) && !q.away && e.agT > 0 && (q.x - e.x) ** 2 + (q.y - e.y) ** 2 < 220 * 220)) { Session.AIM = q.down ? P : q; return false; }
      e.ag = null; e.agCd = 5; e.back = true; e.charge = 0; e.burst = 0;
    }
    e.t += dt; e.kx = 0; e.ky = 0;
    if (e.flash > 0) e.flash -= dt;
    if (e.healing > 0) e.healing -= dt;
    if (e.buffT > 0) e.buffT -= dt;
    if (e.slowT > 0) { e.slowT -= dt; if (e.slowT <= 0) e.slowK = 0; }
    if (e.burnT > 0) {
      e.burnT -= dt; e.burnTick -= dt;
      if (e.burnTick <= 0) {
        e.burnTick = 0.4; e.hp -= e.burnDps * 0.4 * (1 - e.dr);
        if (Math.random() < 0.5) Effects.part(e.x + rnd(-6, 6), e.y - 6, rnd(-20, 20), rnd(-60, -30), 0.4, 3, '#ff8a2a');
        if (e.hp <= 0) { TD_HIT = true; Enemies.killEnemy(e); TD_HIT = false; return true; }
      }
    }
    if (e.affix === 'vampiric' && e.hp < e.maxHp) e.hp = Math.min(e.maxHp, e.hp + e.maxHp * 0.02 * dt);
    const L = tdLaneOf(e);
    if (e.def.ai === 'shield') tdShieldTurn(e, dt);
    if (e.blk) { // упёрлась в кота: стоит и дерётся
      const u = e.blk;
      if (u.dead || u.tg !== e) e.blk = null;
      else {
        e.face = u.x > e.x ? 1 : -1;
        if (e.def.ai === 'exploder') {
          if (!(e.fuse > 0)) { e.fuse = 0.65; e.haz = Bosses.hazardCircle(e.x, e.y, 88, 0.65, e.dmg, 'boom'); Sound.sfx.fuse(); }
          else { e.fuse -= dt; if (e.fuse <= 0) { for (const o of G.td.units) if (!o.dead && (o.x - e.x) ** 2 + (o.y - e.y) ** 2 < 90 * 90) tdUnitHurt(o, e.dmg * 1.6); e.exploded = true; TD_HIT = true; Enemies.killEnemy(e); TD_HIT = false; } }
          return true;
        }
        e.blkT -= dt;
        if (e.blkT <= 0) { e.blkT = e.champion ? 0.8 : 1.1; tdUnitHurt(u, e.dmg * (e.champion ? 1.5 : 0.8)); }
        tdTouch(e);
        return true;
      }
    }
    if (e.cat === 'sup' && !G.td) { // лекари и кексы помогают своим на ходу (в обороне их нет)
      e.cd -= dt;
      if (e.cd <= 0) {
        e.cd = 3.4; e.healTargets = []; const heal = e.def.ai === 'healer';
        for (const o of G.enemies) {
          if (o === e || o.dead || (heal && (o.hp >= o.maxHp || o.def.ai === 'healer'))) continue;
          if ((o.x - e.x) ** 2 + (o.y - e.y) ** 2 > 190 * 190) continue;
          if (heal) { o.hp = Math.min(o.maxHp, o.hp + o.maxHp * 0.25); Effects.floatText(o.x, o.y - o.r - 8, '+', '#7dff9a'); } else o.buffT = 3;
          e.healTargets.push(o);
        }
        if (e.healTargets.length) e.healing = 0.5;
      }
    } else if (e.def.shot && e.def.ai === 'ranged') { // стрелки бьют по героине, не сходя с дороги
      if (e.charge > 0) {
        e.charge -= dt;
        if (e.charge <= 0 && e.shotAt && !e.shotAt.down) { Session.AIM = e.shotAt; Enemies.fireShot(e); Session.AIM = P; }
        tdTouch(e);
        return true;
      }
      e.cd -= dt;
      if (e.cd <= 0) {
        const h = tdNearHero(e, 240);
        if (h && G.shooters < 4) { e.charge = 0.4; e.cd = e.def.shot.cd * 1.3 * e.cdMul; e.shotAt = h; G.shooters++; e.look = Math.atan2(h.y - e.y, h.x - e.x); } else e.cd = 0.5;
      }
    }
    // героиня совсем рядом – наземные бросают дорогу и идут на неё (бегуны и летуны не отвлекаются)
    if (!e.fly && !e.run && !e.back && e.agCd <= 0) { const h = tdNearHero(e, 80); if (h) { e.ag = h; e.agT = 3.5; Session.AIM = h; return false; } }
    const spd = e.lspd * (e.slowT > 0 ? (e.slowK || 0.55) : 1) * (tdTwist('rush') ? 1.33 : 1);
    if (e.back) { // возвращается туда, где сошла с дороги
      tdLanePt(L, e.dist, e);
      const tx = e.px + e.ox, ty = e.py + e.oy, dx = tx - e.x, dy = ty - e.y, d = Math.hypot(dx, dy), st = spd * 1.7 * dt;
      e.backT = (e.backT || 0) + dt;
      if (d <= st + 30 || e.backT > 6) { e.ox = clamp(e.x - e.px, -20, 20); e.oy = clamp(e.y - e.py, -20, 20); e.back = false; e.backT = 0; e.lpx = e.px; } // почти на месте – встаёт в строй, где оказалась: соседи расталкивают, точка в точку не попасть
      else { e.x += dx / d * st; e.y += dy / d * st; e.face = dx > 0 ? 1 : -1; }
    } else {
      if (e.confT > 0) { e.confT -= dt; e.dist = Math.max(0, e.dist - spd * dt); } else e.dist += spd * dt;
      if (e.dist >= L.total - 26) { tdLeak(e); return true; }
      tdLanePt(L, e.dist, e);
      if (Math.abs(e.px - e.lpx) > 0.02) e.face = e.px > e.lpx ? 1 : -1;
      e.lpx = e.px; e.x = e.px + e.ox; e.y = e.py + e.oy;
    }
    e.rem = L.total - e.dist;
    tdTouch(e);
    return true;
  }

  // щитоносец поворачивает щит к угрозе: к героине рядом, иначе к башне, что по нему бьёт, иначе – вперёд по дороге
  function tdShieldTurn(e, dt) {
    let a = null;
    const h = tdNearHero(e, 280);
    if (h) a = Math.atan2(h.y - e.y, h.x - e.x);
    else if (e.hitBy && G.time - e.hitBy.t < 4) a = Math.atan2(e.hitBy.y - e.y, e.hitBy.x - e.x);
    else if (e.blk) a = Math.atan2(e.blk.y - e.y, e.blk.x - e.x);
    else { const L = tdLaneOf(e), o = tdLanePt(L, Math.min(L.total, e.dist + 40), { seg: e.seg }); a = Math.atan2(o.py - e.py, o.px - e.px); }
    e.look = a; e.shieldAng += clamp(angDiff(e.shieldAng, a), -2.4 * dt, 2.4 * dt);
  }
  // удар спереди в щит: стрелы и перья башен вязнут (−70%)
  function tdShieldHit(e, sx, sy) { return e.def && e.def.ai === 'shield' && !e.dead && Math.abs(angDiff(e.shieldAng, Math.atan2(sy - e.y, sx - e.x))) < 1.05; }

  // ---------- башни ----------
  const tdIsBoss = q => q && q.hx !== undefined && q.stage !== undefined;
  const TD_FRIEND = { r: 400, k: 0.15 }; // соседние площадки, даже через дорогу
  const tdK = tw => Math.pow(1 + TD_BOOST.k, tw.boost) * (tw.fr ? 1 + TD_FRIEND.k : 1); // 1.0.15: каждое усиление – +15% от текущей силы
  function tdFriends() { // вместе: башня, рядом с которой стоит башня другой игроки, сильнее
    const M = G.td; if (!M) return;
    const on = NET.on && G.netRun, tws = M.spots.map(s => s.tw).filter(Boolean);
    for (const a of tws) { a.fr = false; a.frL = null; if (!on) continue;
      for (const b of tws) if (b !== a && (b.by || 1) !== (a.by || 1) && (a.x - b.x) ** 2 + (a.y - b.y) ** 2 < TD_FRIEND.r * TD_FRIEND.r) { a.fr = true; (a.frL = a.frL || []).push(b); } }
  }
  function tdSpent(tw) {
    let s = 0; for (let i = 0; i < Math.min(3, tw.lvl); i++) s += tw.def.lv[i].cost;
    if (tw.lvl >= 4) s += tw.def.sp[tw.sp].cost;
    for (let i = 0; i < tw.boost; i++) s += Math.round(TD_BOOST.cost * (tw.k === 'bank' ? 1.7 : 1) * Math.pow(TD_BOOST.grow, i) / 10) * 10;
    return s;
  }
  // цена следующего шага: уровень, мастерство (k = 0 или 1) или усиление; null – дальше некуда
  function tdUpCost(tw, k) {
    if (tw.lvl < 3) return tw.def.lv[tw.lvl].cost;
    if (tw.lvl === 3) return tw.def.sp[k === 1 ? 1 : 0].cost;
    return tw.boost >= TD_BOOST.max ? null : Math.round(TD_BOOST.cost * (tw.k === 'bank' ? 1.7 : 1) * Math.pow(TD_BOOST.grow, tw.boost) / 10) * 10; // копилку усиливать дороже
  }
  function tdDmg(e, v, crit, magic) {
    if (tdTwist('armor')) v *= 0.75;
    if (tdIsBoss(e)) { Bosses.damageBoss(e, { v: v * 0.5, crit: !!crit }, true, true); return; }
    if (e.dead) return;
    if (e.frailT > 0) v *= e.frailK || 1.35;
    v *= (magic ? 1 : 1 - (e.dr || 0)) * (e.buffT > 0 ? 0.6 : 1);
    e.hp -= v; e.flash = 0.1;
    if (G.st) G.st.dmgDealt += Math.min(v, e.hp + v);
    if (crit || Math.random() < 0.22) Effects.dmgText(e.x + rnd(-6, 6), e.y - e.r - 6, v, '#e8e0ff', !!crit);
    if (e.hp <= 0) { TD_HIT = true; Enemies.killEnemy(e); TD_HIT = false; }
  }
  // кого бить: того, кто ближе всех к кристаллу (снайпер – самого крепкого); real = false – гостья, там это просто картинка
  const tdRng = S => S.rng * (tdTwist('fog') ? 0.67 : 1);
  function tdTargets(tw, S, n) {
    const r2 = tdRng(S) ** 2, air = tw.def.air, out = [];
    for (const e of G.enemies) {
      if (e.dead || e.spawnT > 0 || (!air && e.fly)) continue;
      const d2 = (e.x - tw.x) ** 2 + (e.y - tw.y) ** 2; if (d2 > r2 || (S.minR && d2 < S.minR * S.minR)) continue;
      e._v = S.strong ? -e.hp : (e.rem !== undefined ? e.rem : 5000 + Math.sqrt(d2));
      out.push(e);
    }
    out.sort((a, b) => a._v - b._v);
    if (!out.length) { const b = G.activeBoss; if (b && b.state === 'fight' && (b.z || 0) < 30 && (b.alpha === undefined || b.alpha > 0.3) && (b.x - tw.x) ** 2 + (b.y - tw.y) ** 2 < r2) out.push(b); }
    return out.length > n ? out.slice(0, n) : out;
  }
  function tdTowers(dt, real) {
    const M = G.td;
    M.frT = (M.frT || 0) - dt; if (M.frT <= 0) { M.frT = 0.5; tdFriends(); }
    for (const sp of M.spots) {
      const tw = sp.tw; if (!tw) continue;
      const S = tdStat(tw.def, tw.lvl, tw.sp), k = tdK(tw);
      tw.t += dt; if (tw.shot > 0) tw.shot -= dt;
      if (tw.pop) { tw.pop.t -= dt; if (tw.pop.t <= 0) tw.pop = null; }
      if (tw.gust > 0) tw.gust -= dt;
      if (tw.silT > 0) { tw.silT -= dt; continue; } // страж усыпил
      if (tw.k === 'cats') continue;
      if (tw.k === 'frost') { tdFrost(tw, S, k, dt, real); continue; }
      if (tw.k === 'bank') { // копилка: платит один раз, когда начинается следующая волна; каждая следующая копилка – меньше
        const A = G.abyss; if (tw.paid === undefined) tw.paid = A.wave;
        if (A.wave > tw.paid) {
          tw.paid = A.wave;
          const banks = M.spots.filter(q => q.tw && q.tw.k === 'bank').map(q => q.tw), i = banks.indexOf(tw), share = Math.max(0.4, 1 - 0.25 * i);
          const v = Math.round(S.inc * share * k); tw.shot = 0.5; tw.pop = { v, t: 1.6 }; // k – усиления и дружба башен
          if (real) A.coins += v;
        }
        continue;
      }
      tw.cd -= dt; if (tw.cd > 0) continue;
      const list = tdTargets(tw, S, S.multi || 1), tg = list[0];
      if (!tg) { tw.cd = 0.15; continue; }
      tw.cd = S.cd; tw.shot = 0.18; tw.aim = Math.atan2(tg.y - tw.y, tg.x - tw.x);
      if (tw.k === 'feather') {
        for (const e of list) M.shots.push({ k: 'f', x: tw.x, y: tw.y - 44, tg: e, tx: e.x, ty: e.y, spd: S.strong ? 900 : 620, dmg: S.dmg * k, crit: S.crit || 0, big: !!S.strong, real, src: tw });
      } else if (tw.k === 'fire') {
        const dur = S.stun ? 0.8 : 0.6; let tx = tg.x, ty = tg.y;
        if (tg.ln !== undefined && !tg.ag && !tg.blk && !tg.back && !(tg.stunT > 0)) { const o = tdLanePt(M.lanes[tg.ln], tg.dist + tg.lspd * dur * (tg.slowT > 0 ? (tg.slowK || 0.55) : 1), { seg: tg.seg }); tx = o.px + tg.ox; ty = o.py + tg.oy; }
        M.shots.push({ k: 'b', sx: tw.x, sy: tw.y - 36, x: tw.x, y: tw.y - 36, z: 0, tx, ty, t: 0, dur, dmg: S.dmg * k, S, big: !!S.stun, real });
      } else if (tw.k === 'disco') tdChain(tw, S, k, tg, real);
      else if (tw.k === 'mortar') { // хлопушка – по дуге, взрыв по толпе
        const dur = 1.0, tx = tg.x, ty = tg.y;
        M.shots.push({ k: 'b', sx: tw.x, sy: tw.y - 30, x: tw.x, y: tw.y - 30, z: 0, tx, ty, t: 0, dur, dmg: S.dmg * k, S: Object.assign({ burn: 0 }, S), big: !!S.stun, real, pop: true });
      } else if (tw.k === 'wind') { // ветряк: отбрасывает назад по дороге
        const ls = tdTargets(tw, S, S.n || 3); tw.gust = 0.5;
        for (const e of ls) {
          if (tdIsBoss(e)) continue;
          if (real) { tdDmg(e, S.dmg * k, false, true); if (!e.dead && e.ln !== undefined && e.dist !== undefined) { e.dist = Math.max(0, e.dist - S.push * (e.elite ? 0.6 : 1)); e.ag = false; if (S.conf) e.confT = Math.max(e.confT || 0, S.conf); } }
          for (let i = 0; i < 4; i++) Effects.part(e.x + rnd(-10, 10), e.y + rnd(-10, 10), Math.cos(tw.aim) * 160, Math.sin(tw.aim) * 160, 0.35, 3, '#d8f0ff');
        }
      } else if (tw.k === 'vine') { // плющ: опутывает и ранит
        const ls = tdTargets(tw, S, S.n || 2);
        for (const e of ls) {
          if (real) { tdDmg(e, S.dmg * k, false, true); if (!e.dead) { if (tdIsBoss(e)) e.stunT = Math.max(e.stunT || 0, S.root * 0.25); else e.stunT = Math.max(e.stunT || 0, S.root); } }
          e.vineT = S.root;
          for (let i = 0; i < 5; i++) Effects.part(e.x + rnd(-12, 12), e.y + rnd(-4, 8), rnd(-20, 20), -rnd(30, 70), 0.6, 3, i % 2 ? '#6ab04a' : '#a8e07a');
        }
      }
    }
  }
  function tdFrost(tw, S, k, dt, real) {
    const r2 = tdRng(S) ** 2;
    tw.cd -= dt; const pulse = tw.cd <= 0; if (pulse) tw.cd = S.cd;
    if (S.freeze) tw.fz = (tw.fz === undefined ? 3 : tw.fz) - dt;
    const frz = !!S.freeze && tw.fz <= 0; let any = false;
    for (const e of G.enemies) {
      if (e.dead || e.spawnT > 0 || (e.x - tw.x) ** 2 + (e.y - tw.y) ** 2 > r2) continue;
      any = true; if (!real) continue;
      e.slowT = Math.max(e.slowT, 0.3); e.slowK = Math.min(e.slowK || 1, S.slow);
      if (S.frail) { e.frailT = 0.5; e.frailK = S.frail; }
      if (frz && !e.champion) { e.stunT = Math.max(e.stunT || 0, S.freeze); e.iceT = S.freeze; }
      if (pulse) tdDmg(e, S.dmg * k, false, true);
    }
    if (pulse && any) tw.shot = 0.3;
    if (frz) { if (any) { tw.fz = 6; Effects.shockRing(tw.x, tw.y, '#bfeaff', S.rng); Sound.sfx.glass(); tw.shot = 0.5; } else tw.fz = 0.3; }
  }
  function tdChain(tw, S, k, tg, real) {
    const M = G.td, hit = [tg]; let cur = tg, x = tw.x, y = tw.y - 50;
    for (let n = 0; n < S.chain && cur; n++) {
      const cy = cur.y - (cur.fly ? 8 : 0) - (cur.z || 0);
      M.zaps.push({ x0: x, y0: y, x1: cur.x, y1: cy, life: 0.16 });
      if (real) { tdDmg(cur, S.dmg * k * (n ? 0.8 : 1), false, true); if (S.conf && cur.ln !== undefined && !cur.champion && !cur.dead && !cur.blk && Math.random() < S.conf) cur.confT = 1.6; }
      x = cur.x; y = cy;
      let nx = null, bd = 115 * 115;
      for (const e of G.enemies) { if (e.dead || e.spawnT > 0 || hit.includes(e)) continue; const d2 = (e.x - x) ** 2 + (e.y - y) ** 2; if (d2 < bd) { bd = d2; nx = e; } }
      cur = nx; if (nx) hit.push(nx);
    }
  }
  function tdShots(dt) {
    const M = G.td;
    for (const s of M.shots) {
      if (s.k === 'f') {
        const tg = s.tg, live = tg && (tdIsBoss(tg) ? tg.state === 'fight' : !tg.dead);
        if (live) { s.tx = tg.x; s.ty = tg.y - (tg.fly ? 8 : 0) - (tg.z || 0); }
        const dx = s.tx - s.x, dy = s.ty - s.y, d = Math.hypot(dx, dy) || 1, st = s.spd * dt;
        s.a = Math.atan2(dy, dx);
        if (d <= st + 8) {
          s.dead = true;
          if (s.real && live) {
            const cr = Math.random() < s.crit, blk = !tdIsBoss(tg) && tdShieldHit(tg, s.src.x, s.src.y);
            if (!tdIsBoss(tg)) tg.hitBy = { x: s.src.x, y: s.src.y, t: G.time }; // щитоносец запомнит, откуда стреляют
            if (blk) { Effects.burst(s.x, s.y, 5, '#bfefff', 110); if (Math.random() < 0.25) Effects.floatText(tg.x, tg.y - tg.r - 8, 'блок', '#bfefff'); }
            tdDmg(tg, s.dmg * (cr ? 2.5 : 1) * (blk ? 0.3 : 1), cr && !blk);
          }
          if (s.big) Effects.burst(s.tx, s.ty, 8, '#ffd25a', 140);
        }
        else { s.x += dx / d * st; s.y += dy / d * st; }
      } else { // огненный шар летит по дуге
        s.t += dt; const k = Math.min(1, s.t / s.dur);
        s.x = s.sx + (s.tx - s.sx) * k; s.y = s.sy + (s.ty - s.sy) * k; s.z = Math.sin(k * Math.PI) * (s.big ? 110 : 70);
        if (k >= 1) { s.dead = true; tdBoom(s); }
      }
    }
    if (M.shots.some(s => s.dead)) M.shots = M.shots.filter(s => !s.dead);
    if (M.zaps.length) M.zaps = M.zaps.filter(z => (z.life -= dt) > 0);
  }
  function tdBoom(s) {
    const S = s.S, r = S.r;
    Effects.burst(s.tx, s.ty, s.big ? 30 : 12, '#ff8a2a', s.big ? 260 : 160); Effects.shockRing(s.tx, s.ty, '#ffb03a', r);
    if (s.big) { G.shake = Math.max(G.shake, 5); Sound.sfx.boom(); }
    if (S.pool) G.td.pools.push({ x: s.tx, y: s.ty, r: r * 0.85, t: S.pool, t0: S.pool, dps: s.dmg * 0.3, tick: 0.2, real: s.real });
    if (!s.real) return;
    for (const e of G.enemies) {
      if (e.dead || e.fly || e.spawnT > 0 || (e.x - s.tx) ** 2 + (e.y - s.ty) ** 2 > (r + e.r) ** 2) continue;
      if (S.burn) { e.burnT = 3; e.burnDps = Math.max(e.burnDps || 0, S.burn * s.dmg / S.dmg); if (!(e.burnTick > 0)) e.burnTick = 0.4; }
      if (S.stun && !e.champion) e.stunT = Math.max(e.stunT || 0, S.stun);
      tdDmg(e, s.dmg, false);
    }
    const b = G.activeBoss; if (b && b.state === 'fight' && Math.hypot(b.x - s.tx, b.y - s.ty) < r + b.r) tdDmg(b, s.dmg, false);
  }
  function tdPools(dt) {
    const M = G.td; if (!M.pools.length) return;
    for (const p of M.pools) {
      p.t -= dt; p.tick -= dt;
      if (p.tick <= 0) { p.tick = 0.5; if (p.real) for (const e of G.enemies) if (!e.dead && !e.fly && (e.x - p.x) ** 2 + (e.y - p.y) ** 2 < p.r * p.r) tdDmg(e, p.dps * 0.5, false); }
      if (Math.random() < dt * 8) Effects.part(p.x + rnd(-p.r, p.r) * 0.7, p.y + rnd(-p.r, p.r) * 0.45, 0, -45, 0.5, 3, Math.random() < 0.5 ? '#ff8a2a' : '#ffd23a');
    }
    M.pools = M.pools.filter(p => p.t > 0);
  }
  // ---------- коты-заслон ----------
  function tdRelist() {
    const M = G.td; M.units = [];
    for (const sp of M.spots) if (sp.tw && sp.tw.units) for (const u of sp.tw.units) M.units.push(u);
    for (const t of M.temp) for (const u of t.units) if (!u.gone) M.units.push(u);
  }
  const tdUS = tw => tw.stat || tdStat(tw.def, tw.lvl, tw.sp); // у котоподмоги свои числа
  // ближайшая к точке дорога (для котоподмоги); null – далеко
  function tdRoadAt(x, y, r = 170) {
    let best = null, bd = r * r;
    for (const L of G.td.lanes) for (let d = 60; d < L.total - 40; d += 12) { const o = tdLanePt(L, d, {}), dd = (o.px - x) ** 2 + (o.py - y) ** 2; if (dd < bd) { bd = dd; best = { x: o.px, y: o.py }; } }
    return best;
  }
  function tdStarfall(x, y) {
    const M = G.td, H = tdTypHp();
    for (let i = 0; i < 7; i++) {
      const a = rnd(0, TAU), r = i ? rnd(25, 95) : 0, sx = x + Math.cos(a) * r, sy = y + Math.sin(a) * r * 0.8, dl = 0.6 + i * 0.13;
      M.stars.push({ x: sx, y: sy, t: dl, dmg: H * 0.8 });
      const h = Bosses.hazardCircle(sx, sy, 55, dl, 0, 'meteor'); h.star = true; h.td = true;
    }
    return true;
  }
  function tdReinforce(x, y) {
    const M = G.td, p = tdRoadAt(x, y); if (!p) return false;
    const H = tdTypHp(), tw = { def: TD_TW_BY.cats, lvl: 3, sp: -1, boost: 0, temp: true, s: -1, x: p.x, y: p.y - 40, post: p, stat: { n: 3, hp: H * 3, dmg: H * 0.14, cd: 0.8, rng: 140 }, units: [] };
    for (let i = 0; i < 3; i++) {
      const a = i * TAU / 3 + 0.6;
      tw.units.push({ id: ++M.uid, x: p.x + rnd(-24, 24), y: p.y - 34, dead: false, resp: 0, cd: 0, t: rnd(0, 5), face: 1, hp: tw.stat.hp, maxHp: tw.stat.hp, tw, px: p.x + Math.cos(a) * 15, py: p.y + Math.sin(a) * 11, temp: true, life: 16 });
    }
    M.temp.push(tw); tdRelist();
    Effects.burst(p.x, p.y, 24, '#ffb07a', 180); Effects.shockRing(p.x, p.y, '#ffd0a0', 80); Sound.sfx.meow();
    return true;
  }
  function tdSpellTick(dt) {
    const M = G.td;
    for (const k in M.spcd) if (M.spcd[k] > 0) M.spcd[k] -= dt;
    if (!M.stars.length || NET.client) return;
    for (const st of M.stars) {
      st.t -= dt; if (st.t > 0) continue;
      st.done = true;
      for (const e of G.enemies) if (!e.dead && (e.x - st.x) ** 2 + (e.y - st.y) ** 2 < (58 + e.r) ** 2) tdDmg(e, st.dmg, true, true);
      const b = G.activeBoss; if (b && b.state === 'fight' && Math.hypot(b.x - st.x, b.y - st.y) < 58 + b.r) tdDmg(b, st.dmg * 2, true);
    }
    M.stars = M.stars.filter(q => !q.done);
  }
  // нажали на заклинание, потом на карту
  function tdSpellBtn(id) {
    const M = G.td, D = TD_SPELLS[id]; if (!defOn() || !D || Session.state !== 'play' || G.abyss.done) return;
    if (M.spcd[id] > 0) { RunStats.toast(`${D.ic} ${D.nm}: ещё ${Math.ceil(M.spcd[id])} с`); Sound.sfx.block(); return; }
    if (M.aim === id) { M.aim = ''; Sound.sfx.click(); return; }
    M.aim = id; M.sel = -1; M.pick = ''; RunStats.toast(D.hint); Sound.sfx.click();
  }
  function tdCast(id, x, y) {
    const M = G.td, D = TD_SPELLS[id];
    if (id === 'cats' && !tdRoadAt(x, y)) { RunStats.toast('🐾 Нажми ближе к дороге'); Sound.sfx.block(); return; }
    M.aim = ''; M.spcd[id] = D.cd; Achievements.life('defSpells');
    tdAct('m', 0, [id, Math.round(x), Math.round(y)]);
  }
  function tdFreeUnits(list) { for (const u of list) { if (u.tg) { u.tg.blk = null; u.tg = null; } u.dead = true; } }
  function tdMakeUnits(tw) {
    const M = G.td, S = tdUS(tw), old = tw.units || [];
    if (!tw.post) { // пост – ближайшая точка дороги
      let bd = 1e18;
      for (const L of M.lanes) for (let d = 70; d < L.total - 60; d += 14) { const o = tdLanePt(L, d, {}), dd = (o.px - tw.x) ** 2 + (o.py - tw.y) ** 2; if (dd < bd) { bd = dd; tw.post = { x: o.px, y: o.py }; } }
    }
    tw.units = [];
    for (let i = 0; i < S.n; i++) {
      const a = i * TAU / S.n + 0.6, u = old[i] || { id: ++M.uid, x: tw.x, y: tw.y + 14, dead: false, resp: 0, cd: 0, t: rnd(0, 5), face: 1, hp: 0, maxHp: 0 };
      const mh = S.hp * tdK(tw);
      u.tw = tw; u.px = tw.post.x + Math.cos(a) * 15; u.py = tw.post.y + Math.sin(a) * 11;
      u.hp = u.dead ? 0 : Math.min(mh, u.hp + (mh - u.maxHp)); u.maxHp = mh;
      tw.units.push(u);
    }
    tdFreeUnits(old.slice(S.n));
    tdRelist();
  }
  function tdUnitHurt(u, v) {
    if (u.dead) return;
    const S = tdUS(u.tw);
    if (S.dodge && Math.random() < S.dodge) { Effects.floatText(u.x, u.y - 22, 'мимо!', '#bfeaff'); return; }
    u.hp -= v * (1 - (S.armor || 0)); u.flash = 0.12;
    if (u.hp <= 0) { u.dead = true; u.resp = 9; if (u.temp) u.life = 0; if (u.tg) { u.tg.blk = null; u.tg = null; } Effects.burst(u.x, u.y, 10, '#ffb07a', 120); Effects.floatText(u.x, u.y - 22, '😿', '#fff'); }
  }
  function tdUnits(dt) {
    const M = G.td;
    let gone = false;
    for (const u of M.units) {
      const tw = u.tw, S = tdUS(tw);
      u.t += dt; if (u.flash > 0) u.flash -= dt; if (u.hit > 0) u.hit -= dt;
      if (u.temp) { u.life -= dt; if (u.life <= 0) { if (u.tg) { u.tg.blk = null; u.tg = null; } if (!u.dead) Effects.burst(u.x, u.y, 10, '#ffd0a0', 100); u.dead = true; u.gone = true; gone = true; continue; } }
      if (u.dead) { u.resp -= dt; if (u.resp <= 0) { u.dead = false; u.hp = u.maxHp; u.x = tw.x; u.y = tw.y + 14; Effects.burst(u.x, u.y, 8, '#ffd0a0', 90); } continue; }
      let e = u.tg; if (e && (e.dead || e.blk !== u)) u.tg = e = null;
      if (!e) {
        let bv = 1e18;
        for (const o of G.enemies) {
          if (o.dead || o.fly || o.ln === undefined || o.blk || o.ag || o.back || o.spawnT > 0) continue;
          if ((o.x - u.px) ** 2 + (o.y - u.py) ** 2 > 52 * 52) continue;
          if (o.rem < bv) { bv = o.rem; e = o; }
        }
        if (e) { u.tg = e; e.blk = u; e.blkT = 0.6; }
      }
      const tx = e ? e.x + (u.x < e.x ? -1 : 1) * (e.r + 8) : u.px, ty = e ? e.y + 2 : u.py;
      const dx = tx - u.x, dy = ty - u.y, d = Math.hypot(dx, dy);
      u.mv = d > 3;
      if (u.mv) { const st = Math.min(d, 150 * dt); u.x += dx / d * st; u.y += dy / d * st; u.face = dx > 0 ? 1 : -1; }
      if (e) {
        if (d < 16) {
          u.face = e.x > u.x ? 1 : -1; u.cd -= dt;
          if (u.cd <= 0) { u.cd = S.cd; u.hit = 0.15; const cr = !!S.dodge && Math.random() < 0.3; tdDmg(e, S.dmg * tdK(tw) * (cr ? 2 : 1), cr); }
        }
      } else if (u.hp < u.maxHp) u.hp = Math.min(u.maxHp, u.hp + u.maxHp * 0.06 * dt);
    }
    if (gone) { M.temp = M.temp.filter(t => t.units.some(u => !u.gone)); tdRelist(); }
  }

  // ---------- стройка ----------
  function tdFx(sp, col) { Effects.burst(sp.x, sp.y - 10, 18, col || '#ffd25a', 170); Effects.shockRing(sp.x, sp.y, col || '#ffd25a', 60); Sound.sfx.magic(); }
  // a: 'b' построить (k – башня), 'u' улучшить / выбрать мастерство (k = 0, 1) / усилить, 's' продать, 'c' позвать волну
  function tdAct(a, s, k) {
    if (!defOn() || G.abyss.done) return false;
    if (NET.client) {
      NetT.send(0, { t: 'bd', a, s, k });
      if (a === 'c') { const A = G.abyss; A.votes = A.votes || new Set(); if (A.votes.has(NET.id)) A.votes.delete(NET.id); else A.votes.add(NET.id); } // сразу видно своё «готова»
      return true;
    }
    return tdDo(a, s, k, 1);
  }
  // вместе волну раньше срока зовут, только когда нажали все; одна – сразу
  function tdVote(id) {
    const A = G.abyss; if (A.q.length || G.activeBoss || A.passed < A.wave || A.rest <= 0.4) return false;
    if (!(NET.host && G.netRun && Multiplayer.netLiveMates() > 0)) return tdCall();
    A.votes = A.votes || new Set();
    if (A.votes.has(id)) A.votes.delete(id); else A.votes.add(id);
    tdVoteCheck();
    return true;
  }
  function tdVoteCheck() {
    const A = G.abyss; if (!A.votes || !A.votes.size) return;
    const ids = new Set([1, ...[...NET.peers.values()].filter(m => m.live).map(m => m.id)]); // кто вышел – того голос не ждём
    for (const v of [...A.votes]) if (!ids.has(v)) A.votes.delete(v);
    if (A.votes.size && A.votes.size >= ids.size) { A.votes.clear(); tdCall(); }
  }
  function tdDo(a, s, k, from) {
    const A = G.abyss, M = G.td; if (!defOn() || A.done) return false;
    if (a === 'c') return tdVote(from || 1);
    if (a === 'f') return KrillFactory.tdFacDo(s);
    if (a === 'm') { const [id, x, y] = Array.isArray(k) ? k : []; if (!TD_SPELLS[id] || !isFinite(+x) || !isFinite(+y)) return false; return id === 'star' ? tdStarfall(+x, +y) : tdReinforce(+x, +y); }
    const sp = M.spots[s]; if (!sp) return false;
    if (a === 'b') {
      const def = TD_TW_BY[k]; if (!def || sp.tw || A.coins < def.lv[0].cost) return false;
      A.coins -= def.lv[0].cost; A.built++;
      sp.tw = { s: sp.i, k, def, lvl: 1, sp: -1, boost: 0, x: sp.x, y: sp.y, cd: 0.4, t: 0, aim: -Math.PI / 2, shot: 0, by: from || (NET.on ? NET.id || 1 : 1) };
      if (k === 'cats') tdMakeUnits(sp.tw);
      tdFx(sp, def.col);
      return true;
    }
    const tw = sp.tw; if (!tw) return false;
    if (a === 's') {
      A.coins += Math.round(tdSpent(tw) * TD_SELL);
      if (tw.units) tdFreeUnits(tw.units);
      sp.tw = null; tdRelist(); Effects.burst(sp.x, sp.y - 10, 16, '#ffd25a', 150); Sound.sfx.chest();
      return true;
    }
    if (a === 'u') {
      const cost = tdUpCost(tw, k); if (cost === null || A.coins < cost) return false;
      A.coins -= cost;
      if (tw.lvl < 3) tw.lvl++; else if (tw.lvl === 3) { tw.lvl = 4; tw.sp = k === 1 ? 1 : 0; Achievements.lifeMax('defSpec', 1); } else tw.boost++;
      if (tw.k === 'cats') tdMakeUnits(tw);
      tdFx(sp, tw.def.col);
      return true;
    }
    return false;
  }
  // площадка под рукой – только та, по которой нажали (сама по себе, когда героиня подходит, не открывается)
  function tdCurSpot() {
    const M = G.td;
    if (M.sel >= 0) { if (G.time - M.selT < 30) return M.spots[M.sel]; M.sel = -1; M.pick = ''; }
    return null;
  }
  function tdTap(sx, sy) { // короткий тап по экрану: заклинание, выбор площадки или снятие выбора
    if (!defOn() || Session.state !== 'play' || G.abyss.done) return;
    const M = G.td, wx = G.cam.x + (sx - Viewport.VW / 2) / Viewport.ZOOM, wy = G.cam.y + (sy - Viewport.VH / 2) / Viewport.ZOOM;
    if (M.aim) { tdCast(M.aim, wx, wy); return; }
    let best = -1, bd = 1e9;
    for (const sp of M.spots) { // по башне можно попасть и в саму башню, не только в площадку
      const dx = Math.abs(sp.x - wx), dy = wy - sp.y, hit = sp.tw ? dx < 34 && dy > -70 && dy < 26 : dx * dx + (dy - 5) ** 2 < 44 * 44;
      if (!hit) continue;
      const d = dx + Math.abs(dy - (sp.tw ? -20 : 5));
      if (d < bd) { bd = d; best = sp.i; }
    }
    if (best >= 0 && best !== M.sel) { M.sel = best; M.selT = G.time; M.pick = ''; Sound.sfx.click(); }
    else if (M.sel >= 0) { M.sel = -1; M.pick = ''; }
  }
  const tdStatLine = (def, S, k) => def.id === 'bank' ? `🪙 +${Math.round(S.inc * k)} за каждую отбитую волну` + (S.luck ? ` · 🍀 +${S.luck} за врага рядом` : '') + ' · 2-я копилка −25%, 3-я −50%'
    : def.id === 'wind' ? `⚔️ ${Math.round(S.dmg * k)} · ⏱ ${S.cd} с · 🎯 ${Math.round(S.rng / World.PX_PER_M)} м · 💨 назад ${Math.round(S.push / World.PX_PER_M)} м ×${S.n}` + (S.conf ? ' · 🌀' : '')
    : def.id === 'vine' ? `⚔️ ${Math.round(S.dmg * k)} · ⏱ ${S.cd} с · 🎯 ${Math.round(S.rng / World.PX_PER_M)} м · 🌿 держит ${S.root} с ×${S.n}`
    : def.id === 'mortar' ? `⚔️ ${Math.round(S.dmg * k)} · ⏱ ${S.cd} с · 🎯 ${Math.round(S.minR / World.PX_PER_M)}–${Math.round(S.rng / World.PX_PER_M)} м · 💥 ${Math.round(S.r / World.PX_PER_M)} м` + (S.stun ? ' · 💫' : '')
    : def.id === 'cats' ? `🐈 ${S.n} · ❤️ ${Math.round(S.hp * k)} · ⚔️ ${Math.round(S.dmg * k)}` : `⚔️ ${Math.round(S.dmg * k)} · ⏱ ${S.cd} с · 🎯 ${Math.round(S.rng / World.PX_PER_M)} м` + (S.slow ? ` · 🐌 −${Math.round((1 - S.slow) * 100)}%` : '') + (S.chain ? ` · ⚡×${S.chain}` : '');
  const TD_RING = 66;
  function teamHudY(top) {
    if (!defOn()) return top;
    const skip = $('defSkip');
    return Math.max(top + 32, skip._on && skip._bottom ? skip._bottom + 5 : 0);
  }
  // каждый кадр: кнопка волны, заклинания и кольцо стройки вокруг выбранной площадки
  function tdPanelSync() {
    const on = defOn() && !G.abyss.done && Session.state === 'play' && !G.cutscene, A = G.abyss, M = G.td;
    const ring = $('tdRing'), sk = $('defSkip'), spl = $('tdSpells');
    const sp = on ? tdCurSpot() : null;
    const canCall = on && !A.q.length && !G.activeBoss && A.passed >= A.wave && A.rest > 0.4;
    if (sk._on !== canCall) { sk._on = canCall; sk.classList.toggle('hidden', !canCall); sk._k = ''; }
    if (canCall) {
      const coop = NET.on && G.netRun && (NET.client || Multiplayer.netLiveMates() > 0), need = NET.client ? A.need || 2 : 1 + Multiplayer.netLiveMates(), myId = NET.host ? 1 : NET.id;
      const nv = A.votes ? A.votes.size : 0, mine = !!(A.votes && A.votes.has(myId));
      const b = tdCallBonus(), nt = A.next && A.next.tw, key = `${A.wave}:${Math.ceil(A.rest)}:${b}:${nt}:${!!A.next}:${coop ? nv + '/' + need + mine : ''}:${Viewport.VW}:${Terrain.paperOn}`;
      if (sk._k !== key) {
        sk._k = key;
        const tot = {}; if (A.next && A.next.sum) for (const [, list] of A.next.sum) for (const [tag, n] of list) tot[tag] = (tot[tag] || 0) + n;
        const who = Object.entries(tot).sort((x, y) => y[1] - x[1]).slice(0, 4).map(([tag, n]) => `${TD_TAG[tag] || '👣'}${n > 1 ? n : ''}`).join(' ');
        const X = nt ? TD_TWIST_BY[nt] : null;
        const gates = coop ? lanesAhead() : '';
        sk.innerHTML = (A.wave ? `⏩ Волна ${A.wave + 1} <small>через ${Math.ceil(A.rest)} с${b ? ` · +${b} 🪙` : ''}</small>` : `▶ Начать <small>волна 1 через ${Math.ceil(A.rest)} с</small>`) + (who ? `<small class="who">${who}</small>` : '') + (X ? `<small class="tw">${X.ic} ${X.nm}</small>` : '')
          + (gates ? `<small>Враги ${gates}</small>` : '')
          + (coop ? `<small class="vt">${mine ? '✅ ты готова' : '✋ нажми, когда готова'} · ${nv}/${need}</small>` : '');
        sk.classList.toggle('voted', coop && mine);
        if (coop) sk._bottom = sk.getBoundingClientRect().bottom;
      }
    }
    // 1.0.14: панель фабрики – когда героиня в цеху
    { const fp = $('tdFac'), F = M && M.fac, inF = !!(on && F && F.found && KrillFactory.tdFacIn(F, P.x, P.y));
      if (fp._on !== inF) { fp._on = inF; fp.classList.toggle('hidden', !inF); fp._k = ''; }
      if (inF) {
        const uc = F.lvl < TD_FAC.rate.length ? TD_FAC.up[F.lvl] : 0, hc = F.workers < TD_FAC.hire.length ? TD_FAC.hire[F.workers] : 0;
        const key = `${F.lvl}:${F.workers}:${uc && A.coins >= uc}:${hc && A.coins >= hc}`;
        if (fp._k !== key) {
          fp._k = key; const base = TD_FAC.rate[F.lvl - 1];
          fp.innerHTML = `<b>🏭 Фабрика Крилей · станок ур. ${F.lvl}</b><small>Пока ты в цеху – ${base.toFixed(1)} 🪙/с (вдвоём больше) · крилек: ${F.workers}/3, они дают ${(F.workers * TD_FAC.worker * base).toFixed(1)} 🪙/с и без вас</small>`
            + `<div><button data-f="up" class="${!uc || A.coins < uc ? 'no' : ''}">${uc ? `⚙️ Станок ур. ${F.lvl + 1}<i>${uc} 🪙</i>` : '⚙️ Станок на максимуме'}</button>`
            + `<button data-f="hire" class="${!hc || A.coins < hc ? 'no' : ''}">${hc ? `🦐 Нанять крильку<i>${hc} 🪙</i>` : '🦐 Все крильки на месте'}</button></div>`;
        }
      }
    }
    // заклинания
    if (spl._on !== on) { spl._on = on; spl.classList.toggle('hidden', !on); }
    if (on) for (const bt of spl.children) {
      const id = bt.dataset.s, D = TD_SPELLS[id], cd = Math.max(0, M.spcd[id] || 0), key = Math.ceil(cd) + (M.aim === id ? 'a' : '');
      if (bt._k === key) continue; bt._k = key;
      bt.style.setProperty('--cd', Math.round(cd / D.cd * 360) + 'deg');
      bt.classList.toggle('cool', cd > 0); bt.classList.toggle('aim', M.aim === id);
      bt.querySelector('b').textContent = cd > 0 ? Math.ceil(cd) : '';
    }
    if (ring._on !== !!sp) { ring._on = !!sp; ring.classList.toggle('hidden', !sp); ring._k = ''; ring._p = ''; }
    if (M) M.cur = sp ? sp.i : -1;
    if (!sp) return;
    // кольцо стоит прямо на площадке и едет вместе с картой
    const R = TD_RING, RO = sp.tw ? R : R + 44, cx = clamp((sp.x - G.cam.x) * Viewport.ZOOM + Viewport.VW / 2, RO + 30, Viewport.VW - RO - 30), cy = clamp((sp.y - 14 - G.cam.y) * Viewport.ZOOM + Viewport.VH / 2, Viewport.SAFE_TOP + RO + 36, Viewport.VH - RO - 40);
    // подсказка над кольцом или под ним; в портретном экране не залезает на заклинания справа
    const upFits = cy - R - 150 > Viewport.SAFE_TOP + 20, tipM = upFits ? 'up' : cy + R + 160 < Viewport.VH ? 'down' : 'side'; // в горизонтальном экране места мало – тогда подсказка сбоку
    const off = clamp(cx + (tipM === 'side' ? (cx > Viewport.VW / 2 ? -(R + 160) : R + 160) : 0), 125, Viewport.VW - 125 - (Viewport.VH > Viewport.VW && cy - R - 150 < Viewport.SAFE_TOP + 290 ? 66 : 0)) - cx, pk = `${Math.round(cx)},${Math.round(cy)},${tipM},${Math.round(off)}`;
    if (ring._p !== pk) { ring._p = pk; ring.style.transform = `translate(${Math.round(cx)}px, ${Math.round(cy)}px)`; }
    const tw = sp.tw, c = A.coins;
    const key = `${sp.i}|${tw ? tw.k + tw.lvl + tw.sp + ':' + tw.boost : ''}|${M.pick}|${tw ? (c >= (tdUpCost(tw, 0) || 1e9)) + ':' + (c >= (tdUpCost(tw, 1) || 1e9)) : TD_TOWERS.map(d => c >= d.lv[0].cost ? 1 : 0).join('')}|${tipM}|${Math.round(off)}`;
    if (ring._k === key) return; ring._k = key;
    const at = deg => [Math.round(Math.cos(deg * Math.PI / 180) * R), Math.round(Math.sin(deg * Math.PI / 180) * R)];
    const btn = (a, k, ic, tx, no, deg, cls) => { const [x, y] = cls === 'outer' ? [Math.round(Math.cos(deg * Math.PI / 180) * (R + 44)), Math.round(Math.sin(deg * Math.PI / 180) * (R + 44))] : at(deg); return `<button data-a="${a}" data-k="${k}" class="${no ? 'no ' : ''}${M.pick === a + ':' + k ? 'on ' : ''}${cls || ''}" style="left:${x}px;top:${y}px"><i>${ic}</i><b>${tx}</b></button>`; };
    let title, row = '', desc = '';
    if (!tw) {
      title = '🔨 Что построим?';
      TD_TOWERS.forEach((d, i) => { row += i < 5 ? btn('b', d.id, d.ic, d.lv[0].cost, c < d.lv[0].cost, -90 + i * 72) : btn('b', d.id, d.ic, d.lv[0].cost, c < d.lv[0].cost, -54 + (i - 5) * 72, 'outer'); });
      const pk = M.pick.startsWith('b:') ? TD_TW_BY[M.pick.slice(2)] : null;
      desc = pk ? `<b>${pk.ic} ${pk.nm}</b> – ${pk.ds}<br><span>${tdStatLine(pk, pk.lv[0], 1)}</span><u>Нажми ещё раз – построим</u>` : 'Нажми на башню – расскажу, что она умеет';
    } else {
      const d = tw.def, S = tdStat(d, tw.lvl, tw.sp), k = tdK(tw), sell = Math.round(tdSpent(tw) * TD_SELL);
      title = `${tw.lvl >= 4 ? S.ic : d.ic} ${tw.lvl >= 4 ? S.nm : d.nm} · ${tw.lvl >= 4 ? 'мастер' + (tw.boost ? ' +' + tw.boost : '') : 'ур. ' + tw.lvl}`;
      desc = `<span>${tdStatLine(d, S, k)}</span>` + (tw.fr ? '<br>🤝 +15% – рядом башня подруги' : NET.on && G.netRun ? '<br><small>🤝 Поставь рядом с башней подруги – обе станут сильнее</small>' : '');
      if (tw.lvl < 3) {
        const N = d.lv[tw.lvl]; row += btn('u', 0, '⬆️', N.cost, c < N.cost, -90);
        if (M.pick === 'u:0') desc = `Уровень ${tw.lvl + 1}:<br><span>${tdStatLine(d, N, 1)}</span><u>Нажми ещё раз – улучшим</u>`;
      } else if (tw.lvl === 3) {
        d.sp.forEach((N, i) => { row += btn('u', i, N.ic, N.cost, c < N.cost, i ? -40 : -140); });
        const i = M.pick === 'u:1' ? 1 : M.pick === 'u:0' ? 0 : -1;
        desc = i >= 0 ? `<b>${d.sp[i].ic} ${d.sp[i].nm}</b> – ${d.sp[i].ds}<br><span>${tdStatLine(d, d.sp[i], 1)}</span><u>Нажми ещё раз – выберем это мастерство</u>` : desc + '<br>Пора выбрать мастерство – одно из двух';
      } else {
        const cost = tdUpCost(tw, 0);
        if (cost !== null) { row += btn('u', 0, '💪', cost, c < cost, -90); if (M.pick === 'u:0') desc = `Усиление: +${Math.round(TD_BOOST.k * 100)}% ${tw.k === 'bank' ? 'к монеткам' : 'к силе'} (×${(k / (tw.fr ? 1 + TD_FRIEND.k : 1)).toFixed(2)} → ×${(k / (tw.fr ? 1 + TD_FRIEND.k : 1) * (1 + TD_BOOST.k)).toFixed(2)})<br><span>${tdStatLine(d, S, k * (1 + TD_BOOST.k))}</span><u>Нажми ещё раз – усилим</u>`; }
      }
      row += btn('s', 0, '💰', '+' + sell, false, 90, 'sell');
      if (M.pick === 's:0') desc = `Продать и вернуть ${sell} 🪙?<u>Нажми ещё раз – продадим</u>`;
    }
    ring.classList.toggle('wide', !tw);
    ring.innerHTML = `<div class="tdDisc"></div>${row}<div class="tdTip ${tipM}" style="left:${Math.round(off)}px"><div class="tdT">${title}</div><div class="tdD">${desc}</div></div>`;
  }
  function tdPanelTap(b) {
    if (!defOn() || !b) return;
    const M = G.td, A = G.abyss, sp = tdCurSpot(); if (!sp) return;
    const a = b.dataset.a, raw = b.dataset.k, k = a === 'b' ? raw : +raw, key = a + ':' + raw;
    M.selT = G.time; // пока с площадкой возятся, кольцо не гаснет
    if (M.pick !== key) { M.pick = key; Sound.sfx.click(); return; }
    const cost = a === 'b' ? TD_TW_BY[k].lv[0].cost : a === 'u' ? tdUpCost(sp.tw, k) : 0;
    if (a !== 's' && A.coins < cost) { RunStats.toast(`Нужно ${cost} 🪙 – монетки дают за врагов`); Sound.sfx.block(); A.coinNoT = G.time; return; }
    M.pick = '';
    if (tdAct(a, sp.i, k) && NET.client) { Effects.burst(sp.x, sp.y - 10, 10, '#ffd25a', 120); Sound.sfx.magic(); }
  }
  // дальность: у выбранной башни – её, у выбранной покупки – будущая
  function tdRingOf(sp) {
    const M = G.td, tw = sp.tw, p = M.pick;
    if (!tw) return p.startsWith('b:') ? TD_TW_BY[p.slice(2)].lv[0].rng : 0;
    if (tw.lvl < 3 && p === 'u:0') return tw.def.lv[tw.lvl].rng;
    if (tw.lvl === 3 && p.startsWith('u:')) return tw.def.sp[+p.slice(2)].rng;
    return tdStat(tw.def, tw.lvl, tw.sp).rng;
  }

  // ---------- героиня без сил и конец обороны ----------
  function defDown() {
    if (P.down) return;
    Challenges.buzz(220);
    P.down = true; P.hp = 0; P.revT = 0; P.stormT = 0; P.tdRev = 8; G.combo = 0;
    Effects.burst(P.x, P.y, 30, '#c9b3ff', 220); Sound.sfx.hurt();
    Screens.showBanner('Без сил!', NET.on && G.netRun ? 'Подруга поднимет – или кристалл вернёт силы через 8 с' : 'Кристалл вернёт силы через 8 секунд');
    if (G.st) G.st.deaths++;
  }
  function tdHeroTick(dt) {
    if (!P.down) return;
    P.inv = Math.max(P.inv, 0.3); P.tdRev = (P.tdRev === undefined ? 8 : P.tdRev) - dt;
    if (P.tdRev > 0) return;
    const C = G.core;
    P.down = false; P.revT = 0; P.x = C.x + rnd(-40, 40); P.y = C.y + 70; World.ensureWalkable(P); P.hp = Math.round(P.maxHp * 0.6); P.inv = 2.5; P.dashT = 0;
    Effects.burst(P.x, P.y, 26, '#ff8ad8', 220); Sound.sfx.heart(); Screens.showBanner('Снова в строю!', 'Кристалл поделился силой 💗');
  }
  function defLose() {
    const A = G.abyss, C = G.core; if (!A || A.done) return;
    Effects.burst(C.x, C.y - 20, 80, '#ff8ad8', 380); Effects.shockRing(C.x, C.y, '#ff8ad8', 360); G.shake = 18; Sound.sfx.shatter();
    defFinish(); defEndScreen();
  }
  function defFinish() {
    const A = G.abyss; if (!A || !A.def || A.done) return; A.done = true;
    const cleared = Math.max(A.passed, A.wave - 1, 0); A.cleared = cleared;
    if (cleared > A.passed) { A.passed = cleared; defWaveDone(cleared); }
    if (NET.host && G.netRun) NetT.send(-1, { t: 'dend', wave: cleared, time: Math.round(A.t), hp: G.core.hp });
    RunStats.recordRunEnd(`оборона «${TD_MAP_BY[A.map].nm}»: отбито волн ${cleared}`);
    if (G.td) { G.td.sel = -1; G.td.pick = ''; }
  }
  function defEndScreen() {
    const A = G.abyss, M = TD_MAP_BY[A.map], w = A.cleared || 0, best = (Saves.loadProfile().tdBest || {})[A.map];
    Session.state = 'dying'; P.down = false;
    setTimeout(() => {
      if (!G.abyss || G.abyss !== A) return;
      $('deadTitle').textContent = w >= 20 ? `🏆 Отбито волн: ${w}!` : w >= 10 ? `🛡️ Отбито волн: ${w}` : '💎 Кристалл разбит…';
      $('deadText').innerHTML = `${M.ic} ${M.nm} · волн отбито: <b>${w}</b> · ${RunStats.fmtT(A.t)}<br>Башен построено: ${A.built} · врагов: ${G.kills}` +
        (A.better ? '<br>🏆 Новый рекорд!' : best ? `<br>Рекорд: ${best.wave} ${plural(best.wave, 'волна', 'волны', 'волн')}` : '') + (NET.on && G.netRun && NET.client ? '<br>Заново начнёт хозяйка' : '');
      Screens.setState('dead');
    }, 900);
  }
  function lanesAhead() {
    const sum = G.abyss.next && G.abyss.next.sum;
    if (!sum) return '';
    const edges = new Set();
    for (const [i] of sum) {
      const lane = G.td.M.lanes[i];
      if (!lane) continue;
      const [x, y] = lane.pts[0];
      if (y === 0) edges.add(x < TD_W / 2 ? 'сверху слева' : 'сверху справа');
      else edges.add(x === 0 ? 'слева' : 'справа');
    }
    if (edges.has('сверху слева') && edges.has('сверху справа')) {
      const top = edges.size === 2 ? 'сверху с двух сторон' : 'сверху';
      edges.delete('сверху слева'); edges.delete('сверху справа'); edges.add(top);
    }
    return [...edges].join(', ');
  }
  function enemiesOnRoad() {
    let count = 0;
    for (const e of G.enemies) if (!e.dead && e.ln !== undefined) count++;
    return count;
  }
  function defInfo() {
    const A = G.abyss;
    const r = repairStatus();
    if (r) {
      if (r.repaired) return '💎 Кристалл починен · +1';
      return r.near < 2 ? '💎 Вдвоём к кристаллу · ' + r.near + '/2' : '💎 Ремонт · ' + r.progress + '%';
    }
    let status = '';
    if (A.q.length) status = ` · идут: ${A.q.length}`;
    else if (A.wave && A.passed < A.wave) {
      const left = NET.client ? A.enemiesOnRoad : enemiesOnRoad();
      status = left === undefined ? ' · идёт бой' : ' · добей: ' + left;
    }
    return `🛡️ ${A.wave ? 'Волна ' + A.wave : 'Готовься'}` + (A.twist ? ' ' + TD_TWIST_BY[A.twist].ic : '') + status;
  }

  // ---------- вместе: гостья ----------
  function defClientTick(dt) {
    const A = G.abyss, C = G.core, M = G.td; if (!A || A.done) return;
    A.t += dt; if (A.rest > 0 && !A.spawning) A.rest -= dt;
    if (A.hkW !== A.wave) { A.hkW = A.wave; A.heroK = tdHeroK(); }
    C.t += dt; if (C.flash > 0) C.flash -= dt;
    tdHeroTick(dt); tdSpellTick(dt);
    tdTowers(dt, false); tdShots(dt); tdPools(dt);
    const k = Math.min(1, dt * 14);
    for (const u of M.units) { u.t += dt; if (u.tx !== undefined) { u.mv = Math.abs(u.tx - u.x) + Math.abs(u.ty - u.y) > 2; u.x += (u.tx - u.x) * k; u.y += (u.ty - u.y) * k; } }
  }
  function defSnap() {
    const A = G.abyss, M = G.td, b = Session.bosses[0], r = A.repair;
    return [A.wave, G.core.hp, A.q.length || G.activeBoss || A.passed < A.wave ? -1 : Math.round(A.rest * 10), A.coins, A.passed,
      M.spots.filter(s => s.tw).map(s => [s.i, TD_TOWERS.indexOf(s.tw.def), s.tw.lvl, s.tw.sp, s.tw.boost, s.tw.silT > 0 ? 1 : 0, s.tw.by || 1]),
      M.units.map(u => [u.id, u.x | 0, u.y | 0, u.dead ? 0 : Math.max(1, Math.round(u.hp / u.maxHp * 100)), u.tw.temp ? -1 : u.tw.s, u.face > 0 ? 1 : 0]),
      A.next ? A.next.sum : 0, b && A.bw ? [b.kind, b.level, A.bw] : 0, A.q.length, A.twist || '', A.next ? A.next.tw || '' : '', A.votes ? [...A.votes] : [], 1 + Multiplayer.netLiveMates(),
      M.fac ? [M.fac.lvl, M.fac.workers, Math.floor(M.fac.crate), M.fac.found ? 1 : 0, M.fac.work] : 0,
      { left: enemiesOnRoad(), repair: r ? [r.near, r.progress] : null }];
  }
  function defNetApply(dz) {
    const A = G.abyss, C = G.core, M = G.td; if (!A || !A.def || A.done || !C || !M) return;
    const [w, hp, rest, coins, passed, tws, uns, nx, bk, ql, twist, ntw, votes, need, fc, team] = dz;
    A.enemiesOnRoad = team && team.left;
    const r = team && team.repair;
    A.repair = r ? { near: r[0], progress: r[1], repaired: r[1] === 100 } : null;
    if (fc && M.fac) { const F = M.fac, was = F.found; F.lvl = fc[0]; F.workers = fc[1]; F.crate = fc[2]; F.found = !!fc[3]; F.work = fc[4]; if (F.found && !was) KrillFactory.tdFacBan(); }
    A.votes = new Set(votes || []); A.need = need || 2;
    A.twist = twist || '';
    A.wave = w; A.spawning = rest < 0; if (rest >= 0) A.rest = rest / 10; A.coins = coins; A.passed = passed; A.q = { length: ql || 0 };
    if (hp < C.hp) tdCoreFx(C.hp - hp);
    if (hp > C.hp && A.repair && A.repair.repaired) repairFx();
    C.hp = hp;
    A.next = nx ? { sum: nx, tw: ntw || '' } : null;
    if (bk && A.bw !== bk[2]) { // хозяйка выпустила стража – у гостьи он тоже должен появиться
      A.bw = bk[2]; World.CFG.bosses = [bk[0]]; World.CFG.bossLevels = [bk[1]]; World.CFG.bossTiles = [{ x: Math.floor(C.x / World.T), y: Math.floor(C.y / World.T) }]; G.defeated = [false];
      if (BOSSES[bk[0]]) Bosses.makeBosses();
    }
    const seen = new Set();
    for (const [s, ti, lvl, spc, boost, sil, by] of tws || []) {
      const sp = M.spots[s], def = TD_TOWERS[ti]; if (!sp || !def) continue;
      seen.add(s);
      const tw = sp.tw;
      if (tw) { tw.silT = sil ? 0.6 : 0; tw.by = by || 1; }
      if (!tw || tw.def !== def) { sp.tw = { s, k: def.id, def, lvl, sp: spc, boost, x: sp.x, y: sp.y, cd: 0.4, t: 0, aim: -Math.PI / 2, shot: 0, by: by || 1 }; tdFx(sp, def.col); }
      else if (tw.lvl !== lvl || tw.sp !== spc || tw.boost !== boost) { tw.lvl = lvl; tw.sp = spc; tw.boost = boost; tdFx(sp, def.col); }
    }
    for (const sp of M.spots) if (sp.tw && !seen.has(sp.i)) { sp.tw = null; Effects.burst(sp.x, sp.y - 10, 14, '#ffd25a', 130); }
    const old = new Map(M.units.map(u => [u.id, u]));
    M.units = [];
    for (const [id, x, y, hpP, s, f] of uns || []) {
      const tw = s < 0 ? (M.tempTw || (M.tempTw = { def: TD_TW_BY.cats, lvl: 3, sp: -1, boost: 0, temp: true, stat: { n: 3, hp: 100, dmg: 0, cd: 1, rng: 140 } })) : M.spots[s] && M.spots[s].tw; if (!tw) continue;
      const u = old.get(id) || { id, x, y, t: 0 };
      u.tx = x; u.ty = y; u.dead = !hpP; u.hp = hpP; u.maxHp = 100; u.tw = tw; u.face = f ? 1 : -1;
      M.units.push(u);
    }
  }

  return {
    defOn, tdScale, tdHeroK, tdTwist, tdPortal, tdMapOpen, tdMapPick, startDefense, tdMakeWave,
    tdSpawn, defWave, tdEnemyTick, tdSpent, tdUpCost, tdTargets, tdUS, tdSpellBtn, tdCast,
    tdAct, tdDo, tdCurSpot, tdTap, tdPanelSync, tdPanelTap, tdRingOf, defDown, defFinish,
    defEndScreen, defInfo, defClientTick, defSnap, defNetApply, defUpdate, tdSurvived,
    defWaveDone, tdCall, tdCoreHit, repairStatus, REPAIR_RADIUS, REPAIR_SECONDS, teamHudY,
    get TD_HIT() { return TD_HIT; },
  };
})();
