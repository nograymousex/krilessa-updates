'use strict';

// A reverse distance field is shared by the chapter chart and all three minimaps.
const Navigation = (() => {
  let field = null,
    lastStart = -1,
    points = [];
  function build(goal) {
    const w = World.MW,
      h = World.PLAY_H,
      distance = new Uint16Array(w * h),
      queue = new Int32Array(w * h);
    const enter = (x, y, i, d) => {
      if (x < 0 || y < 0 || x >= w || y >= h || distance[i] || World.isSolidTile(x, y, false)) return;
      distance[i] = d;
      queue[end++] = i;
    };
    let end = 0;
    enter(goal % w, Math.floor(goal / w), goal, 1);
    for (let cur = 0; cur < end; cur++) {
      const i = queue[cur],
        x = i % w,
        y = (i - x) / w,
        d = distance[i] + 1;
      enter(x - 1, y, i - 1, d);
      enter(x + 1, y, i + 1, d);
      enter(x, y - 1, i - w, d);
      enter(x, y + 1, i + w, d);
    }
    return distance;
  }
  function follow(s, goal) {
    const w = World.MW,
      d = field.distance;
    if (!d[s]) return [];
    const cells = [s];
    let i = s,
      heading = 0;
    while (i !== goal) {
      let next = -1,
        best = -Infinity;
      for (const step of [-w, 1, w, -1]) {
        const k = i + step;
        if (d[k] !== d[i] - 1) continue;
        const tile = World.tiles[k],
          score = (tile === PATH || tile === STONE ? 3 : 0) + (heading === step ? 2 : 0);
        if (score > best) {
          best = score;
          next = k;
        }
      }
      if (next < 0) return [];
      heading = next - i;
      i = next;
      cells.push(i);
    }
    // Collapse only collinear runs. Every drawn segment stays on the tested walkable cells.
    return cells
      .filter((v, j) => !j || j === cells.length - 1 || v - cells[j - 1] !== cells[j + 1] - v)
      .map((v) => ({ x: World.tc(v % w), y: World.tc(Math.floor(v / w)) }));
  }
  function route() {
    if (
      typeof World.CHN !== 'number' ||
      !Session.bosses.length ||
      P.y >= World.PLAY_H * World.T ||
      G.jump
    )
      return [];
    const target = Simulation.objective(),
      w = World.MW,
      x = Math.floor(target.x / World.T),
      y = Math.floor(target.y / World.T);
    const sx = Math.floor(P.x / World.T),
      sy = Math.floor(P.y / World.T);
    if (
      x < 0 ||
      x >= w ||
      y < 0 ||
      y >= World.PLAY_H ||
      sx < 0 ||
      sx >= w ||
      sy < 0 ||
      sy >= World.PLAY_H
    )
      return [];
    const goal = y * w + x,
      start = sy * w + sx,
      melted = (G.melted || []).length,
      bridge = !!(World.landscape && World.landscape.bridgeOpen);
    if (
      !field ||
      field.tiles !== World.tiles ||
      field.goal !== goal ||
      field.gate !== World.gateOpen ||
      field.bridge !== bridge ||
      field.melted !== melted
    ) {
      field = { tiles: World.tiles, goal, gate: World.gateOpen, bridge, melted, distance: build(goal) };
      lastStart = -1;
    }
    if (lastStart !== start) {
      points = follow(start, goal);
      lastStart = start;
    }
    return points;
  }
  function draw(c, path, X, Y, color, width = 2, limit = Infinity) {
    if (path.length < 2) return;
    c.save();
    c.lineCap = 'round';
    c.lineJoin = 'round';
    c.beginPath();
    c.moveTo(X(P.x), Y(P.y));
    let traveled = 0;
    for (let i = 0; i < path.length; i++) {
      const p = path[i],
        prev = i ? path[i - 1] : P,
        dist = Math.hypot(p.x - prev.x, p.y - prev.y);
      if (traveled + dist > limit) {
        const f = (limit - traveled) / dist;
        c.lineTo(X(prev.x + (p.x - prev.x) * f), Y(prev.y + (p.y - prev.y) * f));
        break;
      }
      c.lineTo(X(p.x), Y(p.y));
      traveled += dist;
    }
    c.strokeStyle = '#29332d';
    c.lineWidth = width + 1.8;
    c.stroke();
    c.strokeStyle = color;
    c.lineWidth = width;
    c.setLineDash([4, 3]);
    c.stroke();
    c.restore();
  }
  return { route, draw };
})();
