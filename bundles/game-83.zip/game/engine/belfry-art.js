'use strict';

const BelfryArt = (() => {
  const art = {};
  function picture(name) {
    if (!art[name]) {
      art[name] = new Image();
      art[name].src = 'art/bell-' + name + '.webp';
    }
    return art[name];
  }
  function drawScene(c, w, h, sc, t) {
    const img = picture(sc.art),
      f = sc.fx || 0.5;
    c.fillStyle = '#141a1b';
    c.fillRect(0, 0, w, h);
    if (!img.naturalWidth) return;
    const portrait = h > w,
      boxH = portrait ? h * 0.63 : h,
      top = portrait ? h * 0.09 : 0,
      zoom = 1 + 0.018 * Math.min(1, t / 4);
    const k = Math.max(w / img.width, boxH / img.height) * zoom,
      dw = img.width * k,
      dh = img.height * k;
    c.save();
    c.beginPath();
    c.rect(0, top, w, boxH);
    c.clip();
    c.drawImage(img, (w - dw) * f, top + (boxH - dh) * 0.47, dw, dh);
    c.restore();
    const g = c.createLinearGradient(0, h * 0.52, 0, h);
    g.addColorStop(0, 'rgba(13,18,19,0)');
    g.addColorStop(1, '#101719');
    c.fillStyle = g;
    c.fillRect(0, h * 0.52, w, h * 0.48);
  }
  // Water recedes to the lower ring after each sluice. The brass tide marks stay on the stone.
  function basin(c, vis) {
    const x = World.tc(World.CASTLE.x), y = World.tc(World.CASTLE.y);
    const radius = (World.CASTLE.half - .8) * World.T;
    if (!vis(x, y, radius + World.T * 2)) return;
    const closed = 2 - Bosses.guardiansDone();
    c.save();
    c.translate(x,y);
    for (const frac of [.38,.65,.94]) {
      c.beginPath(); c.arc(0,0,radius*frac,0,TAU);
      c.strokeStyle = '#b8aa837d'; c.lineWidth = 3; c.stroke();
    }
    if (closed > 0) {
      const r = radius * (closed === 2 ? .96 : .64);
      const water = c.createRadialGradient(0,0,3,0,0,r);
      water.addColorStop(0,'#163c52ed'); water.addColorStop(.85,'#315c6be8'); water.addColorStop(1,'#79a9a9dc');
      c.fillStyle = water; c.beginPath(); c.arc(0,0,r,0,TAU); c.fill();
      c.lineWidth = 2; c.strokeStyle = '#c9e4de8a';
      for(let i=0;i<5;i++){
        const f = (i+.5)/5;
        c.beginPath(); c.ellipse(Math.sin(i*9)*r*.18,(f-.5)*r, r*(.15+f*.26),3+Math.sin(G.time*1.3+i),0,.12,2.85); c.stroke();
      }
    } else {
      c.strokeStyle='#ab9369'; c.lineWidth=3;
      for(let i=0;i<12;i++){
        const a=i*TAU/12; c.beginPath(); c.moveTo(Math.cos(a)*radius*.88, Math.sin(a)*radius*.88);
        c.lineTo(Math.cos(a)*radius*.94,Math.sin(a)*radius*.94);c.stroke();
      }
    }
    c.translate(0, World.CASTLE.half * World.T);
    const w=World.T*1.5;
    for(const side of [-1,1]){
      const x=side*(w+6); c.fillStyle='#364d54'; c.fillRect(x-6,-22,12,40);
      c.fillStyle='#d2b280'; c.fillRect(x-7,-24,14,6);
    }
    if(!World.gateOpen){
      c.fillStyle='#3f5559'; c.fillRect(-w,-18,w*2,9); c.fillRect(-w,3,w*2,7);
      for(let i=-3;i<=3;i++){ c.fillStyle='#b89968'; c.fillRect(i*w/3-2,-21,5,32); }
    }
    c.restore();
  }
  for (const kind of ['chainWarden','sluiceHeron','hollowBell']) {
    const sprite = picture(kind);
    BSPR[kind] = (c,b,t) => {
      const r = BOSSES[kind].r, h = r * 2.7;
      c.save();
      c.translate(0,Math.sin(t*(kind==='sluiceHeron'?3:1.7))*1.8);
      if(sprite.naturalWidth){
        const w = h*sprite.width/sprite.height;
        if (b.flash > 0) c.filter='brightness(1.65)';
        c.drawImage(sprite,-w/2,-h*.63,w,h);
      } else {
        c.fillStyle=BOSSES[kind].col; c.beginPath(); c.ellipse(0,-6,r*.7,r,0,0,TAU); c.fill();
      }
      c.restore();
    };
  }
  return { drawScene, basin };
})();
