'use strict';

const Screens = (() => {
  // ------------------------------------------------------------------
  //  Диалоги и баннеры
  // ------------------------------------------------------------------
  const Dialog = {
    queue: [], cur: null, t: 0, shown: -1,
    get talking() { return !!(this.cur && this.cur.pause); },
    update(dt) {
      if (!this.cur && this.queue.length) {
        this.cur = this.queue.shift(); this.t = 0; this.shown = -1;
        const who = this.cur.who;
        const heroine = who === 'ryzhova' || who === 'krilessa' || who === 'tessa';
        $('dlgName').textContent = who === 'ryzhova' ? 'Рыжовая' : who === 'krilessa' ? 'Крилесса' : who === 'tessa' ? 'Тесса' : BOSSES[who].name;
        $('dialog').classList.toggle('boss', !heroine);
        $('dialog').classList.toggle('teamRush', !!(G.netRun && G.rush));
        const dc = $('dlgAvatar').getContext('2d'); dc.clearRect(0, 0, 116, 116);
        if (Session.AVATAR[who]) dc.drawImage(Session.AVATAR[who], 0, 0, 116, 116);
        $('dialog').classList.remove('hidden');
        // речь босса: игра на паузе, пока не коснёшься экрана
        $('dialog').classList.toggle('wait', !!this.cur.pause);
        $('talkTap').classList.toggle('hidden', !this.cur.pause);
        if (this.cur.pause) { Controls.input.touchId = null; Controls.input.mx = 0; Controls.input.my = 0; }
      }
      if (!this.cur) return;
      this.t += dt;
      const n = Math.min(this.cur.text.length, Math.floor(this.t * 42));
      if (n !== this.shown) { this.shown = n; $('dlgText').textContent = this.cur.text.slice(0, n); }
      if (!this.cur.pause && this.t > this.cur.dur) this.close();
    },
    advance() {
      if (!this.cur) return;
      if (this.shown < this.cur.text.length) { this.t = 99; this.shown = this.cur.text.length; $('dlgText').textContent = this.cur.text; return; }
      this.close();
    },
    close() { this.cur = null; $('dialog').classList.add('hidden'); $('talkTap').classList.add('hidden'); },
    clear() { this.queue.length = 0; this.close(); },
  };
  function say(text, dur) { if (!text) return; Dialog.queue.push({ text, who: World.CFG.hostage || 'ryzhova', dur: dur || Math.max(3.2, text.length * 0.06) }); }
  function speak(kind, text, dur, pause = true) {
    if (!text) return;
    if (NET.host && G.netRun) NetT.send(-1, { t: 'spk', k: kind, text, d: dur || 0 });
    if (!Session.AVATAR[kind]) Session.AVATAR[kind] = BOSSES[kind].avatar ? Session.AVATAR[BOSSES[kind].avatar] : bossPortrait(kind);
    // реплики босса показываем сразу, героиня подождёт
    // В обороне и совместном раше бой продолжается во время реплик.
    if (G.td || (G.netRun && G.rush)) pause = false;
    Dialog.queue.unshift({ text, who: kind, dur: dur || Math.max(3.4, text.length * 0.065), pause });
    if (Dialog.cur && (Dialog.cur.who === 'ryzhova' || Dialog.cur.who === 'krilessa' || Dialog.cur.who === 'tessa')) Dialog.queue.push(Dialog.cur);
    Dialog.cur = null;
  }
  let bannerTimer = 0;
  function showBanner(big, sub) {
    const el = $('banner');
    $('bannerBig').textContent = big; $('bannerSub').textContent = sub || '';
    el.classList.remove('hidden', 'show'); void el.offsetWidth; el.classList.add('show');
    clearTimeout(bannerTimer); bannerTimer = setTimeout(() => el.classList.add('hidden'), 2700);
  }

  // ------------------------------------------------------------------
  //  Экраны
  // ------------------------------------------------------------------
  const screens = ['boot', 'intro', 'menu', 'levelup', 'pause', 'dead', 'victory', 'stats', 'whatsnew', 'teaser', 'zmenu', 'portal', 'choice', 'board', 'npc', 'wardrobe', 'mapscr', 'intros', 'relic', 'talents', 'admin', 'chapSheet', 'settings', 'splash', 'krill', 'joyedit', 'mp', 'modes', 'coll', 'ach', 'book', 'muts', 'hall', 'look', 'season', 'relics', 'home', 'starAtlas'];
  const listParents = {
    look: ['menu', 'coll'], hall: ['menu', 'coll'], talents: ['menu', 'coll'],
    intros: ['coll', 'menu'], chapSheet: ['menu', 'modes'], admin: ['menu', 'settings'],
  };
  const listSources = new Map();
  function leaveList(fallback) {
    const target = listSources.get(Session.state) || fallback;
    if (target === 'menu' && Session.state !== 'chapSheet') AdventureMenu.openMenu();
    else if (target === 'coll') Collection.openColl();
    else if (target === 'modes') Collection.openModes();
    else setState(target);
  }
  function setState(s) {
    const prev = Session.state;
    if (listParents[s] && listParents[s].includes(prev)) listSources.set(s, prev);
    Session.state = s;
    if(s!=='intro') document.body.classList.remove('belfryFilm');
    for (const n of screens) $(n).classList.toggle('hidden', n !== s && !(s === 'chapSheet' && n === 'menu')); // карточка главы – поверх карты
    if (prev !== s) {
      const page = $(s);
      const back = page && page.querySelector('.menuNav .menuBack');
      if (back) back.focus({ preventScroll: true });
    }
    $('hud').classList.toggle('hidden', s !== 'play');
    if (s === 'dead' || s === 'victory') {
      const teamMode = G.netRun && (NET.ch === 'rush' || NET.ch === 'defense');
      $(s === 'dead' ? 'btnDeadRoom' : 'btnVictoryRoom').classList.toggle('hidden', !(NET.host && teamMode));
      if (s === 'dead') $('btnRetry').classList.toggle('hidden', !!(teamMode && NET.client));
    }
    $('talkTap').classList.toggle('hidden', !(s === 'play' && Dialog.talking));
    $('dialog').classList.toggle('offscreen', s !== 'play' && s !== 'dying'); // диалог не висит поверх меню и карты
    if (s !== 'play') { Controls.input.touchId = null; Controls.input.mx = 0; Controls.input.my = 0; }
    if (s === 'settings' && prev !== s) {
      MenuActions.notifyLabel();
      MenuActions.orientLabel();
      Challenges.vibLabel();
      MenuActions.paintDiff();
    }
    if (s !== 'play' && !$('rotHint').classList.contains('hidden')) MenuActions.rotHintHide();
    if (Terrain.paperOn && !PAPER_SKIP.has(s)) paperScreen(s);
  }
  // ===== 1.0: тёмные плашки любых экранов становятся бумажными =====
  // экраны рисуются в разных местах кода; вместо правки каждого – после показа проходим по элементам:
  // тёмный фон → бумага с чернильной обводкой, светлый текст на бумаге → чернила. Перерисовка экрана – проходим снова
  const PAPER_SKIP = new Set(['settings', 'joyedit', 'stats', 'play', 'dying', 'splash', 'intro', 'menu', 'krill', 'zmenu', 'boot', 'teaser', 'pause', 'chapSheet', 'whatsnew', 'talents', 'modes', 'coll', 'mp', 'levelup', 'portal', 'muts', 'starAtlas']);
  const PAPER_OBS = new Map();
  const rgbOf = str => { const m = /rgba?\(([\d.]+),\s*([\d.]+),\s*([\d.]+)(?:,\s*([\d.]+))?/.exec(str || ''); return m ? [+m[1], +m[2], +m[3], m[4] === undefined ? 1 : +m[4]] : null; };
  const lum = c => (0.3 * c[0] + 0.59 * c[1] + 0.11 * c[2]) / 255;
  function darkBg(cs) {
    const bc = rgbOf(cs.backgroundColor); if (bc && bc[3] > 0.35 && lum(bc) < 0.42) return true;
    const bi = cs.backgroundImage; if (!bi || bi === 'none' || bi.includes('url(')) return false;
    const cols = [...bi.matchAll(/rgba?\([^)]+\)/g)].map(m => rgbOf(m[0])).filter(c => c && c[3] > 0.35);
    return cols.length > 0 && cols.reduce((a, c) => a + lum(c), 0) / cols.length < 0.42;
  }
  function paperize(root) {
    const rcs = getComputedStyle(root);
    if (!root.classList.contains('dim') && darkBg(rcs)) { root.style.background = 'radial-gradient(ellipse at 50% 10%, rgba(251,243,224,.97), rgba(232,214,178,.98) 80%)'; root.style.color = '#4b2e1e'; }
    const light = new Set([root.classList.contains('dim') ? null : root]);
    for (const el of root.querySelectorAll('*')) {
      if (el.tagName === 'CANVAS' || el.tagName === 'svg' || el.closest('svg') || el.classList.contains('btn')) continue;
      const cs = getComputedStyle(el);
      if (darkBg(cs)) {
        el.style.background = '#fffaf0'; el.style.color = '#4b2e1e';
        if (parseFloat(cs.borderTopWidth) > 0) el.style.borderColor = '#4b2e1e'; else if (parseFloat(cs.paddingTop) > 3) el.style.border = '1.5px solid rgba(75,46,30,.8)';
        el.style.boxShadow = '0 3px 0 rgba(75,46,30,.35)'; el.style.textShadow = 'none'; light.add(el);
      }
    }
    for (const el of root.querySelectorAll('*')) { // светлый текст на светлом фоне – в чернила
      if (el.tagName === 'CANVAS' || el.classList.contains('btn')) continue;
      let p = el, onLight = false; while (p && p !== root.parentNode) { if (light.has(p)) { onLight = true; break; } const bc = rgbOf(getComputedStyle(p).backgroundColor); if (bc && bc[3] > 0.5) { onLight = lum(bc) > 0.6; break; } p = p.parentElement; }
      if (!onLight) continue;
      const cs = getComputedStyle(el), tc = rgbOf(cs.color);
      if (tc && lum(tc) > 0.72 && el.childNodes.length && [...el.childNodes].some(n => n.nodeType === 3 && n.textContent.trim())) { el.style.color = lum(tc) > 0.9 ? '#4b2e1e' : '#8a3a1a'; el.style.textShadow = 'none'; }
    }
  }
  function paperScreen(id) {
    const root = $(id); if (!root) return;
    try { paperize(root); } catch (e) {}
    if (!PAPER_OBS.has(id) && window.MutationObserver) {
      let tm = 0; const ob = new MutationObserver(() => { if (tm) return; tm = setTimeout(() => { tm = 0; if (Session.state === id) { ob.disconnect(); try { paperize(root); } catch (e) {} ob.observe(root, { childList: true, subtree: true }); } }, 30); });
      ob.observe(root, { childList: true, subtree: true }); PAPER_OBS.set(id, ob);
    }
  }
  function refreshLevelHint() {
    $('lvHint').textContent = (G.freePicks > 0 ? '🎁 Стартовый набор · ' : '') + (G.pendingLv > 1 ? `Выбери улучшение (ещё ${G.pendingLv})` : 'Выбери улучшение');
    if (G.rush && G.rush.link && !G.rush.done) {
      const next = Session.bosses[G.rush.idx];
      if (next) $('lvHint').textContent += ` · Бой ${G.rush.idx + 1}/${G.rush.total} · ${next.name}`;
    }
  }
  function openLevelUp() {
    if (G.pendingLv <= 0) return;
    Challenges.buzz(25);
    setState('levelup');
    Sound.sfx.level();
    // три обычных варианта + особое улучшение главы отдельным слотом (не вытесняет основные)
    const avail = UPGRADES.filter(u => Actors.lv(u.id) < u.max && !u.ch), spec = UPGRADES.filter(u => Actors.lv(u.id) < u.max && u.ch && u.ch === World.CHN && !G.rush);
    const opts = [];
    while (opts.length < (Actors.talent('pick4') ? 4 : 3) && avail.length) opts.push(avail.splice(Math.floor(Math.random() * avail.length), 1)[0]);
    const extra = spec.length ? spec[Math.floor(Math.random() * spec.length)] : null;
    const evo = EVOS.find(e => !Actors.lv(e.id) && e.need.every(([k, n]) => Actors.lv(k) >= n)) || null; // эволюция готова – отдельная карточка сверху
    refreshLevelHint();
    const box = $('cards'); box.innerHTML = ''; box.classList.toggle('four', opts.length > 3);
    const mk = (u, i) => {
      const el = document.createElement('button');
      el.className = 'card' + (u.ch ? ' special' : '') + (u.need ? ' evo' : ''); el.style.animationDelay = (i * 0.07) + 's';
      const ov = HEROES[P.hero].names[u.id];
      const ic = ov ? ov[0] : u.ic, nm = ov ? ov[1] : u.nm, ds = ov ? ov[2] : u.ds;
      el.innerHTML = `<div class="ic">${ic}</div><div><div class="nm">${nm}</div><div class="ds">${ds}</div><div class="lv">${u.need ? '✨ Эволюция · ' + u.need.map(([k]) => upName(k)).join(' + ') : `Уровень ${Actors.lv(u.id)} → ${Actors.lv(u.id) + 1}`}</div></div>`;
      el.dataset.id = u.id;
      el.addEventListener('click', () => {
        P.up[u.id] = Actors.lv(u.id) + 1;
        if (G.st) G.st.ups.push(u.id);
        if (G.freePicks > 0) G.freePicks--;
        if (u.id === 'hp') P.hp = Math.min(P.maxHp + 30, P.hp + 30 + P.maxHp * 0.2);
        if (u.need) evoGot(u);
        Actors.computeStats();
        Sound.sfx.click();
        G.pendingLv--;
        Saves.saveGame();
        if (G.pendingLv > 0) openLevelUp(); else setState('play');
      });
      box.appendChild(el);
    };
    if (evo) {
      const dv = document.createElement('div'); dv.className = 'spDiv evoDiv'; dv.innerHTML = '<span>🌈 Эволюция готова!</span>'; box.appendChild(dv);
      mk(evo, 0);
      const d2 = document.createElement('div'); d2.className = 'spDiv'; d2.innerHTML = '<span>или обычное улучшение</span>'; box.appendChild(d2);
    }
    opts.forEach((u, i) => mk(u, i + (evo ? 1 : 0)));
    if (extra) {
      const dv = document.createElement('div'); dv.className = 'spDiv'; dv.style.animationDelay = (opts.length * 0.07) + 's';
      dv.innerHTML = '<span>✨ или особое – только в этой главе</span>'; box.appendChild(dv);
      mk(extra, opts.length + 1);
    }
    if (!opts.length && !extra && !evo) { G.pendingLv = 0; P.hp = P.maxHp; setState('play'); }
  }
  const upName = k => { const ov = HEROES[P.hero] && HEROES[P.hero].names[k]; const u = UPGRADES.find(x => x.id === k); return ov ? ov[1] : u ? u.nm : k; };
  function evoGot(e) {
    const pr = Saves.loadProfile(); pr.evoSeen = pr.evoSeen || {}; const first = !pr.evoSeen[e.id];
    if (first) pr.evoSeen[e.id] = Date.now(); Saves.saveProfile(pr);
    Achievements.life('evos'); setTimeout(() => { showBanner(`${e.ic} ${e.nm}!`, first ? 'Новая эволюция – она теперь в Кринжопедии' : e.ds); }, 150);
    Sound.sfx.win(); Challenges.buzz(120); Effects.burst(P.x, P.y, 50, '#fff3a0', 260); Effects.shockRing(P.x, P.y, '#ff8ad8', 260);
  }
  function pauseGame(shared, byName) {
    if (Session.state !== 'play') return;
    $('pauseStats').innerHTML =
      (Defense.defOn() ? `<b>🛡️ Оборона: ${TD_MAP_BY[G.abyss.map].nm}</b> · волна ${G.abyss.wave} · 💎 ${G.core.hp} · 🪙 ${G.abyss.coins}` : `<b>Глава ${World.CHN}: ${World.CFG.name}</b>`) + ` · ${HEROES[P.hero].name}<br>` +
      `❤️ HP ${Math.ceil(P.hp)}/${P.maxHp} · 🪶 урон ${Math.round(P.dmg)} · 💨 ${(1 / P.fireInt).toFixed(1)} выстр/с<br>` +
      `🎯 крит ${Math.round(P.crit * 100)}% (x${P.critMul.toFixed(2)}) · 🛡️ броня ${Math.round(P.armor * 100)}%<br>` +
      `💎 осколков ${P.shards} · ☠️ врагов ${G.kills} · 🔥 лучшее комбо ${G.bestCombo}<br>` +
      `🔑 ключей ${G.keys || 0}` + ((G.relics || []).length ? ' · ' + G.relics.map(id => RELICS[id].ic + ' ' + RELICS[id].name).join(', ') : '') + '<br>' +
      `🗺️ карта #${World.SEED % 10000} · 🌟 супер ${Math.floor(P.sp)}% · ⚖️ зона: ур. ${Actors.zoneE(World.biomeMap[clamp(Math.floor(P.y / World.T), 0, World.MH - 1) * World.MW + clamp(Math.floor(P.x / World.T), 0, World.MW - 1)])}`;
    $('coopSavePanel').classList.toggle('hidden', !(NET.on && G.netRun));
    $('coopSaveStatus').textContent = NET.ch === 'defense' ? 'Возвращение к строительству перед волной' : NET.ch === 'rush' ? 'Возвращение к началу текущего боя' : 'Возвращение к последней точке главы';
    $('pause').classList.add('quick'); Multiplayer.kickListSync();
    if (shared === true && NET.on && G.netRun && !NET.paused) netPause(1);
    $('pauseNote').textContent = NET.on && G.netRun ? (NET.paused ? `⏸ ${byName || 'Ты'} – пауза у всех. Коснись, чтобы продолжить` : '⏸ Вместе мир не замирает – друзья играют дальше') : '⏸ Игра стоит. Коснись, чтобы продолжить';
    setState('pause'); Sound.sfx.click();
  }
  function resumeGame(fromNet) { if (fromNet !== true && NET.on && G.netRun && NET.paused) netPause(0); setState('play'); }
  // общая пауза вместе: любой игрок ставит игру на паузу у всех, любой снимает. Хозяин рассылает решение всем
  function netPause(v) {
    if (!NET.on || !G.netRun) return;
    const by = NET.name || 'Игрок';
    if (NET.host) { netPauseApply(v, by); NetT.send(-1, { t: 'pz', v: v ? 1 : 0, by }); }
    else { NET.paused = !!v; NET.pauseBy = by; NetT.send(0, { t: 'pz', v: v ? 1 : 0, by }); }
  }
  function netPauseApply(v, by) {
    NET.paused = !!v; NET.pauseBy = by;
    if (v) { if (Session.state === 'play') pauseGame(false, by); else if (Session.state === 'pause') $('pauseNote').textContent = `⏸ ${by} – пауза у всех. Коснись, чтобы продолжить`; }
    else if (Session.state === 'pause') { setState('play'); RunStats.toast(`▶ ${by} продолжила игру`); }
  }
  $('btnPauseMore').addEventListener('click', () => { $('pause').classList.remove('quick'); Sound.init(); Sound.sfx.click(); });
  $('pause').addEventListener('pointerdown', e => { if (e.target === $('pause') && $('pause').classList.contains('quick') && Session.state === 'pause') resumeGame(); });
  function playerDied() {
    Effects.burst(P.x, P.y, 40, '#c9b3ff', 260); Challenges.buzz(260); Achievements.life('deaths');
    if (G.abyss) { if (G.abyss.def) Defense.defFinish(); else Challenges.abyssFinish(); }
    if (G.daily) Challenges.dailyFinish(false);
    if (G.st) { G.st.deaths++; if (G.st.cur) G.st.cur.d++; }
    if (G.rush) Challenges.rushFinish(false);
    const run = G.st;
    setTimeout(() => {
      if (Session.state !== 'dying' || G.st !== run) return;
      const R = G.rush;
      $('deadTitle').textContent = R ? 'Босс-раш окончен' : G.team ? 'Обе героини без сил…' : `${HEROES[P.hero].name} без сил…`;
      $('deadText').innerHTML = R ? `Побеждено боссов: <b>${R.idx}/${R.total}</b> за ${RunStats.fmtT(R.t)}${R.link ? '<br>Командных связок: <b>' + R.links + '</b>' : ''}${R.better ? '<br>🏆 Новый рекорд!' : ''}`
        : World.CFG.deadText ? World.CFG.deadText : (World.CHN === 3 ? 'Крилесса всё ещё ждёт!' : 'Рыжовая всё ещё ждёт!') + ' Попробуй снова –<br>уровень и улучшения сохранятся.';
      if (G.abyss && G.abyss.def) { $('deadTitle').textContent = '💎 Оборона окончена'; $('deadText').innerHTML = `Отбито волн: <b>${G.abyss.cleared || 0}</b>`; }
      else if (G.abyss) { const ab = Saves.loadProfile().abyssBest; $('deadTitle').textContent = `🕳️ Бездна: волна ${G.abyss.wave}`; $('deadText').innerHTML = `Продержалась ${RunStats.fmtT(G.abyss.t)}, врагов: ${G.kills}` + (G.abyss.better ? '<br>🏆 Новый рекорд!' : ab ? `<br>Рекорд: волна ${ab.wave}` : ''); }
      if (G.daily) { $('deadTitle').textContent = '📅 Испытание дня'; $('deadText').innerHTML = `Очков: <b>${RunStats.fmtN(G.daily.score)}</b> · лучший сегодня: ${RunStats.fmtN(G.daily.best || 0)}<br>Можно попробовать ещё раз!`; }
      setState('dead');
    }, 700);
    Session.state = 'dying';
  }
  function respawn() {
    if (G.abyss && G.abyss.def) { if (NET.on && G.netRun) { if (NET.host) Multiplayer.mpGo(); else RunStats.toast('Заново начнёт хозяйка 🏠'); return; } Defense.startDefense(G.abyss.map); return; }
    if (World.CFG.abyss) { Challenges.startAbyss(); return; }
    if (G.daily) { Challenges.startDaily(); return; }
    if (G.rush) { if (NET.on && G.netRun) { if (NET.host) Multiplayer.mpGo(); else RunStats.toast('Заново начнёт хозяйка 🏠'); return; } Challenges.startRush(); return; }
    if (G.finalFinal) {
      // подлянка: бой с бессмертным начинается заново
      G.finalFinal.t = 0; G.finalFinal.bank = 0; G.finalFinal.said = {};
      G.enemies.length = 0; G.ebullets.length = 0; G.hazards.length = 0; G.feathers.length = 0; G.beams.length = 0;
      P.x = G.cp.x; P.y = G.cp.y; P.hp = P.maxHp; P.inv = 2.5; P.dashT = 0; P.slowT = 0;
      Dialog.clear(); say('Я с тобой, Рыжовая! Ещё раз – вместе!');
      setState('play');
      return;
    }
    for (const b of Session.bosses) if (b.state === 'fight') Bosses.resetBoss(b);
    for (const ch of World.chests) if (ch.mimic && ch.open && !ch.mimicDone) ch.open = false; // мимик снова прячется
    G.activeBoss = null;
    if (G.activeShrine) { G.activeShrine.state = 'idle'; G.activeShrine = null; }
    // чемпион не исчезает после смерти героини: остаётся на карте с тем же здоровьем
    const champ = G.champ && !G.champ.dead && G.enemies.includes(G.champ) ? G.champ : null;
    G.enemies.length = 0; G.ebullets.length = 0; G.hazards.length = 0; G.feathers.length = 0; G.beams.length = 0;
    if (champ) {
      const d = Math.hypot(champ.x - G.cp.x, champ.y - G.cp.y);
      // не караулит у точки возрождения, но и не теряется далеко – ждёт в паре экранов (корона на карте)
      if (d < 520 || d > 1600) {
        const base = Math.atan2(champ.y - G.cp.y, champ.x - G.cp.x), R = d < 520 ? 620 : 900;
        for (let k = 0; k < 32; k++) {
          const a = base + (k ? rnd(-1.6, 1.6) : 0), x = G.cp.x + Math.cos(a) * R, y = G.cp.y + Math.sin(a) * R;
          if (Physics.walkable(x, y, !!champ.def.fly) && y < World.PLAY_H * World.T) { champ.x = x; champ.y = y; break; }
        }
      }
      champ.jd = 0; champ.wind = 0; champ.slowT = 0; champ.burnT = 0;
      G.enemies.push(champ);
    }
    P.x = G.cp.x; P.y = G.cp.y; P.hp = P.maxHp; P.inv = 2; P.dashT = 0; P.slowT = 0; P.lives = HEROES[P.hero].lives || 0; G.invertT = 0; G.staticT = 0; G.jump = null; P.z = 0;
    G.combo = 0;
    if (Actors.talent('super')) P.sp = Math.max(P.sp, 25 * Actors.talent('super'));
    if (G.team) { for (const id of G.team.list) { G.team.f[id] = 1; G.team.ko[id] = false; } G.team.bx = P.x; G.team.by = P.y; }
    if (G.tessaAlly && !World.CFG.tessaStart) { G.tessaAlly = null; G.pet = null; } // бой с Мраком заново – Тесса снова во льду
    G.blizzardT = 0; G.wxId = null; G.wxT = 0; G.falling = []; G.chill = 0;
    Dialog.clear(); say(`Я жду тебя, ${HEROES[P.hero].name}! Не сдавайся!`);
    setState('play');
    Encounters.biomeMusic(true);
  }
  function showVictory(mode) {
    if (mode === 'daily') { Dialog.clear(); $('victoryButtons').classList.remove('hidden'); Collection.victoryExtras('daily'); setState('victory'); return; }
    showVictory0(mode); Collection.victoryExtras(mode);
  }
  function showVictory0(mode) {
    Dialog.clear();
    $('victoryButtons').classList.remove('hidden');
    if (mode === 'rush') {
      const R = G.rush, vc0 = $('victoryPortrait').getContext('2d');
      vc0.clearRect(0, 0, 300, 300); vc0.drawImage(heroPortrait(P.hero, 300), 0, 0, 300, 300);
      $('victoryTitle').textContent = '⚔️ Босс-раш пройден!';
      $('victoryStats').innerHTML = `Все <b>${R.total}</b> боссов за <b>${RunStats.fmtT(R.t)}</b>${R.link ? '<br>Командных связок: <b>' + R.links + '</b>' : ''}${R.better ? '<br>🏆 Новый рекорд!' : ''}`;
      $('victoryNext').classList.add('hidden'); $('victoryTeaser').classList.add('hidden');
      setState('victory');
      return;
    }
    if (World.CHN === 8) {
      const c=$('victoryPortrait').getContext('2d');
      c.clearRect(0,0,300,300);
      c.drawImage(heroPortrait('ryzhovaya',300),0,0,300,300);
      $('victoryTitle').textContent='Колокол замолк';
      $('victoryStats').textContent='Оба шлюза открыты. Звонарка повержена. Время в главе '+RunStats.fmtT(G.time)+'.';
      $('victoryNext').classList.add('hidden');
      $('victoryTeaser').classList.add('hidden');
      setState('victory');
      return;
    }
    if (World.CHN === 7) {
      const v7 = $('victoryPortrait').getContext('2d'); v7.clearRect(0, 0, 300, 300);
      v7.drawImage(heroPortrait('krilessa', 300), 0, 0, 300, 300);
      const small7 = (img, x, y, col) => { if (!img) return; v7.save(); v7.beginPath(); v7.arc(x, y, 46, 0, TAU); v7.clip(); v7.drawImage(img, x - 46, y - 46, 92, 92); v7.restore(); v7.strokeStyle = col; v7.lineWidth = 5; v7.beginPath(); v7.arc(x, y, 46, 0, TAU); v7.stroke(); };
      small7(Session.AVATAR.ryzhova, 56, 245, '#ff7a2f'); small7(Session.AVATAR.tessa, 245, 245, '#6ae0ff');
      const m7 = Math.floor(G.time / 60), s7 = Math.floor(G.time % 60), got = World.pearls.filter(q => q.got).length;
      $('victoryTitle').textContent = 'Крилюбовь победила!';
      $('victoryStats').innerHTML = 'Крильятин сдулся и признался: он просто хотел, чтобы его <b>крилюбили</b>. 🦐💗<br>Теперь он краснеет не от злости, а от смущения.<br>' +
        `Слов найдено: <b>${got}/${World.pearls.length}</b> · Время: <b>${m7}:${String(s7).padStart(2, '0')}</b> · Уровень: <b>${P.level}</b> · Врагов: <b>${G.kills}</b>`;
      $('victoryTeaser').innerHTML = CHAPTERS[8] ? 'Глава 8 открыта!' : '…а глава 8 уже строится. Скоро! 🚧';
      $('victoryNext').classList.toggle('hidden', !CHAPTERS[8]); $('victoryNext').textContent = 'Глава 8 →';
      $('victoryTeaser').classList.remove('hidden');
      setState('victory'); Sound.music('truewin');
      return;
    }
    if (World.CHN === 6) {
      const v6 = $('victoryPortrait').getContext('2d'); v6.clearRect(0, 0, 300, 300);
      v6.drawImage(heroPortrait('krilessa', 300), 0, 0, 300, 300);
      const small6 = (img, x, y, col) => { if (!img) return; v6.save(); v6.beginPath(); v6.arc(x, y, 46, 0, TAU); v6.clip(); v6.drawImage(img, x - 46, y - 46, 92, 92); v6.restore(); v6.strokeStyle = col; v6.lineWidth = 5; v6.beginPath(); v6.arc(x, y, 46, 0, TAU); v6.stroke(); };
      small6(Session.AVATAR.ryzhova, 56, 245, '#ff7a2f'); small6(Session.AVATAR.tessa, 245, 245, '#bfeaff');
      const m6 = Math.floor(G.time / 60), s6 = Math.floor(G.time % 60);
      $('victoryTitle').textContent = 'Зима отступила!';
      $('victoryStats').innerHTML = 'Лёд растаял, Тесса на свободе, лето вернулось. ☀️<br>Мрак оттаял и впервые улыбнулся. Но его последние слова не дают покоя…<br>' +
        `Время: <b>${m6}:${String(s6).padStart(2, '0')}</b> · Уровень: <b>${P.level}</b> · Врагов: <b>${G.kills}</b>`;
      $('victoryTeaser').innerHTML = '…где-то далеко стало подозрительно тихо. 🤫' + (CHAPTERS[7] ? '<br>Глава 7 открыта!' : '');
      $('victoryNext').classList.toggle('hidden', !CHAPTERS[7]); $('victoryNext').textContent = 'Глава 7 →';
      $('victoryTeaser').classList.remove('hidden');
      setState('victory'); Sound.music('truewin');
      return;
    }
    if (World.CHN === 4 || World.CHN === 5) {
      const vc4 = $('victoryPortrait').getContext('2d'); vc4.clearRect(0, 0, 300, 300);
      vc4.drawImage(Session.AVATAR.tessaBig || heroPortrait('tessa', 300), 0, 0, 300, 300);
      const small = (img, x, y, col) => { if (!img) return; vc4.save(); vc4.beginPath(); vc4.arc(x, y, 44, 0, TAU); vc4.clip(); vc4.drawImage(img, x - 44, y - 44, 88, 88); vc4.restore(); vc4.strokeStyle = col; vc4.lineWidth = 5; vc4.beginPath(); vc4.arc(x, y, 44, 0, TAU); vc4.stroke(); };
      const mm = Math.floor(G.time / 60), ss = Math.floor(G.time % 60);
      const statLine = `Время: <b>${mm}:${String(ss).padStart(2, '0')}</b> · Уровень: <b>${P.level}</b> · Врагов: <b>${G.kills}</b>`;
      if (World.CHN === 4) {
        small(Session.AVATAR.glitchcat, 245, 245, mode === 'kind' ? '#ff6fb5' : '#3ff0a0');
        $('victoryTitle').textContent = mode === 'kind' ? 'Мяу.exe приручён!' : 'Дом спасён!';
        $('victoryStats').innerHTML = (mode === 'kind' ? 'Тесса не стала удалять вирус. Она просто потёрлась о него носом…<br>Мяу.exe впервые замурлыкал. <b>Добрая</b> кошка. 💗<br>'
          : 'Тесса удалила Мяу.exe. Лампочки больше не мигают, телевизор молчит.<br><b>Хорошая</b> кошка. 🛡️<br>') + statLine;
        $('victoryTeaser').innerHTML = '…а утром из всех мисок пропал корм. 🐟<br>Глава 5 открыта!';
      } else {
        small(ART.zyamaFace, 56, 245, '#ffd25a'); small(heroPortrait('krilessa', 88), 245, 245, '#bfeaff'); small(Session.AVATAR.ryzhova, 245, 56, '#ff7a2f');
        $('victoryTitle').textContent = 'Банкет!';
        $('victoryStats').innerHTML = 'Дело раскрыто: корм спрятал Зямочкккк – для банкета в честь Тессы!<br>Пришли все: Крилесса, Рыжовая, Пик, Гуля, Шуршик и даже Барон. 🎉<br>' + statLine;
        $('victoryTeaser').innerHTML = CHAPTERS[6] ? '…а ночью выпал снег. Посреди лета. ❄️<br>Глава 6 открыта!' : 'Продолжение следует… 🐾';
      }
      $('victoryNext').classList.toggle('hidden', !CHAPTERS[World.CHN + 1]);
      $('victoryNext').textContent = `Глава ${World.CHN + 1} →`;
      $('victoryTeaser').classList.remove('hidden');
      setState('victory'); Sound.music(World.CHN === 5 ? 'final5' : 'truewin');
      return;
    }
    const vc = $('victoryPortrait').getContext('2d');
    vc.clearRect(0, 0, 300, 300);
    if (Session.AVATAR.ryzhovaBig) vc.drawImage(Session.AVATAR.ryzhovaBig, 0, 0, 300, 300);
    if (World.CHN === 3) {
      vc.clearRect(0, 0, 300, 300);
      if (Session.AVATAR.ryzhovaBig) vc.drawImage(Session.AVATAR.ryzhovaBig, 0, 0, 300, 300);
      const kp = heroPortrait('krilessa', 120);
      vc.save(); vc.beginPath(); vc.arc(62, 238, 56, 0, TAU); vc.clip(); vc.drawImage(kp, 2, 178, 120, 120); vc.restore();
      vc.strokeStyle = '#bfeaff'; vc.lineWidth = 5; vc.beginPath(); vc.arc(62, 238, 56, 0, TAU); vc.stroke();
    }
    if (World.CHN >= 2 && ART.zyamaFace) {
      vc.save(); vc.beginPath(); vc.arc(240, 240, 52, 0, TAU); vc.clip(); vc.drawImage(ART.zyamaFace, 188, 188, 104, 104); vc.restore();
      vc.strokeStyle = '#ff3ea5'; vc.lineWidth = 5; vc.beginPath(); vc.arc(240, 240, 52, 0, TAU); vc.stroke();
      const em = emojiSprite(mode === 'true' ? '❤️' : '😭', 30); vc.drawImage(em, 250, 160, 50, 50);
    }
    const m = Math.floor(G.time / 60), s = Math.floor(G.time % 60);
    $('victoryTitle').textContent = ['', 'Рыжовая спасена!', 'Рыжовая снова свободна!', 'Крилесса спасена!'][World.CHN];
    $('victoryStats').innerHTML = [
      '', 'Крилесса освободила Рыжовую из Тёмного замка!<br>',
      'Зямочкккк повержен! (Но обещал вернуться в версии 0.03…)<br>',
      'Рыжовая разбила Зеркальный дворец и спасла подругу!<br>Зямочкккк попросил у неё автограф 🥲 Конец трилогии… или нет? 👀<br>'][World.CHN] +
      `Время: <b>${m}:${String(s).padStart(2, '0')}</b> · Уровень: <b>${P.level}</b> · Врагов: <b>${G.kills}</b> · Осколков: <b>${P.shards}</b>`;
    $('victoryNext').classList.toggle('hidden', World.CHN >= 3 && !(World.CHN === 3 && mode === 'true'));
    $('victoryTeaser').classList.toggle('hidden', World.CHN >= 3);
    $('victoryNext').textContent = `Глава ${World.CHN + 1} →`;
    $('victoryTeaser').innerHTML = World.CHN === 1 ? '…но в небе уже открылся кринжовый портал.<br>Глава 2 открыта!'
      : '…Зямочкккк сдержал слово и вернулся в 0.03!<br>Глава 3 открыта – играешь за Рыжовую! 🔥';
    if (mode === 'true') {
      $('victoryTitle').textContent = 'НАСТОЯЩАЯ ПОБЕДА!';
      $('victoryStats').innerHTML = 'Рыжовая и Крилесса вместе одолели Зямочкккк ∞!<br>Он поклонился, сказал «браво» и ушёл пить какао ❤️<br><b>Трилогия завершена!</b><br>' +
        `Время: <b>${m}:${String(s).padStart(2, '0')}</b> · Уровень: <b>${P.level}</b> · Врагов: <b>${G.kills}</b>`;
      $('victoryTeaser').innerHTML = '…но кто это мурлычет в темноте? 🐾<br>Глава 4 открыта – играешь за Тессу!';
      $('victoryTeaser').classList.remove('hidden');
    }
    setState('victory');
    if (World.CHN === 3 && !mode && !G.trueWin && !NET.on) { $('victoryButtons').classList.add('hidden'); Story.later(4800, Story.startTrick); }
  }

  return {
    Dialog, say, speak, showBanner, setState, leaveList, refreshLevelHint, openLevelUp, pauseGame, resumeGame, netPauseApply,
    playerDied, respawn, showVictory,
  };
})();
