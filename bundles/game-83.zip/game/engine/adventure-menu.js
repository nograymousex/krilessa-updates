'use strict';

const AdventureMenu = (() => {
  // ------------------------------------------------------------------
  //  Меню
  // ------------------------------------------------------------------
  // карточки секретных глав: название показываем только когда глава открыта
  const SECRET_CARDS = {
    4: { title: 'Ночь глитчей', locked: 'Хорошая… или добрая?..', open: 'Хорошая… или добрая?.. Новая героиня ждёт 🐾' },
    5: { title: 'Пропавший корм', locked: 'Кто-то что-то съел…', open: 'Кто украл корм? Уютный детектив 🕵️' },
    6: { title: 'Мрак: новый сезон', locked: 'Кто-то выключил лето…', open: 'Зима пришла не одна. Играешь вдвоём ❄️' },
    7: { title: 'Крилевая бездна', locked: 'Где-то в глубине стало подозрительно тихо…', open: 'Под воду! Течения, жемчужины со словами и кто-то очень ругучий на дне 🦐' },
  };
  function drawMenuPortrait() {
    const c = $('menuPortrait').getContext('2d');
    c.clearRect(0, 0, 240, 320);
    if (Session.IMG.ryzhova) {
      // крупно лицо – в шапке меню портрет маленький
      const cv = Session.IMG.ryzhova.cartoon, f = Session.IMG.ryzhova.face || { x: 0.5, y: 0.4, r: 0.3 };
      const R = cv.width * f.r * 1.25, cx = cv.width * f.x, cy = cv.height * f.y;
      c.drawImage(cv, cx - R * 0.75, cy - R, R * 1.5, R * 2, 0, 0, 240, 320);
    }

  }
  // шапка меню: рамка портрета, эмблема, звание и слава
  function menuGlory(pr) {
    const g = Achievements.gloryOf(pr), lk = Achievements.myLook(pr), fr = lookItem('fr', lk.fr), mp = $('mPortrait');
    mp.style.setProperty('--fb', fr.b); mp.style.setProperty('--fa', fr.a || 'none'); mp.style.setProperty('--fg', fr.glow || 'rgba(0,0,0,0)');
    mp.classList.toggle('live', !!fr.a);
    $('mEmb').innerHTML = avatarHtml(lk, 26);
    $('mRank').textContent = `${g.rank.ic} ${Achievements.titleText(lk.ti, g.rk)} · ✨ ${RunStats.fmtN(g.fame)}`;
  }
  function openMenu() {
    GameLoop.liveClear(); // из забега вышли сами – это не вылет
    try { Achievements.lifeFlush(); } catch (e) { /* ignore */ }
    if (!NET.on && G.st) try { // вышли посреди забега: раш и испытание дня засчитываются, Бездну можно продолжить
      if (G.rush && !G.rush.done && G.rush.idx > 0) Challenges.rushFinish(false);
      if (G.daily && !G.daily.done && G.daily.score > 0) Challenges.dailyFinish(false);
      if (Defense.defOn() && !G.abyss.done && G.abyss.wave > 0) Defense.defFinish();
      if (G.abyss && !G.abyss.def && !G.abyss.done) { const ck = Challenges.abyssCkLoad(); if (ck) setTimeout(() => RunStats.toast(`🕳️ Бездна сохранена после волны ${ck.wave} – продолжить можно в «Режимах»`), 400); }
    } catch (e) { GameLoop.logErr(e, 'menu'); }
    if (NET.on && G.netRun) Multiplayer.mpLeave(true); // вышли из игры вместе – отключаемся
    G.inMenu = true;
    if ($('updBox').parentNode !== $('menu')) { $('mHead').after($('updBox')); MenuActions.showUpdate(); }
    if (World.CHN !== 1 || !World.tiles) Chapters.loadChapter(1);
    Chapters.resetRun();
    Bosses.makeBosses();
    const prof = Saves.loadProfile();
    renderMap(prof);
    $('btnWardrobe').classList.toggle('hidden', !(prof.ch3Done || GameLoop.DEBUG || prof.admin));
    const freeStars = (prof.stars || 0) - talentSpent(prof.talents || {});
    $('mStarsN').textContent = prof.stars || 0;
    $('talBadge').textContent = freeStars; $('talBadge').classList.toggle('hidden', freeStars <= 0);
    try { menuGlory(prof); } catch (e) { /* ignore */ }
    try { Seasons.seasonDaily(); } catch (e) { GameLoop.logErr(e, 'season'); }
    if (prof.talReset031) { delete prof.talReset031; Saves.saveProfile(prof); setTimeout(() => RunStats.toast('⭐ Таланты стали созвездиями – все звёзды вернулись. Распредели заново!'), 1500); }
    // интро – только после прохождения главы
    ['btnIntro', 'btnIntro2', 'btnIntro3', 'btnIntro4', 'btnIntro5', 'btnIntro6', 'btnIntro7','btnIntro8'].forEach((id, i) => {
      const done = GameLoop.DEBUG || prof.admin || prof['ch' + (i + 1) + 'Done'];
      $(id).classList.toggle('locked', !done);
      $(id).textContent = (done ? '' : '🔒 ') + 'Интро ' + (i + 1);
    });
    const rushOpen = GameLoop.DEBUG || prof.admin || prof.ch1Done;
    $('chapRush').classList.toggle('locked', !rushOpen);
    $('menu').querySelector('.version').textContent = 'v' + VERSION + (prof.admin ? ' · 🔓 админ' : '');
    MenuActions.updateSoundButtons();
    drawMenuPortrait();
    try { const A = window.KrilessaAndroid; const raw = A && A.updateInfo ? A.updateInfo() : ''; if (raw && !G.update) G.update = JSON.parse(raw); } catch (e) { /* ignore */ }
    MenuActions.showUpdate();
    Screens.setState('menu');
    Sound.music('menu');
    if (prof.ch4Done && !prof.ch4Choice && !G.pendingWhatsNew) { setTimeout(() => { if (Session.state === 'menu') HouseChapter.openChoice(true); }, 400); }
    if (G.pendingWhatsNew) { const from = G.pendingWhatsNew; G.pendingWhatsNew = null; setTimeout(() => Story.openWhatsNew(from === true ? null : from), 300); }
  }
  // ---------- стартовый экран (для тех, кто уже играл) ----------
  const SPLASH_EFFECTS = { 1: 'ff', 2: 'disco', 3: 'ember', 4: 'eyes', 5: 'paws', 6: 'snow', 7: 'sea' };
  const SP = { firstJourney: false, raf: 0, t: 0, th: 1, heroes: [], pet: false, jump: {}, hearts: [] };
  function openSplash(firstJourney = false) {
    SP.firstJourney = firstJourney;
    $('spMapLabel').textContent = firstJourney ? 'Начать историю' : 'Карта приключений';
    const prof = Saves.loadProfile();
    const doneN = Session.CH_NUMS.filter(n => prof['ch' + n + 'Done']).length;
    let th = prof.lastCh && CHAPTERS[prof.lastCh] && Chapters.chapterOpen(prof.lastCh) ? prof.lastCh : 1;
    if (!prof.lastCh) for (const n of Session.CH_NUMS) if (Chapters.chapterOpen(n)) th = n;
    SP.th = th;
    SP.heroes = ['krilessa'].concat(prof.ch1Done || GameLoop.DEBUG || prof.admin ? ['ryzhovaya'] : []).concat(prof.ch3Done || GameLoop.DEBUG || prof.admin ? ['tessa'] : []);
    SP.pet = prof.ch4Choice === 'kind';
    SP.jump = {}; SP.hearts = []; SP.t = 0;
    $('spSub').textContent = doneN >= Session.CH_NUMS.length ? 'Сезон пройден! Но приключения продолжаются…' : 'Спасение Рыжовой';
    $('spUpd').appendChild($('updBox')); MenuActions.showUpdate(); // радужная плашка обновления – прямо на стартовом экране
    Screens.setState('splash');
    Sound.music('menu'); // главная тема – одна на стартовом экране и на карте приключений
    cancelAnimationFrame(SP.raf); SP.last = performance.now(); SP.raf = requestAnimationFrame(splashLoop);
  }
  function splashLoop(now) {
    if (Session.state !== 'splash') { SP.raf = 0; return; }
    const dt = Math.min(0.05, (now - SP.last) / 1000); SP.last = now; SP.t += dt;
    const cv = $('splashCv'), c = cv.getContext('2d'), dpr = Math.min(window.devicePixelRatio || 1, 2);
    const W = cv.clientWidth, H = cv.clientHeight;
    if (cv.width !== Math.round(W * dpr) || cv.height !== Math.round(H * dpr)) { cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr); }
    c.setTransform(dpr, 0, 0, dpr, 0, 0);
    const effect = SPLASH_EFFECTS[SP.th], t = SP.t;
    c.clearRect(0, 0, W, H);
    for (let i = 0; i < 38; i++) {
      c.fillStyle = `rgba(251,228,181,${0.22 + 0.52 * Math.abs(Math.sin(t * 0.6 + i))})`;
      c.fillRect(hash2(i, 1) * W, hash2(1, i) * H * 0.68, 1.3, 1.3);
    }
    if (SP.th === 6) for (let k = 0; k < 3; k++) { // северное сияние
      c.strokeStyle = ['rgba(90,255,180,.16)', 'rgba(120,200,255,.14)', 'rgba(200,120,255,.12)'][k]; c.lineWidth = 40 - k * 8; c.lineCap = 'round';
      c.beginPath(); for (let x = 0; x <= W; x += 16) { const y = H * (0.22 + k * 0.05) + Math.sin(x * 0.012 + t * 0.7 + k) * 20; if (x) c.lineTo(x, y); else c.moveTo(x, y); } c.stroke();
    }
    if (effect === 'disco') for (let k = 0; k < 4; k++) { // лучи прожекторов
      const a = Math.sin(t * 0.9 + k * 1.7) * 0.6, x0 = W * (0.15 + k * 0.23);
      c.save(); c.translate(x0, -10); c.rotate(a);
      const bg2 = c.createLinearGradient(0, 0, 0, H * 0.8); bg2.addColorStop(0, ['rgba(255,110,220,.35)', 'rgba(110,230,255,.3)', 'rgba(255,230,110,.3)', 'rgba(160,120,255,.3)'][k]); bg2.addColorStop(1, 'rgba(0,0,0,0)');
      c.fillStyle = bg2; c.beginPath(); c.moveTo(-6, 0); c.lineTo(6, 0); c.lineTo(70, H * 0.8); c.lineTo(-70, H * 0.8); c.closePath(); c.fill(); c.restore();
    }
    // Маленькие игровые героини на переднем плане по-прежнему отвечают на касания.
    const landscape = W > H, ks = Math.min(1.45, W / 290, H / 220);
    const gy = landscape ? H * 0.84 : H * 0.75;
    const slots = SP.heroes.map((id, i) => landscape
      ? 0.74 + (i - (SP.heroes.length - 1) / 2) * 0.1
      : 0.50 + (i - (SP.heroes.length - 1) / 2) * 0.2);
    SP.heroes.forEach((id, i) => {
      const hx = W * slots[i], j = SP.jump[id] || 0, jy = j > 0 ? Math.sin((1 - j) * Math.PI) * 50 : 0;
      if (j > 0) SP.jump[id] = Math.max(0, j - dt * 1.6);
      c.fillStyle = 'rgba(0,0,0,0.25)'; c.beginPath(); c.ellipse(hx, gy + 12 + Math.sin(hx * 0.017 - t * 0.04) * 10, 26, 7, 0, 0, TAU); c.fill();
      drawHero(id, c, hx, gy + Math.sin(hx * 0.017 - t * 0.04) * 10 - jy + Math.sin(t * 2 + i) * 2, t, slots[i] < 0.5 ? 1 : slots[i] > 0.5 ? -1 : 1, ks, 1, false);
      SP.heroX = SP.heroX || {}; SP.heroX[id] = [hx, gy - 40 * ks / 3];
    });
    if (SP.pet) { // Мяу.exe
      const px = W * 0.93, py = gy - 18 + Math.sin(t * 4) * 3;
      for (const [x, y] of [[-3, -4], [3, -4], [-3, -3], [-2, -3], [-1, -3], [0, -3], [1, -3], [2, -3], [3, -3], [-3, -2], [-2, -2], [0, -2], [2, -2], [3, -2], [-3, -1], [-2, -1], [-1, -1], [0, -1], [1, -1], [2, -1], [3, -1], [-2, 0], [-1, 0], [0, 0], [1, 0], [2, 0], [-2, 1], [2, 1]]) { c.fillStyle = '#3ff0a0'; c.fillRect(px + x * 3, py + y * 3, 3, 3); }
    }
    // В ночной главе в нижней части иллюстрации моргают кошачьи глаза.
    if (effect === 'eyes') {
      c.fillStyle = '#9ee3dd';
      for (let i = 0; i < 3; i++) {
        const x = W * (.15 + i * .34), y = H * (.63 + (i % 2) * .07);
        const height = Math.sin(t * 1.3 + i * 2) > .94 ? .8 : 2.5;
        c.beginPath(); c.ellipse(x - 5, y, 3, height, 0, 0, TAU); c.ellipse(x + 5, y, 3, height, 0, 0, TAU); c.fill();
      }
    }
    // частицы темы
    if (effect === 'ff') for (let i = 0; i < 16; i++) { const x = hash2(i, 3) * W + Math.sin(t * 0.8 + i) * 20, y = H * (0.45 + hash2(3, i) * 0.4) + Math.cos(t * 0.6 + i * 2) * 14; c.fillStyle = `rgba(255,240,120,${0.3 + 0.7 * Math.abs(Math.sin(t * 2 + i))})`; c.beginPath(); c.arc(x, y, 2.2, 0, TAU); c.fill(); }
    if (effect === 'ember') for (let i = 0; i < 22; i++) { const k = (t * (0.15 + hash2(i, 4) * 0.2) + hash2(4, i)) % 1, x = hash2(i, 5) * W + Math.sin(t + i) * 10, y = H * (1 - k * 0.9); c.fillStyle = `rgba(255,${150 + (i % 3) * 30},60,${1 - k})`; c.beginPath(); c.arc(x, y, 2.4, 0, TAU); c.fill(); }
    if (effect === 'snow') for (let i = 0; i < 60; i++) { const k = (t * (0.05 + hash2(i, 6) * 0.06) + hash2(6, i)) % 1, x = (hash2(i, 7) * W + Math.sin(t * 0.7 + i) * 18 + k * 30) % W, y = k * H; c.fillStyle = 'rgba(255,255,255,0.85)'; c.beginPath(); c.arc(x, y, 1.2 + hash2(i, 8) * 2, 0, TAU); c.fill(); }
    if (effect === 'sea') { // подводный свет, пузыри и стайка криля
      for (let k = 0; k < 4; k++) { const x0 = W * (0.12 + k * 0.27) + Math.sin(t * 0.4 + k) * 20; c.fillStyle = 'rgba(160,230,255,0.07)'; c.beginPath(); c.moveTo(x0 - 14, 0); c.lineTo(x0 + 14, 0); c.lineTo(x0 + 70, H * 0.8); c.lineTo(x0 - 40, H * 0.8); c.closePath(); c.fill(); }
      for (let i = 0; i < 26; i++) { const k = (t * (0.06 + hash2(i, 12) * 0.08) + hash2(12, i)) % 1, x = hash2(i, 13) * W + Math.sin(t * 1.4 + i) * 8, y = H * (1 - k); c.strokeStyle = `rgba(210,245,255,${0.7 * (1 - k)})`; c.lineWidth = 1.3; c.beginPath(); c.arc(x, y, 1.5 + hash2(i, 14) * 3.5, 0, TAU); c.stroke(); }
      for (let i = 0; i < 9; i++) { const a = t * 0.5 + i * 0.7, x = W * 0.5 + Math.cos(a) * W * 0.36, y = H * 0.24 + Math.sin(a * 1.3) * 40 + i * 4; c.fillStyle = '#ff8aa8'; c.save(); c.translate(x, y); c.rotate(a + Math.PI / 2); c.beginPath(); c.ellipse(0, 0, 6, 2.6, 0, 0, TAU); c.fill(); c.restore(); }
    }
    if (effect === 'paws') for (let i = 0; i < 6; i++) { const k = (t * 0.5 - i * 0.18) % 1.4; if (k < 0 || k > 1) continue; c.globalAlpha = Math.sin(k * Math.PI) * 0.6; c.font = '18px Krilessa Icons, sans-serif'; c.fillText('🐾', W * (0.08 + i * 0.15), gy + 36 + (i % 2) * 10); c.globalAlpha = 1; }
    if (effect === 'disco') for (let i = 0; i < 10; i++) { const a = Math.abs(Math.sin(t * 1.5 + i * 1.3)); c.fillStyle = `rgba(255,255,255,${a})`; star(c, hash2(i, 11) * W, hash2(11, i) * H * 0.6, 3 * a + 1, t, 4); c.fill(); }
    // сердечки от прыжков
    for (const hh of SP.hearts) { hh.t += dt; hh.y -= 60 * dt; c.globalAlpha = Math.max(0, 1 - hh.t); c.fillStyle = hh.col; heartPath(c, hh.x + Math.sin(hh.t * 6 + hh.x) * 6, hh.y, 7); c.fill(); c.globalAlpha = 1; }
    SP.hearts = SP.hearts.filter(hh => hh.t < 1);
    if (Terrain.paperOn) { // заставка тоже на бумаге: мягче краски и зерно
      if (!HUD.PAPER.tex) HUD.PAPER.tex = HUD.paperTex();
      c.save(); c.setTransform(dpr, 0, 0, dpr, 0, 0); c.globalCompositeOperation = 'screen'; c.fillStyle = 'rgba(255,236,206,.14)'; c.fillRect(0, 0, W, H);
      c.globalCompositeOperation = 'multiply'; c.fillStyle = c.createPattern(HUD.PAPER.tex, 'repeat'); c.fillRect(0, 0, W, H); c.restore();
    }
    SP.raf = requestAnimationFrame(splashLoop);
  }
  // ---------- главный экран: карта приключений ----------
  const CH_META = {
    1: { ic: '🌲', c: ['#7dff7d', '#1f7a2a'], sc: '30,90,40', deco: ['🌲', '🌳', '🍄', '🌼'], hero: 'krilessa', desc: 'Рыжовая в плену у колдуна Мрака. Победи трёх стражей и открой Тёмный замок' },
    2: { ic: '🪩', c: ['#ff8ad8', '#6a2ad8'], sc: '90,30,110', deco: ['🪩', '✨', '🎤', '💿'], hero: 'krilessa', desc: 'Зямочкккк утащил Рыжовую в свою Кринж-Цитадель. Диско-шары, портреты и много кринжа' },
    3: { ic: '🪞', c: ['#ffc070', '#c03a10'], sc: '110,45,20', deco: ['🪞', '🔥', '🦄', '✨'], hero: 'ryzhovaya', desc: 'Теперь играешь за Рыжовую! Огонь в её волосах – оружие. Спаси Крилессу из Зеркального дворца' },
    4: { ic: '🌙', c: ['#8fa6e8', '#141a40'], sc: '20,26,60', deco: ['🌙', '🐾', '💡', '📺'], hero: 'tessa' },
    5: { ic: '🔎', c: ['#ffe08a', '#d8782a'], sc: '110,70,20', deco: ['🐟', '🔎', '📦', '🥣'], hero: 'tessa' },
    6: { ic: '❄️', c: ['#d8f2ff', '#3a6ac8'], sc: '30,60,110', deco: ['❄️', '⛄', '🔥', '🌨️'], hero: 'krilessa' },
    8: {ic:'🔔',c:['#dec391','#346776'],sc:'50,81,87',deco:['🔔','✦','☾','✦'],hero:'ryzhovaya',desc:'Под водой звонит колокол. На дамбе отражение Крилессы делает первый шаг.'},
    7: { ic: '🦐', c: ['#6ae0ff', '#062a5a'], sc: '10,50,90', deco: ['🐠', '🦐', '🐚', '🌊'], hero: 'krilessa' },
  };
  const CH_STUBS = 2;
  const CH_LOCKED_META = { ic: '❔', c: ['#6a6080', '#1a1626'], sc: '30,26,44' };
  function chapterView(n, prof) {
    const C = CHAPTERS[n], open = Chapters.chapterOpen(n), done = !!prof['ch' + n + 'Done'], sv = Saves.loadSave(n), sec = SECRET_CARDS[n];
    const hidden = !open && !!sec; // закрытая секретная глава – загадка
    const meta = hidden ? CH_LOCKED_META : CH_META[n];
    // идёт новое прохождение – показываем его прогресс, иначе для пройденной главы все звёзды
    const nb = C.bosses.length, beaten = sv && sv.defeated ? sv.defeated.filter(Boolean).length : done ? nb : 0;
    let stat = '';
    if (!open) stat = hidden ? '🔒 ' + sec.locked : `🔒 Откроется после главы ${n - 1}`;
    else if (sv) stat = `💾 Сохранение: боссы ${beaten}/${nb} · ур. ${sv.level}`;
    else if (n === 3 && prof.trueWin) stat = '✓ Настоящий финал пройден ❤';
    else if (n === 4 && done) stat = prof.ch4Choice === 'kind' ? '✓ Пройдена · добрая концовка 💗' : prof.ch4Choice === 'good' ? '✓ Пройдена · хорошая концовка 🛡️' : '✓ Пройдена';
    else if (n === 5 && done) stat = '✓ Дело раскрыто 🕵️';
    else if (n === 6 && done) stat = '✓ Зима отступила ❄️';
    else if (n === 7 && done) stat = '✓ Слова вернулись 💗';
    else if (done) stat = '✓ Пройдена';
    else stat = 'Новая прокачка с 1 уровня';
    return { n, open, done, sv, hidden, meta, nb, beaten, stat,
      title: hidden ? '???' : (sec ? sec.title : C.name),
      desc: hidden ? 'Что здесь – секрет. Пройди предыдущую главу.' : (sec ? sec.open : CH_META[n].desc),
      isNew: open && !done && !sv && n > 1 && !!prof['ch' + (n - 1) + 'Done'] };
  }
  // Путь ведёт от первой главы у нижнего края к горам. Абсциссы заданы в процентах,
  // поэтому медальоны и кривая остаются совмещены при повороте телефона.
  const routeX = [43, 72, 29, 66, 30, 71, 36, 69, 31, 58];
  const routeStep = 120;
  const routeHeight = 70 + routeStep * (routeX.length - 1) + 78;
  function routePoint(i) { return { x: routeX[i], y: routeHeight - 78 - i * routeStep }; }

  function drawRoad(views) {
    const road = $('mRoad');
    road.setAttribute('viewBox', '0 0 100 ' + routeHeight);
    road.replaceChildren();
    let previous = { x: routeX[0] - 8, y: routeHeight + 6 };
    let path = 'M ' + previous.x + ' ' + previous.y;
    let future = '', travelled = '';
    routeX.forEach((_, i) => {
      const point = routePoint(i);
      const mid = (point.y + previous.y) / 2;
      const curve = ` C ${previous.x} ${mid}, ${point.x} ${mid}, ${point.x} ${point.y}`;
      if (i < views.length) {
        path += curve;
        if (views[i].open) travelled += `M ${previous.x} ${previous.y}` + curve;
      } else {
        if (!future) future = `M ${previous.x} ${previous.y}`;
        future += curve;
      }
      previous = point;
    });
    for (const [layer, d] of [['future', future], ['edge', path], ['earth', path], ['travelled', travelled], ['steps', path]]) {
      const line = document.createElementNS('http://www.w3.org/2000/svg', 'path');
      line.setAttribute('class', 'road-' + layer);
      line.setAttribute('vector-effect', 'non-scaling-stroke');
      line.setAttribute('d', d);
      road.appendChild(line);
    }
  }

  function chapterButton(n, view, current) {
    const button = document.createElement('button');
    button.type = 'button';
    button.id = 'chap' + n;
    button.className = 'node';
    const point = routePoint(n - 1);
    button.style.left = point.x + '%';
    button.style.top = point.y + 'px';
    const label = view ? view.hidden ? 'Тайная глава' : view.title : 'Глава ' + n;
    const detail = view ? view.open ? '★ ' + view.beaten + ' / ' + view.nb : 'После главы ' + (n - 1) : 'Скоро';
    const icon = view ? view.hidden ? '❔' : view.meta.ic : '·';
    button.innerHTML = `<span class="med"><span class="ic" aria-hidden="true"></span><b class="num"></b></span>
      <span class="lbl"><strong></strong><small class="pr"></small></span>`;
    button.querySelector('.ic').textContent = icon;
    button.querySelector('.num').textContent = n;
    button.querySelector('strong').textContent = label;
    button.querySelector('.pr').textContent = detail;
    if (!view) button.classList.add('stub');
    else {
      button.classList.toggle('locked', !view.open);
      button.classList.toggle('done', view.done);
      if (view === current) { button.classList.add('cur'); button.setAttribute('aria-current', 'step'); }
      button.style.setProperty('--c1', view.meta.c[0]);
      button.style.setProperty('--c2', view.meta.c[1]);
      button.insertAdjacentHTML('afterbegin', chapterFx(view, point.x < 50 ? 1 : -1));
    }
    button.setAttribute('aria-label', 'Глава ' + n + '. ' + (view ? label + '. ' : '') + detail);
    button.addEventListener('click', () => {
      Sound.init(); Sound.sfx.click();
      if (!view) RunStats.toast(`🚧 Глава ${n} пока строится. Скоро!`);
      else if (n === 7 && view.hidden) Story.openKrillTeaser();
      else openChapterSheet(n);
    });
    return button;
  }

  function placeCharms(map, view, point) {
    // Пары по противоположным берегам дороги, вдали от подписи и кнопки главы.
    const spots = point.x > 50 ? [[12,-38],[37,23],[90,-24],[45,-51]] : [[12,-25],[72,-43],[88,14],[69,31]];
    CH_META[view.n].deco.forEach((glyph, i) => {
      const deco = document.createElement('button');
      deco.type = 'button'; deco.className = 'deco'; deco.textContent = glyph;
      const [x, dy] = spots[i];
      deco.style.left = x + '%'; deco.style.top = (point.y + dy) + 'px';
      deco.style.animationDelay = (-i * .6) + 's';
      deco.setAttribute('aria-label', `Сбить украшение ${i + 1} главы ${view.n}`);
      deco.addEventListener('click', () => knockDeco(deco, glyph));
      map.appendChild(deco);
    });
  }

  function renderMap(prof) {
    const map = $('mMap');
    for (const el of map.querySelectorAll('.node, .deco')) el.remove();
    map.style.height = routeHeight + 'px';
    const views = Session.CH_NUMS.map(n => chapterView(n, prof));
    const current = views.find(view => view.open && !view.done) || [...views].reverse().find(view => view.open) || views[0];
    $('mFeaturedChapter').textContent = 'Глава ' + current.n;
    $('mSub').textContent = current.title;
    $('mLaunchLabel').textContent = current.sv ? 'Продолжить' : current.done ? 'Играть снова' : 'Открыть главу';
    $('mProgress').textContent = views.filter(view => view.done).length + ' / ' + views.length + ' пройдено';
    $('mFeature').onclick = () => $('chap' + current.n).click();
    drawRoad(views);
    for (let i = 0; i < views.length + CH_STUBS; i++) {
      const view = views[i];
      if (view && !view.hidden) placeCharms(map, view, routePoint(i));
      map.appendChild(chapterButton(i + 1, view, current));
    }
    const point = routePoint(current.n - 1);
    const hero = $('mHero'), portrait = $('mHeroCv').getContext('2d');
    hero.style.left = `calc(${point.x}% + ${point.x < 50 ? -43 : 43}px)`;
    hero.style.top = (point.y - 42) + 'px';
    portrait.clearRect(0, 0, 96, 96);
    const avatar = Expedition.heroAvatar(current.meta.hero);
    if (avatar) portrait.drawImage(avatar, 0, 0, 96, 96);
    G.menuCur = current.n;
    requestAnimationFrame(() => {
      const viewport = $('mJourney');
      viewport.scrollTop = point.y - viewport.clientHeight * .73;
    });
  }
  // ---------- украшения на карте можно сбивать тапом ----------
  const DECO_COL = {
    '❄️': ['#ffffff', '#bfeaff', '#7fd8ff'], '🌨️': ['#ffffff', '#bfeaff'], '⛄': ['#ffffff', '#ff8a2a', '#bfeaff'],
    '🔥': ['#ffe08a', '#ffb03a', '#ff6a1f'], '✨': ['#fff3b0', '#ffd25a', '#ffffff'], '🌲': ['#7dff7d', '#2f9a3a', '#c8ffb0'], '🌳': ['#7dff7d', '#3fae4a'],
    '🍄': ['#ff4a4a', '#ffffff'], '🌼': ['#ffe04a', '#ffffff'], '🪩': ['#ff6fd8', '#6ae6ff', '#ffe08a', '#ffffff'], '💿': ['#c8d4ff', '#ff9ad8', '#9affe8'],
    '🎤': ['#ff6fb5', '#c8c8d8'], '🪞': ['#d8f2ff', '#ffffff', '#ffd25a'], '🦄': ['#ff9ad8', '#9ad8ff', '#fff3b0', '#c8a8ff'], '🌙': ['#ffe08a', '#fff7c8'],
    '🐾': ['#ff9ab8', '#ffd0dc'], '💡': ['#fff7a0', '#ffe04a'], '📺': ['#3ff0a0', '#ff3ea5', '#6ae6ff'], '🐟': ['#6ac8ff', '#ffd25a'],
    '🔎': ['#ffd25a', '#d8f2ff'], '📦': ['#d8a050', '#8a5a2a'], '🥣': ['#ffffff', '#6ac8ff'],
  };
  let decoCombo = 0, decoComboT = 0;
  function knockDeco(el, glyph) {
    if (el.classList.contains('hit')) return;
    Sound.init();
    const cols = DECO_COL[glyph] || ['#ffffff', '#ffd25a'], map = $('mMap');
    const icon = el.getBoundingClientRect(), bounds = map.getBoundingClientRect();
    const cx = icon.left - bounds.left + icon.width / 2, cy = icon.top - bounds.top + icon.height / 2;
    el.style.setProperty('--kx', ((Math.random() < 0.5 ? -1 : 1) * (40 + Math.random() * 50)) + 'px');
    el.style.setProperty('--kr', ((Math.random() < 0.5 ? -1 : 1) * (240 + Math.random() * 200)) + 'deg');
    el.classList.remove('back'); el.classList.add('hit');
    // искры в цветах украшения + пара маленьких копий
    const add = (cls, html, css) => { const b = document.createElement('i'); b.className = cls; if (html) b.textContent = html; b.style.cssText = css; map.appendChild(b); setTimeout(() => b.remove(), 900); };
    for (let k = 0; k < 12; k++) {
      const a = k / 12 * TAU + Math.random() * 0.4, r = 34 + Math.random() * 34, col = cols[k % cols.length];
      add('spark', '', `left:${cx}px;top:${cy}px;background:${col};box-shadow:0 0 6px ${col};--dx:${Math.cos(a) * r}px;--dy:${Math.sin(a) * r}px;animation-duration:${0.5 + Math.random() * 0.3}s`);
    }
    for (let k = 0; k < 2; k++) {
      const a = -Math.PI / 2 + (k ? 0.8 : -0.8);
      add('spark g', glyph, `left:${cx}px;top:${cy}px;--dx:${Math.cos(a) * 46}px;--dy:${Math.sin(a) * 46}px;animation-duration:.7s`);
    }
    add('ringFx', '', `left:${cx}px;top:${cy}px;--rc:${cols[0]}`);
    // серия быстрых тапов – множитель
    const now = performance.now();
    decoCombo = now - decoComboT < 1600 ? decoCombo + 1 : 1; decoComboT = now;
    Achievements.life('deco'); Achievements.lifeMax('decoCombo', decoCombo); Achievements.lifeSoon();
    if (decoCombo >= 2) add('comboFx', '×' + decoCombo + (decoCombo >= 5 ? '!' : ''), `left:${cx}px;top:${cy - 18}px`);
    if (glyph === '❄️' || glyph === '🌨️' || glyph === '🪞') Sound.sfx.glass(); else if (glyph === '🔥') Sound.sfx.fireball(); else Sound.sfx.shard();
    // через несколько секунд украшение возвращается
    setTimeout(() => { if (!el.isConnected) return; el.classList.remove('hit'); void el.offsetWidth; el.classList.add('back'); }, 5000 + Math.random() * 4000);
  }
  // живые украшения у медальонов: глаза в темноте, светлячки, диско-лучи, искры, следы лап, снег
  const EYES4 = side => [[side * 80, -52], [side * 120, 18], [-side * 110, 40]];
  function chapterFx(v, side) {
    const at = (x, y, extra = '') => `style="left:${Math.round(x)}px;top:${Math.round(y)}px;${extra}"`;
    const d = k => `animation-delay:${(-k).toFixed(2)}s;`;
    let h = '';
    if (v.n === 4) { // глаза – как раньше на карточке, видны даже у закрытой главы
      const [e1, e2, e3] = EYES4(side);
      h += `<div class="eyes2" ${at(e1[0] - 22, e1[1] - 6)}><i></i><i></i></div>`;
      h += `<div class="eyes2 s" ${at(e2[0] - 22, e2[1] - 6)}><i style="${d(1.3)}"></i><i style="${d(1.3)}"></i></div>`;
      if (v.open) h += `<div class="eyes2 g s" ${at(e3[0] - 22, e3[1] - 6)}><i style="${d(2.6)}"></i><i style="${d(2.6)}"></i></div>`;
    } else if (v.n === 6) { // снег – тоже виден заранее
      for (let k = 0; k < 7; k++) h += `<b class="sn" ${at(-70 + k * 22 + hash2(k, 6) * 10, -10 + hash2(6, k) * 20, d(k * 0.55))}></b>`;
    } else if (v.n === 7) { // пузыри и розовые крили кружат вокруг медальона
      for (let k = 0; k < 5; k++) h += `<b class="bub" ${at(-30 + k * 14, 10, d(k * 0.6))}></b>`;
      for (let k = 0; k < 3; k++) h += `<b class="kr" style="${d(k * 2.33)}">🦐</b>`;
    } else if (!v.open && v.n === 5) {
      for (let k = 0; k < 3; k++) h += `<b class="q" ${at(side * (55 + k * 22), -20 + k * 18, d(k * 1.1))}>?</b>`;
    } else if (v.open && v.n === 1) {
      for (let k = 0; k < 6; k++) h += `<b class="ff" ${at((hash2(k, 1) - 0.5) * 180, (hash2(1, k) - 0.5) * 110, d(k * 0.85))}></b>`;
    } else if (v.open && v.n === 2) {
      ['rgba(255,110,220,.45)', 'rgba(110,230,255,.45)', 'rgba(255,230,110,.45)'].forEach((col, k) => {
        h += `<b class="beam" style="background:linear-gradient(transparent, ${col});${d(k * 1.66)}"></b>`;
      });
      for (let k = 0; k < 4; k++) h += `<b class="tw" ${at((hash2(k, 2) - 0.5) * 150, (hash2(2, k) - 0.5) * 110, d(k * 0.45))}>✦</b>`;
    } else if (v.open && v.n === 3) {
      for (let k = 0; k < 6; k++) h += `<b class="em" ${at(-40 + k * 16, 22 - hash2(k, 3) * 12, d(k * 0.43))}></b>`;
    } else if (v.open && v.n === 5) {
      for (let k = 0; k < 4; k++) h += `<b class="paw" ${at(side * (52 + k * 22), 46 - k * 22, `transform:rotate(${side * 25}deg);` + `animation-delay:${(k * 0.5).toFixed(1)}s;`)}>🐾</b>`;
    }
    return `<div class="fx">${h}</div>`;
  }
  // оформление карточек глав – как раньше на старых карточках: глаза кошки, снег, огоньки…
  function sheetFx(n, open) {
    const P2 = (x, y, extra = '') => `style="left:${x}%;top:${y}%;${extra}"`, dl = k => `animation-delay:${(-k).toFixed(2)}s;`;
    let h = '';
    if (n === 4) {
      h += `<div class="lookA" ${P2(74, 16)}><div class="eyes2 big"><i></i><i></i></div></div>`;
      h += `<div class="lookB" ${P2(6, 44)}><div class="eyes2 s"><i style="${dl(1.7)}"></i><i style="${dl(1.7)}"></i></div></div>`;
      if (open) h += `<div class="lookA" ${P2(84, 62)}><div class="eyes2 g s"><i style="${dl(3.1)}"></i><i style="${dl(3.1)}"></i></div></div>`;
      for (let k = 0; k < 5; k++) h += `<b class="paw" ${P2(8 + k * 19, 88 - (k % 2) * 4, `transform:rotate(80deg);animation-delay:${(k * 0.45).toFixed(2)}s;`)}>🐾</b>`;
      if (open) h += '<b class="glitchLn"></b>';
    } else if (n === 6) {
      for (let k = 0; k < 18; k++) h += `<b class="sn sh" ${P2(Math.round(hash2(k, 61) * 98), 0, dl(hash2(61, k) * 4))}></b>`;
      h += '<b class="frost l"></b><b class="frost r"></b>';
    } else if (n === 7) { // пузыри поднимаются со дна
      for (let k = 0; k < 14; k++) h += `<b class="bub" ${P2(Math.round(hash2(k, 71) * 96), 92, dl(hash2(71, k) * 5))}></b>`;
    } else if (n === 5) {
      if (open) for (let k = 0; k < 5; k++) h += `<b class="paw" ${P2(6 + k * 20, 86 - (k % 2) * 5, `transform:rotate(70deg);animation-delay:${(k * 0.5).toFixed(2)}s;`)}>🐾</b>`;
      for (let k = 0; k < 4; k++) h += `<b class="q" ${P2([8, 86, 14, 80][k], [30, 26, 60, 58][k], dl(k * 0.9))}>?</b>`;
    } else if (!open) {
      return '';
    } else if (n === 1) {
      for (let k = 0; k < 9; k++) h += `<b class="ff" ${P2(Math.round(hash2(k, 11) * 94), Math.round(10 + hash2(11, k) * 75), dl(k * 0.6))}></b>`;
    } else if (n === 2) {
      ['rgba(255,110,220,.35)', 'rgba(110,230,255,.35)', 'rgba(255,230,110,.3)'].forEach((col, k) => {
        h += `<b class="swing" style="left:${[18, 50, 82][k]}%;background:linear-gradient(${col}, transparent);${dl(k * 1.1)}"></b>`;
      });
      for (let k = 0; k < 7; k++) h += `<b class="tw" ${P2(Math.round(hash2(k, 22) * 92), Math.round(8 + hash2(22, k) * 80), dl(k * 0.35))}>✦</b>`;
    } else if (n === 3 || n === 'rush') {
      for (let k = 0; k < 10; k++) h += `<b class="em tall${n === 'rush' ? ' red' : ''}" ${P2(Math.round(4 + k * 10 + hash2(k, 33) * 5), 96, dl(k * 0.37))}></b>`;
      if (n === 3) h += '<b class="shine"></b>';
    }
    return h;
  }
  let sheetCh = 0;
  function openChapterSheet(n) {
    const opening = Session.state !== 'chapSheet' || sheetCh !== n;
    const prof = Saves.loadProfile(), sh = $('chapSheet');
    sheetCh = n;
    const show = (id, on) => $(id).classList.toggle('hidden', !on);
    if (n === 'rush') {
      const rushOpen = GameLoop.DEBUG || prof.admin || prof.ch1Done, rb = prof.rushBest;
      sh.style.setProperty('--c1', '#ff8a6a'); sh.style.setProperty('--c2', '#8a1a1a'); sh.style.setProperty('--sc', '110,25,25');
      $('shIc').textContent = '⚔️'; $('shNum').textContent = 'Испытание'; $('shTitle').textContent = 'Босс-раш';
      $('shDesc').textContent = 'Все побеждённые боссы подряд, на время. У всех одинаковая героиня 24 уровня + твои таланты и реликвии';
      $('shStat').textContent = !rushOpen ? '🔒 Откроется после главы 1' : rb ? `🏆 Рекорд: ${rb.n}/${rb.total} боссов за ${RunStats.fmtT(rb.time)}` : 'Рекорда пока нет';
      $('shPlay').textContent = rushOpen ? 'В бой!' : '🔒 Закрыто';
      const rhId = (prof.settings || {}).rushHero;
      $('rushHero').textContent = '🔄 ' + (HEROES[rhId] ? HEROES[rhId].name : 'Крилесса');
      show('shNew', false); show('shIntro', false); show('shMut', false); show('ch4Riddle', false); show('rushHero', rushOpen && !!(prof.ch3Done || GameLoop.DEBUG || prof.admin));
      $('shFx').innerHTML = sheetFx('rush', rushOpen);
    } else {
      const v = chapterView(n, prof);
      sh.style.setProperty('--c1', v.meta.c[0]); sh.style.setProperty('--c2', v.meta.c[1]); sh.style.setProperty('--sc', v.meta.sc);
      $('shIc').textContent = v.open ? v.meta.ic : (v.hidden ? '❔' : '🔒');
      $('shNum').textContent = 'Глава ' + n; $('shTitle').textContent = v.title; $('shDesc').textContent = v.desc; $('shStat').textContent = v.stat;
      $('shPlay').textContent = !v.open ? '🔒 Закрыто' : v.sv ? 'Продолжить' : 'Играть';
      show('shNew', v.open && !!v.sv); show('shIntro', v.done || GameLoop.DEBUG || !!prof.admin); show('shMut', v.done && !NET.on); show('ch4Riddle', n === 4 && !prof.ch4Done); show('rushHero', false);
      $('shFx').innerHTML = sheetFx(n, v.open);
    }
    Screens.setState('chapSheet');
    if (opening) {
      $('chapSheet').querySelector('.sheet').scrollTop = 0;
      $('shClose').focus({ preventScroll: true });
    }
  }
  function closeSheet() { Screens.leaveList('menu'); }
  // ---------- обновления через интернет (только в приложении на Android) ----------

  return {
    SECRET_CARDS, drawMenuPortrait, openMenu, SP, openSplash, CH_META, openChapterSheet,
    closeSheet,
    get sheetCh() { return sheetCh; },
  };
})();
