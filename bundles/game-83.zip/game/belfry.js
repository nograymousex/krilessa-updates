'use strict';

const Belfry = {
  scenes: {
    ch8: {end: 9, scenes: [
      {at: 0, art: 'dam', fx: .30, music: 'belfry', text: 'На середине дамбы Рыжовая останавливается. Из-под воды доносится удар колокола.', sfx: 'toll'},
      {at: 3, art: 'dam', fx: .90, text: 'Крилесса держит её за руку. В воде у её отражения обе руки свободны.'},
      {at: 6, art: 'dam', fx: .17, text: 'Второй удар. На двух шлюзах разом натягиваются цепи.'}
    ]},
    end8: {end: 9, scenes: [
      {at: 0, art: 'basin', fx: .35, music: 'belfry', text: 'Под разбитым колоколом Рыжовая находит рукоять шлюза. На бронзе вмятины от маленькой короны.'},
      {at: 3, art: 'basin', fx: .80, text: 'Крилесса опускается рядом. «Я сама открыла шлюзы. Тогда она впервые подняла руку раньше меня».'},
      {at: 6, art: 'basin', fx: .50, text: 'Рыжовая берёт её за руку. Обе уходят по дамбе. В луже под колоколом кто-то остаётся стоять.'}
    ]}
  },
  // Version 1.2.0 stored room coordinates and had no bosses. Keep the player's build.
  migrate(slot) {
    if (!slot || slot.layout === 2) return slot;
    const { kitchen, cp, defeated, df, cs, chests, shrines, ...carry } = slot;
    return { ...carry, layout: 2, defeated: [false, false, false] };
  }
};

const B8 = registerBiomes(
  {id:'dam', name:'Старая дамба', ground:['#627c62','#6f876b','#566f5c'], tree:'willow', treeP:.075,
    path:['#aa9776','#b4a281','#9a876e'], rock:['#5b7070','#738782','#496469'], deco:'flowers',
    mini:'#68866f', obst:[[ROCK,1]], music:'belfry', spawns:[['slime',3],['crab',1],['bat',2]]},
  {id:'sluice', name:'Медные шлюзы', ground:['#667879','#758581','#5a6b70'], tree:'burnt', treeP:.045,
    path:['#ac987d','#baa889','#9b8976'], rock:['#536467','#6c7e78','#455763'], deco:'boards',
    mini:'#768780', obst:[[ROCK,1]], music:'belfry', spawns:[['crab',2],['eel',2],['bat',1.5]]},
  {id:'bellcourt', name:'Чаша колокола', ground:['#566675','#607381','#4b5c68'], tree:'willow', treeP:.035,
    path:['#a49885','#b6ab90','#968d80'], rock:['#536472','#728581','#445563'], deco:'drops',
    mini:'#647b83', obst:[[ROCK,1]], music:'belfry', spawns:[['wisp',2],['crab',2],['bat',1]]}
);

Object.assign(BOSSES, {
  chainWarden: {
    name:'Цепной паромщик', sub:'Западный шлюз', r:36, ttk:39, hit:.08, touch:.12, spd:78, move:'chase', col:'#d7aa70', music:'sluices', openingAttack:true,
    lines:{intro:'Сто лет тяну эту цепь. Сегодня кто-то тянет с того конца.', stages:['','Держись подальше от якоря.'], death:'Слышишь? Уже течёт.', taunts:['Вода помнит натяжение.']},
    stages:[{attacks:[['chainSweep'],['stomp',{r:106}]]},{at:.52,spd:1.12,attacks:[['chainSweep'],['charge'],['stomp',{r:116}]]}]
  },
  sluiceHeron: {
    name:'Цапля шлюзов', sub:'Восточный затвор', r:35, ttk:42, hit:.077, touch:.12, spd:83, move:'hover', fly:true, col:'#93d9e0', music:'sluices', openingAttack:true,
    lines:{intro:'Рыжовая делает шаг. Длинный клюв бьёт точно в оставленный след.', stages:['','Она слышит шаги сквозь воду.'], death:'Серебряное перо плывёт против течения.', taunts:['На воде проступают три воронки.']},
    stages:[{attacks:[['heronWake'],['leap',{r:77}]]},{at:.52,spd:1.14,attacks:[['heronWake'],['leap',{r:88}],['ring',{n:11}]]}]
  },
  hollowBell: {
    name:'Безликая звонарка', sub:'Отражение Крилессы', r:43, ttk:59, hit:.082, touch:.14, spd:77, move:'hover', col:'#e8c986', music:'thirdBell', openingAttack:true,
    lines:{intro:'«Рыжовая». Крилесса за спиной ещё не открывала рта.', stages:['','«Спроси её, кто поднял воду».','«Смотри в воду. Я сделаю шаг первой».'], death:'В бронзе проступает трещина. Изнутри вытекает чистая вода.', taunts:['Первый звон запомнил, где ты стояла.','Следующий шаг твой.']},
    stages:[{attacks:[['thirdToll'],['shotgun',{n:5}]]},{at:.65,spd:1.10,attacks:[['thirdToll'],['heronWake'],['ring',{n:13}]]},{at:.3,spd:1.18,attacks:[['thirdToll'],['chainSweep'],['leap',{r:98}]]}]
  }
});

CHAPTERS[8] = {
  id:8, title:'Глава 8', name:'Третий звон', seed:8800088, MW:124, MH:92, blobs:0,
  start:{x:59,y:73}, castle:{x:61,y:27,half:10,gate:'south',biome:B8+2}, cage:{x:61,y:24},
  biomeSeeds:[[B8,59,73],[B8+1,30,48],[B8+1,91,50],[B8+2,61,27]],
  bosses:['chainWarden','sluiceHeron','hollowBell'], bossTiles:[{x:30,y:48},{x:91,y:50},{x:61,y:27}],
  bossLevels:[5,7,12], zoneLevel:{[B8]:2,[B8+1]:5,[B8+2]:9}, chests:14, chestDist:[3,16], shrines:4,
  spawnEvery:.50, capBase:15, elite:.065, diff:{hp:1.3,dmg:1.2}, hero:'ryzhovaya', startLevel:1,
  noCage:true, music:'belfry', gateSay:'Вода уходит. На дне чаши стоит Крилесса. У неё нет лица.',
  gateBanner:'Спуск в чашу колокола', deadText:'Дамба ещё держится. Рыжовая возвращается к последнему привалу.'
};
ARENA_STYLE[8] = {name:'Дно водохранилища',floor:['#44575d','#4a6264'],crack:'#a29a7d',ember:'#d6bf85',wall:'#283b46',tint:'125,173,175'};
CHEST_THEME[8] = {body:'#675549',lid:'#a38b64',dark:'#344346'};
