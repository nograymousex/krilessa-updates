'use strict';
// =====================================================================
//  КРИЛЕССА – движок игры (v0.02 beta)
//  Глава 1: Спасение Рыжовой. Глава 2: Кринж-Цитадель Зямочкккк.
//  Контент (враги, боссы, реплики) – в content.js, графика – в sprites.js.
// =====================================================================
(() => {
  // мультиплеер: состояние сети (подробности – в разделе «Мультиплеер»)
  const NET = { on: false, host: false, client: false, id: 0, peers: new Map(), mates: new Map(), uid: 0, hitBy: 0, scanning: false, goneB: new Set() };
  let AIM = null; // за кем гонится моб (в мультиплеере – ближайшая героиня)
  const CH_NUMS = Object.keys(CHAPTERS).filter(k => /^[1-9]\d*$/.test(k)).map(Number).sort((a, b) => a - b); // все готовые главы по порядку (без босс-раша)
  // ------------------------------------------------------------------
  //  Экран
  // ------------------------------------------------------------------
  const canvas = $('game');
  const ctx = canvas.getContext('2d');
  let VW = 0, VH = 0, DPR = 1, ZOOM = 1, SAFE_TOP = 0, ZK = 1; // ZK – обзор: в обороне камера отъезжает
  const safeProbe = document.createElement('div');
  safeProbe.style.cssText = 'position:fixed;top:0;left:0;height:0;padding-top:env(safe-area-inset-top,0px);visibility:hidden';
  document.body.appendChild(safeProbe);
  function resize() {
    DPR = Math.min(window.devicePixelRatio || 1, 2);
    VW = window.innerWidth; VH = window.innerHeight;
    canvas.width = Math.round(VW * DPR); canvas.height = Math.round(VH * DPR);
    canvas.style.width = VW + 'px'; canvas.style.height = VH + 'px';
    ZOOM = clamp(Math.min(VW, VH) / 370, 0.85, 2) * ZK;
    SAFE_TOP = parseFloat(getComputedStyle(safeProbe).paddingTop) || 0;
  }
  window.addEventListener('resize', resize);
  resize();

  // ------------------------------------------------------------------
  //  Мир (пересоздаётся для каждой главы)
  // ------------------------------------------------------------------
  const T = 40;
  const PX_PER_M = 16;
  let CHN = 1, CFG = CHAPTERS[1], SEED = 0;
  let MW = 0, MH = 0, WORLD_W = 0, WORLD_H = 0, PLAY_H = 0, ARENA = null;
  let tiles = null, biomeMap, treeGrid, trees = [], chests = [], shrines = [], mainPath = [];
  // объекты глав Тессы
  let beds = [], lamps = [], clues = [], npcs = [], qitems = [], shelves = [], boxes = [], fires = [];
  let holes = [], ovens = [], drifts = [], glades = []; // глава 6
  let secrets = [], cracks = new Set(); // тайники: комната в скалах, вход – треснувшая стена
  let pearls = [], flow = null, curPts = []; // глава 7: слова-жемчужины и течения
  let START, CASTLE, GATE_FRONT, GATE_INNER, CAGE;
  let gateOpen = false;
  const tc = v => v * T + T / 2;
  const inMap = (tx, ty) => tx >= 0 && ty >= 0 && tx < MW && ty < MH;
  const tileAt = (tx, ty) => (inMap(tx, ty) ? tiles[ty * MW + tx] : ROCK);
  const isGround = t => t < PATH;

  function isSolidTile(tx, ty, fly) {
    if (!inMap(tx, ty)) return true;
    const t = tiles[ty * MW + tx];
    if (t === ROCK || t === WALL) return true;
    if (t === GATE) return !gateOpen;
    if (!fly && (t === WATER || t === LAVA)) return true;
    return false;
  }
  function blocksShots(x, y) {
    const tx = Math.floor(x / T), ty = Math.floor(y / T);
    if (!inMap(tx, ty)) return true;
    const t = tiles[ty * MW + tx];
    return t === ROCK || t === WALL || (t === GATE && !gateOpen);
  }

  function biomeAt(tx, ty) {
    const wx = tx + (vnoise(tx * 0.07, ty * 0.07) - 0.5) * 18;
    const wy = ty + (vnoise(tx * 0.07 + 40, ty * 0.07 + 40) - 0.5) * 18;
    let best = 1e9, b = 0;
    for (const [bb, x, y] of CFG.biomeSeeds) {
      const d = (wx - x) * (wx - x) + (wy - y) * (wy - y);
      if (d < best) { best = d; b = bb; }
    }
    return b;
  }

  function generateWorld() {
    paperBiomes();
    MW = CFG.MW; MH = CFG.MH; WORLD_W = MW * T; WORLD_H = MH * T;
    tiles = new Uint8Array(MW * MH); biomeMap = new Uint8Array(MW * MH); treeGrid = new Int32Array(MW * MH);
    trees = []; chests = []; shrines = []; mainPath = [];
    beds = []; lamps = []; clues = []; npcs = []; qitems = []; shelves = []; boxes = []; fires = [];
    holes = []; ovens = []; drifts = []; glades = []; pearls = []; flow = null; curPts = []; secrets = []; cracks = new Set();
    START = CFG.start;
    CASTLE = CFG.castle;
    const h = CASTLE.half;
    if (CASTLE.gate === 'west') {
      GATE_FRONT = { x: CASTLE.x - h - 3, y: CASTLE.y }; GATE_INNER = { x: CASTLE.x - h + 1, y: CASTLE.y };
    } else if (CASTLE.gate === 'east') {
      GATE_FRONT = { x: CASTLE.x + h + 3, y: CASTLE.y }; GATE_INNER = { x: CASTLE.x + h - 1, y: CASTLE.y };
    } else {
      GATE_FRONT = { x: CASTLE.x, y: CASTLE.y + h + 3 }; GATE_INNER = { x: CASTLE.x, y: CASTLE.y + h - 1 };
    }
    CAGE = CFG.cage;
    const rng = mulberry32(SEED);
    for (let ty = 0; ty < MH; ty++) for (let tx = 0; tx < MW; tx++) {
      const b = biomeAt(tx, ty), i = ty * MW + tx;
      biomeMap[i] = b; tiles[i] = b;
    }
    const set = (tx, ty, t) => { if (inMap(tx, ty)) tiles[ty * MW + tx] = t; };
    // препятствия
    for (let n = 0; n < CFG.blobs; n++) {
      const cx = 4 + Math.floor(rng() * (MW - 8)), cy = 4 + Math.floor(rng() * (MH - 8));
      const type = weighted(BIOMES[biomeMap[cy * MW + cx]].obst, rng());
      const parts = 2 + Math.floor(rng() * 4);
      for (let k = 0; k < parts; k++) {
        const w = 2 + Math.floor(rng() * 6), hh = 2 + Math.floor(rng() * 5);
        const ox = cx + Math.floor(rng() * 8) - 4, oy = cy + Math.floor(rng() * 8) - 4;
        const ecx = ox + (w - 1) / 2, ecy = oy + (hh - 1) / 2, erx = w / 2, ery = hh / 2;
        for (let y = oy; y < oy + hh; y++) for (let x = ox; x < ox + w; x++) if (((x - ecx) / erx) ** 2 + ((y - ecy) / ery) ** 2 <= 1.05) set(x, y, type);
      }
    }
    for (let ty = 0; ty < MH; ty++) for (let tx = 0; tx < MW; tx++) {
      if (tx < 2 || ty < 2 || tx >= MW - 2 || ty >= MH - 2) set(tx, ty, ROCK);
    }
    // замок
    for (let y = CASTLE.y - h - 3; y <= CASTLE.y + h + 3; y++)
      for (let x = CASTLE.x - h - 3; x <= CASTLE.x + h + 3; x++) set(x, y, CASTLE.biome);
    for (let y = CASTLE.y - h; y <= CASTLE.y + h; y++) for (let x = CASTLE.x - h; x <= CASTLE.x + h; x++) {
      const edge = x === CASTLE.x - h || x === CASTLE.x + h || y === CASTLE.y - h || y === CASTLE.y + h;
      set(x, y, edge ? WALL : FLOOR);
      if (inMap(x, y)) biomeMap[y * MW + x] = CASTLE.biome;
    }
    for (const [cx, cy] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) {
      const bx = CASTLE.x + cx * h, by = CASTLE.y + cy * h;
      for (let y = by - 1; y <= by + 1; y++) for (let x = bx - 1; x <= bx + 1; x++) set(x, y, WALL);
    }
    if (CASTLE.gate === 'west') for (let y = CASTLE.y - 1; y <= CASTLE.y + 1; y++) set(CASTLE.x - h, y, GATE);
    else if (CASTLE.gate === 'east') for (let y = CASTLE.y - 1; y <= CASTLE.y + 1; y++) set(CASTLE.x + h, y, GATE);
    else for (let x = CASTLE.x - 1; x <= CASTLE.x + 1; x++) set(x, CASTLE.y + h, GATE);

    // дороги
    const brush = (x, y, rec) => {
      for (let oy = -1; oy <= 1; oy++) for (let ox = -1; ox <= 1; ox++) {
        const tx = x + ox, ty = y + oy;
        if (!inMap(tx, ty) || tx < 2 || ty < 2 || tx >= MW - 2 || ty >= MH - 2) continue;
        const t = tiles[ty * MW + tx];
        if (t === WALL || t === GATE || t === FLOOR) continue;
        const nearCastle = Math.abs(tx - CASTLE.x) < h + 8 && Math.abs(ty - CASTLE.y) < h + 8;
        tiles[ty * MW + tx] = nearCastle ? STONE : PATH;
        if (treeGrid[ty * MW + tx]) treeGrid[ty * MW + tx] = 0;
      }
      if (rec) mainPath.push([x, y]);
    };
    const carve = (ax, ay, bx, by, rec, r = rng) => {
      let x = ax, y = ay, guard = 0;
      brush(x, y, rec);
      while ((x !== bx || y !== by) && guard++ < 6000) {
        const dx = bx - x, dy = by - y;
        const horiz = dy === 0 || (dx !== 0 && r() < Math.abs(dx) / (Math.abs(dx) + Math.abs(dy)));
        const len = 2 + Math.floor(r() * 6);
        for (let k = 0; k < len; k++) {
          if (horiz) { if (x === bx) break; x += Math.sign(dx); } else { if (y === by) break; y += Math.sign(dy); }
          brush(x, y, rec);
        }
      }
    };
    const guards = CFG.bossTiles.slice(0, -1);
    const route = [START, ...guards, GATE_FRONT];
    for (let i = 0; i < route.length - 1; i++) carve(route[i].x, route[i].y, route[i + 1].x, route[i + 1].y, true);
    carve(GATE_FRONT.x, GATE_FRONT.y, GATE_INNER.x, GATE_INNER.y, false);
    if (CHN === 1) carve(START.x, START.y, GATE_FRONT.x, GATE_FRONT.y + 6, true);
    else carve(START.x, START.y, GATE_FRONT.x, GATE_FRONT.y, true);
    const clearCircle = (cx, cy, r) => {
      for (let y = cy - r; y <= cy + r; y++) for (let x = cx - r; x <= cx + r; x++) {
        if (!inMap(x, y) || x < 2 || y < 2 || x >= MW - 2 || y >= MH - 2) continue;
        if ((x - cx) * (x - cx) + (y - cy) * (y - cy) > r * r) continue;
        const t = tiles[y * MW + x];
        treeGrid[y * MW + x] = 0;
        if (t === WALL || t === GATE || t === FLOOR || t === PATH || t === STONE) continue;
        tiles[y * MW + x] = biomeMap[y * MW + x];
      }
    };
    // ледяные реки-горки (глава 6): плавные извилистые полосы льда через полкарты
    if (CFG.slides) {
      const rs = mulberry32(SEED + 707);
      for (const [[ax, ay], [bx, by]] of CFG.slides) {
        const len = Math.hypot(bx - ax, by - ay), nx = -(by - ay) / len, ny = (bx - ax) / len;
        const amp = 3 + rs() * 5, waves = 1 + rs() * 1.5, ph = rs() * TAU;
        for (let k = 0; k <= len * 2; k++) {
          const t = k / (len * 2), w = Math.sin(t * Math.PI * waves * 2 + ph) * amp * Math.sin(t * Math.PI);
          const cx = Math.round(ax + (bx - ax) * t + nx * w), cy = Math.round(ay + (by - ay) * t + ny * w);
          for (let oy = -1; oy <= 1; oy++) for (let ox = -1; ox <= 1; ox++) {
            const x = cx + ox, y = cy + oy;
            if (!inMap(x, y) || x < 3 || y < 3 || x >= MW - 3 || y >= MH - 3) continue;
            if (Math.abs(x - CASTLE.x) <= h + 4 && Math.abs(y - CASTLE.y) <= h + 4) continue;
            const u = tiles[y * MW + x]; if (u === WALL || u === GATE || u === FLOOR || u === PATH || u === STONE) continue;
            tiles[y * MW + x] = ICE;
          }
        }
      }
    }
    // течения (глава 7): извилистые полосы через полкарты – несут вдоль себя
    if (CFG.currents) {
      flow = new Map();
      const rs = mulberry32(SEED + 717);
      for (const [[ax, ay], [bx, by]] of CFG.currents) {
        const len = Math.hypot(bx - ax, by - ay), nx = -(by - ay) / len, ny = (bx - ax) / len;
        const amp = 3 + rs() * 4, waves = 1 + rs() * 1.2, ph = rs() * TAU;
        let px = ax, py = ay;
        for (let k = 0; k <= len * 2; k++) {
          const t = k / (len * 2), w = Math.sin(t * Math.PI * waves * 2 + ph) * amp * Math.sin(t * Math.PI);
          const fx = ax + (bx - ax) * t + nx * w, fy = ay + (by - ay) * t + ny * w;
          const ddx = fx - px, ddy = fy - py, dl = Math.hypot(ddx, ddy) || 1;
          const ux = k ? ddx / dl : (bx - ax) / len, uy = k ? ddy / dl : (by - ay) / len;
          px = fx; py = fy;
          if (k % 3 === 0) curPts.push({ x: fx * T + T / 2, y: fy * T + T / 2, dx: ux, dy: uy });
          const cx = Math.round(fx), cy = Math.round(fy);
          for (let oy = -1; oy <= 1; oy++) for (let ox = -1; ox <= 1; ox++) {
            const x = cx + ox, y = cy + oy;
            if (!inMap(x, y) || x < 3 || y < 3 || x >= MW - 3 || y >= MH - 3) continue;
            if (Math.abs(x - CASTLE.x) <= h + 4 && Math.abs(y - CASTLE.y) <= h + 4) continue;
            const i = y * MW + x, u = tiles[i]; if (u === WALL || u === GATE || u === FLOOR) continue;
            if (!isGround(u) && u !== PATH && u !== STONE) tiles[i] = biomeMap[i]; // через течение всегда можно проплыть
            flow.set(i, [ux, uy]);
          }
        }
      }
    }
    for (const g of guards) clearCircle(g.x, g.y, CHN === 1 ? 8 : 9);
    clearCircle(START.x, START.y, 5);
    // сундуки
    let tries = 0;
    while (chests.length < CFG.chests && tries++ < 900) {
      const cx = 5 + Math.floor(rng() * (MW - 10)), cy = 5 + Math.floor(rng() * (MH - 10));
      if (Math.abs(cx - CASTLE.x) < h + 5 && Math.abs(cy - CASTLE.y) < h + 5) continue;
      let best = null, bd = 1e9;
      for (const [px, py] of mainPath) { const d = Math.abs(px - cx) + Math.abs(py - cy); if (d < bd) { bd = d; best = [px, py]; } }
      if (!best || bd < CFG.chestDist[0] || bd > CFG.chestDist[1]) continue;
      if (chests.some(c => Math.abs(c.tx - cx) + Math.abs(c.ty - cy) < 14)) continue;
      carve(best[0], best[1], cx, cy, false);
      clearCircle(cx, cy, 2);
      chests.push({ tx: cx, ty: cy, x: tc(cx), y: tc(cy), open: false, biome: biomeMap[cy * MW + cx] });
    }
    // деревья
    const blocked = [START, ...guards];
    for (let ty = 3; ty < MH - 3; ty++) for (let tx = 3; tx < MW - 3; tx++) {
      const t = tiles[ty * MW + tx];
      if (!isGround(t)) continue;
      if (blocked.some((p, i) => (p.x - tx) ** 2 + (p.y - ty) ** 2 < (i === 0 ? 30 : 80))) continue;
      if (chests.some(c => Math.abs(c.tx - tx) <= 1 && Math.abs(c.ty - ty) <= 1)) continue;
      if (Math.abs(tx - CASTLE.x) <= h + 1 && Math.abs(ty - CASTLE.y) <= h + 1) continue;
      if (flow && flow.has(ty * MW + tx)) continue; // течение свободно
      const pathy = (x, y) => { const u = tileAt(x, y); return u === PATH || u === STONE; };
      if (pathy(tx + 1, ty) || pathy(tx - 1, ty) || pathy(tx, ty + 1) || pathy(tx, ty - 1)) continue; // дороги свободны
      const b = biomeMap[ty * MW + tx];
      const dens = Math.min(0.16, BIOMES[b].treeP * (0.5 + vnoise(tx * 0.15 + 9, ty * 0.15 + 3)));
      if (rng() < dens) {
        trees.push({ x: tx * T + 10 + rng() * 20, y: ty * T + 14 + rng() * 20, kind: BIOMES[b].tree, s: 0.85 + rng() * 0.35 });
        treeGrid[ty * MW + tx] = trees.length;
      }
    }
    // алтари испытаний (отдельный генератор, чтобы не менять остальную карту)
    const r2 = mulberry32(SEED + 99);
    tries = 0;
    while (shrines.length < CFG.shrines && tries++ < 1500) {
      const cx = 10 + Math.floor(r2() * (MW - 20)), cy = 10 + Math.floor(r2() * (MH - 20));
      if (Math.abs(cx - CASTLE.x) < h + 11 && Math.abs(cy - CASTLE.y) < h + 11) continue;
      if (!isGround(tiles[cy * MW + cx])) continue;
      if (CFG.bossTiles.some(b => Math.abs(b.x - cx) + Math.abs(b.y - cy) < 16)) continue;
      if (Math.abs(START.x - cx) + Math.abs(START.y - cy) < 14) continue;
      if (chests.some(c => Math.abs(c.tx - cx) + Math.abs(c.ty - cy) < 8)) continue;
      if (shrines.some(s => Math.abs(s.tx - cx) + Math.abs(s.ty - cy) < 22)) continue;
      let best = null, bd = 1e9;
      for (const [px, py] of mainPath) { const d = Math.abs(px - cx) + Math.abs(py - cy); if (d < bd) { bd = d; best = [px, py]; } }
      if (!best || bd < 6 || bd > 18) continue;
      carve(best[0], best[1], cx, cy, false, r2);
      clearCircle(cx, cy, 8); // круг испытания (300 px) целиком на чистой поляне
      shrines.push({ tx: cx, ty: cy, x: tc(cx), y: tc(cy), state: 'idle', biome: biomeMap[cy * MW + cx], left: 0 });
    }
    // ---- главы Тессы: лежанки, лампы, улики, жители, полки, коробки ----
    const r3 = mulberry32(SEED + 177);
    const okSpot = (x, y) => x > 4 && y > 4 && x < MW - 5 && y < MH - 5 && !(Math.abs(x - CASTLE.x) < h + 4 && Math.abs(y - CASTLE.y) < h + 4) &&
      Math.abs(x - START.x) + Math.abs(y - START.y) > 5 && !CFG.bossTiles.some(b => Math.abs(b.x - x) + Math.abs(b.y - y) < 5);
    const taken = [];
    const free = (x, y, d) => taken.every(o => Math.abs(o[0] - x) + Math.abs(o[1] - y) >= d);
    const placeNear = (p, dmin, dmax, sep = 3) => {
      for (let k = 0; k < 24; k++) {
        const a = r3() * TAU, d = dmin + r3() * (dmax - dmin), x = Math.round(p[0] + Math.cos(a) * d), y = Math.round(p[1] + Math.sin(a) * d);
        if (!okSpot(x, y) || !free(x, y, sep)) continue;
        carve(p[0], p[1], x, y, false, r3); clearCircle(x, y, 1);
        taken.push([x, y]); return [x, y];
      }
      return null;
    };
    const pathPoint = pred => { for (let i = 0; i < 600; i++) { const p = mainPath[Math.floor(r3() * mainPath.length)]; if (p && pred(p)) return p; } return null; };
    if (CFG.beds) {
      const got = [];
      for (let i = 0; i < 400 && got.length < CFG.beds; i++) {
        const p = pathPoint(q => got.every(o => Math.abs(o.tx - q[0]) + Math.abs(o.ty - q[1]) > 16));
        if (!p) break;
        const s = placeNear(p, 2, 3); if (s) got.push({ tx: s[0], ty: s[1], x: tc(s[0]), y: tc(s[1]), cd: 0, nap: 0 });
      }
      beds = got;
    }
    if (CFG.lamps) {
      for (let i = 0; i < 400 && lamps.length < CFG.lamps; i++) {
        const p = pathPoint(q => lamps.every(o => Math.abs(o.tx - q[0]) + Math.abs(o.ty - q[1]) > 10));
        if (!p) break;
        const s = placeNear(p, 1, 2, 2); if (s) lamps.push({ tx: s[0], ty: s[1], x: tc(s[0]), y: tc(s[1]), ph: r3() * 6 });
      }
    }
    if (CFG.detective) {
      for (let gi = 0; gi < 4; gi++) {
        const B = CFG.bossTiles[gi], bb = biomeMap[B.y * MW + B.x];
        for (let k = 0; k < 3; k++) {
          let p = pathPoint(q => biomeMap[q[1] * MW + q[0]] === bb && Math.hypot(q[0] - B.x, q[1] - B.y) > 6 && Math.hypot(q[0] - B.x, q[1] - B.y) < 26 && clues.every(o => Math.abs(o.tx - q[0]) + Math.abs(o.ty - q[1]) > 6));
          if (!p) p = pathPoint(q => Math.hypot(q[0] - B.x, q[1] - B.y) < 30 && Math.hypot(q[0] - B.x, q[1] - B.y) > 6);
          if (!p) { let bd = 1e9; for (const q of mainPath) { const d = Math.hypot(q[0] - B.x, q[1] - B.y); if (d >= 4 && d < bd) { bd = d; p = q; } } }
          if (!p) p = mainPath[0];
          const s = placeNear(p, 1, 3, 2) || p;
          clues.push({ i: gi, k, tx: s[0], ty: s[1], x: tc(s[0]), y: tc(s[1]), found: false });
        }
      }
      NPCS5.forEach((def, ni) => {
        const p = pathPoint(q => biomeMap[q[1] * MW + q[0]] === def.biome && Math.abs(q[0] - START.x) + Math.abs(q[1] - START.y) > 8) || pathPoint(() => true);
        const s = placeNear(p, 2, 3, 3) || p;
        npcs.push({ def, ni, tx: s[0], ty: s[1], x: tc(s[0]), y: tc(s[1]), state: 'new' });
        const q = pathPoint(q2 => { const d = Math.hypot(q2[0] - s[0], q2[1] - s[1]); return d > 16 && d < 45; }) || pathPoint(() => true);
        const it = placeNear(q, 2, 4, 3) || q;
        qitems.push({ ni, tx: it[0], ty: it[1], x: tc(it[0]), y: tc(it[1]), active: false, taken: false });
      });
    }
    if (CFG.shelves) {
      for (let i = 0; i < 2000 && shelves.length < CFG.shelves * 2; i++) {
        const a = Math.floor(r3() * mainPath.length), b = Math.floor(r3() * mainPath.length);
        const i1 = Math.min(a, b), i2 = Math.max(a, b), P1 = mainPath[i1], P2 = mainPath[i2];
        const d = Math.hypot(P1[0] - P2[0], P1[1] - P2[1]);
        if (i2 - i1 < 40 || i2 - i1 < d * 1.6 || d < 8 || d > 30) continue;
        if (!okSpot(P1[0], P1[1]) || !okSpot(P2[0], P2[1]) || !free(P1[0], P1[1], 6) || !free(P2[0], P2[1], 6)) continue;
        const A = placeNear(P1, 2, 3, 6), B2 = A && placeNear(P2, 2, 3, 6);
        if (!A || !B2) continue;
        const k = shelves.length;
        shelves.push({ tx: A[0], ty: A[1], x: tc(A[0]), y: tc(A[1]), to: k + 1, cd: 0, inside: false });
        shelves.push({ tx: B2[0], ty: B2[1], x: tc(B2[0]), y: tc(B2[1]), to: k, cd: 0, inside: false });
      }
    }
    if (CFG.boxes) {
      for (let i = 0; i < 500 && boxes.length < CFG.boxes; i++) {
        const p = pathPoint(q => boxes.every(o => Math.abs(o.tx - q[0]) + Math.abs(o.ty - q[1]) > 7));
        if (!p) break;
        const s = placeNear(p, 2, 4, 3); if (s) boxes.push({ tx: s[0], ty: s[1], x: tc(s[0]), y: tc(s[1]) });
      }
    }
    if (CFG.fires) {
      for (let i = 0; i < 600 && fires.length < CFG.fires; i++) {
        const p = pathPoint(q => Math.abs(q[0] - START.x) + Math.abs(q[1] - START.y) > 7 && fires.every(o => Math.abs(o.tx - q[0]) + Math.abs(o.ty - q[1]) > 18));
        if (!p) break;
        const s = placeNear(p, 2, 3, 3); if (s) fires.push({ tx: s[0], ty: s[1], x: tc(s[0]), y: tc(s[1]), lit: false, ph: r3() * 6 });
      }
    }
    const placeIn = (arr, n, bset, sep, dmin, dmax, mk) => {
      for (let i = 0; i < 900 && arr.length < n; i++) {
        const p = pathPoint(q => bset.includes(biomeMap[q[1] * MW + q[0]]) && arr.every(o => Math.abs(o.tx - q[0]) + Math.abs(o.ty - q[1]) > sep));
        if (!p) break;
        const s = placeNear(p, dmin, dmax, 3); if (s) arr.push(Object.assign({ tx: s[0], ty: s[1], x: tc(s[0]), y: tc(s[1]) }, mk()));
      }
    };
    if (CFG.holes) placeIn(holes, CFG.holes, [28], 10, 2, 4, () => ({ cd: 0, prog: 0 }));
    if (CFG.ovens) placeIn(ovens, CFG.ovens, [29], 14, 2, 3, () => ({ cd: 0, prog: 0, ph: r3() * 6 }));
    if (CFG.drifts) placeIn(drifts, CFG.drifts, [27, 28, 30, 31], 6, 2, 5, () => ({ hp: 3, done: false, s: 0.85 + r3() * 0.3 }));
    if (CFG.pearls) { const bs = [...new Set(CFG.biomeSeeds.map(q => q[0]))].filter(b => b !== CFG.castle.biome); placeIn(pearls, CFG.pearls, bs, 20, 3, 7, () => ({ got: false, ph: r3() * 6 })); }
    // дорожки к объектам прокладываются после деревьев – убираем деревья вплотную к любой дорожке
    for (let ty = 1; ty < MH - 1; ty++) for (let tx = 1; tx < MW - 1; tx++) {
      const i = ty * MW + tx; if (!treeGrid[i]) continue;
      const pt = u => u === PATH || u === STONE;
      if (pt(tiles[i]) || pt(tiles[i - 1]) || pt(tiles[i + 1]) || pt(tiles[i - MW]) || pt(tiles[i + MW])) treeGrid[i] = 0;
    }
    // ---- сундуки: редкость и мимики ----
    if (chests.length) {
      const r5 = mulberry32(SEED + 313), dist0 = ch => Math.abs(ch.tx - START.x) + Math.abs(ch.ty - START.y);
      for (const ch of chests) { ch.tier = 'wood'; ch.mimic = false; ch.seen = false; }
      const far = chests.slice().sort((a, b) => dist0(b) - dist0(a)).slice(0, Math.max(2, Math.ceil(chests.length / 3)));
      for (let k = 0; k < (CHN === 1 ? 1 : 2) && far.length; k++) far.splice(Math.floor(r5() * far.length), 1)[0].tier = 'gold';
      for (const ch of chests) if (ch.tier !== 'gold') {
        if (r5() < 0.28) ch.tier = 'silver';
        if (r5() < 0.13 && dist0(ch) > 18) ch.mimic = true;
      }
    }
    // ---- глава 6: часть сундуков вмёрзла в ледяные стены ----
    const reachAll = () => {
        const seen = new Uint8Array(MW * MH), q = [START.y * MW + START.x]; seen[q[0]] = 1;
        for (let k = 0; k < q.length; k++) {
          const i = q[k], x = i % MW, y = (i - x) / MW;
          for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
            const nx = x + dx, ny = y + dy; if (!inMap(nx, ny)) continue;
            const j = ny * MW + nx; if (seen[j]) continue;
            const u = tiles[j]; if (u === ROCK || u === WALL || u === WATER || u === LAVA) continue;
            seen[j] = 1; q.push(j);
          }
        }
        const pts = [...shrines.map(o => [o.tx, o.ty]), ...guards.map(o => [o.x, o.y]), [GATE_FRONT.x, GATE_FRONT.y], ...fires.filter(o => !o.glade).map(o => [o.tx, o.ty]),
          ...chests.filter(o => !o.iced && !o.glade).map(o => [o.tx, o.ty]), ...holes.map(o => [o.tx, o.ty]), ...ovens.map(o => [o.tx, o.ty])];
        return pts.every(([x, y]) => seen[y * MW + x]);
      };
    if (CFG.icedChests && chests.length) {
      const r7 = mulberry32(SEED + 521);
      for (const ch of chests) {
        ch.iced = false;
        if (ch.mimic || r7() >= CFG.icedChests) continue;
        const ring = [];
        let ok = true;
        for (let y = ch.ty - 2; y <= ch.ty + 2 && ok; y++) for (let x = ch.tx - 2; x <= ch.tx + 2; x++) {
          if (Math.max(Math.abs(x - ch.tx), Math.abs(y - ch.ty)) !== 2) continue;
          const i = y * MW + x;
          if (!inMap(x, y) || x < 3 || y < 3 || x >= MW - 3 || y >= MH - 3 || !BIOMES[biomeMap[i]].meltable || tiles[i] === WALL || tiles[i] === GATE || tiles[i] === FLOOR) { ok = false; break; }
          ring.push([i, tiles[i], treeGrid[i]]);
        }
        if (!ok) continue;
        for (const [i] of ring) { tiles[i] = ROCK; treeGrid[i] = 0; }
        ch.iced = true;
        if (!reachAll()) { for (const [i, u, tr] of ring) { tiles[i] = u; treeGrid[i] = tr; } ch.iced = false; }
      }
    }
    // ---- тайные поляны за ледяной стеной: сундук, костёр или снежный барс ----
    if (CFG.glades) {
      const r8 = mulberry32(SEED + 919), kinds = ['chest', 'beast', 'fire', 'chest'];
      for (let it = 0; it < 3000 && glades.length < CFG.glades; it++) {
        const cx = 12 + Math.floor(r8() * (MW - 24)), cy = 12 + Math.floor(r8() * (MH - 24));
        if (![27, 28, 31].includes(biomeMap[cy * MW + cx])) continue;
        if (Math.abs(cx - CASTLE.x) < h + 10 && Math.abs(cy - CASTLE.y) < h + 10) continue;
        if (Math.abs(cx - START.x) + Math.abs(cy - START.y) < 20) continue;
        if (CFG.bossTiles.some(b => Math.hypot(b.x - cx, b.y - cy) < 16)) continue;
        if (mainPath.some(([px, py]) => Math.abs(px - cx) + Math.abs(py - cy) < 9)) continue;
        const near = (arr, d) => arr.some(o => Math.hypot(o.tx - cx, o.ty - cy) < d);
        if (near(chests, 9) || near(shrines, 12) || near(fires, 8) || near(glades, 30) || near(holes, 8) || near(ovens, 8)) continue;
        const ring = [], inner = [];
        let ok = true;
        for (let y = cy - 6; y <= cy + 6 && ok; y++) for (let x = cx - 6; x <= cx + 6; x++) {
          const d = Math.hypot(x - cx, y - cy), i = y * MW + x;
          if (d > 5.6) continue;
          if (!BIOMES[biomeMap[i]].meltable || tiles[i] === WALL || tiles[i] === FLOOR || tiles[i] === GATE) { ok = false; break; }
          (d >= 4.5 ? ring : inner).push([i, tiles[i], treeGrid[i]]);
        }
        if (!ok) continue;
        for (const [i] of ring) { tiles[i] = ROCK; treeGrid[i] = 0; }
        for (const [i] of inner) { tiles[i] = biomeMap[i]; treeGrid[i] = 0; }
        if (!reachAll()) { for (const [i, u, tr] of ring.concat(inner)) { tiles[i] = u; treeGrid[i] = tr; } continue; }
        const g = { tx: cx, ty: cy, x: tc(cx), y: tc(cy), kind: kinds[glades.length % kinds.length], ring: ring.map(r => r[0]), open: false, done: false, seen: false };
        glades.push(g);
        if (g.kind === 'chest') chests.push({ tx: cx, ty: cy, x: tc(cx), y: tc(cy), open: false, biome: biomeMap[cy * MW + cx], tier: r8() < 0.5 ? 'gold' : 'silver', mimic: false, seen: false, glade: true, iced: false });
        else if (g.kind === 'fire') fires.push({ tx: cx, ty: cy, x: tc(cx), y: tc(cy), lit: false, ph: r8() * 6, glade: true });
      }
    }
    // ---- тайники: комната 3×3 внутри скального массива, вход закрыт треснувшей стеной ----
    if (typeof CHN === 'number') {
      const rs = mulberry32(SEED + 1337), want = 2 + (rs() < 0.5 ? 1 : 0);
      const solid = (x, y) => { const t = tiles[y * MW + x]; return t === ROCK || t === WALL; };
      const open = (x, y) => inMap(x, y) && !isSolidTile(x, y, false);
      for (let it = 0; it < 8000 && secrets.length < want; it++) {
        const cx = 5 + Math.floor(rs() * (MW - 10)), cy = 5 + Math.floor(rs() * (MH - 10));
        if (Math.abs(cx - CASTLE.x) < CASTLE.half + 4 && Math.abs(cy - CASTLE.y) < CASTLE.half + 4) continue;
        if (Math.abs(cx - START.x) < 8 && Math.abs(cy - START.y) < 8) continue;
        let ok = true;
        for (let y = cy - 2; y <= cy + 2 && ok; y++) for (let x = cx - 2; x <= cx + 2; x++) if (!solid(x, y)) { ok = false; break; }
        if (!ok || secrets.some(o => Math.abs(o.cx - cx) < 16 && Math.abs(o.cy - cy) < 16) || chests.some(o => Math.abs(o.tx - cx) < 5 && Math.abs(o.ty - cy) < 5)) continue;
        const sides = [[0, -1], [1, 0], [0, 1], [-1, 0]].filter(([dx, dy]) => open(cx + dx * 3, cy + dy * 3));
        if (!sides.length) continue;
        const [dx, dy] = sides[Math.floor(rs() * sides.length)];
        for (let y = cy - 1; y <= cy + 1; y++) for (let x = cx - 1; x <= cx + 1; x++) { const i = y * MW + x; tiles[i] = biomeMap[i]; treeGrid[i] = 0; }
        const ex = cx + dx * 2, ey = cy + dy * 2, ci = ey * MW + ex;
        cracks.add(ci);
        const ch = { tx: cx, ty: cy, x: tc(cx), y: tc(cy), open: false, biome: biomeMap[cy * MW + cx], tier: rs() < 0.35 ? 'gold' : 'silver', mimic: false, seen: false, secret: true, iced: false };
        chests.push(ch);
        secrets.push({ cx, cy, ex, ey, i: ci, open: false, chest: ch, hinted: false });
      }
    }
    // ---- карманная арена испытаний: под картой, за полосой пустоты ----
    PLAY_H = MH;
    const GAP = 14, AS = 22, NH = MH + GAP + AS + 2;
    const nt = new Uint8Array(MW * NH), nbm = new Uint8Array(MW * NH), ngr = new Int32Array(MW * NH);
    nt.set(tiles); nbm.set(biomeMap); ngr.set(treeGrid);
    for (let y = MH; y < NH; y++) for (let x = 0; x < MW; x++) { nt[y * MW + x] = WALL; nbm[y * MW + x] = ARENA_BIOME; }
    const ax0 = Math.floor(MW / 2 - AS / 2), ay0 = MH + GAP, half = AS / 2 - 1;
    for (let y = ay0; y < ay0 + AS; y++) for (let x = ax0; x < ax0 + AS; x++) {
      const qx = (x - (ax0 + AS / 2 - 0.5)) / half, qy = (y - (ay0 + AS / 2 - 0.5)) / half;
      if (qx ** 4 + qy ** 4 <= 1) nt[y * MW + x] = FLOOR; // скруглённый квадрат
    }
    for (const [px, py] of [[-6, -6], [4, -6], [-6, 4], [4, 4]]) for (let dy = 0; dy < 2; dy++) for (let dx = 0; dx < 2; dx++) nt[(ay0 + AS / 2 + py + dy) * MW + ax0 + AS / 2 + px + dx] = WALL;
    tiles = nt; biomeMap = nbm; treeGrid = ngr; MH = NH; WORLD_H = MH * T;
    ARENA = { x: tc(ax0 + AS / 2), y: tc(ay0 + AS / 2), exit: { x: tc(ax0 + AS / 2), y: tc(ay0 + AS - 3) } };
    chunkCache.clear(); chunkJob = null;
    buildMinimap();
  }

  // ------------------------------------------------------------------
  //  Отрисовка карты чанками
  // ------------------------------------------------------------------
  const PAL = {
    [PATH]: ['#7a5236', '#855b3c', '#6c482f'], [STONE]: ['#8a8a8e', '#98989c', '#7c7c80'],
    [WATER]: ['#8fcbe8', '#a2d7f0', '#82bfdc'], [ROCK]: ['#a4a4a8', '#b2b2b6', '#96969a'],
    [WALL]: ['#4e4262', '#584b6e', '#433856'], [LAVA]: ['#e0521b', '#f57a24', '#c8410f'],
    [FLOOR]: ['#4b4458', '#554d63', '#433d50'], [ICE]: ['#bfe5f4', '#d4f0fb', '#aed8ea'],
  };
  const PATH_BY_BIOME = { 5: ['#c9a466', '#d2ae70', '#bd9858'], 6: ['#5a4038', '#644840', '#4e3830'], 7: ['#4a4a6e', '#545478', '#404062'], 8: ['#3a2a5a', '#443266', '#30224c'] };
  const CHUNK = 16, CHPX = CHUNK * T;
  const chunkCache = new Map();

  function tilePal(t, b) {
    if (isGround(t)) return BIOMES[t].ground;
    const bi = BIOMES[b];
    if (t === WATER && bi.water) return bi.water;
    if (t === ROCK && bi.rock) return bi.rock;
    if (t === PATH && bi.path) return bi.path;
    if (t === PATH && PATH_BY_BIOME[b]) return PATH_BY_BIOME[b];
    if (t === STONE && bi.mirror) return ['#e4e4f6', '#f2f2ff', '#d6d6ec'];
    if (t === GATE) return PAL[FLOOR];
    return PAL[t];
  }
  function drawTile(c, tx, ty, ox, oy) {
    const i = ty * MW + tx, t = tiles[i], b = biomeMap[i], bi = BIOMES[b];
    const neon = bi.neon;
    if ((t === FLOOR || t === GATE) && neon) {
      c.fillStyle = (tx + ty) % 2 ? '#22143e' : '#2a1a4c'; c.fillRect(ox, oy, T, T);
      c.strokeStyle = 'rgba(63,240,255,0.25)'; c.lineWidth = 1; c.strokeRect(ox + 0.5, oy + 0.5, T - 1, T - 1);
      return;
    }
    if (t === WALL && neon) {
      c.fillStyle = '#1e1236'; c.fillRect(ox, oy, T, T);
      c.fillStyle = '#ff3ea5'; c.fillRect(ox, oy, T, 3);
      c.fillStyle = 'rgba(255,62,165,0.3)'; c.fillRect(ox, oy + 3, T, 3);
      if (tileAt(tx, ty + 1) !== WALL) { c.fillStyle = '#120a22'; c.fillRect(ox, oy + T - 12, T, 12); c.fillStyle = '#3ff0ff'; c.fillRect(ox, oy + T - 13, T, 2); }
      return;
    }
    if (bi.arena) {
      const st = ARENA_STYLE[CHN] || ARENA_STYLE[1];
      if (t === FLOOR) {
        c.fillStyle = (tx + ty) % 2 ? st.floor[0] : st.floor[1]; c.fillRect(ox, oy, T, T);
        const h = hash2(tx * 5 + 3, ty * 7 + 1);
        if (h < 0.45) { c.strokeStyle = st.crack; c.lineWidth = 2; c.beginPath(); c.moveTo(ox + h * T, oy); c.lineTo(ox + T * 0.5, oy + T * (0.3 + h)); c.lineTo(ox + T * (1 - h), oy + T); c.stroke(); }
        if (h > 0.85) { c.fillStyle = st.ember; c.beginPath(); c.arc(ox + 20, oy + 20, 3, 0, TAU); c.fill(); }
        return;
      }
      const nearFloor = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [-1, -1], [1, -1], [-1, 1]].some(([dx, dy]) => tileAt(tx + dx, ty + dy) === FLOOR);
      if (!nearFloor) { c.fillStyle = '#040208'; c.fillRect(ox, oy, T, T); if (hash2(tx, ty) < 0.04) { c.fillStyle = st.ember; c.fillRect(ox + 18, oy + 18, 2, 2); } return; }
      c.fillStyle = st.wall; c.fillRect(ox, oy, T, T);
      c.fillStyle = 'rgba(0,0,0,0.3)'; for (let k = 0; k < 4; k++) c.fillRect(ox, oy + k * 10, T, 2);
      if (tileAt(tx, ty + 1) === FLOOR) { c.fillStyle = st.crack; c.fillRect(ox, oy + T - 4, T, 3); }
      return;
    }
    if (bi.castleStyle === 'ice' && (t === FLOOR || t === GATE)) {
      c.fillStyle = (tx + ty) % 2 ? '#cfe8f8' : '#bcdcf2'; c.fillRect(ox, oy, T, T);
      c.fillStyle = 'rgba(255,255,255,0.45)'; c.beginPath(); c.moveTo(ox + 4, oy + T - 6); c.lineTo(ox + 12, oy + T - 6); c.lineTo(ox + T - 6, oy + 6); c.lineTo(ox + T - 14, oy + 6); c.fill();
      c.strokeStyle = 'rgba(90,150,200,0.35)'; c.lineWidth = 1; c.strokeRect(ox + 0.5, oy + 0.5, T - 1, T - 1);
      if (hash2(tx, ty) < 0.07) { c.fillStyle = '#ffffff'; star(c, ox + 20, oy + 20, 3, 0, 6); c.fill(); }
      return;
    }
    if (bi.castleStyle === 'ice' && t === WALL) {
      c.fillStyle = '#7aa8d8'; c.fillRect(ox, oy, T, T);
      c.fillStyle = 'rgba(255,255,255,0.35)'; c.fillRect(ox + 5, oy + 6, 5, 22); c.fillRect(ox + 22, oy + 4, 3, 14);
      c.fillStyle = '#e8f8ff'; c.fillRect(ox, oy, T, 3);
      if (tileAt(tx, ty + 1) !== WALL) {
        c.fillStyle = '#3a6a9a'; c.fillRect(ox, oy + T - 12, T, 12);
        c.fillStyle = '#bfeaff'; for (let k = 0; k < 4; k++) { c.beginPath(); c.moveTo(ox + k * 10 + 2, oy + T - 12); c.lineTo(ox + k * 10 + 8, oy + T - 12); c.lineTo(ox + k * 10 + 5, oy + T - 3 - (k % 2) * 4); c.fill(); }
      }
      return;
    }
    if (bi.castleStyle === 'coral' && (t === FLOOR || t === GATE)) { // перламутровый пол цитадели
      const g = c.createLinearGradient(ox, oy, ox + T, oy + T); g.addColorStop(0, (tx + ty) % 2 ? '#f6d8e4' : '#ecc8d8'); g.addColorStop(1, (tx + ty) % 2 ? '#e8c0d4' : '#dcb4ca');
      c.fillStyle = g; c.fillRect(ox, oy, T, T);
      c.strokeStyle = 'rgba(200,120,160,0.35)'; c.lineWidth = 1; c.strokeRect(ox + 0.5, oy + 0.5, T - 1, T - 1);
      if (hash2(tx, ty) < 0.12) { const cx = ox + 20, cy = oy + 22; c.strokeStyle = 'rgba(255,255,255,0.7)'; c.lineWidth = 1.2; for (let r = -6; r <= 6; r += 3) { c.beginPath(); c.moveTo(cx, cy + 4); c.lineTo(cx + r, cy - 5); c.stroke(); } }
      return;
    }
    if (bi.castleStyle === 'coral' && t === WALL) { // стены из коралла с ракушками
      c.fillStyle = '#d0607e'; c.fillRect(ox, oy, T, T);
      c.fillStyle = '#e8809a'; for (let k = 0; k < 4; k++) { c.beginPath(); c.arc(ox + 6 + hash2(tx * 3 + k, ty) * 28, oy + 6 + hash2(tx, ty * 3 + k) * 22, 4 + hash2(k, tx + ty) * 3, 0, TAU); c.fill(); }
      c.fillStyle = '#ffb4c4'; c.fillRect(ox, oy, T, 3);
      if (tileAt(tx, ty + 1) !== WALL) {
        c.fillStyle = '#8a2a48'; c.fillRect(ox, oy + T - 12, T, 12);
        c.fillStyle = '#ffd0dc'; for (let k = 0; k < 3; k++) { c.beginPath(); c.ellipse(ox + 7 + k * 13, oy + T - 6, 4, 3, 0, 0, TAU); c.fill(); }
      }
      return;
    }
    if (bi.castleStyle && (t === FLOOR || t === GATE)) {
      const night = bi.castleStyle === 'attic';
      for (let k = 0; k < 4; k++) { c.fillStyle = night ? ((k + tx) % 2 ? '#2a2230' : '#241d2a') : ((k + tx) % 2 ? '#d4a676' : '#c89a6a'); c.fillRect(ox, oy + k * 10, T, 9); }
      c.fillStyle = 'rgba(0,0,0,0.3)'; c.fillRect(ox + ((tx * 13 + ty * 7) % 4) * 10, oy, 1.5, T);
      if (night && hash2(tx, ty) < 0.08) { c.fillStyle = '#3ff0a0'; c.fillRect(ox + 10 + hash2(ty, tx) * 20, oy + 14, 3, 3); }
      return;
    }
    if (bi.castleStyle && t === WALL) {
      const night = bi.castleStyle === 'attic';
      c.fillStyle = night ? '#3a2a24' : '#8a5a3a'; c.fillRect(ox, oy, T, T);
      c.fillStyle = 'rgba(0,0,0,0.25)'; for (let k = 0; k < 4; k++) c.fillRect(ox, oy + k * 10, T, 2);
      if (tileAt(tx, ty + 1) !== WALL) { c.fillStyle = night ? '#1a1210' : '#5a3a20'; c.fillRect(ox, oy + T - 12, T, 12); c.fillStyle = night ? '#3ff0a0' : '#ffd25a'; c.fillRect(ox, oy + T - 13, T, 2); }
      return;
    }
    if (bi.mirror && (t === FLOOR || t === GATE)) {
      c.fillStyle = (tx + ty) % 2 ? '#dcdcf2' : '#c8c8e4'; c.fillRect(ox, oy, T, T);
      c.fillStyle = 'rgba(255,255,255,0.45)'; c.beginPath(); c.moveTo(ox + 4, oy + T - 4); c.lineTo(ox + 14, oy + T - 4); c.lineTo(ox + T - 4, oy + 4); c.lineTo(ox + T - 14, oy + 4); c.fill();
      c.strokeStyle = 'rgba(120,120,170,0.35)'; c.lineWidth = 1; c.strokeRect(ox + 0.5, oy + 0.5, T - 1, T - 1);
      return;
    }
    if (bi.mirror && t === WALL) {
      c.fillStyle = '#9a9abc'; c.fillRect(ox, oy, T, T);
      c.fillStyle = '#ffffff'; c.fillRect(ox, oy, T, 3);
      c.fillStyle = 'rgba(255,255,255,0.35)'; c.fillRect(ox + 6, oy + 8, 4, 20);
      if (tileAt(tx, ty + 1) !== WALL) { c.fillStyle = '#5a5a7a'; c.fillRect(ox, oy + T - 12, T, 12); c.fillStyle = '#bfeaff'; c.fillRect(ox, oy + T - 13, T, 2); }
      return;
    }
    if (bi.rainbow && t === PATH) {
      for (let k = 0; k < 4; k++) { c.fillStyle = RAINBOW[(tx + ty + k) % 7]; c.fillRect(ox, oy + k * 10, T, 10); }
      c.fillStyle = 'rgba(255,255,255,0.35)'; c.fillRect(ox, oy, T, T);
      return;
    }
    const pal = tilePal(t, b);
    // вода, камни, лава, лёд и дорожки – со скруглёнными краями поверх земли
    const organic = t === PATH || t === WATER || t === LAVA || t === ICE || (t === STONE && !bi.mirror) || (t === ROCK && !bi.furniture && !bi.fence);
    let ex = null;
    if (organic) {
      c.save();
      ex = tileShape(c, ox, oy, tx, ty, sameGroup(t), t === PATH || t === STONE ? 11 : 15);
      c.fillStyle = pal[0]; c.fill(); c.clip();
    } else if (!isGround(t)) { c.fillStyle = pal[0]; c.fillRect(ox, oy, T, T); }
    if (!isGround(t) && !(t === ROCK && (bi.furniture || bi.fence))) for (let k = 0; k < 9; k++) {
      const h1 = hash2(tx * 31 + k * 7, ty * 17 + k * 13), h2 = hash2(tx * 11 + k * 29, ty * 41 + k * 3);
      c.fillStyle = pal[1 + (k & 1)];
      if (organic) { c.beginPath(); c.arc(ox + 2 + Math.floor(h1 * 9) * 4, oy + 2 + Math.floor(h2 * 9) * 4, 2.2, 0, TAU); c.fill(); }
      else c.fillRect(ox + Math.floor(h1 * 9) * 4, oy + Math.floor(h2 * 9) * 4, 4, 4);
    }
    const below = tileAt(tx, ty + 1), above = tileAt(tx, ty - 1);
    const hr = hash2(tx * 7 + 3, ty * 5 + 1);
    if (t === FLOOR || t === GATE) {
      c.strokeStyle = 'rgba(0,0,0,0.25)'; c.lineWidth = 2; c.strokeRect(ox + 1, oy + 1, T - 2, T - 2);
    } else if (t === WALL) {
      c.fillStyle = 'rgba(0,0,0,0.25)';
      for (let r = 0; r < 4; r++) { c.fillRect(ox, oy + r * 10, T, 2); c.fillRect(ox + ((r & 1) ? 6 : 26), oy + r * 10, 2, 10); }
      if (below !== WALL) { c.fillStyle = '#2c2238'; c.fillRect(ox, oy + T - 12, T, 12); c.fillStyle = '#7a6a94'; c.fillRect(ox, oy, T, 3); }
    } else if (t === ROCK && (bi.furniture || bi.fence)) {
      drawFurniture(c, bi, pal, ox, oy, below, above, hr);
    } else if (t === ROCK) {
      c.fillStyle = 'rgba(255,255,255,0.18)'; c.fillRect(ox + 4, oy + 6, 10, 3);
      if (below !== ROCK) { c.fillStyle = shade(pal[0], -0.3); c.fillRect(ox, oy + T - 12, T, 12); c.fillStyle = 'rgba(0,0,0,0.25)'; c.fillRect(ox, oy + T - 4, T, 4); }
      if (above !== ROCK) { c.fillStyle = 'rgba(255,255,255,0.3)'; c.fillRect(ox, oy, T, 3); }
      if (b === 7 && hr < 0.4) { c.fillStyle = 'rgba(91,227,255,0.6)'; c.fillRect(ox + 14, oy + 10, 4, 10); }
      if (bi.candy) { c.fillStyle = 'rgba(255,111,181,0.7)'; for (let k = -2; k < 4; k++) { c.beginPath(); c.moveTo(ox + k * 14, oy + T); c.lineTo(ox + k * 14 + 7, oy + T); c.lineTo(ox + k * 14 + 7 + T, oy); c.lineTo(ox + k * 14 + T, oy); c.fill(); } }
      if (bi.mirror) { c.fillStyle = 'rgba(255,255,255,0.6)'; c.beginPath(); c.moveTo(ox + 6, oy + 26); c.lineTo(ox + 12, oy + 26); c.lineTo(ox + 26, oy + 6); c.lineTo(ox + 20, oy + 6); c.fill(); }
      if (b === 9 && hr < 0.5) { c.fillStyle = '#ff3ea5'; c.fillRect(ox + 4, oy + 12, 30, 3); c.fillStyle = '#3ff0ff'; c.fillRect(ox + 8, oy + 16, 26, 2); }
      if (b === 12) { c.fillStyle = ['#c0392b', '#2980b9', '#f1c40f'][Math.floor(hr * 3)]; c.fillRect(ox + 8 + hr * 14, oy + 10, 8, 5); }
      if (neon && hr < 0.5) { c.fillStyle = '#ff3ea5'; c.fillRect(ox + 6, oy + 14, 28, 2); }
    } else if (t === WATER) {
      c.fillStyle = 'rgba(255,255,255,0.35)';
      if (hr < 0.5) c.fillRect(ox + 8 + Math.floor(hr * 30), oy + 14, 10, 2);
      if (above !== WATER) { c.fillStyle = 'rgba(0,30,60,0.35)'; c.fillRect(ox, oy, T, 6); }
      if (b === 11) { c.fillStyle = '#ffffff'; c.fillRect(ox + Math.floor(hr * 30), oy + Math.floor(hash2(ty, tx) * 30), 2, 2); c.fillRect(ox + Math.floor(hash2(tx, 7) * 34), oy + Math.floor(hash2(9, ty) * 34), 1, 1); }
      if (b === 12 && hr < 0.6) { c.fillStyle = 'rgba(220,255,180,0.8)'; c.beginPath(); c.arc(ox + 8 + hr * 24, oy + 12 + hr * 14, 3, 0, TAU); c.fill(); }
      if (b === 9) { c.fillStyle = 'rgba(63,240,160,0.55)'; c.fillRect(ox + 6 + Math.floor(hr * 20), oy + 8, 2, 6); c.fillRect(ox + 20, oy + 22 + Math.floor(hr * 8), 5, 2); }
    } else if (t === LAVA) {
      c.fillStyle = '#ffd23a';
      for (let k = 0; k < 3; k++) {
        const hh = hash2(tx * 3 + k, ty * 9 + k);
        c.fillRect(ox + Math.floor(hh * 8) * 4, oy + Math.floor(hash2(ty + k, tx * 2) * 8) * 4, 6, 4);
      }
      if (above !== LAVA) { c.fillStyle = 'rgba(60,0,0,0.4)'; c.fillRect(ox, oy, T, 6); }
    } else if (t === ICE) {
      c.strokeStyle = 'rgba(255,255,255,0.7)'; c.lineWidth = 2;
      c.beginPath(); c.moveTo(ox + 6 + hr * 10, oy + 30); c.lineTo(ox + 22 + hr * 10, oy + 14); c.stroke();
    } else if (isGround(t)) {
      drawDeco(c, bi.deco, tx, ty, ox, oy);
      if (above === ROCK || above === WALL) { c.fillStyle = 'rgba(0,0,0,0.3)'; c.fillRect(ox, oy, T, 7); }
    }
    if (organic) {
      // кромка: пена у воды, тень у дорожки
      const wet = t === WATER || t === LAVA || t === ICE;
      c.fillStyle = wet ? 'rgba(255,255,255,0.22)' : t === ROCK ? 'rgba(0,0,0,0.12)' : 'rgba(0,0,0,0.1)';
      const bw = wet ? 3 : 2;
      if (!ex.n) c.fillRect(ox, oy, T, bw); if (!ex.s) c.fillRect(ox, oy + T - bw, T, bw);
      if (!ex.w) c.fillRect(ox, oy, bw, T); if (!ex.e) c.fillRect(ox + T - bw, oy, bw, T);
      c.restore();
    }
  }
  // ---- поверхность: земля в два слоя (основа + мягкие пятна), формы со скруглёнными краями ----
  function drawGroundBase(c, tx, ty, ox, oy) {
    const i = ty * MW + tx, t = tiles[i], bi = BIOMES[isGround(t) ? t : biomeMap[i]];
    if (t === FLOOR || t === WALL || t === GATE) return;
    const pal = bi.ground;
    c.fillStyle = pal[0]; c.fillRect(ox, oy, T, T);
    if (bi.floor) { drawFloor(c, bi.floor, pal, tx, ty, ox, oy); return; }
    for (let k = 0; k < 14; k++) {
      const h1 = hash2(tx * 31 + k * 7, ty * 17 + k * 13), h2 = hash2(tx * 11 + k * 29, ty * 41 + k * 3), s = 2 + Math.floor(hash2(tx + k * 5, ty * 3 + k) * 3);
      c.fillStyle = pal[1 + (k & 1)];
      c.fillRect(ox + Math.floor(h1 * 19) * 2, oy + Math.floor(h2 * 19) * 2, s, s);
    }
  }
  function drawGroundDetail(c, tx, ty, ox, oy) {
    if (!inMap(tx, ty)) return;
    const i = ty * MW + tx, t = tiles[i], bi = BIOMES[isGround(t) ? t : biomeMap[i]];
    if (t === FLOOR || t === WALL || t === GATE || bi.floor) return;
    const pal = bi.ground, h1 = hash2(tx * 3 + 11, ty * 7 + 5), h2 = hash2(tx * 13 + 1, ty * 5 + 3), h3 = hash2(tx + 17, ty * 19 + 2);
    c.globalAlpha = 0.45;
    c.fillStyle = h1 < 0.5 ? pal[1] : pal[2];
    c.beginPath(); c.ellipse(ox + h2 * T, oy + h3 * T, 9 + h1 * 13, 6 + h3 * 9, h2 * 3, 0, TAU); c.fill();
    if (h3 > 0.55) { c.fillStyle = shade(pal[0], h2 > 0.5 ? 0.1 : -0.1); c.beginPath(); c.arc(ox + h1 * T, oy + h2 * T, 7 + h3 * 9, 0, TAU); c.fill(); }
    c.globalAlpha = 1;
    if (bi.deco === 'grass' || bi.deco === 'flowers' || bi.deco === 'reeds' || bi.deco === 'glitch' || bi.deco === 'leaves') {
      c.strokeStyle = shade(pal[0], -0.28); c.lineWidth = 1.5;
      for (let k = 0; k < 3; k++) {
        const x = ox + hash2(tx * 7 + k, ty * 3 + 1) * T, y = oy + hash2(ty * 7 + k, tx * 5 + 2) * T;
        c.beginPath(); c.moveTo(x, y + 4); c.lineTo(x - 2.5, y - 2); c.moveTo(x, y + 4); c.lineTo(x + 2, y - 3); c.stroke();
      }
    }
  }
  const sameGroup = t => (t === PATH || t === STONE) ? (u => u === PATH || u === STONE || u === GATE || u === FLOOR)
    : t === ROCK ? (u => u === ROCK || u === WALL) : (u => u === t);
  function tileShape(c, ox, oy, tx, ty, test, r) {
    const n = test(tileAt(tx, ty - 1)), s = test(tileAt(tx, ty + 1)), w = test(tileAt(tx - 1, ty)), e = test(tileAt(tx + 1, ty));
    const tl = !n && !w ? r : 0, tr = !n && !e ? r : 0, br = !s && !e ? r : 0, bl = !s && !w ? r : 0;
    c.beginPath();
    c.moveTo(ox + tl, oy);
    c.lineTo(ox + T - tr, oy); if (tr) c.quadraticCurveTo(ox + T, oy, ox + T, oy + tr);
    c.lineTo(ox + T, oy + T - br); if (br) c.quadraticCurveTo(ox + T, oy + T, ox + T - br, oy + T);
    c.lineTo(ox + bl, oy + T); if (bl) c.quadraticCurveTo(ox, oy + T, ox, oy + T - bl);
    c.lineTo(ox, oy + tl); if (tl) c.quadraticCurveTo(ox, oy, ox + tl, oy);
    c.closePath();
    return { n, s, w, e };
  }

  function drawFloor(c, kind, pal, tx, ty, ox, oy) {
    c.save(); c.beginPath(); c.rect(ox, oy, T, T); c.clip();
    switch (kind) {
      case 'parquet':
        if ((tx + ty) % 2) { c.fillStyle = pal[1]; c.fillRect(ox, oy, T, T / 2 - 1); c.fillStyle = pal[2]; c.fillRect(ox, oy + T / 2, T, T / 2 - 1); }
        else { c.fillStyle = pal[2]; c.fillRect(ox, oy, T / 2 - 1, T); c.fillStyle = pal[1]; c.fillRect(ox + T / 2, oy, T / 2 - 1, T); }
        c.fillStyle = 'rgba(0,0,0,0.18)'; c.fillRect(ox, oy + T - 1, T, 1); c.fillRect(ox + T - 1, oy, 1, T);
        break;
      case 'boards':
        for (let k = 0; k < 4; k++) { c.fillStyle = pal[(k + tx) % 2 ? 1 : 2]; c.fillRect(ox, oy + k * 10, T, 9); }
        c.fillStyle = 'rgba(0,0,0,0.25)'; c.fillRect(ox + ((tx * 13 + ty * 7) % 4) * 10, oy, 1.5, T);
        break;
      case 'checker':
        c.fillStyle = (tx + ty) % 2 ? pal[1] : shade(pal[0], -0.12); c.fillRect(ox, oy, T, T);
        c.fillStyle = 'rgba(255,255,255,0.12)'; c.fillRect(ox + 2, oy + 2, T - 4, 3);
        break;
      case 'tiles':
        for (let k = 0; k < 2; k++) for (let m = 0; m < 2; m++) { c.fillStyle = (k + m + tx + ty) % 2 ? pal[1] : pal[2]; c.fillRect(ox + k * 20 + 1, oy + m * 20 + 1, 18, 18); }
        break;
      case 'carpet':
        for (let k = 0; k < 6; k++) { c.fillStyle = pal[1 + (k & 1)]; c.fillRect(ox + Math.floor(hash2(tx * 5 + k, ty * 3 + k) * 18) * 2, oy + Math.floor(hash2(ty + k, tx * 2 + k) * 18) * 2, 3, 3); }
        if ((tx * 3 + ty * 5) % 7 === 0) { c.fillStyle = shade(pal[0], 0.15); c.beginPath(); c.arc(ox + 20, oy + 20, 6, 0, TAU); c.fill(); }
        break;
      case 'paving': {
        const off = ty % 2 ? 10 : 0;
        for (let k = -1; k < 3; k++) { c.fillStyle = pal[(k + tx + ty + 8) % 2 ? 1 : 2]; c.fillRect(ox + k * 20 + off + 1, oy + 1, 18, 18); c.fillRect(ox + k * 20 + 11 - off, oy + 21, 18, 18); }
        break;
      }
    }
    c.restore();
  }
  function drawFurniture(c, bi, pal, ox, oy, below, above, hr) {
    if (bi.fence) {
      c.fillStyle = shade(pal[0], -0.25); c.fillRect(ox, oy, T, T);
      for (let k = 0; k < 4; k++) { c.fillStyle = pal[1]; c.fillRect(ox + k * 10 + 1, oy + 4, 8, T - 4); c.beginPath(); c.moveTo(ox + k * 10 + 1, oy + 4); c.lineTo(ox + k * 10 + 5, oy); c.lineTo(ox + k * 10 + 9, oy + 4); c.fill(); }
      c.fillStyle = 'rgba(0,0,0,0.25)'; c.fillRect(ox, oy + 12, T, 3); c.fillRect(ox, oy + 28, T, 3);
      return;
    }
    if (bi.toyRocks) {
      const col = pal[Math.floor(hr * 3)];
      c.fillStyle = col; c.fillRect(ox + 1, oy + 1, T - 2, T - 2); c.strokeStyle = shade(col, -0.35); c.lineWidth = 2; c.strokeRect(ox + 2, oy + 2, T - 4, T - 4);
      c.fillStyle = 'rgba(255,255,255,0.85)'; c.font = 'bold 18px sans-serif'; c.textAlign = 'center'; c.fillText('АБВГДЕЖЗ'[Math.floor(hr * 8)], ox + T / 2, oy + T / 2 + 6);
      return;
    }
    if (above !== ROCK) { c.fillStyle = shade(pal[0], 0.25); c.fillRect(ox, oy, T, 6); }
    c.strokeStyle = 'rgba(0,0,0,0.35)'; c.lineWidth = 1.5; c.strokeRect(ox + 4, oy + 9, T - 8, 12); c.strokeRect(ox + 4, oy + 24, T - 8, 12);
    c.fillStyle = '#d8c080'; c.fillRect(ox + T / 2 - 3, oy + 14, 6, 2); c.fillRect(ox + T / 2 - 3, oy + 29, 6, 2);
    if (below !== ROCK) { c.fillStyle = shade(pal[0], -0.35); c.fillRect(ox, oy + T - 6, T, 6); }
  }
  function drawDeco(c, deco, tx, ty, ox, oy) {
    const d = hash2(tx * 13 + 5, ty * 19 + 7), e = hash2(tx * 3 + 1, ty * 7 + 2);
    const px = ox + 6 + Math.floor(e * 24), py = oy + 8 + Math.floor((d * 997) % 22);
    switch (deco) {
      case 'grass':
        if (d < 0.12) { c.fillStyle = ['#ff8fb1', '#ffe066', '#b8a6ff'][Math.floor(d * 1000) % 3]; c.fillRect(px, py, 4, 4); }
        else if (d < 0.35) { c.fillStyle = '#2f5a35'; c.fillRect(px, py, 2, 6); c.fillRect(px + 4, py + 2, 2, 4); }
        break;
      case 'reeds':
        if (d < 0.18) { c.fillStyle = '#5c6e2e'; c.fillRect(px, oy + 8, 2, 14); c.fillStyle = '#7a4a2a'; c.fillRect(px - 1, oy + 6, 4, 6); }
        break;
      case 'snow':
        if (d < 0.15) { c.fillStyle = '#ffffff'; c.fillRect(px, py, 3, 3); }
        break;
      case 'bones':
        if (d < 0.08) { c.fillStyle = '#b26bff'; c.fillRect(px, oy + 16, 6, 4); c.fillStyle = '#d9d0e6'; c.fillRect(px + 2, oy + 20, 2, 4); }
        else if (d < 0.14) { c.fillStyle = '#d8d0c0'; c.fillRect(ox + 10, oy + 20, 10, 3); c.fillRect(ox + 9, oy + 19, 3, 5); c.fillRect(ox + 19, oy + 19, 3, 5); }
        break;
      case 'flowers':
        if (d < 0.35) {
          const col = ['#ff6fb5', '#ffe04a', '#ffffff', '#b18cff', '#ff8a3a'][Math.floor(d * 1000) % 5];
          c.fillStyle = col; c.fillRect(px - 2, py, 2, 2); c.fillRect(px + 2, py, 2, 2); c.fillRect(px, py - 2, 2, 2); c.fillRect(px, py + 2, 2, 2);
          c.fillStyle = '#ffd23a'; c.fillRect(px, py, 2, 2);
        } else if (d < 0.5) { c.fillStyle = '#5aa04a'; c.fillRect(px, py, 2, 6); }
        break;
      case 'desert':
        if (d < 0.1) { c.fillStyle = '#b89a5a'; c.fillRect(px, py, 6, 4); }
        else if (d < 0.13) { c.fillStyle = '#f0e8d8'; c.fillRect(px, py, 8, 6); c.fillStyle = '#3a2a1a'; c.fillRect(px + 1, py + 2, 2, 2); c.fillRect(px + 5, py + 2, 2, 2); }
        else if (d < 0.3) { c.fillStyle = 'rgba(160,120,60,0.35)'; c.fillRect(px, py, 12, 2); }
        break;
      case 'embers':
        if (d < 0.14) { c.fillStyle = '#ff8a2a'; c.fillRect(px, py, 3, 3); c.fillStyle = 'rgba(255,138,42,0.3)'; c.fillRect(px - 2, py - 2, 7, 7); }
        else if (d < 0.3) { c.fillStyle = '#1e1414'; c.fillRect(px, py, 10, 2); c.fillRect(px + 8, py, 2, 6); }
        break;
      case 'gems':
        if (d < 0.14) { c.fillStyle = ['#5be3ff', '#c77dff', '#ff6fb5'][Math.floor(d * 1000) % 3]; c.beginPath(); c.moveTo(px, py - 4); c.lineTo(px + 3, py); c.lineTo(px, py + 4); c.lineTo(px - 3, py); c.fill(); }
        break;
      case 'glitch':
        if (d < 0.16) { c.fillStyle = 'rgba(255,62,165,0.6)'; c.fillRect(px, py, 6, 2); c.fillStyle = 'rgba(63,240,255,0.6)'; c.fillRect(px + 2, py + 2, 6, 2); }
        else if (d < 0.26) { c.fillStyle = '#3ff0a0'; c.fillRect(px, py, 3, 3); }
        break;
      case 'sprinkles':
        if (d < 0.4) { for (let k = 0; k < 3; k++) { c.fillStyle = RAINBOW[(Math.floor(d * 100) + k) % 7]; c.fillRect(px + k * 5 - 5, py + (k % 2) * 6, 4, 2); } }
        break;
      case 'sky':
        if (d < 0.08) { c.fillStyle = '#ffe04a'; star(c, px, py, 3); c.fill(); }
        else if (d < 0.25) { c.fillStyle = 'rgba(255,255,255,0.8)'; c.beginPath(); c.arc(px, py, 5, 0, TAU); c.arc(px + 6, py, 4, 0, TAU); c.fill(); }
        break;
      case 'trash':
        if (d < 0.1) { c.fillStyle = '#c0392b'; c.fillRect(px, py, 4, 7); c.fillStyle = '#ddd'; c.fillRect(px, py, 4, 2); }
        else if (d < 0.18) { c.fillStyle = 'rgba(46,204,113,0.7)'; c.fillRect(px, py, 3, 8); }
        else if (d < 0.26) { c.fillStyle = 'rgba(120,255,80,0.25)'; c.beginPath(); c.arc(px, py, 6, 0, TAU); c.fill(); }
        break;
      case 'mirror':
        if (d < 0.1) { c.fillStyle = '#ffffff'; star(c, px, py, 3, 0, 4); c.fill(); }
        else if (d < 0.2) { c.fillStyle = 'rgba(255,255,255,0.5)'; c.fillRect(px, py, 10, 1); }
        break;
      case 'toys':
        if (d < 0.05) { c.fillStyle = ['#ff6a6a', '#6ac8ff', '#ffd25a'][Math.floor(d * 1000) % 3]; c.beginPath(); c.arc(px, py, 3, 0, TAU); c.fill(); }
        else if (d < 0.08) { c.fillStyle = '#ffffff'; c.fillRect(px, py, 4, 4); }
        break;
      case 'dust':
        if (d < 0.12) { c.fillStyle = 'rgba(200,200,220,0.25)'; c.beginPath(); c.arc(px, py, 4, 0, TAU); c.fill(); }
        break;
      case 'crumbs':
        if (d < 0.14) { c.fillStyle = '#c8a060'; c.fillRect(px, py, 2, 2); c.fillRect(px + 4, py + 2, 2, 2); }
        break;
      case 'pixelnight':
        if (d < 0.06) { c.fillStyle = 'rgba(63,240,160,0.5)'; c.fillRect(px, py, 3, 3); }
        else if (d < 0.09) { c.fillStyle = 'rgba(255,62,165,0.4)'; c.fillRect(px, py, 3, 3); }
        break;
      case 'drops':
        if (d < 0.12) { c.fillStyle = 'rgba(160,220,255,0.45)'; c.beginPath(); c.ellipse(px, py, 3, 2, 0, 0, TAU); c.fill(); }
        break;
      case 'leaves':
        if (d < 0.12) { c.fillStyle = ['#d88a3a', '#c8a03a', '#a05a2a'][Math.floor(d * 1000) % 3]; c.beginPath(); c.ellipse(px, py, 4, 2, d * 20, 0, TAU); c.fill(); }
        break;
      case 'neon':
        if ((tx + ty) % 4 === 0) { c.fillStyle = 'rgba(63,240,255,0.18)'; c.fillRect(ox, oy, T, 1); }
        if ((tx * 3 + ty) % 5 === 0) { c.fillStyle = 'rgba(255,62,165,0.18)'; c.fillRect(ox, oy, 1, T); }
        if (d < 0.05) { c.fillStyle = '#ffe04a'; star(c, px, py, 3); c.fill(); }
        break;
    }
  }
  // Кусок карты рисуется в три прохода. Заранее (до того как он попадёт на экран) его строим
  // понемногу – по несколько миллисекунд за кадр, поэтому при беге и в меню нет рывков.
  let chunkJob = null;
  const CH2 = CHUNK * CHUNK, CHB = (CHUNK + 2) * (CHUNK + 2);
  // ---- края карты: у каждой главы свои (лес, занавес, зеркала, обои, ели) ----
  const EDGE_BY_CH = { 1: 'forest', 2: 'curtain', 3: 'mirror', 4: 'nightwall', 5: 'daywall', 6: 'firs', 7: 'reef' };
  const EDGE_MINI = { forest: '#1d4a22', curtain: '#7a0a1e', mirror: '#b8c8e8', nightwall: '#262c52', daywall: '#e8d4ae', firs: '#2a5a48', reef: '#1a4a5a' };
  const edgeStyle = () => EDGE_BY_CH[CHN] || null;
  // клетка рамки: 0 – внутреннее кольцо (у самой карты), 1 – внешнее; сторона – куда смотрит рамка
  function edgeInfo(tx, ty) {
    if (tx < 0 || ty < 0 || tx >= MW || ty >= PLAY_H) return null;
    const dl = tx, dr = MW - 1 - tx, dt = ty, db = PLAY_H - 1 - ty, m = Math.min(dl, dr, dt, db);
    if (m > 1) return null;
    const side = dt === m ? 't' : db === m ? 'b' : dl === m ? 'l' : 'r';
    return { depth: 1 - m, side };
  }
  const FOREST_GREENS = ['#245c28', '#2b6a2e', '#1f5223', '#2f7432'];
  function drawEdge(c, st, tx, ty, ox, oy) {
    const e = edgeInfo(tx, ty); if (!e) return;
    const d = e.depth, horiz = e.side === 't' || e.side === 'b';
    // внутренняя граница (сторона клетки, что смотрит в карту)
    const inner = d === 0;
    const h = k => hash2(tx * 13 + k * 7, ty * 29 + k * 11);
    if (st === 'forest') { // густой лес: кроны внахлёст, к краю темнее
      c.fillStyle = d ? '#10291a' : '#163a1e'; c.fillRect(ox, oy, T, T);
      for (let k = 0; k < 3; k++) {
        const cx = ox + 20 + (h(k) - 0.5) * 26, cy = oy + 20 + (h(k + 5) - 0.5) * 26, r = 15 + h(k + 9) * 10;
        const col = FOREST_GREENS[Math.floor(h(k + 13) * 4)], dk = -0.28 * d;
        c.fillStyle = 'rgba(0,0,0,0.3)'; c.beginPath(); c.arc(cx + 3, cy + 5, r, 0, TAU); c.fill();
        c.fillStyle = shade(col, dk); c.beginPath(); c.arc(cx, cy, r, 0, TAU); c.fill();
        c.fillStyle = shade('#3f8f3e', dk); c.beginPath(); c.arc(cx - r * 0.3, cy - r * 0.32, r * 0.55, 0, TAU); c.fill();
        c.fillStyle = shade('#5bb055', dk * 1.5); c.beginPath(); c.arc(cx - r * 0.42, cy - r * 0.45, r * 0.2, 0, TAU); c.fill();
      }
      return;
    }
    if (st === 'firs') { // заснеженные ели, у карты – сугроб
      c.fillStyle = d ? '#c8dcec' : '#e2eef8'; c.fillRect(ox, oy, T, T);
      for (let k = 0; k < 2; k++) {
        const cx = ox + 10 + k * 20 + (h(k) - 0.5) * 10, by = oy + 34 + (h(k + 3) - 0.5) * 10, w = 13 + h(k + 6) * 6, dk = -0.3 * d;
        c.fillStyle = 'rgba(40,70,110,0.25)'; c.beginPath(); c.ellipse(cx + 4, by + 2, w * 0.9, 5, 0, 0, TAU); c.fill();
        for (let tier = 0; tier < 3; tier++) {
          const ty0 = by - tier * 11, ww = w * (1 - tier * 0.25);
          c.fillStyle = shade('#1e4a3a', dk + tier * 0.05); c.beginPath(); c.moveTo(cx - ww, ty0); c.lineTo(cx + ww, ty0); c.lineTo(cx, ty0 - 17); c.closePath(); c.fill();
          c.fillStyle = '#f4faff'; c.beginPath(); c.moveTo(cx - ww * 0.55, ty0 - 7); c.lineTo(cx + ww * 0.4, ty0 - 8); c.lineTo(cx, ty0 - 17); c.closePath(); c.fill();
        }
      }
      if (inner) { // сугроб вдоль края карты
        c.fillStyle = '#f6fbff';
        for (let k = 0; k < 3; k++) {
          const along = 6 + k * 14 + h(k + 20) * 6, r = 8 + h(k + 23) * 5;
          const [px, py] = e.side === 't' ? [ox + along, oy + T] : e.side === 'b' ? [ox + along, oy] : e.side === 'l' ? [ox + T, oy + along] : [ox, oy + along];
          c.beginPath(); c.arc(px, py, r, 0, TAU); c.fill();
        }
      }
      return;
    }
    if (st === 'reef') { // подводная скала: кораллы, водоросли, пузыри
      c.fillStyle = d ? '#0e2a38' : '#16384a'; c.fillRect(ox, oy, T, T);
      for (let k = 0; k < 3; k++) { const cx = ox + 20 + (h(k) - 0.5) * 26, cy = oy + 20 + (h(k + 4) - 0.5) * 26, r = 9 + h(k + 8) * 8;
        c.fillStyle = shade(['#1e4a5a', '#24566a', '#1a4050'][k], -0.25 * d); c.beginPath(); c.arc(cx, cy, r, 0, TAU); c.fill(); }
      if (h(20) < 0.45) { const x = ox + 8 + h(21) * 24, y = oy + 34; const col = ['#ff7a96', '#ffb04a', '#c8a0ff'][Math.floor(h(22) * 3)];
        c.strokeStyle = shade(col, -0.2 * d); c.lineWidth = 2.5; c.lineCap = 'round';
        c.beginPath(); c.moveTo(x, y); c.lineTo(x - 4, y - 10); c.lineTo(x - 7, y - 16); c.moveTo(x - 4, y - 10); c.lineTo(x + 2, y - 17); c.moveTo(x, y); c.lineTo(x + 5, y - 9); c.stroke(); c.lineCap = 'butt'; }
      else if (h(23) < 0.5) { const x = ox + 10 + h(24) * 20; c.strokeStyle = shade('#3a8a3a', -0.3 * d); c.lineWidth = 3; c.beginPath(); c.moveTo(x, oy + 38); c.bezierCurveTo(x - 6, oy + 26, x + 6, oy + 14, x, oy + 2); c.stroke(); }
      if (inner && h(30) < 0.3) { c.fillStyle = 'rgba(220,250,255,0.55)'; for (let k = 0; k < 3; k++) { c.beginPath(); c.arc(ox + 12 + h(31 + k) * 16, oy + 8 + k * 10, 1.5 + k * 0.7, 0, TAU); c.fill(); } }
      return;
    }
    if (st === 'curtain') { // бархатный занавес с золотой бахромой – Кринж-Цитадель как сцена
      const along0 = horiz ? tx * T : ty * T;
      for (let i = 0; i < T; i += 4) {
        const v = (Math.sin((along0 + i) * TAU / 22) + 1) / 2, dk = -0.25 * d;
        c.fillStyle = shade(v > 0.66 ? '#c8203c' : v > 0.33 ? '#9a1430' : '#6a0a1e', dk);
        if (horiz) c.fillRect(ox + i, oy, 4, T); else c.fillRect(ox, oy + i, T, 4);
      }
      if (inner) {
        c.fillStyle = '#ffcf4a';
        const [rx, ry, rw, rh] = e.side === 't' ? [ox, oy + T - 6, T, 4] : e.side === 'b' ? [ox, oy + 2, T, 4] : e.side === 'l' ? [ox + T - 6, oy, 4, T] : [ox + 2, oy, 4, T];
        c.fillRect(rx, ry, rw, rh);
        c.fillStyle = '#e8a82a';
        for (let i = 4; i < T; i += 8) { // кисточки
          if (e.side === 't') c.fillRect(ox + i, oy + T - 3, 3, 6); else if (e.side === 'b') c.fillRect(ox + i, oy - 2, 3, 5);
          else if (e.side === 'l') c.fillRect(ox + T - 3, oy + i, 6, 3); else c.fillRect(ox - 2, oy + i, 5, 3);
        }
      }
      if (h(31) < 0.18) { c.fillStyle = 'rgba(255,240,180,0.9)'; star(c, ox + 8 + h(32) * 24, oy + 8 + h(33) * 24, 3, 0, 4); c.fill(); }
      return;
    }
    if (st === 'mirror') { // стена зеркал в золотых рамах
      const g = c.createLinearGradient(ox, oy, ox + T, oy + T);
      g.addColorStop(0, d ? '#8a9cc4' : '#c8d8f4'); g.addColorStop(0.5, d ? '#a8b8dc' : '#eef4ff'); g.addColorStop(1, d ? '#7a8cb8' : '#b8c8ea');
      c.fillStyle = g; c.fillRect(ox, oy, T, T);
      c.fillStyle = 'rgba(255,170,210,0.18)'; c.fillRect(ox + 4, oy + 22, T - 8, 12);
      c.fillStyle = 'rgba(255,255,255,0.7)'; c.beginPath(); c.moveTo(ox + 6, oy + 30); c.lineTo(ox + 11, oy + 30); c.lineTo(ox + 30, oy + 9); c.lineTo(ox + 25, oy + 9); c.fill();
      c.fillStyle = 'rgba(255,255,255,0.45)'; c.fillRect(ox + 26 + h(1) * 6, oy + 14, 2, 14);
      c.strokeStyle = d ? '#b8902a' : '#e8c050'; c.lineWidth = 3; c.strokeRect(ox + 1.5, oy + 1.5, T - 3, T - 3);
      if (inner) {
        c.fillStyle = '#ffd25a';
        if (e.side === 't') c.fillRect(ox, oy + T - 5, T, 5); else if (e.side === 'b') c.fillRect(ox, oy, T, 5);
        else if (e.side === 'l') c.fillRect(ox + T - 5, oy, 5, T); else c.fillRect(ox, oy, 5, T);
      }
      return;
    }
    if (st === 'nightwall' || st === 'daywall') { // стены дома: обои и плинтус
      const night = st === 'nightwall';
      c.fillStyle = night ? (d ? '#161a34' : '#1e2446') : (d ? '#e2cfa6' : '#f2e2c0'); c.fillRect(ox, oy, T, T);
      c.fillStyle = night ? 'rgba(120,140,220,0.18)' : 'rgba(210,120,120,0.22)';
      for (let i = 4; i < T; i += 13) { if (horiz) c.fillRect(ox + i, oy, 5, T); else c.fillRect(ox, oy + i, T, 5); }
      c.fillStyle = night ? 'rgba(200,210,255,0.35)' : 'rgba(120,170,110,0.5)';
      for (let k = 0; k < 2; k++) { c.beginPath(); c.arc(ox + 10 + k * 20, oy + 10 + h(k) * 20, night ? 1.5 : 2.4, 0, TAU); c.fill(); }
      if (night && h(40) < 0.12) { // глитч в обоях
        c.fillStyle = '#ff3ea5'; c.fillRect(ox + h(41) * 26, oy + h(42) * 26, 10, 4);
        c.fillStyle = '#3ff0ff'; c.fillRect(ox + h(43) * 26, oy + h(44) * 26, 7, 3);
      }
      if (inner) { // плинтус
        const bc = night ? '#3a4070' : '#8a5a32', hl = night ? '#5a62a0' : '#b07a48';
        const [rx, ry, rw, rh, hx, hy, hw, hh] = e.side === 't' ? [ox, oy + T - 8, T, 8, ox, oy + T - 8, T, 2] : e.side === 'b' ? [ox, oy, T, 8, ox, oy + 6, T, 2]
          : e.side === 'l' ? [ox + T - 8, oy, 8, T, ox + T - 8, oy, 2, T] : [ox, oy, 8, T, ox + 6, oy, 2, T];
        c.fillStyle = bc; c.fillRect(rx, ry, rw, rh); c.fillStyle = hl; c.fillRect(hx, hy, hw, hh);
        if (!night && e.side === 't' && h(50) < 0.08) { // розетка
          c.fillStyle = '#fafafa'; c.fillRect(ox + 14, oy + 12, 12, 14); c.fillStyle = '#555'; c.fillRect(ox + 17, oy + 17, 2, 4); c.fillRect(ox + 21, oy + 17, 2, 4);
        }
      }
    }
  }
  function newChunkJob(cx, cy) {
    const cv = makeCanvas(CHPX, CHPX);
    return { key: cx + ',' + cy, cx, cy, cv, c: cv.getContext('2d'), pass: 0, i: 0 };
  }
  function runChunkJob(j, budgetMs) {
    const t0 = budgetMs === Infinity ? 0 : performance.now(), c = j.c, bx = j.cx * CHUNK, by = j.cy * CHUNK;
    const est = edgeStyle();
    while (j.pass < 4) {
      if (j.pass === 0) {
        const tx = j.i % CHUNK, ty = (j.i / CHUNK) | 0;
        if (inMap(bx + tx, by + ty)) drawGroundBase(c, bx + tx, by + ty, tx * T, ty * T);
        if (++j.i >= CH2) { j.pass = 1; j.i = 0; }
      } else if (j.pass === 1) {
        // мягкие пятна заходят на соседние клетки, поэтому рисуем и рамку вокруг куска – без швов
        const tx = (j.i % (CHUNK + 2)) - 1, ty = ((j.i / (CHUNK + 2)) | 0) - 1;
        drawGroundDetail(c, bx + tx, by + ty, tx * T, ty * T);
        if (++j.i >= CHB) { j.pass = 2; j.i = 0; }
      } else if (j.pass === 2) {
        const tx = j.i % CHUNK, ty = (j.i / CHUNK) | 0;
        if (inMap(bx + tx, by + ty)) drawTile(c, bx + tx, by + ty, tx * T, ty * T);
        if (++j.i >= CH2) { j.pass = 3; j.i = 0; }
      } else {
        // края карты: кроны и сугробы заходят на соседние клетки – рисуем и рамку вокруг куска
        if (!est || (bx > 2 && by > 2 && bx + CHUNK < MW - 3 && by + CHUNK < PLAY_H - 3)) { j.pass = 4; break; }
        const tx = (j.i % (CHUNK + 2)) - 1, ty = ((j.i / (CHUNK + 2)) | 0) - 1;
        drawEdge(c, est, bx + tx, by + ty, tx * T, ty * T);
        if (++j.i >= CHB) j.pass = 4;
      }
      if (budgetMs !== Infinity && (j.i & 7) === 0 && performance.now() - t0 > budgetMs) return false;
    }
    paperWash(j.cv);
    chunkCache.set(j.key, j.cv);
    if (chunkCache.size > 42) chunkCache.delete(chunkCache.keys().next().value);
    return true;
  }
  // 1.0: земля и деревья – светлая акварель на бумаге (смешиваем с цветом бумаги один раз при запекании)
  let paperOn = false; const PAPER_COL = '#f3e4c4';
  function paperWash(cv, a) {
    if (!paperOn) return; const c = cv.getContext('2d');
    c.save(); c.setTransform(1, 0, 0, 1, 0, 0); c.globalCompositeOperation = 'source-atop'; c.globalAlpha = a || G.paperMix || 0.22; c.fillStyle = PAPER_COL; c.fillRect(0, 0, cv.width, cv.height); c.restore();
  }
  // палитры биомов светлеют до «акварели»: оттенок тот же, светлее и мягче
  function paperCol(hex, kind) {
    const m = /^#([0-9a-f]{6})$/i.exec(hex); if (!m) return hex;
    const n = parseInt(m[1], 16); let r = (n >> 16) / 255, g = ((n >> 8) & 255) / 255, b = (n & 255) / 255;
    const mx = Math.max(r, g, b), mn = Math.min(r, g, b); let h = 0, sat = 0; const l = (mx + mn) / 2, d = mx - mn;
    if (d) { sat = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn); h = mx === r ? (g - b) / d + (g < b ? 6 : 0) : mx === g ? (b - r) / d + 2 : (r - g) / d + 4; h /= 6; }
    const L2 = Math.max(l, (kind === 'water' ? 0.56 : 0.6) + l * 0.3), S2 = Math.min(0.62, sat * 0.85 + 0.1);
    if (kind !== 'water' && h > 0.22 && h < 0.45) h = h - (h - 0.22) * 0.35; // зелень чуть теплее, как в пробнике
    const q = L2 < 0.5 ? L2 * (1 + S2) : L2 + S2 - L2 * S2, p = 2 * L2 - q;
    const f = t => { t = (t + 1) % 1; return t < 1 / 6 ? p + (q - p) * 6 * t : t < 0.5 ? q : t < 2 / 3 ? p + (q - p) * (2 / 3 - t) * 6 : p; };
    return '#' + [f(h + 1 / 3), f(h), f(h - 1 / 3)].map(v => Math.round(v * 255).toString(16).padStart(2, '0')).join('');
  }
  let biomesPapered = false;
  function paperBiomes() {
    if (biomesPapered || !paperOn) return; biomesPapered = true;
    for (const bi of BIOMES) for (const k of ['ground', 'path', 'water', 'rock']) if (Array.isArray(bi[k])) bi[k] = bi[k].map(c => paperCol(c, k));
    for (const k in PATH_BY_BIOME) PATH_BY_BIOME[k] = PATH_BY_BIOME[k].map(c => paperCol(c, 'path'));
    for (const t of [PATH, WATER, ROCK, STONE]) if (Array.isArray(PAL[t])) PAL[t] = PAL[t].map(c => paperCol(c, t === WATER ? 'water' : 'path'));
  }
  // чернильный контур вокруг готового спрайта: силуэт чернилами со сдвигом во все стороны, сверху – сам спрайт
  function inkOutline(cv, w) {
    const W2 = cv.width, H2 = cv.height, o = document.createElement('canvas'); o.width = W2; o.height = H2; const oc = o.getContext('2d');
    for (let k = 0; k < 8; k++) { const a = k * Math.PI / 4; oc.drawImage(cv, Math.round(Math.cos(a) * w), Math.round(Math.sin(a) * w)); }
    oc.globalCompositeOperation = 'source-in'; oc.fillStyle = 'rgba(75,46,30,.92)'; oc.fillRect(0, 0, W2, H2);
    oc.globalCompositeOperation = 'source-over'; oc.drawImage(cv, 0, 0);
    const c = cv.getContext('2d'); c.save(); c.setTransform(1, 0, 0, 1, 0, 0); c.clearRect(0, 0, W2, H2); c.drawImage(o, 0, 0); c.restore();
  }
  let treesWashed = false;
  function getChunk(cx, cy) {
    if (!treesWashed && paperOn) { treesWashed = true; for (const k in TREE_SPR) if (TREE_SPR[k] && TREE_SPR[k].getContext) { inkOutline(TREE_SPR[k], 2.2); paperWash(TREE_SPR[k], 0.26); } }
    const key = cx + ',' + cy;
    let ch = chunkCache.get(key);
    if (ch) { chunkCache.delete(key); chunkCache.set(key, ch); return ch; }
    // нужен прямо сейчас: достраиваем начатый или строим целиком
    const j = chunkJob && chunkJob.key === key ? chunkJob : newChunkJob(cx, cy);
    if (j === chunkJob) chunkJob = null;
    runChunkJob(j, Infinity);
    return j.cv;
  }

  // мини-карта и туман
  let miniBase = makeCanvas(1, 1), fog = makeCanvas(1, 1);
  function buildMinimap() {
    miniBase = makeCanvas(MW, PLAY_H); fog = makeCanvas(MW, PLAY_H);
    const c = miniBase.getContext('2d');
    const MINI = { [PATH]: '#9a6b45', [STONE]: '#a0a0a4', [WALL]: '#6a5a86', [GATE]: '#ffcf4a', [LAVA]: '#ff6a22', [FLOOR]: '#5a5268', [ICE]: '#c8eefb' };
    for (let ty = 0; ty < PLAY_H; ty++) for (let tx = 0; tx < MW; tx++) {
      const t = tiles[ty * MW + tx], b = biomeMap[ty * MW + tx];
      let col;
      if (isGround(t)) col = BIOMES[t].mini;
      else if (t === WATER) col = (BIOMES[b].water || ['#8fcbe8'])[0];
      else if (t === ROCK) col = shade((BIOMES[b].rock || ['#a4a4a8'])[0], 0.2);
      else col = MINI[t];
      if (EDGE_MINI[edgeStyle()] && edgeInfo(tx, ty)) col = EDGE_MINI[edgeStyle()];
      if (paperOn) { let pc = MINI_PAPER.get(col); if (!pc) { pc = paperCol(col, t === WATER ? 'water' : 'ground'); MINI_PAPER.set(col, pc); } col = pc; }
      c.fillStyle = col; c.fillRect(tx, ty, 1, 1);
    }
    trees.forEach((tr, k) => { const tx = Math.floor(tr.x / T), ty = Math.floor(tr.y / T); if (treeGrid[ty * MW + tx] === k + 1) { c.fillStyle = 'rgba(0,0,0,0.25)'; c.fillRect(tx, ty, 1, 1); } });
    for (const sc of secrets) if (!sc.open) { c.fillStyle = shade((BIOMES[biomeMap[sc.i]].rock || ['#a4a4a8'])[0], 0.2); c.fillRect(sc.cx - 1, sc.cy - 1, 3, 3); }
    resetFog();
    MM2.neon = null; MM2.sign = null; // мини-карта 2.0 перерисует основу под новую главу
  }
  const MINI_PAPER = new Map();
  function resetFog() { const c = fog.getContext('2d'); c.globalCompositeOperation = 'source-over'; c.fillStyle = paperOn ? '#efe0bf' : '#0d0a16'; c.fillRect(0, 0, MW, MH); }
  function revealFog(x, y, r) {
    const c = fog.getContext('2d');
    c.globalCompositeOperation = 'destination-out';
    const g = c.createRadialGradient(x / T, y / T, r * 0.6, x / T, y / T, r);
    g.addColorStop(0, 'rgba(0,0,0,1)'); g.addColorStop(1, 'rgba(0,0,0,0)');
    c.fillStyle = g; c.beginPath(); c.arc(x / T, y / T, r, 0, TAU); c.fill();
    c.globalCompositeOperation = 'source-over';
  }

  // ------------------------------------------------------------------
  //  Состояние
  // ------------------------------------------------------------------
  let state = 'boot'; // пока готовятся картинки – экран загрузки
  const IMG = { ryzhova: null, zyama: null };
  const AVATAR = {};
  const P = {
    x: 0, y: 0, r: 13, hp: 100, maxHp: 100, face: 1, t: 0, inv: 0, dashT: 0, dashCd: 0, dashX: 0, dashY: 0,
    fireT: 0, boltT: 0, orbA: 0, moving: false, level: 1, xp: 0, xpNext: 10, up: {}, bonus: {},
    vx: 0, vy: 0, slowT: 0, shieldT: 0, shards: 0, hero: 'krilessa', sp: 0, stormT: 0, stormE: 0,
  };
  const G = {
    time: 0, kills: 0, defeated: [], cp: { x: 0, y: 0 },
    enemies: [], feathers: [], ebullets: [], hazards: [], pickups: [], parts: [], texts: [], bolts: [], rings: [], beams: [],
    shake: 0, hurtFlash: 0, activeBoss: null, pendingLv: 0, spawnT: 0, fogT: 0, gateMsgT: 0, lowHpT: 0,
    hintT: 0, cutscene: null, cam: { x: 0, y: 0 }, menuT: 0, victoryShown: false, cageOpen: 0,
    combo: 0, comboT: 0, bestCombo: 0, activeShrine: null, pzones: [], novas: [], scaleCache: {}, shooters: 0,
    diff: DIFFS.normal, diffId: 'normal', ev: null, evT: EVENT_EVERY, lastEv: null, st: null, lowHpSaid: false,
    finalFinal: null, rush: null, trueWin: false, musWant: null, musHold: 0, musT: 0,
  };
  let bosses = [];

  // ------------------------------------------------------------------
  //  Улучшения и характеристики
  // ------------------------------------------------------------------
  const lv = id => P.up[id] || 0;
  const bon = id => P.bonus[id] || 0;
  const talent = id => (G.tal && G.tal[id]) || 0;
  const relicMax = () => 3 + talent('relic');
  function computeStats() {
    const oldMax = P.maxHp;
    Object.assign(P, statsFor(P.up, P.bonus, P.hero));
    if (hasRelic('boots')) { P.speed *= 1.1 + 0.05 * relicLv('boots'); P.dashCdMax *= 0.8 - 0.05 * relicLv('boots'); }
    if (hasRelic('horseshoe')) P.magnet *= 2 + relicLv('horseshoe');
    if (hasRelic('hourglass')) P.superGain *= 1.2 + 0.2 * relicLv('hourglass');
    if (hasRelic('clover')) P.crit = Math.min(0.85, P.crit + 0.06 + 0.04 * relicLv('clover'));
    if (hasRelic('heartstone')) P.maxHp = Math.round(P.maxHp * (1.15 + 0.1 * relicLv('heartstone')));
    if (hasRelic('crown')) P.dmg *= 1.15 + 0.1 * relicLv('crown');
    // эволюции
    if (lv('evBlood')) P.critMul += 0.5;
    if (lv('evAegis') && P.shieldLv) P.shieldCd *= 0.5;
    if (lv('evComet')) P.dashCdMax *= 0.5;
    if (lv('evNova')) P.superGain *= 1.5;
    // таланты (звёзды)
    if (talent('dmg')) P.dmg *= 1 + 0.04 * talent('dmg');
    if (talent('hp')) P.maxHp = Math.round(P.maxHp * (1 + 0.06 * talent('hp')));
    if (talent('crit')) P.crit = Math.min(0.85, P.crit + 0.03 * talent('crit'));
    if (talent('speed')) P.speed *= 1 + 0.04 * talent('speed');
    if (talent('magnet')) P.magnet *= 1 + 0.25 * talent('magnet');
    if (talent('critdmg')) P.critMul += 0.12 * talent('critdmg');
    if (talent('rate')) P.fireInt /= 1 + 0.04 * talent('rate');
    if (talent('armor')) P.armor = Math.min(0.7, P.armor + 0.03 * talent('armor'));
    if (talent('dashcd')) P.dashCdMax *= 1 - 0.12 * talent('dashcd');
    if (mutOn('glass')) { P.dmg *= 1.5; P.maxHp = Math.round(P.maxHp * 0.5); }
    if (talent('regen')) P.regen += P.maxHp * 0.004 * talent('regen');
    if (P.maxHp > oldMax) P.hp += P.maxHp - oldMax;
    P.hp = Math.min(P.hp, P.maxHp);
  }
  const xpFor = l => 5 + l * 4 + Math.floor(l * l * 0.35);
  // ---------- Баланс: всё подстраивается под силу героя ----------
  function nextBossIdx() { for (let i = 0; i < bosses.length; i++) if (!G.defeated[i]) return i; return bosses.length - 1; }
  function zoneE(biome) {
    const keys = Object.keys(CFG.zoneLevel);
    const zl = CFG.zoneLevel[biome] !== undefined ? CFG.zoneLevel[biome] : CFG.zoneLevel[keys[0]];
    const prog = bosses.length ? CFG.bossLevels[nextBossIdx()] - 3 : zl;
    return Math.max(zl, prog);
  }
  // Сложность главы набирает силу постепенно: на старте (ур. 4) мобы как в главе 1,
  // к локациям 16-го уровня – полный множитель главы. Глава всегда начинается с 1 уровня.
  function chDiff(E) {
    const k = CFG.rush ? 1 : clamp((E - 4) / 12, 0, 1);
    return { hp: 1 + (CFG.diff.hp - 1) * k, dmg: 1 + (CFG.diff.dmg - 1) * k, k };
  }
  function mobScale(E) {
    const key = Math.round(E);
    const cached = G.scaleCache[key];
    if (cached) return cached;
    const Rm = estMobDPS(P) / refMobDPS(E), Q = estEHP(P) / refEHP(E), cd = chDiff(E);
    const sc = {
      hp: BAL.mobHpK * BAL.metaK * refMobDPS(E) / refMobDPS(4) * cd.hp * G.diff.hp * scaleUp(Rm, BAL.mobHpExp, 0.6),
      dmg: BAL.mobDmgK * BAL.metaK * refEHP(E) / refEHP(4) * cd.dmg * G.diff.dmg * scaleUp(Q, BAL.mobDmgExp, 0.7),
      xp: xpFor(E) / BAL.xpDiv * xpGap(P.level, E),
    };
    G.scaleCache[key] = sc;
    return sc;
  }
  function bossStats(b) {
    const E = CFG.bossLevels[b.id] !== undefined ? CFG.bossLevels[b.id] : CFG.bossLevels[CFG.bossLevels.length - 1] + 2;
    const Rb = estDPS(P) / refDPS(E), Q = estEHP(P) / refEHP(E);
    b.E = E;
    const cd = chDiff(E);
    b.maxHp = b.hp = b.def.ttk * refDPS(E) * BAL.eff * BAL.metaK * cd.hp * G.diff.hp * scaleUp(Rb, BAL.bossHpExp, 0.6);
    const dm = refEHP(E) * BAL.bossDmgK * BAL.metaK * cd.dmg * G.diff.dmg * scaleUp(Q, BAL.bossDmgExp, 0.7);
    b.dmg = b.def.hit * dm; b.cdmg = b.def.touch * dm;
    b.level = E + Math.max(0, Math.round((P.level - E) * 0.7));
    b.aggro = 1 + clamp((P.level - E) * 0.02, 0, 0.3);
    if (G.mut && G.mut.ng) { b.maxHp *= 1.6; b.hp = b.maxHp; b.dmg *= 1.6; b.cdmg *= 1.6; }
  }
  function rollHit(base) {
    const crit = Math.random() < P.crit;
    if (crit && lv('evBlood') && (G.bloodT || 0) <= 0 && P.hp < P.maxHp && !P.down) { G.bloodT = 0.3; P.hp = Math.min(P.maxHp, P.hp + P.maxHp * 0.01); } // кровавая луна
    const combo = P.up.c2combo ? 1 + 0.01 * P.up.c2combo * Math.min(G.combo, 100) / 10 : 1;
    const rage = talent('berserk') && P.hp < P.maxHp * 0.35 ? 1 + 0.15 * talent('berserk') : 1;
    return { v: base * (crit ? P.critMul : 1) * rnd(0.9, 1.1) * (P.napT > 0 ? 1.2 : 1) * combo * (G.cookieT > 0 ? 1.25 : 1) * rage, crit };
  }

  // ------------------------------------------------------------------
  //  Физика
  // ------------------------------------------------------------------
  function collide(e) {
    const r = e.r;
    const tx0 = Math.floor((e.x - r) / T), tx1 = Math.floor((e.x + r) / T);
    const ty0 = Math.floor((e.y - r) / T), ty1 = Math.floor((e.y + r) / T);
    for (let ty = ty0; ty <= ty1; ty++) for (let tx = tx0; tx <= tx1; tx++) {
      if (!isSolidTile(tx, ty, e.fly)) continue;
      const rx = tx * T, ry = ty * T;
      const nx = clamp(e.x, rx, rx + T), ny = clamp(e.y, ry, ry + T);
      const dx = e.x - nx, dy = e.y - ny, d2 = dx * dx + dy * dy;
      if (d2 >= r * r) continue;
      if (d2 > 1e-6) { const d = Math.sqrt(d2), push = r - d; e.x += (dx / d) * push; e.y += (dy / d) * push; }
      else {
        const l = e.x - rx, rr = rx + T - e.x, u = e.y - ry, dd = ry + T - e.y, m = Math.min(l, rr, u, dd);
        if (m === l) e.x = rx - r; else if (m === rr) e.x = rx + T + r; else if (m === u) e.y = ry - r; else e.y = ry + T + r;
      }
    }
    // деревья больше не преграда: сквозь них проходят и героиня, и враги – никаких тупиков
    // (крона просвечивает, когда кто-то под ней)
  }
  function moveEntity(e, dx, dy) {
    const steps = Math.max(1, Math.ceil(Math.max(Math.abs(dx), Math.abs(dy)) / (e.r * 0.7)));
    for (let s = 0; s < steps; s++) { e.x += dx / steps; e.y += dy / steps; collide(e); }
  }
  function playerInCastle() {
    const tx = Math.floor(P.x / T), ty = Math.floor(P.y / T);
    return Math.abs(tx - CASTLE.x) < CASTLE.half && Math.abs(ty - CASTLE.y) < CASTLE.half;
  }
  function walkable(x, y, fly) {
    const tx = Math.floor(x / T), ty = Math.floor(y / T);
    if (isSolidTile(tx, ty, fly)) return false;
    if (!gateOpen && tileAt(tx, ty) === FLOOR && biomeMap[ty * MW + tx] !== ARENA_BIOME && !playerInCastle()) return false;
    return true;
  }
  function leadAngle(x, y, spd, k = 0.85) {
    const Q = AIM || P, d = Math.hypot(Q.x - x, Q.y - y);
    const tt = (d / spd) * k;
    return Math.atan2(Q.y + (Q.vy || 0) * tt - y, Q.x + (Q.vx || 0) * tt - x);
  }

  // ------------------------------------------------------------------
  //  Эффекты
  // ------------------------------------------------------------------
  // на поздних волнах обороны, когда врагов толпа, частиц меньше – телефону легче
  const partMax = () => G.td && G.enemies.length > 90 ? 240 : 500;
  function part(x, y, vx, vy, life, size, col, grav = 0) {
    if (G.parts.length > partMax()) return;
    G.parts.push({ x, y, vx, vy, life, max: life, size, col, grav });
  }
  function burst(x, y, n, col, spd) {
    for (let i = 0; i < n; i++) { const a = rnd(0, TAU), s = rnd(0.2, 1) * spd; part(x, y, Math.cos(a) * s, Math.sin(a) * s, rnd(0.3, 0.8), rnd(2, 5), col); }
  }
  function floatText(x, y, txt, col = '#fff', big = false) {
    if (G.texts.length > 45) G.texts.shift();
    G.texts.push({ x, y, txt, t: 0, col, big });
  }
  function dmgText(x, y, v, col = '#fff', crit = false) {
    floatText(x, y, String(Math.max(1, Math.round(v))) + (crit ? '!' : ''), crit ? '#ffe04a' : col, crit);
  }
  function shockRing(x, y, col, max = 220) { G.rings.push({ x, y, r: 10, max, col, t: 0 }); }
  // талант «Звездопад»: звезда падает на цель и бьёт всех вокруг
  function starfall(x, y, k = 3, col = '#ffe08a', ic = '🌠') {
    const R = 80, base = P.dmg * k;
    for (const e of G.enemies) if (!e.dead && !(e.spawnT > 0) && (e.x - x) ** 2 + (e.y - y) ** 2 < (R + e.r) ** 2) damageEnemy(e, rollHit(base), 0, 0, false);
    const b = G.activeBoss; if (b && (b.x - x) ** 2 + (b.y - y) ** 2 < (R + b.r) ** 2) damageBoss(b, rollHit(base));
    shockRing(x, y, col, R); burst(x, y, 22, col, 220);
    for (let j = 0; j < 8; j++) part(x + rnd(-10, 10), y - 120 + j * 15, 0, 300, 0.25, 5, col);
    floatText(x, y - 30, ic, col);
  }
  function dropGem(x, y, v) {
    if (G.pickups.length > 280) { const g = G.pickups.find(p => p.kind === 'xp'); if (g) { g.v += v; return; } }
    G.pickups.push({ kind: 'xp', x, y, v, t: 0, pull: false });
  }
  function dropPickup(x, y, kind, extra) { if (kind === 'heart' && G.mut && G.mut.noheart) return; if (kind === 'key' && G.td) return; /* в обороне ключи не нужны */ G.pickups.push(Object.assign({ kind, x, y, v: 0, t: 0, pull: false }, extra || {})); }
  const SHARD_W = SHARDS.map((s, i) => [i, s.w]);
  function dropShard(x, y) { dropPickup(x + rnd(-12, 12), y + rnd(-12, 12), 'shard', { sid: weighted(SHARD_W) }); }

  // ------------------------------------------------------------------
  //  Враги
  // ------------------------------------------------------------------
  const SLIME_COL = { 0: '#63d65a', 1: '#8fae3a', 2: '#8fd8ff', 3: '#b05bd6', 4: '#7dff9a', 7: '#a98bff' };
  const BAT_COL = { 0: '#6b4a8f', 1: '#4a6b3a', 2: '#5a7fa8', 3: '#3a2050', 4: '#8a5aa8', 7: '#4a3a8f' };
  function spawnEnemy(type, x, y, biome, opts = {}) {
    const d = ENEMIES[type];
    const E = opts.E || zoneE(biome);
    const sc = opts.sc || (G.td ? tdScale(E) : mobScale(E)); // в обороне и свита стражей живёт по правилам обороны
    const elite = !!opts.elite;
    const affix = elite ? pick(AFFIXES).id : null;
    let col = d.col;
    if (type === 'slime' && SLIME_COL[biome]) col = SLIME_COL[biome];
    if (type === 'bat' && BAT_COL[biome]) col = BAT_COL[biome];
    const calm = opts.minion ? 0 : calmOf(biome);
    const hp = d.hp * sc.hp * (elite ? 3 : 1) * (1 - calm);
    const e = {
      type, def: d, sprite: d.sprite || type, x, y, r: d.r * (elite ? 1.35 : 1),
      hp, maxHp: hp, dmg: d.dmg * sc.dmg * (elite ? 1.4 : 1) * (affix === 'frenzied' ? 1.2 : 1) * (1 - calm),
      spd: d.spd * rnd(0.9, 1.1) * (elite ? 1.08 : 1) * (affix === 'fast' ? 1.45 : 1), xp: d.xp * sc.xp * (elite ? 5 : 1), fly: !!d.fly,
      t: 0, seed: Math.random() * 10, flash: 0, kx: 0, ky: 0, orbCd: 0, cd: rnd(0.8, 2.2), jt: rnd(0.3, 1.5), jd: 0, jx: 0, jy: 0,
      wind: 0, fuse: 0, charge: 0, burst: 0, burstT: 0, blink: 0, bx: 0, by: 0, healing: 0, healTargets: [],
      face: 1, look: 0, dead: false, flank: rnd(-1, 1) * (d.pack ? 1.3 : d.ai === 'swarm' ? 1.2 : 0.8),
      steerT: 0, steerDir: 1, stuckT: 0, dodgeCd: rnd(0, 1), slowT: 0, spawnT: opts.instant ? 0 : 0.45, elite,
      col, shieldAng: 0, biome, minion: !!opts.minion, small: type === 'mummini', vx: 0, vy: 0, dashAng: 0,
      shrine: opts.shrine || null, haz: null, exploded: false, E, affix, dr: affix === 'armored' ? 0.5 : 0,
      cdMul: affix === 'frenzied' ? 0.6 : 1, buffT: 0, burnT: 0, burnDps: 0, burnTick: 0, owner: opts.owner || null, sumT: rnd(1, 3),
      bossPart: opts.bossPart || null,
    };
    if (G.mut) { if (G.mut.ng) { e.hp *= 1.6; e.maxHp *= 1.6; e.dmg *= 1.6; } if (G.mut.fast) e.spd *= 1.3; }
    G.enemies.push(e);
    return e;
  }
  function seek(e, ux, uy, d, mul = 1) {
    const f = e.flank * mul * clamp((d - 90) / 220, 0, 1);
    const c = Math.cos(f), s = Math.sin(f);
    return [ux * c - uy * s, ux * s + uy * c];
  }
  // снаряды мобов летят недалеко и рассеиваются (раньше – до 6 секунд, через полкарты)
  const MOB_SHOT_RANGE = 480, MOB_RING_RANGE = 380, SHOT_FADE = 0.3;
  function fireShot(e) {
    const s = e.def.shot;
    const dmg = s.dmg * (e.dmg / e.def.dmg);
    if (s.kind === 'bolt') {
      const tt = 0.6;
      const Q = AIM || P; hazardCircle(Q.x + (Q.vx || 0) * tt, Q.y + (Q.vy || 0) * tt, 44, 0.7, dmg, 'bolt');
    } else if (s.ring) {
      const off = s.spin ? e.t * 2 : e.t;
      for (let k = 0; k < s.n; k++) ebullet(e.x, e.y, k / s.n * TAU + off, s.spd, dmg, s.col || '#ff3ea5', 8, { emoji: s.emoji, square: s.square, life: MOB_RING_RANGE / s.spd });
    } else {
      const a = leadAngle(e.x, e.y, s.spd);
      for (let k = 0; k < s.n; k++) ebullet(e.x, e.y, a + (k - (s.n - 1) / 2) * (s.spread || 0), s.spd, dmg, s.col || '#ffffff', s.emoji ? 9 : 6, { life: MOB_SHOT_RANGE / s.spd, emoji: s.emoji, emojiSet: s.emojiSet, square: s.square });
    }
    Sound.sfx.enemyShot();
  }
  function tryDodge(e) {
    for (const f of G.feathers) {
      const rx = e.x - f.x, ry = e.y - f.y;
      if (rx * rx + ry * ry > 95 * 95) continue;
      const sp = Math.hypot(f.vx, f.vy) || 1, vx = f.vx / sp, vy = f.vy / sp;
      const along = rx * vx + ry * vy, cross = rx * vy - ry * vx;
      if (along > 0 && Math.abs(cross) < e.r + 10) {
        const s = cross >= 0 ? 1 : -1;
        e.kx += -vy * s * 330; e.ky += vx * s * 330;
        e.dodgeCd = e.elite ? 0.9 : 1.6;
        part(e.x, e.y, 0, 0, 0.3, 4, 'rgba(255,255,255,0.7)');
        return;
      }
    }
  }
  // сколько стрелков стреляют разом: в главах – по номеру главы, в обороне – трое (в Бездне и раше стрелки молчат, как и раньше)
  function shotCap() { return typeof CHN === 'number' ? 2 + CHN : G.core ? 3 : -1; }
  function updateEnemy(e, dt) {
    const Q = AIM || P; // цель моба
    e.t += dt;
    if (e.flash > 0) e.flash -= dt;
    if (e.orbCd > 0) e.orbCd -= dt;
    if (e.slowT > 0) e.slowT -= dt;
    if (e.dodgeCd > 0) e.dodgeCd -= dt;
    if (e.healing > 0) e.healing -= dt;
    if (e.buffT > 0) e.buffT -= dt;
    if (e.spawnT > 0) { e.spawnT -= dt; return; }
    if (e.burnT > 0) {
      e.burnT -= dt; e.burnTick -= dt;
      if (e.burnTick <= 0) {
        e.burnTick = 0.4; e.hp -= e.burnDps * 0.4 * (1 - e.dr);
        if (Math.random() < 0.5) part(e.x + rnd(-6, 6), e.y - 6, rnd(-20, 20), rnd(-60, -30), 0.4, 3, '#ff8a2a');
        if (e.hp <= 0) { killEnemy(e); return; }
      }
    }
    if (e.affix === 'vampiric' && e.hp < e.maxHp) e.hp = Math.min(e.maxHp, e.hp + e.maxHp * 0.02 * dt);
    const def = e.def;
    const dx = Q.x - e.x, dy = Q.y - e.y, d = Math.hypot(dx, dy) || 1;
    const ux = dx / d, uy = dy / d;
    e.look = Math.atan2(dy, dx);
    let mx = 0, my = 0, spd = e.spd * (e.slowT > 0 ? 0.55 : 1);
    const evId = G.ev ? G.ev.def.id : null;
    if (evId === 'song' && !e.minion) { e.kx *= 0.9; e.ky *= 0.9; return; } // концерт: замерли и танцуют
    if (G.hidden && !e.minion) { const a = e.seed * 3 + e.t * 0.6; moveEntity(e, Math.cos(a) * spd * 0.3 * dt, Math.sin(a) * spd * 0.3 * dt); return; } // Тесса в коробке
    if (e.lit > 0) { e.lit -= dt; spd *= 0.6; } // тёплый свет лампы глитчам не нравится
    if (evId === 'rage') spd *= 1.25;
    if (e.thief) { // золотой воришка убегает зигзагом и обходит стены
      spd = P.speed * 0.8 * (e.slowT > 0 ? 0.6 : 1);
      const w = Math.sin(e.t * 2.2 + e.seed * 5) * 0.75;
      let fx = -ux - uy * w, fy = -uy + ux * w; const L = Math.hypot(fx, fy) || 1; fx /= L; fy /= L;
      for (let k = 0; k < 4 && !walkable(e.x + fx * 34, e.y + fy * 34, false); k++) { const s2 = e.seed > 0.5 ? 1 : -1; [fx, fy] = [-fy * s2, fx * s2]; }
      mx = fx; my = fy;
      if (Math.random() < dt * 8) part(e.x + rnd(-8, 8), e.y - 6, rnd(-20, 20), rnd(-50, -20), 0.5, 3, '#ffd25a');
    } else switch (def.ai) {
      case 'chase': [mx, my] = seek(e, ux, uy, d); spd *= 0.82; if (def.pack && d < 170) spd *= 1.2; break; // догоняющие – помедленнее, от них можно оторваться
      case 'hop': [mx, my] = seek(e, ux, uy, d); spd *= 1.8 * Math.max(0, Math.sin(e.t * 6 + e.seed)); break;
      case 'bat': { const w = Math.sin(e.t * 5 + e.seed) * 0.9; const [sx, sy] = seek(e, ux, uy, d); mx = sx - sy * w; my = sy + sx * w; break; }
      case 'swarm': if (d < 130) { mx = ux; my = uy; spd *= 1.15; } else [mx, my] = seek(e, ux, uy, d, 1.6); break;
      case 'jump':
        e.jt -= dt;
        if (e.wind > 0) { e.wind -= dt; if (e.wind <= 0) { e.jd = 0.35; const a = leadAngle(e.x, e.y, 300, 0.5); e.jx = Math.cos(a); e.jy = Math.sin(a); } }
        else if (e.jd > 0) { e.jd -= dt; mx = e.jx; my = e.jy; spd = 300; }
        else if (e.jt <= 0 && d < 500) { e.jt = rnd(1.2, 1.8); e.wind = 0.35; }
        else if (G.core && d >= 500) { [mx, my] = seek(e, ux, uy, d); spd *= 0.7; } // в обороне издалека подходят пешком
        break;
      case 'ranged': case 'turret': {
        if (def.ai === 'ranged') {
          if (d > 230) { [mx, my] = seek(e, ux, uy, d); } else if (d < 105) { mx = -ux; my = -uy; }
          else { const s = Math.sin(e.seed) > 0 ? 1 : -1; mx = -uy * s; my = ux * s; spd *= 0.6; }
        }
        e.cd -= dt;
        if (e.burst > 0) { e.burstT -= dt; if (e.burstT <= 0) { fireShot(e); e.burst--; e.burstT = 0.16; } }
        else if (e.charge > 0) { e.charge -= dt; spd *= 0.3; if (e.charge <= 0) { fireShot(e); if (def.shot.burst) { e.burst = def.shot.burst - 1; e.burstT = 0.16; } } }
        else if (e.cd <= 0 && d < 430) {
          if (G.shooters < shotCap()) { e.charge = 0.38; e.cd = def.shot.cd * rnd(0.85, 1.15) * e.cdMul; G.shooters++; }
          else e.cd = 0.3;
        }
        break;
      }
      case 'summoner': {
        e.cd -= dt; e.sumT -= dt;
        if (e.charge > 0) { e.charge -= dt; if (e.charge <= 0) fireShot(e); }
        else if (e.cd <= 0 && d < 430 && G.shooters < shotCap()) { e.charge = 0.4; e.cd = def.shot.cd * e.cdMul; G.shooters++; }
        if (e.sumT <= 0) {
          e.sumT = 5;
          const mine = G.enemies.filter(o => o.owner === e && !o.dead).length;
          for (let k = 0; k < 2 && mine + k < 6; k++) { const s = spawnEnemy(def.summons, e.x + rnd(-24, 24), e.y + rnd(-24, 24), e.biome, { owner: e, E: e.E }); s.xp *= 0.3; }
        }
        break;
      }
      case 'buffer': {
        if (d < 260) { mx = -ux; my = -uy; }
        let cxs = 0, cys = 0, n = 0;
        for (const o of G.enemies) { if (o === e || o.dead) continue; const dd = (o.x - e.x) ** 2 + (o.y - e.y) ** 2; if (dd < 400 * 400) { cxs += o.x; cys += o.y; n++; } }
        if (n) { const tx = cxs / n - e.x, ty = cys / n - e.y, tl = Math.hypot(tx, ty) || 1; if (tl > 90) { mx += tx / tl * 0.7; my += ty / tl * 0.7; } }
        else if (G.core) [mx, my] = seek(e, ux, uy, d); // в обороне одинокая поддержка тоже идёт к кристаллу
        e.cd -= dt;
        if (e.cd <= 0) {
          e.cd = 3.5; e.healTargets = [];
          for (const o of G.enemies) {
            if (o === e || o.dead) continue;
            if ((o.x - e.x) ** 2 + (o.y - e.y) ** 2 < 200 * 200) { o.buffT = 3; e.healTargets.push(o); }
          }
          if (e.healTargets.length) e.healing = 0.5;
        }
        break;
      }
      case 'healer': {
        if (d < 260) { mx = -ux; my = -uy; }
        let cxs = 0, cys = 0, n = 0;
        for (const o of G.enemies) { if (o === e || o.dead || o.def.ai === 'healer') continue; const dd = (o.x - e.x) ** 2 + (o.y - e.y) ** 2; if (dd < 400 * 400) { cxs += o.x; cys += o.y; n++; } }
        if (n) { const tx = cxs / n - e.x, ty = cys / n - e.y, tl = Math.hypot(tx, ty) || 1; if (tl > 90) { mx += tx / tl * 0.7; my += ty / tl * 0.7; } }
        else if (G.core) [mx, my] = seek(e, ux, uy, d); // в обороне одинокая поддержка тоже идёт к кристаллу
        e.cd -= dt;
        if (e.cd <= 0) {
          e.cd = 3.2; e.healTargets = [];
          for (const o of G.enemies) {
            if (o === e || o.dead || o.hp >= o.maxHp) continue;
            if ((o.x - e.x) ** 2 + (o.y - e.y) ** 2 < 190 * 190) { o.hp = Math.min(o.maxHp, o.hp + o.maxHp * 0.3); e.healTargets.push(o); floatText(o.x, o.y - o.r - 8, '+', '#7dff9a'); }
          }
          if (e.healTargets.length) e.healing = 0.5;
        }
        break;
      }
      case 'shield':
        e.shieldAng += clamp(angDiff(e.shieldAng, e.look), -2.1 * dt, 2.1 * dt);
        [mx, my] = seek(e, ux, uy, d, 0.5);
        break;
      case 'exploder':
        if (e.fuse > 0) { e.fuse -= dt; if (e.fuse <= 0) { e.exploded = true; killEnemy(e); } }
        else { [mx, my] = seek(e, ux, uy, d); if (d < 72) { e.fuse = 0.65; e.haz = hazardCircle(e.x, e.y, 88, 0.65, e.dmg, 'boom'); Sound.sfx.fuse(); } }
        break;
      case 'charger':
        if (e.wind > 0) { e.wind -= dt; if (e.wind <= 0) e.jd = 0.42; }
        else if (e.jd > 0) { e.jd -= dt; mx = Math.cos(e.dashAng); my = Math.sin(e.dashAng); spd = 490; if (e.jd <= 0) e.cd = rnd(1.2, 2); }
        else {
          e.cd -= dt;
          [mx, my] = seek(e, ux, uy, d);
          if (d < 290 && e.cd <= 0) { e.wind = 0.55; e.dashAng = leadAngle(e.x, e.y, 490, 0.5); mx = 0; my = 0; }
        }
        break;
      case 'bouncer': {
        if (!e.vx && !e.vy) { const a = e.look + rnd(-0.6, 0.6); e.vx = Math.cos(a); e.vy = Math.sin(a); }
        const cur = Math.atan2(e.vy, e.vx), na = cur + clamp(angDiff(cur, e.look), -1.3 * dt, 1.3 * dt);
        e.vx = Math.cos(na); e.vy = Math.sin(na);
        const ox = e.x, oy = e.y, stx = e.vx * spd * dt, sty = e.vy * spd * dt;
        moveEntity(e, stx, sty);
        if (Math.abs(e.x - ox) < Math.abs(stx) * 0.5) e.vx = -e.vx;
        if (Math.abs(e.y - oy) < Math.abs(sty) * 0.5) e.vy = -e.vy;
        spd = 0;
        break;
      }
      case 'blinker':
        if (e.blink > 0) {
          e.blink -= dt; spd = 0;
          if (e.blink <= 0) { e.x = e.bx; e.y = e.by; burst(e.x, e.y, 14, '#ff5bf0', 160); e.kx = ux * 220; e.ky = uy * 220; }
        } else {
          [mx, my] = seek(e, ux, uy, d);
          e.cd -= dt;
          if (e.cd <= 0 && d > 150 && d < 480) {
            const base = Math.hypot(Q.vx, Q.vy) > 20 ? Math.atan2(Q.vy, Q.vx) : rnd(0, TAU);
            for (let k = 0; k < 6; k++) {
              const a = base + rnd(-0.9, 0.9), x = Q.x + Math.cos(a) * 95, y = Q.y + Math.sin(a) * 95;
              if (walkable(x, y, e.fly)) { e.bx = x; e.by = y; e.blink = 0.55; hazardCircle(x, y, 26, 0.55, 0, 'dark'); break; }
            }
            e.cd = rnd(3, 4.5);
          }
        }
        break;
    }
    if (def.dodge && e.dodgeCd <= 0) tryDodge(e);
    // обход препятствий
    if (e.steerT > 0) {
      e.steerT -= dt;
      const a = e.steerDir * 1.25, c = Math.cos(a), s = Math.sin(a);
      const nx = mx * c - my * s, ny = mx * s + my * c; mx = nx; my = ny;
    }
    if (Math.abs(mx) > 0.1) e.face = mx > 0 ? 1 : -1;
    const ex = e.x, ey = e.y;
    const want = Math.hypot(mx, my) * spd * dt;
    moveEntity(e, (mx * spd + e.kx) * dt, (my * spd + e.ky) * dt);
    if (!e.fly && want > 0.6) {
      const moved = Math.hypot(e.x - ex, e.y - ey);
      if (moved < want * 0.3) { e.stuckT += dt; if (e.stuckT > 0.2) { e.steerT = 0.7; e.steerDir = Math.random() < 0.5 ? -1 : 1; e.stuckT = 0; } }
      else e.stuckT = 0;
    }
    const kd = Math.pow(0.002, dt); e.kx *= kd; e.ky *= kd;
    const dP = Q === P ? d : Math.hypot(P.x - e.x, P.y - e.y); // касание считаем по себе: по подругам бьёт их телефон
    if (dP < e.r + P.r - 2 && e.blink <= 0 && e.fuse <= 0 && !e.thief) {
      const wasInv = P.inv > 0 || P.dashT > 0;
      hurtPlayer(e.jd > 0 && def.ai === 'charger' ? e.dmg * 1.5 : e.dmg, e.x, e.y);
      if (!wasInv && e.affix === 'vampiric') e.hp = Math.min(e.maxHp, e.hp + e.dmg * 2);
    }
    if (d > 1600 && !e.shrine && !e.champion && !e.mimicOf) e.dead = true;
  }
  function updateEnemies(dt) {
    const list = G.enemies;
    G.shooters = 0;
    for (const e of list) if (!e.dead && (e.charge > 0 || e.burst > 0)) G.shooters++;
    for (const e of list) if (!e.dead) {
      AIM = NET.host ? netAim(e.x, e.y) : P;
      if (G.td && tdEnemyTick(e, dt)) continue; // в обороне враги идут по дороге; отвлеклась на героиню – дальше своим умом
      updateEnemy(e, dt);
    }
    AIM = P;
    for (let i = 0; i < list.length; i++) {
      const a = list[i]; if (a.dead || a.spawnT > 0) continue;
      for (let j = i + 1; j < list.length; j++) {
        const b = list[j]; if (b.dead || b.spawnT > 0) continue;
        const dx = b.x - a.x, dy = b.y - a.y, rr = a.r + b.r;
        const d2 = dx * dx + dy * dy;
        if (d2 < rr * rr && d2 > 0.01) {
          const d = Math.sqrt(d2), push = (rr - d) * 0.5, nx = dx / d, ny = dy / d;
          if (a.def.ai !== 'turret') { a.x -= nx * push; a.y -= ny * push; }
          if (b.def.ai !== 'turret') { b.x += nx * push; b.y += ny * push; }
        }
      }
    }
    if (G.td) for (const e of list) { // в обороне враги не сходят с дороги, даже когда толкаются у котов или стоят во льду
      if (e.dead || e.ln === undefined || e.ag || e.back || e.px === undefined) continue;
      const dx = e.x - e.px, dy = e.y - e.py, d = Math.hypot(dx, dy);
      if (d > 26) { e.x = e.px + dx / d * 26; e.y = e.py + dy / d * 26; }
    }
    G.enemies = list.filter(e => !e.dead);
  }
  function killEnemy(e, silent) {
    if (e.dead) return;
    e.dead = true;
    if (e.haz && !e.exploded) { e.haz.cancel = true; if (NET.host && e.haz.nid) NET.hzCancel.push(e.haz.nid); }
    burst(e.x, e.y, e.elite ? 30 : 12, e.type === 'snowman' ? '#ffffff' : e.col.startsWith('#') ? e.col : '#c77dff', 170);
    if (e.exploded) { burst(e.x, e.y, 30, '#ff8a2a', 260); Sound.sfx.boom(); G.shake = Math.max(G.shake, 8); }
    if (e.shrine) e.shrine.left--;
    if (e.bossPart) bossPartDestroyed(e.bossPart);
    if (e.affix === 'volatile' && !silent) hazardCircle(e.x, e.y, 95, 0.55, e.dmg * 1.3, 'boom');
    else if (G.mut && G.mut.boom && !silent && !e.minion && !e.bossPart) hazardCircle(e.x, e.y, 80, 0.6, e.dmg, 'boom');
    if (e.def.puddle && !silent) G.hazards.push({ kind: 'zone', x: e.x, y: e.y, r: 52, t: 0, delay: 0.2, dur: 4, dot: e.dmg * 0.3, fx: 'toxic' });
    if (NET.host && e.nid) NET.killed.push([e.nid]);
    if (silent || e.def.noDrop) return;
    G.kills++;
    if (G.td && G.abyss && !G.abyss.done) {
      G.abyss.coins += Math.round((1.5 + e.def.xp * 1.2) * (e.champion ? 8 : e.elite ? 3 : 1) * (tdTwist('gold') ? 2 : 1)); // монетки на стройку – общие
      for (const sp of G.td.spots) { const tw = sp.tw; if (!tw || tw.k !== 'bank' || tw.lvl < 4) continue; const S = tdStat(tw.def, tw.lvl, tw.sp); if (S.luck && (e.x - tw.x) ** 2 + (e.y - tw.y) ** 2 < S.rng * S.rng) { G.abyss.coins += S.luck; tw.pop = { v: S.luck, t: 0.8 }; } } // счастливая монетка
    }
    const byMate = TD_HIT ? -1 : NET.host ? NET.hitBy : 0; // добила подруга – супер и вампиризм ей; добила башня (−1) – никому
    if (byMate > 0) netEvent(byMate, ['k', e.elite ? 1 : 0, e.type]); else { if (!byMate) addSuper(e.elite ? 8 : 2.2); life('kills'); if (e.elite) life('elites'); bookKill('e', e.type); }
    if (!byMate && e.slowT > 0 && lv('evBlizzard')) { // ледяная буря: осколки во все стороны
      for (let k = 0; k < 6; k++) { const a = k * TAU / 6 + Math.random() * 0.4; G.feathers.push({ x: e.x, y: e.y, vx: Math.cos(a) * 430, vy: Math.sin(a) * 430, dmg: P.dmg * 0.6, pierce: 1, life: 0.45, life0: 0.45, hit: [e], kind: P.proj }); }
      burst(e.x, e.y, 14, '#bfeaff', 170);
    }
    dailyAdd(e.elite ? 50 : 10);
    if (G.st) { G.st.kills++; if (e.elite) G.st.elites++; G.st.byType[e.type] = (G.st.byType[e.type] || 0) + 1; }
    Sound.sfx.die();
    dropGem(e.x, e.y, e.xp * (1 + Math.min(G.combo, 100) / 100) / netXpDiv()); // вместе мобов больше – опыт с них делим
    if (!TD_HIT) { G.combo++; G.comboT = 2.6; G.bestCombo = Math.max(G.bestCombo, G.combo); } // комбо – только за свои победы, башни не в счёт
    if (!byMate && P.vamp && P.hp < P.maxHp) P.hp = Math.min(P.maxHp, P.hp + P.vamp);
    const luck = 1 + 0.15 * talent('luck');
    const nShards = G.td ? (e.elite && Math.random() < 0.5 ? 1 : 0) : e.elite ? 3 : (Math.random() < SHARD_CHANCE * luck * (G.ev && G.ev.def.id === 'gold' ? 2 : G.ev && G.ev.def.id === 'rage' ? 1.5 : 1) ? 1 : 0);
    for (let i = 0; i < nShards * (weekEv('gold') ? 2 : 1); i++) dropShard(e.x, e.y);
    if (e.elite && !e.champion && Math.random() < 0.007) dropPickup(e.x - 12, e.y, 'key'); // ключи редкие – золотой сундук должен быть наградой
    if (e.mimicOf) mimicKilled(e);
    if (e.thief) thiefCaught(e);
    if (G.ev && G.ev.def.id === 'horde' && !e.minion) G.ev.kills++;
    if (e.gladeBeast || e.pikeLoot) {
      dropPickup(e.x + 14, e.y, 'heart'); for (let k = 0; k < (e.gladeBeast ? 6 : 3); k++) dropShard(e.x, e.y);
      if (e.gladeBeast) { dropPickup(e.x - 14, e.y, 'key'); floatText(e.x, e.y - 40, '🐆 Барс повержен!', '#ffd25a', true); }
    }
    if (!byMate && hasRelic('fang') && P.hp < P.maxHp) P.hp = Math.min(P.maxHp, P.hp + P.maxHp * 0.005 * (1 + relicLv('fang')));
    const r = Math.random();
    // чем меньше здоровья, тем чаще падают сердечки
    if (e.elite || r < (0.03 + 0.05 * clamp(1 - P.hp / P.maxHp, 0, 1) + 0.04 * lv('c1petal')) * luck) dropPickup(e.x + 10, e.y, 'heart');
    else if (r > 0.993) dropPickup(e.x + 10, e.y, 'magnet');
    calmKill(e.biome);
    if (e.champion) {
      G.champ = null; if (G.st) G.st.champs = (G.st.champs || 0) + 1; if (!byMate) { life('champs'); if (weekEv('champ')) life('spts', 15); } dailyAdd(300);
      { const pr = loadProfile(); pr.champsTotal = (pr.champsTotal || 0) + 1; saveProfile(pr); if (pr.champsTotal >= 10) unlockOutfit('crown'); }
      showBanner('👑 Чемпион повержен!', 'Награда: улучшение, осколки и сердечко');
      Sound.sfx.chest(); burst(e.x, e.y, 40, '#ffd25a', 260);
      for (let i = 0; i < 6; i++) dropShard(e.x + rnd(-30, 30), e.y + rnd(-30, 30));
      dropPickup(e.x, e.y + 20, 'heart'); if (Math.random() < 0.35) dropPickup(e.x - 24, e.y + 20, 'key');
      G.pendingLv++; openLevelUp();
      if (NET.host) for (const m of NET.peers.values()) netEvent(m.id, ['lvl', 1]); // награда за чемпиона – всем
    }
    if (e.def.split) for (let k = 0; k < 2; k++) {
      const s = spawnEnemy(e.def.split, e.x + rnd(-10, 10), e.y + rnd(-10, 10), e.biome, { instant: true, E: e.E });
      s.kx = rnd(-200, 200); s.ky = rnd(-200, 200); s.shrine = e.shrine;
      if (e.shrine) e.shrine.left++;
    }
  }
  function damageEnemy(e, hit, kx, ky, fromFeather) {
    if (e.dead || e.spawnT > 0) return false;
    if (!NET.hitBy && e.slowT > 0 && lv('evBlizzard')) hit = { v: hit.v * 1.3, crit: hit.crit }; // ледяная буря
    if (NET.client) { // попадание гостьи: хозяин посчитает урон, тут – только вспышка и цифра
      if (!e.nid) return false;
      if (G.td && G.abyss) hit = { v: hit.v * (G.abyss.heroK || 1), crit: hit.crit }; // в обороне прокачка гостьи тоже уравнивается – у неё самой
      NET.hits.push([e.nid, Math.round(hit.v), hit.crit ? 1 : 0, Math.round(kx || 0), Math.round(ky || 0), P.frost && fromFeather ? +(1.2 + 0.4 * P.frost).toFixed(1) : 0]);
      e.flash = 0.1; e.hp = Math.max(1, e.hp - hit.v * (1 - (e.dr || 0)));
      dmgText(e.x + rnd(-6, 6), e.y - e.r - 6, hit.v * (1 - (e.dr || 0)), '#fff', hit.crit);
      if (G.st) G.st.dmgDealt += hit.v;
      Sound.sfx.hit();
      return true;
    }
    const shield = !TD_HIT && tdPortal(e); // у входа враги под защитой портала
    if (shield && (G.portalSaid || 0) < G.time) { G.portalSaid = G.time + 2.5; floatText(e.x, e.y - e.r - 14, '🌀 портал защищает', '#e0a0ff'); }
    const v = hit.v * (1 - e.dr) * (e.buffT > 0 ? 0.6 : 1) * (shield ? 0.25 : 1) * (G.td && G.abyss && e.ln !== undefined && !TD_HIT && !NET.hitBy ? (G.abyss.heroK || 1) : 1);
    e.hp -= v; e.flash = 0.1;
    if (G.st) G.st.dmgDealt += Math.min(v, e.hp + v);
    if (e.def.ai !== 'turret') { e.kx += kx; e.ky += ky; }
    if (P.frost && fromFeather) e.slowT = 1.2 + 0.4 * P.frost;
    dmgText(e.x + rnd(-6, 6), e.y - e.r - 6, v, e.dr || e.buffT > 0 ? '#b8c4d8' : '#fff', hit.crit);
    Sound.sfx.hit();
    if (e.hp <= 0) killEnemy(e);
    return true;
  }

  // ------------------------------------------------------------------
  //  Боссы
  // ------------------------------------------------------------------
  function makeBosses() {
    bosses = CFG.bosses.map((kind, i) => {
      const d = BOSSES[kind];
      const hx = tc(CFG.bossTiles[i].x), hy = tc(CFG.bossTiles[i].y);
      return {
        id: i, kind, def: d, name: d.name, sub: d.sub, r: d.r, maxHp: 1, hp: 1, spd: d.spd, dmg: 0, cdmg: 0,
        E: CFG.bossLevels[i], level: CFG.bossLevels[i], aggro: 1, shield: false, stunT: 0, burnT: 0, burnDps: 0, burnTick: 0,
        fly: !!d.fly, move: d.move, hx, hy, x: hx, y: hy, state: G.defeated[i] ? 'dead' : 'sleep', mode: 'idle', t: 0,
        flash: 0, z: 0, last: null, stage: 0, sub: 0, cnt: 0, anim: Math.random() * 5, alpha: 1, ang: 0, tx: 0, ty: 0,
        sx: 0, sy: 0, dist: 0, charging: false, dur: 0, inv: false, final: i === CFG.bosses.length - 1, look: 0, p: null,
        speedMul: 1, tauntT: 9, orbCd: 0, bubble: null,
        calmBiome: i < CFG.bosses.length - 1 ? biomeMap[CFG.bossTiles[i].y * MW + CFG.bossTiles[i].x] : -1,
      };
    });
  }
  const guardiansCount = () => bosses.length - 1;
  const guardiansDone = () => G.defeated.slice(0, guardiansCount()).filter(Boolean).length;
  function startBossFight(b) {
    bossStats(b); G.bossHurt = false;
    if (talent('brave') && !CFG.rush && !CFG.abyss) { P.inv = Math.max(P.inv, 3); floatText(P.x, P.y - 40, '🫧 Храбрый вход', '#bfeaff', true); }
    b.mpX = netCoop() ? 3 : 1; // вместе – втрое крепче
    if (b.mpX > 1) { b.maxHp *= b.mpX; b.hp = b.maxHp; }
    if (G.st && !G.st.cur) G.st.cur = { k: b.kind, n: b.name, pl: P.level, bl: b.level, t0: G.st.time, d: 0, h: 0, df: G.diffId };
    b.state = 'fight'; b.mode = 'idle'; b.t = 1.5; b.stage = 0; b.speedMul = b.aggro; G.activeBoss = b;
    // обычные мобы разбегаются – на арене только босс и его свита
    if (!G.core) for (const e of G.enemies) if (!e.minion && !e.shrine && !e.bossPart && Math.hypot(e.x - b.x, e.y - b.y) < 800) { e.dead = true; burst(e.x, e.y, 6, '#c9b3ff', 90); }
    G.bossHeartT = (HEART_EVERY[G.diffId] || 12) * 0.8;
    b.shield = false; b.stunT = 0; b.burnT = 0;
    showBanner(b.name, `${b.sub} · ур. ${b.level}`);
    Sound.sfx.roar(); Sound.music(CFG.abyss && G.abyss && G.abyss.mus ? abyssBossTrack() : b.def.music ? b.def.music : b.def.immortal ? 'ultimate' : b.def.final ? (CHN === 3 ? 'final2' : 'final') : 'boss');
    if (G.ev) endEvent();
    speak(b.kind, b.def.lines.intro);
    G.shake = 10;
  }
  function resetBoss(b) {
    b.state = 'sleep'; b.hp = b.maxHp; b.x = b.hx; b.y = b.hy; b.z = 0; b.alpha = 1; b.stage = 0; b.speedMul = 1;
    b.mode = 'idle'; b.charging = false; b.inv = false; b.shield = false; b.stunT = 0; b.burnT = 0;
    if (G.activeBoss === b) { G.activeBoss = null; biomeMusic(true); }
    G.hazards.length = 0; G.ebullets.length = 0; G.beams.length = 0;
    for (const e of G.enemies) if (e.minion) e.dead = true;
  }
  function startStage(b, i) {
    b.stage = i; b.mode = 'trans'; b.t = 2.3; b.inv = true; b.charging = false; b.z = 0; b.alpha = 1;
    if (i > 0) dropHeartNear(100, 200);
    b.speedMul = (b.def.stages[i].spd || 1) * b.aggro; b.stunT = 0;
    G.ebullets.length = 0; G.hazards.length = 0; G.beams.length = 0;
    shockRing(b.x, b.y, '#ffffff', 320);
    const d = Math.hypot(P.x - b.x, P.y - b.y);
    if (d < 230) { const a = Math.atan2(P.y - b.y, P.x - b.x); moveEntity(P, Math.cos(a) * (230 - d), Math.sin(a) * (230 - d)); }
    showBanner(`СТАДИЯ ${i + 1}`, b.name);
    speak(b.kind, b.def.lines.stages[i]);
    if (b.final && i >= 2 && CFG.team) freeTessa();
    Sound.sfx.stage(); G.shake = 16;
  }
  function endAttack(b, rest) { b.mode = 'idle'; b.t = rest / b.speedMul; b.sub = 0; b.cnt = 0; b.charging = false; b.z = 0; b.alpha = 1; }
  function nextAttack(b) {
    const list = b.def.stages[b.stage].attacks;
    let a, guard = 0;
    do { a = pick(list); } while ((a[0] === b.last || (a[0] === 'mirrors' && b.shield)) && guard++ < 12 && list.length > 1);
    if (a[0] === 'mirrors' && b.shield) a = ['ring', { n: 16, waves: 2 }];
    b.last = a[0]; b.mode = a[0]; b.p = a[1] || {}; b.sub = 0; b.t = 0; b.cnt = 0;
  }
  function bossMove(b, dt) {
    const spd = b.spd * b.speedMul;
    const dx = AIM.x - b.x, dy = AIM.y - b.y, d = Math.hypot(dx, dy) || 1;
    let mx, my;
    if (b.move === 'hover') {
      const want = 150;
      mx = (-dy / d) + (dx / d) * (d - want) / 100; my = (dx / d) + (dy / d) * (d - want) / 100;
    } else { mx = dx / d; my = dy / d; if (d < b.r + AIM.r + 6) { mx = 0; my = 0; } }
    const hd = Math.hypot(b.x - b.hx, b.y - b.hy);
    if (hd > 340) { mx = (b.hx - b.x) / hd; my = (b.hy - b.y) / hd; }
    const m = Math.hypot(mx, my);
    if (m > 0.01) moveEntity(b, (mx / m) * spd * dt, (my / m) * spd * dt);
  }
  function ebullet(x, y, a, spd, dmg, col, r = 7, o = {}) {
    if (G.ebullets.length > 260 || (G.ebullets.length > 170 && Math.random() < 0.4)) return;
    G.ebullets.push({ x, y, vx: Math.cos(a) * spd, vy: Math.sin(a) * spd, spd, dmg, col, r, homing: o.homing || 0,
      life: o.life || 3.6, emoji: o.emoji ? pick(o.emojiSet || (G.activeBoss && G.activeBoss.def.emojiSet) || ZYAMA_EMOJI) : (o.heart ? '❤️' : null), slow: !!o.slow,
      square: !!o.square, saw: !!o.saw, bounce: !!o.bounce, missile: !!o.missile, hx: o.hx, hy: o.hy, rot: 0 });
  }
  function shotPuff(b, n) {
    if (b.saw || G.parts.length > partMax()) return;
    for (let k = 0; k < n; k++) { const a = Math.random() * TAU, v = rnd(20, 60); part(b.x, b.y, Math.cos(a) * v + b.vx * 0.15, Math.sin(a) * v + b.vy * 0.15, rnd(0.25, 0.45), b.r * 0.6, b.col || '#ffffff'); }
  }
  function bdmg(b, k = 1) { return b.dmg * k * (1 + 0.1 * b.stage); }
  function bossRing(b, n, spd, dmg, col, off = 0, o = {}) {
    for (let i = 0; i < n; i++) ebullet(b.x, b.y - b.z, off + (i / n) * TAU, spd, dmg, col, 7, o);
    Sound.sfx.enemyShot();
  }
  function hazardCircle(x, y, r, delay, dmg, fx) { const h = { kind: 'circle', x, y, r, t: 0, delay, dmg, fx, done: false }; G.hazards.push(h); return h; }
  function hazardLine(x, y, ang, len, w, delay, dmg, fx) { const h = { kind: 'line', x, y, ang, len, w, t: 0, delay, dmg, fx, done: false }; G.hazards.push(h); return h; }
  function minionCount(type) { let n = 0; for (const e of G.enemies) if (e.type === type && e.minion && !e.dead) n++; return n; }
  function summon(b, type, n, max = 6) {
    n = Math.max(1, Math.round(n * 0.85)); max = Math.max(2, Math.round(max * 0.8));
    const biome = biomeMap[Math.floor(b.hy / T) * MW + Math.floor(b.hx / T)];
    for (let i = 0; i < n; i++) {
      if (minionCount(type) >= max) break;
      const a = rnd(0, TAU), x = b.x + Math.cos(a) * (b.r + 34), y = b.y + Math.sin(a) * (b.r + 34);
      if (!walkable(x, y, ENEMIES[type].fly)) continue;
      const e = spawnEnemy(type, x, y, biome, { minion: true, E: b.E }); e.xp *= 0.3;
    }
    Sound.sfx.magic();
  }
  const ATK = {
    ring(b, dt, p) {
      if (b.t <= 0) {
        bossRing(b, p.n || 14, (p.spd || 150), bdmg(b), p.col || '#d7ff7a', b.cnt * 0.22, { square: p.square });
        b.cnt++; b.t = (p.gap || 0.45) / b.speedMul; if (b.cnt >= (p.waves || 3)) endAttack(b, 1.2);
      }
    },
    emoji(b, dt, p) {
      if (b.t <= 0) {
        bossRing(b, p.n || 14, 170, bdmg(b), '#ff3ea5', b.cnt * 0.25, { emoji: true });
        b.cnt++; b.t = 0.5 / b.speedMul; if (b.cnt >= (p.waves || 3)) endAttack(b, 1.2);
      }
    },
    spiral(b, dt, p) {
      if (b.sub === 0) { b.sub = 1; b.dur = p.dur || 2.6; b.t = 0; }
      b.dur -= dt;
      if (b.t <= 0) {
        const arms = p.arms || 3;
        for (let k = 0; k < arms; k++) ebullet(b.x, b.y - b.z, b.anim * 1.7 + (k / arms) * TAU, p.spd || 150, bdmg(b), p.rainbow ? RAINBOW[(b.cnt++) % 7] : (p.col || '#c77dff'), 7, { emoji: p.emoji, square: p.square });
        b.t = p.rate || 0.11; Sound.sfx.enemyShot();
      }
      if (b.dur <= 0) endAttack(b, 1.0);
    },
    aimed(b, dt, p) {
      if (b.t <= 0) {
        const spd = p.spd || 270;
        ebullet(b.x, b.y - b.z, leadAngle(b.x, b.y, spd) + rnd(-(p.spread || 0.22), p.spread || 0.22), spd, bdmg(b), p.col || '#ffffff', p.r || 9, { square: p.square, emoji: p.emoji });
        Sound.sfx.enemyShot(); b.cnt++; b.t = (p.rate || 0.16) / b.speedMul; if (b.cnt >= (p.count || 10)) endAttack(b, 1.1);
      }
    },
    shotgun(b, dt, p) {
      if (b.t <= 0) {
        const n = p.n || 5, a = leadAngle(b.x, b.y, 200);
        for (let k = 0; k < n; k++) ebullet(b.x, b.y - b.z, a + (k - (n - 1) / 2) * 0.17, 200, bdmg(b), p.col || '#7dffb0', 8, { emoji: p.emoji, emojiSet: p.emojiSet });
        Sound.sfx.enemyShot(); b.cnt++; b.t = 0.5 / b.speedMul; if (b.cnt >= (p.waves || 3)) endAttack(b, 1.2);
      }
    },
    stomp(b, dt, p) {
      if (b.sub === 0) { hazardCircle(b.x, b.y, (p.r || 140) + b.cnt * 25, 0.9 / Math.sqrt(b.speedMul), bdmg(b, 1.7), 'stomp'); b.sub = 1; b.t = 1.05 / Math.sqrt(b.speedMul); }
      else if (b.t <= 0) { b.cnt++; if (b.cnt < (p.repeat || 1)) b.sub = 0; else endAttack(b, 1.0); }
    },
    leap(b, dt, p) {
      if (b.sub === 0) {
        let tx = AIM.x + (AIM.vx || 0) * 0.4, ty = AIM.y + (AIM.vy || 0) * 0.4; const hd = Math.hypot(tx - b.hx, ty - b.hy);
        if (hd > 330) { tx = b.hx + (tx - b.hx) / hd * 330; ty = b.hy + (ty - b.hy) / hd * 330; }
        b.tx = tx; b.ty = ty; b.sx = b.x; b.sy = b.y; b.dur = 0.95 / Math.sqrt(b.speedMul);
        hazardCircle(tx, ty, p.r || 100, b.dur, bdmg(b, 1.8), 'stomp'); b.sub = 1; b.t = b.dur;
      } else if (b.sub === 1) {
        const k = 1 - clamp(b.t / b.dur, 0, 1);
        b.x = lerp(b.sx, b.tx, k); b.y = lerp(b.sy, b.ty, k); b.z = Math.sin(k * Math.PI) * 130;
        if (b.t <= 0) { b.z = 0; b.x = b.tx; b.y = b.ty; collide(b); bossRing(b, p.ringN || 12, 175, bdmg(b), '#7dffb0'); G.shake = 12; b.sub = 2; b.t = 0.5; }
      } else if (b.t <= 0) { b.cnt++; if (b.cnt < (p.repeat || 1)) b.sub = 0; else endAttack(b, 1.0); }
    },
    lash(b, dt, p) {
      if (b.sub === 0) {
        const base = Math.atan2(AIM.y - b.y, AIM.x - b.x), fan = p.fan || 1;
        for (let k = 0; k < fan; k++) hazardLine(b.x, b.y, base + (k - (fan - 1) / 2) * 0.4, 380, 34, 0.7, bdmg(b, 1.5), 'tongue');
        b.sub = 1; b.t = 1.0;
      } else if (b.t <= 0) { b.cnt++; if (b.cnt < (p.repeat || 1)) b.sub = 0; else endAttack(b, 0.9); }
    },
    charge(b, dt, p) {
      const spd = p.spd || 640;
      if (b.sub === 0) { b.ang = leadAngle(b.x, b.y, spd, 0.4); b.trailD = 0; hazardLine(b.x, b.y, b.ang, 560, 76, 0.75, 0, 'charge'); b.sub = 1; b.t = 0.75; }
      else if (b.sub === 1) { if (b.t <= 0) { b.sub = 2; b.dist = 0; b.charging = true; Sound.sfx.roar(); } }
      else if (b.sub === 2) {
        const step = spd * dt, ox = b.x, oy = b.y;
        moveEntity(b, Math.cos(b.ang) * step, Math.sin(b.ang) * step);
        const moved = Math.hypot(b.x - ox, b.y - oy);
        b.dist += step;
        if (p.trail && b.dist - (b.trailD || 0) > 40) { b.trailD = b.dist; G.hazards.push({ kind: 'zone', x: b.x, y: b.y, r: 30, t: 0, delay: 0.15, dur: 2.4, dot: bdmg(b, 0.45), fx: 'rainbow' }); }
        if (Math.random() < 0.6) part(b.x + rnd(-20, 20), b.y + 30, rnd(-40, 40), rnd(-60, -10), 0.5, 4, p.trail ? pick(RAINBOW) : '#ffffff');
        if (moved < step * 0.5 || b.dist >= 560 || Math.hypot(b.x - b.hx, b.y - b.hy) > 430) {
          b.charging = false; b.sub = 3; b.t = 0.6; G.shake = 10; Sound.sfx.boom(); burst(b.x, b.y, 18, '#e6f4ff', 200);
          if (p.ringN) bossRing(b, p.ringN, 180, bdmg(b), '#ffffff');
        }
      } else if (b.t <= 0) { b.cnt++; if (b.cnt < (p.repeat || 2)) b.sub = 0; else endAttack(b, 1.0); }
    },
    rain(b, dt, p) {
      if (b.t <= 0) {
        const a = rnd(0, TAU), d = b.cnt === 0 ? 0 : rnd(0, 150);
        hazardCircle(AIM.x + (AIM.vx || 0) * 0.5 + Math.cos(a) * d, AIM.y + (AIM.vy || 0) * 0.5 + Math.sin(a) * d, p.r || 58, 0.9, bdmg(b, 1.3), p.fx || 'rain');
        b.cnt++; b.t = (p.rate || 0.26) / b.speedMul; if (b.cnt >= (p.n || 8)) endAttack(b, 1.1);
      }
    },
    summon(b, dt, p) { summon(b, p.type, p.n || 2, p.max || 6); endAttack(b, 1.4); },
    laser(b, dt, p) {
      if (b.sub === 0) {
        const n = p.beams || 2, base = Math.atan2(AIM.y - b.y, AIM.x - b.x), dir = Math.random() < 0.5 ? -1 : 1;
        const dur = p.dur || 3.2;
        for (let k = 0; k < n; k++) G.beams.push({ b, ang: base + (k / n) * TAU + (n === 1 ? 0 : 0.4), rot: (p.rot || 0.8) * dir, len: 560, w: 24, t: 0, warm: 0.9, dur, dmg: bdmg(b, 1.1), mouth: !!p.mouth, rainbow: !!p.rainbow });
        b.sub = 1; b.t = 0.9 + dur; Sound.sfx.laser();
      } else { bossMove(b, dt * 0.25); if (b.t <= 0) endAttack(b, 1.0); }
    },
    cross(b, dt, p) {
      if (b.sub === 0) { for (let k = 0; k < 4; k++) hazardLine(b.x, b.y, k * Math.PI / 2, 700, 44, 0.9, bdmg(b, 1.5), 'beam'); b.sub = 1; b.t = 1.0; }
      else if (b.sub === 1) { if (b.t <= 0) { for (let k = 0; k < 4; k++) hazardLine(b.x, b.y, Math.PI / 4 + k * Math.PI / 2, 700, 44, 0.9, bdmg(b, 1.5), 'beam'); b.sub = 2; b.t = 1.1; } }
      else if (b.t <= 0) endAttack(b, 1.0);
    },
    // волна: кольцо с проходами. Сначала зелёные дорожки показывают, где пройти, потом идёт кольцо
    wave(b, dt, p) {
      if (b.t > 0) return;
      if (b.sub === 0) {
        const nG = p.gaps || (b.cnt % 2 ? 2 : 3), side = Math.random() < 0.5 ? -1 : 1;
        const base = b.cnt === 0 ? Math.atan2(AIM.y - b.y, AIM.x - b.x) + side * rnd(0.6, 1.0) : b.waveBase + side * rnd(0.7, 1.2);
        b.waveBase = base; b.waveGaps = Array.from({ length: nG }, (_, i) => base + i * TAU / nG);
        const warn = Math.max(0.55, 0.8 / b.speedMul);
        b.waveX = b.x; b.waveY = b.y; // кольцо пойдёт ровно оттуда, где показаны дорожки
        G.hazards.push({ kind: 'wavewarn', x: b.x, y: b.y, gaps: b.waveGaps, half: WAVE_GAP, t: 0, delay: warn - 0.3, dur: warn });
        Sound.sfx.fuse(); b.sub = 1; b.t = warn;
        if (!G.waveTip) { G.waveTip = true; floatText(AIM.x, AIM.y - 50, '🟢 Беги в зелёный проход!', '#9dffc0', true); }
        return;
      }
      G.hazards.push({ kind: 'wave', x: b.waveX, y: b.waveY, r: 14, spd: p.spd || 230, thick: 24, max: 760, dmg: bdmg(b, 1.4), t: 0, hit: false, gaps: b.waveGaps, half: WAVE_GAP });
      Sound.sfx.boom(); G.shake = 6;
      b.cnt++; b.sub = 0;
      if (b.cnt >= (p.n || 2)) endAttack(b, 1.3); else b.t = 0.45 / b.speedMul;
    },
    suck(b, dt, p) {
      if (b.sub === 0) { b.sub = 1; b.dur = p.dur || 2.5; Sound.sfx.laser(); }
      b.dur -= dt;
      const d = Math.hypot(b.x - AIM.x, b.y - AIM.y) || 1;
      if (AIM === P && P.dashT <= 0 && d > b.r) moveEntity(P, (b.x - AIM.x) / d * 150 * dt, (b.y - AIM.y) / d * 150 * dt);
      if (Math.random() < 0.7) { const a = rnd(0, TAU), r = rnd(120, 260); part(b.x + Math.cos(a) * r, b.y + Math.sin(a) * r, -Math.cos(a) * 280, -Math.sin(a) * 280, 0.6, 4, '#c8d0e0'); }
      if (b.dur <= 0) { if (p.ring) bossRing(b, 18, 170, bdmg(b), '#b0b0c0'); endAttack(b, 1.1); }
    },
    invert(b, dt, p) {
      if (AIM && AIM !== P && AIM.id) netEvent(AIM.id, ['inv', p.dur || 2.5]); // заклятие – той, в кого целится босс
      else { G.invertT = p.dur || 2.5; showBanner('🔄 ПЕРЕВЁРНУТО', 'Управление шиворот-навыворот!'); }
      Sound.sfx.whisper(); G.shake = 6;
      bossRing(b, 12, 150, bdmg(b), '#c08aff');
      endAttack(b, 1.2);
    },
    static(b, dt, p) {
      if (b.sub === 0) { b.sub = 1; b.dur = p.dur || 2.5; if (AIM && AIM !== P && AIM.id) netEvent(AIM.id, ['stat', b.dur]); else G.staticT = b.dur; Sound.sfx.staticNoise(); }
      b.dur -= dt; b.t -= dt;
      if (b.t <= 0) { b.t = 0.45 / b.speedMul; const a = Math.atan2(AIM.y - b.y, AIM.x - b.x); for (let k = -1; k <= 1; k++) ebullet(b.x, b.y - b.z, a + k * 0.25, 230, bdmg(b), '#e8e8e8', 7, { square: true }); }
      if (b.dur <= 0) endAttack(b, 1.1);
    },
    blizzard(b, dt, p) {
      if (b.sub === 0) { b.sub = 1; b.dur = p.dur || 3; b.t = 0.4; G.blizzardT = Math.max(G.blizzardT || 0, b.dur + 1); Sound.sfx.whisper(); floatText(b.x, b.y - b.r - 20, '❄️ МЕТЕЛЬ', '#e8f8ff', true); }
      b.dur -= dt; bossMove(b, dt * 0.6);
      if (b.t <= 0) {
        b.t = 0.75 / b.speedMul; const a = Math.atan2(AIM.y - b.y, AIM.x - b.x);
        for (let k = -2; k <= 2; k++) ebullet(b.x, b.y - b.z, a + k * 0.24, 200, bdmg(b), '#e8f8ff', 7);
        Sound.sfx.enemyShot();
      }
      if (b.dur <= 0) endAttack(b, 1.0);
    },
    homing(b, dt, p) {
      const n = p.n || 4;
      for (let k = 0; k < n; k++) ebullet(b.x, b.y - b.z, (k / n) * TAU + b.anim, 125, bdmg(b, 1.2), p.heart ? '#ff3b6b' : '#ff5bf0', 10, { homing: 1.8, life: 5.5, heart: p.heart });
      Sound.sfx.enemyShot(); endAttack(b, 1.6);
    },
    teleport(b, dt, p) {
      if (b.sub === 0) { b.sub = 1; b.t = 0.45; }
      else if (b.sub === 1) {
        b.alpha = clamp(b.t / 0.45, 0, 1);
        if (b.t <= 0) {
          let tx = b.x, ty = b.y;
          for (let k = 0; k < 14; k++) {
            const a = rnd(0, TAU), x = AIM.x + Math.cos(a) * 170, y = AIM.y + Math.sin(a) * 170;
            if (walkable(x, y, true) && Math.hypot(x - b.hx, y - b.hy) < 380) { tx = x; ty = y; break; }
          }
          b.tx = tx; b.ty = ty; hazardCircle(tx, ty, 80, 0.6, bdmg(b, 1.2), 'dark'); b.sub = 2; b.t = 0.6;
        }
      } else if (b.sub === 2) {
        if (b.t <= 0) { b.x = b.tx; b.y = b.ty; b.alpha = 1; bossRing(b, p.ringN || 14, 175, bdmg(b), '#c77dff', 0, { emoji: b.kind === 'zyama' }); burst(b.x, b.y, 24, '#c77dff', 220); b.sub = 3; b.t = 0.5; }
      } else if (b.t <= 0) endAttack(b, 0.9);
    },
    mines(b, dt, p) {
      if (b.sub === 0) {
        const n = p.n || 12;
        for (let k = 0; k < n; k++) hazardCircle(AIM.x + rnd(-260, 260), AIM.y + rnd(-260, 260), 52, 1.0 + k * 0.07, bdmg(b, 1.3), 'crystal');
        b.sub = 1; b.t = 1.0 + n * 0.07 + 0.4;
      } else if (b.t <= 0) endAttack(b, 1.0);
    },
    clones(b, dt, p) {
      const n = p.n || 3;
      for (let k = 0; k < n; k++) {
        const a = (k / n) * TAU + rnd(-0.3, 0.3), x = b.hx + Math.cos(a) * 230, y = b.hy + Math.sin(a) * 230;
        if (!walkable(x, y, true)) continue;
        const e = spawnEnemy('zclone', x, y, CASTLE.biome, { minion: true, E: b.E });
        e.hp = e.maxHp = b.maxHp / (b.mpX || 1) * 0.035; e.dmg = bdmg(b);
      }
      speak(b.kind, 'Знакомьтесь – мои клоны! Каждый из них тоже Зямочкккк! 👯');
      Sound.sfx.magic(); endAttack(b, 1.5);
    },
    web(b, dt, p) {
      if (b.t <= 0) {
        const n = p.n || 5, a = leadAngle(b.x, b.y, 210);
        for (let k = 0; k < n; k++) ebullet(b.x, b.y - b.z, a + (k - (n - 1) / 2) * 0.22, 210, bdmg(b, 0.8), '#e8e0ff', 10, { slow: true });
        Sound.sfx.enemyShot(); b.cnt++; b.t = 0.6; if (b.cnt >= (p.waves || 1)) endAttack(b, 1.0);
      }
    },
    honey(b, dt, p) {
      for (let k = 0; k < (p.n || 4); k++) G.hazards.push({ kind: 'zone', x: AIM.x + rnd(-190, 190), y: AIM.y + rnd(-190, 190), r: 72, t: 0, delay: 0.5, dur: 6, slow: true, fx: p.fx || 'honey' });
      endAttack(b, 1.0);
    },
    cream(b, dt, p) { ATK.honey(b, dt, Object.assign({ fx: 'cream' }, p)); },
    // --- Глава 3 ---
    glitch(b, dt, p) {
      if (b.t <= 0) {
        hazardCircle(b.x, b.y, 70, 0.6, bdmg(b, 1.3), 'glitch');
        let tx = b.x, ty = b.y;
        for (let k = 0; k < 12; k++) {
          const a = rnd(0, TAU), r = rnd(120, 200), x = AIM.x + Math.cos(a) * r, y = AIM.y + Math.sin(a) * r;
          if (walkable(x, y, b.fly) && Math.hypot(x - b.hx, y - b.hy) < 380) { tx = x; ty = y; break; }
        }
        burst(b.x, b.y, 16, '#ff3ea5', 180);
        b.x = tx; b.y = ty; collide(b);
        burst(b.x, b.y, 16, '#3ff0a0', 180);
        bossRing(b, 8, 170, bdmg(b), '#3ff0a0', rnd(0, 1), { square: true });
        Sound.sfx.blink();
        b.cnt++; b.t = 0.55 / b.speedMul; if (b.cnt >= (p.n || 3)) endAttack(b, 1.0);
      }
    },
    pixels(b, dt, p) {
      if (b.t <= 0) {
        const vertical = p.both ? b.cnt % 2 === 1 : false;
        const gap = Math.floor(rnd(-4, 5));
        for (let k = -9; k <= 9; k++) {
          if (Math.abs(k - gap) <= 1) continue;
          if (!vertical) ebullet(AIM.x + k * 40, AIM.y - 380, Math.PI / 2, 190, bdmg(b), '#3ff0a0', 9, { square: true, life: 4.5 });
          else ebullet(AIM.x - 380, AIM.y + k * 40, 0, 190, bdmg(b), '#ff3ea5', 9, { square: true, life: 4.5 });
        }
        Sound.sfx.enemyShot();
        b.cnt++; b.t = 1.0 / b.speedMul; if (b.cnt >= (p.n || 1) * (p.both ? 2 : 1)) endAttack(b, 1.0);
      }
    },
    sprinkles(b, dt, p) {
      if (b.sub === 0) { b.sub = 1; b.dur = p.dur || 2; b.t = 0; }
      b.dur -= dt;
      if (b.t <= 0) {
        const a = Math.atan2(AIM.y - b.y, AIM.x - b.x);
        for (let k = 0; k < 2; k++) ebullet(b.x, b.y - b.z, a + rnd(-0.9, 0.9), rnd(160, 260), bdmg(b, 0.8), pick(RAINBOW), 5);
        b.t = 0.05; if (Math.random() < 0.3) Sound.sfx.enemyShot();
      }
      if (b.dur <= 0) endAttack(b, 1.0);
    },
    lightning(b, dt, p) {
      if (b.t <= 0) {
        const a = rnd(0, TAU), d = b.cnt === 0 ? 0 : rnd(0, 160);
        hazardCircle(AIM.x + (AIM.vx || 0) * 0.6 + Math.cos(a) * d, AIM.y + (AIM.vy || 0) * 0.6 + Math.sin(a) * d, 50, 0.75, bdmg(b, 1.4), 'bolt');
        b.cnt++; b.t = (p.rate || 0.22) / b.speedMul; if (b.cnt >= (p.n || 8)) endAttack(b, 1.1);
      }
    },
    saws(b, dt, p) {
      const n = p.n || 2, a0 = Math.atan2(AIM.y - b.y, AIM.x - b.x);
      for (let k = 0; k < n; k++) ebullet(b.x, b.y, a0 + (k - (n - 1) / 2) * 0.5, 240, bdmg(b, 1.2), '#c0c0c0', 13, { saw: true, bounce: true, life: 7, hx: b.hx, hy: b.hy });
      Sound.sfx.enemyShot(); endAttack(b, 1.2);
    },
    missiles(b, dt, p) {
      const n = p.n || 4;
      for (let k = 0; k < n; k++) ebullet(b.x, b.y - 20, -Math.PI / 2 + (k - (n - 1) / 2) * 0.45, 175, bdmg(b, 1.2), '#ff6a22', 9, { homing: 2.6, life: 4.5, missile: true });
      Sound.sfx.enemyShot(); endAttack(b, 1.4);
    },
    comments(b, dt, p) {
      if (b.t <= 0) {
        const a = leadAngle(b.x, b.y, 220);
        for (let k = 0; k < 5; k++) ebullet(b.x, b.y, a + (k - 2) * 0.2, 220, bdmg(b), '#ffffff', 9, { emoji: true, emojiSet: ['💬', '🤬', '💢', '🙄'] });
        Sound.sfx.enemyShot(); b.cnt++; b.t = 0.45 / b.speedMul; if (b.cnt >= (p.waves || 3)) endAttack(b, 1.1);
      }
    },
    toxic(b, dt, p) {
      for (let k = 0; k < (p.n || 4); k++) G.hazards.push({ kind: 'zone', x: AIM.x + rnd(-200, 200), y: AIM.y + rnd(-200, 200), r: 62, t: 0, delay: 0.6, dur: 5, dot: bdmg(b, 0.35), fx: 'toxic' });
      endAttack(b, 1.0);
    },
    mirrors(b, dt, p) {
      const n = p.n || 4;
      let made = 0;
      for (let k = 0; k < n * 3 && made < n; k++) {
        const a = (made / n) * TAU + rnd(-0.3, 0.3), r = rnd(150, 190), x = AIM.x + Math.cos(a) * r, y = AIM.y + Math.sin(a) * r;
        if (!walkable(x, y, true) || Math.hypot(x - b.hx, y - b.hy) > 420) continue;
        const e = spawnEnemy('zmirror', x, y, CASTLE.biome, { minion: true, E: b.E, bossPart: b });
        e.hp = e.maxHp = b.maxHp / (b.mpX || 1) * 0.035; e.dmg = bdmg(b); made++;
      }
      if (made) { b.shield = true; b.shieldT = 22; speak(b.kind, 'Пока зеркала целы – я НЕУЯЗВИМ! Разбей их, если сможешь! 🪞'); Sound.sfx.magic(); }
      endAttack(b, 1.2);
    },
    erupt(b, dt, p) {
      if (b.t <= 0) {
        hazardCircle(AIM.x + rnd(-210, 210), AIM.y + rnd(-210, 210), 62, 0.9, bdmg(b, 1.4), 'erupt');
        b.cnt++; b.t = 0.17 / b.speedMul; if (b.cnt >= (p.n || 8)) endAttack(b, 1.2);
      }
    },
  };

  function updateBoss(b, dt) {
    AIM = NET.host ? netAim(b.x, b.y) : P;
    if (b.state === 'dead') return;
    if (b.bubble) { b.bubble.t -= dt; if (b.bubble.t <= 0) b.bubble = null; }
    b.anim += dt; if (b.flash > 0) b.flash -= dt; if (b.orbCd > 0) b.orbCd -= dt;
    b.look = Math.atan2(AIM.y - b.y, AIM.x - b.x);
    const WK = NET.host ? netAim(b.hx, b.hy) : P, dHome = Math.hypot(WK.x - b.hx, WK.y - b.hy); // будит любая героиня
    if (b.state === 'sleep') {
      if (CFG.abyss) return; // в Бездне стража будит волна
      if (CFG.rush) {
        if (b.id === G.rush.idx && G.rush.wait <= 0 && !G.rush.done && !G.activeBoss) {
          // в раше босс выходит рядом с героиней, а не в дальнем углу арены
          const nx = AIM.x, ny = AIM.y - 300;
          if (walkable(nx, ny, b.fly)) { b.hx = b.x = nx; b.hy = b.y = ny; }
          startBossFight(b);
        }
        return;
      }
      if (b.def.immortal) return;
      const clueOk = !CFG.detective || b.final || (G.clues5[b.id] || 0) >= 3;
      if (!clueOk && dHome < 330 && G.clueMsgT <= 0) { G.clueMsgT = 3; floatText(b.x, b.y - b.r - 20, `🔎 Сначала найди улики: ${G.clues5[b.id] || 0}/3`, '#ffd25a', true); }
      const can = (!b.final || (gateOpen && (playerInCastle() || netMateInCastle()))) && clueOk;
      if (can && dHome < 330 && !G.activeBoss) startBossFight(b);
      return;
    }
    if (dHome > 1000 && !CFG.rush && !G.td) { resetBoss(b); return; } // в обороне страж идёт к кристаллу сам, где бы ни была героиня
    const stages = b.def.stages;
    if (b.mode !== 'trans' && b.stage < stages.length - 1 && b.hp <= b.maxHp * stages[b.stage + 1].at) startStage(b, b.stage + 1);
    if (b.burnT > 0) {
      b.burnT -= dt; b.burnTick -= dt;
      if (b.burnTick <= 0) { b.burnTick = 0.4; damageBoss(b, { v: b.burnDps * 0.4, crit: false }, true); if (b.state !== 'fight') return; }
    }
    if (b.shield) {
      b.shieldT -= dt;
      if (b.shieldT <= 0) { for (const o of G.enemies) if (o.bossPart === b) killEnemy(o, true); bossPartDestroyed(b); b.stunT = 1.2; }
    }
    if (b.stunT > 0) {
      b.stunT -= dt;
      if (Math.random() < 0.3) part(b.x + rnd(-b.r, b.r), b.y - b.r - 10, 0, -30, 0.6, 4, '#ffe04a');
      return;
    }
    b.t -= dt;
    if (b.mode === 'trans') {
      if (Math.random() < 0.5) part(b.x + rnd(-b.r, b.r), b.y + rnd(-b.r, b.r), rnd(-40, 40), rnd(-120, -40), 0.7, 5, pick(['#ffffff', '#ffd25a', '#ff3ea5']));
      if (b.t <= 0) { b.inv = false; endAttack(b, 0.6); }
    } else if (b.mode === 'idle') { bossMove(b, dt); if (b.t <= 0) nextAttack(b); }
    else ATK[b.mode](b, dt, b.p);
    if (b.def.lines.taunts && b.mode !== 'trans') {
      b.tauntT -= dt;
      if (b.tauntT <= 0) { b.tauntT = rnd(9, 14); b.bubble = { text: pick(b.def.lines.taunts), t: 3.6 }; }
    }
    if (b.z < 10 && b.alpha > 0.5) {
      const d = Math.hypot(P.x - b.x, P.y - b.y); // по подругам бьёт их телефон
      if (!P.down && d < b.r + P.r - 4) hurtPlayer(b.charging ? b.cdmg * 1.6 : b.cdmg, b.x, b.y);
    }
  }
  function damageBoss(b, hit, dot, remote) {
    if (b.state !== 'fight' || b.alpha < 0.3 || b.z > 30) return false;
    if (NET.client && !b.inv && !b.shield && !b.def.immortal) {
      const v = hit.v * (b.stunT > 0 ? 1.5 : 1) * (1 + 0.12 * lv('c1guard')) * (1 + 0.08 * talent('boss'));
      NET.bhits.push([bosses.indexOf(b), Math.round(v), hit.crit ? 1 : 0, dot ? 1 : 0]);
      if (!dot) b.flash = 0.08; addSuper(v / Math.max(1, b.maxHp / (b.mpX || 1)) * 150);
      if (!dot) dmgText(b.x + rnd(-15, 15), b.y - b.r - 10, v, '#ffd25a', hit.crit);
      if (G.st) G.st.dmgDealt += v;
      return true;
    }
    if (b.inv) { if (Math.random() < 0.08) floatText(b.x, b.y - b.r - 14, 'неуязвим', '#aaaaaa'); return false; }
    if (b.shield) { if (Math.random() < 0.06) floatText(b.x, b.y - b.r - 14, 'зеркальный щит!', '#bfeaff'); return false; }
    if (b.def.immortal) { if (Math.random() < 0.08) floatText(b.x + rnd(-20, 20), b.y - b.r - 14, '∞', '#ff3ea5', true); addSuper(0.3); return false; }
    const v = remote ? hit.v : hit.v * (b.stunT > 0 ? 1.5 : 1) * (1 + 0.12 * lv('c1guard')) * (1 + 0.08 * talent('boss'));
    if (G.st && !remote) G.st.dmgDealt += v;
    b.hp -= v; if (!dot) b.flash = 0.08;
    if (!remote) addSuper(v / (b.maxHp / (b.mpX || 1)) * 150);
    if (dot) { if (Math.random() < 0.4) floatText(b.x + rnd(-20, 20), b.y - b.r, String(Math.round(v)), '#ff8a2a'); }
    else dmgText(b.x + rnd(-15, 15), b.y - b.r - 10, v, '#ffd25a', hit.crit);
    if (b.hp <= 0) bossDefeated(b);
    return true;
  }
  function bossPartDestroyed(b) {
    if (!b.shield) return;
    const left = b.shieldT > 0 && G.enemies.some(o => o.bossPart === b && !o.dead);
    if (left) return;
    b.shield = false; b.stunT = 2.8;
    showBanner('Щит разбит!', 'Бей, пока он оглушён!');
    Sound.sfx.glass(); G.shake = 12; burst(b.x, b.y, 40, '#bfeaff', 300);
    speak(b.kind, 'Мои зеркала!!! Это был эксклюзивный декор! 😱');
  }
  // звезда – за каждого босса, один раз навсегда
  function awardStar(b) {
    if (typeof CHN !== 'number') return;
    const prof = loadProfile(); prof.starsGot = prof.starsGot || {};
    const key = CHN + ':' + b.id;
    if (prof.starsGot[key]) return;
    prof.starsGot[key] = 1; prof.stars = Object.keys(prof.starsGot).length; saveProfile(prof);
    setTimeout(() => { floatText(P.x, P.y - 64, '⭐ +1 звезда для талантов!', '#ffd25a', true); Sound.sfx.superReady(); }, 1400);
    if (G.st) G.st.stars = (G.st.stars || 0) + 1;
  }
  function bossDefeated(b) {
    if (G.st && G.st.cur) { const c = G.st.cur; G.st.bosses.push({ k: c.k, n: c.n, pl: c.pl, bl: c.bl, t: Math.round(G.st.time - c.t0), d: c.d, h: c.h || 0, df: c.df || G.diffId }); G.st.cur = null; }
    b.state = 'dead'; b.hp = 0; G.defeated[b.id] = true; G.activeBoss = null; G.invertT = 0; G.staticT = 0;
    G.hazards.length = 0; G.ebullets.length = 0; G.beams.length = 0;
    for (const e of G.enemies) if (e.minion) killEnemy(e, true);
    burst(b.x, b.y, 80, '#ffd25a', 400); burst(b.x, b.y, 50, '#ff7a2f', 280); shockRing(b.x, b.y, '#ffd25a', 400);
    G.shake = 20; Sound.sfx.boom(); Sound.sfx.win(); buzz(160);
    speak(b.kind, b.def.lines.death, 4);
    life('bosses'); bookKill('b', b.kind); if (!G.bossHurt) life('noHit'); dailyAdd(500);
    if (!P.down && P.hp > 0 && P.hp < P.maxHp * 0.05) lifeMax('clutch', 1);
    if (b.final && !G.bossHurt && G.diffId === 'hard' && typeof CHN === 'number' && CHN >= 5 && !CFG.rush && !CFG.abyss) lifeMax('untouch', 1);
    const nG = 24, gemV = xpFor(b.E) * 3.2 * xpGap(P.level, b.E) / nG * (G.td ? 0.12 : 1); // в обороне опыт идёт от волн, страж не должен разом поднимать на десяток уровней
    for (let i = 0; i < nG; i++) dropGem(b.x + rnd(-70, 70), b.y + rnd(-70, 70), gemV);
    for (let i = 0; i < 8 + b.id * 2; i++) dropShard(b.x + rnd(-60, 60), b.y + rnd(-60, 60));
    dropPickup(b.x + 30, b.y, 'heart'); dropPickup(b.x - 30, b.y, 'heart'); dropPickup(b.x, b.y + 30, 'magnet'); if (!b.final && !CFG.rush && !CFG.abyss) dropPickup(b.x - 50, b.y + 20, 'key');
    G.cp = { x: b.hx, y: b.hy };
    if (CFG.abyss) { abyssBossDown(b); return; }
    if (CFG.rush) { rushBossDown(b); return; }
    awardStar(b);
    if (!b.final && talent('heal')) {
      P.hp = P.maxHp; if (G.team) for (const id of G.team.list) { G.team.f[id] = 1; G.team.ko[id] = false; }
      floatText(P.x, P.y - 70, '🩹 Передышка: здоровье полное', '#7dff9a', true);
    }
    if (!b.final && b.calmBiome >= 0 && G.calm[b.calmBiome] === undefined) {
      G.calm[b.calmBiome] = 0;
      setTimeout(() => { if (state === 'play' && !G.activeBoss) showBanner('🕊️ Усмирение I', 'Враги тут слабее на 10%. Охоться здесь – до −30% и награды'); }, 5000);
    }
    if (!b.final) {
      setTimeout(() => { if (state === 'play') showBanner('Страж повержен!', b.name); }, 300);
      const done = guardiansDone(), total = guardiansCount();
      if (done >= total && !gateOpen) {
        gateOpen = true;
        say(CHN === 1 ? 'Все стражи побеждены! Ворота замка открыты – спаси меня!' : CFG.gateSay || 'Все стражи пали! Ворота Кринж-Цитадели открыты! Скорее!!!');
        setTimeout(() => { if (state === 'play') { showBanner('Ворота открыты!', CHN === 1 ? 'Тёмный замок ждёт' : CFG.gateBanner || 'Кринж-Цитадель ждёт'); Sound.sfx.gate(); } }, 3000);
        if (CFG.detective) G.boardPending = true;
      } else say(`Осталось стражей: ${total - done}. Иди по стрелке!`);
      biomeMusic(true);
      saveGame();
    } else startVictoryCutscene();
  }

  // ------------------------------------------------------------------
  //  Игрок
  // ------------------------------------------------------------------
  function hurtPlayer(dmg, sx, sy) {
    if (P.down || P.inv > 0 || P.dashT > 0 || state !== 'play' || G.cutscene) return;
    if (P.shieldLv && P.shieldT <= 0) {
      P.shieldT = P.shieldCd; P.inv = 0.5;
      floatText(P.x, P.y - 36, 'БЛОК!', '#7fe8ff', true); shockRing(P.x, P.y, '#7fe8ff', 70); Sound.sfx.block();
      if (lv('evAegis')) { G.novas.push({ x: P.x, y: P.y, r: 10, max: 230, hit: new Set(), k: 3, star: true }); shockRing(P.x, P.y, '#9ad8ff', 230); }
      return;
    }
    if (hasRelic('guard') && (G.guardT || 0) <= 0) { G.guardT = 12 - 2 * relicLv('guard'); P.inv = 0.5; floatText(P.x, P.y - 36, '🛡️ БЛОК!', '#ffd25a', true); shockRing(P.x, P.y, '#ffd25a', 70); Sound.sfx.block(); return; }
    if (hasRelic('mirror') && Math.random() < 0.08 + 0.045 * relicLv('mirror')) { P.inv = 0.3; floatText(P.x, P.y - 36, '🪞 мимо!', '#bfeaff', true); return; }
    const d = dmg * (1 - P.armor) * (G.ev && G.ev.def.id === 'rage' ? 1.3 : 1) * (hasRelic('crown') ? 1.15 : 1);
    P.hp -= d; P.inv = 0.6; buzz(d > P.maxHp * 0.15 ? 70 : 35);
    if (G.activeBoss) G.bossHurt = true;
    if (G.st) G.st.dmgTaken += d; G.shake = Math.max(G.shake, 7); G.hurtFlash = 0.35;
    dmgText(P.x, P.y - 30, d, '#ff5b5b');
    Sound.sfx.hurt();
    if (sx !== undefined) { const a = Math.atan2(P.y - sy, P.x - sx); moveEntity(P, Math.cos(a) * 14, Math.sin(a) * 14); }
    G.combo = 0;
    if (P.hp <= 0) {
      if (G.team && teamCatch()) { /* вторая героиня в строю */ }
      else if (hasRelic('phoenix') && !G.phoenixUsed) {
        G.phoenixUsed = true; P.hp = Math.round(P.maxHp * (0.25 + 0.25 * relicLv('phoenix'))); P.inv = relicLv('phoenix') >= 3 ? 3.5 : 2.5;
        showBanner('🪶 Перо феникса!', 'Ты возродилась из пепла'); burst(P.x, P.y, 40, '#ff8a2a', 260); Sound.sfx.magic();
      } else if (talent('second') && !G.secondUsed) {
        G.secondUsed = true; P.hp = Math.round(P.maxHp * (0.25 + 0.15 * Math.min(3, talent('second')))); P.inv = 2.5;
        showBanner('🕊️ Второе дыхание!', 'Звёзды не дали тебе упасть'); burst(P.x, P.y, 40, '#bfeaff', 260); Sound.sfx.magic(); buzz(120);
      } else if (G.td) defDown(); // в обороне героиня отдохнёт у кристалла и вернётся
      else if (P.lives > 1 && !CFG.rush) loseLife(); else if (NET.on && G.netRun) netDown(); else { P.hp = 0; playerDied(); }
    }
    else if (P.hp < P.maxHp * 0.3 && !G.lowHpSaid) { G.lowHpSaid = true; say('Осторожно! Собирай сердечки, чтобы подлечиться!'); }
  }
  function gainXp(v) {
    if (G.ev && G.ev.def.id === 'gold') v *= 2; else if (G.ev && G.ev.def.id === 'rage') v *= 1.5;
    v *= 1 + 0.08 * talent('xp');
    if (weekEv('xp')) v *= 1.3;
    P.xp += v;
    while (P.xp >= P.xpNext) { P.xp -= P.xpNext; P.level++; P.xpNext = xpFor(P.level); G.pendingLv++; }
    if (G.pendingLv > 0 && state === 'play' && !G.cutscene) openLevelUp();
  }
  function tryDash() {
    if (state !== 'play' || P.dashCd > 0 || G.cutscene) return;
    let dx = input.mx, dy = input.my;
    if (G.invertT > 0) { dx = -dx; dy = -dy; }
    if (Math.hypot(dx, dy) < 0.1) { dx = P.face; dy = 0; }
    const m = Math.hypot(dx, dy); dx /= m; dy /= m;
    P.dashCd = P.dashCdMax;
    if (G.st) G.st.dashes++;
    if (P.up.c3glitch) P.inv = Math.max(P.inv, 0.2 + 0.3 * P.up.c3glitch);
    if (HEROES[P.hero].blink) {
      const sx = P.x, sy = P.y;
      for (let k = 0; k < 15; k++) {
        const nx = P.x + dx * 10, ny = P.y + dy * 10;
        if (isSolidTile(Math.floor(nx / T), Math.floor(ny / T), false)) break;
        P.x = nx; P.y = ny;
      }
      collide(P);
      P.inv = Math.max(P.inv, 0.35);
      for (let k = 0; k <= 3; k++) G.pzones.push({ x: lerp(sx, P.x, k / 3), y: lerp(sy, P.y, k / 3), r: 30, t: 0, dur: 1.6, tick: 0, dmg: P.dmg * (lv('evComet') ? 1.6 : 0.8) });
      burst(sx, sy, 14, '#ff8a2a', 160); burst(P.x, P.y, 18, '#ffd23a', 200);
      Sound.sfx.blink();
    } else {
      P.dashX = dx; P.dashY = dy; P.dashT = 0.2;
      if (HEROES[P.hero].pounce) { P.pounce = true; Sound.sfx.pounce(); } else Sound.sfx.dash();
    }
  }
  function addSuper(v) {
    if (P.sp >= 100 || G.cutscene) return;
    P.sp = Math.min(100, P.sp + v * (P.superGain || 1));
    if (P.sp >= 100) { Sound.sfx.superReady(); floatText(P.x, P.y - 46, 'СУПЕР ГОТОВ!', '#ffd25a', true); }
  }
  function trySuper() {
    if (state !== 'play' || P.sp < 100 || G.cutscene) return;
    P.sp = 0; buzz(80); life('supers');
    if (G.st) G.st.supers++;
    for (const bl of G.ebullets) if ((bl.x - P.x) ** 2 + (bl.y - P.y) ** 2 < 220 * 220) bl.life = 0;
    const H = HEROES[P.hero];
    if (G.team) {
      showBanner('ДРУЖБА-СУПЕР!', 'Перьевой ураган + Огненная ярость');
      P.stormT = 2.6; P.stormE = 0; G.novas.push({ x: P.x, y: P.y, r: 10, max: 470, hit: new Set() });
      P.inv = Math.max(P.inv, 1.4); Sound.sfx.magic(); Sound.sfx.nova(); G.shake = 14;
      return;
    }
    showBanner(H.superName + '!', '');
    if (H.super === 'storm') { P.stormT = 2.6; P.stormE = 0; P.inv = Math.max(P.inv, 1.3); Sound.sfx.magic(); Sound.sfx.dash(); }
    else if (H.super === 'purr') {
      const heal = Math.round(P.maxHp * 0.25); P.hp = Math.min(P.maxHp, P.hp + heal); floatText(P.x, P.y - 40, '+' + heal, '#7dff7d', true);
      G.novas.push({ x: P.x, y: P.y, r: 10, max: 420, hit: new Set(), purr: true }); P.inv = Math.max(P.inv, 1.1); Sound.sfx.purr();
    }
    else { G.novas.push({ x: P.x, y: P.y, r: 10, max: 470, hit: new Set() }); P.inv = Math.max(P.inv, 1.1); Sound.sfx.nova(); }
    G.shake = 14;
    if (lv('evNova')) G.evNovaT = 1.4; // сверхновая – в конце супера
  }
  // периодические эволюции: грозовой вихрь, метеориты, сверхновая
  function evoTick(dt) {
    if (G.bloodT > 0) G.bloodT -= dt;
    if (lv('evStorm') && P.orbit) {
      G.evStormT = (G.evStormT || 0) - dt;
      if (G.evStormT <= 0) {
        G.evStormT = 1.2; let any = false;
        for (let k = 0; k < Math.min(P.orbit, 6); k++) {
          const a = P.orbA + (k / P.orbit) * TAU, ox2 = P.x + Math.cos(a) * 62, oy2 = P.y + Math.sin(a) * 62;
          let best = null, bd = 190 * 190;
          for (const e of G.enemies) { if (e.dead || e.spawnT > 0) continue; const d = (e.x - ox2) ** 2 + (e.y - oy2) ** 2; if (d < bd) { bd = d; best = e; } }
          const bb = G.activeBoss; if (!best && bb && bb.state === 'fight' && !bb.inv && (bb.x - ox2) ** 2 + (bb.y - oy2) ** 2 < (190 + bb.r) ** 2) best = bb;
          if (best) { any = true; G.bolts.push({ pts: [[ox2, oy2], [best.x, best.y - (best.z || 0)]], t: 0.18, col: '190,230,255' }); hitAny(best, rollHit(P.dmg * 1.1), 0, 0, false); }
        }
        if (any) Sound.sfx.bolt();
      }
    }
    if (lv('evMeteor')) {
      G.evMetT = (G.evMetT === undefined ? 2 : G.evMetT) - dt;
      if (G.evMetT <= 0) {
        G.evMetT = 4;
        const cands = G.enemies.filter(e => !e.dead && e.spawnT <= 0 && (e.x - P.x) ** 2 + (e.y - P.y) ** 2 < (P.range * 1.3) ** 2);
        if (G.activeBoss && G.activeBoss.state === 'fight' && !G.activeBoss.inv) cands.push(G.activeBoss);
        for (let k = 0; k < 3 && cands.length; k++) { const t = cands.splice(Math.floor(Math.random() * cands.length), 1)[0]; starfall(t.x, t.y - (t.z || 0), 2.5, '#ff9a3a', '☄️'); }
      }
    }
    if (G.evNovaT > 0) {
      G.evNovaT -= dt;
      if (G.evNovaT <= 0) { G.novas.push({ x: P.x, y: P.y, r: 10, max: 380, hit: new Set(), k: 6, star: true }); shockRing(P.x, P.y, '#fff3a0', 380); burst(P.x, P.y, 40, '#fff3a0', 300); Sound.sfx.nova(); G.shake = Math.max(G.shake, 12); }
    }
  }
  function nearestTarget(range) {
    let best = null, bd = range * range;
    for (const e of G.enemies) {
      if (e.dead || e.spawnT > 0) continue;
      let d = (e.x - P.x) ** 2 + (e.y - P.y) ** 2;
      if (d > range * range) continue;
      if (e.def.ai === 'healer') d *= 0.6; // лекарей бьём первыми
      if (d < bd) { bd = d; best = e; }
    }
    const b = G.activeBoss;
    if (b && b.state === 'fight' && b.alpha > 0.3 && b.z < 30 && !b.inv && !b.shield) {
      const d = (b.x - P.x) ** 2 + (b.y - P.y) ** 2;
      if (d < (range + b.r) ** 2 && (!best || bd > 85 * 85 || d < bd * 2.5)) best = b;
    }
    return best;
  }
  function hitAny(tg, hit, kx, ky, fromFeather) {
    if (tg.kind) return damageBoss(tg, hit);
    return damageEnemy(tg, hit, kx, ky, fromFeather);
  }
  function onProjHit(f, tg) {
    if (f.kind === 'fire') {
      const R = P.splash || 38;
      for (const e of G.enemies) {
        if (e === tg || e.dead || e.spawnT > 0) continue;
        if ((e.x - f.x) ** 2 + (e.y - f.y) ** 2 < (R + e.r) ** 2) damageEnemy(e, { v: f.dmg * 0.5, crit: false }, 0, 0, false);
      }
      G.rings.push({ x: f.x, y: f.y, r: 6, max: R, col: '#ff8a2a', t: 0 });
      burst(f.x, f.y, 6, '#ffb03a', 120);
      if (tg && !tg.dead) { tg.burnT = 2; tg.burnDps = Math.max(tg.burnDps || 0, f.dmg * (P.burn || 0.35)); tg.burnTick = tg.burnTick || 0.4; }
    } else if (P.explode) featherExplode(f.x, f.y, f.dmg, tg && !tg.kind ? tg : null);
  }
  function featherExplode(x, y, dmg, skip) {
    const R = 40 + 12 * P.explode;
    for (const e of G.enemies) {
      if (e === skip || e.dead || e.spawnT > 0) continue;
      if ((e.x - x) ** 2 + (e.y - y) ** 2 < (R + e.r) ** 2) damageEnemy(e, { v: dmg * 0.35, crit: false }, 0, 0, false);
    }
    G.rings.push({ x, y, r: 6, max: R, col: '#ffb03a', t: 0 });
  }

  function updatePlayer(dt) {
    P.t += dt;
    if (state === 'dying') return;
    if (P.inv > 0) P.inv -= dt;
    if (P.dashCd > 0) P.dashCd -= dt;
    if (P.slowT > 0) P.slowT -= dt;
    if (P.shieldLv && P.shieldT > 0) P.shieldT -= dt;
    if (P.down) { P.moving = false; P.vx = 0; P.vy = 0; return; } // без сил – ждём, пока поднимут
    if (P.regen && P.hp < P.maxHp) P.hp = Math.min(P.maxHp, P.hp + P.regen * dt);
    let mx = input.mx, my = input.my;
    if (G.invertT > 0) { mx = -mx; my = -my; }
    if (P.napT > 0) P.napT -= dt;
    const m = Math.hypot(mx, my);
    if (m > 1) { mx /= m; my /= m; }
    P.moving = m > 0.08;
    const ox = P.x, oy = P.y;
    const spd = P.speed * (P.slowT > 0 ? 0.55 : 1) * (G.blizzardT > 0 && !G.nearFire && !lv('c6warm') ? 0.9 : 1);
    const onIce = CFG.slippery && tileAt(Math.floor(P.x / T), Math.floor(P.y / T)) === ICE;
    if (P.dashT > 0) {
      P.dashT -= dt;
      moveEntity(P, P.dashX * P.speed * 3.3 * dt, P.dashY * P.speed * 3.3 * dt);
      P.ivx = P.dashX * P.speed * 1.3; P.ivy = P.dashY * P.speed * 1.3;
      part(P.x + rnd(-6, 6), P.y + rnd(-10, 6), 0, 0, 0.35, 5, 'rgba(160,225,255,0.8)');
      if (Math.abs(P.dashX) > 0.2) P.face = P.dashX > 0 ? 1 : -1;
      if (P.dashT <= 0 && P.pounce) { P.pounce = false; pounceHit(); }
      if (lv('evComet')) { G.cometT = (G.cometT || 0) - dt; if (G.cometT <= 0) { G.cometT = 0.04; G.pzones.push({ x: P.x, y: P.y, r: 28, t: 0, dur: 1.4, tick: 0, dmg: P.dmg * 0.9 }); } }
    } else if (onIce) {
      // лёд: разгон и торможение с инерцией
      const k = Math.min(1, dt * 2.4);
      const isp = CFG.iceSpeed || 1.15;
      P.ivx = (P.ivx || 0) + ((P.moving ? mx * spd * isp : 0) - (P.ivx || 0)) * k;
      P.ivy = (P.ivy || 0) + ((P.moving ? my * spd * isp : 0) - (P.ivy || 0)) * k;
      moveEntity(P, P.ivx * dt, P.ivy * dt);
      if (dt > 0) { P.ivx = (P.x - ox) / dt; P.ivy = (P.y - oy) / dt; }
      if (P.moving && Math.abs(mx) > 0.15) P.face = mx > 0 ? 1 : -1;
      if (Math.hypot(P.ivx, P.ivy) > 70 && Math.random() < 0.3) part(P.x + rnd(-6, 6), P.y + 10, -P.ivx * 0.1, -10, 0.4, 3, 'rgba(230,248,255,0.9)');
    } else if (P.moving) {
      moveEntity(P, mx * spd * dt, my * spd * dt);
      if (Math.abs(mx) > 0.15) P.face = mx > 0 ? 1 : -1;
      P.ivx = mx * spd; P.ivy = my * spd;
    } else { P.ivx = 0; P.ivy = 0; }
    if (dt > 0) { P.vx = lerp(P.vx, (P.x - ox) / dt, 0.3); P.vy = lerp(P.vy, (P.y - oy) / dt, 0.3); }
    // супер Крилессы: перьевой ураган
    if (P.stormT > 0) {
      P.stormT -= dt; P.stormE -= dt;
      if (P.stormE <= 0) {
        P.stormE = 0.07;
        for (let k = 0; k < 5; k++) {
          const a = P.t * 4 + (k / 5) * TAU;
          G.feathers.push({ x: P.x, y: P.y - 8, vx: Math.cos(a) * 520, vy: Math.sin(a) * 520, dmg: P.dmg * 0.9, pierce: 2, life: 0.9, hit: [], kind: 'feather' });
        }
      }
    }
    // перья
    P.fireT -= dt;
    if (P.fireT <= 0 && !G.hidden && !G.jump) {
      P.volley = (P.volley || 0) + 1;
      let tg = nearestTarget(P.range);
      // каждый второй залп – в босса, даже если вокруг толпа миньонов
      const bb = G.activeBoss;
      if (bb && P.volley % 2 === 0 && bb.state === 'fight' && !bb.inv && !bb.shield && bb.alpha > 0.3 && bb.z < 30 &&
        (bb.x - P.x) ** 2 + (bb.y - P.y) ** 2 < (P.range + bb.r) ** 2) tg = bb;
      if (!tg && CFG.icedChests && (P.proj === 'fire' || lv('c6ice'))) tg = iceTarget();
      if (!tg && secrets.length) tg = crackTarget();
      if (tg) {
        const base = Math.atan2(tg.y - (tg.z || 0) - P.y, tg.x - P.x);
        for (let i = 0; i < P.shots; i++) {
          const a = base + (i - (P.shots - 1) / 2) * 0.16;
          const life = (P.range / P.projSpd) * 1.35;
          G.feathers.push({ x: P.x, y: P.y - 8, vx: Math.cos(a) * P.projSpd, vy: Math.sin(a) * P.projSpd, dmg: P.dmg, pierce: P.pierce, life, life0: life, hit: [], kind: P.proj });
        }
        if (P.up.c3twin && Math.random() < 0.1 * P.up.c3twin) {
          const life = (P.range / P.projSpd) * 1.35;
          for (let i = 0; i < P.shots; i++) {
            const a = base + (i - (P.shots - 1) / 2) * 0.16 + 0.09;
            G.feathers.push({ x: P.x, y: P.y - 8, vx: Math.cos(a) * P.projSpd, vy: Math.sin(a) * P.projSpd, dmg: P.dmg, pierce: P.pierce, life, life0: life, hit: [], kind: P.proj, twin: true });
          }
        }
        if (P.proj === 'fire') Sound.sfx.fireball(); else if (P.proj === 'claw') Sound.sfx.claw(); else Sound.sfx.shoot();
        if (lv('evHurricane') && P.volley % 6 === 0) { // ураган: кольцо снарядов
          const life = (P.range / P.projSpd) * 1.1;
          for (let k = 0; k < 16; k++) { const a = k * TAU / 16; G.feathers.push({ x: P.x, y: P.y - 8, vx: Math.cos(a) * P.projSpd, vy: Math.sin(a) * P.projSpd, dmg: P.dmg * 0.7, pierce: P.pierce, life, life0: life, hit: [], kind: P.proj }); }
        }
        if (talent('starfall') && P.volley % [12, 10, 8][Math.min(3, talent('starfall')) - 1] === 0) starfall(tg.x, tg.y - (tg.z || 0));
        P.fireT = P.fireInt;
      } else P.fireT = 0.1;
    }
    if (P.up.c2disco) {
      P.discoT = (P.discoT === undefined ? 6 : P.discoT) - dt;
      if (P.discoT <= 0 && !G.cutscene) { P.discoT = 6; G.novas.push({ x: P.x, y: P.y, r: 10, max: 150 + 25 * P.up.c2disco, hit: new Set(), k: 0.8 * P.up.c2disco, disco: true }); }
    }
    // вихрь
    if (P.orbit) {
      P.orbA += dt * 3.2;
      for (let k = 0; k < P.orbit; k++) {
        const a = P.orbA + (k / P.orbit) * TAU, ox2 = P.x + Math.cos(a) * 62, oy2 = P.y + Math.sin(a) * 62;
        for (const e of G.enemies) {
          if (e.dead || e.orbCd > 0 || e.spawnT > 0) continue;
          if ((e.x - ox2) ** 2 + (e.y - oy2) ** 2 < (e.r + 10) ** 2) { e.orbCd = 0.35; damageEnemy(e, rollHit(P.dmg * 0.7), Math.cos(a) * 120, Math.sin(a) * 120, false); }
        }
        const b = G.activeBoss;
        if (b && (b.x - ox2) ** 2 + (b.y - oy2) ** 2 < (b.r + 10) ** 2 && b.orbCd <= 0) { b.orbCd = 0.3; damageBoss(b, rollHit(P.dmg * 0.7)); }
      }
    }
    // молния
    if (P.bolt) {
      P.boltT -= dt;
      if (P.boltT <= 0) {
        P.boltT = Math.max(1.0, 2.8 - P.bolt * 0.28);
        const cands = G.enemies.filter(e => !e.dead && e.spawnT <= 0 && (e.x - P.x) ** 2 + (e.y - P.y) ** 2 < (P.range * 1.3) ** 2);
        if (G.activeBoss && G.activeBoss.state === 'fight' && !G.activeBoss.inv) cands.push(G.activeBoss);
        if (cands.length) {
          let cur = pick(cands); const pts = [[P.x, P.y - 20]]; const used = new Set();
          for (let k = 0; k <= P.bolt; k++) {
            if (!cur) break;
            used.add(cur); pts.push([cur.x, cur.y]);
            hitAny(cur, rollHit(P.dmg * 1.6), 0, 0, false);
            let nb = null, nd = 160 * 160;
            for (const e of cands) { if (used.has(e) || e.dead) continue; const d = (e.x - cur.x) ** 2 + (e.y - cur.y) ** 2; if (d < nd) { nd = d; nb = e; } }
            cur = nb;
          }
          G.bolts.push({ pts, t: 0.25 });
          Sound.sfx.bolt();
        }
      }
    }
    evoTick(dt);
  }

  // ------------------------------------------------------------------
  //  Мир: спавн, снаряды, опасности, подбор
  // ------------------------------------------------------------------
  function spawnEnemies(dt) {
    G.spawnT -= dt;
    if (G.spawnT > 0) return;
    G.spawnT = CFG.spawnEvery * 0.8 * (G.ev && G.ev.def.id === 'horde' ? 0.35 : 1);
    if (G.activeShrine || CFG.rush || CFG.abyss || G.finalFinal) return;
    // вместе: мобы появляются то у одной, то у другой героини
    let A = P;
    if (NET.host && NET.peers.size) { const L = [P].concat([...NET.peers.values()].filter(m => m.live && !m.down)).filter(q => !q.down); A = L[Math.floor(Math.random() * L.length)] || P; }
    const ptx = Math.floor(A.x / T), pty = Math.floor(A.y / T);
    if (Math.hypot(ptx - START.x, pty - START.y) < 7) return;
    const pb = biomeMap[clamp(pty, 0, MH - 1) * MW + clamp(ptx, 0, MW - 1)];
    const zi = Math.max(0, Object.keys(CFG.zoneLevel).indexOf(String(pb)));
    let cap = CFG.capBase * 1.3 + zi * 2 + Math.min(8, Math.max(0, P.level - zoneE(pb)) * 0.3);
    if (CHN !== 1) cap *= clamp(0.5 + P.level * 0.035, 0.5, 1); // глава начинается с 1 уровня – толпа нарастает постепенно
    if (G.activeBoss) return;
    if (G.ev && G.ev.def.id === 'horde') cap *= 1.8;
    cap *= netXpDiv(); // вместе мобов больше (опыт с них – во столько же раз меньше)
    if (G.enemies.length >= cap) return;
    const vw = VW / ZOOM, vh = VH / ZOOM;
    const inCastle = Math.abs(ptx - CASTLE.x) < CASTLE.half && Math.abs(pty - CASTLE.y) < CASTLE.half;
    for (let k = 0; k < 8; k++) {
      const R = inCastle ? rnd(240, 420) : Math.hypot(vw, vh) / 2 + 50;
      const a = rnd(0, TAU), x = A.x + Math.cos(a) * R, y = A.y + Math.sin(a) * R;
      const tx = Math.floor(x / T), ty = Math.floor(y / T);
      if (!inMap(tx, ty) || ty >= PLAY_H) continue; // ниже карты – пустота и арена
      if (inCastle && tiles[ty * MW + tx] !== FLOOR) continue;
      const biome = inCastle ? CASTLE.biome : biomeMap[ty * MW + tx];
      if (!SPAWNS[biome]) continue;
      const type = weighted(SPAWNS[biome]);
      if (!walkable(x, y, ENEMIES[type].fly)) continue;
      if (bosses.some(b => b.state === 'sleep' && Math.hypot(x - b.hx, y - b.hy) < 300)) continue;
      const elite = Math.random() < CFG.elite * G.diff.elite * (0.35 + 0.65 * chDiff(zoneE(biome)).k) * (mutOn('elite') ? 3 : 1); // элита в начале главы реже
      spawnEnemy(type, x, y, biome, { elite, instant: !inCastle });
      const grp = ENEMIES[type].group;
      if (grp) { const n = grp[0] + Math.floor(Math.random() * (grp[1] - grp[0] + 1)) - 1; for (let i = 0; i < n; i++) spawnEnemy(type, x + rnd(-30, 30), y + rnd(-30, 30), biome, { instant: !inCastle }); }
      return;
    }
  }
  function updateProjectiles(dt) {
    for (const f of G.feathers) {
      f.x += f.vx * dt; f.y += f.vy * dt; f.life -= dt;
      if (blocksShots(f.x, f.y)) { f.life = 0; burst(f.x, f.y, 3, '#fff', 60); if (!tryCrack(f) && CFG.slippery) tryMelt(f); continue; }
      if (drifts.length && !f.ally && hitDrift(f)) continue;
      for (const e of G.enemies) {
        if (e.dead || e.spawnT > 0 || f.hit.includes(e)) continue;
        if ((e.x - f.x) ** 2 + (e.y - f.y) ** 2 < (e.r + 5) ** 2) {
          f.hit.push(e);
          if (e.def.ai === 'shield' && Math.abs(angDiff(e.shieldAng, Math.atan2(f.y - e.y, f.x - e.x))) < 1.05) {
            f.life = 0; burst(f.x, f.y, 6, '#bfefff', 120); if (Math.random() < 0.3) floatText(e.x, e.y - e.r - 8, 'блок', '#bfefff'); Sound.sfx.block(); break;
          }
          damageEnemy(e, rollHit(f.dmg), f.vx * 0.25, f.vy * 0.25, true);
          onProjHit(f, e);
          if (f.pierce-- <= 0) { f.life = 0; break; }
        }
      }
      const b = G.activeBoss;
      if (f.life > 0 && b && !f.hit.includes(b) && (b.x - f.x) ** 2 + (b.y - b.z - f.y) ** 2 < (b.r + 5) ** 2) {
        f.hit.push(b);
        if (damageBoss(b, rollHit(f.dmg))) { Sound.sfx.hit(); burst(f.x, f.y, 4, '#ffd25a', 90); onProjHit(f, b); }
        else if (b.def.immortal && G.finalFinal && !f.ally) { G.finalFinal.bank = Math.min(0.5, G.finalFinal.bank + 0.1); burst(f.x, f.y, 3, '#ff8ad8', 70); }
        if (f.pierce-- <= 0) f.life = 0;
      }
    }
    G.feathers = G.feathers.filter(f => f.life > 0);
    for (const b of G.ebullets) {
      if (b.homing) {
        const Q = NET.host ? netAim(b.x, b.y) : P, want = Math.atan2(Q.y - b.y, Q.x - b.x), cur = Math.atan2(b.vy, b.vx);
        const na = cur + clamp(angDiff(cur, want), -b.homing * dt, b.homing * dt);
        b.vx = Math.cos(na) * b.spd; b.vy = Math.sin(na) * b.spd;
      }
      if (b.bounce) {
        const nx = b.x + b.vx * dt, ny = b.y + b.vy * dt;
        if (blocksShots(nx, b.y) || Math.abs(nx - b.hx) > 430) b.vx = -b.vx;
        if (blocksShots(b.x, ny) || Math.abs(ny - b.hy) > 430) b.vy = -b.vy;
        b.rot += dt * 12;
      }
      if (b.missile && Math.random() < 0.4) part(b.x, b.y, rnd(-10, 10), rnd(-10, 10), 0.5, 4, 'rgba(160,160,160,0.6)');
      b.x += b.vx * dt; b.y += b.vy * dt; b.life -= dt;
      if (!b.bounce && blocksShots(b.x, b.y)) { b.life = 0; shotPuff(b, 3); continue; }
      if (b.life <= 0) { shotPuff(b, 4); if (NET.client) NET.goneB.add(b.nid); continue; } // выдохся – рассеялся облачком
      if (!P.down && b.life > SHOT_FADE * 0.4 && (P.x - b.x) ** 2 + (P.y - 6 - b.y) ** 2 < (b.r + P.r - 3) ** 2) { // почти растаявший уже не ранит
        if (P.inv <= 0 && P.dashT <= 0) { hurtPlayer(b.dmg); if (b.slow) P.slowT = 1.6; b.life = 0; if (NET.client) { NET.bcons.push(b.nid); NET.goneB.add(b.nid); } }
      }
    }
    G.ebullets = G.ebullets.filter(b => b.life > 0);
    // лазеры
    for (const bm of G.beams) {
      bm.t += dt;
      if (bm.b.state !== 'fight' || bm.b.mode === 'trans') { bm.t = 1e9; continue; }
      const o = bm.mouth ? bossMouth(bm.b) : { x: bm.b.x, y: bm.b.y - bm.b.z };
      bm.x = o.x; bm.y = o.y;
      if (bm.t > bm.warm) {
        bm.ang += bm.rot * dt;
        const ca = Math.cos(bm.ang), sa = Math.sin(bm.ang);
        let len = 0;
        for (len = 0; len < 560; len += 20) if (blocksShots(bm.x + ca * len, bm.y + sa * len)) break;
        bm.len = len;
        const dx = P.x - bm.x, dy = P.y - bm.y;
        const along = dx * ca + dy * sa, perp = Math.abs(-dx * sa + dy * ca);
        if (along > 0 && along < bm.len && perp < bm.w / 2 + P.r * 0.4) hurtPlayer(bm.dmg);
      }
    }
    G.beams = G.beams.filter(bm => bm.t < bm.warm + bm.dur);
  }
  function updatePlayerFx(dt) {
    for (const z of G.pzones) {
      z.t += dt; z.tick -= dt;
      if (Math.random() < 0.4) part(z.x + rnd(-z.r, z.r) * 0.6, z.y + rnd(-z.r, z.r) * 0.6, 0, -50, 0.5, 4, pick(['#ff8a2a', '#ffd23a', '#ff4a1a']));
      if (z.tick <= 0) {
        z.tick = 0.35;
        for (const e of G.enemies) if (!e.dead && e.spawnT <= 0 && (e.x - z.x) ** 2 + (e.y - z.y) ** 2 < (z.r + e.r) ** 2) damageEnemy(e, { v: z.dmg, crit: false }, 0, 0, false);
        const b = G.activeBoss;
        if (b && (b.x - z.x) ** 2 + (b.y - z.y) ** 2 < (z.r + b.r) ** 2) damageBoss(b, { v: z.dmg, crit: false }, true);
      }
    }
    G.pzones = G.pzones.filter(z => z.t < z.dur);
    for (const n of G.novas) {
      n.r += (n.disco ? 520 : 900) * dt;
      for (const e of G.enemies) {
        if (e.dead || e.spawnT > 0 || n.hit.has(e)) continue;
        const d = Math.hypot(e.x - n.x, e.y - n.y);
        if (Math.abs(d - n.r) < 36 + e.r) {
          n.hit.add(e);
          if (n.k) damageEnemy(e, rollHit(P.dmg * n.k), (e.x - n.x) / d * 160, (e.y - n.y) / d * 160, false);
          else if (n.purr) { damageEnemy(e, rollHit(P.dmg * 4), (e.x - n.x) / d * 260, (e.y - n.y) / d * 260, false); e.slowT = Math.max(e.slowT || 0, 2.5); }
          else { damageEnemy(e, rollHit(P.dmg * 6), (e.x - n.x) / d * 300, (e.y - n.y) / d * 300, false); e.burnT = 3; e.burnDps = P.dmg * 0.6; }
        }
      }
      const b = G.activeBoss;
      if (b && !n.hit.has(b) && Math.abs(Math.hypot(b.x - n.x, b.y - n.y) - n.r) < 40 + b.r) {
        n.hit.add(b);
        if (n.k) damageBoss(b, rollHit(P.dmg * n.k * 1.5));
        else if (n.purr) { damageBoss(b, rollHit(P.dmg * 9)); if (!b.def.immortal) b.stunT = Math.max(b.stunT, 1.2); }
        else { damageBoss(b, rollHit(P.dmg * 12)); b.burnT = 3; b.burnDps = P.dmg * 0.6; }
      }
      if (!n.disco) for (const bl of G.ebullets) if ((bl.x - n.x) ** 2 + (bl.y - n.y) ** 2 < n.r * n.r) bl.life = 0;
    }
    G.novas = G.novas.filter(n => n.r < n.max);
  }
  const WAVE_GAP = 0.32; // половина прохода в кольце, рад (~37° на проход)
  const inWaveGap = (h, a) => !h.gaps || h.gaps.some(g => Math.abs(angDiff(a, g)) < h.half); // angDiff из util.js – со знаком
  function updateHazards(dt) {
    for (const h of G.hazards) {
      h.t += dt;
      if (h.cancel) { h.t = 1e9; h.r = 1e9; continue; }
      if (h.kind === 'wavewarn') continue;
      if (h.kind === 'wave') {
        h.r += h.spd * dt;
        const d = Math.hypot(P.x - h.x, P.y - h.y);
        if (!h.hit && Math.abs(d - h.r) < h.thick / 2 + P.r * 0.4 && P.inv <= 0 && P.dashT <= 0 && !inWaveGap(h, Math.atan2(P.y - h.y, P.x - h.x))) { hurtPlayer(h.dmg); h.hit = true; }
        continue;
      }
      if (h.kind === 'zone') {
        if (h.t > h.delay && Math.hypot(P.x - h.x, P.y - h.y) < h.r) {
          if (h.slow) P.slowT = Math.max(P.slowT, 0.25);
          if (h.dot) { h.tick = (h.tick || 0) - dt; if (h.tick <= 0) { h.tick = 0.5; hurtPlayer(h.dot); } }
        }
        continue;
      }
      if (!h.done && h.t >= h.delay) {
        h.done = true;
        let hit = false;
        if (h.kind === 'circle') hit = Math.hypot(P.x - h.x, P.y - h.y) < h.r + P.r * 0.5;
        else {
          const dx = P.x - h.x, dy = P.y - h.y, ca = Math.cos(h.ang), sa = Math.sin(h.ang);
          const along = dx * ca + dy * sa, perp = Math.abs(-dx * sa + dy * ca);
          hit = along > -10 && along < h.len && perp < h.w / 2 + P.r * 0.5;
        }
        if (hit && h.dmg && !P.down) hurtPlayer(h.dmg);
        if (h.fx === 'stomp') { burst(h.x, h.y, 26, '#c9a46b', 260); G.shake = Math.max(G.shake, 9); Sound.sfx.boom(); }
        else if (h.fx === 'meteor') {
          burst(h.x, h.y, 26, h.star ? '#9fb4ff' : '#ff8a2a', 260); burst(h.x, h.y, 10, '#ffd23a', 160); G.shake = Math.max(G.shake, 6); Sound.sfx.meteor();
          if (!NET.client && !h.td) { // звездопад обороны бьёт сам – по своим правилам
            if (h.star && walkable(h.x, h.y, false)) dropShard(h.x, h.y);
            for (const e of G.enemies) if (!e.dead && e.spawnT <= 0 && (e.x - h.x) ** 2 + (e.y - h.y) ** 2 < (h.r + e.r) ** 2) damageEnemy(e, { v: P.dmg * 4, crit: false }, 0, 0, false);
          }
        }
        else if (h.fx === 'icicle') { burst(h.x, h.y, 14, '#bfefff', 200); Sound.sfx.hit(); }
        else if (h.fx === 'dark') burst(h.x, h.y, 16, '#c77dff', 200);
        else if (h.fx === 'crystal') burst(h.x, h.y, 16, '#5be3ff', 200);
        else if (h.fx === 'rain') burst(h.x, h.y, 12, '#ffffff', 160);
        else if (h.fx === 'boom') { burst(h.x, h.y, 30, '#ff8a2a', 280); G.shake = Math.max(G.shake, 8); }
        else if (h.fx === 'bolt') { G.bolts.push({ pts: [[h.x + rnd(-30, 30), h.y - 340], [h.x, h.y]], t: 0.3, col: '255,240,120' }); burst(h.x, h.y, 14, '#fff04a', 200); Sound.sfx.bolt(); }
        else if (h.fx === 'glitch') { burst(h.x, h.y, 18, '#3ff0a0', 220); burst(h.x, h.y, 10, '#ff3ea5', 180); }
        else if (h.fx === 'erupt') {
          burst(h.x, h.y, 22, '#ff6a22', 260);
          if (!NET.client) G.hazards.push({ kind: 'zone', x: h.x, y: h.y, r: 46, t: 0, delay: 0, dur: 2.6, dot: h.dmg * 0.25, fx: 'lava' });
        }
      }
    }
    G.hazards = G.hazards.filter(h => {
      if (h.kind === 'wave') return h.r < h.max;
      if (h.kind === 'zone') return h.t < h.delay + h.dur;
      return h.t < h.delay + 0.3;
    });
  }
  function updatePickups(dt) {
    for (const p of G.pickups) {
      p.t += dt;
      // вместе: подбирашка летит к ближайшей героине
      let Q = P;
      if (NET.host && NET.peers.size) { let bd = P.down ? 1e18 : (P.x - p.x) ** 2 + (P.y - p.y) ** 2; for (const m of NET.peers.values()) { if (!m.live || m.down || m.away) continue; const d2 = (m.x - p.x) ** 2 + (m.y - p.y) ** 2; if (d2 < bd) { bd = d2; Q = m; } } if (Q === P && P.down) continue; }
      const dx = Q.x - p.x, dy = Q.y - p.y, d = Math.hypot(dx, dy) || 1, mag = Q === P ? P.magnet : (Q.mag || 110);
      if (d < mag || p.pull || (G.td && p.kind === 'xp' && p.t > 0.7)) { // в обороне опыт сам летит к героине через всё поле
        p.pull = true;
        const s = 260 + p.t * 120;
        p.x += (dx / d) * Math.min(d, s * dt); p.y += (dy / d) * Math.min(d, s * dt);
      }
      if (Q !== P && d < (Q.r || 13) + 8) { // подобрала подруга
        p.got = true;
        if (p.kind === 'xp') { gainXp(p.v); netEvent(Q.id, ['gem']); }
        else if (p.kind === 'heart') netEvent(Q.id, ['hl']);
        else if (p.kind === 'star') netEvent(Q.id, ['sp', 10]);
        else if (p.kind === 'key') { G.keys = (G.keys || 0) + 1; netEvent(Q.id, ['key']); floatText(P.x, P.y - 34, '🔑 +1 (общий)', '#ffd25a'); }
        else if (p.kind === 'magnet') { for (const q of G.pickups) if (q.kind !== 'heart') q.pull = true; }
        else if (p.kind === 'shard') netEvent(Q.id, ['sh', p.sid]);
        continue;
      }
      if (Q === P && d < P.r + 8) {
        p.got = true;
        if (p.kind === 'xp') { gainXp(p.v); Sound.sfx.gem(); }
        else if (p.kind === 'heart') { const h = Math.round(P.maxHp * 0.25 * (hasRelic('heartstone') ? 1.25 + 0.25 * relicLv('heartstone') : 1) * (1 + 0.2 * lv('c5snack'))), gain = Math.max(0, Math.min(h, P.maxHp - P.hp)); if (G.st) { G.st.hearts = (G.st.hearts || 0) + 1; G.st.healed = (G.st.healed || 0) + (isFinite(gain) ? gain : 0); if (G.st.cur) G.st.cur.h = (G.st.cur.h || 0) + 1; } P.hp = Math.min(P.maxHp, P.hp + h); floatText(P.x, P.y - 34, '+' + h, '#7dff7d'); Sound.sfx.heart(); }
        else if (p.kind === 'star') { addSuper(10); floatText(P.x, P.y - 34, '⭐ +10% супера', '#ffe08a'); Sound.sfx.shard(); }
        else if (p.kind === 'key') { G.keys = (G.keys || 0) + 1; floatText(P.x, P.y - 34, '🔑 +1', '#ffd25a', true); Sound.sfx.clue(); }
        else if (p.kind === 'magnet') { for (const q of G.pickups) if (q.kind !== 'heart') q.pull = true; Sound.sfx.heart(); }
        else if (p.kind === 'shard') {
          const s = SHARDS[p.sid];
          const pb = biomeMap[clamp(Math.floor(P.y / T), 0, MH - 1) * MW + clamp(Math.floor(P.x / T), 0, MW - 1)];
          const val = s.id === 'hp' ? Math.max(3, Math.round(refEHP(zoneE(pb)) * 0.012)) : s.val;
          P.bonus[s.id] = (P.bonus[s.id] || 0) + val; P.shards++;
          computeStats();
          if (s.id === 'hp') P.hp = Math.min(P.maxHp, P.hp + val);
          floatText(P.x + rnd(-10, 10), P.y - 40, s.txt(val), s.col);
          if (G.st) G.st.shards++;
          Sound.sfx.shard();
        }
      }
    }
    G.pickups = G.pickups.filter(p => !p.got);
    for (const c of chests) {
      if (c.open) continue;
      const dd = Math.hypot(P.x - c.x, P.y - c.y);
      if (dd < 320) c.seen = true; // спрятанные сундуки появляются на карте, только когда их увидишь
      if (dd < 34 && !P.down) openChest(c);
      else if (NET.host) for (const m of NET.peers.values()) if (m.live && !m.down && Math.hypot(m.x - c.x, m.y - c.y) < 34) { openChest(c, m); break; }
    }
  }
  function updateShrines() {
    for (const s of shrines) {
      if (s.state === 'done') continue;
      const d = Math.hypot(P.x - s.x, P.y - s.y);
      if (s.state === 'idle') {
        if (G.activeBoss || G.activeShrine || G.jump || !ARENA) continue;
        let on = d < 36 && !P.down;
        if (!on && NET.host) for (const m of NET.peers.values()) if (m.live && !m.down && Math.hypot(m.x - s.x, m.y - s.y) < 36) { on = true; break; } // встала подруга
        if (on) enterTrial(s);
      } else if (s.state === 'active') {
        G.trialT = (G.trialT || 0) + 1 / 60;
        // хозяйка без сил, а на арене никого, кто поднимет, – испытание проиграно, все возвращаются
        let helper = false; if (P.down && NET.host) for (const m of NET.peers.values()) if (m.live && !m.down && m.y > PLAY_H * T) { helper = true; break; }
        G.trialDownT = P.down && !helper ? (G.trialDownT || 0) + 1 / 60 : 0;
        if (G.trialDownT > 2) { G.trialDownT = 0; failTrial(s); }
        else if (G.trialT > 1.5 && !P.down && Math.hypot(P.x - ARENA.exit.x, P.y - ARENA.exit.y) < 24) failTrial(s);
        else if (s.left <= 0) completeTrial(s);
      }
    }
  }
  function updateParticles(dt) {
    for (const p of G.parts) { p.x += p.vx * dt; p.y += p.vy * dt; p.vx *= 0.92; p.vy = p.vy * 0.92 + p.grav * dt; p.life -= dt; }
    G.parts = G.parts.filter(p => p.life > 0);
    for (const t of G.texts) t.t += dt;
    G.texts = G.texts.filter(t => t.t < (t.big ? 1.1 : 0.8));
    for (const b of G.bolts) b.t -= dt;
    G.bolts = G.bolts.filter(b => b.t > 0);
    for (const r of G.rings) { r.t += dt; r.r += (r.max - r.r) * Math.min(1, dt * 8); }
    G.rings = G.rings.filter(r => r.t < 0.45);
  }
  function updateTriggers(dt) {
    G.gateMsgT -= dt; G.lowHpT -= dt;
    if (G.comboT > 0) { G.comboT -= dt; if (G.comboT <= 0) G.combo = 0; }
    if (!gateOpen && G.gateMsgT <= 0 && Math.hypot(P.x - tc(GATE_FRONT.x), P.y - tc(GATE_FRONT.y)) < 180) {
      say(`Ворота заперты магией! Победи стражей: ${guardiansDone()}/${guardiansCount()}.`);
      G.gateMsgT = 12;
    }
    G.fogT -= dt;
    if (G.fogT <= 0) { G.fogT = 0.25; revealFog(P.x, P.y, 9); }
    G.scaleT = (G.scaleT || 0) - dt;
    if (G.scaleT <= 0) { G.scaleT = 1; G.scaleCache = {}; }
    if (G.hintT > 0) G.hintT -= dt;
    if (G.mmHintT > 0) G.mmHintT -= dt;
  }
  function objective() {
    if (CFG.abyss) return { x: P.x, y: P.y }; // в Бездне и обороне идти некуда – враги сами придут
    for (let i = 0; i < guardiansCount(); i++) if (!G.defeated[i]) {
      if (CFG.detective && (G.clues5[i] || 0) < 3) {
        let best = null, bd = 1e12;
        for (const q of clues) if (q.i === i && !q.found) { const d = (q.x - P.x) ** 2 + (q.y - P.y) ** 2; if (d < bd) { bd = d; best = q; } }
        if (best) return { x: best.x, y: best.y };
      }
      return { x: bosses[i].hx, y: bosses[i].hy };
    }
    const fin = bosses[bosses.length - 1];
    if (!G.defeated[fin.id]) {
      if (!playerInCastle()) return { x: tc(GATE_FRONT.x), y: tc(GATE_FRONT.y) };
      return { x: fin.hx, y: fin.hy };
    }
    return { x: tc(CAGE.x), y: tc(CAGE.y) };
  }
  function update(dt) {
    G.time += dt;
    if (G.cutscene) updateCutscene(dt);
    else if (NET.client) { // гостья: мир присылает хозяин, своя только героиня
      updatePlayer(dt);
      netProxies(dt);
      updateProjectiles(dt);
      updatePlayerFx(dt);
      updateHazards(dt);
      updateTriggers(dt);
      updateSea(dt);
      if (CFG.house || beds.length || shelves.length || boxes.length || clues.length || CFG.dark) updateHouse(dt);
      netWinterLocal(dt);
      if (defOn()) defClientTick(dt);
      updateRelics(dt);
      updateMusic(dt);
    } else {
      updatePlayer(dt);
      updateEnemies(dt);
      for (const b of bosses) updateBoss(b, dt);
      AIM = P;
      updateProjectiles(dt);
      updatePlayerFx(dt);
      updateHazards(dt);
      updatePickups(dt);
      updateShrines();
      spawnEnemies(dt);
      updateTriggers(dt);
      updateEvents(dt);
      updateFinalFinal(dt);
      updateBossHearts(dt);
      updateChampions(dt);
      updateHouse(dt);
      updateWinter(dt);
      updateSea(dt);
      updateRelics(dt);
      updateMusic(dt);
      if (G.abyss) { if (G.abyss.def) defUpdate(dt); else abyssUpdate(dt); }
      if (G.daily) dailyUpdate(dt);
    }
    bookScan(dt);
    lifeT -= dt; if (lifeT <= 0) { lifeT = 10; lifeFlush(); }
    if (G.st && state === 'play') G.st.time += dt;
    if (G.rush && !G.rush.done && state === 'play') { G.rush.t += dt; if (G.rush.wait > 0) G.rush.wait -= dt; }
    updateParticles(dt);
    Dialog.update(dt);
    if (G.shake > 0) G.shake = Math.max(0, G.shake - dt * 30);
    if (G.hurtFlash > 0) G.hurtFlash -= dt;
    updateCamera();
  }
  function updateCamera() {
    const vw = VW / ZOOM, vh = VH / ZOOM;
    let tx = P.x, ty = P.y;
    if (state === 'menu') { G.menuT = performance.now() / 1000; tx = tc(START.x) + Math.sin(G.menuT * 0.12) * 900 - 500; ty = tc(START.y) - 600 + Math.cos(G.menuT * 0.09) * 500; }
    if (G.td && state !== 'menu') {
      const B = G.td.bounds, cl = (v, lo, hi, half) => hi - lo <= half * 2 ? (lo + hi) / 2 : clamp(v, lo + half, hi - half);
      G.cam.x = cl(tx, B.x0 - 60, B.x1 + 60, vw / 2); G.cam.y = cl(ty, B.y0 - 250, B.y1 + 110, vh / 2); // сверху запас побольше: входы не должны прятаться под плашками
      return;
    }
    G.cam.x = clamp(tx, vw / 2, WORLD_W - vw / 2);
    const inArena = state !== 'menu' && P.y > PLAY_H * T;
    G.cam.y = clamp(ty, (inArena ? PLAY_H * T : 0) + vh / 2, (inArena ? WORLD_H : PLAY_H * T) - vh / 2);
  }



  // ------------------------------------------------------------------
  //  Главы Тессы: жизни, прыжок, лежанки, улики, жители, полки, коробки
  // ------------------------------------------------------------------
  function loseLife() {
    P.lives--; P.hp = Math.round(P.maxHp * 0.35); P.inv = 2.2;
    for (const bl of G.ebullets) if ((bl.x - P.x) ** 2 + (bl.y - P.y) ** 2 < 200 * 200) bl.life = 0;
    burst(P.x, P.y, 30, '#bfeaff', 220); shockRing(P.x, P.y, '#bfeaff', 180);
    if (P.up.c4life) G.novas.push({ x: P.x, y: P.y, r: 10, max: 320, hit: new Set(), k: 2.5 * P.up.c4life, life: true });
    showBanner(`🐾 Осталось жизней: ${P.lives}`, P.lives <= 2 ? 'Найди лежанку – там можно вздремнуть' : 'Кошки так просто не сдаются');
    Sound.sfx.meow(); G.shake = 10;
    if (G.st) G.st.livesLost = (G.st.livesLost || 0) + 1;
  }
  function pounceHit() {
    const R = 80;
    for (const e of G.enemies) {
      if (e.dead || e.spawnT > 0) continue;
      const d = Math.hypot(e.x - P.x, e.y - P.y) || 1;
      if (d < R + e.r) { damageEnemy(e, rollHit(P.dmg * 1.8), (e.x - P.x) / d * 260, (e.y - P.y) / d * 260, false); e.slowT = Math.max(e.slowT || 0, 1); }
    }
    const b = G.activeBoss;
    if (b && b.state === 'fight' && Math.hypot(b.x - P.x, b.y - P.y) < R + b.r) damageBoss(b, rollHit(P.dmg * 1.8));
    G.rings.push({ x: P.x, y: P.y, r: 8, max: R, col: '#ffd0f0', t: 0 }); burst(P.x, P.y, 12, '#fff0f8', 160); G.shake = Math.max(G.shake, 4);
  }
  function napOn(bd) {
    bd.nap = 0; bd.cd = 75;
    P.hp = P.maxHp; if (P.lives) P.lives = Math.min(HEROES[P.hero].lives || 9, P.lives + 1); P.napT = 60;
    G.cp = { x: bd.x, y: bd.y + 30 };
    showBanner('💤 Тесса вздремнула', 'Здоровье полное, +1 жизнь, +20% урона на минуту');
    Sound.sfx.nap(); burst(bd.x, bd.y, 20, '#ffe0a0', 120);
    saveGame();
  }
  function updateHouse(dt) {
    if (G.invertT > 0) G.invertT -= dt;
    if (G.staticT > 0) G.staticT -= dt;
    if (G.clueMsgT > 0) G.clueMsgT -= dt;
    if (G.revealT > 0) G.revealT -= dt;
    for (const bd of beds) {
      if (bd.cd > 0) { bd.cd -= dt; continue; }
      const near = Math.hypot(P.x - bd.x, P.y - bd.y) < 34 && !G.activeBoss && !G.activeShrine;
      if (near && !P.moving) { bd.nap += dt; if (bd.nap >= 1.4) napOn(bd); } else bd.nap = 0;
    }
    for (const l of lamps) {
      if (Math.abs(l.x - P.x) > 700 || Math.abs(l.y - P.y) > 700) continue;
      for (const e of G.enemies) if (!e.dead && (e.x - l.x) ** 2 + (e.y - l.y) ** 2 < 150 * 150) e.lit = 0.2;
    }
    if (CFG.dark) {
      G.flickT -= dt; if (G.flickT < -G.flickGap) { G.flickT = 0.6; G.flickGap = rnd(6, 14); if (Math.random() < 0.4) Sound.sfx.staticNoise(); }
      G.eyesT -= dt;
      if (!G.eyes && G.eyesT <= 0 && !G.activeBoss) {
        G.eyesT = rnd(14, 24); const a = rnd(0, TAU), r = rnd(280, 380);
        G.eyes = { x: P.x + Math.cos(a) * r, y: P.y + Math.sin(a) * r, t: 0, dur: 2.8 }; Sound.sfx.whisper();
      }
      if (G.eyes) { G.eyes.t += dt; if (Math.hypot(G.eyes.x - P.x, G.eyes.y - P.y) < 160) G.eyes.dur = Math.min(G.eyes.dur, G.eyes.t + 0.2); if (G.eyes.t > G.eyes.dur) G.eyes = null; }
      G.glitchT -= dt; if (G.glitchT <= 0) { G.glitchT = rnd(25, 45); G.glitchFx = 0.35; Sound.sfx.staticNoise(); }
      if (G.glitchFx > 0) G.glitchFx -= dt;
    }
    for (const q of clues) {
      if (NET.client) break; // улики считает хозяйка – у гостьи они придут в снимке
      if (q.found || !netNear(q.x, q.y, 30)) continue;
      q.found = true; G.clues5[q.i] = (G.clues5[q.i] || 0) + 1;
      const [ic, txt] = CLUES5[q.i][q.k];
      Sound.sfx.clue(); burst(q.x, q.y, 16, '#ffd25a', 140); floatText(q.x, q.y - 24, `${ic} улика ${G.clues5[q.i]}/3`, '#ffd25a', true);
      say(`${ic} ${txt}`, 4.2); if (NET.host) NetT.send(-1, { t: 'say', text: `${ic} ${txt}`, d: 4.2 });
      if (G.st) G.st.clues = (G.st.clues || 0) + 1;
      if (G.clues5[q.i] >= 3) { const nm = BOSSES[CFG.bosses[q.i]].name; setTimeout(() => { if (state === 'play') showBanner('🔎 Подозреваемый найден!', nm + ' ждёт допроса'); }, 1200); }
      saveGame();
    }
    let nearN = null;
    if (!NET.client) for (const n of npcs) if (Math.hypot(n.x - P.x, n.y - P.y) < 56) nearN = n; // с жителями говорит хозяйка
    G.nearNpc = nearN;
    for (const it of qitems) {
      if (NET.client) break;
      if (!it.active || it.taken || Math.hypot(it.x - P.x, it.y - P.y) > 30) continue;
      it.taken = true; const def = NPCS5[it.ni];
      Sound.sfx.chest(); burst(it.x, it.y, 16, '#ffd25a', 140);
      showBanner(`${def.item.ic} Нашла: ${def.item.name}!`, `Отнеси – ${def.name} ждёт`);
      saveGame();
    }
    if (G.jump) {
      const J = G.jump; J.t += dt; const k = Math.min(1, J.t / J.dur);
      P.x = lerp(J.sx, J.tx, k); P.y = lerp(J.sy, J.ty, k); P.z = Math.sin(k * Math.PI) * 70; P.inv = Math.max(P.inv, 0.15);
      if (k >= 1) { G.jump = null; P.z = 0; burst(P.x, P.y, 12, '#c8945a', 120); revealFog(P.x, P.y, 12); }
    } else {
      for (const s of shelves) {
        if (s.cd > 0) s.cd -= dt;
        const inside = Math.hypot(s.x - P.x, s.y - P.y) < 22;
        if (inside && !s.inside && s.cd <= 0 && !G.activeBoss) {
          const o = shelves[s.to]; s.cd = o.cd = 1.5; o.inside = true;
          G.jump = { sx: P.x, sy: P.y, tx: o.x, ty: o.y, t: 0, dur: 0.8 };
          Sound.sfx.pounce(); floatText(P.x, P.y - 30, 'прыг!', '#ffd25a');
          if (G.st) G.st.jumps = (G.st.jumps || 0) + 1;
        }
        s.inside = inside;
      }
    }
    if (boxes.length) {
      const bx = !G.activeBoss && !G.activeShrine && !P.moving && boxes.find(o => Math.hypot(o.x - P.x, o.y - P.y) < 20);
      G.hideT = bx ? (G.hideT || 0) + dt : 0;
      const was = G.hidden; G.hidden = G.hideT > 0.25 ? bx : null;
      if (G.hidden && !was) { floatText(P.x, P.y - 30, 'спряталась 📦', '#ffd25a'); Sound.sfx.click(); }
      if (G.hidden) P.hp = Math.min(P.maxHp, P.hp + P.maxHp * 0.03 * dt);
    }
    if (G.pet) {
      const A = G.pet;
      A.x = lerp(A.x, P.x - 26 * P.face, Math.min(1, dt * 5)); A.y = lerp(A.y, P.y - 20, Math.min(1, dt * 5)); A.fireT -= dt;
      if (A.fireT <= 0) {
        const tg = G.hidden ? null : nearestTarget(280);
        if (tg) { A.fireT = 0.7; const a = Math.atan2(tg.y - (tg.z || 0) - A.y, tg.x - A.x); G.feathers.push({ x: A.x, y: A.y, vx: Math.cos(a) * 420, vy: Math.sin(a) * 420, dmg: P.dmg * 0.45, pierce: 0, life: 0.9, hit: [], kind: 'pixel', ally: true }); }
        else A.fireT = 0.25;
      }
    }
    if (G.boardPending && state === 'play' && !Dialog.talking && !G.activeBoss && !NET.client) { G.boardPending = false; openBoard(); }
  }
  // объекты дома на земле
  function drawHouseGround(c, vis) {
    for (const s of shelves) if (vis(s.x, s.y, 40)) {
      c.fillStyle = 'rgba(0,0,0,0.25)'; c.beginPath(); c.ellipse(s.x, s.y + 14, 22, 5, 0, 0, TAU); c.fill();
      c.fillStyle = '#6a4024'; c.fillRect(s.x - 16, s.y + 4, 4, 10); c.fillRect(s.x + 12, s.y + 4, 4, 10);
      c.fillStyle = '#9a6a40'; c.strokeStyle = '#5a3a20'; c.lineWidth = 2; roundRect(c, s.x - 20, s.y - 6, 40, 12, 3); c.fill(); c.stroke();
      if (s.cd <= 0) { c.font = '14px sans-serif'; c.textAlign = 'center'; c.globalAlpha = 0.6 + Math.sin(G.time * 5) * 0.3; c.fillText('🐾', s.x, s.y - 12); c.globalAlpha = 1; }
    }
    for (const bd of beds) if (vis(bd.x, bd.y, 40)) {
      c.fillStyle = 'rgba(0,0,0,0.3)'; c.beginPath(); c.ellipse(bd.x, bd.y + 10, 26, 8, 0, 0, TAU); c.fill();
      c.fillStyle = bd.cd > 0 ? '#7a6a7a' : '#c86a8a'; c.beginPath(); c.ellipse(bd.x, bd.y + 2, 26, 14, 0, 0, TAU); c.fill();
      c.fillStyle = bd.cd > 0 ? '#b0a0b0' : '#ffd0e0'; c.beginPath(); c.ellipse(bd.x, bd.y, 19, 9, 0, 0, TAU); c.fill();
      c.fillStyle = 'rgba(255,255,255,0.4)'; c.beginPath(); c.ellipse(bd.x - 6, bd.y - 3, 7, 3, -0.3, 0, TAU); c.fill();
      if (bd.nap > 0) { c.strokeStyle = '#ffe080'; c.lineWidth = 3; c.beginPath(); c.arc(bd.x, bd.y - 26, 10, -Math.PI / 2, -Math.PI / 2 + TAU * bd.nap / 1.4); c.stroke(); }
      if (bd.cd <= 0) { c.font = 'bold 10px sans-serif'; c.textAlign = 'center'; c.fillStyle = '#ffe0f0'; c.fillText(bd.nap > 0 ? '💤' : 'ЛЕЖАНКА', bd.x, bd.y - 20); }
    }
    for (const l of lamps) if (vis(l.x, l.y, 40)) {
      c.fillStyle = '#5a4a3a'; c.fillRect(l.x - 7, l.y + 4, 14, 4); c.fillRect(l.x - 1.5, l.y - 12, 3, 16);
      c.fillStyle = '#ffd890'; c.beginPath(); c.moveTo(l.x - 10, l.y - 10); c.lineTo(l.x + 10, l.y - 10); c.lineTo(l.x + 6, l.y - 22); c.lineTo(l.x - 6, l.y - 22); c.closePath(); c.fill();
    }
    for (const q of clues) if (!q.found && vis(q.x, q.y, 30)) {
      const bob = Math.sin(G.time * 3 + q.k) * 3;
      c.fillStyle = `rgba(255,220,90,${0.25 + Math.sin(G.time * 4 + q.k) * 0.15})`; c.beginPath(); c.arc(q.x, q.y, 16, 0, TAU); c.fill();
      const spr = emojiSprite(CLUES5[q.i][q.k][0], 18); c.drawImage(spr, q.x - spr.width / 4, q.y - 10 + bob - spr.height / 4, spr.width / 2, spr.height / 2);
      c.fillStyle = '#ffd25a'; star(c, q.x + 10, q.y - 16 + bob, 3, G.time, 4); c.fill();
    }
    for (const it of qitems) if (it.active && !it.taken && vis(it.x, it.y, 30)) {
      const def = NPCS5[it.ni], spr = emojiSprite(def.item.ic, 20), bob = Math.sin(G.time * 3) * 3;
      c.fillStyle = 'rgba(255,255,255,0.3)'; c.beginPath(); c.arc(it.x, it.y, 14, 0, TAU); c.fill();
      c.drawImage(spr, it.x - spr.width / 4, it.y - 8 + bob - spr.height / 4, spr.width / 2, spr.height / 2);
    }
    for (const n of npcs) if (vis(n.x, n.y, 40)) {
      shadow(c, n.x, n.y + 10, 12, 4);
      const spr = emojiSprite(n.def.ic, 26), hop = Math.abs(Math.sin(G.time * 2 + n.ni)) * 3;
      c.drawImage(spr, n.x - spr.width / 4, n.y - 8 - hop - spr.height / 4, spr.width / 2, spr.height / 2);
      c.font = 'bold 10px sans-serif'; c.textAlign = 'center'; c.fillStyle = '#000'; c.fillText(n.def.name, n.x + 1, n.y - 29); c.fillStyle = '#ffffff'; c.fillText(n.def.name, n.x, n.y - 30);
      const it = qitems[n.ni], mark = n.state === 'done' ? '' : it.taken ? '🎁' : n.state === 'new' ? '💬' : '';
      if (mark) { c.font = '14px sans-serif'; c.fillText(mark, n.x + 16, n.y - 22 - Math.abs(Math.sin(G.time * 3)) * 3); }
    }
    for (const bx of boxes) if (vis(bx.x, bx.y, 40) && bx !== G.hidden) drawBox(c, bx, false);
  }
  function drawBox(c, bx, peek) {
    c.fillStyle = 'rgba(0,0,0,0.25)'; c.beginPath(); c.ellipse(bx.x, bx.y + 10, 20, 6, 0, 0, TAU); c.fill();
    if (peek) {
      c.fillStyle = '#5a4034';
      c.beginPath(); c.moveTo(bx.x - 9, bx.y - 11); c.lineTo(bx.x - 6, bx.y - 22); c.lineTo(bx.x - 2, bx.y - 11); c.fill();
      c.beginPath(); c.moveTo(bx.x + 2, bx.y - 11); c.lineTo(bx.x + 6, bx.y - 22); c.lineTo(bx.x + 9, bx.y - 11); c.fill();
    }
    c.fillStyle = '#c8945a'; c.strokeStyle = '#8a6036'; c.lineWidth = 2;
    c.fillRect(bx.x - 16, bx.y - 12, 32, 22); c.strokeRect(bx.x - 16, bx.y - 12, 32, 22);
    c.fillStyle = 'rgba(255,255,255,0.35)'; c.fillRect(bx.x - 3, bx.y - 12, 6, 22);
    if (peek) { c.fillStyle = '#5ab8ff'; c.fillRect(bx.x - 7, bx.y - 9, 3, 2); c.fillRect(bx.x + 4, bx.y - 9, 3, 2); }
    c.fillStyle = '#d8a46a';
    c.beginPath(); c.moveTo(bx.x - 16, bx.y - 12); c.lineTo(bx.x - 24, bx.y - 18); c.lineTo(bx.x - 8, bx.y - 18); c.lineTo(bx.x, bx.y - 12); c.fill();
    c.beginPath(); c.moveTo(bx.x + 16, bx.y - 12); c.lineTo(bx.x + 24, bx.y - 18); c.lineTo(bx.x + 8, bx.y - 18); c.lineTo(bx.x, bx.y - 12); c.fill();
  }
  function drawPet(c) {
    const A = G.pet, y0 = A.y + Math.sin(G.time * 4) * 2;
    c.fillStyle = 'rgba(63,240,160,0.25)'; c.beginPath(); c.arc(A.x, y0, 12, 0, TAU); c.fill();
    const px = (x, y, col) => { c.fillStyle = col; c.fillRect(A.x + x * 2.4, y0 + y * 2.4, 2.4, 2.4); };
    for (const [x, y] of [[-3, -4], [3, -4], [-3, -3], [-2, -3], [-1, -3], [0, -3], [1, -3], [2, -3], [3, -3], [-3, -2], [-2, -2], [0, -2], [2, -2], [3, -2],
      [-3, -1], [-2, -1], [-1, -1], [0, -1], [1, -1], [2, -1], [3, -1], [-2, 0], [-1, 0], [0, 0], [1, 0], [2, 0], [-2, 1], [2, 1]]) px(x, y, '#3ff0a0');
    px(-1, -2, '#0a2a1a'); px(1, -2, '#0a2a1a');
  }
  // темнота главы 4: свет только вокруг Тессы, ламп и лежанок
  let darkCv = null;
  function drawDarkness(c) {
    if (!darkCv) darkCv = makeCanvas(1, 1);
    const w = Math.ceil(VW / 2), h = Math.ceil(VH / 2);
    if (darkCv.width !== w || darkCv.height !== h) { darkCv.width = w; darkCv.height = h; }
    const d = darkCv.getContext('2d');
    d.globalCompositeOperation = 'source-over'; d.clearRect(0, 0, w, h);
    const fl = G.flickT > 0 && Math.random() < 0.5 ? 0.08 : 0;
    d.fillStyle = paperOn ? `rgba(30,32,78,${0.68 + fl})` : `rgba(4,3,14,${0.88 + fl})`; d.fillRect(0, 0, w, h); // 1.0: ночная сказка – синие чернила вместо черноты
    d.globalCompositeOperation = 'destination-out';
    const toS = (x, y) => [((x - G.cam.x) * ZOOM + VW / 2) / 2, ((y - G.cam.y) * ZOOM + VH / 2) / 2];
    const hole = (x, y, r, k = 1) => {
      const [sx, sy] = toS(x, y), rr = r * ZOOM / 2;
      if (sx < -rr || sy < -rr || sx > w + rr || sy > h + rr) return;
      const g = d.createRadialGradient(sx, sy, rr * 0.35, sx, sy, rr);
      g.addColorStop(0, `rgba(0,0,0,${k})`); g.addColorStop(1, 'rgba(0,0,0,0)');
      d.fillStyle = g; d.beginPath(); d.arc(sx, sy, rr, 0, TAU); d.fill();
    };
    hole(P.x, P.y, (G.activeBoss ? 340 : 245) * (1 + 0.2 * lv('c4lamp')));
    for (const l of lamps) hole(l.x, l.y, 165, 0.85 + Math.sin(G.time * 7 + l.ph) * 0.05);
    for (const b of beds) hole(b.x, b.y, 150, 0.8);
    const ab = G.activeBoss; if (ab) hole(ab.x, ab.y, 130, 0.65);
    d.globalCompositeOperation = 'source-over';
    c.save(); c.setTransform(DPR, 0, 0, DPR, 0, 0); c.imageSmoothingEnabled = true;
    c.drawImage(darkCv, 0, 0, VW, VH);
    c.globalCompositeOperation = 'lighter';
    if (paperOn) { // фонарик героини: тёплый круг света, как от свечи в книжке, и пылинки в нём
      const [sx, sy] = toS(P.x, P.y - 10), X = sx * 2, Y = sy * 2, R = (G.activeBoss ? 300 : 220) * (1 + 0.2 * lv('c4lamp')) * ZOOM, fk = 1 + Math.sin(G.time * 9) * 0.03;
      const g = c.createRadialGradient(X, Y, 6, X, Y, R * fk); g.addColorStop(0, 'rgba(255,214,140,0.30)'); g.addColorStop(0.55, 'rgba(255,180,100,0.12)'); g.addColorStop(1, 'rgba(255,170,90,0)');
      c.fillStyle = g; c.fillRect(X - R, Y - R, R * 2, R * 2);
      for (let i = 0; i < 14; i++) { const a = hash2(i, 31) * TAU + G.time * (0.15 + hash2(31, i) * 0.2), rr = R * (0.15 + hash2(i, 32) * 0.55); c.fillStyle = `rgba(255,236,190,${0.25 + 0.35 * Math.abs(Math.sin(G.time * 1.7 + i))})`; c.fillRect(X + Math.cos(a) * rr, Y + Math.sin(a) * rr * 0.8, 1.6, 1.6); }
    }
    for (const l of lamps) {
      const [sx, sy] = toS(l.x, l.y), X = sx * 2, Y = sy * 2, R = 150 * ZOOM;
      if (X < -R || Y < -R || X > VW + R || Y > VH + R) continue;
      const g = c.createRadialGradient(X, Y, 4, X, Y, R); g.addColorStop(0, 'rgba(255,170,80,0.22)'); g.addColorStop(1, 'rgba(255,170,80,0)');
      c.fillStyle = g; c.fillRect(X - R, Y - R, R * 2, R * 2);
    }
    c.globalCompositeOperation = 'source-over';
    for (const e of G.enemies) {
      if (e.dead || e.spawnT > 0) continue;
      const [sx, sy] = toS(e.x, e.y), X = sx * 2, Y = sy * 2;
      if (X < 0 || Y < 0 || X > VW || Y > VH || Math.sin(e.t * 2 + e.seed * 7) > 0.96) continue;
      c.fillStyle = e.type === 'shadowcat' ? '#ffffff' : '#ff3b3b'; c.fillRect(X - 4, Y - 7, 2.5, 2.5); c.fillRect(X + 2, Y - 7, 2.5, 2.5);
    }
    if (G.eyes) {
      const [sx, sy] = toS(G.eyes.x, G.eyes.y), X = sx * 2, Y = sy * 2;
      const a = clamp(G.eyes.t / 0.5, 0, 1) * clamp((G.eyes.dur - G.eyes.t) / 0.4, 0, 1), blinkE = Math.sin(G.eyes.t * 5) > 0.93 ? 0.15 : 1;
      c.globalAlpha = a; c.shadowColor = '#3ff0a0'; c.shadowBlur = 14; c.fillStyle = '#3ff0a0';
      c.beginPath(); c.ellipse(X - 12, Y, 6, 3.5 * blinkE, 0, 0, TAU); c.ellipse(X + 12, Y, 6, 3.5 * blinkE, 0, 0, TAU); c.fill();
      c.shadowBlur = 0; c.fillStyle = '#000'; c.fillRect(X - 13, Y - 3 * blinkE, 2, 6 * blinkE); c.fillRect(X + 11, Y - 3 * blinkE, 2, 6 * blinkE);
      c.globalAlpha = 1;
    }
    c.restore();
  }
  // экранные эффекты: помехи, перевёрнутое управление, глитч
  function drawHouseFx(c) {
    if (G.wxId === 'frost' && G.chill > 0.2) {
      const a = clamp(G.chill / 2.5, 0, 1) * 0.55;
      const g = c.createRadialGradient(VW / 2, VH / 2, Math.min(VW, VH) * 0.28, VW / 2, VH / 2, Math.max(VW, VH) * 0.7);
      g.addColorStop(0, 'rgba(150,210,255,0)'); g.addColorStop(1, `rgba(190,230,255,${a})`); c.fillStyle = g; c.fillRect(0, 0, VW, VH);
      if (G.chill > 0.8) { c.font = '900 15px sans-serif'; c.textAlign = 'center'; c.fillStyle = '#000'; c.fillText('🥶 Замерзаешь! Двигайся', VW / 2 + 1, VH * 0.7 + 1); c.fillStyle = '#d8f2ff'; c.fillText('🥶 Замерзаешь! Двигайся', VW / 2, VH * 0.7); }
    }
    if (G.activeShrine && P.y > PLAY_H * T) {
      const st = ARENA_STYLE[CHN] || ARENA_STYLE[1], a = 0.32 + Math.sin(G.time * 3) * 0.06;
      const g = c.createRadialGradient(VW / 2, VH / 2, Math.min(VW, VH) * 0.3, VW / 2, VH / 2, Math.max(VW, VH) * 0.72);
      g.addColorStop(0, `rgba(${st.tint},0)`); g.addColorStop(1, `rgba(${st.tint},${a})`);
      c.fillStyle = g; c.fillRect(0, 0, VW, VH);
    }
    if (G.staticT > 0) {
      const a = Math.min(1, G.staticT) * 0.35;
      for (let i = 0; i < 160; i++) { const v = Math.random() * 255 | 0; c.fillStyle = `rgba(${v},${v},${v},${a})`; c.fillRect(Math.random() * VW, Math.random() * VH, rnd(6, 30), 2); }
    }
    if (G.invertT > 0) {
      c.fillStyle = `rgba(140,60,255,${0.12 + Math.sin(G.time * 10) * 0.05})`; c.fillRect(0, 0, VW, VH);
      c.font = '900 15px sans-serif'; c.textAlign = 'center'; c.fillStyle = '#e0c8ff'; c.fillText('🔄 управление перевёрнуто', VW / 2, VH * 0.7);
    }
    if (G.glitchFx > 0) {
      c.save(); c.setTransform(1, 0, 0, 1, 0, 0);
      for (let i = 0; i < 6; i++) { const y = Math.random() * canvas.height, hh = rnd(6, 30) * DPR, dx = rnd(-30, 30) * DPR; c.drawImage(canvas, 0, y, canvas.width, hh, dx, y, canvas.width, hh); }
      c.restore();
      c.fillStyle = 'rgba(63,240,160,0.08)'; c.fillRect(0, 0, VW, VH);
    }
    if (G.hidden) { c.font = 'bold 13px sans-serif'; c.textAlign = 'center'; c.fillStyle = '#000'; c.fillText('📦 Тессу не видно · она лечится', VW / 2 + 1, VH * 0.66 + 1); c.fillStyle = '#ffd25a'; c.fillText('📦 Тессу не видно · она лечится', VW / 2, VH * 0.66); }
  }

  // ------------------------------------------------------------------
  //  Глава 6: две героини, скользкий лёд, таяние, костры, метель
  // ------------------------------------------------------------------
  const heroAvatar = id => AVATAR[id === 'ryzhovaya' ? 'ryzhova' : id] || heroPortrait(id);
  const teamOther = () => G.team.list.find(id => id !== P.hero);
  function initTeam(sv) {
    if (!CFG.team || NET.on) { G.team = null; return; } // вместе у каждой своя героиня
    const T6 = G.team = { list: CFG.team.slice(), f: {}, ko: {}, cd: 0, bx: P.x - 34, by: P.y, fireT: 1.5 };
    for (const id of T6.list) {
      T6.f[id] = sv && sv.f && typeof sv.f[id] === 'number' ? clamp(sv.f[id], 0, 1) : 1;
      T6.ko[id] = !!(sv && sv.ko && sv.ko[id]);
    }
    if (T6.ko[P.hero] || T6.f[P.hero] < 0.05) { T6.ko[P.hero] = false; T6.f[P.hero] = Math.max(T6.f[P.hero], 0.35); }
    P.hp = Math.max(1, Math.round(P.maxHp * T6.f[P.hero]));
  }
  function teamSnapshot() {
    if (!G.team) return null;
    const f = Object.assign({}, G.team.f); f[P.hero] = clamp(P.hp / P.maxHp, 0, 1);
    return { f, ko: Object.assign({}, G.team.ko), h: P.hero };
  }
  function switchHero(forced) {
    const T6 = G.team;
    if (!T6 || G.cutscene || (state !== 'play' && !forced)) return false;
    const o = teamOther();
    if (!forced) {
      if (T6.cd > 0 || P.dashT > 0) return false;
      if (T6.ko[o] || T6.f[o] < 0.25) {
        floatText(P.x, P.y - 44, `${HEROES[o].name} ещё отдыхает 💤`, '#bfeaff', true); Sound.sfx.click();
        T6.cd = 0.6; return false;
      }
    }
    T6.f[P.hero] = clamp(P.hp / P.maxHp, 0, 1);
    T6.bx = P.x; T6.by = P.y;
    P.hero = o; computeStats();
    P.hp = Math.max(1, Math.round(P.maxHp * T6.f[o]));
    P.fireT = 0.15; P.inv = Math.max(P.inv, 0.5); T6.cd = 1.2;
    $('dashBtn').querySelector('span').textContent = HEROES[o].dash;
    burst(P.x, P.y, 22, o === 'ryzhovaya' ? '#ff8a2a' : '#7fd8ff', 200); shockRing(P.x, P.y, '#ffffff', 60);
    Sound.sfx.blink();
    if (G.st) G.st.swaps = (G.st.swaps || 0) + 1;
    return true;
  }
  // героиня упала – подруга подхватывает
  function teamCatch() {
    const T6 = G.team; if (!T6) return false;
    const o = teamOther();
    if (T6.ko[o] || T6.f[o] < 0.05) return false;
    const was = P.hero;
    switchHero(true);
    T6.f[was] = 0; T6.ko[was] = true; P.inv = 2;
    showBanner(`${HEROES[P.hero].name} подхватывает!`, `${HEROES[was].name} без сил – отдохнёт у костра`);
    burst(P.x, P.y, 30, '#ffffff', 240); G.shake = 10;
    return true;
  }
  // ---------- лёд Рыжовая растапливает ----------
  function canMelt(i) {
    const tx = i % MW, ty = Math.floor(i / MW);
    if (cracks.has(i)) return tiles[i] === ROCK || tiles[i] === WALL;
    return tx >= 2 && ty >= 2 && tx < MW - 2 && ty < PLAY_H - 2 && tiles[i] === ROCK && !!BIOMES[biomeMap[i]].meltable;
  }
  function tryMelt(f) {
    const tx = Math.floor(f.x / T), ty = Math.floor(f.y / T);
    if (!inMap(tx, ty)) return;
    const i = ty * MW + tx;
    if (!canMelt(i)) return;
    const ice = lv('c6ice');
    if (f.ally || (f.kind !== 'fire' && !ice)) { if (Math.random() < 0.3) part(f.x, f.y, rnd(-30, 30), rnd(-40, 0), 0.4, 3, '#e8f8ff'); return; }
    const h = (G.meltHits[i] || 0) + (f.kind === 'fire' ? 1 : 0.5);
    G.meltHits[i] = h;
    burst(f.x, f.y, 8, '#e8f8ff', 100);
    for (let k = 0; k < 3; k++) part(tc(tx) + rnd(-14, 14), tc(ty) + rnd(-10, 10), rnd(-10, 10), rnd(-70, -30), 0.9, 6, 'rgba(235,245,255,0.7)');
    if (h >= Math.max(1, 3 - ice)) meltTile(i, true);
  }
  function meltTile(i, fx) {
    if (!canMelt(i)) return;
    if (NET.on && G.netRun && !NET.applyMelt) NET.meltOut.push(i); // растаяло у меня – расскажем остальным
    tiles[i] = biomeMap[i]; delete G.meltHits[i];
    if (!G.melted.includes(i)) G.melted.push(i);
    const tx = i % MW, ty = Math.floor(i / MW);
    for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) chunkCache.delete(Math.floor((tx + dx) / CHUNK) + ',' + Math.floor((ty + dy) / CHUNK));
    chunkJob = null; // кусок, который строился, мог задеть растаявшую клетку
    const mc = miniBase.getContext('2d'); mc.fillStyle = BIOMES[tiles[i]].mini; mc.fillRect(tx, ty, 1, 1);
    const sc = secrets.find(o => o.i === i);
    if (sc) { secretOpened(sc, fx); return; }
    if (fx) {
      const x = tc(tx), y = tc(ty);
      burst(x, y, 26, '#ffffff', 190); burst(x, y, 10, '#7fd8ff', 140);
      for (let k = 0; k < 10; k++) part(x + rnd(-18, 18), y + rnd(-14, 14), rnd(-20, 20), rnd(-90, -40), 1.3, 8, 'rgba(235,245,255,0.6)');
      Sound.sfx.glass();
      if ((G.meltSayT || 0) <= 0) { G.meltSayT = 6; floatText(x, y - 20, 'растаяло! 💧', '#bfeaff', true); }
    }
  }
  // треснувшая стена: четыре удара – и проход открыт
  function tryCrack(f) {
    const tx = Math.floor(f.x / T), ty = Math.floor(f.y / T), i = ty * MW + tx;
    if (!cracks.has(i) || f.ally || !canMelt(i)) return false;
    G.crackHits[i] = (G.crackHits[i] || 0) + 1;
    burst(f.x, f.y, 8, '#c8b090', 110); G.shake = Math.max(G.shake, 2); Sound.sfx.hit();
    for (let k = 0; k < 3; k++) part(tc(tx) + rnd(-14, 14), tc(ty) + rnd(-10, 10), rnd(-40, 40), rnd(-60, -20), 0.7, 5, 'rgba(140,110,80,0.8)');
    if (G.crackHits[i] >= 4) meltTile(i, true);
    return true;
  }
  function secretOpened(sc, fx) {
    if (sc.open) return; sc.open = true; sc.chest.seen = true;
    const mc = miniBase.getContext('2d');
    for (let y = sc.cy - 1; y <= sc.cy + 1; y++) for (let x = sc.cx - 1; x <= sc.cx + 1; x++) { mc.fillStyle = BIOMES[tiles[y * MW + x]] ? BIOMES[tiles[y * MW + x]].mini : '#888'; mc.fillRect(x, y, 1, 1); }
    revealFog(sc.chest.x, sc.chest.y, 4);
    if (!fx) return;
    const x = tc(sc.ex), y = tc(sc.ey);
    burst(x, y, 40, '#c8b090', 240); burst(sc.chest.x, sc.chest.y, 30, '#ffd25a', 200); shockRing(x, y, '#ffd25a', 160);
    for (let k = 0; k < 14; k++) part(x + rnd(-18, 18), y + rnd(-14, 14), rnd(-90, 90), rnd(-120, -30), 1.1, 7, pick(['#8a6a4a', '#a0826a', '#6a5040']));
    G.shake = Math.max(G.shake, 9); Sound.sfx.boom(); Sound.sfx.chest(); buzz(90);
    showBanner('🗝️ Тайник!', 'За стеной спрятана комната с сундуком');
    if (!NET.applyMelt) life('secrets');
  }
  // треснувшая стена рядом и врагов нет – героиня бьёт по ней сама
  function crackTarget() {
    let best = null, bd = (P.range + 30) ** 2;
    for (const sc of secrets) {
      if (sc.open) continue;
      const x = tc(sc.ex), y = tc(sc.ey), d = (x - P.x) ** 2 + (y - P.y) ** 2;
      if (d < bd) { bd = d; best = { x, y, z: 0 }; }
      if (!sc.hinted && d < 260 * 260) { sc.hinted = true; floatText(x, y - 30, '🪨 Тут трещина…', '#ffe9a0', true); }
    }
    return best;
  }
  function drawCracks(c, vis) {
    for (const sc of secrets) {
      if (sc.open) continue;
      const x = sc.ex * T, y = sc.ey * T; if (!vis(x + T / 2, y + T / 2, 40)) continue;
      const h = G.crackHits[sc.i] || 0, r = mulberry32(sc.i * 7 + 3);
      c.save();
      c.globalAlpha = 0.16 + 0.1 * Math.sin(G.time * 2.2 + sc.i); c.fillStyle = '#ffe9a0'; c.fillRect(x + 7, y + 7, T - 14, T - 14);
      c.globalAlpha = 0.85; c.strokeStyle = 'rgba(25,15,8,0.9)'; c.lineWidth = 2; c.lineCap = 'round'; c.beginPath();
      for (let k = 0; k < 3 + h * 2; k++) { let px = x + T * (0.3 + r() * 0.4), py = y + T * (0.3 + r() * 0.4); c.moveTo(px, py); for (let j = 0; j < 3; j++) { px += (r() - 0.5) * 18; py += (r() - 0.5) * 18; c.lineTo(px, py); } }
      c.stroke(); c.restore();
    }
  }
  const ringIntact = ch => { for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) if (Math.max(Math.abs(dx), Math.abs(dy)) === 2 && tileAt(ch.tx + dx, ch.ty + dy) !== ROCK) return false; return true; };
  // огонь сам целится в ледяную стену вокруг сундука, если рядом нет врагов
  function iceTarget() {
    let best = null, bd = (P.range + 20) ** 2;
    for (const ch of chests) {
      if (!ch.iced || ch.open || Math.abs(ch.x - P.x) > 320 || Math.abs(ch.y - P.y) > 320 || !ringIntact(ch)) continue;
      for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) {
        if (Math.max(Math.abs(dx), Math.abs(dy)) !== 2) continue;
        const x = tc(ch.tx + dx), y = tc(ch.ty + dy), d = (x - P.x) ** 2 + (y - P.y) ** 2;
        if (d < bd) { bd = d; best = { x, y, z: 0 }; }
      }
    }
    for (const g of glades) {
      if (g.open || Math.abs(g.x - P.x) > 420 || Math.abs(g.y - P.y) > 420) continue;
      for (const i of g.ring) {
        const x = tc(i % MW), y = tc(Math.floor(i / MW)), d = (x - P.x) ** 2 + (y - P.y) ** 2;
        if (d < bd) { bd = d; best = { x, y, z: 0 }; }
      }
    }
    for (const dr of drifts) {
      if (dr.done) continue;
      const d = (dr.x - P.x) ** 2 + (dr.y - P.y) ** 2;
      if (d < bd) { bd = d; best = { x: dr.x, y: dr.y + 4, z: 0 }; }
    }
    return best;
  }
  // ---------- сугробы: огонь растапливает, внутри сюрприз ----------
  function hitDrift(f) {
    for (const dr of drifts) {
      if (dr.done || Math.abs(dr.x - f.x) > 30 || Math.abs(dr.y - f.y) > 30) continue;
      if ((dr.x - f.x) ** 2 + (dr.y - 4 - f.y) ** 2 > 26 * 26) continue;
      f.life = 0;
      if (f.kind !== 'fire' && !lv('c6ice')) { burst(f.x, f.y, 4, '#ffffff', 80); return true; }
      if (NET.client) { NET.driftHits.push([drifts.indexOf(dr), f.kind === 'fire' ? 1 : 0.5]); burst(dr.x, dr.y, 10, '#ffffff', 120); return true; } // сугроб считает хозяйка
      dr.hp -= f.kind === 'fire' ? 1 : 0.5; burst(dr.x, dr.y, 10, '#ffffff', 120);
      for (let k = 0; k < 3; k++) part(dr.x + rnd(-12, 12), dr.y - 6, rnd(-10, 10), rnd(-70, -30), 0.9, 6, 'rgba(235,245,255,0.7)');
      if (dr.hp <= 0) openDrift(dr);
      return true;
    }
    return false;
  }
  function openDrift(dr) {
    dr.done = true; burst(dr.x, dr.y, 30, '#ffffff', 200); Sound.sfx.glass();
    const r = Math.random(), E = zoneE(biomeMap[dr.ty * MW + dr.tx]);
    if (r < 0.22) {
      floatText(dr.x, dr.y - 30, 'Засада! ⛄', '#ff8a8a', true);
      for (let k = 0; k < 3; k++) { const a = k * TAU / 3, x = dr.x + Math.cos(a) * 40, y = dr.y + Math.sin(a) * 40; if (walkable(x, y, false)) spawnEnemy('snowling', x, y, biomeMap[dr.ty * MW + dr.tx], { elite: k === 0, instant: true }); }
      return;
    }
    if (r < 0.42) dropPickup(dr.x, dr.y, 'heart');
    else if (r < 0.47) dropPickup(dr.x, dr.y, 'key');
    floatText(dr.x, dr.y - 30, 'Сугроб растаял! ✨', '#bfeaff');
    for (let k = 0; k < 3; k++) dropGem(dr.x + rnd(-20, 20), dr.y + rnd(-20, 20), xpFor(E) * 0.08);
    for (let k = 0; k < 2; k++) dropShard(dr.x, dr.y);
  }
  // ---------- погода главы 6: метель, звездопад, мороз ----------
  function startWeather(id) {
    G.wxId = id; G.lastWx = id;
    if (id === 'blizzard') { G.wxT = 10; G.blizzardT = 10; showBanner('❄️ МЕТЕЛЬ', 'Ничего не видно! Грейся у костров'); Sound.sfx.whisper(); }
    else if (id === 'starfall') { G.wxT = 14; G.starT = 0.4; showBanner('🌠 ЗВЕЗДОПАД', 'Лови звёзды – они заряжают супер'); Sound.sfx.magic(); }
    else { G.wxT = 12; G.chill = 0; showBanner('🥶 МОРОЗ', 'Не стой на месте – замёрзнешь!'); Sound.sfx.whisper(); }
  }
  // ---------- Тесса вырывается из ледяной клетки ----------
  function freeTessa() {
    if (G.tessaAlly || CFG.hostage !== 'tessa' || !CFG.team) return;
    const cx = tc(CAGE.x), cy = tc(CAGE.y);
    G.tessaAlly = { x: cx, y: cy, fireT: 1.2, face: 1 };
    burst(cx, cy, 50, '#bfeaff', 300); burst(cx, cy, 24, '#ffffff', 220); Sound.sfx.shatter(); G.shake = 14;
    showBanner('🐾 Тесса вырвалась!', 'Теперь вас трое');
    say('Мяу!!! Лёд треснул – я с вами! Держись, Мрак, сейчас будет КУСЬ! 🐾', 4.5);
    if (loadProfile().ch4Choice === 'kind') { G.pet = { x: cx, y: cy, fireT: 1 }; say('Мяу.exe тоже здесь! Пиксельный котик спешит на помощь! 💚', 4); }
  }
  // ---------- глава 7: течения и слова-жемчужины ----------
  function updateSea(dt) {
    if (flow && state === 'play' && !G.cutscene) {
      const f = flow.get(Math.floor(P.y / T) * MW + Math.floor(P.x / T));
      G.onCurrent = !!f;
      if (f) {
        const sp = 150 * (1 + 0.4 * lv('c7flow'));
        if (P.dashT <= 0) moveEntity(P, f[0] * sp * dt, f[1] * sp * dt);
        if (lv('c7flow') && P.dashCd > 0) P.dashCd -= dt * lv('c7flow') * 0.5; // попутное течение: рывок быстрее
        if (Math.random() < dt * 14) part(P.x + rnd(-10, 10), P.y + rnd(-6, 8), -f[0] * 40, -f[1] * 40, 0.5, 3, 'rgba(220,250,255,0.8)');
        if (!G.curSaid) { G.curSaid = true; say('Ух, течение! Плыви по стрелкам – так быстрее 🌊', 4); }
      }
    }
    for (let k = 0; k < pearls.length; k++) {
      const p = pearls[k]; if (p.got || Math.hypot(P.x - p.x, P.y - p.y) >= 34) continue;
      if (NET.client) { NET.pearlReq = k; p.got = true; } // жемчужину засчитает хозяин – для всех
      else collectPearl(k);
    }
    if (NET.host) for (const m of NET.peers.values()) for (let k = 0; k < pearls.length; k++) { const p = pearls[k]; if (!p.got && m.live && !m.down && Math.hypot(m.x - p.x, m.y - p.y) < 34) netPearl(k, m.id); }
  }
  function collectPearl(k, remote) {
    const p = pearls[k]; p.got = true;
    const n = pearls.filter(q => q.got).length, word = PEARL_WORDS[(n - 1) % PEARL_WORDS.length];
    floatText(p.x, p.y - 34, '💗 ' + word, '#ffb0d0', true);
    showBanner(`💗 Слово ${n}/${pearls.length}`, word);
    burst(p.x, p.y, 26, '#ffb0d0', 200); burst(p.x, p.y, 10, '#ffffff', 140); Sound.sfx.magic();
    const love = lv('c7love');
    if (NET.host) NetT.send(-1, { t: 'ban', a: `💗 Слово ${n}/${pearls.length}`, b: word });
    if (!remote) { P.hp = Math.min(P.maxHp, P.hp + P.maxHp * 0.15 * (1 + love)); if (love) addSuper(20 * love); }
    for (let i = 0; i < 3; i++) dropShard(p.x, p.y);
    if (G.st) G.st.pearls = n;
    if (n === pearls.length) {
      life('pearls12');
      showBanner('💗 Все слова вернулись!', 'Крилесса и Рыжовая снова говорят друг другу нежности');
      eventLoot(p.x, p.y + 24, 'gold');
      say('– Ты меня крилюбишь? – Я тебя криливирую! 💗', 4.5);
    } else if (n === 1) say('Слово вернулось! Их тут целых ' + pearls.length + ' – соберём все 💗', 4);
    saveGame();
  }
  // течения: бегущие струйки, слова-жемчужины в раскрытых ракушках
  function drawSeaFloor(c, x0, y0, x1, y1) {
    if (curPts.length) {
      const t = G.time;
      c.strokeStyle = 'rgba(210,248,255,0.38)'; c.lineWidth = 2.2; c.lineCap = 'round'; c.beginPath();
      for (const p of curPts) {
        if (p.x < x0 - 60 || p.x > x1 + 60 || p.y < y0 - 60 || p.y > y1 + 60) continue;
        for (let k = 0; k < 2; k++) {
          const o = ((t * 75 + k * 40 + p.x * 0.37) % 80) - 40, sd = k ? 14 : -14;
          const sx = p.x + p.dx * o - p.dy * sd, sy = p.y + p.dy * o + p.dx * sd;
          c.moveTo(sx, sy); c.lineTo(sx + p.dx * 16, sy + p.dy * 16);
        }
      }
      c.stroke(); c.lineCap = 'butt';
    }
    for (const p of pearls) {
      if (p.got || p.x < x0 - 40 || p.x > x1 + 40 || p.y < y0 - 40 || p.y > y1 + 40) continue;
      const bob = Math.sin(G.time * 2.4 + p.ph) * 2;
      c.fillStyle = 'rgba(0,0,0,0.25)'; c.beginPath(); c.ellipse(p.x, p.y + 10, 16, 5, 0, 0, TAU); c.fill();
      for (const sg of [-1, 1]) { // створки ракушки
        c.fillStyle = sg < 0 ? '#f0c8b0' : '#ffdcc8'; c.beginPath(); c.ellipse(p.x, p.y + (sg < 0 ? 6 : -4), 15, 8, 0, sg < 0 ? 0 : Math.PI, sg < 0 ? Math.PI : TAU); c.fill();
        c.strokeStyle = 'rgba(180,120,100,0.6)'; c.lineWidth = 1; for (let r = -10; r <= 10; r += 5) { c.beginPath(); c.moveTo(p.x, p.y + (sg < 0 ? 6 : -4)); c.lineTo(p.x + r, p.y + (sg < 0 ? 13 : -11)); c.stroke(); }
      }
      const g = c.createRadialGradient(p.x - 2, p.y - 2 + bob, 1, p.x, p.y + bob, 9); g.addColorStop(0, '#ffffff'); g.addColorStop(0.5, '#ffd0e0'); g.addColorStop(1, '#e88ab0');
      c.fillStyle = 'rgba(255,160,200,0.35)'; c.beginPath(); c.arc(p.x, p.y + bob, 14 + Math.sin(G.time * 4 + p.ph) * 2, 0, TAU); c.fill();
      c.fillStyle = g; c.beginPath(); c.arc(p.x, p.y + bob, 7, 0, TAU); c.fill();
    }
  }
  // подводная атмосфера: лучи света сверху и пузырьки
  function drawSeaFx(c) {
    if (!CFG.currents) return;
    const t = G.time;
    for (let k = 0; k < 3; k++) {
      const x = VW * (0.15 + k * 0.33) + Math.sin(t * 0.3 + k * 2) * 40;
      const g = c.createLinearGradient(x, 0, x + 120, VH); g.addColorStop(0, 'rgba(180,240,255,0.10)'); g.addColorStop(1, 'rgba(180,240,255,0)');
      c.fillStyle = g; c.beginPath(); c.moveTo(x - 30, 0); c.lineTo(x + 30, 0); c.lineTo(x + 170, VH); c.lineTo(x + 60, VH); c.closePath(); c.fill();
    }
    c.fillStyle = 'rgba(220,250,255,0.5)';
    for (let i = 0; i < 14; i++) { const k = (t * (0.06 + hash2(i, 2) * 0.05) + hash2(2, i)) % 1, x = hash2(i, 5) * VW + Math.sin(t * 1.3 + i) * 8, y = VH * (1 - k); c.beginPath(); c.arc(x, y, 1.5 + hash2(i, 7) * 2.5, 0, TAU); c.fill(); }
  }
  function updateWinter(dt) {
    if (G.meltSayT > 0) G.meltSayT -= dt;
    const T6 = G.team;
    if (T6) {
      if (T6.cd > 0) T6.cd -= dt;
      const o = teamOther();
      if (T6.f[o] < 1) T6.f[o] = Math.min(1, T6.f[o] + (T6.ko[o] ? 0.006 : 0.02) * (1 + 0.4 * lv('c6duo')) * dt);
      if (T6.ko[o] && T6.f[o] >= 0.25) { T6.ko[o] = false; floatText(P.x, P.y - 44, `${HEROES[o].name} снова в строю!`, '#7dff9a', true); }
      // подруга бежит рядом и подстреливает врагов
      if (Math.hypot(T6.bx - P.x, T6.by - P.y) > 420) { T6.bx = P.x; T6.by = P.y; }
      T6.bx = lerp(T6.bx, P.x - 34 * P.face, Math.min(1, dt * 4)); T6.by = lerp(T6.by, P.y - 6, Math.min(1, dt * 4));
      T6.fireT -= dt;
      if (T6.fireT <= 0) {
        const tg = T6.ko[o] || G.cutscene ? null : nearestTarget(P.range * 0.9);
        if (tg) {
          const H = HEROES[o], a = Math.atan2(tg.y - (tg.z || 0) - T6.by, tg.x - T6.bx);
          T6.fireT = 1.1 / (1 + 0.3 * lv('c6duo'));
          G.feathers.push({ x: T6.bx, y: T6.by - 8, vx: Math.cos(a) * H.projSpd, vy: Math.sin(a) * H.projSpd, dmg: P.dmg * 0.3, pierce: 0, life: 1.0, hit: [], kind: H.proj, ally: true });
        } else T6.fireT = 0.3;
      }
    }
    // костры: греют, лечат обеих и запоминают место
    G.nearFire = null;
    for (const f of fires) {
      if (Math.abs(f.x - P.x) > 120 || Math.abs(f.y - P.y) > 120 || Math.hypot(f.x - P.x, f.y - P.y) > 95) continue;
      G.nearFire = f;
      const warm = 1 + 0.5 * lv('c6warm');
      if (P.hp < P.maxHp) P.hp = Math.min(P.maxHp, P.hp + P.maxHp * 0.05 * warm * dt);
      if (T6) { const o = teamOther(); T6.f[o] = Math.min(1, T6.f[o] + 0.08 * warm * dt); }
      if (!G.activeBoss && !G.activeShrine && (G.cp.x !== f.x || G.cp.y !== f.y + 34)) {
        G.cp = { x: f.x, y: f.y + 34 };
        if (!f.lit) { f.lit = true; floatText(f.x, f.y - 40, '🔥 Костёр: здесь возродишься', '#ffd25a', true); Sound.sfx.magic(); saveGame(); }
      }
    }
    if (CFG.icedChests && !G.iceSaid && P.hero !== 'ryzhovaya') {
      for (const ch of chests) if (ch.iced && !ch.open && Math.hypot(ch.x - P.x, ch.y - P.y) < 210 && ringIntact(ch)) {
        G.iceSaid = true; say('Сундук вмёрз в лёд! Смени героиню 🔄 – огонь Рыжовой растопит стену.', 5); break;
      }
    }
    // погода: накатывает сама по себе, когда нет боя
    if (G.blizzardT > 0) G.blizzardT -= dt;
    if (CFG.weathers) {
      if (G.wxT > 0) { G.wxT -= dt; if (G.wxT <= 0 || G.activeBoss) { if (G.activeBoss && G.wxId === 'blizzard') G.blizzardT = Math.min(G.blizzardT, 0.5); G.wxId = null; G.wxT = 0; } }
      else if (!G.activeBoss && !G.activeShrine && !G.cutscene && P.y < PLAY_H * T) {
        G.blizT -= dt;
        if (G.blizT <= 0) { G.blizT = rnd(55, 85); startWeather(pick(CFG.weathers.filter(w => w !== G.lastWx))); }
      }
      if (G.wxId === 'starfall') {
        G.starT -= dt;
        if (G.starT <= 0) {
          G.starT = 0.55;
          for (let k = 0; k < 6; k++) {
            const a = rnd(0, TAU), r = rnd(40, 330), x = P.x + Math.cos(a) * r, y = P.y + Math.sin(a) * r;
            if (walkable(x, y, false)) { G.falling.push({ x, y, t: 0, dur: 1.1 }); break; }
          }
        }
      }
      if (G.wxId === 'frost') {
        const warmNear = !!G.nearFire;
        if (warmNear) G.chill = Math.max(0, G.chill - dt * 3);
        else if (!P.moving && P.dashT <= 0) G.chill += dt; else G.chill = Math.max(0, G.chill - dt * 1.5);
        if (G.chill > 1.2) {
          G.frostTick = (G.frostTick || 0) - dt; P.slowT = Math.max(P.slowT, 0.3);
          if (G.frostTick <= 0) {
            G.frostTick = 0.5;
            const d = P.maxHp * 0.025 * (lv('c6warm') ? 0.5 : 1);
            P.hp = Math.max(1, P.hp - d); dmgText(P.x, P.y - 30, d, '#9ad8ff');
            if (Math.random() < 0.3) floatText(P.x, P.y - 50, '🥶 двигайся!', '#bfeaff');
          }
        }
      } else G.chill = 0;
    }
    for (const st of G.falling) {
      st.t += dt;
      if (st.t >= st.dur && !st.done) {
        st.done = true; dropPickup(st.x, st.y, 'star'); burst(st.x, st.y, 14, '#ffe08a', 160);
        for (const e of G.enemies) if (!e.dead && (e.x - st.x) ** 2 + (e.y - st.y) ** 2 < 50 * 50) damageEnemy(e, rollHit(P.dmg * 2), 0, 0, false);
      }
    }
    G.falling = G.falling.filter(st => !st.done);
    if (G.cookieT > 0) G.cookieT -= dt;
    // пещеры: темнота, пока героиня внутри
    if (CFG.slides || CFG.currents) {
      const pb = P.y < PLAY_H * T ? biomeMap[clamp(Math.floor(P.y / T), 0, MH - 1) * MW + clamp(Math.floor(P.x / T), 0, MW - 1)] : -1;
      G.caveA = lerp(G.caveA || 0, pb >= 0 && BIOMES[pb].cave ? 1 : 0, Math.min(1, dt * 1.8));
      if (pb >= 0 && BIOMES[pb].cave && !G.caveSaid) { G.caveSaid = true; say('Тут темно! Огонь Рыжовой светит ярче перьев – смени героиню 🔥', 4.5); }
    }
    // тайные поляны: стена растаяла – поляна открыта
    for (const g of glades) {
      if (!g.seen && Math.abs(g.x - P.x) < 420 && Math.abs(g.y - P.y) < 420) g.seen = true;
      if (!g.open && g.ring.some(i => tiles[i] !== ROCK)) { g.open = true; floatText(g.x, g.y - 40, '✨ Тайная поляна!', '#ffe08a', true); Sound.sfx.magic(); }
      if (g.open && !g.done && g.kind === 'beast' && Math.hypot(g.x - P.x, g.y - P.y) < 260) {
        g.done = true;
        const e = spawnEnemy('snowleopard', g.x, g.y, biomeMap[g.ty * MW + g.tx], { elite: true, instant: true });
        e.gladeBeast = true; showBanner('🐆 Снежный барс!', 'Хозяин поляны охраняет добычу'); Sound.sfx.roar();
      }
    }
    // проруби: постой рядом – клюёт!
    G.fishing = null;
    for (const hl of holes) {
      if (hl.cd > 0) { hl.cd -= dt; continue; }
      const near = Math.hypot(P.x - hl.x, P.y - hl.y) < 48 && !G.activeBoss && !G.activeShrine && !P.moving;
      if (!near) { hl.prog = 0; continue; }
      G.fishing = hl; hl.prog += dt;
      if (hl.prog >= 1.6) {
        hl.prog = 0; hl.cd = 40;
        const r = Math.random();
        burst(hl.x, hl.y, 16, '#9ad8ff', 160); Sound.sfx.clue();
        if (r < 0.38) {
          const hp = Math.round(P.maxHp * 0.2); P.hp = Math.min(P.maxHp, P.hp + hp);
          if (T6) { const o = teamOther(); T6.f[o] = Math.min(1, T6.f[o] + 0.2); }
          floatText(hl.x, hl.y - 30, `🐟 Рыбка! +${hp}`, '#7dff7d', true);
        } else if (r < 0.58) { floatText(hl.x, hl.y - 30, '💎 Осколки со дна!', '#c77dff', true); for (let k = 0; k < 3; k++) dropShard(hl.x, hl.y + 20); }
        else if (r < 0.64) { floatText(hl.x, hl.y - 30, '🔑 Ключ на крючке!', '#ffd25a', true); dropPickup(hl.x, hl.y + 24, 'key'); }
        else if (r < 0.8) {
          floatText(hl.x, hl.y - 30, '😱 Щука-мимик!', '#ff8a8a', true);
          const e = spawnEnemy('pike', hl.x + 30, hl.y + 10, biomeMap[hl.ty * MW + hl.tx], { elite: true, instant: true }); e.pikeLoot = true; Sound.sfx.roar();
        } else { floatText(hl.x, hl.y - 30, '👢 Старый сапог… ну хоть опыт', '#c8c8c8', true); dropGem(hl.x, hl.y + 20, xpFor(zoneE(biomeMap[hl.ty * MW + hl.tx])) * 0.15); }
      }
    }
    // пряничная печка: печенька +25% урона на минуту
    G.baking = null;
    for (const ov of ovens) {
      if (ov.cd > 0) { ov.cd -= dt; continue; }
      const near = Math.hypot(P.x - ov.x, P.y - (ov.y + 20)) < 64 && !G.activeBoss && !P.moving;
      if (!near) { ov.prog = 0; continue; }
      G.baking = ov; ov.prog += dt;
      if (ov.prog >= 2) {
        ov.prog = 0; ov.cd = 90; G.cookieT = 60;
        floatText(ov.x, ov.y - 50, '🍪 Печенька! +25% урона на минуту', '#ffd25a', true); Sound.sfx.magic(); burst(ov.x, ov.y - 10, 20, '#ffd25a', 160);
      }
    }
    G.blizA = lerp(G.blizA || 0, G.blizzardT > 0 ? 1 : 0, Math.min(1, dt * 1.6));
    if (G.tessaAlly) {
      const A = G.tessaAlly;
      A.x = lerp(A.x, P.x + 36 * P.face, Math.min(1, dt * 3)); A.y = lerp(A.y, P.y + 6, Math.min(1, dt * 3));
      A.fireT -= dt;
      if (A.fireT <= 0) {
        const tg = nearestTarget(300);
        if (tg) {
          A.fireT = 0.6; const a = Math.atan2(tg.y - (tg.z || 0) - A.y, tg.x - A.x); A.face = Math.cos(a) >= 0 ? 1 : -1;
          G.feathers.push({ x: A.x, y: A.y - 8, vx: Math.cos(a) * 450, vy: Math.sin(a) * 450, dmg: P.dmg * 0.45, pierce: 1, life: 0.9, hit: [], kind: 'claw', ally: true });
        } else A.fireT = 0.25;
      }
    }
  }
  function drawCampfire(c, f, t) {
    const x = f.x, y = f.y;
    const g = c.createRadialGradient(x, y, 4, x, y, 90);
    g.addColorStop(0, 'rgba(255,170,60,0.32)'); g.addColorStop(1, 'rgba(255,170,60,0)');
    c.fillStyle = g; c.beginPath(); c.arc(x, y, 90, 0, TAU); c.fill();
    shadow(c, x, y + 10, 18, 5);
    c.fillStyle = '#8a8a9a'; for (let k = 0; k < 7; k++) { const a = k * TAU / 7; c.beginPath(); c.arc(x + Math.cos(a) * 15, y + 6 + Math.sin(a) * 6, 4, 0, TAU); c.fill(); }
    c.save(); c.translate(x, y + 4);
    c.fillStyle = '#6a3a1a'; c.strokeStyle = '#3a1a0a'; c.lineWidth = 1.5;
    for (const r of [0.5, -0.5]) { c.save(); c.rotate(r); c.fillRect(-14, -3, 28, 6); c.strokeRect(-14, -3, 28, 6); c.restore(); }
    c.restore();
    const fl = Math.sin(t * 13 + f.ph) * 2, fl2 = Math.sin(t * 17 + f.ph * 2) * 2;
    const flame = (w, h, col, dx) => { c.fillStyle = col; c.beginPath(); c.moveTo(x - w + dx, y + 2); c.quadraticCurveTo(x - w * 0.8 + dx, y - h * 0.5, x + dx + fl * 0.6, y - h); c.quadraticCurveTo(x + w * 0.8 + dx, y - h * 0.5, x + w + dx, y + 2); c.closePath(); c.fill(); };
    flame(11, 30 + fl, '#ff6a1f', 0); flame(8, 22 + fl2, '#ffb03a', 1); flame(4, 13 + fl, '#fff3b0', 0);
    if (Math.random() < 0.15) part(x + rnd(-6, 6), y - 18, rnd(-15, 15), rnd(-70, -40), 0.9, 3, '#ffd25a');
    if (f.lit) { c.fillStyle = '#ffd25a'; c.font = 'bold 11px sans-serif'; c.textAlign = 'center'; c.fillText('✓', x + 20, y - 18); }
  }
  function drawIceCage(c, x, y, t) {
    shadow(c, x, y + 30, 36, 9);
    drawHero('tessa', c, x, y + 14 + Math.sin(t * 2) * 2, t, 1, 1, 0.9, false);
    c.fillStyle = 'rgba(170,220,255,0.42)'; c.strokeStyle = 'rgba(255,255,255,0.85)'; c.lineWidth = 2;
    c.beginPath(); c.moveTo(x - 30, y + 30); c.lineTo(x - 36, y - 10); c.lineTo(x - 18, y - 48); c.lineTo(x + 4, y - 56); c.lineTo(x + 26, y - 40); c.lineTo(x + 36, y - 4); c.lineTo(x + 30, y + 30); c.closePath(); c.fill(); c.stroke();
    c.fillStyle = 'rgba(255,255,255,0.4)'; c.beginPath(); c.moveTo(x - 24, y + 20); c.lineTo(x - 28, y - 8); c.lineTo(x - 16, y - 38); c.lineTo(x - 12, y - 30); c.lineTo(x - 18, y + 20); c.closePath(); c.fill();
    if (Math.random() < 0.08) { c.fillStyle = '#ffffff'; star(c, x + rnd(-30, 30), y + rnd(-50, 20), 3, t, 4); c.fill(); }
  }
  function drawHole(c, hl, t) {
    c.fillStyle = 'rgba(214,240,255,0.95)'; c.beginPath(); c.ellipse(hl.x, hl.y + 4, 32, 15, 0, 0, TAU); c.fill();
    c.fillStyle = '#1b4a6a'; c.beginPath(); c.ellipse(hl.x, hl.y + 4, 21, 9, 0, 0, TAU); c.fill();
    c.strokeStyle = 'rgba(255,255,255,0.85)'; c.lineWidth = 2; c.stroke();
    if (hl.cd <= 0) { const k = (t * 0.8 + hl.x * 0.01) % 1; c.strokeStyle = `rgba(190,234,255,${1 - k})`; c.lineWidth = 1.5; c.beginPath(); c.ellipse(hl.x, hl.y + 4, 5 + k * 13, 2 + k * 5, 0, 0, TAU); c.stroke(); }
    else { c.fillStyle = 'rgba(255,255,255,0.5)'; c.beginPath(); c.ellipse(hl.x, hl.y + 4, 21 * (1 - hl.cd / 40), 9 * (1 - hl.cd / 40), 0, 0, TAU); c.fill(); }
    if (G.fishing === hl) {
      c.strokeStyle = '#8a5a2a'; c.lineWidth = 3; c.beginPath(); c.moveTo(P.x + 8 * P.face, P.y - 12); c.lineTo(hl.x + 6, hl.y - 36); c.stroke();
      c.strokeStyle = '#ffffff'; c.lineWidth = 1; c.beginPath(); c.moveTo(hl.x + 6, hl.y - 36); c.lineTo(hl.x, hl.y + 4 + Math.sin(t * 22) * 2); c.stroke();
      c.strokeStyle = '#ffd25a'; c.lineWidth = 4; c.beginPath(); c.arc(hl.x, hl.y - 52, 12, -Math.PI / 2, -Math.PI / 2 + TAU * hl.prog / 1.6); c.stroke();
    }
    if (hl.cd <= 0 && G.fishing !== hl && Math.hypot(P.x - hl.x, P.y - hl.y) < 160) { c.font = '14px sans-serif'; c.textAlign = 'center'; c.fillText('🎣', hl.x, hl.y - 22 + Math.sin(t * 3) * 3); }
  }
  function drawOven(c, ov, t) {
    const x = ov.x, y = ov.y;
    shadow(c, x, y + 24, 32, 8);
    c.fillStyle = '#b06a3a'; c.strokeStyle = '#6a3a1a'; c.lineWidth = 2.5;
    c.beginPath(); c.moveTo(x - 30, y + 22); c.lineTo(x - 30, y - 4); c.quadraticCurveTo(x, y - 48, x + 30, y - 4); c.lineTo(x + 30, y + 22); c.closePath(); c.fill(); c.stroke();
    c.strokeStyle = 'rgba(0,0,0,0.18)'; c.lineWidth = 1.5; for (let k = 0; k < 3; k++) { c.beginPath(); c.moveTo(x - 29, y + 14 - k * 9); c.lineTo(x + 29, y + 14 - k * 9); c.stroke(); }
    c.strokeStyle = '#ffffff'; c.lineWidth = 3; c.beginPath(); for (let k = 0; k < 5; k++) { const a = Math.PI + (k + 0.5) * Math.PI / 5; c.moveTo(x + Math.cos(a) * 26, y - 4 + Math.sin(a) * 34); c.quadraticCurveTo(x + Math.cos(a + 0.2) * 22, y + 2 + Math.sin(a + 0.2) * 30, x + Math.cos(a + 0.4) * 26, y - 4 + Math.sin(a + 0.4) * 34); } c.stroke();
    c.fillStyle = '#7a4a2a'; c.fillRect(x + 12, y - 40, 9, 16);
    const ready = ov.cd <= 0, glow = ready ? 0.7 + Math.sin(t * 6 + ov.ph) * 0.2 : 0.15;
    c.fillStyle = `rgba(255,${ready ? 150 : 60},40,${glow})`; c.beginPath(); c.moveTo(x - 12, y + 22); c.lineTo(x - 12, y + 8); c.quadraticCurveTo(x, y - 6, x + 12, y + 8); c.lineTo(x + 12, y + 22); c.closePath(); c.fill();
    if (ready && Math.random() < 0.06) part(x + 16, y - 42, rnd(-6, 6), -40, 1.4, 7, 'rgba(230,230,230,0.6)');
    for (const [dx, dy, col] of [[-20, 10, '#e53935'], [20, 10, '#43a047'], [0, -20, '#ff6fb5']]) { c.fillStyle = col; c.beginPath(); c.arc(x + dx, y + dy, 2.5, 0, TAU); c.fill(); }
    if (G.baking === ov) { c.strokeStyle = '#ffd25a'; c.lineWidth = 4; c.beginPath(); c.arc(x, y - 62, 12, -Math.PI / 2, -Math.PI / 2 + TAU * ov.prog / 2); c.stroke(); c.font = '13px sans-serif'; c.textAlign = 'center'; c.fillText('🍪', x, y - 57); }
    else if (ready && Math.hypot(P.x - x, P.y - y) < 200) { c.font = '15px sans-serif'; c.textAlign = 'center'; c.fillText('🍪', x, y - 56 + Math.sin(t * 3) * 3); }
  }
  function drawDrift(c, dr, t) {
    const k = (0.55 + 0.45 * dr.hp / 3) * dr.s, x = dr.x, y = dr.y;
    shadow(c, x, y + 8, 24 * k, 6 * k);
    c.fillStyle = '#d8e8f6'; c.beginPath(); c.ellipse(x, y + 4, 26 * k, 12 * k, 0, Math.PI, TAU); c.fill();
    c.fillStyle = '#f4faff'; c.beginPath(); c.ellipse(x - 6 * k, y + 2, 18 * k, 14 * k, 0, Math.PI, TAU); c.fill(); c.beginPath(); c.ellipse(x + 9 * k, y + 3, 14 * k, 10 * k, 0, Math.PI, TAU); c.fill();
    c.fillStyle = '#d8e8f6'; c.fillRect(x - 26 * k, y + 3, 52 * k, 3);
    if (Math.sin(t * 3 + x) > 0.9) { c.fillStyle = '#ffffff'; star(c, x + rnd(-14, 14) * k, y - 6 * k, 2.5, t, 4); c.fill(); }
  }
  // пещеры: темно, светят кристаллы, костры и огонь Рыжовой
  let caveCv = null;
  function drawCaveDark(c) {
    const A = G.caveA || 0;
    if (A < 0.02 || state === 'menu') return;
    if (!caveCv) caveCv = makeCanvas(1, 1);
    const w = Math.ceil(VW / 2), h = Math.ceil(VH / 2);
    if (caveCv.width !== w || caveCv.height !== h) { caveCv.width = w; caveCv.height = h; }
    const d = caveCv.getContext('2d');
    d.globalCompositeOperation = 'source-over'; d.clearRect(0, 0, w, h);
    d.fillStyle = `rgba(6,4,18,${0.86 * A})`; d.fillRect(0, 0, w, h);
    d.globalCompositeOperation = 'destination-out';
    const toS = (x, y) => [((x - G.cam.x) * ZOOM + VW / 2) / 2, ((y - G.cam.y) * ZOOM + VH / 2) / 2];
    const lights = [];
    const hole = (x, y, r, k) => {
      const [sx, sy] = toS(x, y), rr = r * ZOOM / 2;
      if (sx < -rr || sy < -rr || sx > w + rr || sy > h + rr) return false;
      const g = d.createRadialGradient(sx, sy, rr * 0.3, sx, sy, rr);
      g.addColorStop(0, `rgba(0,0,0,${k})`); g.addColorStop(1, 'rgba(0,0,0,0)');
      d.fillStyle = g; d.beginPath(); d.arc(sx, sy, rr, 0, TAU); d.fill();
      return true;
    };
    hole(P.x, P.y, P.proj === 'fire' ? 310 : 200, 0.95);
    if (G.team) hole(G.team.bx, G.team.by, G.team.list.find(id => id !== P.hero) === 'ryzhovaya' ? 140 : 70, 0.7);
    for (const f of fires) hole(f.x, f.y, 180, 0.95);
    for (const f of G.feathers) if (f.kind === 'fire') hole(f.x, f.y, 70, 0.6);
    const vw = VW / ZOOM, vh = VH / ZOOM, tx0 = Math.max(0, Math.floor((G.cam.x - vw / 2) / T) - 2), tx1 = Math.min(MW - 1, Math.floor((G.cam.x + vw / 2) / T) + 2);
    const ty0 = Math.max(0, Math.floor((G.cam.y - vh / 2) / T) - 2), ty1 = Math.min(MH - 1, Math.floor((G.cam.y + vh / 2) / T) + 3);
    for (let ty = ty0; ty <= ty1; ty++) for (let tx = tx0; tx <= tx1; tx++) {
      const ti = treeGrid[ty * MW + tx]; if (!ti) continue;
      const tr = trees[ti - 1]; if (tr.kind !== 'crystal') continue;
      if (hole(tr.x, tr.y - 20, 130, 0.75 + Math.sin(G.time * 2 + tr.x) * 0.1)) lights.push(tr);
    }
    d.globalCompositeOperation = 'source-over';
    c.save(); c.setTransform(DPR, 0, 0, DPR, 0, 0); c.imageSmoothingEnabled = true;
    c.drawImage(caveCv, 0, 0, VW, VH);
    c.globalCompositeOperation = 'lighter';
    for (const tr of lights) {
      const [sx, sy] = toS(tr.x, tr.y - 20), X = sx * 2, Y = sy * 2, R = 110 * ZOOM;
      const g = c.createRadialGradient(X, Y, 4, X, Y, R); g.addColorStop(0, `rgba(150,110,255,${0.22 * A})`); g.addColorStop(1, 'rgba(150,110,255,0)');
      c.fillStyle = g; c.fillRect(X - R, Y - R, R * 2, R * 2);
    }
    c.globalCompositeOperation = 'source-over';
    for (const e of G.enemies) {
      if (e.dead || e.spawnT > 0) continue;
      const [sx, sy] = toS(e.x, e.y), X = sx * 2, Y = sy * 2;
      if (X < 0 || Y < 0 || X > VW || Y > VH || Math.sin(e.t * 2 + e.seed * 7) > 0.96) continue;
      c.globalAlpha = A; c.fillStyle = '#ff5bf0'; c.fillRect(X - 4, Y - 7, 2.5, 2.5); c.fillRect(X + 2, Y - 7, 2.5, 2.5);
    }
    c.globalAlpha = 1;
    c.restore();
    if (G.caveA > 0.5) for (const hz of G.hazards) drawHazard(c, hz);
  }
  let snowCv = null;
  function drawBlizzard(c) {
    const A = G.blizA || 0;
    if (A < 0.02) return;
    if (!snowCv) snowCv = makeCanvas(1, 1);
    const w = Math.ceil(VW / 2), h = Math.ceil(VH / 2);
    if (snowCv.width !== w || snowCv.height !== h) { snowCv.width = w; snowCv.height = h; }
    const d = snowCv.getContext('2d');
    d.globalCompositeOperation = 'source-over'; d.clearRect(0, 0, w, h);
    d.fillStyle = `rgba(232,242,252,${0.68 * A})`; d.fillRect(0, 0, w, h);
    d.globalCompositeOperation = 'destination-out';
    const toS = (x, y) => [((x - G.cam.x) * ZOOM + VW / 2) / 2, ((y - G.cam.y) * ZOOM + VH / 2) / 2];
    const hole = (x, y, r, k) => {
      const [sx, sy] = toS(x, y), rr = r * ZOOM / 2;
      if (sx < -rr || sy < -rr || sx > w + rr || sy > h + rr) return;
      const g = d.createRadialGradient(sx, sy, rr * 0.3, sx, sy, rr);
      g.addColorStop(0, `rgba(0,0,0,${k})`); g.addColorStop(1, 'rgba(0,0,0,0)');
      d.fillStyle = g; d.beginPath(); d.arc(sx, sy, rr, 0, TAU); d.fill();
    };
    hole(P.x, P.y, G.activeBoss ? 300 : 200, 0.92);
    for (const f of fires) hole(f.x, f.y, 170, 0.95);
    d.globalCompositeOperation = 'source-over';
    c.save(); c.setTransform(DPR, 0, 0, DPR, 0, 0); c.imageSmoothingEnabled = true;
    c.drawImage(snowCv, 0, 0, VW, VH);
    c.strokeStyle = `rgba(255,255,255,${0.75 * A})`; c.lineWidth = 2; c.beginPath();
    const tt = G.time;
    for (let k = 0; k < 90; k++) {
      const sx = ((hash2(k, 3) * VW * 1.4 + tt * (420 + hash2(k, 9) * 260)) % (VW * 1.4)) - VW * 0.2;
      const sy = ((hash2(k, 7) * VH + tt * (140 + hash2(k, 5) * 120)) % VH);
      c.moveTo(sx, sy); c.lineTo(sx - 16, sy - 6);
    }
    c.stroke();
    c.restore();
  }

  // ------------------------------------------------------------------
  //  Финал главы 4: хорошая или добрая?
  // ------------------------------------------------------------------
  function openChoice(fromMenu) { G.choiceFromMenu = !!fromMenu; setState('choice'); Sound.music('night4'); }
  function finishCh4(ch) {
    if (NET.host && G.netRun) NetT.send(-1, { t: 'c4', ch });
    const prof = loadProfile(); prof.ch4Choice = ch; prof.ch4Seen = prof.ch4Seen || {}; prof.ch4Seen[ch] = 1; saveProfile(prof);
    unlockOutfit('bow');
    // игру закрыли на экране выбора – спрашиваем ещё раз из меню, без экрана победы
    if (G.choiceFromMenu) { G.choiceFromMenu = false; openMenu(); toast(ch === 'kind' ? '💗 Добрая кошка. Мяу.exe приручён' : '🛡️ Хорошая кошка. Дом спасён'); return; }
    if (ch === 'kind') Sound.sfx.purr(); else Sound.sfx.win();
    showVictory(ch);
  }
  // ------------------------------------------------------------------
  //  Глава 5: доска подозреваемых
  // ------------------------------------------------------------------
  function openBoard() {
    setState('board'); G.accused = false;
    const list = $('boardClues'); list.innerHTML = '';
    for (const q of clues) if (q.found) { const [ic, txt] = CLUES5[q.i][q.k]; const el = document.createElement('div'); el.className = 'bclue'; el.textContent = `${ic} ${txt}`; list.appendChild(el); }
    const sus = $('boardSus'); sus.innerHTML = '';
    for (const s of SUSPECTS) {
      const el = document.createElement('button'); el.className = 'bsus'; el.innerHTML = `<span>${s.ic}</span>${s.name}`;
      el.addEventListener('click', () => { Sound.sfx.click(); accuse(s); }); sus.appendChild(el);
    }
    $('boardResult').innerHTML = ''; $('boardGo').classList.add('hidden');
    Sound.sfx.magic();
  }
  function accuse(s) {
    if (G.accused) return; G.accused = true;
    const ok = s.id === 'zyama', prof = loadProfile(); prof.ch5Accuse = s.id; saveProfile(prof);
    G.boardPending = false; saveGame();
    const wrong = { baron: 'Барон обиженно гавкнул.', cucumber: 'Огурец покраснел. Насколько огурцы умеют.', laserdot: 'Точка смущённо замигала.', pigeonboss: 'Голубь поправил шляпу: «Курлык, не мы».' };
    $('boardResult').innerHTML = ok ? '🎯 Точно! Блёстки, какао, ода и программка «Режиссёр – З.»… Это <b>Зямочкккк</b>!<br>Награда: улучшение, осколки и очки детектива 👓'
      : `🤔 ${s.name}? ${wrong[s.id] || ''}<br>Но все улики всё равно ведут в кладовую…`;
    for (const el of document.querySelectorAll('.bsus')) el.disabled = true;
    if (ok) { Sound.sfx.win(); for (let i = 0; i < 8; i++) dropShard(P.x + rnd(-40, 40), P.y + rnd(-40, 40)); G.pendingLv++; unlockOutfit('glasses'); } else Sound.sfx.hurt();
    $('boardGo').classList.remove('hidden');
  }
  // ------------------------------------------------------------------
  //  Глава 5: разговоры с жителями
  // ------------------------------------------------------------------
  function npcButtons(list) {
    const box = $('npcChoices'); box.innerHTML = '';
    for (const [label, fn] of list) { const el = document.createElement('button'); el.className = 'btn alt'; el.textContent = label; el.addEventListener('click', () => { Sound.sfx.click(); fn(); }); box.appendChild(el); }
  }
  function openNpc(n) {
    if (!n) return;
    G.talkN = n; setState('npc');
    $('npcIc').textContent = n.def.ic; $('npcName').textContent = n.def.name;
    npcPage(n.state === 'done' ? 'Спасибо ещё раз, Тесса! Заходи в гости. 💛' : n.def.greet);
  }
  function npcPage(text) {
    const n = G.talkN, it = qitems[n.ni], def = n.def;
    $('npcText').textContent = text;
    const opts = [];
    if (it.taken && n.state !== 'done') opts.push([`🎁 Вот: ${def.item.ic} ${def.item.name}!`, () => { n.state = 'done'; npcReward(n); npcPage(def.thanks); }]);
    opts.push(['🔎 Кто взял корм?', () => { G.revealT = 120; npcPage(def.hint + '\n\n(Ближайшие улики теперь мигают на мини-карте)'); }]);
    if (n.state === 'new') opts.push(['🤝 Тебе нужна помощь?', () => npcQuest(n)]);
    opts.push(['😽 Потереться носом', () => { P.hp = Math.min(P.maxHp, P.hp + P.maxHp * 0.15); Sound.sfx.purr(); npcPage(def.pet); }]);
    opts.push(['👋 Пока!', () => setState('play')]);
    npcButtons(opts);
  }
  function npcQuest(n) {
    const def = n.def;
    $('npcText').textContent = def.quest;
    npcButtons([
      ['Найду! 🐾', () => { n.state = 'quest'; qitems[n.ni].active = true; setState('play'); showBanner(`${def.item.ic} Поручение`, `Найди: ${def.item.name} – отмечено на мини-карте`); saveGame(); }],
      ['Потом', () => npcPage(def.greet)],
    ]);
  }
  function npcReward(n) {
    Sound.sfx.chest();
    for (let i = 0; i < 6; i++) dropShard(P.x + rnd(-40, 40), P.y + rnd(-40, 40));
    dropPickup(P.x, P.y + 40, 'heart'); addSuper(25);
    unlockOutfit('bell');
    if (G.st) G.st.quests = (G.st.quests || 0) + 1;
    saveGame();
  }
  // ------------------------------------------------------------------
  //  Гардероб Тессы
  // ------------------------------------------------------------------
  function unlockOutfit(id) {
    const prof = loadProfile(); prof.wardrobe = prof.wardrobe || { own: {}, on: 'none' };
    if (prof.wardrobe.own[id]) return;
    prof.wardrobe.own[id] = 1;
    if (!prof.wardrobe.on || prof.wardrobe.on === 'none') { prof.wardrobe.on = id; TESSA_OUTFIT = id; }
    saveProfile(prof);
    const w = WARDROBE.find(x => x.id === id);
    if (w) toast(`🎀 Новый наряд для Тессы: ${w.ic} ${w.name}!`);
  }
  let wardBack = 'menu';
  function openWardrobe() { wardBack = state === 'wardrobe' ? wardBack : state; setState('wardrobe'); renderWardrobe(); }
  function renderWardrobe() {
    const prof = loadProfile(), wd = prof.wardrobe || { own: {}, on: 'none' };
    const box = $('wardList'); box.innerHTML = '';
    for (const w of WARDROBE) {
      const own = w.id === 'none' || DEBUG || wd.own[w.id], on = (wd.on || 'none') === w.id;
      const el = document.createElement('button'); el.className = 'ward' + (on ? ' on' : '') + (own ? '' : ' lock');
      el.innerHTML = `<span>${own ? w.ic : '🔒'}</span><b>${w.name}</b><i>${own ? (on ? 'надето' : 'надеть') : w.how}</i>`;
      el.addEventListener('click', () => {
        Sound.sfx.click();
        if (!own) { toast('🔒 ' + w.how); return; }
        const p2 = loadProfile(); p2.wardrobe = p2.wardrobe || { own: {}, on: 'none' }; p2.wardrobe.on = w.id; saveProfile(p2);
        TESSA_OUTFIT = w.id; renderWardrobe();
      });
      box.appendChild(el);
    }
    const cv = $('wardPreview'), c2 = cv.getContext('2d'); c2.clearRect(0, 0, 200, 200);
    const g = c2.createRadialGradient(100, 100, 10, 100, 100, 100); g.addColorStop(0, '#3a5a9a'); g.addColorStop(1, '#0a1428');
    c2.fillStyle = g; c2.beginPath(); c2.arc(100, 100, 98, 0, TAU); c2.fill();
    drawTessa(c2, 92, 140, 0.4, 1, 4.6, 1, false);
  }


  // ------------------------------------------------------------------
  //  Большая карта (нажми на мини-карту)
  // ------------------------------------------------------------------
  // большая карта: приближение двумя пальцами (или «+ / −», двойной тап), перетаскивание одним пальцем
  const MV = { z: 1, cx: 0, cy: 0, S: 0, ptrs: new Map(), pinch: null, lastTap: 0, raf: 0 };
  function openMap() {
    setState('mapscr'); Sound.sfx.click();
    const cv = $('mapCanvas'), d = Math.min(window.devicePixelRatio || 1, 2);
    const land = VW > VH && VH < 540; // лёжа: карта слева во всю высоту, легенда справа
    const S = Math.max(160, Math.floor(land ? Math.min(VH - 36, VW - 420) : Math.min(VW - 24, VH - 240)));
    cv.style.width = S + 'px'; cv.style.height = S + 'px'; cv.width = Math.round(S * d); cv.height = Math.round(S * d);
    MV.S = S; MV.d = d; MV.ptrs.clear(); MV.pinch = null;
    MV.cx = P.x; MV.cy = P.y; // приближение сохраняется, а смотрим туда, где героиня
    clampMapView(); drawMap();
    $('mapTitle').textContent = `🗺️ ${CFG.title || ''} · ${CFG.name}`;
    buildMapLegend();
    // подсказка про жесты – плашкой на карте, сама пропадает (первые три раза)
    MV.hintN = (MV.hintN || 0) + 1; const hint = $('mapHint');
    hint.classList.remove('show'); if (MV.hintN <= 3) { void hint.offsetWidth; hint.classList.add('show'); }
  }
  function clampMapView() {
    MV.z = clamp(MV.z, 1, 4);
    const hw = WORLD_W / MV.z / 2, hh = PLAY_H * T / MV.z / 2;
    MV.cx = clamp(MV.cx, hw, WORLD_W - hw); MV.cy = clamp(MV.cy, hh, PLAY_H * T - hh);
  }
  // точка на карте (пиксели холста) ↔ точка мира
  const mapK = () => MV.S / WORLD_W * MV.z;
  const mapX0 = () => MV.cx - WORLD_W / MV.z / 2, mapY0 = () => MV.cy - PLAY_H * T / MV.z / 2;
  function mapZoomAt(px, py, f) {
    const k = mapK(), wx = mapX0() + px / k, wy = mapY0() + py / k;
    MV.z = clamp(MV.z * f, 1, 4);
    const k2 = mapK();
    MV.cx = wx - px / k2 + WORLD_W / MV.z / 2; MV.cy = wy - py / k2 + PLAY_H * T / MV.z / 2;
    clampMapView(); requestMapDraw();
  }
  function requestMapDraw() { if (!MV.raf) MV.raf = requestAnimationFrame(() => { MV.raf = 0; if (state === 'mapscr') drawMap(); }); }
  function drawMap() {
    const cv = $('mapCanvas'), S = MV.S, c = cv.getContext('2d');
    c.setTransform(MV.d, 0, 0, MV.d, 0, 0); c.clearRect(0, 0, S, S);
    const k = mapK(), x0 = mapX0(), y0 = mapY0(), mw = MW / MV.z, mh = PLAY_H / MV.z;
    c.imageSmoothingEnabled = false;
    c.drawImage(miniBase, x0 / T, y0 / T, mw, mh, 0, 0, S, S);
    c.globalAlpha = 0.85; c.drawImage(fog, x0 / T, y0 / T, mw, mh, 0, 0, S, S); c.globalAlpha = 1; c.imageSmoothingEnabled = true;
    const zs = Math.min(1.9, 1 + (MV.z - 1) * 0.3); // значки чуть крупнее при приближении
    const X = x => (x - x0) * k, Y = y => (y - y0) * k;
    const pos = MV.pos = {}, at = (kind, x, y) => (pos[kind] = pos[kind] || []).push([X(x), Y(y)]);
    const icon = (ch, x, y, sz = 14, kind) => { if (kind) at(kind, x, y); c.font = Math.round(sz * zs) + 'px sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(ch, X(x), Y(y)); };
    for (const ch of chests) if (chestOnMap(ch)) { // сундучок: тёмная обводка, цвет – дерево, серебро или золото
      at('chest', ch.x, ch.y);
      const cx = X(ch.x), cy = Y(ch.y), u = zs;
      c.fillStyle = '#1a1020'; c.fillRect(cx - 4.5 * u, cy - 3.5 * u, 9 * u, 7 * u);
      c.fillStyle = ch.tier === 'gold' ? '#ffd25a' : ch.tier === 'silver' ? '#e0eaff' : '#c8945a'; c.fillRect(cx - 3.5 * u, cy - 2.5 * u, 7 * u, 5 * u);
      c.fillStyle = 'rgba(0,0,0,0.45)'; c.fillRect(cx - 3.5 * u, cy - 0.5 * u, 7 * u, u);
    }
    for (const sh of shrines) icon(sh.state === 'done' ? '🌀' : '⛩', sh.x, sh.y, 13, 'shrine');
    for (const bd of beds) icon('🛏', bd.x, bd.y, 11, 'bed');
    for (const f of fires) if (!f.glade) icon('🔥', f.x, f.y, 12, 'fire');
    for (const hl of holes) icon('🎣', hl.x, hl.y, 12, 'hole');
    for (const ov of ovens) icon('🍪', ov.x, ov.y, 12, 'oven');
    for (const q of pearls) if (!q.got) icon('💗', q.x, q.y, 12, 'pearl');
    if (NET.on && G.netRun) for (const m of NET.mates.values()) if (m.tx !== undefined) icon(m.down ? '💫' : MATE_EMO[(m.id - 1) % MATE_EMO.length], m.x, m.y, 14, 'mate');
    for (const g of glades) if (g.seen) icon(g.open ? '🌲' : '✨', g.x, g.y, 13, 'glade');
    for (const n of npcs) icon(n.def.ic, n.x, n.y, 13, 'npc');
    for (const q of clues) if (!q.found && (G.clearSight || G.revealT > 0 || (G.pet && Math.hypot(q.x - P.x, q.y - P.y) < 700) || Math.hypot(q.x - P.x, q.y - P.y) < 350 * lv('c5nose'))) icon('🔎', q.x, q.y, 11, 'clue');
    for (const it of qitems) if (it.active && !it.taken) icon(NPCS5[it.ni].item.ic, it.x, it.y, 12, 'npc');
    for (const b of bosses) { if (CFG.rush && G.rush && b.id !== G.rush.idx) continue; icon(b.def.immortal ? '♾️' : b.state === 'dead' ? '✅' : '💀', b.hx, b.hy, 15, 'boss'); }
    if (!CFG.noCage || (CFG.team && !G.tessaAlly)) icon('❤️', tc(CAGE.x), tc(CAGE.y), 13, 'cage');
    if (!CFG.rush) icon('🏠', tc(START.x), tc(START.y), 13, 'start');
    if (G.champ && !G.champ.dead) icon('👑', G.champ.x, G.champ.y, 15, 'champ');
    if (G.ev && G.ev.def.id === 'treasure') icon('❌', G.ev.tx, G.ev.ty, 14, 'treasure');
    if (!CFG.rush) {
      const o = objective(); at('goal', o.x, o.y);
      c.strokeStyle = '#d6f03a'; c.lineWidth = 2; c.setLineDash([4, 4]); c.beginPath(); c.moveTo(X(P.x), Y(P.y)); c.lineTo(X(o.x), Y(o.y)); c.stroke(); c.setLineDash([]);
    }
    c.fillStyle = '#ffffff'; c.strokeStyle = '#000000'; c.lineWidth = 2; c.beginPath(); c.arc(X(P.x), Y(P.y), 6 * Math.min(1.5, zs), 0, TAU); c.fill(); c.stroke();
    at('you', P.x, P.y);
    c.textBaseline = 'alphabetic';
    // нажали на плитку легенды – эти места пульсируют кольцами 3 секунды
    if (MV.hl) {
      const t = (performance.now() - MV.hl.t0) / 1000;
      if (t < 3) {
        for (const [x, y] of pos[MV.hl.kind] || []) for (let k = 0; k < 2; k++) {
          const ph = (t * 1.4 + k * 0.5) % 1;
          c.strokeStyle = `rgba(255,225,120,${1 - ph})`; c.lineWidth = 3 - ph * 2; c.beginPath(); c.arc(x, y, 8 + ph * 18, 0, TAU); c.stroke();
        }
        requestMapDraw();
      } else MV.hl = null;
    }
    $('mapZoomOut').disabled = MV.z <= 1.01; $('mapZoomIn').disabled = MV.z >= 3.99;
    $('mapZoomLbl').textContent = MV.z > 1.01 ? `×${MV.z.toFixed(1).replace('.0', '')}` : '';
  }
  // легенда: плитки «значок · название · сколько», только то, что есть в главе; нажатие подсвечивает места на карте
  function buildMapLegend() {
    const box = $('mapLegend'); box.innerHTML = '';
    const items = [];
    const live = bosses.filter(b => !(CFG.rush && G.rush && b.id !== G.rush.idx));
    if (live.length) items.push(['boss', '💀', CFG.rush ? 'Босс' : 'Стражи', CFG.rush ? '' : `${live.filter(b => b.state === 'dead').length}/${live.length}`]);
    if (!CFG.noCage || (CFG.team && !G.tessaAlly)) items.push(['cage', '❤️', CFG.team ? 'Тесса' : 'Клетка', '']);
    const nc = chests.filter(chestOnMap).length;
    if (nc) items.push(['chest', '<i class="lgChest"><b class="w"></b><b class="s"></b><b class="g"></b></i>', 'Сундуки', String(nc)]);
    const open = shrines.filter(sh => sh.state !== 'done').length, done = shrines.length - open;
    if (open) items.push(['shrine', '⛩', 'Испытания', String(open)]);
    if (done) items.push(['shrine', '🌀', 'Порталы', String(done)]);
    if (beds.length) items.push(['bed', '🛏', 'Лежанки', String(beds.length)]);
    if (fires.some(f => !f.glade)) items.push(['fire', '🔥', 'Костры', '']);
    if (holes.length) items.push(['hole', '🎣', 'Проруби', '']);
    if (ovens.length) items.push(['oven', '🍪', 'Печки', '']);
    if (pearls.length) items.push(['pearl', '💗', 'Слова', `${pearls.filter(q => q.got).length}/${pearls.length}`]);
    if (glades.some(g => g.seen)) items.push(['glade', '✨', 'Поляны', '']);
    if (npcs.length) items.push(['npc', '🙂', 'Жители', '']);
    if (clues.some(q => !q.found)) items.push(['clue', '🔎', 'Улики', '']);
    if (G.champ && !G.champ.dead) items.push(['champ', '👑', 'Чемпион', '']);
    if (G.ev && G.ev.def.id === 'treasure') items.push(['treasure', '❌', 'Клад', '']);
    if (!CFG.rush) items.push(['goal', '<i class="lgPath"></i>', 'Куда идти', '']);
    if (!CFG.rush) items.push(['start', '🏠', 'Старт', '']);
    items.push(['you', '<i class="lgYou"></i>', 'Ты', '']);
    for (const [kind, ic, name, n] of items) {
      const b = document.createElement('button'); b.className = 'lg';
      b.innerHTML = `<span class="lgIc">${ic}</span><span class="lgTx">${name}</span>${n ? `<em>${n}</em>` : ''}`;
      b.addEventListener('click', () => {
        Sound.sfx.click();
        if (kind === 'you') { MV.cx = P.x; MV.cy = P.y; clampMapView(); }
        MV.hl = { kind, t0: performance.now() }; requestMapDraw();
        for (const o of box.children) o.classList.toggle('on', o === b);
        setTimeout(() => b.classList.remove('on'), 3000);
      });
      box.appendChild(b);
    }
  }
  function mapPos(e) { const r = $('mapCanvas').getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; }
  function initMapGestures() {
    const cv = $('mapCanvas');
    cv.addEventListener('pointerdown', e => {
      try { cv.setPointerCapture(e.pointerId); } catch (err) { /* не страшно – двигаем и без захвата */ }
      const p = mapPos(e); MV.ptrs.set(e.pointerId, p);
      if (MV.ptrs.size === 2) { const [a, b] = [...MV.ptrs.values()]; MV.pinch = { d: Math.hypot(a.x - b.x, a.y - b.y) || 1, mx: (a.x + b.x) / 2, my: (a.y + b.y) / 2 }; }
      else if (MV.ptrs.size === 1) { // двойной тап – приблизить (или вернуть всю карту)
        const now = performance.now();
        if (now - MV.lastTap < 300) { if (MV.z >= 3.9) { MV.z = 1; clampMapView(); requestMapDraw(); } else mapZoomAt(p.x, p.y, 2); MV.lastTap = 0; }
        else MV.lastTap = now;
      }
    });
    cv.addEventListener('pointermove', e => {
      if (!MV.ptrs.has(e.pointerId)) return;
      const prev = MV.ptrs.get(e.pointerId), p = mapPos(e); MV.ptrs.set(e.pointerId, p);
      if (MV.ptrs.size >= 2 && MV.pinch) {
        const [a, b] = [...MV.ptrs.values()], d = Math.hypot(a.x - b.x, a.y - b.y) || 1, mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2;
        const k = mapK(); MV.cx -= (mx - MV.pinch.mx) / k; MV.cy -= (my - MV.pinch.my) / k; // двигаем вместе с пальцами
        mapZoomAt(mx, my, d / MV.pinch.d);
        MV.pinch = { d, mx, my };
      } else if (MV.ptrs.size === 1 && MV.z > 1) {
        const k = mapK(); MV.cx -= (p.x - prev.x) / k; MV.cy -= (p.y - prev.y) / k; clampMapView(); requestMapDraw();
      }
    });
    const up = e => { MV.ptrs.delete(e.pointerId); if (MV.ptrs.size < 2) MV.pinch = null; };
    cv.addEventListener('pointerup', up); cv.addEventListener('pointercancel', up);
    cv.addEventListener('wheel', e => { e.preventDefault(); const p = mapPos(e); mapZoomAt(p.x, p.y, e.deltaY < 0 ? 1.25 : 0.8); }, { passive: false });
    onTap('mapZoomIn', () => mapZoomAt(MV.S / 2, MV.S / 2, 1.6));
    onTap('mapZoomOut', () => mapZoomAt(MV.S / 2, MV.S / 2, 1 / 1.6));
  }
  function ensureWalkable(o) {
    if (walkable(o.x, o.y, false)) return;
    for (let r = 1; r < 40; r++) for (let a = 0; a < 16; a++) {
      const x = o.x + Math.cos(a / 16 * TAU) * r * T * 0.5, y = o.y + Math.sin(a / 16 * TAU) * r * T * 0.5;
      if (walkable(x, y, false)) { o.x = x; o.y = y; return; }
    }
  }


  // ------------------------------------------------------------------
  //  Испытания: карманная «инфернальная» арена под картой
  // ------------------------------------------------------------------
  function enterTrial(s) {
    const st = ARENA_STYLE[CHN] || ARENA_STYLE[1];
    s.state = 'active'; G.activeShrine = s; s.left = 0; G.trialT = 0;
    G.trialRet = { x: s.x, y: s.y + 60 };
    burst(P.x, P.y, 30, `rgb(${st.tint})`, 240);
    P.x = ARENA.x; P.y = ARENA.y; P.vx = 0; P.vy = 0; P.dashT = 0; P.inv = Math.max(P.inv, 1.2);
    G.ebullets.length = 0; G.hazards.length = 0; G.beams.length = 0;
    const coop = netCoop();
    const n = Math.min(64, Math.round((10 + CHN * 5 + Math.floor(P.level / 4)) * (coop ? 1 + 0.5 * netLiveMates() : 1))); // вместе – врагов больше
    for (let i = 0; i < n * 4 && s.left < n; i++) {
      const a = rnd(0, TAU), r = rnd(200, 360), x = ARENA.x + Math.cos(a) * r, y = ARENA.y + Math.sin(a) * r;
      const type = weighted(SPAWNS[s.biome]);
      if (!walkable(x, y, ENEMIES[type].fly)) continue;
      spawnEnemy(type, x, y, s.biome, { shrine: s, elite: s.left === 0 || Math.random() < CFG.elite * 2 * G.diff.elite });
      s.left++;
    }
    showBanner('⛩ ' + st.name, coop ? 'Все на арену! Победите всех – и вернётесь с наградой' : 'Победи всех – и вернёшься с наградой');
    if (coop) NetT.send(-1, { t: 'tr', si: shrines.indexOf(s), x: Math.round(ARENA.x), y: Math.round(ARENA.y), rx: Math.round(G.trialRet.x), ry: Math.round(G.trialRet.y), a: st.name });
    Sound.sfx.roar(); Sound.sfx.blink(); G.shake = 10; Sound.music('boss');
    shockRing(P.x, P.y, `rgb(${st.tint})`, 300);
  }
  function leaveArena() {
    burst(P.x, P.y, 24, '#ffffff', 200);
    // добыча из арены отправляется вместе с героиней
    const dx = G.trialRet.x - P.x, dy = G.trialRet.y - P.y;
    for (const p of G.pickups) if (p.y > PLAY_H * T) { p.x += dx; p.y += dy; p.pull = true; }
    P.x = G.trialRet.x; P.y = G.trialRet.y; ensureWalkable(P); P.inv = Math.max(P.inv, 1);
    G.ebullets.length = 0; G.hazards.length = 0; G.beams.length = 0;
    revealFog(P.x, P.y, 12); biomeMusic(true); Sound.sfx.blink();
    burst(P.x, P.y, 30, '#5be3ff', 240);
  }
  function completeTrial(s) {
    s.state = 'done'; G.activeShrine = null; life('trials'); dailyAdd(300);
    if (NET.host && G.netRun) NetT.send(-1, { t: 'trx', ok: 1, x: Math.round(G.trialRet.x), y: Math.round(G.trialRet.y) });
    if (G.st) G.st.shrines++;
    Sound.sfx.win();
    leaveArena();
    showBanner('Испытание пройдено!', 'Награда: улучшение и осколки');
    for (let i = 0; i < 6; i++) dropShard(P.x + rnd(-40, 40), P.y + rnd(-40, 40));
    dropPickup(P.x, P.y + 40, 'heart');
    addSuper(30);
    G.pendingLv++; openLevelUp();
    saveGame();
  }
  function failTrial(s) {
    s.state = 'idle'; G.activeShrine = null;
    if (NET.host && G.netRun) NetT.send(-1, { t: 'trx', ok: 0, x: Math.round(G.trialRet.x), y: Math.round(G.trialRet.y) });
    for (const e of G.enemies) if (e.shrine === s) e.dead = true;
    leaveArena();
    floatText(P.x, P.y - 40, 'Испытание провалено', '#ff8a8a', true);
  }
  function drawArenaExit(c) {
    if (!ARENA || !G.activeShrine) return;
    const ex = ARENA.exit, g = 0.5 + Math.sin(G.time * 4) * 0.3;
    c.fillStyle = `rgba(150,220,255,${0.15 + g * 0.15})`; c.beginPath(); c.arc(ex.x, ex.y, 26, 0, TAU); c.fill();
    c.strokeStyle = `rgba(190,240,255,${0.5 + g * 0.4})`; c.lineWidth = 3; c.beginPath(); c.arc(ex.x, ex.y, 22, 0, TAU); c.stroke();
    c.font = 'bold 10px sans-serif'; c.textAlign = 'center'; c.fillStyle = '#bfeaff'; c.fillText('ВЫХОД (провал)', ex.x, ex.y - 32);
  }


  // ------------------------------------------------------------------
  //  Сундуки, мимики, ключи и реликвии
  // ------------------------------------------------------------------
  function hasRelic(id) { return !!(G.relics && G.relics.includes(id)); }
  const relicLv = id => (hasRelic(id) ? Math.min(3, (G.relicLv && G.relicLv[id]) || 1) : 0);
  function chestReward(c, mult, by) {
    const R = CHEST_TIERS[c.tier] || CHEST_TIERS.wood, zl = zoneE(c.biome), v = xpFor(zl) / 14 * xpGap(P.level, zl);
    const luck = hasRelic('clover') ? 1.25 + 0.25 * relicLv('clover') : 1;
    for (let i = 0; i < R.gems * mult; i++) dropGem(c.x + rnd(-30, 30), c.y + rnd(-30, 30), v);
    for (let i = 0; i < Math.round(R.shards * mult * luck * (weekEv('gold') ? 2 : 1)); i++) dropShard(c.x, c.y);
    if (Math.random() < R.heart) dropPickup(c.x, c.y + 26, 'heart');
    if (Math.random() < R.magnet) dropPickup(c.x + 20, c.y + 20, 'magnet');
    if (R.super) { if (by) netEvent(by.id, ['sp', Math.round(R.super * mult)]); else addSuper(R.super * mult); }
    if (Math.random() < R.key * mult) dropPickup(c.x - 20, c.y + 20, 'key');
  }
  function openChest(c, by) {
    if (c.tier === 'gold') {
      if ((G.keys || 0) <= 0) {
        if ((G.keyMsgT || 0) <= 0) { G.keyMsgT = 2.5; floatText(c.x, c.y - 30, '🔒 Нужен ключ 🔑', '#ffd25a', true); Sound.sfx.block(); if (by) netEvent(by.id, ['txt', '🔒 Нужен ключ 🔑 (ключи общие)']); }
        return;
      }
      G.keys--; floatText(c.x, c.y - 34, '🔑 −1', '#ffd25a', true);
    }
    if (!c.mimic && c.tier !== 'gold' && !c.glade && weekEv('mimic') && Math.random() < 0.33) c.mimic = true; // нашествие мимиков
    c.open = true; buzz(30);
    if (!by) { life('chests'); dailyAdd(60); }
    if (c.mimic) { wakeMimic(c); return; }
    if (G.st) G.st.chests++;
    Sound.sfx.chest(); burst(c.x, c.y, 30, c.tier === 'gold' ? '#ffd25a' : c.tier === 'silver' ? '#e0eaff' : '#d8a060', 220);
    chestReward(c, 1, by);
    if (!by && Math.random() < (c.secret ? 0.3 : c.tier === 'gold' ? 0.25 : c.tier === 'silver' ? 0.05 : 0)) setTimeout(() => furnDrop(c.x, c.y), 600); // находка для домика
    if (!by && talent('golden') && Math.random() < 0.15 + 0.1 * Math.min(3, talent('golden'))) {
      chestReward(c, 1); floatText(c.x, c.y - 44, '💰 Золотая жила: ×2!', '#ffd25a', true); burst(c.x, c.y, 24, '#ffd25a', 200);
    }
    if (c.tier === 'gold') { if (by) netEvent(by.id, ['relic']); else G.relicPending = true; } // реликвию выбирает та, кто открыла
    saveGame();
  }
  function wakeMimic(c) {
    const e = spawnEnemy('mimic', c.x, c.y, c.biome, { instant: true });
    e.mimicOf = c; e.chn = CHN; e.hp = e.maxHp = e.maxHp * (c.tier === 'silver' ? 5 : 4); e.dmg *= 1.15;
    netBan('😱 Это мимик!', 'Победи его – награда будет двойной');
    Sound.sfx.roar(); G.shake = 10; burst(c.x, c.y, 24, '#a0623a', 200);
  }
  function mimicKilled(e) {
    const c = e.mimicOf; c.mimicDone = true; life('mimics'); if (weekEv('mimic')) life('spts', 10);
    if (!NET.hitBy && Math.random() < 0.15) setTimeout(() => furnDrop(e.x, e.y), 600);
    chestReward(c, 2);
    if (Math.random() < 0.25) dropPickup(e.x, e.y + 20, 'key');
    showBanner('Мимик побеждён!', 'Двойная награда'); Sound.sfx.chest();
    if (G.st) { G.st.mimics = (G.st.mimics || 0) + 1; G.st.chests++; }
    saveGame();
  }
  function updateRelics(dt) {
    if (G.guardT > 0) G.guardT -= dt;
    if (G.keyMsgT > 0) G.keyMsgT -= dt;
    if (G.relicPending && state === 'play' && !Dialog.talking) { G.relicPending = false; openRelicChoice(); return; }
    if (hasRelic('collar')) {
      G.thornT = (G.thornT || 0) - dt;
      if (G.thornT <= 0) {
        G.thornT = 0.5;
        for (const e of G.enemies) if (!e.dead && e.spawnT <= 0 && Math.hypot(e.x - P.x, e.y - P.y) < P.r + e.r + 6) damageEnemy(e, { v: P.dmg * (0.75 + 0.75 * relicLv('collar')), crit: false }, 0, 0, false);
      }
    }
    if (hasRelic('storm')) {
      G.stormRT = (G.stormRT === undefined ? 2.5 : G.stormRT) - dt;
      if (G.stormRT <= 0) {
        G.stormRT = 3 - 0.5 * relicLv('storm');
        const tg = nearestTarget(320);
        if (tg) { G.bolts.push({ pts: [[P.x, P.y - 30], [tg.x, tg.y - (tg.z || 0)]], t: 0.25, col: '190,230,255' }); hitAny(tg, rollHit(P.dmg * 3), 0, 0, false); Sound.sfx.bolt(); }
      }
    }
  }
  function openRelicChoice() {
    const owned = G.relics || [], lvs = loadProfile().relicLv || {};
    const pool = Object.keys(RELICS).filter(id => (lvs[id] || 0) < 3); // новые – и свои, которые ещё можно прокачать
    const opts = [];
    while (opts.length < 3 && pool.length) opts.push(pool.splice(Math.floor(Math.random() * pool.length), 1)[0]);
    if (!opts.length) { for (let i = 0; i < 12; i++) dropShard(P.x + rnd(-40, 40), P.y + rnd(-40, 40)); return; }
    const box = $('relicCards'); box.innerHTML = '';
    opts.forEach((id, i) => {
      const r = RELICS[id], el = document.createElement('button'), L = lvs[id] || 0;
      el.className = 'card' + (L ? ' rlUp' : ''); el.style.animationDelay = (i * 0.07) + 's';
      const tag = L ? `<div class="lv">⬆️ Уровень ${L} → ${L + 1}${owned.includes(id) ? ' · надета' : ' · из коллекции'}</div>` : '<div class="lv">✨ Новая</div>';
      el.innerHTML = `<div class="ic">${r.ic}</div><div><div class="nm">${r.name}</div><div class="ds">${relicDs(id, L + 1)}</div>${tag}</div>`;
      el.addEventListener('click', () => { Sound.sfx.click(); pickRelic(id); });
      box.appendChild(el);
    });
    $('relicSwap').classList.add('hidden');
    $('relicHint').textContent = `Выбери реликвию · носить можно ${relicMax()}, сейчас ${owned.length}`;
    setState('relic'); Sound.sfx.chest();
  }
  function pickRelic(id) {
    const pr = loadProfile(); pr.relicLv = pr.relicLv || {}; pr.relicSeen = pr.relicSeen || {};
    const L = Math.min(3, (pr.relicLv[id] || 0) + 1); pr.relicLv[id] = L; pr.relicSeen[id] = 1; saveProfile(pr);
    G.relicLv = Object.assign({}, pr.relicLv);
    if (L >= 3) life('relicMax');
    if ((G.relics || []).includes(id)) { // прокачали надетую
      computeStats(); setState('play');
      showBanner(`${RELICS[id].ic} ${RELICS[id].name} · ур. ${L}`, relicDs(id, L)); Sound.sfx.magic();
      return;
    }
    if ((G.relics || []).length < relicMax()) { addRelic(id); return; }
    $('relicHint').textContent = `${RELICS[id].ic} ${RELICS[id].name} – что заменить?`;
    const box = $('relicOwned'); box.innerHTML = '';
    for (const old of G.relics) {
      const r = RELICS[old], el = document.createElement('button');
      el.className = 'btn alt'; el.textContent = `${r.ic} ${r.name}`;
      el.addEventListener('click', () => { Sound.sfx.click(); G.relics = G.relics.filter(x => x !== old); addRelic(id); });
      box.appendChild(el);
    }
    const keep = document.createElement('button'); keep.className = 'btn gray'; keep.textContent = '🎒 Оставить в коллекции';
    keep.addEventListener('click', () => { Sound.sfx.click(); setState('play'); showBanner(`${RELICS[id].ic} ${RELICS[id].name} – в коллекции`, 'Надеть можно в меню: «Коллекция» → «Реликвии»'); });
    box.appendChild(keep);
    $('relicSwap').classList.remove('hidden');
  }
  function addRelic(id) {
    G.relics = (G.relics || []).concat(id).slice(-relicMax());
    const prof = loadProfile(); prof.relics = G.relics; prof.relicSeen = prof.relicSeen || {}; prof.relicSeen[id] = 1;
    prof.relicLv = prof.relicLv || {}; if (!prof.relicLv[id]) prof.relicLv[id] = 1; G.relicLv = Object.assign({}, prof.relicLv); saveProfile(prof);
    computeStats(); setState('play');
    showBanner(`${RELICS[id].ic} ${RELICS[id].name}` + (relicLv(id) > 1 ? ` · ур. ${relicLv(id)}` : ''), relicDs(id, relicLv(id))); Sound.sfx.magic();
    if (G.st) G.st.relics = (G.st.relics || 0) + 1;
  }

  // ------------------------------------------------------------------
  //  Сердечки в бою с боссом и «усмирённые» локации
  // ------------------------------------------------------------------
  const HEART_EVERY = { easy: 11, normal: 18, hard: 22 };
  function dropHeartNear(r0, r1) {
    for (let k = 0; k < 12; k++) {
      const a = rnd(0, TAU), r = rnd(r0, r1), x = P.x + Math.cos(a) * r, y = P.y + Math.sin(a) * r;
      if (!walkable(x, y, false)) continue;
      dropPickup(x, y, 'heart'); burst(x, y, 10, '#ff5b8a', 120); return;
    }
    dropPickup(P.x + rnd(-30, 30), P.y + 50, 'heart');
  }
  function updateBossHearts(dt) {
    const b = G.activeBoss;
    if (!b || b.state !== 'fight') return;
    G.bossHeartT -= dt * (P.hp < P.maxHp * 0.35 ? 2 : 1);
    if (G.bossHeartT > 0) return;
    G.bossHeartT = HEART_EVERY[G.diffId] || 12;
    dropHeartNear(130, 250);
  }
  // Усмирение: после победы над стражем его локация слабеет ступенями I–V.
  // Ступень растёт за убийства в этой локации, за каждую – награда.
  const CALM_STEPS = [0, 120, 350, 700, 1200], CALM_PCT = [0.10, 0.15, 0.20, 0.25, 0.30], ROMAN = ['I', 'II', 'III', 'IV', 'V'];
  const calmStage = biome => { const n = G.calm[biome] || 0; let s = 0; while (s < 4 && n >= CALM_STEPS[s + 1]) s++; return s; };
  const calmOf = biome => (G.calm && G.calm[biome] !== undefined) ? CALM_PCT[calmStage(biome)] : 0;
  function calmKill(biome) {
    if (!G.calm || G.calm[biome] === undefined || G.calm[biome] >= CALM_STEPS[4]) return;
    const before = calmStage(biome);
    G.calm[biome]++;
    const st = calmStage(biome);
    if (st <= before) return;
    showBanner(`🕊️ Усмирение ${ROMAN[st]}`, `${BIOMES[biome].name}: враги слабее на ${Math.round(CALM_PCT[st] * 100)}%`);
    Sound.sfx.chest();
    for (let i = 0; i < [0, 4, 6, 8, 12][st]; i++) dropShard(P.x + rnd(-40, 40), P.y + rnd(-40, 40));
    dropPickup(P.x, P.y + 40, 'heart');
    if (G.st) G.st.calmUps = (G.st.calmUps || 0) + 1;
    if (st >= 3) { G.pendingLv++; openLevelUp(); }
  }

  // ------------------------------------------------------------------
  //  Чемпионы: сильные бродячие мобы с наградой
  // ------------------------------------------------------------------
  function updateChampions(dt) {
    if (G.champ && (G.champ.dead || !G.enemies.includes(G.champ))) G.champ = null;
    if (G.champ) { if (Math.hypot(G.champ.x - P.x, G.champ.y - P.y) > 3200) { G.champ.dead = true; G.champ = null; } return; }
    if (CFG.rush || CFG.abyss || G.finalFinal || G.activeBoss || G.activeShrine || playerInCastle()) return;
    G.champT -= dt;
    if (G.champT > 0) return;
    G.champT = rnd(150, 210) * (weekEv('champ') ? 0.5 : 1);
    spawnChampion();
  }
  function spawnChampion() {
    const biome = curBiome();
    const types = (SPAWNS[biome] || []).map(s => s[0]).filter(t => !ENEMIES[t].group && ENEMIES[t].ai !== 'exploder' && ENEMIES[t].ai !== 'swarm');
    if (!types.length) return;
    for (let k = 0; k < 20; k++) {
      const a = rnd(0, TAU), r = rnd(450, 750), x = P.x + Math.cos(a) * r, y = P.y + Math.sin(a) * r;
      const type = pick(types), tx = Math.floor(x / T), ty = Math.floor(y / T);
      if (!inMap(tx, ty) || tiles[ty * MW + tx] === FLOOR || !walkable(x, y, ENEMIES[type].fly)) continue;
      const e = spawnEnemy(type, x, y, biome, { elite: true, instant: true });
      e.champion = true; e.hp = e.maxHp = e.maxHp * 6; e.dmg *= 1.2; e.r *= 1.2; e.xp *= 3; e.name = ENEMIES[type].name;
      G.champ = e;
      showBanner('👑 Чемпион!', `${e.name} бродит рядом – ищи корону на карте`);
      Sound.sfx.roar();
      return;
    }
  }

  // ------------------------------------------------------------------
  //  Порталы между пройденными алтарями
  // ------------------------------------------------------------------
  const portalHere = () => shrines.find(s => s.state === 'done' && Math.hypot(P.x - s.x, P.y - s.y) < 60);
  function openPortals() {
    const here = portalHere();
    if (!here) return;
    const dests = shrines.filter(s => s.state === 'done' && s !== here).map(s => ({ ic: '⛩', nm: 'Алтарь · ' + BIOMES[s.biome].name, x: s.x, y: s.y + 56 }));
    dests.push({ ic: '🏠', nm: 'Начало пути', x: tc(START.x), y: tc(START.y) });
    if (gateOpen) dests.push({ ic: '🏰', nm: 'Ворота замка', x: tc(GATE_FRONT.x), y: tc(GATE_FRONT.y) + 20 });
    for (const d of dests) d.dist = Math.round(Math.hypot(d.x - P.x, d.y - P.y) / PX_PER_M);
    dests.sort((a, b) => a.dist - b.dist);
    const list = $('portalList'); list.innerHTML = '';
    for (const d of dests) {
      const el = document.createElement('button'); el.className = 'btn alt';
      el.innerHTML = `${d.ic} ${d.nm} <small>· ${d.dist} м</small>`;
      el.addEventListener('click', () => { Sound.sfx.click(); portalTo(d); });
      list.appendChild(el);
    }
    setState('portal'); Sound.sfx.magic();
  }
  function portalTo(d) {
    burst(P.x, P.y, 30, '#c77dff', 220);
    P.x = d.x; P.y = d.y; P.inv = 1.2; P.vx = 0; P.vy = 0; P.dashT = 0;
    revealFog(P.x, P.y, 12);
    if (!NET.client) for (const e of G.enemies) if (!e.minion && !e.champion && Math.hypot(e.x - P.x, e.y - P.y) < 260) e.dead = true;
    burst(P.x, P.y, 40, '#c77dff', 260); shockRing(P.x, P.y, '#c77dff', 200);
    Sound.sfx.blink(); setState('play'); biomeMusic(true);
  }

  // ------------------------------------------------------------------
  //  Музыка локаций
  // ------------------------------------------------------------------
  function curBiome() {
    if (playerInCastle()) return CASTLE.biome;
    return biomeMap[clamp(Math.floor(P.y / T), 0, MH - 1) * MW + clamp(Math.floor(P.x / T), 0, MW - 1)];
  }
  function biomeMusic(now) {
    const want = CFG.abyss && G.abyss && G.abyss.track ? G.abyss.track : CFG.rush ? 'boss' : (BIOME_MUSIC[curBiome()] || CFG.music);
    if (now) { G.musWant = want; G.musHold = 0; Sound.music(want); }
    return want;
  }
  function updateMusic(dt) {
    if (G.activeBoss || G.cutscene || G.finalFinal || state !== 'play') return;
    G.musT -= dt; if (G.musT > 0) return; G.musT = 0.5;
    const want = biomeMusic(false);
    if (want !== G.musWant) { G.musWant = want; G.musHold = 0; return; }
    G.musHold += 0.5;
    if (G.musHold >= 1.5 && Sound.current() !== want) Sound.music(want);
  }

  // ------------------------------------------------------------------
  //  События на карте (раз в ~3 минуты)
  // ------------------------------------------------------------------
  function pickEvent() {
    const pool = EVENTS.filter(e => e.id !== G.lastEv && (e.id !== 'song' || CHN >= 2) && !(CFG.noEvents || []).includes(e.id));
    return weighted(pool.map(e => [e, e.w * (e.id === 'hearts' && P.hp < P.maxHp * 0.5 ? 2.5 : 1)]));
  }
  // свободное место в кольце вокруг героини, до которого можно дойти пешком (для клада и воришки):
  // обход клеток от героини – остров за водой или комната за стеной не подойдут
  function eventSpot(r0, r1) {
    const ptx = Math.floor(P.x / T), pty = Math.floor(P.y / T), R = Math.ceil(r1 / T) + 2;
    const free = (x, y) => inMap(x, y) && y < PLAY_H - 2 && x > 2 && y > 2 && x < MW - 3 && !isSolidTile(x, y, false) && walkable(tc(x), tc(y), false);
    const seen = new Set([ptx * 4096 + pty]), q = [[ptx, pty]], cands = [];
    for (let qi = 0; qi < q.length; qi++) {
      const [x, y] = q[qi];
      for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const nx = x + dx, ny = y + dy, k = nx * 4096 + ny;
        if (seen.has(k) || Math.abs(nx - ptx) > R || Math.abs(ny - pty) > R) continue;
        seen.add(k);
        if (!free(nx, ny)) continue;
        q.push([nx, ny]);
        const d = Math.hypot(tc(nx) - P.x, tc(ny) - P.y);
        if (d >= r0 && d <= r1 && free(nx + 1, ny) && free(nx - 1, ny) && free(nx, ny + 1) && free(nx, ny - 1)) cands.push([nx, ny]);
      }
    }
    if (!cands.length) return null;
    const [tx, ty] = pick(cands);
    return { x: tc(tx) + rnd(-8, 8), y: tc(ty) + rnd(-8, 8) };
  }
  function startEvent(forceId) {
    let def = (forceId && EVENTS.find(e => e.id === forceId)) || G.nextEv || pickEvent();
    G.nextEv = null;
    // воришке и кладу нужно место рядом – нет места, берём другое событие
    let spot = null;
    if (def.id === 'thief' || def.id === 'treasure') {
      spot = def.id === 'thief' ? eventSpot(240, 340) : eventSpot(420, 700);
      if (!spot) { def = EVENTS.find(e => e.id === 'gold'); }
    }
    G.ev = { def, t: 0, k: 0, kills: 0 }; G.lastEv = def.id;
    G.evT = rnd(EVENT_GAP[0], EVENT_GAP[1]) * G.diff.event * (weekEv('fest') ? 0.5 : 1);
    netBan(def.ic + ' ' + def.name, def.desc);
    Sound.sfx.event(); G.shake = Math.max(G.shake, 6);
    if (G.st) G.st.events[def.id] = (G.st.events[def.id] || 0) + 1;
    if (def.id === 'thief') {
      const biome = biomeMap[Math.floor(spot.y / T) * MW + Math.floor(spot.x / T)];
      const types = (SPAWNS[biome] || []).filter(([t]) => !ENEMIES[t].fly && ENEMIES[t].ai !== 'turret');
      const type = types.length ? weighted(types) : (SPAWNS[biome] ? weighted(SPAWNS[biome]) : Object.keys(ENEMIES)[0]);
      const e = spawnEnemy(type, spot.x, spot.y, biome, { instant: true });
      e.thief = true; e.hp = e.maxHp = e.maxHp * 2.5; e.xp *= 3; e.dmg = 0;
      G.ev.thief = e;
      burst(e.x, e.y, 24, '#ffd25a', 220);
    }
    if (def.id === 'treasure') { G.ev.tx = spot.x; G.ev.ty = spot.y; }
    if (def.id === 'horde') G.ev.goal = Math.round(16 + CHN * 2 + Math.min(10, P.level * 0.25));
    if (def.id === 'song') {
      G.ev.line = Math.floor(Math.random() * SONG_TEXTS.length); G.ev.lineT = 2.6;
      $('songText').textContent = SONG_TEXTS[G.ev.line];
      const ac = $('songAvatar').getContext('2d'); ac.clearRect(0, 0, 96, 96);
      if (ART.zyamaFace) ac.drawImage(ART.zyamaFace, 0, 0, 96, 96);
      $('songBanner').classList.remove('hidden');
    }
  }
  // награда за событие: россыпь опыта и осколков, иногда ключ
  function eventLoot(x, y, tier, mult = 1) {
    dailyAdd(150);
    chestReward({ x, y, tier, biome: curBiome() }, mult);
    if (tier === 'gold') G.relicPending = true;
    Sound.sfx.chest(); burst(x, y, 34, '#ffd25a', 240); G.shake = Math.max(G.shake, 6);
    if (G.st) G.st.evWins = (G.st.evWins || 0) + 1;
  }
  function endEvent(result) {
    const ev = G.ev; if (!ev) return;
    if (ev.def.id === 'song') $('songBanner').classList.add('hidden');
    if (ev.def.id === 'thief' && ev.thief && !ev.thief.dead && result !== 'win') { // убежал
      const e = ev.thief; burst(e.x, e.y, 20, '#ffd25a', 200); e.dead = true;
      floatText(e.x, e.y - 30, '💨 Воришка сбежал…', '#ffe9a0', true);
    }
    if (ev.def.id === 'treasure' && result !== 'win') floatText(P.x, P.y - 60, '🧭 Клад ушёл под землю…', '#ffe9a0', true);
    if (ev.def.id === 'horde' && result !== 'win' && result !== 'quiet') floatText(P.x, P.y - 60, `👹 Осада закончилась: ${ev.kills}/${ev.goal}`, '#d8c0ff', true);
    G.ev = null;
  }
  function thiefCaught(e) { // воришка пойман
    if (!G.ev || G.ev.thief !== e) return;
    netBan('💰 Воришка пойман!', 'Мешок с добычей твой');
    eventLoot(e.x, e.y, Math.random() < 0.25 ? 'gold' : 'silver');
    endEvent('win');
  }
  function updateEvents(dt) {
    if (CFG.rush || CFG.abyss || G.cutscene || G.finalFinal) { if (G.ev) endEvent('quiet'); return; }
    if (G.ev) {
      const ev = G.ev; ev.t += dt; ev.k -= dt;
      const EA = NET.host ? netAnchor() : P; // звёзды и сердечки падают то у одной, то у другой
      if (ev.def.id === 'meteor' && ev.k <= 0) { // звёзды падают вокруг (без прицела на бегу), на месте – осколок
        ev.k = 0.42;
        const a = rnd(0, TAU), r = rnd(50, 300);
        const h = hazardCircle(EA.x + Math.cos(a) * r, EA.y + Math.sin(a) * r, 56, 1.25, P.maxHp * 0.08, 'meteor'); h.star = true;
      }
      if (ev.def.id === 'hearts' && ev.k <= 0) { ev.k = 0.55; const a = rnd(0, TAU), r = rnd(60, 240); dropPickup(EA.x + Math.cos(a) * r, EA.y + Math.sin(a) * r, 'heart'); }
      if (ev.def.id === 'song') {
        const left = Math.ceil(ev.def.dur - ev.t); $('songLeft').textContent = left > 0 ? `Песня кончится через ${left}…` : '';
        ev.lineT -= dt;
        if (ev.lineT <= 0) { ev.lineT = 2.6; ev.line = (ev.line + 1) % SONG_TEXTS.length; $('songText').textContent = SONG_TEXTS[ev.line]; }
        if (Math.random() < dt * 6) floatText(P.x + rnd(-160, 160), P.y + rnd(-200, 40), pick(['♪', '♫', '🎵']), '#ff8ad8', true);
      }
      if (ev.def.id === 'thief' && ev.thief && ev.thief.dead) { floatText(P.x, P.y - 60, '💨 Воришка сбежал…', '#ffe9a0', true); endEvent(); return; } // убежал далеко
      if (ev.def.id === 'treasure' && netNear(ev.tx, ev.ty, 44)) {
        netBan('🧭 Клад найден!', 'Сундук с сокровищами');
        eventLoot(ev.tx, ev.ty, Math.random() < 0.2 ? 'gold' : 'silver');
        endEvent('win'); return;
      }
      if (ev.def.id === 'horde' && ev.kills >= ev.goal) {
        netBan('👹 Осада отбита!', 'Лечение и награда');
        P.hp = Math.min(P.maxHp, P.hp + P.maxHp * 0.3); floatText(P.x, P.y - 40, '+30% ❤️', '#7dff9a', true);
        if (NET.host) for (const m of NET.peers.values()) netEvent(m.id, ['hl']);
        eventLoot(P.x, P.y + 30, 'silver');
        endEvent('win'); return;
      }
      if (ev.t >= ev.def.dur) endEvent();
      return;
    }
    if (G.activeBoss || G.activeShrine) { G.evT = Math.max(G.evT, 25); G.nextEv = null; return; } // после боя – передышка
    G.evT -= dt;
    if (G.evT <= 8 && !G.nextEv) G.nextEv = pickEvent(); // заранее знаем, что будет – пишем на плашке
    if (G.evT <= 0) startEvent();
  }

  // ------------------------------------------------------------------
  //  Статистика (для отправки разработчику)
  // ------------------------------------------------------------------
  function newRunStats() {
    return { ch: CHN, hero: P.hero, diff: G.diffId, lvl0: P.level, time: 0, deaths: 0, kills: 0, elites: 0, byType: {}, dmgDealt: 0, dmgTaken: 0,
      healed: 0, shards: 0, chests: 0, shrines: 0, supers: 0, dashes: 0, events: {}, bosses: [], ups: [], cur: null, champs: 0, calmUps: 0 };
  }
  function loadTotals() { try { return JSON.parse(localStorage.getItem(STATS_KEY)) || {}; } catch (e) { return {}; } }
  function saveTotals(t) { try { localStorage.setItem(STATS_KEY, JSON.stringify(t)); } catch (e) { /* ignore */ } }
  const topTypes = (m, n) => Object.entries(m || {}).sort((a, b) => b[1] - a[1]).slice(0, n);
  const fmtT = sec => { sec = Math.max(0, Math.round(sec)); const h = Math.floor(sec / 3600), m = Math.floor(sec % 3600 / 60), ss = sec % 60; return (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + String(ss).padStart(2, '0'); };
  const fmtN = v => v >= 1e6 ? (v / 1e6).toFixed(1) + 'M' : v >= 1e3 ? (v / 1e3).toFixed(1) + 'K' : String(Math.round(v));
  function summarizeRun() {
    const s = G.st;
    return { ch: s.ch, hero: s.hero, diff: s.diff, lvl0: s.lvl0, lvl: P.level, time: Math.round(s.time), deaths: s.deaths, kills: s.kills, elites: s.elites,
      dealt: Math.round(s.dmgDealt), taken: Math.round(s.dmgTaken), healed: Math.round(s.healed || 0), shards: s.shards, chests: s.chests, shrines: s.shrines,
      supers: s.supers, dashes: s.dashes, combo: G.bestCombo, champs: s.champs || 0, calmUps: s.calmUps || 0, seed: SEED % 10000, mimics: s.mimics || 0, relics: s.relics || 0, events: s.events, bosses: s.bosses, ups: s.ups, top: topTypes(s.byType, 6) };
  }
  function recordRunEnd(result) {
    lifeFlush();
    if (!G.st) return;
    const tot = loadTotals();
    tot.runs = tot.runs || [];
    const run = Object.assign(summarizeRun(), { result, at: Date.now() }), top = tot.runs[0]; G.st.recAt = G.st.time; // уже записан – «идёт сейчас» не дублируем
    if (top && top.ch === run.ch && top.seed === run.seed && top.kills <= run.kills && Date.now() - (top.at || 0) < 1800e3 && /пройдена/.test(top.result)) tot.runs[0] = run; // продолжение того же забега
    else tot.runs.unshift(run);
    tot.runs = tot.runs.slice(0, 10);
    saveTotals(tot);
  }
  function buildReport() {
    const prof = loadProfile(), tot = loadTotals();
    const L = [];
    L.push(`📊 Крилесса v${VERSION} – статистика`);
    const ua = navigator.userAgent, andr = (ua.match(/Android [\d.]+/) || ['?'])[0], chrome = (ua.match(/Chrome\/(\d+)/) || [0, '?'])[1];
    L.push(`📱 ${VW}×${VH} @${DPR}x · ${andr} · WebView ${chrome}`);
    L.push(`⚙️ Сложность: ${DIFFS[(prof.settings || {}).diff || 'normal'].name} · в игре: ${fmtT(tot.playTime || 0)} · запусков: ${tot.sessions || 0}`);
    L.push(`🏆 Главы: ${CH_NUMS.map(n => n + (prof['ch' + n + 'Done'] ? '✓' : '–')).join(' ')}${prof.trueWin ? ' · настоящий финал ✓' : ''}` +
      (prof.rushBest ? ` · Босс-раш: ${prof.rushBest.n}/${prof.rushBest.total} за ${fmtT(prof.rushBest.time)}` : ''));
    { const ab = prof.abyssBest, ck = abyssCkLoad(), g = gloryOf(prof), L2 = prof.life || {};
      L.push(`🎮 Бездна: ${ab ? 'волна ' + ab.wave : '–'}${ck ? ` (сохранено: волна ${ck.wave})` : ''} · испытание дня: ${L2.dBest || 0} · ✨ слава ${g.fame} · 🏆 ${g.n}/${ACHS.length} · ⭐ ${prof.stars || 0}`); }
    const runs = [];
    if (G.st && G.st.time > 1 && !(G.rush && G.rush.done) && !(G.st.recAt !== undefined && G.st.time - G.st.recAt < 5)) runs.push(Object.assign(summarizeRun(), { result: 'идёт сейчас' }));
    for (const r of (tot.runs || [])) runs.push(r);
    for (const r of runs.slice(0, 5)) {
      L.push('');
      L.push(`– ${r.ch === 'rush' || String(r.result).includes('раш') ? 'Босс-раш' : r.ch === 'def' || String(r.result).includes('оборона') ? 'Оборона' : r.ch === 'abyss' ? 'Бездна' : 'Глава ' + r.ch} · ${HEROES[r.hero] ? HEROES[r.hero].name : r.hero} · ${String(r.diff).split('→').map(d => DIFFS[d] ? DIFFS[d].name : d).join(' → ')} · ${r.result} –`);
      L.push(`⏱ ${fmtT(r.time)} · ур. ${r.lvl0}→${r.lvl} · ☠️ ${r.kills} (элита ${r.elites}) · 💀 смертей ${r.deaths} · 🔥 комбо ${r.combo}`);
      if (r.champs !== undefined) L.push(`🗺️ карта #${r.seed} · 👑 чемпионов ${r.champs} · 🕊️ ступеней усмирения ${r.calmUps}` + (r.mimics !== undefined ? ` · 😱 мимиков ${r.mimics} · 🗝️ реликвий ${r.relics}` : ''));
      L.push(`⚔️ нанесено ${fmtN(r.dealt)} · получено ${fmtN(r.taken)} · вылечено ${fmtN(r.healed)} · 💎 ${r.shards} · 📦 ${r.chests} · ⛩ ${r.shrines} · 🌟 ${r.supers} · рывков ${r.dashes}`);
      for (const b of r.bosses || []) L.push(`  👑 ${b.n}: ${fmtT(b.t)} · ур. игрока ${b.pl} / босса ${b.bl} · смертей ${b.d}` + (b.h !== undefined ? ` · ❤️ ${b.h}` : '') + (b.df ? ` · ${DIFFS[b.df] ? DIFFS[b.df].name : b.df}` : ''));
      const ev = Object.entries(r.events || {}).map(([k, v]) => { const e = EVENTS.find(x => x.id === k); return (e ? e.ic : k) + '×' + v; }).join(' ');
      if (ev) L.push(`  🎲 события: ${ev}`);
      if (r.top && r.top.length) L.push(`  👾 ${r.top.map(([k, v]) => (ENEMIES[k] ? ENEMIES[k].name : k) + ' ' + v).join(', ')}`);
      if (r.ups && r.ups.length) { const cnt = {}; r.ups.forEach(u => { cnt[u] = (cnt[u] || 0) + 1; }); L.push(`  ⬆️ ${Object.entries(cnt).map(([k, v]) => k + '×' + v).join(' ')}`); }
    }
    const errs = errLog();
    if (errs.length) {
      L.push(''); L.push('⚠️ Сбои:');
      for (const x of errs.slice(0, 5)) L.push(`  ${new Date(x.at).toLocaleString('ru-RU')} · v${x.v} · ${x.w} · ${x.st} · гл. ${x.ch}: ${x.m}${x.s ? ' (' + x.s + ')' : ''}`);
    }
    L.push('');
    const data = { v: VERSION, scr: [VW, VH, DPR], c: [prof.ch1Done, prof.ch2Done, prof.ch3Done, prof.trueWin, prof.ch4Done, prof.ch5Done, prof.ch6Done, prof.ch7Done].map(Boolean),
      ab: prof.abyssBest ? prof.abyssBest.wave : 0, ack: (abyssCkLoad() || {}).wave || 0, gl: [gloryOf(prof).fame, gloryOf(prof).n], w: prof.ch4Choice || null, a: prof.ch5Accuse || null, d: (prof.settings || {}).diff,
      rb: prof.rushBest || null, pt: Math.round(tot.playTime || 0), ss: tot.sessions || 0, er: errLog().slice(0, 5).map(x => [x.at, x.v, x.w, x.st, x.ch, x.m, x.s]),
      runs: runs.slice(0, 5).map(r => ({ ch: r.ch, h: r.hero, d: r.diff, r: r.result, t: r.time, l: [r.lvl0, r.lvl], k: r.kills, de: r.deaths, dd: r.dealt, dt: r.taken,
        b: (r.bosses || []).map(b => [b.k, b.t, b.pl, b.bl, b.d, b.h || 0, b.df || '']), e: r.events, u: r.ups })) };
    L.push('#KRSTAT ' + JSON.stringify(data));
    return L.join('\n');
  }
  let statsBack = 'menu';
  function openStats() {
    statsBack = state === 'stats' ? statsBack : state;
    $('statsText').textContent = buildReport();
    setState('stats');
  }
  function toast(msg) {
    const t = $('toast'); t.textContent = msg; t.classList.remove('hidden', 'show'); void t.offsetWidth; t.classList.add('show');
    clearTimeout(toast.tm); toast.tm = setTimeout(() => t.classList.add('hidden'), 2600);
  }
  function fallbackCopy(txt) {
    const ta = document.createElement('textarea'); ta.value = txt; ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.appendChild(ta); ta.select();
    try { document.execCommand('copy'); toast('Скопировано! Вставь в сообщение 📋'); } catch (e) { toast('Не получилось скопировать'); }
    ta.remove();
  }
  function copyText(txt) {
    try { if (window.KrilessaAndroid && window.KrilessaAndroid.copy) { window.KrilessaAndroid.copy(txt); toast('Скопировано! Вставь в сообщение 📋'); return; } } catch (e) { /* ignore */ }
    if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(txt).then(() => toast('Скопировано! Вставь в сообщение 📋'), () => fallbackCopy(txt)); return; }
    fallbackCopy(txt);
  }
  function shareText(txt) {
    try { if (window.KrilessaAndroid && window.KrilessaAndroid.share) { window.KrilessaAndroid.share(txt); return; } } catch (e) { /* ignore */ }
    if (navigator.share) { navigator.share({ title: 'Крилесса – статистика', text: txt }).catch(() => {}); return; }
    copyText(txt);
  }

  // ------------------------------------------------------------------
  //  Босс-раш
  // ------------------------------------------------------------------
  function rushPool() {
    const prof = loadProfile(), kinds = [], levels = [];
    for (const n of CH_NUMS) if (CHAPTERS[n] && (prof['ch' + n + 'Done'] || DEBUG || prof.admin)) CHAPTERS[n].bosses.forEach((k, i) => { kinds.push(k); levels.push(CHAPTERS[n].bossLevels[i]); });
    return { kinds, levels };
  }
  function startRush(pool) {
    const prof = loadProfile();
    const { kinds, levels } = pool && pool.kinds ? pool : rushPool(); // вместе список боссов присылает хозяйка
    if (!kinds.length) return;
    const R = CHAPTERS.rush;
    R.bosses = kinds; R.bossLevels = levels; R.bossTiles = kinds.map(() => ({ x: 30, y: 24 }));
    R.hero = NET.on && G.netRun ? NET.hero : rushHeroPick(prof);
    loadChapter('rush'); resetRun();
    // у всех одинаковая героиня 24 уровня (плюс свои таланты и реликвии) – рекорды честные
    { const rb = refBuild(24); P.level = 24; P.up = rb.up; P.bonus = rb.bonus; P.shards = 0; }
    P.xpNext = xpFor(P.level);
    beginPlay();
    gateOpen = true;
    G.rush = { idx: 0, wait: 2.5, t: 0, total: kinds.length, done: false };
    G.st = newRunStats();
    showBanner('⚔️ Босс-раш', `${kinds.length} боссов подряд. Время пошло!`);
    Sound.music('boss');
  }
  function rushBossDown() {
    const R = G.rush;
    R.idx++;
    P.hp = Math.min(P.maxHp, P.hp + P.maxHp * 0.5);
    if (NET.host) for (const m of NET.peers.values()) netEvent(m.id, ['rh']); // подругам тоже лечение и улучшение
    for (const e of G.enemies) if (e.minion) e.dead = true;
    if (R.idx >= R.total) { rushFinish(true); return; }
    R.wait = 3.5;
    showBanner(`Босс ${R.idx}/${R.total} повержен!`, `Время ${fmtT(R.t)}`);
    G.pendingLv++; openLevelUp();
  }
  function rushFinish(win) {
    const R = G.rush, prof = loadProfile();
    if (R.done) return;
    R.done = true;
    const res = { n: R.idx, total: R.total, time: Math.round(R.t), hero: P.hero };
    const coop = NET.on && G.netRun, bk = coop ? 'rushBestCoop' : 'rushBest', best = prof[bk]; // вместе – свой рекорд
    if (coop) res.players = NET.roster.length;
    R.better = !best || res.n > best.n || (res.n === best.n && res.time < best.time);
    if (R.better) { prof[bk] = res; saveProfile(prof); }
    if (win) life('rush');
    if (NET.host && G.netRun) NetT.send(-1, { t: 'rend', win: win ? 1 : 0, n: R.idx, total: R.total, time: Math.round(R.t) });
    recordRunEnd(win ? 'босс-раш пройден' : `босс-раш ${R.idx}/${R.total}`);
    if (win) { Sound.music('win'); setTimeout(() => showVictory('rush'), 1500); }
  }

  // ------------------------------------------------------------------
  //  Подлянка финала главы 3
  // ------------------------------------------------------------------
  let trickTimers = [];
  const later = (ms, fn) => trickTimers.push(setTimeout(fn, ms));
  const Trick = { cv: null, c: null, raf: 0, t0: 0, mode: '', cracks: [], shards: [] };
  function trickSetup() {
    Trick.cv = $('trickCanvas'); Trick.c = Trick.cv.getContext('2d');
    const d = Math.min(window.devicePixelRatio || 1, 2);
    Trick.cv.width = Math.round(VW * d); Trick.cv.height = Math.round(VH * d);
    Trick.c.setTransform(d, 0, 0, d, 0, 0);
    Trick.cv.classList.remove('hidden');
  }
  function trickLoop(now) {
    const c = Trick.c, t = (now - Trick.t0) / 1000;
    c.clearRect(0, 0, VW, VH);
    if (Trick.mode === 'crack') {
      const k = clamp(t / 0.9, 0, 1);
      c.strokeStyle = 'rgba(255,255,255,0.9)'; c.lineWidth = 2; c.shadowColor = '#ff3ea5'; c.shadowBlur = 8;
      for (const cr of Trick.cracks) {
        const n = Math.floor(cr.length * k);
        c.beginPath(); c.moveTo(cr[0][0], cr[0][1]);
        for (let i = 1; i < n; i++) c.lineTo(cr[i][0], cr[i][1]);
        c.stroke();
      }
      c.shadowBlur = 0;
    } else if (Trick.mode === 'shatter') {
      c.fillStyle = `rgba(10,4,20,${clamp(t / 0.3, 0, 1)})`; c.fillRect(0, 0, VW, VH);
      for (const s of Trick.shards) {
        s.vy += 900 * (1 / 60); s.x += s.vx / 60; s.y += s.vy / 60; s.a += s.va / 60;
        c.save(); c.translate(s.x, s.y); c.rotate(s.a);
        c.globalAlpha = clamp(1.6 - t, 0, 1);
        const g = c.createLinearGradient(-30, -30, 30, 30); g.addColorStop(0, '#5a2a4a'); g.addColorStop(0.5, '#ffb347'); g.addColorStop(1, '#2a1238');
        c.fillStyle = g; c.beginPath(); s.pts.forEach(([x, y], i) => i ? c.lineTo(x, y) : c.moveTo(x, y)); c.closePath(); c.fill();
        c.strokeStyle = 'rgba(255,255,255,0.8)'; c.lineWidth = 1.5; c.stroke();
        c.restore();
      }
      c.globalAlpha = 1;
    }
    Trick.raf = requestAnimationFrame(trickLoop);
  }
  function startTrick() {
    if (state !== 'victory' || CHN !== 3 || G.trueWin) return;
    const vic = $('victory'); vic.classList.add('glitching');
    Sound.setGlitch(1); Sound.sfx.staticNoise();
    const title = $('victoryTitle'), orig = title.textContent, glyphs = '█▓▒░#@%&?!ЗЯМОЧКККК';
    let n = 0;
    const scr = setInterval(() => { n++; title.textContent = orig.split('').map(ch => Math.random() < n * 0.05 ? glyphs[Math.floor(Math.random() * glyphs.length)] : ch).join(''); }, 90);
    later(900, () => Sound.sfx.staticNoise());
    later(1800, () => { Sound.sfx.staticNoise(); G.shake = 20; });
    later(2200, () => {
      trickSetup(); Trick.mode = 'crack'; Trick.t0 = performance.now(); Trick.cracks = [];
      const cx = VW * 0.5, cy = VH * 0.38;
      for (let i = 0; i < 16; i++) {
        let a = (i / 16) * TAU + rnd(-0.2, 0.2), x = cx, y = cy; const pts = [[x, y]];
        for (let k = 0; k < 10; k++) { a += rnd(-0.5, 0.5); const l = rnd(25, 70); x += Math.cos(a) * l; y += Math.sin(a) * l; pts.push([x, y]); }
        Trick.cracks.push(pts);
      }
      Sound.sfx.glass();
      cancelAnimationFrame(Trick.raf); Trick.raf = requestAnimationFrame(trickLoop);
    });
    later(3200, () => {
      clearInterval(scr);
      Trick.mode = 'shatter'; Trick.t0 = performance.now(); Trick.shards = [];
      const cols = 6, rows = 10, w = VW / cols, h = VH / rows;
      for (let i = 0; i < cols; i++) for (let j = 0; j < rows; j++) {
        const x0 = i * w, y0 = j * h;
        for (const tri of [[[0, 0], [w, 0], [0, h]], [[w, 0], [w, h], [0, h]]]) {
          const cxs = (tri[0][0] + tri[1][0] + tri[2][0]) / 3, cys = (tri[0][1] + tri[1][1] + tri[2][1]) / 3;
          const px = x0 + cxs, py = y0 + cys, da = Math.atan2(py - VH * 0.38, px - VW / 2);
          Trick.shards.push({ x: px, y: py, pts: tri.map(([a, b]) => [a - cxs, b - cys]), vx: Math.cos(da) * rnd(80, 300), vy: Math.sin(da) * rnd(80, 300) - 200, a: 0, va: rnd(-6, 6) });
        }
      }
      Sound.sfx.shatter(); G.shake = 25;
      vic.classList.add('hidden'); vic.classList.remove('glitching');
    });
    later(4300, () => {
      cancelAnimationFrame(Trick.raf); Trick.cv.classList.add('hidden');
      Sound.setGlitch(0); Sound.music('zyamashow'); openZyamaMenu();
    });
  }
  function openZyamaMenu() {
    setState('zmenu');
    const ac = $('zmAvatar').getContext('2d'); ac.clearRect(0, 0, 160, 160);
    if (ART.zyamaFace) ac.drawImage(ART.zyamaFace, 0, 0, 160, 160);
    $('zmSay').textContent = 'Ой. Вы что, правда думали, что победили? 😏';
    const ex = $('zmExit'); ex.style.transform = ''; ex.textContent = '✖ Выйти';
    G.zm = { tries: 0, go: false };
    later(9500, zyamaMenuGo);
  }
  function zmReact(text, go) { $('zmSay').textContent = text; Sound.sfx.click(); if (go) later(1900, zyamaMenuGo); }
  function zyamaMenuGo() {
    if (!G.zm || G.zm.go) return;
    G.zm.go = true;
    $('zmSay').textContent = 'Вы думали, это конец? Это был только АНТРАКТ! 😈';
    Sound.sfx.roar(); G.shake = 20;
    later(2300, startFinalFinal);
  }
  function startFinalFinal() {
    trickTimers.forEach(clearTimeout); trickTimers = [];
    const d = BOSSES.zyamaInf, hx = tc(CASTLE.x), hy = tc(CASTLE.y);
    const b = {
      id: bosses.length, kind: 'zyamaInf', def: d, name: d.name, sub: d.sub, r: d.r, maxHp: 1, hp: 1, spd: d.spd, dmg: 0, cdmg: 0,
      E: 0, level: 0, aggro: 1, shield: false, stunT: 0, burnT: 0, burnDps: 0, burnTick: 0,
      fly: true, move: d.move, hx, hy, x: hx, y: hy - 80, state: 'sleep', mode: 'idle', t: 0, flash: 0, z: 0, last: null, stage: 0, vstage: 3,
      sub: 0, cnt: 0, anim: 0, alpha: 1, ang: 0, tx: 0, ty: 0, sx: 0, sy: 0, dist: 0, charging: false, dur: 0, inv: false, final: true, look: 0, p: null,
      speedMul: 1, tauntT: 6, orbCd: 0,
    };
    bosses.push(b);
    G.cutscene = null; G.cageOpen = 1;
    P.x = hx; P.y = hy + 210; P.hp = P.maxHp; P.inv = 2;
    G.cp = { x: P.x, y: P.y };
    G.finalFinal = { t: 0, bank: 0, need: d.survive, ally: { x: P.x - 55, y: P.y - 20, fireT: 0 }, said: {} };
    G.enemies.length = 0; G.ebullets.length = 0; G.hazards.length = 0; G.beams.length = 0;
    setState('play');
    startBossFight(b);
    later(2600, () => showBanner('ЗЯМОЧКККК ∞', 'Продержись 40 секунд! Попадания ускоряют ДРУЖБА-СУПЕР'));
  }
  function updateFinalFinal(dt) {
    const F = G.finalFinal;
    if (!F || G.cutscene) return;
    const A = F.ally, b = G.activeBoss;
    A.x = lerp(A.x, P.x - 55 * P.face, Math.min(1, dt * 4)); A.y = lerp(A.y, P.y - 26, Math.min(1, dt * 4));
    A.fireT -= dt;
    if (b && A.fireT <= 0) {
      A.fireT = 0.25;
      const a = Math.atan2(b.y - A.y, b.x - A.x);
      G.feathers.push({ x: A.x, y: A.y, vx: Math.cos(a) * 480, vy: Math.sin(a) * 480, dmg: P.dmg * 0.5, pierce: 3, life: 1.2, hit: [], kind: 'feather', ally: true });
    }
    if (!b) return;
    const extra = Math.min(F.bank, dt * 0.6); F.bank -= extra;
    F.t += dt + extra;
    const lines = [[3, 'Рыжовая, держись! Я заряжаю ДРУЖБА-СУПЕР! 💜'], [16, 'Он бессмертный, но дружба сильнее! Ещё немного!'], [29, 'Почти готово!!! Не сдавайся!'], [36, 'На счёт три... раз... два...']];
    for (const [tt, text] of lines) if (F.t >= tt && !F.said[tt]) { F.said[tt] = 1; say(text, 3.2); }
    if (F.t >= F.need) startTeamUp();
  }
  function startTeamUp() {
    G.cutscene = { t: 0, kind: 'teamup' };
    G.ebullets.length = 0; G.hazards.length = 0; G.beams.length = 0;
    // без опыта: окно улучшений не должно выскакивать посреди сцены
    for (const e of G.enemies) burst(e.x, e.y, 8, '#ffffff', 100);
    G.enemies.length = 0;
    showBanner('ДРУЖБА-СУПЕР!', 'Крилесса + Рыжовая');
    Sound.sfx.nova(); Sound.sfx.magic(); G.shake = 12;
  }
  function updateTeamUp(dt, cs) {
    const b = bosses[bosses.length - 1], A = G.finalFinal.ally;
    A.x = lerp(A.x, P.x - 46, Math.min(1, dt * 3)); A.y = lerp(A.y, P.y - 6, Math.min(1, dt * 3));
    P.t += dt;
    if (cs.t > 0.8 && cs.t < 3.2) { G.shake = Math.max(G.shake, 5); if (Math.random() < 0.9) part(b.x + rnd(-40, 40), b.y + rnd(-40, 40), rnd(-220, 220), rnd(-220, 220), 0.5, 6, pick(RAINBOW)); }
    if (cs.t >= 3.2 && !cs.boom) {
      cs.boom = true; b.state = 'dead'; G.activeBoss = null;
      burst(b.x, b.y, 120, '#ffd25a', 520); burst(b.x, b.y, 80, '#ff3ea5', 420); burst(b.x, b.y, 60, '#3ff0ff', 360);
      shockRing(b.x, b.y, '#ffffff', 650); G.shake = 30; Sound.sfx.boom(); Sound.sfx.win();
      speak('zyamaInf', b.def.lines.death, 4.5);
      Sound.music('truewin');
      if (G.st && G.st.cur) { const c = G.st.cur; G.st.bosses.push({ k: c.k, n: c.n, pl: c.pl, bl: c.bl, t: Math.round(G.st.time - c.t0), d: c.d, h: c.h || 0, df: c.df || G.diffId }); G.st.cur = null; }
    }
    if (cs.boom && Math.random() < 0.4) part(P.x + rnd(-80, 80), P.y + rnd(-90, 10), 0, -50, 1.4, 6, '#ff5b8a');
    if (cs.t > 8.5 && !G.trueWin) {
      G.trueWin = true;
      const prof = loadProfile(); prof.trueWin = true; saveProfile(prof);
      recordRunEnd('настоящая победа');
      showVictory('true');
    }
  }

  // ------------------------------------------------------------------
  //  Что нового (после обновления)
  // ------------------------------------------------------------------
  let wnBack = 'menu', confetti = [], confRaf = 0;
  function confLoop() {
    const cv = $('wnCanvas'), c = cv.getContext('2d');
    const d = Math.min(window.devicePixelRatio || 1, 2);
    if (cv.width !== Math.round(VW * d)) { cv.width = Math.round(VW * d); cv.height = Math.round(VH * d); }
    c.setTransform(d, 0, 0, d, 0, 0); c.clearRect(0, 0, VW, VH);
    if (confetti.length < 90) confetti.push({ x: rnd(0, VW), y: -10, vy: rnd(60, 160), vx: rnd(-30, 30), a: rnd(0, TAU), va: rnd(-6, 6), col: pick(RAINBOW), w: rnd(5, 10) });
    for (const p of confetti) { p.y += p.vy / 60; p.x += p.vx / 60; p.a += p.va / 60; c.save(); c.translate(p.x, p.y); c.rotate(p.a); c.fillStyle = p.col; c.fillRect(-p.w / 2, -3, p.w, 6); c.restore(); }
    confetti = confetti.filter(p => p.y < VH + 20);
    confRaf = requestAnimationFrame(confLoop);
  }
  // старые номера версий, которые потом переименовали (0.11 ранних сборок стала 0.10.2, а 0.11 теперь – настоящая)
  const VERSION_ALIAS = {};
  const verNum = v => (String(v || '').match(/\d+/g) || []).map(Number);
  const verCmp = (a, b) => { const x = verNum(a), y = verNum(b); for (let i = 0; i < Math.max(x.length, y.length); i++) { const d = (x[i] || 0) - (y[i] || 0); if (d) return d; } return 0; };
  function openWhatsNew(fromVer) {
    fromVer = VERSION_ALIAS[fromVer] || fromVer;
    // по номерам, а не по точному совпадению: часть старых версий из списка убрана
    let list = fromVer ? CHANGELOG.filter(cl => verCmp(cl.v, fromVer) > 0) : CHANGELOG;
    if (!list.length) list = CHANGELOG.slice(0, 1);
    $('wnVer').textContent = fromVer && fromVer !== VERSION ? `v${fromVer} → v${VERSION}` : `v${VERSION}`;
    const box = $('wnList'); box.innerHTML = '';
    let k = 0;
    list.forEach((cl, i) => {
      const h = document.createElement('div'); h.className = 'wnHead'; h.style.animationDelay = (k++ * 0.07) + 's';
      h.textContent = `v${cl.v} · ${cl.title}`; box.appendChild(h);
      for (const [ic, nm, ds] of cl.items) {
        const el = document.createElement('div'); el.className = 'wnItem' + (i > 0 ? ' old' : ''); el.style.animationDelay = (k++ * 0.07) + 's';
        el.innerHTML = `<div class="ic">${ic}</div><div><b>${nm}</b><span>${ds}</span></div>`;
        box.appendChild(el);
      }
    });
    wnBack = state === 'whatsnew' ? wnBack : state;
    setState('whatsnew');
    confetti = []; cancelAnimationFrame(confRaf); confRaf = requestAnimationFrame(confLoop);
    Sound.sfx.win();
  }
  function closeWhatsNew() {
    cancelAnimationFrame(confRaf);
    const prof = loadProfile(); prof.lastVersion = VERSION; saveProfile(prof);
    if (wnBack === 'menu') openMenu(); else if (wnBack === 'splash') openSplash(); else setState(wnBack);
  }

  // ------------------------------------------------------------------
  //  Глава 4: загадка
  // ------------------------------------------------------------------
  let teaserBack = 'menu', teaserRaf = 0, teaserImg = null, teaserT0 = 0, teaserGlow = 0;
  const TEASER_LINES = ['Хорошая… или добрая?..', 'Спит двадцать часов в сутки – но видит всё.', 'Голубые глаза. Мягкие лапки. Острые коготки.',
    'Говорят, она знает, где Зямочкккк прячет корм.', 'Глава 4. Скоро.', 'Мяу.'];
  function teaserLoop(now) {
    const cv = $('teaserCanvas'), c = cv.getContext('2d'), t = (now - teaserT0) / 1000;
    c.clearRect(0, 0, 480, 640);
    const br = 1 + Math.sin(t * 1.4) * 0.012;
    c.save(); c.translate(240, 320); c.scale(br, br); c.translate(-240, -320);
    c.filter = `brightness(${(0.42 + teaserGlow * 0.6).toFixed(2)}) blur(${Math.max(0, 1.4 - teaserGlow * 1.4).toFixed(2)}px)`;
    if (teaserImg) c.drawImage(teaserImg, 0, 0, 480, 640);
    c.filter = 'none';
    c.restore();
    const vg = c.createRadialGradient(240, 300, 120, 240, 320, 400);
    vg.addColorStop(0, 'rgba(0,0,0,0)'); vg.addColorStop(1, 'rgba(0,0,0,0.85)');
    c.fillStyle = vg; c.fillRect(0, 0, 480, 640);
    const g = (0.25 + 0.2 * Math.sin(t * 2)) + teaserGlow;
    for (const [ex, ey] of [[0.345, 0.322], [0.555, 0.322]]) {
      const x = ex * 480, y = ey * 640;
      const gr = c.createRadialGradient(x, y, 0, x, y, 26);
      gr.addColorStop(0, `rgba(120,200,255,${clamp(g, 0, 1) * 0.55})`); gr.addColorStop(1, 'rgba(120,200,255,0)');
      c.fillStyle = gr; c.fillRect(x - 30, y - 30, 60, 60);
      c.strokeStyle = `rgba(180,230,255,${clamp(g, 0, 1) * 0.8})`; c.lineWidth = 2.5;
      c.beginPath(); c.ellipse(x, y, 12, 2.4, 0, 0, TAU); c.stroke();
    }
    teaserGlow = Math.max(0, teaserGlow - 0.02);
    teaserRaf = requestAnimationFrame(teaserLoop);
  }
  let teaserNext = null; // окошко-загадка в начале главы: «Дальше» ведёт в интро
  function openTeaser(next) {
    teaserNext = typeof next === 'function' ? next : null;
    $('teaserBack').textContent = teaserNext ? 'Дальше »' : 'Назад';
    teaserBack = state === 'teaser' ? teaserBack : state;
    setState('teaser');
    const box = $('teaserLines'); box.innerHTML = '';
    TEASER_LINES.forEach((ln, i) => {
      const el = document.createElement('div'); el.className = 'tline' + (i === TEASER_LINES.length - 1 ? ' meow' : '');
      el.textContent = ln; el.style.animationDelay = (0.6 + i * 1.15) + 's'; box.appendChild(el);
    });
    if (!teaserImg) { teaserImg = new Image(); teaserImg.src = 'ch4_shadow.jpg'; }
    teaserT0 = performance.now(); cancelAnimationFrame(teaserRaf); teaserRaf = requestAnimationFrame(teaserLoop);
    Sound.music(null);
    setTimeout(() => { if (state === 'teaser') { Sound.sfx.meow(); teaserGlow = 0.6; } }, (0.6 + (TEASER_LINES.length - 1) * 1.15) * 1000);
  }
  function closeTeaser() { cancelAnimationFrame(teaserRaf); if (teaserNext) { const nx = teaserNext; teaserNext = null; nx(); } else if (teaserBack === 'menu') openMenu(); else setState(teaserBack); }

  // ------------------------------------------------------------------
  //  Глава 7: загадка из глубины
  // ------------------------------------------------------------------
  const KRILL_LINES = ['Где-то в глубине стало подозрительно тихо…', 'Их миллиарды. Они розовые. Они криляют.', '– Ты меня крилюбишь?..',
    'А на самом дне кто-то ругается так, что краснеют даже креветки.', 'Глава 7. Скоро.', 'Крилять.'];
  const KRILL_SAY = ['криль!', 'крилюблю!', 'криляю!', 'кривет!', 'крилюбишь?', 'кри-кри!', 'криливирую!'];
  const BOSS_SAY = ['Крилять!', 'Ах ты ж крил…', 'Ёкрилый бабай!', '#@%&!!', 'Крилец вам всем!', 'Шо за крилня?!'];
  const KT = { raf: 0, t0: 0, swarm: [], bubbles: [], pops: [], tap: null, red: 0, say: null, sayT: 4 };
  function drawKrill(c, x, y, a, s, t) {
    c.save(); c.translate(x, y); c.rotate(a); c.scale(s, s);
    const w = Math.sin(t * 14) * 1.2;
    c.strokeStyle = 'rgba(255,170,190,0.75)'; c.lineWidth = 0.8;
    c.beginPath(); for (let k = 0; k < 4; k++) { c.moveTo(-3 + k * 2.5, 2); c.lineTo(-4 + k * 2.5 + w * 0.5, 5.5); } c.stroke();
    c.fillStyle = 'rgba(255,110,145,0.92)'; c.beginPath(); c.ellipse(-1, 0, 8, 3, 0, 0, TAU); c.fill();
    c.fillStyle = 'rgba(255,175,195,0.95)'; c.beginPath(); c.ellipse(5, -0.4, 4, 2.6, 0, 0, TAU); c.fill();
    c.fillStyle = 'rgba(255,95,130,0.9)'; c.beginPath(); c.moveTo(-8, 0); c.lineTo(-13, -3.5 + w * 0.3); c.lineTo(-11.5, 0); c.lineTo(-13, 3.5 - w * 0.3); c.closePath(); c.fill();
    c.fillStyle = '#1a0a10'; c.beginPath(); c.arc(7.2, -1.2, 1.1, 0, TAU); c.fill();
    c.strokeStyle = 'rgba(255,200,210,0.6)'; c.beginPath(); c.moveTo(8.5, -1.5); c.quadraticCurveTo(14, -6 + w, 21, -3); c.moveTo(8.5, -0.5); c.quadraticCurveTo(14, -2 - w, 20, 1); c.stroke();
    c.restore();
  }
  function krillLoop(now) {
    if (state !== 'krill') { KT.raf = 0; return; }
    const cv = $('krillCanvas'), c = cv.getContext('2d'), W = 480, H = 640, t = (now - KT.t0) / 1000, dt = Math.min(0.05, (now - (KT.last || now)) / 1000); KT.last = now;
    const g = c.createLinearGradient(0, 0, 0, H); g.addColorStop(0, '#0e4a7a'); g.addColorStop(0.45, '#062a4a'); g.addColorStop(1, '#01060e');
    c.fillStyle = g; c.fillRect(0, 0, W, H);
    for (let k = 0; k < 5; k++) { // лучи света сверху
      const x = 60 + k * 95 + Math.sin(t * 0.4 + k) * 20;
      const rg = c.createLinearGradient(0, 0, 0, H * 0.7); rg.addColorStop(0, 'rgba(160,230,255,0.16)'); rg.addColorStop(1, 'rgba(160,230,255,0)');
      c.fillStyle = rg; c.beginPath(); c.moveTo(x - 14, 0); c.lineTo(x + 14, 0); c.lineTo(x + 70, H * 0.7); c.lineTo(x - 30, H * 0.7); c.closePath(); c.fill();
    }
    // силуэт на дне
    const sx = W / 2 + Math.sin(t * 0.3) * 10, sy = H - 40;
    c.fillStyle = 'rgba(30,4,18,0.92)';
    c.beginPath(); c.ellipse(sx, sy, 190, 70, 0, Math.PI, TAU); c.fill();
    c.beginPath(); c.moveTo(sx - 170, sy - 10); c.quadraticCurveTo(sx - 230, sy - 120, sx - 150, sy - 160); c.lineTo(sx - 140, sy - 150); c.quadraticCurveTo(sx - 200, sy - 110, sx - 150, sy - 30); c.closePath(); c.fill();
    c.strokeStyle = 'rgba(30,4,18,0.9)'; c.lineWidth = 4;
    c.beginPath(); c.moveTo(sx + 120, sy - 50); c.quadraticCurveTo(sx + 200, sy - 200 + Math.sin(t) * 10, sx + 120, sy - 300); c.moveTo(sx + 100, sy - 54); c.quadraticCurveTo(sx + 160, sy - 180 - Math.sin(t) * 10, sx + 60, sy - 260); c.stroke();
    KT.red = Math.min(1, Math.max(KT.red, (t - 5) / 2)); KT.red = Math.max(0, KT.red - dt * 0.05);
    if (KT.red > 0.02) {
      const bl = Math.sin(t * 1.1) > 0.96 ? 0.15 : 1;
      for (const ex of [sx + 50, sx + 100]) {
        const eg = c.createRadialGradient(ex, sy - 46, 0, ex, sy - 46, 30); eg.addColorStop(0, `rgba(255,40,60,${0.5 * KT.red})`); eg.addColorStop(1, 'rgba(255,40,60,0)');
        c.fillStyle = eg; c.fillRect(ex - 30, sy - 76, 60, 60);
        c.fillStyle = `rgba(255,90,100,${KT.red})`; c.beginPath(); c.ellipse(ex, sy - 46, 11, 4 * bl, -0.2, 0, TAU); c.fill();
      }
    }
    // бормотание со дна
    if (t > 7) { KT.sayT -= dt; if (KT.sayT <= 0) { KT.sayT = rnd(3, 5); KT.say = { text: pick(BOSS_SAY), t: 0 }; } }
    if (KT.say) {
      KT.say.t += dt; const a = Math.min(1, KT.say.t * 3) * Math.max(0, 1 - (KT.say.t - 1.6) * 2);
      if (a <= 0 && KT.say.t > 1.6) KT.say = null;
      else { c.globalAlpha = a; c.fillStyle = 'rgba(0,0,0,0.6)'; roundRect(c, sx - 10, sy - 150, 190, 40, 14); c.fill(); c.font = '900 22px sans-serif'; c.textAlign = 'center'; c.fillStyle = '#ff8aa8'; c.fillText(KT.say.text, sx + 85, sy - 122); c.globalAlpha = 1; }
    }
    // пузыри
    if (Math.random() < 0.25) KT.bubbles.push({ x: rnd(10, W - 10), y: H + 10, r: rnd(2, 6), v: rnd(30, 70) });
    c.strokeStyle = 'rgba(200,240,255,0.6)'; c.lineWidth = 1.5;
    for (const b of KT.bubbles) { b.y -= b.v * dt; b.x += Math.sin(t * 2 + b.r) * 0.3; c.beginPath(); c.arc(b.x, b.y, b.r, 0, TAU); c.stroke(); }
    KT.bubbles = KT.bubbles.filter(b => b.y > -10);
    // стая криля
    const tx = W / 2 + Math.sin(t * 0.55) * 140, ty = H * 0.42 + Math.sin(t * 0.8) * 90;
    for (const k of KT.swarm) {
      const ox = Math.cos(k.ph + t * 0.7) * k.rad, oy = Math.sin(k.ph * 1.7 + t * 0.9) * k.rad * 0.6;
      k.vx += (tx + ox - k.x) * 0.9 * dt; k.vy += (ty + oy - k.y) * 0.9 * dt;
      if (KT.tap) { const dx = k.x - KT.tap.x, dy = k.y - KT.tap.y, d = Math.hypot(dx, dy) || 1; if (d < 140) { k.vx += dx / d * 900 * dt * (1 - d / 140) * 6; k.vy += dy / d * 900 * dt * (1 - d / 140) * 6; } }
      const sp = Math.hypot(k.vx, k.vy), mx = 220; if (sp > mx) { k.vx *= mx / sp; k.vy *= mx / sp; }
      k.vx *= 0.985; k.vy *= 0.985; k.x += k.vx * dt; k.y += k.vy * dt;
      drawKrill(c, k.x, k.y, Math.atan2(k.vy, k.vx), k.s, t + k.ph);
    }
    if (KT.tap) { KT.tap.t -= dt; if (KT.tap.t <= 0) KT.tap = null; }
    for (const pp of KT.pops) { pp.t += dt; c.globalAlpha = Math.max(0, 1 - pp.t); c.font = '900 20px sans-serif'; c.textAlign = 'center'; c.fillStyle = '#ffb0c4'; c.fillText(pp.text, pp.x, pp.y - pp.t * 40); c.globalAlpha = 1; }
    KT.pops = KT.pops.filter(pp => pp.t < 1);
    // виньетка
    const vg = c.createRadialGradient(W / 2, H * 0.45, 140, W / 2, H / 2, 420); vg.addColorStop(0, 'rgba(0,0,0,0)'); vg.addColorStop(1, 'rgba(0,0,0,0.75)');
    c.fillStyle = vg; c.fillRect(0, 0, W, H);
    KT.raf = requestAnimationFrame(krillLoop);
  }
  let krillBack = 'menu';
  let krillNext = null;
  function openKrillTeaser(next) {
    krillNext = typeof next === 'function' ? next : null;
    $('krillBack').textContent = krillNext ? 'Дальше »' : 'Назад';
    krillBack = state === 'krill' ? krillBack : state;
    setState('krill');
    const box = $('krillLines'); box.innerHTML = '';
    const lines = KRILL_LINES.map(ln => ln === 'Глава 7. Скоро.' ? (krillNext ? 'Глава 7. Крилевая бездна.' : CHAPTERS[7] ? 'Глава 7. Ждёт за зимой.' : ln) : ln);
    lines.forEach((ln, i) => {
      const el = document.createElement('div'); el.className = 'tline' + (i === KRILL_LINES.length - 1 ? ' krilf' : '');
      el.textContent = ln; el.style.animationDelay = (0.6 + i * 1.15) + 's'; box.appendChild(el);
    });
    KT.swarm = [];
    for (let i = 0; i < 70; i++) KT.swarm.push({ x: rnd(80, 400), y: rnd(120, 400), vx: rnd(-40, 40), vy: rnd(-40, 40), ph: rnd(0, TAU), rad: rnd(20, 110), s: rnd(0.8, 1.4) });
    KT.bubbles = []; KT.pops = []; KT.tap = null; KT.red = 0; KT.say = null; KT.sayT = 2;
    KT.t0 = performance.now(); KT.last = 0; cancelAnimationFrame(KT.raf); KT.raf = requestAnimationFrame(krillLoop);
    Sound.music(null); Sound.sfx.whisper();
    setTimeout(() => { if (state === 'krill') { Sound.sfx.roar(); KT.red = 1; KT.say = { text: 'КРИЛЯТЬ!!!', t: 0 }; } }, (0.6 + (KRILL_LINES.length - 1) * 1.15) * 1000);
  }
  function closeKrill() { cancelAnimationFrame(KT.raf); if (krillNext) { const nx = krillNext; krillNext = null; nx(); } else if (krillBack === 'menu') openMenu(); else setState(krillBack); }

  // ------------------------------------------------------------------
  //  Прогресс: миграция старых сохранений
  // ------------------------------------------------------------------
  function migrateProfile() {
    const prof = loadProfile();
    const s2 = loadSave(2), s3 = loadSave(3);
    if (s2 || s3 || prof.ch2Done || prof.ch3Done) prof.ch1Done = true;
    if (s3 || prof.ch3Done) prof.ch2Done = true;
    if (prof.ch2Done && !prof.carry2) {
      // 0.02 не запоминала героиню после главы 2 – восстанавливаем
      if (s3) prof.carry2 = { level: s3.level, up: s3.up, bonus: s3.bonus || {}, shards: s3.shards || 0 };
      else {
        const L = Math.max(46, prof.carry ? prof.carry.level : 0), rb = refBuild(L);
        prof.carry2 = { level: L, up: rb.up, bonus: rb.bonus, shards: L * 3, restored: true };
      }
    }
    if (!prof.settings) prof.settings = { diff: 'normal' };
    // 0.10: прокачка своя в каждой главе. Звёзды – за всех уже побеждённых боссов,
    // незаконченные главы начинаются заново (старые уровни с новыми не стыкуются)
    if (!prof.prog2) {
      prof.starsGot = prof.starsGot || {};
      for (const n of [1, 2, 3, 4, 5, 6]) {
        const C = CHAPTERS[n]; if (!C) continue;
        const sv = loadSave(n);
        C.bosses.forEach((k, i) => { if (prof['ch' + n + 'Done'] || (sv && sv.defeated && sv.defeated[i])) prof.starsGot[n + ':' + i] = 1; });
        if (sv && (sv.v || 0) < 5) { prof.restarted = (prof.restarted || []).concat(n); try { localStorage.removeItem(saveKey(n)); } catch (e) { /* ignore */ } }
      }
      prof.stars = Object.keys(prof.starsGot).length;
      prof.talents = prof.talents || {};
      delete prof.hero;
      prof.prog2 = true;
    }
    gloryMigrate(prof); // 0.31: достижения 2.0 и таланты-созвездия
    if (prof.talents && prof.talents.key) { prof.talents.pick4 = 1; delete prof.talents.key; } // 0.31.3: «Отмычка» стала «Богатым выбором»
    if (!prof.relicLv) { prof.relicLv = {}; for (const id of (prof.relics || [])) if (RELICS[id]) prof.relicLv[id] = 1; } // 0.33: у реликвий есть уровни
    saveProfile(prof);
    return prof;
  }

  // ------------------------------------------------------------------
  //  Финальная сцена
  // ------------------------------------------------------------------
  function startVictoryCutscene() {
    if (NET.host) NetT.send(-1, { t: 'vic' }); // победа – у всех сразу
    if (NET.on && G.netRun) life('coop'); mutReward(); // мутаторы вместе – звёзды получает каждая
    if (G.daily) { dailyAdd(1000); dailyFinish(false); }
    try { gloryWin(); } catch (e) { /* ignore */ }
    if (!G.daily) life('spts', 30); // глава пройдена – искры сезона
    recordRunEnd('глава пройдена');
    G.cutscene = { t: 0 };
    G.enemies.forEach(e => burst(e.x, e.y, 8, '#fff', 100));
    G.enemies.length = 0; G.ebullets.length = 0; G.hazards.length = 0; G.beams.length = 0;
    showBanner('ПОБЕДА!', bosses[bosses.length - 1].name + ' повержен');
    Sound.music('win');
    const prof = loadProfile();
    const build = { level: P.level, up: P.up, bonus: P.bonus, shards: P.shards };
    prof['ch' + CHN + 'Done'] = true;
    prof[CHN === 1 ? 'carry' : 'carry' + CHN] = build;
    saveProfile(prof);
    if (!NET.on) try { localStorage.removeItem(saveKey(CHN)); } catch (e) { /* ignore */ }
  }
  function updateCutscene(dt) {
    const cs = G.cutscene; cs.t += dt;
    if (cs.kind === 'teamup') { updateTeamUp(dt, cs); return; }
    if (CFG.noCage) {
      P.moving = false; P.t += dt;
      if (Math.random() < 0.3) part(P.x + rnd(-60, 60), P.y + rnd(-70, 10), 0, -40, 1.4, 6, CHN === 4 ? '#3ff0a0' : '#ffd25a');
      if (cs.t > 3.5 && !G.victoryShown) { G.victoryShown = true; if (CHN === 4) { if (NET.client) { toast('💭 Хозяйка выбирает концовку…'); if (NET.c4) finishCh4(NET.c4); } else openChoice(); } else if (CHN === 7) Intro.start('end7', () => showVictory()); else showVictory(); }
      return;
    }
    const cx = tc(CAGE.x), cy = tc(CAGE.y);
    const dx = cx - 80 - P.x, dy = cy + 30 - P.y, d = Math.hypot(dx, dy);
    if (cs.t > 4 && d > 4) { const s = Math.min(d, 220 * dt); P.x += dx / d * s; P.y += dy / d * s; P.moving = true; P.face = dx > 0 ? 1 : -1; }
    else { P.moving = false; if (cs.t > 4) P.face = 1; }
    P.t += dt;
    if (cs.t > 5.5 && G.cageOpen < 1) {
      G.cageOpen = Math.min(1, G.cageOpen + dt / 1.5);
      if (Math.random() < 0.5) part(cx + rnd(-30, 30), cy + rnd(-40, 20), rnd(-30, 30), rnd(-90, -30), 1, 4, pick(['#ffd25a', '#ff7a2f', '#ff9db5']));
      if (G.cageOpen >= 1) { say(['', 'Спасибо, Крилесса! Ты меня спасла! ❤', 'Крилесса, ты лучшая! Больше никаких кринж-стихов! ❤', 'Рыжовая, ты меня спасла! Теперь мы квиты! ❤🔥'][CHN], 5); Sound.sfx.win(); }
    }
    if (G.cageOpen >= 1 && Math.random() < 0.3) part(cx + rnd(-60, 60), cy + rnd(-60, 20), 0, -40, 1.4, 6, '#ff5b8a');
    if (cs.t > 11 && !G.victoryShown) { G.victoryShown = true; showVictory(); }
  }

  // ------------------------------------------------------------------
  //  Рендер
  // ------------------------------------------------------------------
  function drawCage(c, x, y, open, t) {
    shadow(c, x, y + 32, 40, 10);
    const bob = Math.sin(t * 2) * 3 - open * 14;
    const R = 26 + open * 16;
    if (CFG.hostage === 'krilessa') {
      if (open > 0) { c.fillStyle = `rgba(255,210,90,${open * 0.35})`; c.beginPath(); c.arc(x, y - 6 + bob, R + 14, 0, TAU); c.fill(); }
      drawKrilessa(c, x, y + 16 + bob, t, 1, 1.6 + open * 0.4, 1, open > 0);
    } else if (ART.ryzhovaSmall) {
      if (open > 0) { c.fillStyle = `rgba(255,210,90,${open * 0.35})`; c.beginPath(); c.arc(x, y - 6 + bob, R + 14, 0, TAU); c.fill(); }
      c.save(); c.beginPath(); c.arc(x, y - 6 + bob, R, 0, TAU); c.clip();
      c.drawImage(ART.ryzhovaSmall, x - R, y - 6 - R + bob, R * 2, R * 2); c.restore();
      c.strokeStyle = '#ff7a2f'; c.lineWidth = 3; c.beginPath(); c.arc(x, y - 6 + bob, R, 0, TAU); c.stroke();
    }
    const lift = open * 90;
    c.globalAlpha = 1 - open * 0.8;
    const gold = CHN === 2 ? '#ff3ea5' : CHN === 3 ? '#bfeaff' : '#ffd25a', dark = CHN === 2 ? '#a0206a' : CHN === 3 ? '#6a8ab8' : '#d9a520';
    c.fillStyle = '#7a5a1a'; c.beginPath(); c.ellipse(x, y + 28, 38, 9, 0, 0, TAU); c.fill();
    c.fillStyle = gold; c.beginPath(); c.ellipse(x, y + 25, 38, 8, 0, 0, TAU); c.fill();
    c.strokeStyle = dark; c.lineWidth = 3;
    for (let i = 0; i < 7; i++) { const bx = x - 33 + i * 11; c.beginPath(); c.moveTo(bx, y + 25 - lift); c.lineTo(bx, y - 38 - lift); c.stroke(); }
    c.lineWidth = 4;
    c.beginPath(); c.ellipse(x, y - 38 - lift, 34, 12, 0, Math.PI, TAU); c.stroke();
    c.beginPath(); c.moveTo(x - 34, y - 38 - lift); c.lineTo(x + 34, y - 38 - lift); c.stroke();
    c.fillStyle = gold; c.beginPath(); c.arc(x, y - 52 - lift, 5, 0, TAU); c.fill();
    c.globalAlpha = 1;
  }
  // ------------------------------------------------------------------
  //  Объём: освещение «запекается» один раз на вид спрайта и направление взгляда,
  //  а каждый кадр накладывается поверх живой анимации (только на сам спрайт).
  // ------------------------------------------------------------------
  // без объёма: полупрозрачные свечения, пиксельные и «глючные» мобы, герои-фото
  const VOL_SKIP = new Set(['fan', 'tv', 'zyamabot', 'wisp', 'shade', 'frostwisp', 'glitchbug', 'errorwin', 'pixel', 'eyes', 'staticball', 'bitfly', 'reflection', 'zyama', 'zyama2', 'zyamaInf', 'zmirror']);
  const VOL = new Map(); let volArea = 0, volOn = true;
  const VOL_MAX_AREA = 6e6; // ~24 МБ на всё
  const volCv = makeCanvas(256, 256), vx = volCv.getContext('2d');
  function volBlur(a, w, h, r) {
    const o = new Float32Array(a.length), t = new Float32Array(a.length), k = 1 / (2 * r + 1);
    for (let y = 0; y < h; y++) {
      const row = y * w; let sum = 0;
      for (let x = -r; x <= r; x++) sum += a[row + Math.min(w - 1, Math.max(0, x))];
      for (let x = 0; x < w; x++) { t[row + x] = sum * k; sum += a[row + Math.min(w - 1, x + r + 1)] - a[row + Math.max(0, x - r)]; }
    }
    for (let x = 0; x < w; x++) {
      let sum = 0;
      for (let y = -r; y <= r; y++) sum += t[Math.min(h - 1, Math.max(0, y)) * w + x];
      for (let y = 0; y < h; y++) { o[y * w + x] = sum * k; sum += t[Math.min(h - 1, y + r + 1) * w + x] - t[Math.max(0, y - r) * w + x]; }
    }
    return o;
  }
  function bakeVolume(half, bakeFn, BS, core) {
    const n = Math.ceil(half * 2 * BS), cv = makeCanvas(n, n), x = cv.getContext('2d');
    x.setTransform(BS, 0, 0, BS, n / 2, n / 2); x.save(); bakeFn(x); x.restore();
    const d = x.getImageData(0, 0, n, n).data, N = n * n;
    const A = new Float32Array(N), Lm = new Float32Array(N);
    for (let i = 0; i < N; i++) {
      const a = d[i * 4 + 3] / 255, sa = clamp((a - 0.45) / 0.4, 0, 1); // полупрозрачное (свечения) не считаем телом
      A[i] = sa; Lm[i] = sa * (0.3 * d[i * 4] + 0.59 * d[i * 4 + 1] + 0.11 * d[i * 4 + 2]) / 255;
    }
    const R = Math.max(3, Math.round(n * 0.035));
    const Hm = volBlur(volBlur(volBlur(A, n, n, R), n, n, R), n, n, R), D = volBlur(volBlur(Lm, n, n, 2), n, n, 2);
    const ln = Math.hypot(-0.55, -0.65, 0.52), lx = -0.55 / ln, ly = -0.65 / ln, lz = 0.52 / ln, hn = Math.hypot(lx, ly, lz + 1);
    const out = x.createImageData(n, n), o = out.data, gk = 9 * 120 / n;
    // «ядро» для мобов: освещение только внутри тела, мягко гаснет к краям – тогда его можно
    // класть прямо поверх живого спрайта, и шевелящиеся края не пачкают землю
    const Cm = core ? volBlur(volBlur(A, n, n, Math.max(2, Math.round(n * 0.05))), n, n, Math.max(2, Math.round(n * 0.05))) : null;
    for (let y = 1; y < n - 1; y++) for (let xx = 1; xx < n - 1; xx++) {
      const i = y * n + xx; if (A[i] < 0.02) continue;
      const gx = (Hm[i + 1] - Hm[i - 1]) * gk * 10 + (D[i + 1] - D[i - 1]) * 1.4, gy = (Hm[i + n] - Hm[i - n]) * gk * 10 + (D[i + n] - D[i - n]) * 1.4;
      let nx = -gx, ny = -gy, nz = 1; const nl = Math.hypot(nx, ny, nz); nx /= nl; ny /= nl; nz /= nl;
      const dif = Math.max(0, nx * lx + ny * ly + nz * lz), spec = Math.pow(Math.max(0, (nx * lx + ny * ly + nz * (lz + 1)) / hn), 28);
      const rim = Math.pow(1 - nz, 1.6) * Math.max(0, -(nx * lx + ny * ly));
      const kf = (0.42 + 0.85 * dif) * (0.7 + 0.3 * Math.min(1, Hm[i] * 1.5));
      // свет/тень одним слоем: темнее – чёрным, светлее – белым; сверху блик и голубая кромка
      let r0, g0, b0, a0;
      if (kf < 1) { r0 = g0 = b0 = 0; a0 = (1 - kf) * 0.9; } else { r0 = g0 = b0 = 255; a0 = Math.min(0.45, (kf - 1) * 0.6); }
      const lay = (r, g, b, al) => { const na = al + a0 * (1 - al); if (na <= 0) return; r0 = (r * al + r0 * a0 * (1 - al)) / na; g0 = (g * al + g0 * a0 * (1 - al)) / na; b0 = (b * al + b0 * a0 * (1 - al)) / na; a0 = na; };
      lay(255, 255, 255, Math.min(0.8, spec * 0.75));
      lay(150, 215, 255, Math.min(0.6, rim * 0.6));
      const cm = core ? clamp((Cm[i] - 0.62) / 0.3, 0, 1) : 1;
      o[i * 4] = r0; o[i * 4 + 1] = g0; o[i * 4 + 2] = b0; o[i * 4 + 3] = Math.round(a0 * A[i] * cm * 255);
    }
    x.setTransform(1, 0, 0, 1, 0, 0); x.clearRect(0, 0, n, n); x.putImageData(out, 0, 0);
    if (!core) return cv;
    // обрезаем по непрозрачной части – меньше копировать каждый кадр
    let x0 = n, y0 = n, x1 = -1, y1 = -1;
    for (let y = 0; y < n; y++) for (let xx = 0; xx < n; xx++) if (o[(y * n + xx) * 4 + 3] > 3) { if (xx < x0) x0 = xx; if (xx > x1) x1 = xx; if (y < y0) y0 = y; if (y > y1) y1 = y; }
    if (x1 < 0) return null;
    const cw = x1 - x0 + 1, chh = y1 - y0 + 1, crop = makeCanvas(cw, chh);
    crop.getContext('2d').drawImage(cv, x0, y0, cw, chh, 0, 0, cw, chh);
    crop.ox = x0 / BS - half; crop.oy = y0 / BS - half; crop.w = cw / BS; crop.h = chh / BS;
    return crop;
  }
  function getVol(key, half, bakeFn, BS, core) {
    let ov = VOL.get(key);
    if (ov !== undefined) { VOL.delete(key); VOL.set(key, ov); return ov; } // недавно использованные – в конец
    try { ov = bakeVolume(half, bakeFn, BS, core); } catch (err) { ov = null; }
    VOL.set(key, ov);
    if (ov) volArea += ov.width * ov.height;
    while (volArea > VOL_MAX_AREA && VOL.size > 1) { const [k0, v0] = VOL.entries().next().value; VOL.delete(k0); if (v0) volArea -= v0.width * v0.height; }
    return ov;
  }
  // мобы: спрайт как раньше + одна картинка освещения сверху (дёшево, их много на экране)
  function drawVolCore(c, key, half, drawFn, bakeFn) {
    drawFn(c);
    if (!volOn) return;
    const ov = getVol(key, half, bakeFn, 2, true);
    if (ov) c.drawImage(ov, ov.ox, ov.oy, ov.w, ov.h);
  }
  // боссы: полный объём через отдельный холст (босс на экране один)
  function drawVol(c, key, half, drawFn, bakeFn, BS = 2) {
    if (!volOn) { drawFn(c); return; }
    const ov = getVol(key, half, bakeFn, BS);
    const m = c.getTransform(), ps = Math.hypot(m.a, m.b), px = Math.ceil(half * 2 * ps);
    if (!ov || px < 6 || px > 900) { drawFn(c); return; }
    if (volCv.width < px) { volCv.width = volCv.height = Math.min(960, Math.ceil(px * 1.15)); }
    vx.setTransform(1, 0, 0, 1, 0, 0); vx.globalCompositeOperation = 'source-over'; vx.globalAlpha = 1; vx.clearRect(0, 0, px, px);
    vx.save(); vx.setTransform(ps, 0, 0, ps, px / 2, px / 2); drawFn(vx); vx.restore();
    vx.globalCompositeOperation = 'source-atop'; vx.globalAlpha = 1; vx.drawImage(ov, 0, 0, ov.width, ov.height, 0, 0, px, px);
    vx.globalCompositeOperation = 'source-over';
    c.drawImage(volCv, 0, 0, px, px, -half, -half, half * 2, half * 2);
  }
  // героини: на маленьких фигурках автоматический объём делает лица тусклыми,
  // поэтому у них ручная доводка (градиенты, блики) прямо в спрайтах, а объём – выключен
  const HERO_VOL = false;
  function drawHeroV(id, c, x, y, t, face, s, alpha, moving) {
    if (!HERO_VOL || !volOn || id === 'ryzhovaya') { drawHero(id, c, x, y, t, face, s, alpha, moving); return; }
    c.save(); c.translate(x, y); c.scale(s, s); c.globalAlpha *= alpha;
    const out = id === 'tessa' ? TESSA_OUTFIT : '';
    drawVol(c, 'H|' + id + '|' + face + '|' + out, 34, cc => drawHero(id, cc, 0, 0, t, face, 1, 1, moving), xx => drawHero(id, xx, 0, 0, 0.3, face, 1, 1, false), 3);
    c.restore();
  }
  function drawBoss(c, b) {
    const t = b.anim;
    shadow(c, b.x, b.y + b.r * 0.75, b.r * 0.9 * (1 - Math.min(0.5, b.z / 260)), b.r * 0.28);
    c.save();
    const sx = b.mode === 'trans' ? Math.sin(t * 50) * 4 : 0;
    c.translate(b.x + sx, b.y - b.z);
    c.globalAlpha = b.alpha;
    const bsp = b.def.sprite || b.kind, face = P.x > b.x ? 1 : -1;
    if (VOL_SKIP.has(bsp)) BSPR[bsp](c, b, t, face);
    else {
      const flipK = Math.cos(b.look || 0) < 0 ? 1 : 0;
      drawVol(c, 'B|' + bsp + '|' + face + '|' + flipK + '|' + (b.stage >= 2 ? 1 : 0), b.r * 2.3, cc => BSPR[bsp](cc, b, t, face), xx => {
        const fl = b.flash; b.flash = 0; try { BSPR[bsp](xx, b, 0.3, face); } finally { b.flash = fl; }
      }, 1.5);
    }
    c.restore();
    if (b.kind === 'zyama2' || b.kind === 'zyamaInf') {
      const inf = b.kind === 'zyamaInf';
      c.save(); c.translate(b.x + 30, b.y - b.z - 74 + (inf ? Math.sin(t * 4) * 3 : 0)); c.rotate(inf ? Math.sin(t * 2) * 0.25 : 0.2);
      c.fillStyle = inf ? RAINBOW[Math.floor(t * 6) % RAINBOW.length] : '#ff3ea5'; roundRect(c, -16, -10, 32, 20, 6); c.fill();
      c.fillStyle = '#fff'; c.font = inf ? '900 18px sans-serif' : '900 13px sans-serif'; c.textAlign = 'center'; c.fillText(inf ? '∞' : '2.0', 0, inf ? 6 : 5);
      c.restore();
    }
    if (b.shield) {
      const g = 0.5 + Math.sin(t * 6) * 0.3;
      c.strokeStyle = `rgba(191,234,255,${0.6 + g * 0.3})`; c.lineWidth = 5;
      c.fillStyle = `rgba(191,234,255,${0.12 + g * 0.08})`;
      c.beginPath(); c.arc(b.x, b.y - b.z - 10, b.r + 26, 0, TAU); c.fill(); c.stroke();
    }
    if (b.stunT > 0) {
      for (let k = 0; k < 3; k++) { const a = t * 4 + k * TAU / 3; c.fillStyle = '#ffe04a'; star(c, b.x + Math.cos(a) * 30, b.y - b.r - 30 + Math.sin(a) * 8, 7, t); c.fill(); }
    }
    if (b.burnT > 0 && Math.random() < 0.4) part(b.x + rnd(-b.r, b.r), b.y + rnd(-b.r, b.r * 0.5), 0, -60, 0.5, 5, '#ff8a2a');
    if (b.mode === 'trans') {
      c.strokeStyle = `rgba(255,255,255,${0.4 + Math.sin(t * 20) * 0.3})`; c.lineWidth = 4;
      c.beginPath(); c.arc(b.x, b.y - b.z, b.r + 18 + Math.sin(t * 10) * 4, 0, TAU); c.stroke();
    }
  }
  const FX_COL = { dark: '199,125,255', crystal: '91,227,255', honey: '255,200,40', lava: '255,100,30', glitch: '63,240,160',
    bolt: '255,240,120', toxic: '110,255,60', rainbow: '255,120,220', cream: '255,255,255', meteor: '255,120,30' };
  function drawHazard(c, h) {
    if (h.kind === 'wavewarn') { // где будут проходы: зелёные дорожки от босса
      const a = 0.35 + 0.25 * Math.sin(h.t * 22), k = clamp(h.t / 0.25, 0, 1);
      for (const g of h.gaps) {
        c.fillStyle = `rgba(110,255,160,${0.26 * k})`;
        c.beginPath(); c.moveTo(h.x, h.y); c.arc(h.x, h.y, 520 * k, g - h.half, g + h.half); c.closePath(); c.fill();
        c.strokeStyle = `rgba(170,255,200,${(a + 0.25) * k})`; c.lineWidth = 4; c.setLineDash([14, 9]);
        for (const e of [-1, 1]) { c.beginPath(); c.moveTo(h.x + Math.cos(g + e * h.half) * 40, h.y + Math.sin(g + e * h.half) * 40); c.lineTo(h.x + Math.cos(g + e * h.half) * 520 * k, h.y + Math.sin(g + e * h.half) * 520 * k); c.stroke(); }
        c.setLineDash([]);
        for (let r = 90; r < 520 * k; r += 110) { // стрелки «сюда»
          const x = h.x + Math.cos(g) * r, y = h.y + Math.sin(g) * r;
          c.save(); c.translate(x, y); c.rotate(g); c.fillStyle = `rgba(200,255,215,${a * k})`;
          c.beginPath(); c.moveTo(10, 0); c.lineTo(-6, -8); c.lineTo(-2, 0); c.lineTo(-6, 8); c.closePath(); c.fill(); c.restore();
        }
      }
      return;
    }
    if (h.kind === 'wave') { // кольцо с проходами
      const gs = h.gaps ? h.gaps.slice().sort((x, y) => x - y) : null;
      const arcs = [];
      if (!gs) arcs.push([0, TAU]);
      else for (let i = 0; i < gs.length; i++) arcs.push([gs[i] + h.half, (i + 1 < gs.length ? gs[i + 1] : gs[0] + TAU) - h.half]);
      c.lineCap = 'round';
      c.strokeStyle = 'rgba(255,80,60,0.85)'; c.lineWidth = h.thick;
      for (const [a0, a1] of arcs) { c.beginPath(); c.arc(h.x, h.y, h.r, a0, a1); c.stroke(); }
      c.strokeStyle = 'rgba(255,230,180,0.9)'; c.lineWidth = 3;
      for (const [a0, a1] of arcs) { c.beginPath(); c.arc(h.x, h.y, h.r, a0, a1); c.stroke(); }
      c.lineCap = 'butt';
      if (gs) for (const g of gs) { // проход подсвечен зелёным
        c.strokeStyle = 'rgba(120,255,170,0.35)'; c.lineWidth = h.thick * 0.6;
        c.beginPath(); c.arc(h.x, h.y, h.r, g - h.half * 0.8, g + h.half * 0.8); c.stroke();
      }
      return;
    }
    if (h.kind === 'zone') {
      const a = clamp(h.t / 0.4, 0, 1) * clamp((h.delay + h.dur - h.t) / 0.5, 0, 1);
      const col = FX_COL[h.fx] || '255,200,40';
      c.fillStyle = `rgba(${col},${0.32 * a})`; c.beginPath(); c.arc(h.x, h.y, h.r, 0, TAU); c.fill();
      c.strokeStyle = `rgba(${col},${0.7 * a})`; c.lineWidth = 2; c.stroke();
      return;
    }
    const k = clamp(h.t / h.delay, 0, 1);
    const col = FX_COL[h.fx] || '255,40,40';
    if (!h.done) {
      c.fillStyle = `rgba(${col},0.18)`; c.strokeStyle = `rgba(${col},0.85)`; c.lineWidth = 2;
      if (h.kind === 'circle') {
        c.beginPath(); c.arc(h.x, h.y, h.r, 0, TAU); c.fill(); c.stroke();
        c.fillStyle = `rgba(${col},0.32)`; c.beginPath(); c.arc(h.x, h.y, h.r * k, 0, TAU); c.fill();
        if (h.fx === 'meteor') { const fx = h.x + 230 * (1 - k), fy = h.y - 330 * (1 - k); drawFireball(c, fx, fy, Math.atan2(330, -230), 2.4); }
        if (h.fx === 'icicle' || h.fx === 'rain') { c.fillStyle = '#e6fbff'; c.beginPath(); c.moveTo(h.x - 7, h.y - 260 * (1 - k) - 30); c.lineTo(h.x + 7, h.y - 260 * (1 - k) - 30); c.lineTo(h.x, h.y - 260 * (1 - k)); c.fill(); }
      } else {
        c.save(); c.translate(h.x, h.y); c.rotate(h.ang);
        c.fillRect(0, -h.w / 2, h.len, h.w); c.strokeRect(0, -h.w / 2, h.len, h.w);
        c.fillStyle = `rgba(${col},0.32)`; c.fillRect(0, -h.w / 2, h.len * k, h.w);
        c.restore();
      }
    } else if (h.fx === 'tongue') {
      const a = 1 - (h.t - h.delay) / 0.3;
      c.save(); c.translate(h.x, h.y); c.rotate(h.ang); c.globalAlpha = clamp(a, 0, 1);
      c.fillStyle = '#ff6f91'; c.fillRect(0, -9, h.len, 18);
      c.beginPath(); c.arc(h.len, 0, 14, 0, TAU); c.fill(); c.restore();
    } else if (h.kind === 'line') {
      const a = clamp(1 - (h.t - h.delay) / 0.3, 0, 1);
      c.save(); c.translate(h.x, h.y); c.rotate(h.ang);
      c.fillStyle = `rgba(255,255,255,${a * 0.8})`; c.fillRect(0, -h.w / 2, h.len, h.w); c.restore();
    } else if (h.kind === 'circle') {
      const a = 1 - (h.t - h.delay) / 0.3;
      c.strokeStyle = `rgba(255,255,255,${clamp(a, 0, 1) * 0.8})`; c.lineWidth = 4;
      c.beginPath(); c.arc(h.x, h.y, h.r * (1 + (1 - a) * 0.3), 0, TAU); c.stroke();
    }
  }
  function drawBeam(c, bm) {
    if (bm.x === undefined) return;
    const ca = Math.cos(bm.ang), sa = Math.sin(bm.ang);
    if (bm.t < bm.warm) {
      c.strokeStyle = `rgba(255,60,60,${0.4 + Math.sin(bm.t * 30) * 0.3})`; c.lineWidth = 2;
      c.setLineDash([10, 8]); c.beginPath(); c.moveTo(bm.x, bm.y); c.lineTo(bm.x + ca * 560, bm.y + sa * 560); c.stroke(); c.setLineDash([]);
      return;
    }
    const col = bm.rainbow ? RAINBOW[Math.floor(bm.t * 10) % 7] : bm.mouth ? '#3ff0ff' : '#ff3ea5';
    c.lineCap = 'round';
    c.beginPath(); c.moveTo(bm.x, bm.y); c.lineTo(bm.x + ca * bm.len, bm.y + sa * bm.len);
    c.strokeStyle = col; c.globalAlpha = 0.35; c.lineWidth = bm.w * 1.6; c.stroke();
    c.globalAlpha = 1; c.lineWidth = bm.w * 0.7; c.stroke();
    c.strokeStyle = '#ffffff'; c.lineWidth = bm.w * 0.25; c.stroke();
    c.lineCap = 'butt';
  }
  function drawPickup(c, p) {
    const bob = Math.sin(p.t * 5 + p.x) * 2;
    if (p.kind === 'xp') {
      const col = p.v >= 30 ? '#ffd23a' : p.v >= 10 ? '#d36bff' : p.v >= 3 ? '#4dff9a' : '#5bc8ff';
      const s = p.v >= 30 ? 9 : p.v >= 10 ? 8 : p.v >= 3 ? 6.5 : 5;
      c.fillStyle = col; c.strokeStyle = paperOn ? 'rgba(75,46,30,.85)' : 'rgba(255,255,255,0.8)'; c.lineWidth = paperOn ? 1.1 : 1.5;
      c.beginPath(); c.moveTo(p.x, p.y - s + bob); c.lineTo(p.x + s * 0.7, p.y + bob); c.lineTo(p.x, p.y + s + bob); c.lineTo(p.x - s * 0.7, p.y + bob); c.closePath(); c.fill(); c.stroke();
    } else if (p.kind === 'heart') {
      c.fillStyle = paperOn ? '#e8504a' : '#ff3b5c'; c.strokeStyle = paperOn ? '#4b2e1e' : '#fff'; c.lineWidth = paperOn ? 1.4 : 2;
      heartPath(c, p.x, p.y + bob, 11); c.fill(); c.stroke();
    } else if (p.kind === 'shard') {
      const s = SHARDS[p.sid];
      const g = 0.5 + Math.sin(p.t * 6) * 0.3;
      c.fillStyle = s.col; c.globalAlpha = 0.3 * g; c.beginPath(); c.arc(p.x, p.y + bob, 13, 0, TAU); c.fill(); c.globalAlpha = 1;
      c.strokeStyle = '#fff'; c.lineWidth = 1.5;
      c.beginPath(); c.moveTo(p.x, p.y - 9 + bob); c.lineTo(p.x + 6, p.y - 2 + bob); c.lineTo(p.x + 3, p.y + 8 + bob); c.lineTo(p.x - 3, p.y + 8 + bob); c.lineTo(p.x - 6, p.y - 2 + bob); c.closePath(); c.fill(); c.stroke();
    } else if (p.kind === 'star') {
      c.fillStyle = `rgba(255,224,138,${0.3 + Math.sin(p.t * 6) * 0.15})`; c.beginPath(); c.arc(p.x, p.y + bob, 15, 0, TAU); c.fill();
      c.fillStyle = '#ffe08a'; c.strokeStyle = '#fff'; c.lineWidth = 2; star(c, p.x, p.y + bob, 10, p.t * 2); c.fill(); c.stroke();
    } else if (p.kind === 'key') {
      c.fillStyle = `rgba(255,210,90,${0.25 + Math.sin(p.t * 6) * 0.12})`; c.beginPath(); c.arc(p.x, p.y + bob, 14, 0, TAU); c.fill();
      const spr = emojiSprite('🔑', 18); c.drawImage(spr, p.x - spr.width / 4, p.y + bob - spr.height / 4, spr.width / 2, spr.height / 2);
    } else {
      c.fillStyle = '#5bc8ff'; c.strokeStyle = '#fff'; c.lineWidth = 2;
      star(c, p.x, p.y + bob, 11, p.t); c.fill(); c.stroke();
    }
  }
  // 1.0: обводка чернилами для предметов, которые рисуются каждый кадр (сундуки): рисуем во временный холст, обводим, переносим
  const INKED = { a: null, o: null };
  function drawInked(c, x, y, R, fn) {
    if (!paperOn) { fn(c); return; }
    const m = c.getTransform(), sc = Math.hypot(m.a, m.b), px = Math.ceil(R * 2 * sc);
    if (px < 8 || px > 700) { fn(c); return; }
    if (!INKED.a) { INKED.a = makeCanvas(8, 8); INKED.o = makeCanvas(8, 8); }
    const a = INKED.a, o = INKED.o; if (a.width < px) { a.width = a.height = o.width = o.height = Math.ceil(px * 1.1); }
    const ac = a.getContext('2d'); ac.setTransform(1, 0, 0, 1, 0, 0); ac.clearRect(0, 0, px, px); ac.setTransform(sc, 0, 0, sc, px / 2 - x * sc, px / 2 - y * sc); fn(ac);
    const oc = o.getContext('2d'); oc.setTransform(1, 0, 0, 1, 0, 0); oc.globalCompositeOperation = 'source-over'; oc.clearRect(0, 0, px, px);
    const w = Math.max(1, 1.2 * sc);
    for (let k = 0; k < 8; k++) { const an = k * Math.PI / 4; oc.drawImage(a, 0, 0, px, px, Math.cos(an) * w, Math.sin(an) * w, px, px); }
    oc.globalCompositeOperation = 'source-in'; oc.fillStyle = 'rgba(75,46,30,.9)'; oc.fillRect(0, 0, px, px);
    oc.globalCompositeOperation = 'source-over'; oc.drawImage(a, 0, 0, px, px, 0, 0, px, px);
    c.drawImage(o, 0, 0, px, px, x - R, y - R, R * 2, R * 2);
  }
  function drawChest(c, ch) {
    const tell = ch.mimic && !ch.open && Math.sin(G.time * 1.3 + ch.x * 0.01) > 0.97;
    drawInked(c, ch.x, ch.y, 46, cc => drawChestSprite(cc, ch.x, ch.y, ch.tier || 'wood', ch.open, CHN, G.time, { twitch: tell, eyes: ch.mimic && !ch.open && (tell || hasRelic('compass')) }));
  }
  function drawChestOld(c, ch) {
    shadow(c, ch.x, ch.y + 14, 18, 5);
    if (ch.open) {
      c.fillStyle = '#6b3d1f'; c.fillRect(ch.x - 16, ch.y - 4, 32, 18);
      c.fillStyle = '#3a1f0f'; c.fillRect(ch.x - 14, ch.y - 4, 28, 6);
      c.fillStyle = '#8b5530'; c.fillRect(ch.x - 16, ch.y - 22, 32, 10);
      return;
    }
    const g = Math.sin(G.time * 4 + ch.x) * 0.5 + 0.5;
    c.fillStyle = `rgba(255,210,90,${0.15 + g * 0.2})`; c.beginPath(); c.arc(ch.x, ch.y, 28, 0, TAU); c.fill();
    c.fillStyle = '#8b5530'; c.strokeStyle = '#3a1f0f'; c.lineWidth = 2;
    c.fillRect(ch.x - 16, ch.y - 10, 32, 24); c.strokeRect(ch.x - 16, ch.y - 10, 32, 24);
    c.fillStyle = '#a0643a'; c.fillRect(ch.x - 16, ch.y - 14, 32, 8);
    c.fillStyle = '#ffd25a'; c.fillRect(ch.x - 16, ch.y - 2, 32, 3); c.fillRect(ch.x - 3, ch.y - 5, 6, 8);
  }
  function drawShrine(c, s) {
    const g = 0.5 + Math.sin(G.time * 3 + s.x) * 0.5;
    const col = s.state === 'done' ? '199,125,255' : s.state === 'active' ? '255,70,70' : '91,227,255';
    if (s.state === 'active') {
      c.strokeStyle = `rgba(255,70,70,${0.25 + g * 0.2})`; c.lineWidth = 3; c.setLineDash([12, 10]);
      c.beginPath(); c.arc(s.x, s.y, 300, 0, TAU); c.stroke(); c.setLineDash([]);
    }
    c.fillStyle = `rgba(${col},${0.15 + g * 0.15})`; c.beginPath(); c.arc(s.x, s.y, 34, 0, TAU); c.fill();
    c.fillStyle = '#6a6a7a'; c.strokeStyle = '#2a2a3a'; c.lineWidth = 2;
    c.beginPath(); c.ellipse(s.x, s.y + 6, 24, 9, 0, 0, TAU); c.fill(); c.stroke();
    c.fillStyle = '#8a8a9a'; roundRect(c, s.x - 8, s.y - 30, 16, 36, 4); c.fill(); c.stroke();
    c.fillStyle = `rgb(${col})`; star(c, s.x, s.y - 16, 6 + g * 2, G.time, 4); c.fill();
    if (s.state === 'idle') {
      c.font = 'bold 10px sans-serif'; c.textAlign = 'center'; c.fillStyle = '#bff6ff';
      c.fillText('ИСПЫТАНИЕ', s.x, s.y - 40);
    } else if (s.state === 'done') {
      for (let k = 0; k < 3; k++) {
        const a0 = G.time * (2 + k);
        c.strokeStyle = `rgba(199,125,255,${0.55 - k * 0.13})`; c.lineWidth = 3;
        c.beginPath(); c.arc(s.x, s.y + 4, 16 + k * 8 + Math.sin(G.time * 3 + k) * 2, a0, a0 + 4.2); c.stroke();
      }
      c.font = 'bold 10px sans-serif'; c.textAlign = 'center'; c.fillStyle = '#e0b0ff';
      c.fillText('ПОРТАЛ', s.x, s.y - 40);
    }
  }
  function drawGate(c) {
    if (gateOpen) return;
    const h = CASTLE.half, neon = CHN >= 2;
    let x, y, w, hh;
    if (CASTLE.gate === 'west') { x = (CASTLE.x - h) * T; y = (CASTLE.y - 1) * T; w = T; hh = T * 3; }
    else if (CASTLE.gate === 'east') { x = (CASTLE.x + h) * T; y = (CASTLE.y - 1) * T; w = T; hh = T * 3; }
    else { x = (CASTLE.x - 1) * T; y = (CASTLE.y + h) * T; w = T * 3; hh = T; }
    const iceG = BIOMES[CASTLE.biome].castleStyle === 'ice';
    c.fillStyle = iceG ? '#2a4a6a' : '#2a1f33'; c.fillRect(x, y, w, hh);
    c.strokeStyle = iceG ? '#bfeaff' : neon ? '#ff3ea5' : '#8a8a96'; c.lineWidth = 4;
    if (w < hh) { for (let i = 0; i < 7; i++) { c.beginPath(); c.moveTo(x + 4, y + 8 + i * 17); c.lineTo(x + w - 4, y + 8 + i * 17); c.stroke(); } }
    else { for (let i = 0; i < 7; i++) { c.beginPath(); c.moveTo(x + 8 + i * 17, y + 4); c.lineTo(x + 8 + i * 17, y + hh - 4); c.stroke(); } }
    const g = 0.5 + Math.sin(G.time * 3) * 0.3;
    c.fillStyle = iceG ? `rgba(127,216,255,${g * 0.45})` : `rgba(199,125,255,${g * 0.5})`; c.fillRect(x - 4, y - 4, w + 8, hh + 8);
    c.font = 'bold 16px sans-serif'; c.textAlign = 'center';
    c.fillText('🔒', x + w / 2, y + hh / 2 + 6);
  }
  function drawEnemy(c, e) {
    const lift = e.fly ? 8 : 0;
    let sc = 1, alpha = 1;
    if (e.spawnT > 0) {
      const k = 1 - e.spawnT / 0.45; sc = 0.3 + 0.7 * k; alpha = k;
      c.fillStyle = `rgba(199,125,255,${(1 - k) * 0.6})`; c.beginPath(); c.ellipse(e.x, e.y + e.r * 0.6, e.r * 1.6, e.r * 0.6, 0, 0, TAU); c.fill();
    }
    if (e.blink > 0) alpha = clamp(e.blink / 0.55, 0.15, 1);
    shadow(c, e.x, e.y + e.r * 0.7, e.r * 0.85, e.r * 0.3);
    const evId = G.ev ? G.ev.def.id : null;
    if (evId === 'rage' && e.spawnT <= 0) {
      const g = 0.5 + Math.sin(e.t * 8 + (e.seed || 0)) * 0.5;
      c.fillStyle = `rgba(255,30,30,${0.2 + g * 0.2})`; c.beginPath(); c.arc(e.x, e.y - lift, e.r + 9, 0, TAU); c.fill();
    }
    if (e.elite) {
      const g = 0.5 + Math.sin(e.t * 5) * 0.5;
      c.fillStyle = `rgba(255,210,60,${0.18 + g * 0.15})`; c.beginPath(); c.arc(e.x, e.y - lift, e.r + 10, 0, TAU); c.fill();
      if (e.champion) { c.strokeStyle = `rgba(255,210,60,${0.6 + g * 0.4})`; c.lineWidth = 3; c.beginPath(); c.arc(e.x, e.y - lift, e.r + 15 + g * 3, 0, TAU); c.stroke(); }
    }
    if (e.def.ai === 'charger' && e.wind > 0) {
      c.fillStyle = `rgba(255,40,40,${0.25 + Math.sin(e.t * 30) * 0.1})`;
      c.save(); c.translate(e.x, e.y); c.rotate(e.dashAng); c.fillRect(0, -e.r, 210, e.r * 2); c.restore();
    }
    if (e.healing > 0) {
      c.strokeStyle = e.def.ai === 'buffer' ? 'rgba(255,140,198,0.8)' : 'rgba(125,255,154,0.8)'; c.lineWidth = 3;
      for (const o of e.healTargets) { if (o.dead) continue; c.beginPath(); c.moveTo(e.x, e.y); c.lineTo(o.x, o.y); c.stroke(); }
    }
    c.save(); c.translate(e.x, e.y - lift);
    if (evId === 'song' && !e.minion) { const ph = G.ev.t * 9 + (e.seed || 0); c.translate(0, -Math.abs(Math.sin(ph)) * 6); c.rotate(Math.sin(ph) * 0.3); }
    c.globalAlpha = alpha;
    const s = sc * (e.elite ? 1.35 : 1);
    if (s !== 1) c.scale(s, s);
    // объём: свой для каждого вида и направления взгляда
    if (VOL_SKIP.has(e.sprite)) ESPR[e.sprite](c, e);
    else {
      const flip = Math.cos(e.look || 0) < 0 ? 1 : 0;
      drawVolCore(c, 'E|' + e.sprite + '|' + flip + (e.sprite === 'mimic' ? '|' + e.chn : ''), Math.max(24, e.def.r * 2.5), cc => ESPR[e.sprite](cc, e), xx => {
        const t0 = e.t, l0 = e.look; e.t = 0.3; e.look = flip ? Math.PI : 0;
        try { ESPR[e.sprite](xx, e); } finally { e.t = t0; e.look = l0; }
      });
    }
    c.restore();
    if (e.def.ai === 'shield' && e.spawnT <= 0) { c.save(); c.translate(e.x, e.y - lift); drawEnemyShield(c, e, e.col); c.restore(); }
    if (e.flash > 0) { c.fillStyle = 'rgba(255,255,255,0.55)'; c.beginPath(); c.arc(e.x, e.y - lift, e.r, 0, TAU); c.fill(); }
    if (e.slowT > 0) { c.strokeStyle = 'rgba(150,220,255,0.7)'; c.lineWidth = 2; c.beginPath(); c.arc(e.x, e.y - lift, e.r + 3, 0, TAU); c.stroke(); }
    if (e.buffT > 0) { c.fillStyle = 'rgba(255,140,198,0.22)'; c.strokeStyle = 'rgba(255,140,198,0.7)'; c.lineWidth = 2; c.beginPath(); c.arc(e.x, e.y - lift, e.r + 6, 0, TAU); c.fill(); c.stroke(); }
    if (e.burnT > 0 && Math.random() < 0.25) part(e.x + rnd(-e.r, e.r) * 0.6, e.y - lift, rnd(-10, 10), -50, 0.4, 3, '#ff8a2a');
    if (e.elite) {
      const af = AFFIXES.find(a => a.id === e.affix);
      c.font = 'bold 10px sans-serif'; c.textAlign = 'center'; c.fillStyle = af ? af.col : '#ffd25a';
      if (e.champion) { c.font = '900 12px sans-serif'; c.fillStyle = '#ffd25a'; c.fillText('👑 Чемпион · ' + (e.name || e.def.name), e.x, e.y - e.r - 20 - lift); }
      else c.fillText('★ ' + (af ? af.name : 'ЭЛИТА'), e.x, e.y - e.r - 18 - lift);
    }
    if (e.hp < e.maxHp && e.spawnT <= 0) {
      const w = e.elite ? 36 : 24;
      c.fillStyle = 'rgba(0,0,0,0.6)'; c.fillRect(e.x - w / 2, e.y - e.r - 12 - lift, w, 4);
      c.fillStyle = e.elite ? '#ffd25a' : '#ff4d4d'; c.fillRect(e.x - w / 2, e.y - e.r - 12 - lift, w * clamp(e.hp / e.maxHp, 0, 1), 4);
    }
  }
  function drawFeather(c, x, y, a, s) {
    c.save(); c.translate(x, y); c.rotate(a); c.scale(s, s);
    c.fillStyle = 'rgba(150,225,255,0.35)'; c.beginPath(); c.ellipse(-8, 0, 10, 4, 0, 0, TAU); c.fill();
    c.fillStyle = P.frost ? '#cdf6ff' : '#ffffff'; c.strokeStyle = P.explode ? '#ff8a2a' : '#7b4dff'; c.lineWidth = 1.2;
    c.beginPath(); c.moveTo(9, 0); c.quadraticCurveTo(0, -5, -8, 0); c.quadraticCurveTo(0, 5, 9, 0); c.fill(); c.stroke();
    c.beginPath(); c.moveTo(9, 0); c.lineTo(-10, 0); c.stroke();
    c.restore();
  }
  function drawBubble(c, x, y, text, a, minX, maxX) {
    c.save(); c.globalAlpha = a; c.font = 'bold 12px sans-serif';
    const lines = []; let ln = '';
    for (const w of text.split(' ')) { const t = ln ? ln + ' ' + w : w; if (ln && c.measureText(t).width > 180) { lines.push(ln); ln = w; } else ln = t; }
    if (ln) lines.push(ln);
    const w = Math.max(...lines.map(l => c.measureText(l).width)) + 16, h = lines.length * 15 + 9, by = y - h;
    const bx = clamp(x - w / 2, minX + 6, maxX - w - 6); x = clamp(x, bx + 12, bx + w - 12);
    c.fillStyle = 'rgba(255,255,255,0.95)'; roundRect(c, bx, by, w, h, 9); c.fill();
    c.beginPath(); c.moveTo(x - 7, y - 1); c.lineTo(x + 7, y - 1); c.lineTo(x, y + 9); c.fill();
    c.strokeStyle = '#ff3ea5'; c.lineWidth = 1.5; roundRect(c, bx, by, w, h, 9); c.stroke();
    c.fillStyle = '#3a0a3a'; c.textAlign = 'center';
    lines.forEach((l, i) => c.fillText(l, bx + w / 2, by + 16 + i * 15));
    c.restore();
  }
  function renderWorld() {
    const c = ctx;
    const vw = VW / ZOOM, vh = VH / ZOOM;
    const shx = G.shake ? rnd(-G.shake, G.shake) * 0.6 : 0, shy = G.shake ? rnd(-G.shake, G.shake) * 0.6 : 0;
    const camX = G.cam.x + shx, camY = G.cam.y + shy;
    const s = DPR * ZOOM;
    c.setTransform(s, 0, 0, s, Math.round(DPR * VW / 2 - camX * s), Math.round(DPR * VH / 2 - camY * s));
    c.imageSmoothingEnabled = false;
    const x0 = camX - vw / 2, y0 = camY - vh / 2, x1 = x0 + vw, y1 = y0 + vh;
    c.fillStyle = '#0d0a14'; c.fillRect(x0 - 2, y0 - 2, vw + 4, vh + 4);
    for (let cy = Math.floor(y0 / CHPX); cy <= Math.floor(y1 / CHPX); cy++) {
      for (let cx = Math.floor(x0 / CHPX); cx <= Math.floor(x1 / CHPX); cx++) {
        if (cx < 0 || cy < 0 || cx * CHUNK >= MW || cy * CHUNK >= MH) continue;
        c.drawImage(getChunk(cx, cy), cx * CHPX, cy * CHPX);
      }
    }
    c.imageSmoothingEnabled = true;
    if (CFG.currents || CFG.pearls) drawSeaFloor(c, x0, y0, x1, y1);
    // заранее и понемногу строим соседние куски карты – без рывков при беге и в меню
    if (state === 'play' || state === 'menu') {
      if (!chunkJob) {
        let best = null, bd = 1e9;
        const mcx = (x0 + x1) / 2 / CHPX, mcy = (y0 + y1) / 2 / CHPX;
        for (let cy = Math.floor(y0 / CHPX) - 1; cy <= Math.floor(y1 / CHPX) + 1; cy++)
          for (let cx = Math.floor(x0 / CHPX) - 1; cx <= Math.floor(x1 / CHPX) + 1; cx++) {
            if (cx < 0 || cy < 0 || cx * CHUNK >= MW || cy * CHUNK >= MH || chunkCache.has(cx + ',' + cy)) continue;
            const d = (cx + 0.5 - mcx) ** 2 + (cy + 0.5 - mcy) ** 2;
            if (d < bd) { bd = d; best = [cx, cy]; }
          }
        if (best) chunkJob = newChunkJob(best[0], best[1]);
      }
      if (chunkJob && runChunkJob(chunkJob, 5)) chunkJob = null;
    }
    const vis = (x, y, m) => x > x0 - m && x < x1 + m && y > y0 - m && y < y1 + m;
    drawGate(c);
    for (const sh of shrines) if (vis(sh.x, sh.y, 320)) drawShrine(c, sh);
    if (!CFG.dark && !(G.caveA > 0.5)) for (const h of G.hazards) drawHazard(c, h);
    drawHouseGround(c, vis);
    drawArenaExit(c);
    for (const hl of holes) if (vis(hl.x, hl.y, 70)) drawHole(c, hl, G.time);
    drawCracks(c, vis);
    if (G.td) drawDefGround(c, vis);
    for (const ch of chests) if (vis(ch.x, ch.y, 40)) drawChest(c, ch);
    for (const p of G.pickups) if (vis(p.x, p.y, 20)) drawPickup(c, p);
    if (state !== 'menu' && !G.cutscene) {
      c.save(); c.setLineDash([7, 8]); c.strokeStyle = 'rgba(255,255,255,0.16)'; c.lineWidth = 1.5;
      c.beginPath(); c.arc(P.x, P.y, P.range, 0, TAU); c.stroke(); c.restore();
    }
    const items = [];
    const tx0 = Math.max(0, Math.floor(x0 / T) - 1), tx1 = Math.min(MW - 1, Math.floor(x1 / T) + 1);
    const ty0 = Math.max(0, Math.floor(y0 / T) - 1), ty1 = Math.min(MH - 1, Math.floor(y1 / T) + 3);
    for (let ty = ty0; ty <= ty1; ty++) for (let tx = tx0; tx <= tx1; tx++) {
      const ti = treeGrid[ty * MW + tx];
      if (ti) items.push({ y: trees[ti - 1].y, tree: trees[ti - 1] });
    }
    for (const e of G.enemies) if (vis(e.x, e.y, 60)) items.push({ y: e.y, e });
    if (G.td) {
      if (vis(G.core.x, G.core.y, 120)) items.push({ y: G.core.y + 14, defc: true });
      for (const sp of G.td.spots) if (sp.tw && vis(sp.x, sp.y, 70)) items.push({ y: sp.y + 9, dtw: sp.tw });
      for (const u of G.td.units) if (!u.dead && vis(u.x, u.y, 30)) items.push({ y: u.y, dun: u });
    }
    for (const b of bosses) if (b.state !== 'dead' && vis(b.x, b.y, 140) && (!CFG.rush || !G.rush || b.id === G.rush.idx)) items.push({ y: b.y, b });
    const ally = G.finalFinal && G.finalFinal.ally;
    if (ally && state !== 'menu') items.push({ y: ally.y, ally });
    const cageX = tc(CAGE.x), cageY = tc(CAGE.y);
    if (!CFG.noCage && vis(cageX, cageY, 80)) items.push({ y: cageY + 20, cage: true });
    if (CFG.team && CFG.hostage === 'tessa' && !G.tessaAlly && !G.cutscene && state !== 'menu' && vis(cageX, cageY, 90)) items.push({ y: cageY + 20, iceCage: true });
    for (const f of fires) if (vis(f.x, f.y, 100)) items.push({ y: f.y + 6, fire: f });
    for (const ov of ovens) if (vis(ov.x, ov.y, 80)) items.push({ y: ov.y + 20, oven: ov });
    for (const dr of drifts) if (!dr.done && vis(dr.x, dr.y, 50)) items.push({ y: dr.y + 8, drift: dr });
    if (G.team && state !== 'menu' && !G.cutscene) items.push({ y: G.team.by, buddy: true });
    if (G.tessaAlly && state !== 'menu') items.push({ y: G.tessaAlly.y, tessa: G.tessaAlly });
    if (state !== 'menu' && state !== 'dying' && state !== 'dead') items.push({ y: P.y, player: true });
    if (NET.on && G.netRun && state !== 'menu') for (const m of NET.mates.values()) if (m.tx !== undefined && vis(m.x, m.y, 80)) items.push({ y: m.y, mate: m });
    items.sort((a, b) => a.y - b.y);
    for (const it of items) {
      if (it.tree) {
        const tr = it.tree, spr = TREE_SPR[tr.kind];
        const w = 64 * tr.s, h = 84 * tr.s;
        const under = (x, y) => y < tr.y && y > tr.y - h * 0.95 && Math.abs(x - tr.x) < w * 0.5;
        const behind = state !== 'menu' && (under(P.x, P.y) || (G.activeBoss && under(G.activeBoss.x, G.activeBoss.y)));
        if (behind) c.globalAlpha = 0.42;
        c.drawImage(spr, tr.x - w / 2, tr.y - h + 5 * tr.s, w, h);
        c.globalAlpha = 1;
      } else if (it.e) drawEnemy(c, it.e);
      else if (it.b) drawBoss(c, it.b);
      else if (it.cage) drawCage(c, cageX, cageY, G.cageOpen, G.time);
      else if (it.iceCage) drawIceCage(c, cageX, cageY, G.time);
      else if (it.fire) drawCampfire(c, it.fire, G.time);
      else if (it.oven) drawOven(c, it.oven, G.time);
      else if (it.drift) drawDrift(c, it.drift, G.time);
      else if (it.buddy) {
        const T6 = G.team, o = teamOther(), ko = T6.ko[o];
        shadow(c, T6.bx, T6.by + 10, 10, 4);
        const tg = G.activeBoss || null;
        drawHeroV(o, c, T6.bx, T6.by, P.t, tg ? (tg.x > T6.bx ? 1 : -1) : P.face, 0.9, ko ? 0.45 : 0.92, P.moving);
        if (ko) { c.font = '14px sans-serif'; c.textAlign = 'center'; c.fillText('💤', T6.bx + 12, T6.by - 34 + Math.sin(P.t * 3) * 3); }
      }
      else if (it.tessa) {
        const A = it.tessa;
        shadow(c, A.x, A.y + 10, 10, 4);
        drawHeroV('tessa', c, A.x, A.y, P.t, A.face, 0.85, 1, true);
        if (CFG.tessaStart) { // пузырь-шлем
          const bg = c.createRadialGradient(A.x - 6, A.y - 22, 2, A.x, A.y - 14, 20); bg.addColorStop(0, 'rgba(255,255,255,0.35)'); bg.addColorStop(0.7, 'rgba(160,230,255,0.12)'); bg.addColorStop(1, 'rgba(160,230,255,0.45)');
          c.fillStyle = bg; c.beginPath(); c.arc(A.x, A.y - 14, 19, 0, TAU); c.fill();
          c.strokeStyle = 'rgba(220,250,255,0.7)'; c.lineWidth = 1.5; c.stroke();
          c.fillStyle = 'rgba(255,255,255,0.7)'; c.beginPath(); c.ellipse(A.x - 8, A.y - 24, 4, 2.2, -0.6, 0, TAU); c.fill();
        }
      }
      else if (it.ally) {
        const A = it.ally, ab = G.activeBoss || bosses[bosses.length - 1];
        shadow(c, A.x, A.y + 10, 11, 4);
        c.fillStyle = `rgba(191,234,255,${0.18 + Math.sin(P.t * 5) * 0.08})`; c.beginPath(); c.arc(A.x, A.y - 6, 26, 0, TAU); c.fill();
        drawHero('krilessa', c, A.x, A.y + Math.sin(P.t * 4) * 3, P.t, ab && ab.x > A.x ? 1 : -1, 1, 1, true);
      }
      else if (it.defc) drawDefCore(c);
      else if (it.dtw) drawDefTower(c, it.dtw);
      else if (it.dun) drawDefUnit(c, it.dun);
      else if (it.mate) drawMate(c, it.mate);
      else if (it.player && P.down) { // без сил – лежит, ждёт подругу
        shadow(c, P.x, P.y + 10, 11, 4);
        c.save(); c.translate(P.x, P.y + 4); c.rotate(Math.PI / 2 * P.face); drawHeroV(P.hero, c, 0, 0, P.t, 1, 0.9, 0.7, false); c.restore();
        c.font = '16px sans-serif'; c.textAlign = 'center'; c.fillText('💫', P.x, P.y - 26 + Math.sin(P.t * 3) * 3);
        if (NET.on && G.netRun) { c.lineWidth = 5; c.strokeStyle = 'rgba(0,0,0,0.45)'; c.beginPath(); c.arc(P.x, P.y - 4, 24, 0, TAU); c.stroke(); }
        if (P.revT > 0) { c.strokeStyle = '#7dff9a'; c.lineWidth = 4; c.beginPath(); c.arc(P.x, P.y - 4, 24, -Math.PI / 2, -Math.PI / 2 + TAU * clamp(P.revT / 2.6, 0, 1)); c.stroke(); }
        if (G.td && P.tdRev > 0) { c.font = 'bold 11px sans-serif'; c.textAlign = 'center'; c.fillStyle = '#ff8ad8'; c.fillText(`💗 ${Math.ceil(P.tdRev)} с`, P.x, P.y + 34); }
      }
      else if (it.player) {
        const blink = P.inv > 0 && Math.floor(P.t * 20) % 2 === 0;
        shadow(c, P.x, P.y + 10, 11, 4);
        if (NET.on && G.netRun) { c.strokeStyle = mateCol(NET.id || 1); c.globalAlpha = 0.8; c.lineWidth = 2.5; c.beginPath(); c.ellipse(P.x, P.y + 10, 15, 6, 0, 0, TAU); c.stroke(); c.globalAlpha = 1; }
        if (G.myAura && G.myAura !== 'none' && !G.hidden) drawAura(c, G.myAura, P.x, P.y - (P.z || 0), P.t);
        if (!(G.hidden && P.hero === 'tessa')) drawHeroV(P.hero, c, P.x, P.y - (P.z || 0), P.t, P.face, 1, blink ? 0.4 : 1, P.moving || P.dashT > 0 || !!G.jump);
        if (P.napT > 0) { c.fillStyle = `rgba(255,220,120,${0.25 + Math.sin(P.t * 4) * 0.1})`; c.beginPath(); c.arc(P.x, P.y - 6 - (P.z || 0), 20, 0, TAU); c.fill(); }
        if (P.stormT > 0) { c.strokeStyle = 'rgba(150,225,255,0.6)'; c.lineWidth = 3; c.beginPath(); c.arc(P.x, P.y - 6, 28 + Math.sin(P.t * 20) * 4, 0, TAU); c.stroke(); }
        if (P.shieldLv && P.shieldT <= 0) {
          c.strokeStyle = `rgba(127,232,255,${0.5 + Math.sin(P.t * 4) * 0.2})`; c.lineWidth = 2;
          c.beginPath(); c.arc(P.x, P.y - 6, 22, 0, TAU); c.stroke();
        }
        if (P.slowT > 0) { c.fillStyle = 'rgba(255,220,80,0.35)'; c.beginPath(); c.ellipse(P.x, P.y + 10, 16, 6, 0, 0, TAU); c.fill(); }
      }
    }
    if (G.td) drawDefOver(c, vis);
    if (G.hidden) drawBox(c, G.hidden, true);
    if (G.pet && state !== 'menu') drawPet(c);
    if (P.orbit && state !== 'menu' && !G.cutscene) {
      for (let k = 0; k < P.orbit; k++) {
        const a = P.orbA + (k / P.orbit) * TAU, ox = P.x + Math.cos(a) * 62, oy = P.y + Math.sin(a) * 62;
        if (P.proj === 'fire') drawFireball(c, ox, oy, a + Math.PI / 2, 1.2);
        else if (P.proj === 'claw') { c.fillStyle = '#ff6fb5'; c.beginPath(); c.arc(ox, oy, 7, 0, TAU); c.fill(); c.strokeStyle = '#c0306a'; c.lineWidth = 1.5; c.beginPath(); c.arc(ox, oy, 7, a, a + 2.4); c.stroke(); }
        else drawFeather(c, ox, oy, a + Math.PI / 2, 1.3);
      }
    }
    for (const z of G.pzones) {
      const a = clamp((z.dur - z.t) / 0.5, 0, 1);
      c.fillStyle = `rgba(255,120,30,${0.25 * a})`; c.beginPath(); c.arc(z.x, z.y, z.r, 0, TAU); c.fill();
    }
    for (const n of G.novas) {
      if (n.star) { // золотая волна эволюций
        const a = clamp(1 - n.r / n.max, 0, 1) + 0.15;
        c.lineWidth = 12; c.strokeStyle = `rgba(255,243,160,${a})`; c.beginPath(); c.arc(n.x, n.y, n.r, 0, TAU); c.stroke();
        c.lineWidth = 3; c.strokeStyle = `rgba(255,255,255,${a})`; c.stroke();
        continue;
      }
      if (n.disco || n.life) {
        const a = clamp(1 - n.r / n.max, 0, 1) + 0.2;
        c.lineWidth = n.disco ? 7 : 14;
        c.strokeStyle = n.disco ? `hsla(${(G.time * 360) % 360},100%,70%,${a})` : `rgba(191,234,255,${a})`;
        c.beginPath(); c.arc(n.x, n.y, n.r, 0, TAU); c.stroke();
        continue;
      }
      if (n.purr) {
        c.lineWidth = 22; c.strokeStyle = 'rgba(255,140,200,0.4)'; c.beginPath(); c.arc(n.x, n.y, n.r, 0, TAU); c.stroke();
        c.lineWidth = 6; c.strokeStyle = 'rgba(255,220,240,0.9)'; c.stroke();
        for (let k = 0; k < 8; k++) { const a = k * TAU / 8 + n.r * 0.01; c.fillStyle = '#ff6fb5'; heartPath(c, n.x + Math.cos(a) * n.r, n.y + Math.sin(a) * n.r, 7); c.fill(); }
        continue;
      }
      c.lineWidth = 26; c.strokeStyle = 'rgba(255,90,20,0.45)'; c.beginPath(); c.arc(n.x, n.y, n.r, 0, TAU); c.stroke();
      c.lineWidth = 10; c.strokeStyle = 'rgba(255,220,80,0.9)'; c.stroke();
      c.lineWidth = 3; c.strokeStyle = '#ffffff'; c.stroke();
    }
    if (CFG.dark || mutOn('dark')) { drawDarkness(c); for (const h of G.hazards) drawHazard(c, h); }
    for (const st of G.falling) {
      const k = clamp(st.t / st.dur, 0, 1), sx = st.x + (1 - k) * 140, sy = st.y - (1 - k) * 320;
      c.strokeStyle = `rgba(255,224,138,${0.25 + k * 0.5})`; c.lineWidth = 2; c.beginPath(); c.arc(st.x, st.y, 10 + (1 - k) * 26, 0, TAU); c.stroke();
      c.strokeStyle = 'rgba(255,240,190,0.6)'; c.lineWidth = 4; c.beginPath(); c.moveTo(sx, sy); c.lineTo(sx + 40, sy - 90); c.stroke();
      c.fillStyle = '#ffe08a'; star(c, sx, sy, 9, st.t * 8); c.fill();
    }
    drawCaveDark(c);
    drawBlizzard(c);
    for (const bm of G.beams) drawBeam(c, bm);
    // ДРУЖБА-СУПЕР: два луча сливаются в радугу
    const cs = G.cutscene;
    if (cs && cs.kind === 'teamup' && G.finalFinal) {
      const A = G.finalFinal.ally, tb = bosses[bosses.length - 1];
      if (cs.t < 0.8) {
        for (const [hx, hy, col] of [[P.x, P.y - 6, '255,140,40'], [A.x, A.y - 6, '120,200,255']]) {
          c.fillStyle = `rgba(${col},${0.25 + cs.t * 0.5})`; c.beginPath(); c.arc(hx, hy, 18 + cs.t * 30 + Math.sin(cs.t * 40) * 3, 0, TAU); c.fill();
        }
      } else if (cs.t < 3.2 && tb) {
        const mx = (P.x + A.x) / 2, my = (P.y + A.y) / 2 - 30, w = 10 + Math.sin(cs.t * 30) * 3;
        c.lineCap = 'round';
        for (const [hx, hy, col] of [[P.x, P.y - 6, '#ff8a2a'], [A.x, A.y - 6, '#7fd8ff']]) {
          c.strokeStyle = col; c.lineWidth = w; c.beginPath(); c.moveTo(hx, hy); c.lineTo(mx, my); c.stroke();
        }
        const ang = Math.atan2(tb.y - tb.z - my, tb.x - mx), len = Math.hypot(tb.x - mx, tb.y - tb.z - my);
        c.save(); c.translate(mx, my); c.rotate(ang);
        RAINBOW.forEach((col, i) => { c.fillStyle = col; c.fillRect(0, (i - RAINBOW.length / 2) * (w * 0.6), len, w * 0.6); });
        c.fillStyle = 'rgba(255,255,255,0.85)'; c.fillRect(0, -w * 0.4, len, w * 0.8);
        c.restore();
        c.fillStyle = '#ffffff'; c.beginPath(); c.arc(mx, my, w * 1.6, 0, TAU); c.fill();
        c.lineCap = 'butt';
      }
    }
    for (const f of G.rfeathers || []) { // выстрелы подруг
      if (!vis(f.x, f.y, 20)) continue;
      if (f.kind === 'fire') drawFireball(c, f.x, f.y, Math.atan2(f.vy, f.vx), 1);
      else if (f.kind === 'claw') drawClaw(c, f);
      else if (f.kind === 'pixel') { c.fillStyle = '#3ff0a0'; c.fillRect(f.x - 3, f.y - 3, 6, 6); }
      else drawFeather(c, f.x, f.y, Math.atan2(f.vy, f.vx), 1);
    }
    for (const f of G.feathers) {
      if (f.kind === 'fire') drawFireball(c, f.x, f.y, Math.atan2(f.vy, f.vx), 1);
      else if (f.kind === 'claw') drawClaw(c, f);
      else if (f.kind === 'pixel') { c.fillStyle = '#3ff0a0'; c.fillRect(f.x - 3, f.y - 3, 6, 6); c.fillStyle = '#ffffff'; c.fillRect(f.x - 3, f.y - 3, 2, 2); }
      else drawFeather(c, f.x, f.y, Math.atan2(f.vy, f.vx), 1);
    }
    for (const b of G.ebullets) {
      if (!vis(b.x, b.y, 20)) continue;
      if (b.saw) {
        c.save(); c.translate(b.x, b.y); c.rotate(b.rot);
        c.fillStyle = '#9aa4b8'; c.beginPath();
        for (let k = 0; k < 16; k++) { const rr = k % 2 ? b.r * 0.75 : b.r; const a = k / 16 * TAU; c.lineTo(Math.cos(a) * rr, Math.sin(a) * rr); }
        c.closePath(); c.fill(); c.strokeStyle = '#3a3a4a'; c.lineWidth = 1.5; c.stroke();
        c.fillStyle = '#ff3b3b'; c.beginPath(); c.arc(0, 0, 3, 0, TAU); c.fill();
        c.restore(); continue;
      }
      const spr = b.emoji ? emojiSprite(b.emoji, 18) : b.square ? squareSprite(b.col, b.r * 0.85) : bulletSprite(b.col, b.r);
      const fa = b.life < SHOT_FADE ? Math.max(0, b.life / SHOT_FADE) : 1, sz = 0.5 * (0.55 + 0.45 * fa); // в конце полёта тает и сжимается
      if (fa < 1) c.globalAlpha = fa;
      c.drawImage(spr, b.x - spr.width * sz / 2, b.y - spr.height * sz / 2, spr.width * sz, spr.height * sz);
      if (fa < 1) c.globalAlpha = 1;
    }
    for (const b of G.bolts) {
      c.strokeStyle = `rgba(${b.col || '190,230,255'},${clamp(b.t * 4, 0, 1)})`; c.lineWidth = 3;
      c.beginPath();
      for (let i = 0; i < b.pts.length - 1; i++) {
        const [ax, ay] = b.pts[i], [bx, by] = b.pts[i + 1];
        c.moveTo(ax, ay);
        for (let k = 1; k <= 4; k++) c.lineTo(lerp(ax, bx, k / 4) + (k < 4 ? rnd(-10, 10) : 0), lerp(ay, by, k / 4) + (k < 4 ? rnd(-10, 10) : 0));
      }
      c.stroke();
    }
    for (const r of G.rings) {
      c.strokeStyle = r.col; c.globalAlpha = clamp(1 - r.t / 0.45, 0, 1); c.lineWidth = 4;
      c.beginPath(); c.arc(r.x, r.y, r.r, 0, TAU); c.stroke(); c.globalAlpha = 1;
    }
    for (const p of G.parts) {
      c.globalAlpha = clamp(p.life / p.max, 0, 1); c.fillStyle = p.col;
      c.fillRect(p.x - p.size / 2, p.y - p.size / 2, p.size, p.size);
    }
    c.globalAlpha = 1;
    c.textAlign = 'center';
    for (const t of G.texts) {
      const life = t.big ? 1.1 : 0.8;
      c.globalAlpha = clamp(1 - t.t / life, 0, 1);
      if (paperOn) { // цифры – от руки: чернила с бумажной обводкой
        const col = t.col === '#ffe04a' ? '#c8342a' : lightCol(t.col) ? INK : t.col;
        c.font = HAND(t.big ? 24 : 18); c.lineJoin = 'round'; c.lineWidth = 3.5; c.strokeStyle = 'rgba(251,243,224,.92)';
        c.strokeText(t.txt, t.x, t.y - t.t * 30); c.fillStyle = col; c.fillText(t.txt, t.x, t.y - t.t * 30);
        continue;
      }
      c.font = t.big ? 'bold 17px sans-serif' : 'bold 13px sans-serif';
      c.fillStyle = '#000'; c.fillText(t.txt, t.x + 1, t.y - t.t * 30 + 1);
      c.fillStyle = t.col; c.fillText(t.txt, t.x, t.y - t.t * 30);
    }
    c.globalAlpha = 1;
    for (const b of bosses) if (b.bubble && b.state === 'fight') drawBubble(c, b.x, b.y - b.z - b.r - 30, b.bubble.text, clamp(b.bubble.t / 0.3, 0, 1), x0, x1);
    if (state === 'menu' || G.cutscene) return;
    if (G.ev && G.ev.def.id === 'treasure') { // метка клада: золотой крест и столб света
      const ex = G.ev.tx, ey = G.ev.ty, pu = 0.5 + 0.5 * Math.sin(G.time * 5);
      const gl = c.createLinearGradient(ex, ey - 160, ex, ey); gl.addColorStop(0, 'rgba(255,220,120,0)'); gl.addColorStop(1, `rgba(255,220,120,${0.35 + 0.2 * pu})`);
      c.fillStyle = gl; c.fillRect(ex - 16, ey - 160, 32, 160);
      c.strokeStyle = '#7a4a00'; c.lineWidth = 9; c.lineCap = 'round';
      c.beginPath(); c.moveTo(ex - 14, ey - 10); c.lineTo(ex + 14, ey + 10); c.moveTo(ex + 14, ey - 10); c.lineTo(ex - 14, ey + 10); c.stroke();
      c.strokeStyle = '#ffd25a'; c.lineWidth = 5;
      c.beginPath(); c.moveTo(ex - 14, ey - 10); c.lineTo(ex + 14, ey + 10); c.moveTo(ex + 14, ey - 10); c.lineTo(ex - 14, ey + 10); c.stroke(); c.lineCap = 'butt';
    }
    if (G.ev && G.ev.thief && !G.ev.thief.dead) { const e = G.ev.thief; c.font = '18px sans-serif'; c.textAlign = 'center'; c.fillText('💰', e.x, e.y - e.r - 16 + Math.sin(G.time * 8) * 3); }
    const bw = 64, bx = P.x - bw / 2, by = P.y - 52;
    if (paperOn) { // над головой – тонкая полоска от руки (цифры – в записке сверху)
      const k = clamp(P.hp / P.maxHp, 0, 1), bw2 = 44, bx2 = P.x - bw2 / 2, by2 = by + 4;
      c.fillStyle = 'rgba(251,243,224,.85)'; c.fillRect(bx2, by2, bw2, 6);
      c.fillStyle = k < 0.3 ? 'rgba(220,40,30,.8)' : 'rgba(200,60,48,.62)'; c.fillRect(bx2 + 1, by2 + 1, (bw2 - 2) * k, 4);
      c.strokeStyle = 'rgba(75,46,30,.75)'; c.lineWidth = 1; c.strokeRect(bx2, by2, bw2, 6);
      if (P.lives) handText(c, '🐾' + P.lives, P.x + bw2 / 2 + 4, by2 + 7, 13, INK, 'left');
      c.textAlign = 'center';
    } else {
    c.fillStyle = 'rgba(0,0,0,0.65)'; c.fillRect(bx - 2, by - 2, bw + 4, 13);
    c.fillStyle = P.hp < P.maxHp * 0.3 ? '#ff4d4d' : '#4cd964'; c.fillRect(bx, by, bw * clamp(P.hp / P.maxHp, 0, 1), 9);
    c.font = 'bold 9px sans-serif'; c.fillStyle = '#fff';
    c.fillText(`${Math.ceil(P.hp)}/${P.maxHp}` + (P.lives ? ` · 🐾${P.lives}` : ''), P.x, by + 8);
    }
    if (!G.activeBoss && !G.activeShrine) {
      const o = objective();
      const dx = o.x - P.x, dy = o.y - P.y, d = Math.hypot(dx, dy);
      if (d > 170) {
        const a = Math.atan2(dy, dx), ax = P.x + Math.cos(a) * 82, ay = P.y + Math.sin(a) * 82 - 6;
        c.save(); c.translate(ax, ay); c.rotate(a);
        c.fillStyle = '#d6f03a'; c.strokeStyle = '#4a5a00'; c.lineWidth = 2;
        c.beginPath(); c.moveTo(14, 0); c.lineTo(-8, -11); c.lineTo(-3, 0); c.lineTo(-8, 11); c.closePath(); c.fill(); c.stroke();
        c.restore();
        if (paperOn) handText(c, `${Math.round(d / PX_PER_M)} м`, ax, ay + 27, 17, INK, 'center', 'rgba(251,243,224,.9)');
        else { c.font = 'bold 13px sans-serif'; c.fillStyle = '#000'; c.fillText(`${Math.round(d / PX_PER_M)} м`, ax + 1, ay + 27);
        c.fillStyle = '#fff'; c.fillText(`${Math.round(d / PX_PER_M)} м`, ax, ay + 26); }
      }
    }
    const evT = G.ev && (G.ev.def.id === 'thief' && G.ev.thief && !G.ev.thief.dead ? G.ev.thief : G.ev.def.id === 'treasure' ? { x: G.ev.tx, y: G.ev.ty } : null);
    if (evT) { // золотая стрелка к цели события
      const dx = evT.x - P.x, dy = evT.y - P.y, d = Math.hypot(dx, dy);
      if (d > 120) {
        const a = Math.atan2(dy, dx), ax = P.x + Math.cos(a) * 104, ay = P.y + Math.sin(a) * 104 - 6, pl = 1 + 0.12 * Math.sin(G.time * 8);
        c.save(); c.translate(ax, ay); c.rotate(a); c.scale(pl, pl);
        c.fillStyle = '#ffd25a'; c.strokeStyle = '#7a4a00'; c.lineWidth = 2;
        c.beginPath(); c.moveTo(15, 0); c.lineTo(-8, -12); c.lineTo(-3, 0); c.lineTo(-8, 12); c.closePath(); c.fill(); c.stroke();
        c.restore();
        c.font = '15px sans-serif'; c.textAlign = 'center'; c.fillText(G.ev.def.ic, ax, ay - 16);
      }
    }
    if (G.champ && !G.champ.dead && !G.activeBoss) {
      const dx = G.champ.x - P.x, dy = G.champ.y - P.y;
      if (Math.hypot(dx, dy) > 260) {
        const a = Math.atan2(dy, dx), ax = P.x + Math.cos(a) * 62, ay = P.y + Math.sin(a) * 62 - 6;
        c.font = '15px sans-serif'; c.textAlign = 'center'; c.globalAlpha = 0.6 + 0.4 * Math.sin(G.time * 5); c.fillText('👑', ax, ay + 5); c.globalAlpha = 1;
      }
    }
  }

  // ------------------------------------------------------------------
  //  Мини-карта 2.0 «Неон-вывеска главы»: местность вокруг героини светящимися контурами,
  //  дальние цели – значками по краю, рамка с неоновыми украшениями главы.
  //  ?mm=classic – старая мини-карта (для проверки); в «Ещё» её тоже можно вернуть.
  // ------------------------------------------------------------------
  const MM_URL = (location.search.match(/[?&]mm=(\w+)/) || [])[1];
  let MM_STYLE = MM_URL || 'paper';
  const MM2 = { neon: null, sign: null, head: -Math.PI / 2, K: 3, sizeF: 0 };
  const NEON_COL = { 1: '#3dffa0', 2: '#ff3ea5', 3: '#7fd8ff', 4: '#b07dff', 5: '#ffcf4a', 6: '#9fe8ff', 7: '#3fe8ff' };
  const NEON_ACC = { 1: '#d8ff6a', 2: '#7fd8ff', 3: '#ffd25a', 4: '#9dffc8', 5: '#ff8a3a', 6: '#ffffff', 7: '#ff9ad0' };
  const neonCol = () => NEON_COL[CHN] || '#3ff0ff', neonAcc = () => NEON_ACC[CHN] || '#ffffff';
  // основа: светящиеся контуры стен, вода, дорожки и слабая заливка проходимого (3 пикселя на клетку)
  function mm2Neon() {
    if (MM2.neon) return MM2.neon;
    const K = MM2.K, cv = makeCanvas(MW * K, PLAY_H * K), c = cv.getContext('2d'), col = neonCol();
    c.fillStyle = '#06030f'; c.fillRect(0, 0, cv.width, cv.height);
    for (let ty = 0; ty < PLAY_H; ty++) for (let tx = 0; tx < MW; tx++) {
      const t = tiles[ty * MW + tx];
      if (t === WATER || t === LAVA || t === ICE) { c.fillStyle = t === LAVA ? 'rgba(255,90,40,0.35)' : 'rgba(80,180,255,0.22)'; c.fillRect(tx * K, ty * K, K, K); }
      else if (t === PATH) { c.fillStyle = 'rgba(255,255,255,0.22)'; c.fillRect(tx * K, ty * K, K, K); }
      if (!isSolidTile(tx, ty, false)) { c.globalAlpha = 0.07; c.fillStyle = col; c.fillRect(tx * K, ty * K, K, K); c.globalAlpha = 1; continue; }
      c.fillStyle = 'rgba(255,255,255,0.04)'; c.fillRect(tx * K, ty * K, K, K);
      c.fillStyle = col;
      if (!isSolidTile(tx, ty + 1, false)) c.fillRect(tx * K, ty * K + K - 1, K, 1);
      if (!isSolidTile(tx, ty - 1, false)) c.fillRect(tx * K, ty * K, K, 1);
      if (!isSolidTile(tx - 1, ty, false)) c.fillRect(tx * K, ty * K, 1, K);
      if (!isSolidTile(tx + 1, ty, false)) c.fillRect(tx * K + K - 1, ty * K, 1, K);
    }
    return (MM2.neon = cv);
  }
  // что показать: цели (дальние – значками по краю)
  function mm2Marks() {
    const L = [];
    for (const b of bosses) {
      if (CFG.rush && G.rush && b.id !== G.rush.idx) continue;
      if (G.td) { if (b.state !== 'dead' && b.state !== 'sleep') L.push({ x: b.x, y: b.y, ic: '💀', rim: true, k: 'boss' }); continue; } // в обороне босс идёт по дороге: метка – где он сейчас, убитый не отмечается
      L.push({ x: b.hx, y: b.hy, ic: b.def.immortal ? '♾️' : b.state === 'dead' ? '✅' : '💀', rim: b.state !== 'dead', k: 'boss' });
    }
    if (!CFG.noCage || (CFG.team && !G.tessaAlly)) L.push({ x: tc(CAGE.x), y: tc(CAGE.y), ic: '❤️', rim: true, k: 'cage' });
    if (G.champ && !G.champ.dead) L.push({ x: G.champ.x, y: G.champ.y, ic: '👑', rim: true, k: 'champ' });
    if (G.td) { L.push({ x: G.core.x, y: G.core.y, ic: '💎', rim: true, k: 'core' }); for (const ln of G.td.lanes) if (ln.from <= G.abyss.wave + 1) L.push({ x: ln.gate.x, y: ln.gate.y, ic: '🌀', k: 'gate' }); }
    if (G.ev && G.ev.def.id === 'treasure') L.push({ x: G.ev.tx, y: G.ev.ty, ic: '🧭', rim: true, k: 'ev' });
    if (G.ev && G.ev.thief && !G.ev.thief.dead) L.push({ x: G.ev.thief.x, y: G.ev.thief.y, ic: '💰', rim: true, k: 'ev' });
    for (const sh of shrines) L.push({ x: sh.x, y: sh.y, ic: sh.state === 'done' ? '🌀' : '⛩', k: 'shrine' });
    for (const n of npcs) L.push({ x: n.x, y: n.y, ic: n.def.ic, k: 'npc' });
    for (const f of fires) if (!f.glade || f.lit) L.push({ x: f.x, y: f.y, ic: '🔥', k: 'fire' });
    for (const bd of beds) L.push({ x: bd.x, y: bd.y, ic: '🛏', k: 'bed' });
    for (const q of pearls) if (!q.got) L.push({ x: q.x, y: q.y, ic: '💗', k: 'pearl' });
    if (NET.on && G.netRun) for (const m of NET.mates.values()) if (m.tx !== undefined) L.push({ x: m.x, y: m.y, ic: m.down ? '💫' : MATE_EMO[(m.id - 1) % MATE_EMO.length], rim: true, k: 'mate' });
    return L;
  }
  function mm2Heading(dt) { if (Math.hypot(P.vx, P.vy) > 20) { const a = Math.atan2(P.vy, P.vx); MM2.head += angDiff(MM2.head, a) * Math.min(1, dt * 8); } return MM2.head; }
  function drawMini2(c, mx, my, ms) {
    const col = neonCol(), cx = mx + ms / 2, cy = my + ms / 2, rr = ms / 2, R = 26 * T * ms / (MM2.msBase || ms), s = rr / R; // ~26 клеток вокруг; растянутое окно показывает больше
    const X = wx => cx + (wx - P.x) * s, Y = wy => cy + (wy - P.y) * s;
    const now = performance.now() / 1000, head = mm2Heading(1 / 60);
    const inBox = (x, y, m = 0) => x > mx + m && x < mx + ms - m && y > my + m && y < my + ms - m;
    const pap = MM_STYLE === 'paper';
    if (pap) { // листок бумаги на кнопке
      c.save(); c.translate(mx + ms / 2, my + ms / 2); c.rotate(0.018); c.shadowColor = 'rgba(80,50,20,.35)'; c.shadowBlur = 6 * DPR; c.shadowOffsetY = 2 * DPR;
      c.fillStyle = '#fbf3e0'; c.fillRect(-ms / 2 - 6, -ms / 2 - 6, ms + 12, ms + 12); c.restore();
    }
    c.save();
    c.fillStyle = pap ? '#f3e6c8' : 'rgba(6,3,15,0.9)'; roundRect(c, mx, my, ms, ms, pap ? 3 : 12); c.fill();
    roundRect(c, mx, my, ms, ms, pap ? 3 : 12); c.clip();
    if (pap) {
      const sx2 = (P.x - R) / T, sy2 = (P.y - R) / T, sw2 = R * 2 / T;
      c.imageSmoothingEnabled = false; c.drawImage(miniBase, sx2, sy2, sw2, sw2, mx, my, ms, ms);
      c.globalCompositeOperation = 'multiply'; c.globalAlpha = 0.85; c.drawImage(miniBase, sx2, sy2, sw2, sw2, mx, my, ms, ms); // краски гуще – карта читается на бумаге
      c.globalCompositeOperation = 'source-over'; c.globalAlpha = 1; c.imageSmoothingEnabled = true;
      c.globalAlpha = 0.5; c.drawImage(fog, sx2, sy2, sw2, sw2, mx, my, ms, ms); c.globalAlpha = 1;
    } else {
    // местность вокруг героини: контуры и их мягкое свечение
    const base = mm2Neon(), K = MM2.K, sx = (P.x - R) / T * K, sy = (P.y - R) / T * K, sw = R * 2 / T * K;
    c.imageSmoothingEnabled = false; c.drawImage(base, sx, sy, sw, sw, mx, my, ms, ms);
    c.globalCompositeOperation = 'lighter'; c.globalAlpha = 0.45; c.imageSmoothingEnabled = true; c.drawImage(base, sx, sy, sw, sw, mx - 1, my - 1, ms + 2, ms + 2);
    c.globalAlpha = 1; c.globalCompositeOperation = 'source-over';
    const fsx = (P.x - R) / T, fsy = (P.y - R) / T, fsw = R * 2 / T;
    c.globalAlpha = 0.55; c.drawImage(fog, fsx, fsy, fsw, fsw, mx, my, ms, ms); c.globalAlpha = 1;
    c.fillStyle = 'rgba(255,255,255,0.05)'; for (let y = my + ((now * 30) % 4); y < my + ms; y += 4) c.fillRect(mx, y, ms, 1); // строки развёртки
    }
    // враги, сундуки, отметки
    c.fillStyle = pap ? '#c8342a' : '#ff3e7a';
    for (const e of G.enemies) { const ex = X(e.x), ey = Y(e.y); if (!inBox(ex, ey)) continue; c.beginPath(); c.arc(ex, ey, e.elite ? 2.6 : 1.7, 0, TAU); c.fill(); }
    c.lineWidth = 1.5;
    for (const ch of chests) if (chestOnMap(ch)) {
      const x = X(ch.x), y = Y(ch.y); if (!inBox(x, y, 2)) continue;
      c.strokeStyle = ch.tier === 'gold' ? '#ffd25a' : ch.tier === 'silver' ? '#e0eaff' : '#c8945a';
      c.beginPath(); c.moveTo(x, y - 3.5); c.lineTo(x + 3.5, y); c.lineTo(x, y + 3.5); c.lineTo(x - 3.5, y); c.closePath(); c.stroke();
    }
    const marks = mm2Marks(), o = CFG.rush || CFG.abyss ? null : objective(), rimList = [];
    c.font = '11px sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle';
    for (const m of marks) { const x = X(m.x), y = Y(m.y); if (inBox(x, y, 7)) c.fillText(m.ic, x, y); else if (m.rim) rimList.push(m); }
    // героиня: светящаяся стрелка по направлению бега
    c.save(); c.translate(cx, cy); c.rotate(head); c.fillStyle = pap ? '#3a6ab0' : '#fff'; c.shadowColor = pap ? 'rgba(0,0,0,0)' : col; c.shadowBlur = 8;
    c.beginPath(); c.moveTo(7, 0); c.lineTo(-5, -5); c.lineTo(-2, 0); c.lineTo(-5, 5); c.closePath(); c.fill(); c.restore();
    c.restore();
    // рамка-вывеска (готовая картинка) + живые украшения главы
    if (pap) { c.strokeStyle = 'rgba(75,46,30,.45)'; c.lineWidth = 1; roundRect(c, mx, my, ms, ms, 3); c.stroke(); paperPin(c, mx + ms / 2, my - 3, '#3a6ab0'); } else {
    const S = mmSign(MM2.msBase || ms), fl = hash2(Math.floor(now * 12), 7) > 0.985 ? 0.45 : 1; // изредка «моргает», как настоящий неон
    const sk = ms / S.ms, sp = S.pad * sk, sW = S.W * sk;
    c.globalAlpha = fl; c.drawImage(S.cv, mx - sp, my - sp, sW, sW);
    if (S.tints && (now % 2.6) < 0.14) { // глава 4: глитч – рамка двоится розовым и голубым
      c.globalAlpha = 0.55; c.drawImage(S.tints[0], mx - sp - 2, my - sp, sW, sW); c.drawImage(S.tints[1], mx - sp + 2, my - sp + 1, sW, sW);
    }
    c.globalAlpha = 1;
    mmSignLive(c, mx, my, ms, now);
    }
    // дальние цели – по краю, не налезая друг на друга
    // значки – чуть внутри рамки: украшения главы снаружи остаются видны
    const rimAt = (a, inset = 11) => { const k = (rr - inset) / Math.max(Math.abs(Math.cos(a)), Math.abs(Math.sin(a))); return [cx + Math.cos(a) * k, cy + Math.sin(a) * k]; };
    c.textAlign = 'center'; c.textBaseline = 'middle';
    const items = rimList.map(m => ({ m, a: Math.atan2(m.y - P.y, m.x - P.x) })).sort((p1, p2) => p1.a - p2.a), gap = 20 / rr;
    for (let it = 0; it < 8 && items.length > 1; it++) for (let i = 0; i < items.length; i++) {
      const A = items[i], B = items[(i + 1) % items.length]; let d = B.a - A.a; if (i === items.length - 1) d += TAU;
      if (d < gap) { const pu2 = (gap - d) / 2; A.a -= pu2; B.a += pu2; }
    }
    for (const { m, a } of items) {
      const [x, y] = rimAt(a);
      c.fillStyle = pap ? '#fbf3e0' : 'rgba(10,8,20,0.88)'; c.beginPath(); c.arc(x, y, 9, 0, TAU); c.fill();
      c.strokeStyle = m.k === 'ev' ? (pap ? '#c8902a' : '#ffd25a') : pap ? 'rgba(75,46,30,.7)' : col; c.lineWidth = 1.5; c.stroke();
      c.font = '11px sans-serif'; c.fillText(m.ic, x, y + 0.5);
    }
    if (o) { // куда идти: стрелка (внутри – у цели, иначе – на краю), пульсирует
      const ox = X(o.x), oy = Y(o.y), a = Math.atan2(o.y - P.y, o.x - P.x), [x, y] = inBox(ox, oy, 14) ? [ox, oy] : rimAt(a, 1), p2 = 1 + 0.2 * Math.sin(now * 7);
      c.save(); c.translate(x, y); c.rotate(a); c.scale(p2, p2);
      c.fillStyle = '#d6f03a'; c.strokeStyle = 'rgba(0,0,0,0.7)'; c.lineWidth = 1.5;
      c.beginPath(); c.moveTo(8, 0); c.lineTo(-5, -6); c.lineTo(-2, 0); c.lineTo(-5, 6); c.closePath(); c.fill(); c.stroke(); c.restore();
    }
    c.textBaseline = 'alphabetic';
    // значок «развернуть» в углу: мини-карта нажимается
    { const ex = mx + ms - 9, ey = my + ms - 9; c.save(); c.globalAlpha = 0.75; c.strokeStyle = pap ? '#4b2e1e' : col; c.lineWidth = 1.6; c.lineCap = 'round';
      c.beginPath(); c.moveTo(ex - 5, ey - 1); c.lineTo(ex - 5, ey - 5); c.lineTo(ex - 1, ey - 5); c.moveTo(ex + 5, ey + 1); c.lineTo(ex + 5, ey + 5); c.lineTo(ex + 1, ey + 5);
      c.moveTo(ex - 5, ey - 5); c.lineTo(ex - 1.5, ey - 1.5); c.moveTo(ex + 5, ey + 5); c.lineTo(ex + 1.5, ey + 1.5); c.stroke(); c.restore(); }
    if (G.mmHintT > 0 && !G.activeBoss) { // первые разы – как пользоваться
      c.globalAlpha = clamp(G.mmHintT / 0.6, 0, 1); c.font = 'bold 10px sans-serif'; c.textAlign = 'right'; c.textBaseline = 'alphabetic';
      const ht = '👆 тап – карта · 🤏 щипок – больше', hw = c.measureText(ht).width + 14, hy = my + ms + 24;
      c.fillStyle = 'rgba(8,4,20,0.8)'; roundRect(c, mx + ms - hw + 4, hy - 12, hw, 17, 8); c.fill();
      c.fillStyle = '#fff'; c.fillText(ht, mx + ms - 3, hy); c.globalAlpha = 1;
    }
  }
  // рамка с украшениями главы: светящиеся трубки рисуются один раз в отдельный холст – каждый кадр только копируется
  function mmSign(ms) {
    ms = Math.round(ms);
    const key = CHN + '|' + ms + '|' + DPR;
    if (MM2.sign && MM2.sign.key === key) return MM2.sign;
    const pad = 32, W = ms + pad * 2, d = Math.min(DPR, 3);
    const cv = makeCanvas(Math.ceil(W * d), Math.ceil(W * d)), c = cv.getContext('2d'); c.scale(d, d);
    mmSignDraw(c, pad, pad, ms);
    let tints = null;
    if (CHN === 4) tints = ['#ff3ea5', '#3ff0ff'].map(colr => { const t = makeCanvas(cv.width, cv.height), tcx = t.getContext('2d'); tcx.drawImage(cv, 0, 0); tcx.globalCompositeOperation = 'source-in'; tcx.fillStyle = colr; tcx.fillRect(0, 0, t.width, t.height); return t; });
    return (MM2.sign = { key, cv, pad, W, tints, ms });
  }
  function mmSignDraw(c, mx, my, ms) {
    const col = neonCol(), acc = neonAcc(), ch = CHN, cx = mx + ms / 2;
    // неоновая трубка: цветное свечение и белая сердцевина
    const tube = (color, w, path, fill) => {
      c.save(); c.strokeStyle = color; c.lineWidth = w; c.lineCap = 'round'; c.lineJoin = 'round'; c.shadowColor = color; c.shadowBlur = 10;
      c.beginPath(); path(); if (fill) { c.fillStyle = fill; c.fill(); } c.stroke();
      c.shadowBlur = 0; c.globalAlpha = 0.85; c.strokeStyle = '#ffffff'; c.lineWidth = Math.max(0.6, w * 0.32); c.stroke(); c.restore();
    };
    tube(col, 2.6, () => roundRect(c, mx, my, ms, ms, 12));
    tube(col, 1, () => roundRect(c, mx - 5, my - 5, ms + 10, ms + 10, 16));
    const leaf = (x, y, a, k = 1, colr = acc) => tube(colr, 1.5, () => { c.save(); c.translate(x, y); c.rotate(a); c.scale(k, k); c.moveTo(0, 0); c.quadraticCurveTo(6, -6, 13, 0); c.quadraticCurveTo(6, 6, 0, 0); c.moveTo(1, 0); c.lineTo(11, 0); c.restore(); });
    const ears = (outer, inner) => { for (const sg of [-1, 1]) {
      const bx = cx + sg * ms * 0.3, by = my;
      tube(outer, 2, () => { c.moveTo(bx - sg * 10, by + 1); c.lineTo(bx + sg * 5, by - 14); c.lineTo(bx + sg * 11, by + 3); }, 'rgba(6,3,15,0.85)');
      tube(inner, 1.2, () => { c.moveTo(bx - sg * 3, by - 1); c.lineTo(bx + sg * 4, by - 8); c.lineTo(bx + sg * 7, by + 1); });
    } };
    const star5 = (x, y, r) => { for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + i * Math.PI / 5, rr2 = i % 2 ? r * 0.45 : r; const px = x + Math.cos(a) * rr2, py = y + Math.sin(a) * rr2; if (i) c.lineTo(px, py); else c.moveTo(px, py); } c.closePath(); };
    if (ch === 1) { // лес: листья по углам, лоза, грибок, цветок
      leaf(mx - 2, my - 2, -2.4); leaf(mx - 2, my - 2, -1.5, 0.8); leaf(mx + ms + 2, my + ms + 2, 0.75); leaf(mx + ms + 2, my + ms + 2, -0.1, 0.8);
      leaf(mx + ms + 2, my - 2, -0.75, 0.9); leaf(mx - 2, my + ms + 2, 2.4, 0.9);
      tube(acc, 1.2, () => { c.moveTo(mx + 16, my - 2); for (let x = mx + 16; x <= mx + ms - 16; x += 2) c.lineTo(x, my - 2 - Math.sin((x - mx) * 0.16) * 3); });
      for (let x = mx + 26; x < mx + ms - 20; x += 22) leaf(x, my - 2 - Math.sin((x - mx) * 0.16) * 3, -1.2 + ((x / 22) % 2) * 2.4, 0.55);
      tube('#ff6a8a', 1.6, () => { c.arc(mx + 16, my + ms + 9, 7, Math.PI, 0); c.closePath(); }, 'rgba(6,3,15,0.85)');
      tube(acc, 1.3, () => { c.moveTo(mx + 13.5, my + ms + 9); c.lineTo(mx + 14, my + ms + 16); c.lineTo(mx + 18, my + ms + 16); c.lineTo(mx + 18.5, my + ms + 9); });
      const fx = mx + ms - 14, fy = my - 9; for (let i = 0; i < 5; i++) { const a = i / 5 * TAU; tube('#ff9ad0', 1.1, () => c.arc(fx + Math.cos(a) * 3.2, fy + Math.sin(a) * 3.2, 2, 0, TAU)); } tube(acc, 1, () => c.arc(fx, fy, 1.2, 0, TAU), acc);
    } else if (ch === 2) { // Кринж-Цитадель: диско-шар, ноты, звёзды, молния
      const x = mx - 2, y = my + ms - 2, r = 10;
      tube(acc, 1.6, () => { c.moveTo(x, y - r - 10); c.lineTo(x, y - r); c.moveTo(x + r, y); c.arc(x, y, r, 0, TAU); c.moveTo(x - r, y); c.lineTo(x + r, y); c.moveTo(x, y - r); c.lineTo(x, y + r); c.ellipse(x, y, r * 0.5, r, 0, 0, TAU); }, 'rgba(6,3,15,0.9)');
      const note = (nx, ny, k) => tube('#ffffff', 1.3, () => { c.ellipse(nx, ny, 3 * k, 2.2 * k, -0.4, 0, TAU); c.moveTo(nx + 2.8 * k, ny); c.lineTo(nx + 2.8 * k, ny - 11 * k); c.quadraticCurveTo(nx + 7 * k, ny - 9 * k, nx + 6 * k, ny - 5 * k); });
      note(mx - 6, my + 22, 1); note(mx + 12, my - 8, 0.8);
      tube(acc, 1.4, () => star5(mx + ms - 8, my - 8, 7)); tube('#ffffff', 1, () => star5(mx + ms + 7, my + 14, 3.5));
      tube('#ffd25a', 1.6, () => { const lx = mx + ms + 6, ly = my + ms * 0.45; c.moveTo(lx + 2, ly - 12); c.lineTo(lx - 3, ly); c.lineTo(lx + 2, ly); c.lineTo(lx - 2, ly + 12); });
    } else if (ch === 3) { // Зеркальный дворец: корона, самоцветы, леденец
      tube(acc, 1.6, () => { c.moveTo(cx - 14, my + 1); c.lineTo(cx - 14, my - 9); c.lineTo(cx - 7, my - 3); c.lineTo(cx, my - 13); c.lineTo(cx + 7, my - 3); c.lineTo(cx + 14, my - 9); c.lineTo(cx + 14, my + 1); c.closePath(); }, 'rgba(6,3,15,0.9)');
      for (const gx of [-7, 0, 7]) tube('#ff6fb5', 1, () => c.arc(cx + gx, my - 2, 1.3, 0, TAU), '#ff6fb5');
      for (const [x, y] of [[mx - 5, my + ms / 2], [mx + ms + 5, my + ms / 2], [cx, my + ms + 5]]) tube(acc, 1.5, () => { c.moveTo(x, y - 6); c.lineTo(x + 4.5, y); c.lineTo(x, y + 6); c.lineTo(x - 4.5, y); c.closePath(); }, 'rgba(255,210,90,0.3)');
      const lx = mx + ms + 4, ly = my + ms - 16;
      tube('#ffffff', 1.5, () => { c.moveTo(lx, ly + 7); c.lineTo(lx, ly + 22); });
      tube('#ff6fb5', 1.6, () => { c.arc(lx, ly, 7, 0, TAU); for (let a = 0; a < TAU * 1.6; a += 0.3) { const r2 = 6 - a * 0.55; if (r2 < 0.5) break; c[a ? 'lineTo' : 'moveTo'](lx + Math.cos(a) * r2, ly + Math.sin(a) * r2); } }, 'rgba(6,3,15,0.85)');
    } else if (ch === 4) { // ночь глитчей: кошачьи ушки, усы, хвост, глитч-пиксели
      ears(col, '#ff9ad0');
      for (const sg of [-1, 1]) tube('#ffffff', 1, () => { const bx = sg < 0 ? mx - 3 : mx + ms + 3, by = my + ms * 0.58; for (const dy of [-5, 0, 5]) { c.moveTo(bx, by + dy * 0.4); c.lineTo(bx + sg * 13, by + dy); } });
      tube(col, 2, () => { c.moveTo(mx + ms - 4, my + ms + 4); c.bezierCurveTo(mx + ms + 18, my + ms + 6, mx + ms + 16, my + ms - 22, mx + ms + 8, my + ms - 20); });
      for (const [x, y, colr] of [[mx - 4, my + 8, '#ff3ea5'], [mx + 6, my - 5, '#3ff0ff'], [mx + ms + 2, my + ms * 0.3, '#3ff0ff'], [mx + ms * 0.2, my + ms + 3, '#ff3ea5']]) { c.save(); c.fillStyle = colr; c.shadowColor = colr; c.shadowBlur = 8; c.fillRect(x, y, 4, 4); c.fillRect(x + 5, y + 2, 2, 2); c.restore(); }
    } else if (ch === 5) { // детектив Тесса: ушки, лупа, знак вопроса
      ears(col, '#ff9ad0');
      const lx = mx - 4, ly = my + ms - 2;
      tube('#c8a040', 3, () => { c.moveTo(lx - 5, ly + 5); c.lineTo(lx - 14, ly + 14); });
      tube(acc, 1.8, () => c.arc(lx, ly, 7, 0, TAU), 'rgba(160,220,255,0.15)');
      tube('#ffffff', 1.6, () => { const qx = mx + ms + 7, qy = my + 16; c.arc(qx, qy - 4, 4.5, Math.PI * 1.1, Math.PI * 2.4); c.lineTo(qx, qy + 4); c.moveTo(qx, qy + 9); c.arc(qx, qy + 9, 0.6, 0, TAU); });
    } else if (ch === 7) { // бездна: водоросли по углам, ракушка сверху, морская звезда
      for (const [x, sg] of [[mx - 2, 1], [mx + ms + 2, -1]]) for (let k = 0; k < 2; k++) tube('#3dffa0', 1.5, () => { const x0 = x + sg * k * 6; c.moveTo(x0, my + ms + 6); c.bezierCurveTo(x0 + sg * 8, my + ms - 8, x0 - sg * 6, my + ms - 18, x0 + sg * 4, my + ms - 30 - k * 8); });
      tube(acc, 1.5, () => { const sx = cx, sy = my - 3; c.moveTo(sx - 11, sy + 2); c.quadraticCurveTo(sx, sy - 18, sx + 11, sy + 2); c.closePath(); for (let r = -8; r <= 8; r += 4) { c.moveTo(sx, sy + 2); c.lineTo(sx + r, sy - 8); } }, 'rgba(6,3,15,0.85)');
      tube('#ffb04a', 1.4, () => star5(mx + ms + 6, my + 10, 7));
    } else if (ch === 6) { // зима: снежная шапка, сосульки, снежинки
      tube('#ffffff', 1.6, () => { c.moveTo(mx + 6, my + 1); for (let i = 0, x = mx + 6; x < mx + ms - 6; i++) { const w2 = 9 + hash2(i, 9) * 8; c.quadraticCurveTo(x + w2 / 2, my - 6 - hash2(i, 4) * 5, x + w2, my + 1); x += w2; } }, 'rgba(255,255,255,0.12)');
      for (let i = 0; i < 6; i++) { const x = mx + ms * (0.1 + i * 0.16), y = my + ms + 3, l = 6 + hash2(i, 5) * 8; tube(col, 1.4, () => { c.moveTo(x - 2.5, y); c.lineTo(x, y + l); c.lineTo(x + 2.5, y); }); }
      const flake = (x, y, r) => tube(acc, 1.1, () => { for (let k = 0; k < 3; k++) { const a = k * Math.PI / 3; c.moveTo(x - Math.cos(a) * r, y - Math.sin(a) * r); c.lineTo(x + Math.cos(a) * r, y + Math.sin(a) * r); } });
      flake(mx - 4, my - 4, 6); flake(mx + ms + 4, my - 4, 5); flake(mx - 6, my + ms * 0.6, 4); flake(mx + ms + 6, my + ms * 0.5, 4.5);
    }
  }
  // живые украшения: без размытия (оно дорогое), лёгкие точки и линии
  function mmSignLive(c, mx, my, ms, now) {
    const col = neonCol(), acc = neonAcc(), ch = CHN, cx = mx + ms / 2, cy = my + ms / 2;
    const dot = (x, y, r, colr, a) => { c.globalAlpha = a * 0.3; c.fillStyle = colr; c.beginPath(); c.arc(x, y, r * 2.6, 0, TAU); c.fill(); c.globalAlpha = a; c.beginPath(); c.arc(x, y, r, 0, TAU); c.fill(); c.globalAlpha = 1; };
    if (ch === 1) for (let i = 0; i < 5; i++) { // светлячки вокруг рамки
      const x = cx + Math.sin(now * 0.6 + i * 1.7) * (ms / 2 + 12), y = cy + Math.cos(now * 0.8 + i * 2.3) * (ms / 2 + 12);
      if (Math.abs(x - cx) < ms / 2 - 2 && Math.abs(y - cy) < ms / 2 - 2) continue;
      dot(x, y, 1.4, acc, 0.5 + 0.5 * Math.sin(now * 4 + i));
    } else if (ch === 2) { // эквалайзер под рамкой и искорки
      const n = 9, bw = (ms - 30) / n;
      for (let i = 0; i < n; i++) { const h = 3 + Math.abs(Math.sin(now * 7 + i * 1.3) * Math.sin(now * 3.1 + i)) * 10; c.globalAlpha = 0.85; c.fillStyle = i % 2 ? col : acc; c.fillRect(mx + 22 + i * bw, my + ms + 9 - h, bw - 3, h); }
      c.globalAlpha = 1;
      for (let i = 0; i < 3; i++) { const t = (now * 0.7 + i / 3) % 1; dot(mx - 2 + Math.cos(2.2 + i) * (14 + t * 10), my + ms - 2 + Math.sin(2.2 + i) * (14 + t * 10), 1.2, '#ffffff', 1 - t); }
    } else if (ch === 3) { // огоньки бегут по рамке, как гирлянда
      const per = ms * 4;
      for (let i = 0; i < 8; i++) {
        let d = (now * 40 + i * per / 8) % per, x, y;
        if (d < ms) { x = mx + d; y = my - 5; } else if ((d -= ms) < ms) { x = mx + ms + 5; y = my + d; } else if ((d -= ms) < ms) { x = mx + ms - d; y = my + ms + 5; } else { d -= ms; x = mx - 5; y = my + ms - d; }
        dot(x, y, 1.5, acc, 0.9);
      }
    } else if (ch === 4) { // моргающие глаза под рамкой
      const bl = Math.sin(now * 1.3) > 0.95 ? 0.15 : 1;
      c.fillStyle = acc; c.globalAlpha = 0.35; for (const sg of [-1, 1]) { c.beginPath(); c.ellipse(cx + sg * 10, my + ms + 12, 6, 4 * bl, 0, 0, TAU); c.fill(); }
      c.globalAlpha = 1; for (const sg of [-1, 1]) { c.beginPath(); c.ellipse(cx + sg * 10, my + ms + 12, 3.5, 2.2 * bl, 0, 0, TAU); c.fill(); }
    } else if (ch === 5) { // лапки шагают по низу
      for (let i = 0; i < 6; i++) {
        const t = ((now * 0.35 + i / 6) % 1), x = mx + 18 + t * (ms - 26), y = my + ms + 9 + (i % 2 ? 3 : -2), a = clamp(Math.min(t, 1 - t) * 6, 0, 1) * 0.85;
        c.globalAlpha = a; c.fillStyle = acc; c.beginPath(); c.ellipse(x, y, 2.2, 1.7, 0, 0, TAU); c.fill();
        for (const [dx, dy] of [[-2.2, -2.4], [0, -3.2], [2.2, -2.4]]) { c.beginPath(); c.arc(x + dx, y + dy, 0.9, 0, TAU); c.fill(); }
      }
      c.globalAlpha = 1;
    } else if (ch === 7) { // пузырьки поднимаются и криль плывёт вдоль верха
      for (let i = 0; i < 7; i++) { const k = (now * (0.18 + hash2(i, 4) * 0.1) + hash2(4, i)) % 1, x = (i % 2 ? mx - 6 : mx + ms + 6) + Math.sin(now * 2 + i) * 3, y = my + ms + 6 - k * (ms + 20); dot(x, y, 1 + hash2(i, 9) * 1.6, '#dff8ff', 0.8 * Math.sin(k * Math.PI)); }
      const kx = mx + ((now * 30) % (ms + 40)) - 20, ky = my - 9 + Math.sin(now * 3) * 2;
      for (let j = 0; j < 3; j++) { const x = kx - j * 9; if (x < mx - 10 || x > mx + ms + 10) continue; dot(x, ky + Math.sin(now * 5 + j) * 1.5, 1.6, acc, 0.9); c.strokeStyle = acc; c.globalAlpha = 0.6; c.lineWidth = 1; c.beginPath(); c.moveTo(x - 2, ky); c.lineTo(x - 6, ky + 1.5); c.stroke(); c.globalAlpha = 1; }
    } else if (ch === 6) for (let i = 0; i < 9; i++) { // снег падает
      const k = (now * (0.08 + hash2(i, 3) * 0.06) + hash2(3, i)) % 1, x = mx - 8 + hash2(i, 8) * (ms + 16) + Math.sin(now + i) * 4, y = my - 14 + k * (ms + 34);
      dot(x, y, 1.1, '#ffffff', 0.8 * Math.sin(k * Math.PI));
    }
  }
  function drawEventFx(c) {
    const ev = G.ev; if (!ev) return;
    const d = ev.def, fade = clamp(ev.t / 0.6, 0, 1) * clamp((d.dur - ev.t) / 0.8, 0, 1);
    const pulse = d.id === 'rage' ? 0.5 + 0.25 * Math.sin(ev.t * 4) : 0.3 + 0.1 * Math.sin(ev.t * 3);
    const g = c.createRadialGradient(VW / 2, VH / 2, Math.min(VW, VH) * 0.25, VW / 2, VH / 2, Math.max(VW, VH) * 0.72);
    g.addColorStop(0, `rgba(${d.tint},0)`); g.addColorStop(1, `rgba(${d.tint},${0.55 * pulse * fade})`);
    c.fillStyle = g; c.fillRect(0, 0, VW, VH);
    if (d.id === 'rage') { c.fillStyle = `rgba(255,20,20,${(0.07 + 0.04 * Math.sin(ev.t * 7)) * fade})`; c.fillRect(0, 0, VW, VH); }
  }
  // сундуки снова видны на карте сразу; тайные (на полянах) – только когда их нашёл или с компасом
  const chestOnMap = ch => !ch.open && (ch.secret ? ch.seen || relicLv('compass') >= 3 : !ch.glade || ch.seen || (hasRelic('compass') && Math.hypot(ch.x - P.x, ch.y - P.y) < (relicLv('compass') >= 2 ? 1700 : 1000)));
  // плашка с подписью слева и числом справа: ширина по тексту, чтобы ничего не налезало
  function pillFit(c, x, y, h, fill, left, right, leftFont, rightFont) {
    const maxW = VW - Math.min(124, VW * 0.3) - 22 - x;
    let lf = leftFont; c.font = lf; let wl = c.measureText(left).width;
    c.font = rightFont; const wr = right ? c.measureText(right).width : 0;
    let w = Math.max(156, wl + wr + (right ? 22 : 14));
    if (w > maxW) { // не влезает – чуть мельче шрифт
      const px = parseFloat(lf.match(/(\d+)px/)[1]), k = Math.max(0.75, (maxW - wr - 22) / wl);
      lf = lf.replace(/\d+px/, Math.floor(px * k) + 'px'); c.font = lf; wl = c.measureText(left).width; w = maxW;
    }
    c.fillStyle = fill; roundRect(c, x, y, w, h, 8); c.fill();
    return { w, lf };
  }
  function drawEventPill(c, x, y) {
    const ev = G.ev;
    if (ev) {
      const d = ev.def, left = Math.max(0, d.dur - ev.t);
      const lt = d.id === 'horde' ? `${d.ic} Осада · ${ev.kills}/${ev.goal}` : d.id === 'thief' ? `${d.ic} Воришка · лови!`
        : d.id === 'treasure' ? `${d.ic} Клад · ${Math.round(Math.hypot(ev.tx - P.x, ev.ty - P.y) / PX_PER_M)} м` : `${d.ic} ${d.name}`;
      const rt = `${Math.ceil(left)}с`;
      const { w, lf } = pillFit(c, x, y, 24, `rgba(${d.tint},0.85)`, lt, rt, '900 11px sans-serif', '900 11px sans-serif');
      c.fillStyle = 'rgba(0,0,0,0.35)'; c.fillRect(x + 6, y + 18, w - 12, 3);
      c.fillStyle = '#fff'; c.fillRect(x + 6, y + 18, (w - 12) * clamp(left / d.dur, 0, 1), 3);
      c.font = lf; c.textAlign = 'left'; c.fillStyle = '#fff';
      c.fillText(lt, x + 6, y + 13);
      c.font = '900 11px sans-serif'; c.textAlign = 'right'; c.fillText(rt, x + w - 6, y + 13);
      return;
    }
    if (CFG.rush || G.cutscene || G.finalFinal || G.activeBoss || G.activeShrine) return;
    if (G.evT > 8) {
      const bi = curBiome(), cm = calmOf(bi);
      if (cm > 0) {
        const st = calmStage(bi), n = G.calm[bi], nx = CALM_STEPS[st + 1];
        const lt = `🕊️ Усмирение ${ROMAN[st]} · −${Math.round(cm * 100)}%`, rt = nx ? `${n}/${nx}` : 'МАКС';
        const { w, lf } = pillFit(c, x, y, 24, 'rgba(30,110,130,0.8)', lt, rt, 'bold 11px sans-serif', 'bold 10px sans-serif');
        c.font = lf; c.textAlign = 'left'; c.fillStyle = '#dffaff';
        c.fillText(lt, x + 6, y + 13);
        c.textAlign = 'right'; c.font = 'bold 10px sans-serif'; c.fillText(rt, x + w - 6, y + 13);
        c.fillStyle = 'rgba(0,0,0,0.35)'; c.fillRect(x + 6, y + 18, w - 12, 3);
        c.fillStyle = '#bff6ff'; c.fillRect(x + 6, y + 18, (w - 12) * (nx ? clamp((n - CALM_STEPS[st]) / (nx - CALM_STEPS[st]), 0, 1) : 1), 3);
      }
      return;
    }
    // за 8 секунд – что будет и когда
    const nx = G.nextEv, lt = nx ? `🎲 Скоро: ${nx.ic} ${nx.name}` : '🎲 Скоро событие', rt = `${Math.ceil(G.evT)}с`;
    const { w, lf } = pillFit(c, x, y, 20, 'rgba(0,0,0,0.55)', lt, rt, 'bold 11px sans-serif', 'bold 11px sans-serif');
    c.font = lf; c.textAlign = 'left'; c.fillStyle = Math.floor(G.evT * 2) % 2 ? '#ffd25a' : '#ffffff';
    c.fillText(lt, x + 8, y + 14);
    c.font = 'bold 11px sans-serif'; c.textAlign = 'right'; c.fillText(rt, x + w - 7, y + 14);
  }
  // ===== 1.0: акварельная бумага поверх мира =====
  // мир рисуется как раньше, а сверху – тёплый «подъём» тёмных тонов, зерно бумаги (прилипает к миру) и виньетка
  const PAPER = { tex: null, pat: null, vig: null, vw: 0, vh: 0 };
  function paperTex() {
    const S = 384, cv = document.createElement('canvas'); cv.width = cv.height = S; const c = cv.getContext('2d');
    c.fillStyle = '#ffffff'; c.fillRect(0, 0, S, S);
    // пятна акварели – бесшовно: каждое рисуем и со сдвигом на размер плитки
    const wash = (x, y, r, col) => { for (const dx of [-S, 0, S]) for (const dy of [-S, 0, S]) { const g = c.createRadialGradient(x + dx, y + dy, 0, x + dx, y + dy, r); g.addColorStop(0, col); g.addColorStop(1, 'rgba(255,255,255,0)'); c.fillStyle = g; c.fillRect(x + dx - r, y + dy - r, r * 2, r * 2); } };
    for (let i = 0; i < 26; i++) wash(Math.random() * S, Math.random() * S, 40 + Math.random() * 90, Math.random() < 0.5 ? 'rgba(236,214,178,.35)' : 'rgba(214,196,160,.22)');
    // зерно и волокна
    const id = c.getImageData(0, 0, S, S), d = id.data;
    for (let i = 0; i < d.length; i += 4) { const n = (Math.random() - 0.5) * 22; d[i] = Math.min(255, d[i] + n); d[i + 1] = Math.min(255, d[i + 1] + n); d[i + 2] = Math.min(255, d[i + 2] + n * 1.2); }
    c.putImageData(id, 0, 0);
    c.strokeStyle = 'rgba(150,120,80,.10)'; c.lineWidth = 0.7;
    for (let i = 0; i < 90; i++) { const x = Math.random() * S, y = Math.random() * S, a = Math.random() * TAU, l = 6 + Math.random() * 14; c.beginPath(); c.moveTo(x, y); c.quadraticCurveTo(x + Math.cos(a + 0.5) * l * 0.5, y + Math.sin(a + 0.5) * l * 0.5, x + Math.cos(a) * l, y + Math.sin(a) * l); c.stroke(); }
    return cv;
  }
  const NIGHT_TINT = { dark: [96, 104, 176], neon: [110, 90, 180], crystal: [92, 116, 186], volcano: [186, 112, 96], glitch: [84, 146, 160] };
  function paperPass() {
    if (!paperOn) return;
    const c = ctx;
    if (!PAPER.tex) PAPER.tex = paperTex();
    if (!PAPER.pat) PAPER.pat = c.createPattern(PAPER.tex, 'repeat');
    if (PAPER.vw !== VW || PAPER.vh !== VH) {
      PAPER.vw = VW; PAPER.vh = VH; const v = document.createElement('canvas'); v.width = Math.ceil(VW / 2); v.height = Math.ceil(VH / 2); const vc = v.getContext('2d');
      const g = vc.createRadialGradient(v.width / 2, v.height / 2, Math.min(v.width, v.height) * 0.35, v.width / 2, v.height / 2, Math.hypot(v.width, v.height) * 0.55);
      g.addColorStop(0, 'rgba(255,255,255,1)'); g.addColorStop(1, 'rgba(226,200,160,1)'); vc.fillStyle = g; vc.fillRect(0, 0, v.width, v.height); PAPER.vig = v;
    }
    c.save(); c.setTransform(DPR, 0, 0, DPR, 0, 0);
    // «ночная сказка»: в тёмных краях – ночной оттенок и тёплый свет вокруг героини
    let nt = null; try { const bid = BIOMES[curBiome()] && BIOMES[curBiome()].id; nt = G.td ? null : NIGHT_TINT[bid] || null; } catch (e) {}
    if (nt) PAPER.nt = nt;
    PAPER.nk = (PAPER.nk || 0) + ((nt ? 1 : 0) - (PAPER.nk || 0)) * 0.04;
    if (PAPER.nk > 0.02 && PAPER.nt) {
      const [r, g, b] = PAPER.nt, k = PAPER.nk;
      c.globalCompositeOperation = 'multiply'; c.globalAlpha = k * 0.32; c.fillStyle = `rgb(${r},${g},${b})`; c.fillRect(0, 0, VW, VH);
      c.globalAlpha = 1; c.globalCompositeOperation = 'lighter';
      const hx = (P.x - G.cam.x) * ZOOM + VW / 2, hy = (P.y - 20 - G.cam.y) * ZOOM + VH / 2, R = Math.min(VW, VH) * 0.42;
      const lg = c.createRadialGradient(hx, hy, 0, hx, hy, R); lg.addColorStop(0, `rgba(255,190,110,${0.30 * k})`); lg.addColorStop(1, 'rgba(255,160,80,0)');
      c.fillStyle = lg; c.fillRect(hx - R, hy - R, R * 2, R * 2);
      c.globalCompositeOperation = 'source-over';
    }
    c.globalCompositeOperation = 'multiply';
    const k = ZOOM, ox = -(G.cam.x * k) % 384, oy = -(G.cam.y * k) % 384;
    if (PAPER.pat.setTransform) PAPER.pat.setTransform(new DOMMatrix([k * 0.9, 0, 0, k * 0.9, ox, oy]));
    c.fillStyle = PAPER.pat; c.fillRect(0, 0, VW, VH);
    c.drawImage(PAPER.vig, 0, 0, VW, VH);
    c.restore();
  }
  // ===== 1.0: бумажный интерфейс =====
  const INK = '#4b2e1e', NOTE_C = 'rgba(251,244,226,.94)';
  const HAND = s => `400 ${s}px Neucha, sans-serif`;
  const _lightC = new Map();
  function lightCol(col) { // светлый цвет текста на бумаге не читается – такой меняем на чернила
    let v = _lightC.get(col); if (v !== undefined) return v;
    const m = /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(col || ''); v = false;
    if (m) { let h = m[1]; if (h.length === 3) h = h.split('').map(x => x + x).join(''); const n = parseInt(h, 16); v = (0.3 * (n >> 16) + 0.59 * ((n >> 8) & 255) + 0.11 * (n & 255)) > 190; }
    _lightC.set(col, v); return v;
  }
  function paperPin(c, x, y, col) {
    c.save(); c.shadowColor = 'rgba(60,30,10,.4)'; c.shadowBlur = 3 * DPR; c.shadowOffsetY = 1.5 * DPR; c.fillStyle = col; c.beginPath(); c.arc(x, y, 5, 0, TAU); c.fill(); c.restore();
    c.fillStyle = 'rgba(255,255,255,.6)'; c.beginPath(); c.arc(x - 1.5, y - 1.5, 1.6, 0, TAU); c.fill();
  }
  function paperNote(c, x, y, w, h, rot) {
    c.save(); c.translate(x + w / 2, y + h / 2); c.rotate(rot); c.shadowColor = 'rgba(80,50,20,.3)'; c.shadowBlur = 6 * DPR; c.shadowOffsetY = 2 * DPR;
    c.fillStyle = NOTE_C; c.fillRect(-w / 2, -h / 2, w, h); c.restore();
  }
  function handText(c, t, x, y, size, col, al = 'left', stroke) {
    c.font = HAND(size); c.textAlign = al; if (stroke) { c.lineJoin = 'round'; c.lineWidth = 4; c.strokeStyle = stroke; c.strokeText(t, x, y); } c.fillStyle = col; c.fillText(t, x, y);
  }
  function inkLine(c, x1, y1, x2, y2, col, lw) { for (const [dx, dy, a] of [[0, 0, 1], [0.8, 0.6, 0.45]]) { c.globalAlpha = a; c.strokeStyle = col; c.lineWidth = lw; c.beginPath(); c.moveTo(x1 + dx, y1 + dy); c.lineTo(x2 + dx, y2 - 0.6 + dy); c.stroke(); } c.globalAlpha = 1; }
  function inkFlask(c, x, y, k) {
    const p = new Path2D(`M${x - 4},${y - 16} L${x + 4},${y - 16} L${x + 4},${y - 8} C${x + 14},${y - 4} ${x + 14},${y + 14} ${x},${y + 14} C${x - 14},${y + 14} ${x - 14},${y - 4} ${x - 4},${y - 8} Z`);
    c.fillStyle = 'rgba(255,255,255,.65)'; c.fill(p); c.save(); c.clip(p);
    const top = y + 14 - 26 * clamp(k, 0, 1); c.fillStyle = k < 0.3 ? 'rgba(232,60,40,.85)' : 'rgba(216,70,58,.75)'; c.beginPath(); c.moveTo(x - 16, top); c.quadraticCurveTo(x, top - 3, x + 16, top); c.lineTo(x + 16, y + 16); c.lineTo(x - 16, y + 16); c.fill();
    c.fillStyle = 'rgba(255,255,255,.55)'; c.fillRect(x - 7, y - 2, 2.5, 9); c.restore();
    for (const [dx, dy, a] of [[0, 0, 1], [0.8, 0.6, 0.4]]) { c.save(); c.globalAlpha = a; c.translate(dx, dy); c.strokeStyle = INK; c.lineWidth = 1.4; c.stroke(p); c.restore(); }
    c.fillStyle = '#a87a52'; c.fillRect(x - 5, y - 20, 10, 5);
  }
  function drawPaperTop(c, x0, y0, w, infoT) {
    const h = 68;
    paperNote(c, x0, y0, w, h, -0.012); paperPin(c, x0 + w * 0.55, y0 + 3, '#d8463a');
    // портрет героини в нарисованном кружке
    const px = x0 + 32, py = y0 + 32, pr = 21;
    c.save(); c.beginPath(); c.arc(px, py, pr, 0, TAU); c.fillStyle = '#f6e2c8'; c.fill(); c.clip();
    try { c.drawImage(heroAvatar(P.hero), px - pr, py - pr, pr * 2, pr * 2); } catch (e) {}
    c.restore();
    for (const [dx, dy, a] of [[0, 0, 1], [0.8, 0.6, 0.45]]) { c.globalAlpha = a; c.strokeStyle = INK; c.lineWidth = 1.5; c.beginPath(); c.arc(px + dx, py + dy, pr + 1, 0, TAU); c.stroke(); } c.globalAlpha = 1;
    handText(c, String(P.level), px + 19, py + 26, 17, '#3a6ab0', 'center', NOTE_C);
    // здоровье – колба, опыт – синяя линия
    const k = clamp(P.hp / P.maxHp, 0, 1);
    inkFlask(c, x0 + 74, y0 + 28, k);
    handText(c, `${Math.max(0, Math.ceil(P.hp))}/${Math.round(P.maxHp)}`, x0 + 90, y0 + 27, 18, k < 0.3 ? '#c8241a' : '#8a2a1a');
    const lx1 = x0 + 90, lx2 = x0 + w - 10, ly = y0 + 41;
    inkLine(c, lx1, ly, lx2, ly, 'rgba(75,46,30,.45)', 1.1);
    c.strokeStyle = '#4a86c8'; c.lineWidth = 4; c.lineCap = 'round'; c.beginPath(); c.moveTo(lx1 + 1, ly); c.quadraticCurveTo(lx1 + (lx2 - lx1) * 0.4, ly - 2, lx1 + (lx2 - lx1) * clamp(P.xp / P.xpNext, 0.01, 1), ly - 0.5); c.stroke(); c.lineCap = 'butt';
    // строка о главе: подгоняем размер под ширину
    let fs = 14; c.font = HAND(fs); while (c.measureText(infoT).width > w - 70 && fs > 10) { fs--; c.font = HAND(fs); }
    handText(c, infoT, x0 + 64, y0 + 60, fs, 'rgba(75,46,30,.85)');
  }
  function renderHUD() {
    const c = ctx;
    c.setTransform(DPR, 0, 0, DPR, 0, 0);
    if (state === 'play' || state === 'pause' || state === 'levelup') { drawSeaFx(c); drawEventFx(c); drawHouseFx(c); }
    if (G.hurtFlash > 0) {
      const g = c.createRadialGradient(VW / 2, VH / 2, Math.min(VW, VH) * 0.3, VW / 2, VH / 2, Math.max(VW, VH) * 0.7);
      g.addColorStop(0, 'rgba(255,0,0,0)'); g.addColorStop(1, `rgba(255,0,0,${G.hurtFlash})`);
      c.fillStyle = g; c.fillRect(0, 0, VW, VH);
    }
    const top = SAFE_TOP + 10;
    const lx = 58;
    const topLeft = () => {
    // плашка уровня растягивается под текст (до мини-карты), при нехватке места текст чуть мельче
    const lvT = `Ур. ${P.level}`, zl = zoneE(curBiome());
    let infoT = defOn() ? defInfo() : CFG.abyss && G.abyss ? `🕳️ Бездна · волна ${G.abyss.wave} · ${fmtT(G.abyss.t)}`
      : G.daily ? `📅 ${fmtT(G.daily.left)} · ${fmtN(G.daily.score)} очк.${mutIds().length ? ' ' + mutIds().map(id => MUT_BY[id].ic).join('') : ''}`
      : CFG.rush && G.rush ? `⚔️ Раш · ${Math.min(G.rush.idx + 1, G.rush.total)}/${G.rush.total} · ${fmtT(G.rush.t)}`
      : `Гл.${CHN} · Б ${G.defeated.filter(Boolean).length}/${CFG.bosses.length} · зона ${isFinite(zl) ? zl : '–'}`;
    if (paperOn) { // 1.0: записка на кнопке – портрет, колба здоровья, опыт, уровень
      const nw = clamp(VW - Math.min(124, VW * 0.3) - 34, 170, 236);
      drawPaperTop(c, 8, top - 2, nw, infoT);
      const ly = top + 78;
      if (state === 'play') drawEventPill(c, lx, ly);
      if (defOn()) drawDefHud(c, lx, ly);
      if (NET.on && G.netRun) netHud(c, lx, ly + (G.ev || G.nextEv ? 30 : 0) + (defOn() ? 112 : 0));
      return;
    }
    c.font = '900 14px sans-serif'; const wL = c.measureText(lvT).width;
    let fI = 11; c.font = `bold ${fI}px sans-serif`; let wI = c.measureText(infoT).width;
    const lbMax = VW - Math.min(124, VW * 0.3) - 24 - lx - (MM_STYLE !== 'classic' ? 14 : 0);
    let lbw = Math.max(156, wL + wI + 26);
    while (lbw > lbMax && fI > 9) { fI--; c.font = `bold ${fI}px sans-serif`; wI = c.measureText(infoT).width; lbw = Math.max(156, wL + wI + 26); }
    if (lbw > lbMax && !CFG.rush) { infoT = infoT.replace(' · зона ', ' · з.'); wI = c.measureText(infoT).width; }
    lbw = Math.min(lbMax, Math.max(156, wL + wI + 26));
    c.fillStyle = 'rgba(0,0,0,0.5)'; roundRect(c, lx, top, lbw, 40, 10); c.fill();
    c.font = '900 14px sans-serif'; c.textAlign = 'left'; c.fillStyle = '#ffd25a';
    c.fillText(lvT, lx + 8, top + 17);
    c.font = `bold ${fI}px sans-serif`; c.fillStyle = '#fff'; c.fillText(infoT, lx + 18 + wL, top + 17);
    c.fillStyle = 'rgba(255,255,255,0.15)'; c.fillRect(lx + 8, top + 25, lbw - 16, 7);
    c.fillStyle = '#5bc8ff'; c.fillRect(lx + 8, top + 25, (lbw - 16) * clamp(P.xp / P.xpNext, 0, 1), 7);
    if (state === 'play') drawEventPill(c, lx, top + 46);
    if (defOn()) drawDefHud(c, lx, top + 46);
    if (NET.on && G.netRun) netHud(c, lx, top + 46 + (G.ev || G.nextEv ? 30 : 0) + (defOn() ? 112 : 0)); // в обороне под плашками ещё кнопка вызова волны
    };
    topLeft();
    // мини-карта: щипком её можно растянуть в сторону игры (в бою с боссом – обычного размера)
    const neonMM = MM_STYLE !== 'classic', mmB = MM_STYLE === 'neon' ? 22 : neonMM ? 8 : 0; // у неоновой рамки украшения сверху и снизу
    const msBase = Math.min(124, VW * 0.3), msMax = Math.max(msBase, Math.min(VW - 30, VH / 2 - 78 - top)); // не наезжает на героиню в центре
    { // растянутая щипком мини-карта через пару секунд плавно возвращается к обычному размеру
      const nowT = performance.now(), dtT = Math.min(0.1, (nowT - (MM2.lastT || nowT)) / 1000); MM2.lastT = nowT;
      if (MM2.sizeF && !MMP.pinch && nowT > (MM2.relaxAt || 0)) {
        const cur = MM2.sizeF * VW, nxt = cur + (msBase - cur) * Math.min(1, dtT * 7);
        MM2.sizeF = Math.abs(nxt - msBase) < 1.5 ? 0 : nxt / VW;
      }
    }
    const ms = G.activeBoss || CFG.rush ? msBase : clamp(MM2.sizeF ? MM2.sizeF * VW : msBase, msBase * 0.8, msMax);
    const mx = VW - ms - 10, my = top + (MM_STYLE === 'neon' ? 8 : neonMM ? 4 : 0);
    MM2.msBase = msBase; MM2.msMax = msMax;
    G.miniRect = { x: mx, y: my, s: ms };
    if (MM_STYLE !== 'classic') drawMini2(c, mx, my, ms); else {
    c.save();
    roundRect(c, mx - 3, my - 3, ms + 6, ms + 6, 12); c.fillStyle = 'rgba(255,255,255,0.85)'; c.fill();
    roundRect(c, mx, my, ms, ms, 10); c.clip();
    c.imageSmoothingEnabled = false;
    c.drawImage(miniBase, mx, my, ms, ms);
    c.globalAlpha = 0.72; c.drawImage(fog, mx, my, ms, ms); c.globalAlpha = 1;
    c.imageSmoothingEnabled = true;
    const k = ms / WORLD_W;
    c.fillStyle = '#ff3b3b';
    for (const e of G.enemies) c.fillRect(mx + e.x * k - 1.5, my + e.y * k - 1.5, 3, 3);
    c.fillStyle = '#ffd25a';
    for (const ch of chests) if (chestOnMap(ch)) {
      c.fillStyle = ch.tier === 'gold' ? '#ffd25a' : ch.tier === 'silver' ? '#e0eaff' : '#c8945a';
      c.fillRect(mx + ch.x * k - 2, my + ch.y * k - 2, 4, 4);
    }
    c.fillStyle = '#5be3ff';
    const blink = 0.35 + 0.65 * Math.abs(Math.sin(performance.now() / 380));
    for (const s of shrines) {
      const sx = mx + s.x * k, sy = my + s.y * k;
      if (s.state === 'done') { c.fillStyle = '#c77dff'; c.beginPath(); c.arc(sx, sy, 2.4, 0, TAU); c.fill(); continue; }
      c.globalAlpha = blink; c.fillStyle = '#5be3ff'; c.fillRect(sx - 2.5, sy - 2.5, 5, 5);
      c.strokeStyle = '#5be3ff'; c.lineWidth = 1; c.beginPath(); c.arc(sx, sy, 4 + blink * 2.5, 0, TAU); c.stroke(); c.globalAlpha = 1;
    }
    for (const bd of beds) { c.fillStyle = '#ff9ad0'; c.fillRect(mx + bd.x * k - 1.5, my + bd.y * k - 1.5, 3, 3); }
    for (const f of fires) if (!f.glade || f.lit) { c.fillStyle = '#ff8a2a'; c.beginPath(); c.arc(mx + f.x * k, my + f.y * k, 2.2, 0, TAU); c.fill(); }
    for (const q of pearls) if (!q.got) { c.fillStyle = '#ff9ad0'; c.beginPath(); c.arc(mx + q.x * k, my + q.y * k, 2.4, 0, TAU); c.fill(); }
    for (const q of clues) if (!q.found && (G.clearSight || G.revealT > 0 || (G.pet && Math.hypot(q.x - P.x, q.y - P.y) < 700) || Math.hypot(q.x - P.x, q.y - P.y) < 350 * lv('c5nose'))) {
      c.globalAlpha = blink; c.fillStyle = '#ffd25a'; c.beginPath(); c.arc(mx + q.x * k, my + q.y * k, 2.5, 0, TAU); c.fill(); c.globalAlpha = 1;
    }
    for (const n of npcs) { c.fillStyle = '#ffffff'; c.fillRect(mx + n.x * k - 2, my + n.y * k - 2, 4, 4); }
    for (const it of qitems) if (it.active && !it.taken) { c.globalAlpha = blink; c.fillStyle = '#7dff7d'; c.fillRect(mx + it.x * k - 2, my + it.y * k - 2, 4, 4); c.globalAlpha = 1; }
    if (G.champ && !G.champ.dead) { c.globalAlpha = blink; c.font = '10px sans-serif'; c.textAlign = 'center'; c.fillText('👑', mx + G.champ.x * k, my + G.champ.y * k + 4); c.globalAlpha = 1; }
    c.font = '10px sans-serif'; c.textAlign = 'center';
    for (const b of bosses) {
      if (CFG.rush && G.rush && b.id !== G.rush.idx) continue;
      if (G.td) { if (b.state !== 'dead' && b.state !== 'sleep') c.fillText('💀', mx + b.x * k, my + b.y * k + 4); continue; }
      c.fillText(b.def.immortal ? '♾️' : b.state === 'dead' ? '✅' : '💀', mx + b.hx * k, my + b.hy * k + 4);
    }
    if (!CFG.noCage || (CFG.team && !G.tessaAlly)) c.fillText('❤️', mx + tc(CAGE.x) * k, my + tc(CAGE.y) * k - 4);
    if (G.core) c.fillText('💎', mx + G.core.x * k, my + G.core.y * k + 4);
    c.strokeStyle = '#fff'; c.lineWidth = 2; c.beginPath(); c.arc(mx + P.x * k, my + P.y * k, 4, 0, TAU); c.stroke();
    c.restore();
    c.font = '11px sans-serif'; c.textAlign = 'right'; c.globalAlpha = 0.8; c.fillText('🔍', mx + ms - 3, my + ms - 4); c.globalAlpha = 1;
    }
    if (ms > msBase * 1.1 && mx < lx + 210) topLeft(); // большая мини-карта заходит под плашку уровня – плашка остаётся сверху
    // подруга без сил: записка внизу и стрелка к ней (у края экрана, если она далеко)
    if (NET.on && G.netRun && (state === 'play' || state === 'pause')) {
      const downs = [...NET.mates.values()].filter(m => m.down && m.tx !== undefined && m.id !== NET.id);
      if (downs.length) {
        const m0 = downs[0], nm = (m0.name || 'Подруга') + (downs.length > 1 ? ` и ещё ${downs.length - 1}` : ''), dist = Math.round(Math.hypot(m0.x - P.x, m0.y - P.y) / PX_PER_M);
        const txt = `💫 ${nm} без сил – подними! · ${dist} м`, ny = VH - 175;
        c.font = HAND(17); const tw = c.measureText(txt).width + 26;
        paperNote(c, VW / 2 - tw / 2, ny - 18, tw, 30, -0.01); handText(c, txt, VW / 2, ny + 3, 17, '#b8302a', 'center');
        const pu = 1 + Math.sin(G.time * 6) * 0.12;
        for (const m of downs) {
          const sx = (m.x - G.cam.x) * ZOOM + VW / 2, sy = (m.y - G.cam.y) * ZOOM + VH / 2, mg = 34;
          if (sx > mg && sx < VW - mg && sy > top + 80 && sy < VH - 120) { // видна – стрелка над ней
            c.save(); c.translate(sx, sy - 46 * ZOOM - Math.abs(Math.sin(G.time * 5)) * 8); c.scale(pu, pu);
            c.fillStyle = '#e04a3a'; c.strokeStyle = INK; c.lineWidth = 1.5; c.beginPath(); c.moveTo(-9, -10); c.lineTo(9, -10); c.lineTo(0, 4); c.closePath(); c.fill(); c.stroke(); c.restore();
            continue;
          }
          const a = Math.atan2(sy - VH / 2, sx - VW / 2), ex = clamp(sx, mg, VW - mg), ey = clamp(sy, top + 96, VH - 130);
          c.save(); c.translate(ex, ey);
          c.fillStyle = 'rgba(251,244,226,.95)'; c.strokeStyle = INK; c.lineWidth = 1.5; c.beginPath(); c.arc(0, 0, 15, 0, TAU); c.fill(); c.stroke();
          c.font = '15px sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText('💫', 0, 1); c.textBaseline = 'alphabetic';
          c.rotate(a); c.scale(pu, pu); c.fillStyle = '#e04a3a'; c.beginPath(); c.moveTo(25, 0); c.lineTo(16, -7); c.lineTo(16, 7); c.closePath(); c.fill(); c.stroke();
          c.restore();
        }
      }
    }
    // комбо
    if (G.combo >= 5) {
      const cy = top + ms + mmB + (G.activeBoss ? 70 : 30) + (defOn() && VH > VW ? 150 : 0); // в обороне справа заклинания
      c.globalAlpha = clamp(G.comboT / 0.6, 0, 1); c.textAlign = 'right';
      c.font = '900 18px sans-serif'; c.fillStyle = '#000'; c.fillText(`КОМБО x${G.combo}`, VW - 11, cy + 1);
      c.fillStyle = G.combo >= 50 ? '#ff3ea5' : G.combo >= 20 ? '#ffd25a' : '#ffffff'; c.fillText(`КОМБО x${G.combo}`, VW - 12, cy);
      c.font = 'bold 10px sans-serif'; c.fillStyle = '#bff6ff'; c.fillText(`+${Math.min(G.combo, 100)}% опыта`, VW - 12, cy + 13);
      c.globalAlpha = 1;
    }
    // босс
    const b = G.activeBoss;
    if (b && b.state === 'fight') {
      const w = Math.min(VW - 40, 380), x = (VW - w) / 2, y = top + ms + 12 + mmB;
      if (!paperOn || (b.def.immortal && G.finalFinal)) { c.fillStyle = 'rgba(0,0,0,0.7)'; roundRect(c, x - 4, y - 4, w + 8, 34, 8); c.fill();
      c.fillStyle = '#3a0a0a'; c.fillRect(x, y + 13, w, 11); }
      if (b.def.immortal && G.finalFinal) {
        // бессмертный: вместо здоровья – заряд ДРУЖБА-СУПЕР
        const F = G.finalFinal, k2 = clamp(F.t / F.need, 0, 1), seg = w / RAINBOW.length;
        RAINBOW.forEach((col, i) => { c.fillStyle = col; c.fillRect(x + i * seg, y + 13, seg, 11); });
        c.fillStyle = '#ff3ea5'; c.fillRect(x, y + 13, w, 11);
        c.save(); c.beginPath(); c.rect(x, y + 13, w * k2, 11); c.clip();
        RAINBOW.forEach((col, i) => { c.fillStyle = col; c.fillRect(x + i * seg, y + 13, seg + 1, 11); });
        c.restore();
        c.font = '900 12px sans-serif'; c.textAlign = 'center'; c.fillStyle = '#ffd25a';
        c.fillText(`${b.name.toUpperCase()} · НЕУЯЗВИМ · ПРОДЕРЖИСЬ ${Math.ceil(Math.max(0, F.need - F.t))}с`, VW / 2, y + 8);
        c.font = '900 9px sans-serif'; c.fillStyle = '#fff'; c.fillText(`💜 ДРУЖБА-СУПЕР ${Math.floor(k2 * 100)}%${F.bank > 0.05 ? ' ⏩' : ''}`, VW / 2, y + 22);
      } else if (paperOn) {
        const bw = Math.min(VW - 70, 260), bx = (VW - bw) / 2, ny = y + 16;
        handText(c, b.name, VW / 2, ny, 25, INK, 'center', 'rgba(251,243,224,.88)');
        c.font = HAND(25); const nw2 = Math.min(bw, c.measureText(b.name).width + 10);
        c.strokeStyle = '#c8342a'; c.lineWidth = 1.6; c.beginPath(); c.moveTo(VW / 2 - nw2 / 2, ny + 6); for (let q = -nw2 / 2; q <= nw2 / 2; q += 5) c.lineTo(VW / 2 + q, ny + 6 + Math.sin(q / 3) * 1.6); c.stroke();
        const by = ny + 14, bh = 13, k2 = clamp(b.hp / b.maxHp, 0, 1);
        c.fillStyle = 'rgba(251,243,224,.75)'; c.fillRect(bx, by, bw, bh);
        c.fillStyle = b.stage >= 2 ? 'rgba(200,30,60,.62)' : b.stage === 1 ? 'rgba(220,90,40,.6)' : 'rgba(200,52,42,.58)';
        c.beginPath(); c.moveTo(bx + 2, by + 2); c.lineTo(bx + bw * k2, by + 1); c.lineTo(bx + bw * k2 - 2, by + bh - 1); c.lineTo(bx + 1, by + bh); c.fill();
        for (const [dx, dy, a] of [[0, 0, 1], [0.8, 0.6, 0.45]]) { c.globalAlpha = a; c.strokeStyle = INK; c.lineWidth = 1.3; c.beginPath(); c.moveTo(bx + dx, by + dy); c.lineTo(bx + bw + 1 + dx, by - 0.5 + dy); c.lineTo(bx + bw + dx, by + bh + 0.5 + dy); c.lineTo(bx - 1 + dx, by + bh + dy); c.closePath(); c.stroke(); } c.globalAlpha = 1;
        c.strokeStyle = INK; c.lineWidth = 1.2; for (const st of b.def.stages) if (st.at) { c.beginPath(); c.moveTo(bx + bw * st.at, by - 2); c.lineTo(bx + bw * st.at + 0.5, by + bh + 2); c.stroke(); }
        handText(c, `ур. ${b.level} · стадия ${b.stage + 1}/${b.def.stages.length}`, VW / 2, by + bh + 16, 14, 'rgba(75,46,30,.8)', 'center', 'rgba(251,243,224,.8)');
      } else {
        c.fillStyle = b.stage >= 2 ? '#ff3b6b' : b.stage === 1 ? '#ff7a2f' : '#e53935';
        c.fillRect(x, y + 13, w * clamp(b.hp / b.maxHp, 0, 1), 11);
        c.fillStyle = '#ffffff';
        for (const st of b.def.stages) if (st.at) c.fillRect(x + w * st.at - 1, y + 11, 2, 15);
        c.font = '900 12px sans-serif'; c.textAlign = 'center'; c.fillStyle = '#ffd25a';
        c.fillText(`${b.name.toUpperCase()} · УР. ${b.level} · СТАДИЯ ${b.stage + 1}/${b.def.stages.length}`, VW / 2, y + 8);
      }
    }
    if (CFG.rush && G.rush && !G.rush.done && !G.activeBoss && G.rush.wait > 0 && state === 'play') {
      const nb = bosses[G.rush.idx];
      if (nb) {
        c.font = '900 16px sans-serif'; c.textAlign = 'center';
        const txt = `Следующий: ${nb.name} через ${Math.ceil(G.rush.wait)}…`;
        c.fillStyle = '#000'; c.fillText(txt, VW / 2 + 1, top + ms + 41); c.fillStyle = '#ffa080'; c.fillText(txt, VW / 2, top + ms + 40);
      }
    }
    if (G.activeShrine) {
      c.font = '900 14px sans-serif'; c.textAlign = 'center'; c.fillStyle = '#000';
      c.fillText(`Испытание: осталось ${G.activeShrine.left}`, VW / 2 + 1, top + ms + 63);
      c.fillStyle = '#ff8a8a'; c.fillText(`Испытание: осталось ${G.activeShrine.left}`, VW / 2, top + ms + 62);
    }
    const joyOn = input.touchId !== null;
    if (joyOn || (JOY.fixed && state === 'play' && !G.cutscene)) { // закреплённый виден всегда, плавающий – пока палец на экране
      const [bx, by] = joyOn ? [input.bx, input.by] : joyBase(), kx = joyOn ? input.mx : 0, ky = joyOn ? input.my : 0;
      if (paperOn) {
        c.fillStyle = `rgba(255,248,230,${joyOn ? 0.22 : 0.14})`; c.strokeStyle = `rgba(75,46,30,${joyOn ? 0.32 : 0.2})`; c.lineWidth = 1.5;
        c.beginPath(); c.arc(bx, by, JOY_R, 0, TAU); c.fill(); c.stroke();
        c.save(); c.shadowColor = 'rgba(80,50,20,.3)'; c.shadowBlur = 6 * DPR; c.shadowOffsetY = 2 * DPR; c.fillStyle = `rgba(255,248,232,${joyOn ? 0.95 : 0.6})`;
        c.beginPath(); c.arc(bx + kx * JOY_R, by + ky * JOY_R, 22 * JOY.k, 0, TAU); c.fill(); c.restore();
      } else {
      c.strokeStyle = `rgba(255,255,255,${joyOn ? 0.35 : 0.22})`; c.lineWidth = 3; c.fillStyle = `rgba(255,255,255,${joyOn ? 0.08 : 0.05})`;
      c.beginPath(); c.arc(bx, by, JOY_R, 0, TAU); c.fill(); c.stroke();
      c.fillStyle = `rgba(255,255,255,${joyOn ? 0.45 : 0.25})`;
      c.beginPath(); c.arc(bx + kx * JOY_R, by + ky * JOY_R, 24 * JOY.k, 0, TAU); c.fill();
      }
    }
    if (G.hintT > 0) {
      c.globalAlpha = clamp(G.hintT, 0, 1);
      c.font = 'bold 15px sans-serif'; c.textAlign = 'center';
      const ht = JOY.fixed ? 'Тяни джойстик, чтобы бежать' : 'Веди пальцем по экрану, чтобы бежать';
      c.fillStyle = '#000'; c.fillText(ht, VW / 2 + 1, VH * 0.72 + 1);
      c.fillStyle = '#fff'; c.fillText(ht, VW / 2, VH * 0.72);
      c.fillStyle = '#000'; c.fillText('Крилесса стреляет перьями сама!', VW / 2 + 1, VH * 0.72 + 23);
      c.fillStyle = '#ffd25a'; c.fillText('Крилесса стреляет перьями сама!', VW / 2, VH * 0.72 + 22);
      c.globalAlpha = 1;
    }
    let ry = top + (paperOn ? 124 : 50);
    c.textAlign = 'left';
    if (G.keys > 0) { c.font = 'bold 13px sans-serif'; c.fillStyle = '#000'; c.fillText('🔑' + G.keys, 13, ry + 14); c.fillStyle = '#ffd25a'; c.fillText('🔑' + G.keys, 12, ry + 13); ry += 22; }
    if (G.cookieT > 0) { const tx = '🍪 ' + Math.ceil(G.cookieT) + 'с'; c.font = 'bold 13px sans-serif'; c.fillStyle = '#000'; c.fillText(tx, 13, ry + 14); c.fillStyle = '#ffd25a'; c.fillText(tx, 12, ry + 13); ry += 22; }
    if (G.wxId && G.wxT > 0) { const tx = { blizzard: '❄️', starfall: '🌠', frost: '🥶' }[G.wxId] + ' ' + Math.ceil(G.wxT) + 'с'; c.font = 'bold 13px sans-serif'; c.fillStyle = '#000'; c.fillText(tx, 13, ry + 14); c.fillStyle = '#d8f2ff'; c.fillText(tx, 12, ry + 13); ry += 22; }
    for (const id of (G.relics || [])) { c.globalAlpha = id === 'phoenix' && G.phoenixUsed ? 0.35 : 1; c.font = '17px sans-serif'; c.fillText(RELICS[id].ic, 14, ry + 15); const L = relicLv(id); if (L > 1) { c.font = 'bold 10px sans-serif'; c.fillStyle = '#000'; c.fillText(L, 34, ry + 19); c.fillStyle = '#ffd25a'; c.fillText(L, 33, ry + 18); } ry += 24; }
    c.globalAlpha = 1;
    if (state === 'play' && !G.activeBoss && !G.activeShrine) {
      let near = false;
      for (const ch of chests) if (!ch.open && ch.glade && !ch.seen && Math.hypot(ch.x - P.x, ch.y - P.y) < 520) { near = true; break; }
      if (near) {
        c.globalAlpha = 0.6 + Math.sin(G.time * 5) * 0.35; c.font = 'bold 12px sans-serif'; c.textAlign = 'center';
        c.fillStyle = '#000'; c.fillText('✨ Где-то рядом сокровище…', VW / 2 + 1, VH * 0.25 + 1); c.fillStyle = '#ffe9a0'; c.fillText('✨ Где-то рядом сокровище…', VW / 2, VH * 0.25);
        c.globalAlpha = 1;
      }
    }
    const nearN = state === 'play' && !G.activeBoss && !!G.nearNpc;
    const nb = $('npcBtn'); if (nb._on !== nearN) { nb._on = nearN; nb.classList.toggle('hidden', !nearN); }
    const nearPortal = state === 'play' && !G.activeBoss && !G.activeShrine && !G.cutscene && !CFG.rush && !!portalHere();
    const pb = $('portalBtn'); if (pb._on !== nearPortal) { pb._on = nearPortal; pb.classList.toggle('hidden', !nearPortal); }
    tdPanelSync();
    const sw = $('swapBtn'), showSw = !!G.team && state === 'play' && !G.cutscene;
    if (sw._on !== showSw) { sw._on = showSw; sw.classList.toggle('hidden', !showSw); }
    if (showSw) {
      const o = teamOther(), f = G.team.f[o], ko = G.team.ko[o] || f < 0.25, cd = G.team.cd > 0;
      const key = o + Math.round(f * 60) + (ko ? 'k' : '') + (cd ? 'c' : '');
      if (sw._k !== key) {
        sw._k = key;
        if (sw._o !== o) { sw._o = o; const sc = $('swapAvatar').getContext('2d'); sc.clearRect(0, 0, 96, 96); sc.drawImage(heroAvatar(o), 0, 0, 96, 96); $('swapName').textContent = '🔄 ' + HEROES[o].name; }
        sw.style.setProperty('--hp', Math.round(f * 360) + 'deg');
        sw.classList.toggle('ko', ko); sw.classList.toggle('cool', cd);
      }
    }
    const dashEl = $('dashBtn');
    const cool = P.dashCd > 0;
    if (cool !== dashEl._cool) { dashEl._cool = cool; dashEl.classList.toggle('cool', cool); }
    const supEl = $('superBtn'), sp = Math.floor(P.sp);
    if (supEl._sp !== sp) {
      supEl._sp = sp;
      supEl.style.setProperty('--sp', (sp * 3.6) + 'deg');
      supEl.classList.toggle('ready', sp >= 100);
      $('superPct').textContent = sp >= 100 ? 'ГОТОВ' : sp + '%';
    }
  }

  // ------------------------------------------------------------------
  //  Управление
  // ------------------------------------------------------------------
  let JOY_R = 55;
  // джойстик: плавающий (появляется под пальцем) или закреплённый на своём месте; размер – 0,8 / 1 / 1,25
  const JOY = { fixed: false, x: 0.25, y: 0.8, k: 1 };
  function applyJoy(js) { Object.assign(JOY, { fixed: false, x: 0.25, y: 0.8, k: 1 }, js || {}); JOY_R = 55 * JOY.k; }
  const joyBase = () => [clamp(JOY.x, 0, 1) * VW, clamp(JOY.y, 0, 1) * VH];
  const input = { mx: 0, my: 0, touchId: null, bx: 0, by: 0, keys: {} };
  canvas.addEventListener('pointerdown', e => {
    Sound.init();
    if (state === 'play' && G.miniRect) {
      const R = G.miniRect, m = MMP.ptrs.size ? 50 : 6; // второй палец может лечь чуть мимо
      if (e.clientX >= R.x - m && e.clientX <= R.x + R.s + m && e.clientY >= R.y - m && e.clientY <= R.y + R.s + m) {
        MMP.ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY });
        try { canvas.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
        if (MMP.ptrs.size === 2) { const [a, b] = [...MMP.ptrs.values()]; MMP.pinch = { d: Math.hypot(a.x - b.x, a.y - b.y) || 1, s: R.s }; MMP.used = true; }
        else if (MMP.ptrs.size === 1) { MMP.used = false; MMP.t0 = performance.now(); }
        return;
      }
    }
    if (state !== 'play' || input.touchId !== null) return;
    if (JOY.fixed) { // закреплённый: слушается только касаний рядом с собой
      const [bx, by] = joyBase();
      if (Math.hypot(e.clientX - bx, e.clientY - by) > JOY_R * 2.4) return;
      input.touchId = e.pointerId; input.bx = bx; input.by = by; joyMove(e.clientX, e.clientY);
    } else { input.touchId = e.pointerId; input.bx = e.clientX; input.by = e.clientY; input.mx = 0; input.my = 0; }
    try { canvas.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
  });
  function joyMove(x, y) {
    let dx = x - input.bx, dy = y - input.by;
    const d = Math.hypot(dx, dy);
    if (d > JOY_R) {
      if (JOY.fixed) { dx = dx / d * JOY_R; dy = dy / d * JOY_R; } // закреплённый стоит на месте
      else { input.bx += (dx / d) * (d - JOY_R); input.by += (dy / d) * (d - JOY_R); dx = x - input.bx; dy = y - input.by; }
    }
    input.mx = dx / JOY_R; input.my = dy / JOY_R;
  }
  canvas.addEventListener('pointermove', e => {
    if (MMP.ptrs.has(e.pointerId)) { // щипок по мини-карте
      MMP.ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (MMP.pinch && MMP.ptrs.size >= 2 && !G.activeBoss) { // пальцы врозь – окно растёт в сторону игры, вместе – меньше
        const [a, b] = [...MMP.ptrs.values()], base = MM2.msBase || 124;
        MM2.sizeF = clamp(MMP.pinch.s * (Math.hypot(a.x - b.x, a.y - b.y) || 1) / MMP.pinch.d, base * 0.8, MM2.msMax || base * 2.5) / VW;
      }
      return;
    }
    if (e.pointerId === input.touchId) joyMove(e.clientX, e.clientY);
  });
  // мини-карта: короткий тап одним пальцем – большая карта, щипок двумя – ближе/дальше
  const MMP = { ptrs: new Map(), pinch: null, used: false, t0: 0 };
  function miniUp(e) {
    if (!MMP.ptrs.has(e.pointerId)) return false;
    MMP.ptrs.delete(e.pointerId);
    if (MMP.pinch && MMP.ptrs.size < 2) { MMP.pinch = null; MM2.relaxAt = performance.now() + 2500; } // подержим 2,5 с – и обратно
    if (!MMP.ptrs.size && !MMP.used && performance.now() - MMP.t0 < 600 && state === 'play') openMap();
    return true;
  }
  const endTouch = e => { if (miniUp(e)) return; if (e.pointerId === input.touchId) { input.touchId = null; input.mx = 0; input.my = 0; } };
  canvas.addEventListener('pointerup', endTouch);
  canvas.addEventListener('pointercancel', endTouch);
  $('dashBtn').addEventListener('pointerdown', e => { e.preventDefault(); e.stopPropagation(); tryDash(); });
  $('superBtn').addEventListener('pointerdown', e => { e.preventDefault(); e.stopPropagation(); trySuper(); });
  $('swapBtn').addEventListener('pointerdown', e => { e.preventDefault(); e.stopPropagation(); switchHero(); });
  $('tdRing').addEventListener('pointerdown', e => { const b = e.target.closest('button'); if (!b) return; e.preventDefault(); e.stopPropagation(); tdPanelTap(b); });
  for (const b of $('tdSpells').children) b.addEventListener('pointerdown', e => { e.preventDefault(); e.stopPropagation(); tdSpellBtn(b.dataset.s); });
  $('defSkip').addEventListener('pointerdown', e => { e.preventDefault(); e.stopPropagation(); if (tdAct('c')) Sound.sfx.click(); });
  { // оборона: короткий тап по площадке выбирает её, даже если героиня далеко
    let tp = null;
    canvas.addEventListener('pointerdown', e => { tp = G.td && state === 'play' ? { id: e.pointerId, x: e.clientX, y: e.clientY, t: performance.now() } : null; });
    canvas.addEventListener('pointerup', e => { if (tp && tp.id === e.pointerId && performance.now() - tp.t < 320 && Math.hypot(e.clientX - tp.x, e.clientY - tp.y) < 12) tdTap(e.clientX, e.clientY); tp = null; });
  }
  $('pauseBtn').addEventListener('click', () => pauseGame(true));
  $('talkTap').addEventListener('pointerdown', e => { e.preventDefault(); Sound.init(); Dialog.advance(); });
  window.addEventListener('keydown', e => {
    if (e.target && e.target.tagName === 'INPUT') return; // ввод пароля – не управление
    if (state === 'play' && Dialog.talking && (e.code === 'Space' || e.code === 'Enter')) { Dialog.advance(); return; }
    input.keys[e.code] = true;
    if (e.code === 'Space' || e.code === 'ShiftLeft') tryDash();
    if (e.code === 'KeyE' || e.code === 'KeyQ') trySuper();
    if (e.code === 'KeyR' || e.code === 'Tab') { e.preventDefault(); switchHero(); }
    if (e.code === 'Escape') { if (state === 'play') pauseGame(); else if (state === 'pause') resumeGame(); }
    if (DEBUG) debugKey(e.code);
  });
  window.addEventListener('keyup', e => { input.keys[e.code] = false; });
  function pollKeys() {
    if (input.touchId !== null) return;
    const k = input.keys;
    const x = (k.KeyD || k.ArrowRight ? 1 : 0) - (k.KeyA || k.ArrowLeft ? 1 : 0);
    const y = (k.KeyS || k.ArrowDown ? 1 : 0) - (k.KeyW || k.ArrowUp ? 1 : 0);
    const m = Math.hypot(x, y) || 1;
    input.mx = x / m; input.my = y / m;
  }

  // ------------------------------------------------------------------
  //  Диалоги и баннеры
  // ------------------------------------------------------------------
  const Dialog = {
    queue: [], cur: null, t: 0, shown: -1,
    get talking() { return !!(this.cur && this.cur.pause); },
    update(dt) {
      if (!this.cur && this.queue.length) {
        this.cur = this.queue.shift(); this.t = 0; this.shown = -1;
        const who = this.cur.who;
        const heroine = who === 'ryzhova' || who === 'krilessa' || who === 'tessa';
        $('dlgName').textContent = who === 'ryzhova' ? 'Рыжовая' : who === 'krilessa' ? 'Крилесса' : who === 'tessa' ? 'Тесса' : BOSSES[who].name;
        $('dialog').classList.toggle('boss', !heroine);
        const dc = $('dlgAvatar').getContext('2d'); dc.clearRect(0, 0, 116, 116);
        if (AVATAR[who]) dc.drawImage(AVATAR[who], 0, 0, 116, 116);
        $('dialog').classList.remove('hidden');
        // речь босса: игра на паузе, пока не коснёшься экрана
        $('dialog').classList.toggle('wait', !!this.cur.pause);
        $('talkTap').classList.toggle('hidden', !this.cur.pause);
        if (this.cur.pause) { input.touchId = null; input.mx = 0; input.my = 0; }
      }
      if (!this.cur) return;
      this.t += dt;
      const n = Math.min(this.cur.text.length, Math.floor(this.t * 42));
      if (n !== this.shown) { this.shown = n; $('dlgText').textContent = this.cur.text.slice(0, n); }
      if (!this.cur.pause && this.t > this.cur.dur) this.close();
    },
    advance() {
      if (!this.cur) return;
      if (this.shown < this.cur.text.length) { this.t = 99; this.shown = this.cur.text.length; $('dlgText').textContent = this.cur.text; return; }
      this.close();
    },
    close() { this.cur = null; $('dialog').classList.add('hidden'); $('talkTap').classList.add('hidden'); },
    clear() { this.queue.length = 0; this.close(); },
  };
  function say(text, dur) { if (!text) return; Dialog.queue.push({ text, who: CFG.hostage || 'ryzhova', dur: dur || Math.max(3.2, text.length * 0.06) }); }
  function speak(kind, text, dur, pause = true) {
    if (!text) return;
    if (NET.host && G.netRun) NetT.send(-1, { t: 'spk', k: kind, text, d: dur || 0 });
    if (!AVATAR[kind]) AVATAR[kind] = BOSSES[kind].avatar ? AVATAR[BOSSES[kind].avatar] : bossPortrait(kind);
    // реплики босса показываем сразу, героиня подождёт
    if (G.td) pause = false; // в обороне речь босса идёт сама, игру не останавливает
    Dialog.queue.unshift({ text, who: kind, dur: dur || Math.max(3.4, text.length * 0.065), pause });
    if (Dialog.cur && (Dialog.cur.who === 'ryzhova' || Dialog.cur.who === 'krilessa' || Dialog.cur.who === 'tessa')) Dialog.queue.push(Dialog.cur);
    Dialog.cur = null;
  }
  let bannerTimer = 0;
  function showBanner(big, sub) {
    const el = $('banner');
    $('bannerBig').textContent = big; $('bannerSub').textContent = sub || '';
    el.classList.remove('hidden', 'show'); void el.offsetWidth; el.classList.add('show');
    clearTimeout(bannerTimer); bannerTimer = setTimeout(() => el.classList.add('hidden'), 2700);
  }

  // ------------------------------------------------------------------
  //  Экраны
  // ------------------------------------------------------------------
  const screens = ['boot', 'intro', 'menu', 'levelup', 'pause', 'dead', 'victory', 'stats', 'whatsnew', 'teaser', 'zmenu', 'portal', 'choice', 'board', 'npc', 'wardrobe', 'mapscr', 'intros', 'relic', 'talents', 'admin', 'chapSheet', 'settings', 'splash', 'krill', 'joyedit', 'mp', 'modes', 'coll', 'ach', 'book', 'muts', 'hall', 'look', 'season', 'relics', 'home'];
  function setState(s) {
    const prev = state;
    state = s;
    for (const n of screens) $(n).classList.toggle('hidden', n !== s && !(s === 'chapSheet' && n === 'menu')); // карточка главы – поверх карты
    $('hud').classList.toggle('hidden', s !== 'play');
    $('talkTap').classList.toggle('hidden', !(s === 'play' && Dialog.talking));
    $('dialog').classList.toggle('offscreen', s !== 'play' && s !== 'dying'); // диалог не висит поверх меню и карты
    if (s !== 'play') { input.touchId = null; input.mx = 0; input.my = 0; }
    // вернулись в настройки (из «Что нового», статистики, меню) – кровь течёт дальше
    if (s === 'settings' && prev !== 'settings') { notifyLabel(); orientLabel(); vibLabel(); if (!Blood.resume()) paintDiff(false); }
    if (s !== 'play' && !$('rotHint').classList.contains('hidden')) rotHintHide();
    if (paperOn && !PAPER_SKIP.has(s)) paperScreen(s);
  }
  // ===== 1.0: тёмные плашки любых экранов становятся бумажными =====
  // экраны рисуются в разных местах кода; вместо правки каждого – после показа проходим по элементам:
  // тёмный фон → бумага с чернильной обводкой, светлый текст на бумаге → чернила. Перерисовка экрана – проходим снова
  const PAPER_SKIP = new Set(['play', 'dying', 'splash', 'intro', 'menu', 'krill', 'zmenu', 'boot', 'teaser', 'pause', 'chapSheet', 'whatsnew', 'talents', 'modes', 'coll', 'mp', 'levelup', 'portal', 'muts']);
  const PAPER_OBS = new Map();
  const rgbOf = str => { const m = /rgba?\(([\d.]+),\s*([\d.]+),\s*([\d.]+)(?:,\s*([\d.]+))?/.exec(str || ''); return m ? [+m[1], +m[2], +m[3], m[4] === undefined ? 1 : +m[4]] : null; };
  const lum = c => (0.3 * c[0] + 0.59 * c[1] + 0.11 * c[2]) / 255;
  function darkBg(cs) {
    const bc = rgbOf(cs.backgroundColor); if (bc && bc[3] > 0.35 && lum(bc) < 0.42) return true;
    const bi = cs.backgroundImage; if (!bi || bi === 'none' || bi.includes('url(')) return false;
    const cols = [...bi.matchAll(/rgba?\([^)]+\)/g)].map(m => rgbOf(m[0])).filter(c => c && c[3] > 0.35);
    return cols.length > 0 && cols.reduce((a, c) => a + lum(c), 0) / cols.length < 0.42;
  }
  function paperize(root) {
    const rcs = getComputedStyle(root);
    if (!root.classList.contains('dim') && darkBg(rcs)) { root.style.background = 'radial-gradient(ellipse at 50% 10%, rgba(251,243,224,.97), rgba(232,214,178,.98) 80%)'; root.style.color = '#4b2e1e'; }
    const light = new Set([root.classList.contains('dim') ? null : root]);
    for (const el of root.querySelectorAll('*')) {
      if (el.tagName === 'CANVAS' || el.tagName === 'svg' || el.closest('svg') || el.classList.contains('btn')) continue;
      const cs = getComputedStyle(el);
      if (darkBg(cs)) {
        el.style.background = '#fffaf0'; el.style.color = '#4b2e1e';
        if (parseFloat(cs.borderTopWidth) > 0) el.style.borderColor = '#4b2e1e'; else if (parseFloat(cs.paddingTop) > 3) el.style.border = '1.5px solid rgba(75,46,30,.8)';
        el.style.boxShadow = '0 3px 0 rgba(75,46,30,.35)'; el.style.textShadow = 'none'; light.add(el);
      }
    }
    for (const el of root.querySelectorAll('*')) { // светлый текст на светлом фоне – в чернила
      if (el.tagName === 'CANVAS' || el.classList.contains('btn')) continue;
      let p = el, onLight = false; while (p && p !== root.parentNode) { if (light.has(p)) { onLight = true; break; } const bc = rgbOf(getComputedStyle(p).backgroundColor); if (bc && bc[3] > 0.5) { onLight = lum(bc) > 0.6; break; } p = p.parentElement; }
      if (!onLight) continue;
      const cs = getComputedStyle(el), tc = rgbOf(cs.color);
      if (tc && lum(tc) > 0.72 && el.childNodes.length && [...el.childNodes].some(n => n.nodeType === 3 && n.textContent.trim())) { el.style.color = lum(tc) > 0.9 ? '#4b2e1e' : '#8a3a1a'; el.style.textShadow = 'none'; }
    }
  }
  function paperScreen(id) {
    const root = $(id); if (!root) return;
    try { paperize(root); } catch (e) {}
    if (!PAPER_OBS.has(id) && window.MutationObserver) {
      let tm = 0; const ob = new MutationObserver(() => { if (tm) return; tm = setTimeout(() => { tm = 0; if (state === id) { ob.disconnect(); try { paperize(root); } catch (e) {} ob.observe(root, { childList: true, subtree: true }); } }, 30); });
      ob.observe(root, { childList: true, subtree: true }); PAPER_OBS.set(id, ob);
    }
  }
  function openLevelUp() {
    if (G.pendingLv <= 0) return;
    buzz(25);
    setState('levelup');
    Sound.sfx.level();
    // три обычных варианта + особое улучшение главы отдельным слотом (не вытесняет основные)
    const avail = UPGRADES.filter(u => lv(u.id) < u.max && !u.ch), spec = UPGRADES.filter(u => lv(u.id) < u.max && u.ch && u.ch === CHN && !G.rush);
    const opts = [];
    while (opts.length < (talent('pick4') ? 4 : 3) && avail.length) opts.push(avail.splice(Math.floor(Math.random() * avail.length), 1)[0]);
    const extra = spec.length ? spec[Math.floor(Math.random() * spec.length)] : null;
    const evo = EVOS.find(e => !lv(e.id) && e.need.every(([k, n]) => lv(k) >= n)) || null; // эволюция готова – отдельная карточка сверху
    $('lvHint').textContent = (G.freePicks > 0 ? '🎁 Стартовый набор · ' : '') + (G.pendingLv > 1 ? `Выбери улучшение (ещё ${G.pendingLv})` : 'Выбери улучшение');
    const box = $('cards'); box.innerHTML = ''; box.classList.toggle('four', opts.length > 3);
    const mk = (u, i) => {
      const el = document.createElement('button');
      el.className = 'card' + (u.ch ? ' special' : '') + (u.need ? ' evo' : ''); el.style.animationDelay = (i * 0.07) + 's';
      const ov = HEROES[P.hero].names[u.id];
      const ic = ov ? ov[0] : u.ic, nm = ov ? ov[1] : u.nm, ds = ov ? ov[2] : u.ds;
      el.innerHTML = `<div class="ic">${ic}</div><div><div class="nm">${nm}</div><div class="ds">${ds}</div><div class="lv">${u.need ? '✨ Эволюция · ' + u.need.map(([k]) => upName(k)).join(' + ') : `Уровень ${lv(u.id)} → ${lv(u.id) + 1}`}</div></div>`;
      el.dataset.id = u.id;
      el.addEventListener('click', () => {
        P.up[u.id] = lv(u.id) + 1;
        if (G.st) G.st.ups.push(u.id);
        if (G.freePicks > 0) G.freePicks--;
        if (u.id === 'hp') P.hp = Math.min(P.maxHp + 30, P.hp + 30 + P.maxHp * 0.2);
        if (u.need) evoGot(u);
        computeStats();
        Sound.sfx.click();
        G.pendingLv--;
        saveGame();
        if (G.pendingLv > 0) openLevelUp(); else setState('play');
      });
      box.appendChild(el);
    };
    if (evo) {
      const dv = document.createElement('div'); dv.className = 'spDiv evoDiv'; dv.innerHTML = '<span>🌈 Эволюция готова!</span>'; box.appendChild(dv);
      mk(evo, 0);
      const d2 = document.createElement('div'); d2.className = 'spDiv'; d2.innerHTML = '<span>или обычное улучшение</span>'; box.appendChild(d2);
    }
    opts.forEach((u, i) => mk(u, i + (evo ? 1 : 0)));
    if (extra) {
      const dv = document.createElement('div'); dv.className = 'spDiv'; dv.style.animationDelay = (opts.length * 0.07) + 's';
      dv.innerHTML = '<span>✨ или особое – только в этой главе</span>'; box.appendChild(dv);
      mk(extra, opts.length + 1);
    }
    if (!opts.length && !extra && !evo) { G.pendingLv = 0; P.hp = P.maxHp; setState('play'); }
  }
  const upName = k => { const ov = HEROES[P.hero] && HEROES[P.hero].names[k]; const u = UPGRADES.find(x => x.id === k); return ov ? ov[1] : u ? u.nm : k; };
  function evoGot(e) {
    const pr = loadProfile(); pr.evoSeen = pr.evoSeen || {}; const first = !pr.evoSeen[e.id];
    if (first) pr.evoSeen[e.id] = Date.now(); saveProfile(pr);
    life('evos'); setTimeout(() => { showBanner(`${e.ic} ${e.nm}!`, first ? 'Новая эволюция – она теперь в Кринжопедии' : e.ds); }, 150);
    Sound.sfx.win(); buzz(120); burst(P.x, P.y, 50, '#fff3a0', 260); shockRing(P.x, P.y, '#ff8ad8', 260);
  }
  function pauseGame(shared, byName) {
    if (state !== 'play') return;
    $('pauseStats').innerHTML =
      (defOn() ? `<b>🛡️ Оборона: ${TD_MAP_BY[G.abyss.map].nm}</b> · волна ${G.abyss.wave} · 💎 ${G.core.hp} · 🪙 ${G.abyss.coins}` : `<b>Глава ${CHN}: ${CFG.name}</b>`) + ` · ${HEROES[P.hero].name}<br>` +
      `❤️ HP ${Math.ceil(P.hp)}/${P.maxHp} · 🪶 урон ${Math.round(P.dmg)} · 💨 ${(1 / P.fireInt).toFixed(1)} выстр/с<br>` +
      `🎯 крит ${Math.round(P.crit * 100)}% (x${P.critMul.toFixed(2)}) · 🛡️ броня ${Math.round(P.armor * 100)}%<br>` +
      `💎 осколков ${P.shards} · ☠️ врагов ${G.kills} · 🔥 лучшее комбо ${G.bestCombo}<br>` +
      `🔑 ключей ${G.keys || 0}` + ((G.relics || []).length ? ' · ' + G.relics.map(id => RELICS[id].ic + ' ' + RELICS[id].name).join(', ') : '') + '<br>' +
      `🗺️ карта #${SEED % 10000} · 🌟 супер ${Math.floor(P.sp)}% · ⚖️ зона: ур. ${zoneE(biomeMap[clamp(Math.floor(P.y / T), 0, MH - 1) * MW + clamp(Math.floor(P.x / T), 0, MW - 1)])}`;
    $('pause').classList.add('quick'); kickListSync();
    if (shared === true && NET.on && G.netRun && !NET.paused) netPause(1);
    $('pauseNote').textContent = NET.on && G.netRun ? (NET.paused ? `⏸ ${byName || 'Ты'} – пауза у всех. Коснись, чтобы продолжить` : '⏸ Вместе мир не замирает – друзья играют дальше') : '⏸ Игра стоит. Коснись, чтобы продолжить';
    setState('pause'); Sound.sfx.click();
  }
  function resumeGame(fromNet) { if (fromNet !== true && NET.on && G.netRun && NET.paused) netPause(0); setState('play'); }
  // общая пауза вместе: любой игрок ставит игру на паузу у всех, любой снимает. Хозяин рассылает решение всем
  function netPause(v) {
    if (!NET.on || !G.netRun) return;
    const by = NET.name || 'Игрок';
    if (NET.host) { netPauseApply(v, by); NetT.send(-1, { t: 'pz', v: v ? 1 : 0, by }); }
    else { NET.paused = !!v; NET.pauseBy = by; NetT.send(0, { t: 'pz', v: v ? 1 : 0, by }); }
  }
  function netPauseApply(v, by) {
    NET.paused = !!v; NET.pauseBy = by;
    if (v) { if (state === 'play') pauseGame(false, by); else if (state === 'pause') $('pauseNote').textContent = `⏸ ${by} – пауза у всех. Коснись, чтобы продолжить`; }
    else if (state === 'pause') { setState('play'); toast(`▶ ${by} продолжила игру`); }
  }
  $('btnPauseMore').addEventListener('click', () => { $('pause').classList.remove('quick'); Sound.init(); Sound.sfx.click(); });
  $('pause').addEventListener('pointerdown', e => { if (e.target === $('pause') && $('pause').classList.contains('quick') && state === 'pause') resumeGame(); });
  function playerDied() {
    burst(P.x, P.y, 40, '#c9b3ff', 260); buzz(260); life('deaths');
    if (G.abyss) { if (G.abyss.def) defFinish(); else abyssFinish(); }
    if (G.daily) dailyFinish(false);
    if (G.st) { G.st.deaths++; if (G.st.cur) G.st.cur.d++; }
    if (G.rush) rushFinish(false);
    setTimeout(() => {
      const R = G.rush;
      $('deadTitle').textContent = R ? 'Босс-раш окончен' : G.team ? 'Обе героини без сил…' : `${HEROES[P.hero].name} без сил…`;
      $('deadText').innerHTML = R ? `Побеждено боссов: <b>${R.idx}/${R.total}</b> за ${fmtT(R.t)}${R.better ? '<br>🏆 Новый рекорд!' : ''}`
        : CFG.deadText ? CFG.deadText : (CHN === 3 ? 'Крилесса всё ещё ждёт!' : 'Рыжовая всё ещё ждёт!') + ' Попробуй снова –<br>уровень и улучшения сохранятся.';
      if (G.abyss && G.abyss.def) { $('deadTitle').textContent = '💎 Оборона окончена'; $('deadText').innerHTML = `Отбито волн: <b>${G.abyss.cleared || 0}</b>`; }
      else if (G.abyss) { const ab = loadProfile().abyssBest; $('deadTitle').textContent = `🕳️ Бездна: волна ${G.abyss.wave}`; $('deadText').innerHTML = `Продержалась ${fmtT(G.abyss.t)}, врагов: ${G.kills}` + (G.abyss.better ? '<br>🏆 Новый рекорд!' : ab ? `<br>Рекорд: волна ${ab.wave}` : ''); }
      if (G.daily) { $('deadTitle').textContent = '📅 Испытание дня'; $('deadText').innerHTML = `Очков: <b>${fmtN(G.daily.score)}</b> · лучший сегодня: ${fmtN(G.daily.best || 0)}<br>Можно попробовать ещё раз!`; }
      setState('dead');
    }, 700);
    state = 'dying';
  }
  function respawn() {
    if (G.abyss && G.abyss.def) { if (NET.on && G.netRun) { if (NET.host) mpGo(); else toast('Заново начнёт хозяйка 🏠'); return; } startDefense(G.abyss.map); return; }
    if (CFG.abyss) { startAbyss(); return; }
    if (G.daily) { startDaily(); return; }
    if (G.rush) { if (NET.on && G.netRun) { if (NET.host) mpGo(); else toast('Заново начнёт хозяйка 🏠'); return; } startRush(); return; }
    if (G.finalFinal) {
      // подлянка: бой с бессмертным начинается заново
      G.finalFinal.t = 0; G.finalFinal.bank = 0; G.finalFinal.said = {};
      G.enemies.length = 0; G.ebullets.length = 0; G.hazards.length = 0; G.feathers.length = 0; G.beams.length = 0;
      P.x = G.cp.x; P.y = G.cp.y; P.hp = P.maxHp; P.inv = 2.5; P.dashT = 0; P.slowT = 0;
      Dialog.clear(); say('Я с тобой, Рыжовая! Ещё раз – вместе!');
      setState('play');
      return;
    }
    for (const b of bosses) if (b.state === 'fight') resetBoss(b);
    for (const ch of chests) if (ch.mimic && ch.open && !ch.mimicDone) ch.open = false; // мимик снова прячется
    G.activeBoss = null;
    if (G.activeShrine) { G.activeShrine.state = 'idle'; G.activeShrine = null; }
    // чемпион не исчезает после смерти героини: остаётся на карте с тем же здоровьем
    const champ = G.champ && !G.champ.dead && G.enemies.includes(G.champ) ? G.champ : null;
    G.enemies.length = 0; G.ebullets.length = 0; G.hazards.length = 0; G.feathers.length = 0; G.beams.length = 0;
    if (champ) {
      const d = Math.hypot(champ.x - G.cp.x, champ.y - G.cp.y);
      // не караулит у точки возрождения, но и не теряется далеко – ждёт в паре экранов (корона на карте)
      if (d < 520 || d > 1600) {
        const base = Math.atan2(champ.y - G.cp.y, champ.x - G.cp.x), R = d < 520 ? 620 : 900;
        for (let k = 0; k < 32; k++) {
          const a = base + (k ? rnd(-1.6, 1.6) : 0), x = G.cp.x + Math.cos(a) * R, y = G.cp.y + Math.sin(a) * R;
          if (walkable(x, y, !!champ.def.fly) && y < PLAY_H * T) { champ.x = x; champ.y = y; break; }
        }
      }
      champ.jd = 0; champ.wind = 0; champ.slowT = 0; champ.burnT = 0;
      G.enemies.push(champ);
    }
    P.x = G.cp.x; P.y = G.cp.y; P.hp = P.maxHp; P.inv = 2; P.dashT = 0; P.slowT = 0; P.lives = HEROES[P.hero].lives || 0; G.invertT = 0; G.staticT = 0; G.jump = null; P.z = 0;
    G.combo = 0;
    if (talent('super')) P.sp = Math.max(P.sp, 25 * talent('super'));
    if (G.team) { for (const id of G.team.list) { G.team.f[id] = 1; G.team.ko[id] = false; } G.team.bx = P.x; G.team.by = P.y; }
    if (G.tessaAlly && !CFG.tessaStart) { G.tessaAlly = null; G.pet = null; } // бой с Мраком заново – Тесса снова во льду
    G.blizzardT = 0; G.wxId = null; G.wxT = 0; G.falling = []; G.chill = 0;
    Dialog.clear(); say(`Я жду тебя, ${HEROES[P.hero].name}! Не сдавайся!`);
    setState('play');
    biomeMusic(true);
  }
  function showVictory(mode) {
    if (mode === 'daily') { Dialog.clear(); $('victoryButtons').classList.remove('hidden'); victoryExtras('daily'); setState('victory'); return; }
    showVictory0(mode); victoryExtras(mode);
  }
  function showVictory0(mode) {
    Dialog.clear();
    $('victoryButtons').classList.remove('hidden');
    if (mode === 'rush') {
      const R = G.rush, vc0 = $('victoryPortrait').getContext('2d');
      vc0.clearRect(0, 0, 300, 300); vc0.drawImage(heroPortrait(P.hero, 300), 0, 0, 300, 300);
      $('victoryTitle').textContent = '⚔️ Босс-раш пройден!';
      $('victoryStats').innerHTML = `Все <b>${R.total}</b> боссов за <b>${fmtT(R.t)}</b>${R.better ? '<br>🏆 Новый рекорд!' : ''}`;
      $('victoryNext').classList.add('hidden'); $('victoryTeaser').classList.add('hidden');
      setState('victory');
      return;
    }
    if (CHN === 7) {
      const v7 = $('victoryPortrait').getContext('2d'); v7.clearRect(0, 0, 300, 300);
      v7.drawImage(heroPortrait('krilessa', 300), 0, 0, 300, 300);
      const small7 = (img, x, y, col) => { if (!img) return; v7.save(); v7.beginPath(); v7.arc(x, y, 46, 0, TAU); v7.clip(); v7.drawImage(img, x - 46, y - 46, 92, 92); v7.restore(); v7.strokeStyle = col; v7.lineWidth = 5; v7.beginPath(); v7.arc(x, y, 46, 0, TAU); v7.stroke(); };
      small7(AVATAR.ryzhova, 56, 245, '#ff7a2f'); small7(AVATAR.tessa, 245, 245, '#6ae0ff');
      const m7 = Math.floor(G.time / 60), s7 = Math.floor(G.time % 60), got = pearls.filter(q => q.got).length;
      $('victoryTitle').textContent = 'Крилюбовь победила!';
      $('victoryStats').innerHTML = 'Крильятин сдулся и признался: он просто хотел, чтобы его <b>крилюбили</b>. 🦐💗<br>Теперь он краснеет не от злости, а от смущения.<br>' +
        `Слов найдено: <b>${got}/${pearls.length}</b> · Время: <b>${m7}:${String(s7).padStart(2, '0')}</b> · Уровень: <b>${P.level}</b> · Врагов: <b>${G.kills}</b>`;
      $('victoryTeaser').innerHTML = CHAPTERS[8] ? 'Глава 8 открыта!' : '…а глава 8 уже строится. Скоро! 🚧';
      $('victoryNext').classList.toggle('hidden', !CHAPTERS[8]); $('victoryNext').textContent = 'Глава 8 →';
      $('victoryTeaser').classList.remove('hidden');
      setState('victory'); Sound.music('truewin');
      return;
    }
    if (CHN === 6) {
      const v6 = $('victoryPortrait').getContext('2d'); v6.clearRect(0, 0, 300, 300);
      v6.drawImage(heroPortrait('krilessa', 300), 0, 0, 300, 300);
      const small6 = (img, x, y, col) => { if (!img) return; v6.save(); v6.beginPath(); v6.arc(x, y, 46, 0, TAU); v6.clip(); v6.drawImage(img, x - 46, y - 46, 92, 92); v6.restore(); v6.strokeStyle = col; v6.lineWidth = 5; v6.beginPath(); v6.arc(x, y, 46, 0, TAU); v6.stroke(); };
      small6(AVATAR.ryzhova, 56, 245, '#ff7a2f'); small6(AVATAR.tessa, 245, 245, '#bfeaff');
      const m6 = Math.floor(G.time / 60), s6 = Math.floor(G.time % 60);
      $('victoryTitle').textContent = 'Зима отступила!';
      $('victoryStats').innerHTML = 'Лёд растаял, Тесса на свободе, лето вернулось. ☀️<br>Мрак оттаял и впервые улыбнулся. Но его последние слова не дают покоя…<br>' +
        `Время: <b>${m6}:${String(s6).padStart(2, '0')}</b> · Уровень: <b>${P.level}</b> · Врагов: <b>${G.kills}</b>`;
      $('victoryTeaser').innerHTML = '…где-то далеко стало подозрительно тихо. 🤫' + (CHAPTERS[7] ? '<br>Глава 7 открыта!' : '');
      $('victoryNext').classList.toggle('hidden', !CHAPTERS[7]); $('victoryNext').textContent = 'Глава 7 →';
      $('victoryTeaser').classList.remove('hidden');
      setState('victory'); Sound.music('truewin');
      return;
    }
    if (CHN === 4 || CHN === 5) {
      const vc4 = $('victoryPortrait').getContext('2d'); vc4.clearRect(0, 0, 300, 300);
      vc4.drawImage(AVATAR.tessaBig || heroPortrait('tessa', 300), 0, 0, 300, 300);
      const small = (img, x, y, col) => { if (!img) return; vc4.save(); vc4.beginPath(); vc4.arc(x, y, 44, 0, TAU); vc4.clip(); vc4.drawImage(img, x - 44, y - 44, 88, 88); vc4.restore(); vc4.strokeStyle = col; vc4.lineWidth = 5; vc4.beginPath(); vc4.arc(x, y, 44, 0, TAU); vc4.stroke(); };
      const mm = Math.floor(G.time / 60), ss = Math.floor(G.time % 60);
      const statLine = `Время: <b>${mm}:${String(ss).padStart(2, '0')}</b> · Уровень: <b>${P.level}</b> · Врагов: <b>${G.kills}</b>`;
      if (CHN === 4) {
        small(AVATAR.glitchcat, 245, 245, mode === 'kind' ? '#ff6fb5' : '#3ff0a0');
        $('victoryTitle').textContent = mode === 'kind' ? 'Мяу.exe приручён!' : 'Дом спасён!';
        $('victoryStats').innerHTML = (mode === 'kind' ? 'Тесса не стала удалять вирус. Она просто потёрлась о него носом…<br>Мяу.exe впервые замурлыкал. <b>Добрая</b> кошка. 💗<br>'
          : 'Тесса удалила Мяу.exe. Лампочки больше не мигают, телевизор молчит.<br><b>Хорошая</b> кошка. 🛡️<br>') + statLine;
        $('victoryTeaser').innerHTML = '…а утром из всех мисок пропал корм. 🐟<br>Глава 5 открыта!';
      } else {
        small(ART.zyamaFace, 56, 245, '#ffd25a'); small(heroPortrait('krilessa', 88), 245, 245, '#bfeaff'); small(AVATAR.ryzhova, 245, 56, '#ff7a2f');
        $('victoryTitle').textContent = 'Банкет!';
        $('victoryStats').innerHTML = 'Дело раскрыто: корм спрятал Зямочкккк – для банкета в честь Тессы!<br>Пришли все: Крилесса, Рыжовая, Пик, Гуля, Шуршик и даже Барон. 🎉<br>' + statLine;
        $('victoryTeaser').innerHTML = CHAPTERS[6] ? '…а ночью выпал снег. Посреди лета. ❄️<br>Глава 6 открыта!' : 'Продолжение следует… 🐾';
      }
      $('victoryNext').classList.toggle('hidden', !CHAPTERS[CHN + 1]);
      $('victoryNext').textContent = `Глава ${CHN + 1} →`;
      $('victoryTeaser').classList.remove('hidden');
      setState('victory'); Sound.music(CHN === 5 ? 'final5' : 'truewin');
      return;
    }
    const vc = $('victoryPortrait').getContext('2d');
    vc.clearRect(0, 0, 300, 300);
    if (AVATAR.ryzhovaBig) vc.drawImage(AVATAR.ryzhovaBig, 0, 0, 300, 300);
    if (CHN === 3) {
      vc.clearRect(0, 0, 300, 300);
      if (AVATAR.ryzhovaBig) vc.drawImage(AVATAR.ryzhovaBig, 0, 0, 300, 300);
      const kp = heroPortrait('krilessa', 120);
      vc.save(); vc.beginPath(); vc.arc(62, 238, 56, 0, TAU); vc.clip(); vc.drawImage(kp, 2, 178, 120, 120); vc.restore();
      vc.strokeStyle = '#bfeaff'; vc.lineWidth = 5; vc.beginPath(); vc.arc(62, 238, 56, 0, TAU); vc.stroke();
    }
    if (CHN >= 2 && ART.zyamaFace) {
      vc.save(); vc.beginPath(); vc.arc(240, 240, 52, 0, TAU); vc.clip(); vc.drawImage(ART.zyamaFace, 188, 188, 104, 104); vc.restore();
      vc.strokeStyle = '#ff3ea5'; vc.lineWidth = 5; vc.beginPath(); vc.arc(240, 240, 52, 0, TAU); vc.stroke();
      const em = emojiSprite(mode === 'true' ? '❤️' : '😭', 30); vc.drawImage(em, 250, 160, 50, 50);
    }
    const m = Math.floor(G.time / 60), s = Math.floor(G.time % 60);
    $('victoryTitle').textContent = ['', 'Рыжовая спасена!', 'Рыжовая снова свободна!', 'Крилесса спасена!'][CHN];
    $('victoryStats').innerHTML = [
      '', 'Крилесса освободила Рыжовую из Тёмного замка!<br>',
      'Зямочкккк повержен! (Но обещал вернуться в версии 0.03…)<br>',
      'Рыжовая разбила Зеркальный дворец и спасла подругу!<br>Зямочкккк попросил у неё автограф 🥲 Конец трилогии… или нет? 👀<br>'][CHN] +
      `Время: <b>${m}:${String(s).padStart(2, '0')}</b> · Уровень: <b>${P.level}</b> · Врагов: <b>${G.kills}</b> · Осколков: <b>${P.shards}</b>`;
    $('victoryNext').classList.toggle('hidden', CHN >= 3 && !(CHN === 3 && mode === 'true'));
    $('victoryTeaser').classList.toggle('hidden', CHN >= 3);
    $('victoryNext').textContent = `Глава ${CHN + 1} →`;
    $('victoryTeaser').innerHTML = CHN === 1 ? '…но в небе уже открылся кринжовый портал.<br>Глава 2 открыта!'
      : '…Зямочкккк сдержал слово и вернулся в 0.03!<br>Глава 3 открыта – играешь за Рыжовую! 🔥';
    if (mode === 'true') {
      $('victoryTitle').textContent = 'НАСТОЯЩАЯ ПОБЕДА!';
      $('victoryStats').innerHTML = 'Рыжовая и Крилесса вместе одолели Зямочкккк ∞!<br>Он поклонился, сказал «браво» и ушёл пить какао ❤️<br><b>Трилогия завершена!</b><br>' +
        `Время: <b>${m}:${String(s).padStart(2, '0')}</b> · Уровень: <b>${P.level}</b> · Врагов: <b>${G.kills}</b>`;
      $('victoryTeaser').innerHTML = '…но кто это мурлычет в темноте? 🐾<br>Глава 4 открыта – играешь за Тессу!';
      $('victoryTeaser').classList.remove('hidden');
    }
    setState('victory');
    if (CHN === 3 && !mode && !G.trueWin && !NET.on) { $('victoryButtons').classList.add('hidden'); later(4800, startTrick); }
  }

  // ------------------------------------------------------------------
  //  Сохранения
  // ------------------------------------------------------------------
  const PROFILE_KEY = 'krilessa_profile_v2';
  const saveKey = ch => 'krilessa_save_v2_ch' + ch;
  function loadProfile() { try { return JSON.parse(localStorage.getItem(PROFILE_KEY)) || {}; } catch (e) { return {}; } }
  function saveProfile(p) { try { localStorage.setItem(PROFILE_KEY, JSON.stringify(p)); } catch (e) { /* ignore */ } }
  // ===== сохранение игры вместе: потом можно продолжить с теми же подругами =====
  const COOP_KEY = 'krilessa_coop', COOP_ME = 'krilessa_coop_me';
  function coopLoad(k) { try { return JSON.parse(localStorage.getItem(k) || 'null'); } catch (e) { return null; } }
  function coopSave() {
    if (!NET.on || !G.netRun || typeof NET.ch !== 'number' || CFG.rush || CFG.abyss || !NET.coopId) return;
    if (state === 'menu' || state === 'intro' || G.cutscene || !bosses.length) return;
    try {
      if (G.defeated[bosses.length - 1] || G.finalFinal) { localStorage.removeItem(NET.host ? COOP_KEY : COOP_ME); return; } // глава пройдена – сохранение не нужно
      const mine = { v: 1, id: NET.coopId, ch: CHN, level: P.level, xp: P.xp, up: P.up, bonus: P.bonus, shards: P.shards, hero: P.hero, at: Date.now() };
      if (NET.host) localStorage.setItem(COOP_KEY, JSON.stringify(Object.assign(mine, { seed: SEED, diff: NET.diff, defeated: G.defeated, ml: G.melted || [], cp: G.cp, kills: G.kills, time: G.time,
        chests: chests.map(c => c.open && (!c.mimic || c.mimicDone) ? 1 : 0), keys: G.keys || 0, names: NET.roster.filter(r => r.id !== 1).map(r => r.name) })));
      else localStorage.setItem(COOP_ME, JSON.stringify(mine));
    } catch (e) { /* ignore */ }
  }
  function coopApplyMine(me) { // своя прокачка из сохранения
    if (!me) return;
    P.level = me.level || P.level; P.xp = me.xp || 0; P.xpNext = xpFor(P.level); P.up = me.up || {}; P.bonus = me.bonus || {}; P.shards = me.shards || 0; G.pendingLv = 0;
    computeStats(); P.hp = P.maxHp;
  }
  function coopApplyWorld(r) { // мир из сохранения хозяйки: побеждённые стражи, растаявший лёд, место
    if (!r) return;
    if (r.df) G.defeated = CFG.bosses.map((_, i) => !!r.df[i]);
    if (r.ml && r.ml.length) { NET.applyMelt = true; for (const i of r.ml) meltTile(i, false); NET.applyMelt = false; }
    (r.ch || []).forEach((o, i) => { if (chests[i] && o) { chests[i].open = true; if (chests[i].mimic) chests[i].mimicDone = true; } });
    if (r.cp) { G.cp = r.cp; P.x = r.cp.x + rnd(-30, 30); P.y = r.cp.y + rnd(-30, 30); ensureWalkable(P); updateCamera(); }
    gateOpen = guardiansDone() >= guardiansCount();
  }
  function loadSave(ch) { try { const s = localStorage.getItem(saveKey(ch)); return s ? JSON.parse(s) : null; } catch (e) { return null; } }
  function saveGame() {
    if (NET.on) { coopSave(); return; } // вместе – своё сохранение (у хозяйки – мир, у каждой – её прокачка)
    if (CFG.rush || CFG.abyss || G.daily || G.finalFinal) return; // Бездна и испытание дня не сохраняются
    if (state === 'menu' || state === 'intro' || state === 'boot') return;
    if (G.cutscene || !bosses.length || G.defeated[bosses.length - 1]) return;
    const data = { v: 5, defeated: G.defeated, level: P.level, xp: P.xp, up: P.up, bonus: P.bonus, shards: P.shards, cp: G.cp, sp: P.sp,
      kills: G.kills, time: G.time, bestCombo: G.bestCombo, chests: chests.map(c => c.open && (!c.mimic || c.mimicDone) ? 1 : 0), cs: chests.map(c => c.seen ? 1 : 0), keys: G.keys || 0, ph: !!G.phoenixUsed, sw: !!G.secondUsed, shrines: shrines.map(s => s.state === 'done' ? 1 : 0),
      st: G.st, lowHp: G.lowHpSaid, calm: G.calm, seed: SEED,
      clues: clues.map(q => q.found ? 1 : 0), npcs: npcs.map(n => n.state), qi: qitems.map(i => (i.active ? 1 : 0) + (i.taken ? 2 : 0)), acc: !!G.accused,
      tm: teamSnapshot(), ml: G.melted, fl: fires.map(f => f.lit ? 1 : 0), dr: drifts.map(d => d.done ? 1 : 0), gl: glades.map(g => g.done ? 1 : 0), pl: pearls.map(q => q.got ? 1 : 0), mut: mutIds() };
    try { localStorage.setItem(saveKey(CHN), JSON.stringify(data)); } catch (e) { /* ignore */ }
  }
  (function migrateV1() {
    try {
      const old = localStorage.getItem('krilessa_save_v1');
      if (old && !localStorage.getItem(saveKey(1))) localStorage.setItem(saveKey(1), old);
      if (old) localStorage.removeItem('krilessa_save_v1');
    } catch (e) { /* ignore */ }
  })();

  // ------------------------------------------------------------------
  //  Запуск глав
  // ------------------------------------------------------------------
  function loadChapter(n, seed) {
    CHN = n; CFG = CHAPTERS[n]; SEED = seed || CFG.seed; // каждое новое прохождение – своя карта
    if (ZK !== 1) { ZK = 1; resize(); } // обычный обзор; оборона отодвинет камеру сама
    generateWorld();
  }
  function resetRun() {
    G.time = 0; G.kills = 0; G.defeated = CFG.bosses.map(() => false);
    G.cp = { x: tc(START.x), y: tc(START.y) };
    G.enemies = []; G.feathers = []; G.ebullets = []; G.hazards = []; G.pickups = []; G.parts = []; G.texts = []; G.bolts = []; G.rings = []; G.beams = [];
    G.shake = 0; G.hurtFlash = 0; G.activeBoss = null; G.pendingLv = 0; G.spawnT = 2; G.gateMsgT = 0; G.lowHpT = 0; G.calm = {}; G.bossHeartT = 12; G.champ = null; G.champT = 150;
    G.invertT = 0; G.staticT = 0; G.clues5 = [0, 0, 0, 0]; G.clueMsgT = 0; G.revealT = 0; G.hidden = null; G.hideT = 0; G.jump = null; G.pet = null;
    G.clearSight = false; G.boardPending = false; G.nearNpc = null; G.eyes = null; G.eyesT = 10; G.glitchT = 30; G.glitchFx = 0; G.flickT = -5; G.flickGap = 8; G.accused = false;
    P.z = 0; P.napT = 0; P.pounce = false; P.lives = 0; P.down = false; P.revT = 0;
    G.abyss = null; G.core = null; G.td = null; G.daily = null; G.mut = null; G.mutEarned = undefined; G.bossHurt = false;
    G.keys = 0; G.phoenixUsed = false; G.secondUsed = false; G.relicPending = false; G.guardT = 0; G.hintT = 0; G.mmHintT = 0; G.freePicks = 0;
    G.team = null; G.teamSave = null; G.tessaAlly = null; G.blizzardT = 0; G.blizA = 0; G.blizT = 55; G.melted = []; G.meltHits = {}; G.crackHits = {}; G.iceSaid = false; G.nearFire = null;
    for (const f of fires) f.lit = false;
    P.ivx = 0; P.ivy = 0; P.discoT = undefined;
    G.wxId = null; G.wxT = 0; G.lastWx = null; G.falling = []; G.chill = 0; G.cookieT = 0; G.caveA = 0; G.caveSaid = false; G.curSaid = false; G.onCurrent = false; G.fishing = null; G.baking = null;
    for (const d of drifts) { d.hp = 3; d.done = false; }
    for (const g of glades) { g.open = false; g.done = false; g.seen = false; }
    for (const o of holes.concat(ovens)) { o.cd = 0; o.prog = 0; }
    for (const ch of chests) { ch.mimicDone = false; ch.seen = false; }
    for (const bd of beds) { bd.cd = 0; bd.nap = 0; }
    for (const q of clues) q.found = false;
    for (const n of npcs) n.state = 'new';
    for (const it of qitems) { it.active = false; it.taken = false; }
    for (const s of shelves) { s.cd = 0; s.inside = false; }
    G.cutscene = null; G.victoryShown = false; G.cageOpen = 0; G.combo = 0; G.comboT = 0; G.bestCombo = 0; G.activeShrine = null;
    P.level = 1; P.xp = 0; P.xpNext = xpFor(1); P.up = {}; P.bonus = {}; P.shards = 0; P.maxHp = 100; P.hp = 100;
    P.inv = 0; P.dashT = 0; P.dashCd = 0; P.fireT = 0; P.boltT = 1; P.face = 1; P.slowT = 0; P.shieldT = 0; P.vx = 0; P.vy = 0;
    P.hero = CFG.hero; P.sp = 0; P.stormT = 0; G.pzones = []; G.novas = []; G.scaleCache = {};
    if (G.ev) endEvent();
    G.ev = null; G.evT = EVENT_EVERY; G.lowHpSaid = false; G.finalFinal = null; G.rush = null; G.trueWin = false; G.st = null; G.zm = null;
    trickTimers.forEach(clearTimeout); trickTimers = [];
    for (const c of chests) c.open = false;
    for (const s of shrines) s.state = 'idle';
    gateOpen = false;
    resetFog();
    Dialog.clear();
  }
  function beginPlay() {
    G.inMenu = false;
    const prof = loadProfile();
    G.tal = Object.assign({}, prof.talents || {});
    G.relicLv = Object.assign({}, prof.relicLv || {});
    try { G.myAura = myLook(prof).au; } catch (e) { G.myAura = 'none'; }
    G.relics = (prof.relics || []).filter(id => RELICS[id]).slice(0, relicMax());
    G.diffId = (prof.settings && prof.settings.diff) || 'normal'; G.diff = DIFFS[G.diffId] || DIFFS.normal;
    G.evT = EVENT_EVERY * G.diff.event * (weekEv('fest') ? 0.5 : 1);
    if (weekEv('champ')) G.champT = Math.min(G.champT, 75);
    P.maxHp = 100; computeStats(); P.hp = P.maxHp;
    initTeam(G.teamSave); G.teamSave = null;
    P.lives = CFG.rush || CFG.abyss ? 0 : HEROES[P.hero].lives || 0;
    if (CHN === 5) { const ch4 = prof.ch4Choice; G.pet = ch4 === 'kind' ? { x: P.x, y: P.y, fireT: 1 } : null; G.clearSight = ch4 === 'good'; }
    P.x = G.cp.x; P.y = G.cp.y; ensureWalkable(P);
    if (CFG.tessaStart) G.tessaAlly = { x: P.x + 34, y: P.y + 8, fireT: 1.2, face: 1 };
    makeBosses();
    revealFog(P.x, P.y, 12);
    $('dashBtn').querySelector('span').textContent = HEROES[P.hero].dash;
    setState('play');
    if (!G.st) G.st = newRunStats();
    else if (!String(G.st.diff).split('→').includes(G.diffId)) G.st.diff += '→' + G.diffId; // сложность меняли по ходу
    Sound.init(); biomeMusic(true);
    if (!CFG.rush) setTimeout(() => rotHintMaybe(), 1600);
  }
  // Если герой слабее стартового уровня главы – автонабор + последние улучшения на выбор
  function autoPick() {
    let best = null, bv = 1e9;
    for (const k in REF_W) { const l = P.up[k] || 0; if (l >= UPGRADE_MAX[k]) continue; const v = (l + 1) / REF_W[k]; if (v < bv) { bv = v; best = k; } }
    if (best) P.up[best] = (P.up[best] || 0) + 1;
  }
  function newChapter(n, seed) {
    loadChapter(n, seed || 1 + Math.floor(Math.random() * 2e9)); resetRun();
    if (G.mutNext) { G.mut = {}; for (const id of G.mutNext) if (MUT_BY[id]) G.mut[id] = true; }
    if (G.dailyNext && !NET.on) G.daily = G.dailyNext;
    G.mutNext = null; G.dailyNext = null;
    if (NET.on) P.hero = NET.hero; // вместе каждая играет своей героиней
    else if (!G.daily) try { localStorage.removeItem(saveKey(n)); } catch (e) { /* ignore */ } // испытание дня не трогает сохранение главы
    // прокачка своя в каждой главе: всегда с 1 уровня. Навсегда остаются реликвии и таланты
    beginPlay();
    { const pr = loadProfile(); if (MM_STYLE !== 'classic' && (pr.mmHintN || 0) < 3) { G.mmHintT = 6; pr.mmHintN = (pr.mmHintN || 0) + 1; saveProfile(pr); } }
    const tStart = talent('start');
    if (tStart) { G.pendingLv += tStart; G.freePicks = tStart; }
    if (talent('super')) P.sp = 25 * talent('super');
    if (n === 1) {
      G.hintT = 6;
      showBanner('Спаси Рыжовую!', 'Победи трёх стражей и открой Тёмный замок');
      say('Крилесса! Колдун Мрак запер меня в Тёмном замке!', 4);
      say('Победи трёх стражей – тогда ворота откроются. Иди по стрелке!', 4.5);
      say('Убивай врагов – копи СУПЕР-удар (кнопка над рывком)!', 4);
    } else if (n === 2) {
      showBanner('Глава 2', 'Кринж-Цитадель');
      say('Крилесса! Зямочкккк утащил меня в свою Кринж-Цитадель! Тут везде его портреты и диско-шары!!!', 5);
      say('Победи четырёх стражей: Кактуса, Пчелу, Голема и Паука. Враги здесь подстраиваются под твою силу!', 6);
    } else if (n === 3) {
      showBanner('Глава 3', 'Рыжовая спешит на помощь');
      say('Рыжовая! Это я, Крилесса! Зямочкккк запер меня в Зеркальном дворце!', 5);
      say('Победи четырёх стражей Зямоверса. Огонь в твоих волосах – твоё оружие! 🔥', 5);
      say('Твоя ВСПЫШКА переносит сквозь врагов и оставляет огненный след. СУПЕР – огненная волна!', 6);
    } else if (n === 4) {
      showBanner('Глава 4', 'Ночь глитчей');
      say('Мрр… Три часа ночи. Почему мигает свет? И кто шепчет в колонке?..', 5);
      say('Я царапаю сама. ПРЫЖОК – прыжок-кусь, СУПЕР – мурчание: лечит и оглушает.', 6);
      say('У кошки девять жизней 🐾. А на лежанке можно вздремнуть – станет легче.', 5.5);
      say('Тёплый свет ламп пугает глитчей. Держись поближе к свету…', 4.5);
    } else if (n === 5) {
      unlockOutfit('hat');
      showBanner('Глава 5', 'Пропавший корм');
      say('Миска пуста. ВСЕ миски пусты. Это дело для детектива Тессы. 🕵️', 5);
      say('У каждого подозреваемого спрятано три улики – найди их, и он не отвертится.', 5.5);
      say('Полки 🐾 – кошачьи короткие пути. В коробке 📦 меня никто не найдёт.', 5);
      const ch4 = loadProfile().ch4Choice;
      if (ch4 === 'kind') say('Мяу.exe теперь мой маленький пиксельный котик. Он помогает искать улики!', 5);
      else if (ch4 === 'good') say('После ночи с глитчами я вижу яснее: все улики видны на мини-карте.', 5);
    } else if (n === 6) {
      showBanner('Глава 6', 'Мрак: новый сезон');
      say('Крилесса! Рыжовая! Я в ледяной клетке на вершине замка… Тут так холодно! 🥶', 5);
      say('Победите четырёх стражей зимы – тогда ворота Ледяного замка откроются.', 5);
      say('Вы теперь вдвоём! Кнопка 🔄 меняет героиню. Пока одна бьётся – вторая отдыхает.', 6);
      say('Костры 🔥 греют и лечат. Огонь Рыжовой растапливает лёд и сугробы – за ними прячутся сокровища!', 5.5);
      say('По ледяным рекам можно мчаться с ветерком – но тормозить на льду трудно! ⛸️', 4.5);
    } else if (n === 7) {
      showBanner('Глава 7', 'Крилевая бездна');
      say('Буль! Мы под водой! Тесса с нами – в пузыре-шлеме, и она тоже стреляет. 🫧', 5);
      say('Криль украл все слова любви и спрятал в жемчужины 💗. Собери все 12!', 5.5);
      say('Синие течения несут быстро – прыгай в них, чтобы мчаться по карте. 🌊', 5);
      say('Четыре стража бездны охраняют путь к Крилевому замку. А на дне кто-то ОЧЕНЬ ругается…', 5.5);
    }
    if (G.pendingLv > 0) openLevelUp();
  }
  function continueChapter(n) {
    const s = loadSave(n);
    if (!s || (s.v || 0) < 5) { newChapter(n); return; }
    loadChapter(n, s.seed); resetRun();
    if (s.mut && s.mut.length) { G.mut = {}; for (const id of s.mut) if (MUT_BY[id]) G.mut[id] = true; }
    P.sp = s.sp || 0;
    G.defeated = CFG.bosses.map((_, i) => !!(s.defeated && s.defeated[i]));
    G.kills = s.kills || 0; G.time = s.time || 0; G.cp = s.cp || G.cp; G.bestCombo = s.bestCombo || 0;
    P.level = s.level || 1; P.xp = s.xp || 0; P.xpNext = xpFor(P.level); P.up = s.up || {}; P.bonus = s.bonus || {}; P.shards = s.shards || 0;
    (s.chests || []).forEach((o, i) => { if (chests[i]) { chests[i].open = !!o; if (o && chests[i].mimic) chests[i].mimicDone = true; } });
    (s.cs || []).forEach((o, i) => { if (chests[i]) chests[i].seen = !!o; });
    G.keys = s.keys || 0; G.phoenixUsed = !!s.ph; G.secondUsed = !!s.sw;
    (s.shrines || []).forEach((o, i) => { if (shrines[i] && o) shrines[i].state = 'done'; });
    G.st = s.st || null; G.lowHpSaid = !!s.lowHp; G.calm = s.calm || {};
    (s.clues || []).forEach((f, i) => { if (clues[i] && f) { clues[i].found = true; G.clues5[clues[i].i]++; } });
    (s.npcs || []).forEach((st, i) => { if (npcs[i]) npcs[i].state = st; });
    (s.qi || []).forEach((v, i) => { if (qitems[i]) { qitems[i].active = !!(v & 1); qitems[i].taken = !!(v & 2); } });
    (s.ml || []).forEach(i => meltTile(i, false));
    (s.fl || []).forEach((v, i) => { if (fires[i]) fires[i].lit = !!v; });
    (s.dr || []).forEach((v, i) => { if (drifts[i] && v) { drifts[i].done = true; drifts[i].hp = 0; } });
    (s.gl || []).forEach((v, i) => { if (glades[i] && v) glades[i].done = true; });
    (s.pl || []).forEach((v, i) => { if (pearls[i] && v) pearls[i].got = true; });
    for (const g of glades) if (g.ring.some(i => tiles[i] !== ROCK)) { g.open = true; g.seen = true; }
    if (s.tm && CFG.team && CFG.team.includes(s.tm.h)) P.hero = s.tm.h;
    G.teamSave = s.tm || null;
    beginPlay();
    gateOpen = guardiansDone() >= guardiansCount();
    G.accused = !!s.acc;
    if (CFG.detective && gateOpen && !G.accused) G.boardPending = true;
    // старые сохранения: локации уже побеждённых стражей сразу усмирены
    bosses.forEach((b, i) => { if (G.defeated[i] && b.calmBiome >= 0 && G.calm[b.calmBiome] === undefined) G.calm[b.calmBiome] = 0; });
    say(gateOpen ? 'Ворота открыты! Скорее в замок!' : `С возвращением! Стражей побеждено: ${guardiansDone()}/${guardiansCount()}.`);
  }
  function chapterOpen(n) {
    const prof = loadProfile();
    return DEBUG || !!prof.admin || n === 1 || !!prof['ch' + (n - 1) + 'Done'];
  }
  function startChapter(n) {
    if (!chapterOpen(n)) { toast(`🔒 Сначала пройди главу ${n - 1}`); return; }
    { const pr = loadProfile(); pr.lastCh = n; saveProfile(pr); } // для стартового экрана
    if (loadSave(n)) { continueChapter(n); return; }
    if (n === 1) { newChapter(1); return; }
    const intro = () => Intro.start('ch' + n, () => newChapter(n));
    // загадки глав 4 и 7 – прямо в начале главы (в первый раз), а не только по кнопке
    const pr = loadProfile();
    if (n === 4 && !pr.ch4Done) openTeaser(intro);
    else if (n === 7 && !pr.ch7Done) openKrillTeaser(intro);
    else intro();
  }
  const startChapter2 = () => startChapter(2);

  // ------------------------------------------------------------------
  //  Меню
  // ------------------------------------------------------------------
  // карточки секретных глав: название показываем только когда глава открыта
  const SECRET_CARDS = {
    4: { title: 'Ночь глитчей', locked: 'Хорошая… или добрая?..', open: 'Хорошая… или добрая?.. Новая героиня ждёт 🐾' },
    5: { title: 'Пропавший корм', locked: 'Кто-то что-то съел…', open: 'Кто украл корм? Уютный детектив 🕵️' },
    6: { title: 'Мрак: новый сезон', locked: 'Кто-то выключил лето…', open: 'Зима пришла не одна. Играешь вдвоём ❄️' },
    7: { title: 'Крилевая бездна', locked: 'Где-то в глубине стало подозрительно тихо…', open: 'Под воду! Течения, жемчужины со словами и кто-то очень ругучий на дне 🦐' },
  };
  function drawMenuPortrait() {
    const c = $('menuPortrait').getContext('2d');
    c.clearRect(0, 0, 240, 320);
    if (IMG.ryzhova) {
      // крупно лицо – в шапке меню портрет маленький
      const cv = IMG.ryzhova.cartoon, f = IMG.ryzhova.face || { x: 0.5, y: 0.4, r: 0.3 };
      const R = cv.width * f.r * 1.25, cx = cv.width * f.x, cy = cv.height * f.y;
      c.drawImage(cv, cx - R * 0.75, cy - R, R * 1.5, R * 2, 0, 0, 240, 320);
    }
    c.strokeStyle = 'rgba(255,210,90,0.85)'; c.lineWidth = 6;
    for (let i = 1; i < 6; i++) { c.beginPath(); c.moveTo(i * 40, 0); c.lineTo(i * 40, 320); c.stroke(); }
    c.lineWidth = 8; c.beginPath(); c.moveTo(0, 6); c.lineTo(240, 6); c.moveTo(0, 314); c.lineTo(240, 314); c.stroke();
  }
  // шапка меню: рамка портрета, эмблема, звание и слава
  function menuGlory(pr) {
    const g = gloryOf(pr), lk = myLook(pr), fr = lookItem('fr', lk.fr), mp = $('mPortrait');
    mp.style.setProperty('--fb', fr.b); mp.style.setProperty('--fa', fr.a || 'none'); mp.style.setProperty('--fg', fr.glow || 'rgba(0,0,0,0)');
    mp.classList.toggle('live', !!fr.a);
    $('mEmb').innerHTML = avatarHtml(lk, 26);
    $('mRank').textContent = `${g.rank.ic} ${titleText(lk.ti, g.rk)} · ✨ ${fmtN(g.fame)}`;
  }
  function openMenu() {
    liveClear(); // из забега вышли сами – это не вылет
    try { lifeFlush(); } catch (e) { /* ignore */ }
    if (!NET.on && G.st) try { // вышли посреди забега: раш и испытание дня засчитываются, Бездну можно продолжить
      if (G.rush && !G.rush.done && G.rush.idx > 0) rushFinish(false);
      if (G.daily && !G.daily.done && G.daily.score > 0) dailyFinish(false);
      if (defOn() && !G.abyss.done && G.abyss.wave > 0) defFinish();
      if (G.abyss && !G.abyss.def && !G.abyss.done) { const ck = abyssCkLoad(); if (ck) setTimeout(() => toast(`🕳️ Бездна сохранена после волны ${ck.wave} – продолжить можно в «Режимах»`), 400); }
    } catch (e) { logErr(e, 'menu'); }
    if (NET.on && G.netRun) mpLeave(true); // вышли из игры вместе – отключаемся
    G.inMenu = true;
    if ($('updBox').parentNode !== $('menu')) { $('mHead').after($('updBox')); showUpdate(); }
    if (CHN !== 1 || !tiles) loadChapter(1);
    resetRun();
    makeBosses();
    const prof = loadProfile();
    renderMap(prof);
    $('btnWardrobe').classList.toggle('hidden', !(prof.ch3Done || DEBUG || prof.admin));
    const freeStars = (prof.stars || 0) - talentSpent(prof.talents || {});
    $('mStarsN').textContent = prof.stars || 0;
    $('talBadge').textContent = freeStars; $('talBadge').classList.toggle('hidden', freeStars <= 0);
    try { menuGlory(prof); } catch (e) { /* ignore */ }
    try { seasonDaily(); } catch (e) { logErr(e, 'season'); }
    if (prof.talReset031) { delete prof.talReset031; saveProfile(prof); setTimeout(() => toast('⭐ Таланты стали созвездиями – все звёзды вернулись. Распредели заново!'), 1500); }
    // интро – только после прохождения главы
    ['btnIntro', 'btnIntro2', 'btnIntro3', 'btnIntro4', 'btnIntro5', 'btnIntro6', 'btnIntro7'].forEach((id, i) => {
      const done = DEBUG || prof.admin || prof['ch' + (i + 1) + 'Done'];
      $(id).classList.toggle('locked', !done);
      $(id).textContent = (done ? '' : '🔒 ') + 'Интро ' + (i + 1);
    });
    const rushOpen = DEBUG || prof.admin || prof.ch1Done;
    $('chapRush').classList.toggle('locked', !rushOpen);
    $('menu').querySelector('.version').textContent = 'v' + VERSION + (prof.admin ? ' · 🔓 админ' : '');
    updateSoundButtons();
    drawMenuPortrait();
    try { const A = window.KrilessaAndroid; const raw = A && A.updateInfo ? A.updateInfo() : ''; if (raw && !G.update) G.update = JSON.parse(raw); } catch (e) { /* ignore */ }
    showUpdate();
    setState('menu');
    Sound.music('menu');
    if (prof.ch4Done && !prof.ch4Choice && !G.pendingWhatsNew) { setTimeout(() => { if (state === 'menu') openChoice(true); }, 400); }
    if (G.pendingWhatsNew) { const from = G.pendingWhatsNew; G.pendingWhatsNew = null; setTimeout(() => openWhatsNew(from === true ? null : from), 300); }
  }
  // ---------- стартовый экран (для тех, кто уже играл) ----------
  const SPLASH_THEME = {
    1: { sky: ['#0e0c2a', '#2a2a6a', '#3a5a6a'], hill: ['#14301e', '#0a1c12'], moon: '#fff3c8', fx: 'ff' },
    2: { sky: ['#1a0628', '#4a1450', '#6a1a5a'], hill: ['#2a0a3a', '#14061e'], fx: 'disco' },
    3: { sky: ['#1a0814', '#5a1a20', '#a0401a'], hill: ['#2a0c10', '#14060a'], fx: 'ember' },
    4: { sky: ['#020208', '#0a0c1e', '#141a33'], hill: ['#06060e', '#020206'], moon: '#c8d8ff', fx: 'eyes' },
    5: { sky: ['#ffb070', '#ffcf8a', '#ffe8c0'], hill: ['#8a5a2a', '#5a3a1a'], sun: '#fff3a0', fx: 'paws' },
    6: { sky: ['#06102a', '#12285a', '#2a4a8a'], hill: ['#e8f2fc', '#bcd4ea'], fx: 'snow' },
    7: { sky: ['#021430', '#06386a', '#0a6a8a'], hill: ['#e8c890', '#b8945a'], fx: 'sea', noStars: true },
  };
  const TIPS = [
    [0, 'Веди пальцем по экрану – героиня стреляет сама. Рывок спасает от всего!'],
    [0, 'Сердечки чаще падают, когда здоровья мало. Не сдавайся!'],
    [0, 'На карте можно сбивать значки тапом. Быстро – будет множитель 😉'],
    [0, 'Нажми на мини-карту – откроется большая карта с метками.'],
    [1, 'За каждого босса – звезда ⭐. Трать их в «Талантах»!'],
    [1, 'Чемпион с короной 👑 крепкий, но награда того стоит.'],
    [1, 'Алтари ⛩ открывают испытания и порталы между собой.'],
    [1, 'Золотые сундуки заперты – ключи дают стражи, чемпионы и мимики.'],
    [3, 'Реликвии остаются с тобой во всех главах. Носить можно три.'],
    [4, 'Тесса прячется в коробках 📦 и лечится там.'],
    [5, 'Особые улучшения выпадают только в своей главе – лови их!'],
    [6, 'Огонь Рыжовой растапливает лёд и сугробы. Меняйтесь кнопкой 🔄'],
    [6, 'Под водой прыгай в течения 🌊 – мчат быстрее, а жемчужины 💗 лечат и хранят слова'],
  ];
  const SP = { raf: 0, t: 0, th: 1, heroes: [], pet: false, jump: {}, hearts: [], gy: 0, measT: -1 };
  function openSplash() {
    const prof = loadProfile();
    const doneN = CH_NUMS.filter(n => prof['ch' + n + 'Done']).length;
    let th = prof.lastCh && CHAPTERS[prof.lastCh] && chapterOpen(prof.lastCh) ? prof.lastCh : 1;
    if (!prof.lastCh) for (const n of CH_NUMS) if (chapterOpen(n)) th = n;
    SP.th = th;
    SP.heroes = ['krilessa'].concat(prof.ch1Done || DEBUG || prof.admin ? ['ryzhovaya'] : []).concat(prof.ch3Done || DEBUG || prof.admin ? ['tessa'] : []);
    SP.pet = prof.ch4Choice === 'kind';
    SP.jump = {}; SP.hearts = []; SP.t = 0;
    $('spLogo').innerHTML = [...'Крилесса'].map((ch, i) => `<span style="animation-delay:${(i * 0.07).toFixed(2)}s, ${(1 + i * 0.12).toFixed(2)}s">${ch}</span>`).join('');
    $('spSub').textContent = doneN >= CH_NUMS.length ? 'Сезон пройден! Но приключения продолжаются…' : 'Спасение Рыжовой';
    const tips = TIPS.filter(([req]) => req <= doneN || (req && prof.admin));
    $('spTip').textContent = '💡 ' + pick(tips)[1];
    $('spUpd').appendChild($('updBox')); showUpdate(); // радужная плашка обновления – прямо на стартовом экране
    SP.gy = 0; SP.measT = -1;
    setState('splash');
    Sound.music('menu'); // главная тема – одна на стартовом экране и на карте приключений
    cancelAnimationFrame(SP.raf); SP.last = performance.now(); SP.raf = requestAnimationFrame(splashLoop);
  }
  function splashLoop(now) {
    if (state !== 'splash') { SP.raf = 0; return; }
    const dt = Math.min(0.05, (now - SP.last) / 1000); SP.last = now; SP.t += dt;
    const cv = $('splashCv'), c = cv.getContext('2d'), dpr = Math.min(window.devicePixelRatio || 1, 2);
    const W = cv.clientWidth, H = cv.clientHeight;
    if (cv.width !== Math.round(W * dpr) || cv.height !== Math.round(H * dpr)) { cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr); }
    c.setTransform(dpr, 0, 0, dpr, 0, 0);
    const th = SPLASH_THEME[SP.th] || SPLASH_THEME[1], t = SP.t;
    const g = c.createLinearGradient(0, 0, 0, H); g.addColorStop(0, th.sky[0]); g.addColorStop(0.55, th.sky[1]); g.addColorStop(1, th.sky[2]);
    c.fillStyle = g; c.fillRect(0, 0, W, H);
    // звёзды
    if (SP.th !== 5 && !th.noStars) for (let i = 0; i < 70; i++) { c.fillStyle = `rgba(255,255,255,${0.25 + 0.6 * Math.abs(Math.sin(t * (0.6 + hash2(i, 9)) + i))})`; c.fillRect(hash2(i, 1) * W, hash2(1, i) * H * 0.6, 1.6, 1.6); }
    if (th.moon) { c.fillStyle = th.moon; c.shadowColor = th.moon; c.shadowBlur = 30; c.beginPath(); c.arc(W * 0.78, H * 0.3, 26, 0, TAU); c.fill(); c.shadowBlur = 0; c.fillStyle = th.sky[1]; c.beginPath(); c.arc(W * 0.78 + 10, H * 0.3 - 6, 22, 0, TAU); c.fill(); }
    if (th.sun) { const sg = c.createRadialGradient(W * 0.25, H * 0.34, 4, W * 0.25, H * 0.34, 90); sg.addColorStop(0, th.sun); sg.addColorStop(1, 'rgba(255,243,160,0)'); c.fillStyle = sg; c.fillRect(W * 0.25 - 90, H * 0.34 - 90, 180, 180); }
    if (SP.th === 6) for (let k = 0; k < 3; k++) { // северное сияние
      c.strokeStyle = ['rgba(90,255,180,.16)', 'rgba(120,200,255,.14)', 'rgba(200,120,255,.12)'][k]; c.lineWidth = 40 - k * 8; c.lineCap = 'round';
      c.beginPath(); for (let x = 0; x <= W; x += 16) { const y = H * (0.22 + k * 0.05) + Math.sin(x * 0.012 + t * 0.7 + k) * 20; if (x) c.lineTo(x, y); else c.moveTo(x, y); } c.stroke();
    }
    if (th.fx === 'disco') for (let k = 0; k < 4; k++) { // лучи прожекторов
      const a = Math.sin(t * 0.9 + k * 1.7) * 0.6, x0 = W * (0.15 + k * 0.23);
      c.save(); c.translate(x0, -10); c.rotate(a);
      const bg2 = c.createLinearGradient(0, 0, 0, H * 0.8); bg2.addColorStop(0, ['rgba(255,110,220,.35)', 'rgba(110,230,255,.3)', 'rgba(255,230,110,.3)', 'rgba(160,120,255,.3)'][k]); bg2.addColorStop(1, 'rgba(0,0,0,0)');
      c.fillStyle = bg2; c.beginPath(); c.moveTo(-6, 0); c.lineTo(6, 0); c.lineTo(70, H * 0.8); c.lineTo(-70, H * 0.8); c.closePath(); c.fill(); c.restore();
    }
    // холмы
    const hill = (yb, amp, k, col, sp) => { c.fillStyle = col; c.beginPath(); c.moveTo(0, H); for (let x = 0; x < W + 12; x += 12) c.lineTo(Math.min(x, W), yb + Math.sin(Math.min(x, W) * k + t * sp) * amp); c.lineTo(W, H); c.closePath(); c.fill(); };
    const ks = Math.min(2.4, W / 150);
    if (SP.t - SP.measT > 0.2 || SP.measT < 0) { // где кончается плашка обновления и начинаются кнопки
      SP.measT = SP.t;
      const sp = $('splash'), ub = $('updBox'), bot = sp.querySelector('.spBot');
      const offY = el => { let y = 0; while (el && el !== sp) { y += el.offsetTop; el = el.offsetParent; } return y; }; // без учёта анимаций
      SP.botY = bot ? offY(bot) : H - 200;
      SP.cardY = !ub.classList.contains('hidden') && ub.parentNode === $('spUpd') ? offY(ub) + ub.offsetHeight : 0;
    }
    let want = Math.max(H * 0.5, SP.botY - 48); // героини стоят прямо над кнопкой
    if (SP.cardY) want = Math.min(Math.max(want, SP.cardY + 42 * ks + 10), H - 120);
    SP.gy = SP.gy ? SP.gy + (want - SP.gy) * Math.min(1, dt * 5) : want;
    const gy = SP.gy; // холм над кнопками
    hill(gy - 46, 18, 0.011, th.hill[1], 0.05);
    if (th.fx === 'eyes') for (let k = 0; k < 4; k++) { // глаза в темноте
      const ex = W * (0.12 + k * 0.26), ey = gy - 30 + (k % 2) * 14, bl = Math.sin(t * 1.3 + k * 2.1) > 0.95 ? 0.15 : 1;
      c.fillStyle = k === 2 ? '#9dffc8' : '#c8ecff'; c.shadowColor = k === 2 ? '#3ff0a0' : '#7fc8ff'; c.shadowBlur = 10;
      c.beginPath(); c.ellipse(ex - 7, ey, 4.5, 2.5 * bl, 0, 0, TAU); c.ellipse(ex + 7, ey, 4.5, 2.5 * bl, 0, 0, TAU); c.fill(); c.shadowBlur = 0;
    }
    hill(gy, 10, 0.017, th.hill[0], -0.04);
    // героини на холме
    const n = SP.heroes.length, slots = n === 1 ? [0.5] : n === 2 ? [0.35, 0.65] : [0.2, 0.5, 0.8];
    SP.heroes.forEach((id, i) => {
      const hx = W * slots[i], j = SP.jump[id] || 0, jy = j > 0 ? Math.sin((1 - j) * Math.PI) * 50 : 0;
      if (j > 0) SP.jump[id] = Math.max(0, j - dt * 1.6);
      c.fillStyle = 'rgba(0,0,0,0.25)'; c.beginPath(); c.ellipse(hx, gy + 12 + Math.sin(hx * 0.017 - t * 0.04) * 10, 26, 7, 0, 0, TAU); c.fill();
      drawHero(id, c, hx, gy + Math.sin(hx * 0.017 - t * 0.04) * 10 - jy + Math.sin(t * 2 + i) * 2, t, slots[i] < 0.5 ? 1 : slots[i] > 0.5 ? -1 : 1, ks, 1, false);
      SP.heroX = SP.heroX || {}; SP.heroX[id] = [hx, gy - 40 * ks / 3];
    });
    if (SP.pet) { // Мяу.exe
      const px = W * 0.93, py = gy - 18 + Math.sin(t * 4) * 3;
      for (const [x, y] of [[-3, -4], [3, -4], [-3, -3], [-2, -3], [-1, -3], [0, -3], [1, -3], [2, -3], [3, -3], [-3, -2], [-2, -2], [0, -2], [2, -2], [3, -2], [-3, -1], [-2, -1], [-1, -1], [0, -1], [1, -1], [2, -1], [3, -1], [-2, 0], [-1, 0], [0, 0], [1, 0], [2, 0], [-2, 1], [2, 1]]) { c.fillStyle = '#3ff0a0'; c.fillRect(px + x * 3, py + y * 3, 3, 3); }
    }
    // частицы темы
    if (th.fx === 'ff') for (let i = 0; i < 16; i++) { const x = hash2(i, 3) * W + Math.sin(t * 0.8 + i) * 20, y = H * (0.45 + hash2(3, i) * 0.4) + Math.cos(t * 0.6 + i * 2) * 14; c.fillStyle = `rgba(255,240,120,${0.3 + 0.7 * Math.abs(Math.sin(t * 2 + i))})`; c.beginPath(); c.arc(x, y, 2.2, 0, TAU); c.fill(); }
    if (th.fx === 'ember') for (let i = 0; i < 22; i++) { const k = (t * (0.15 + hash2(i, 4) * 0.2) + hash2(4, i)) % 1, x = hash2(i, 5) * W + Math.sin(t + i) * 10, y = H * (1 - k * 0.9); c.fillStyle = `rgba(255,${150 + (i % 3) * 30},60,${1 - k})`; c.beginPath(); c.arc(x, y, 2.4, 0, TAU); c.fill(); }
    if (th.fx === 'snow') for (let i = 0; i < 60; i++) { const k = (t * (0.05 + hash2(i, 6) * 0.06) + hash2(6, i)) % 1, x = (hash2(i, 7) * W + Math.sin(t * 0.7 + i) * 18 + k * 30) % W, y = k * H; c.fillStyle = 'rgba(255,255,255,0.85)'; c.beginPath(); c.arc(x, y, 1.2 + hash2(i, 8) * 2, 0, TAU); c.fill(); }
    if (th.fx === 'sea') { // подводный свет, пузыри и стайка криля
      for (let k = 0; k < 4; k++) { const x0 = W * (0.12 + k * 0.27) + Math.sin(t * 0.4 + k) * 20; c.fillStyle = 'rgba(160,230,255,0.07)'; c.beginPath(); c.moveTo(x0 - 14, 0); c.lineTo(x0 + 14, 0); c.lineTo(x0 + 70, H * 0.8); c.lineTo(x0 - 40, H * 0.8); c.closePath(); c.fill(); }
      for (let i = 0; i < 26; i++) { const k = (t * (0.06 + hash2(i, 12) * 0.08) + hash2(12, i)) % 1, x = hash2(i, 13) * W + Math.sin(t * 1.4 + i) * 8, y = H * (1 - k); c.strokeStyle = `rgba(210,245,255,${0.7 * (1 - k)})`; c.lineWidth = 1.3; c.beginPath(); c.arc(x, y, 1.5 + hash2(i, 14) * 3.5, 0, TAU); c.stroke(); }
      for (let i = 0; i < 9; i++) { const a = t * 0.5 + i * 0.7, x = W * 0.5 + Math.cos(a) * W * 0.36, y = H * 0.24 + Math.sin(a * 1.3) * 40 + i * 4; c.fillStyle = '#ff8aa8'; c.save(); c.translate(x, y); c.rotate(a + Math.PI / 2); c.beginPath(); c.ellipse(0, 0, 6, 2.6, 0, 0, TAU); c.fill(); c.restore(); }
    }
    if (th.fx === 'paws') for (let i = 0; i < 6; i++) { const k = (t * 0.5 - i * 0.18) % 1.4; if (k < 0 || k > 1) continue; c.globalAlpha = Math.sin(k * Math.PI) * 0.6; c.font = '18px sans-serif'; c.fillText('🐾', W * (0.08 + i * 0.15), gy + 36 + (i % 2) * 10); c.globalAlpha = 1; }
    if (th.fx === 'disco') for (let i = 0; i < 10; i++) { const a = Math.abs(Math.sin(t * 1.5 + i * 1.3)); c.fillStyle = `rgba(255,255,255,${a})`; star(c, hash2(i, 11) * W, hash2(11, i) * H * 0.6, 3 * a + 1, t, 4); c.fill(); }
    // сердечки от прыжков
    for (const hh of SP.hearts) { hh.t += dt; hh.y -= 60 * dt; c.globalAlpha = Math.max(0, 1 - hh.t); c.fillStyle = hh.col; heartPath(c, hh.x + Math.sin(hh.t * 6 + hh.x) * 6, hh.y, 7); c.fill(); c.globalAlpha = 1; }
    SP.hearts = SP.hearts.filter(hh => hh.t < 1);
    if (paperOn) { // заставка тоже на бумаге: мягче краски и зерно
      if (!PAPER.tex) PAPER.tex = paperTex();
      c.save(); c.setTransform(dpr, 0, 0, dpr, 0, 0); c.globalCompositeOperation = 'screen'; c.fillStyle = 'rgba(255,236,206,.14)'; c.fillRect(0, 0, W, H);
      c.globalCompositeOperation = 'multiply'; c.fillStyle = c.createPattern(PAPER.tex, 'repeat'); c.fillRect(0, 0, W, H); c.restore();
    }
    SP.raf = requestAnimationFrame(splashLoop);
  }
  // ---------- главный экран: карта приключений ----------
  const CH_META = {
    1: { ic: '🌲', c: ['#7dff7d', '#1f7a2a'], sc: '30,90,40', deco: ['🌲', '🌳', '🍄', '🌼'], hero: 'krilessa', desc: 'Рыжовая в плену у колдуна Мрака. Победи трёх стражей и открой Тёмный замок' },
    2: { ic: '🪩', c: ['#ff8ad8', '#6a2ad8'], sc: '90,30,110', deco: ['🪩', '✨', '🎤', '💿'], hero: 'krilessa', desc: 'Зямочкккк утащил Рыжовую в свою Кринж-Цитадель. Диско-шары, портреты и много кринжа' },
    3: { ic: '🪞', c: ['#ffc070', '#c03a10'], sc: '110,45,20', deco: ['🪞', '🔥', '🦄', '✨'], hero: 'ryzhovaya', desc: 'Теперь играешь за Рыжовую! Огонь в её волосах – оружие. Спаси Крилессу из Зеркального дворца' },
    4: { ic: '🌙', c: ['#8fa6e8', '#141a40'], sc: '20,26,60', deco: ['🌙', '🐾', '💡', '📺'], hero: 'tessa' },
    5: { ic: '🔎', c: ['#ffe08a', '#d8782a'], sc: '110,70,20', deco: ['🐟', '🔎', '📦', '🥣'], hero: 'tessa' },
    6: { ic: '❄️', c: ['#d8f2ff', '#3a6ac8'], sc: '30,60,110', deco: ['❄️', '⛄', '🔥', '🌨️'], hero: 'krilessa' },
    7: { ic: '🦐', c: ['#6ae0ff', '#062a5a'], sc: '10,50,90', deco: ['🐠', '🦐', '🐚', '🌊'], hero: 'krilessa' },
  };
  const CH_STUBS = 3; // главы 8–10 – пока заглушки «скоро…»
  const CH_LOCKED_META = { ic: '❔', c: ['#6a6080', '#1a1626'], sc: '30,26,44' };
  function chapterView(n, prof) {
    const C = CHAPTERS[n], open = chapterOpen(n), done = !!prof['ch' + n + 'Done'], sv = loadSave(n), sec = SECRET_CARDS[n];
    const hidden = !open && !!sec; // закрытая секретная глава – загадка
    const meta = hidden ? CH_LOCKED_META : CH_META[n];
    // идёт новое прохождение – показываем его прогресс, иначе для пройденной главы все звёзды
    const nb = C.bosses.length, beaten = sv && sv.defeated ? sv.defeated.filter(Boolean).length : done ? nb : 0;
    let stat = '';
    if (!open) stat = hidden ? '🔒 ' + sec.locked : `🔒 Откроется после главы ${n - 1}`;
    else if (sv) stat = `💾 Сохранение: боссы ${beaten}/${nb} · ур. ${sv.level}`;
    else if (n === 3 && prof.trueWin) stat = '✓ Настоящий финал пройден ❤';
    else if (n === 4 && done) stat = prof.ch4Choice === 'kind' ? '✓ Пройдена · добрая концовка 💗' : prof.ch4Choice === 'good' ? '✓ Пройдена · хорошая концовка 🛡️' : '✓ Пройдена';
    else if (n === 5 && done) stat = '✓ Дело раскрыто 🕵️';
    else if (n === 6 && done) stat = '✓ Зима отступила ❄️';
    else if (n === 7 && done) stat = '✓ Слова вернулись 💗';
    else if (done) stat = '✓ Пройдена';
    else stat = 'Новая прокачка с 1 уровня';
    return { n, open, done, sv, hidden, meta, nb, beaten, stat,
      title: hidden ? '???' : (sec ? sec.title : C.name),
      desc: hidden ? 'Что здесь – секрет. Пройди предыдущую главу.' : (sec ? sec.open : CH_META[n].desc),
      isNew: open && !done && !sv && n > 1 && !!prof['ch' + (n - 1) + 'Done'] };
  }
  function renderMap(prof) {
    const map = $('mMap'), road = $('mRoad'), hero = $('mHero');
    for (const el of [...map.querySelectorAll('.node,.zone,.deco')]) el.remove();
    const N = CH_NUMS.length, ALL = N + CH_STUBS, GAP = 150, TOP = 130, BOT = 110, W = Math.min(map.clientWidth || window.innerWidth, 460);
    const H = TOP + BOT + GAP * (ALL - 1);
    map.style.height = H + 'px';
    const xs = [0.5, 0.27, 0.72, 0.3, 0.7, 0.34, 0.66, 0.32, 0.68, 0.38, 0.6];
    const pos = i => ({ x: (map.clientWidth || W) / 2 + (xs[i] - 0.5) * W, y: H - BOT - i * GAP }); // i=0 – глава 1, снизу
    const views = [];
    for (let n = 1; n <= N; n++) views.push(chapterView(n, prof));
    let cur = views.find(v => v.open && !v.done) || [...views].reverse().find(v => v.open) || views[0];
    // цветные «зоны» глав и украшения вокруг дороги
    views.forEach((v, i) => {
      const p = pos(i), z = document.createElement('div');
      z.className = 'zone'; z.style.top = (p.y - GAP * 0.75) + 'px'; z.style.height = (GAP * 1.5) + 'px';
      z.style.background = `radial-gradient(ellipse 70% 50% at ${Math.round(xs[i] * 100)}% 50%, ${v.meta.c[0]}, transparent)`;
      z.style.opacity = v.open ? 0.3 : 0.1; map.appendChild(z);
      const eyes = v.n === 4 ? EYES4(xs[i] <= 0.5 ? 1 : -1) : [];
      if (!v.hidden) CH_META[v.n].deco.forEach((d, k) => {
        const side = (k % 2 ? 1 : -1) * (xs[i] < 0.5 ? -1 : 1), dx = side * (70 + hash2(v.n, k) * 70), dy = (hash2(k, v.n) - 0.5) * 90;
        if (eyes.some(([ax, ay]) => Math.hypot(dx + 11 - ax, dy - 3 - ay) < 48)) return; // глаза в темноте не загораживаем
        const e = document.createElement('div'); e.className = 'deco'; e.textContent = d;
        e.style.left = Math.max(6, Math.min((map.clientWidth || W) - 30, p.x + dx)) + 'px'; e.style.top = (p.y + dy - 14) + 'px';
        e.style.animationDelay = (k * 0.7 + v.n * 0.3) + 's'; e.style.opacity = v.open ? 0.85 : 0.35;
        e.addEventListener('click', ev2 => { ev2.stopPropagation(); knockDeco(e, d); });
        map.appendChild(e);
      });
    });
    // дорога
    const pts = views.map((v, i) => pos(i));
    let d = `M ${pts[0].x} ${pts[0].y + 70}`, far = '';
    let gold = '';
    for (let i = 0; i < pts.length; i++) {
      const a2 = i === 0 ? { x: pts[0].x, y: pts[0].y + 70 } : pts[i - 1], b2 = pts[i], my = (a2.y + b2.y) / 2;
      const seg = ` C ${a2.x} ${my}, ${b2.x} ${my}, ${b2.x} ${b2.y}`;
      d += seg;
      if (i === 0 || (views[i - 1] && views[i - 1].done)) gold += (gold ? '' : `M ${a2.x} ${a2.y}`) + seg;
    }
    for (let i = N; i < ALL; i++) { // тропинка к будущим главам – еле заметная
      const a2 = pos(i - 1), b2 = pos(i), my = (a2.y + b2.y) / 2;
      far += (far ? '' : `M ${a2.x} ${a2.y}`) + ` C ${a2.x} ${my}, ${b2.x} ${my}, ${b2.x} ${b2.y}`;
    }
    road.setAttribute('viewBox', `0 0 ${map.clientWidth || W} ${H}`);
    road.innerHTML = `<path d="${far}" fill="none" stroke="rgba(233,214,176,.22)" stroke-width="14" stroke-linecap="round" stroke-dasharray="2 18"/>` +
      (paperOn ? `<path d="${d}" fill="none" stroke="#6a4a2e" stroke-width="25" stroke-linecap="round" opacity=".75"/>` + `<path d="${d}" fill="none" stroke="#ecd3a2" stroke-width="22" stroke-linecap="round"/>` + `<path d="${d}" fill="none" stroke="#f6e4bf" stroke-width="10" stroke-linecap="round" opacity=".8"/>`
      : `<path d="${d}" fill="none" stroke="rgba(0,0,0,.35)" stroke-width="30" stroke-linecap="round"/>` +
      `<path d="${d}" fill="none" stroke="#e9d6b0" stroke-width="22" stroke-linecap="round"/>`) +
      (gold ? `<path d="${gold}" fill="none" stroke="#ffd25a" stroke-width="22" stroke-linecap="round" opacity=".9"/>` : '') +
      `<path d="${d}" fill="none" stroke="rgba(120,80,40,.55)" stroke-width="3" stroke-dasharray="10 12" stroke-linecap="round"/>`;
    // главы
    views.forEach((v, i) => {
      const p = pos(i), el = document.createElement('button');
      el.className = 'node' + (v.open ? '' : ' locked') + (v.done ? ' done' : '') + (v === cur ? ' cur' : '') + (v.n === 7 && v.hidden ? ' tz' : '');
      el.id = 'chap' + v.n; el.style.left = p.x + 'px'; el.style.top = (p.y - 42) + 'px';
      el.style.setProperty('--c1', v.meta.c[0]); el.style.setProperty('--c2', v.meta.c[1]);
      const stars = v.open ? '★'.repeat(v.beaten) + '☆'.repeat(v.nb - v.beaten) : '';
      el.innerHTML = `<div class="med"><span class="ic">${v.open ? v.meta.ic : (v.hidden ? '❔' : '🔒')}</span><b class="num">${v.n}</b>${v.isNew ? '<div class="newb">НОВОЕ</div>' : ''}</div>` +
        `<div class="lbl">${v.title}${stars ? `<span class="pr">${stars}</span>` : ''}</div>`;
      el.insertAdjacentHTML('afterbegin', chapterFx(v, xs[i] <= 0.5 ? 1 : -1));
      // закрытая глава 7 – загадка из глубины, как раньше
      el.addEventListener('click', () => { Sound.init(); Sound.sfx.click(); if (v.n === 7 && v.hidden) openKrillTeaser(); else openChapterSheet(v.n); });
      map.appendChild(el);
    });
    // главы 8–10 – просто заглушки «скоро…», без загадок
    for (let i = N; i < ALL; i++) {
      const ps = pos(i), n = i + 1, el = document.createElement('button');
      el.className = 'node stub'; el.id = 'chap' + n; el.style.left = ps.x + 'px'; el.style.top = (ps.y - 42) + 'px';
      el.innerHTML = `<div class="med"><span class="ic">🚧</span><b class="num">${n}</b></div><div class="lbl">Глава ${n}<span class="pr">Скоро…</span></div>`;
      el.addEventListener('click', () => { Sound.init(); Sound.sfx.click(); toast(`🚧 Глава ${n} пока строится. Скоро!`); });
      map.appendChild(el);
    }
    // героиня над текущей главой
    const pc = pos(cur.n - 1), side = xs[cur.n - 1] <= 0.5 ? 1 : -1; // сбоку от медальона, к центру экрана
    hero.style.left = (pc.x + side * 62) + 'px'; hero.style.top = (pc.y - 100) + 'px';
    const hc = $('mHeroCv').getContext('2d'); hc.clearRect(0, 0, 96, 96);
    const hid = cur.hidden ? null : (CH_META[cur.n] || {}).hero;
    if (hid) { const img = heroAvatar(hid); if (img) hc.drawImage(img, 0, 0, 96, 96); }
    $('mSub').textContent = cur.hidden ? 'Спасение Рыжовой' : `Глава ${cur.n} · ${cur.title}`;
    G.menuCur = cur.n;
    requestAnimationFrame(() => { const box = $('mPath'); box.scrollTop = Math.max(0, pc.y - box.clientHeight * 0.55); });
  }
  // ---------- украшения на карте можно сбивать тапом ----------
  const DECO_COL = {
    '❄️': ['#ffffff', '#bfeaff', '#7fd8ff'], '🌨️': ['#ffffff', '#bfeaff'], '⛄': ['#ffffff', '#ff8a2a', '#bfeaff'],
    '🔥': ['#ffe08a', '#ffb03a', '#ff6a1f'], '✨': ['#fff3b0', '#ffd25a', '#ffffff'], '🌲': ['#7dff7d', '#2f9a3a', '#c8ffb0'], '🌳': ['#7dff7d', '#3fae4a'],
    '🍄': ['#ff4a4a', '#ffffff'], '🌼': ['#ffe04a', '#ffffff'], '🪩': ['#ff6fd8', '#6ae6ff', '#ffe08a', '#ffffff'], '💿': ['#c8d4ff', '#ff9ad8', '#9affe8'],
    '🎤': ['#ff6fb5', '#c8c8d8'], '🪞': ['#d8f2ff', '#ffffff', '#ffd25a'], '🦄': ['#ff9ad8', '#9ad8ff', '#fff3b0', '#c8a8ff'], '🌙': ['#ffe08a', '#fff7c8'],
    '🐾': ['#ff9ab8', '#ffd0dc'], '💡': ['#fff7a0', '#ffe04a'], '📺': ['#3ff0a0', '#ff3ea5', '#6ae6ff'], '🐟': ['#6ac8ff', '#ffd25a'],
    '🔎': ['#ffd25a', '#d8f2ff'], '📦': ['#d8a050', '#8a5a2a'], '🥣': ['#ffffff', '#6ac8ff'],
  };
  let decoCombo = 0, decoComboT = 0;
  function knockDeco(el, glyph) {
    if (el.classList.contains('hit')) return;
    Sound.init();
    const cols = DECO_COL[glyph] || ['#ffffff', '#ffd25a'], map = $('mMap');
    const cx = el.offsetLeft + el.offsetWidth / 2, cy = el.offsetTop + el.offsetHeight / 2; // центр значка
    el.style.setProperty('--kx', ((Math.random() < 0.5 ? -1 : 1) * (40 + Math.random() * 50)) + 'px');
    el.style.setProperty('--kr', ((Math.random() < 0.5 ? -1 : 1) * (240 + Math.random() * 200)) + 'deg');
    el.classList.remove('back'); el.classList.add('hit');
    // искры в цветах украшения + пара маленьких копий
    const add = (cls, html, css) => { const b = document.createElement('i'); b.className = cls; if (html) b.textContent = html; b.style.cssText = css; map.appendChild(b); setTimeout(() => b.remove(), 900); };
    for (let k = 0; k < 12; k++) {
      const a = k / 12 * TAU + Math.random() * 0.4, r = 34 + Math.random() * 34, col = cols[k % cols.length];
      add('spark', '', `left:${cx}px;top:${cy}px;background:${col};box-shadow:0 0 6px ${col};--dx:${Math.cos(a) * r}px;--dy:${Math.sin(a) * r}px;animation-duration:${0.5 + Math.random() * 0.3}s`);
    }
    for (let k = 0; k < 2; k++) {
      const a = -Math.PI / 2 + (k ? 0.8 : -0.8);
      add('spark g', glyph, `left:${cx}px;top:${cy}px;--dx:${Math.cos(a) * 46}px;--dy:${Math.sin(a) * 46}px;animation-duration:.7s`);
    }
    add('ringFx', '', `left:${cx}px;top:${cy}px;--rc:${cols[0]}`);
    // серия быстрых тапов – множитель
    const now = performance.now();
    decoCombo = now - decoComboT < 1600 ? decoCombo + 1 : 1; decoComboT = now;
    life('deco'); lifeMax('decoCombo', decoCombo); lifeSoon();
    if (decoCombo >= 2) add('comboFx', '×' + decoCombo + (decoCombo >= 5 ? '!' : ''), `left:${cx}px;top:${cy - 18}px`);
    if (glyph === '❄️' || glyph === '🌨️' || glyph === '🪞') Sound.sfx.glass(); else if (glyph === '🔥') Sound.sfx.fireball(); else Sound.sfx.shard();
    // через несколько секунд украшение возвращается
    setTimeout(() => { if (!el.isConnected) return; el.classList.remove('hit'); void el.offsetWidth; el.classList.add('back'); }, 5000 + Math.random() * 4000);
  }
  // живые украшения у медальонов: глаза в темноте, светлячки, диско-лучи, искры, следы лап, снег
  const EYES4 = side => [[side * 80, -52], [side * 120, 18], [-side * 110, 40]];
  function chapterFx(v, side) {
    const at = (x, y, extra = '') => `style="left:${Math.round(x)}px;top:${Math.round(y)}px;${extra}"`;
    const d = k => `animation-delay:${(-k).toFixed(2)}s;`;
    let h = '';
    if (v.n === 4) { // глаза – как раньше на карточке, видны даже у закрытой главы
      const [e1, e2, e3] = EYES4(side);
      h += `<div class="eyes2" ${at(e1[0] - 22, e1[1] - 6)}><i></i><i></i></div>`;
      h += `<div class="eyes2 s" ${at(e2[0] - 22, e2[1] - 6)}><i style="${d(1.3)}"></i><i style="${d(1.3)}"></i></div>`;
      if (v.open) h += `<div class="eyes2 g s" ${at(e3[0] - 22, e3[1] - 6)}><i style="${d(2.6)}"></i><i style="${d(2.6)}"></i></div>`;
    } else if (v.n === 6) { // снег – тоже виден заранее
      for (let k = 0; k < 7; k++) h += `<b class="sn" ${at(-70 + k * 22 + hash2(k, 6) * 10, -10 + hash2(6, k) * 20, d(k * 0.55))}></b>`;
    } else if (v.n === 7) { // пузыри и розовые крили кружат вокруг медальона
      for (let k = 0; k < 5; k++) h += `<b class="bub" ${at(-30 + k * 14, 10, d(k * 0.6))}></b>`;
      for (let k = 0; k < 3; k++) h += `<b class="kr" style="${d(k * 2.33)}">🦐</b>`;
    } else if (!v.open && v.n === 5) {
      for (let k = 0; k < 3; k++) h += `<b class="q" ${at(side * (55 + k * 22), -20 + k * 18, d(k * 1.1))}>?</b>`;
    } else if (v.open && v.n === 1) {
      for (let k = 0; k < 6; k++) h += `<b class="ff" ${at((hash2(k, 1) - 0.5) * 180, (hash2(1, k) - 0.5) * 110, d(k * 0.85))}></b>`;
    } else if (v.open && v.n === 2) {
      ['rgba(255,110,220,.45)', 'rgba(110,230,255,.45)', 'rgba(255,230,110,.45)'].forEach((col, k) => {
        h += `<b class="beam" style="background:linear-gradient(transparent, ${col});${d(k * 1.66)}"></b>`;
      });
      for (let k = 0; k < 4; k++) h += `<b class="tw" ${at((hash2(k, 2) - 0.5) * 150, (hash2(2, k) - 0.5) * 110, d(k * 0.45))}>✦</b>`;
    } else if (v.open && v.n === 3) {
      for (let k = 0; k < 6; k++) h += `<b class="em" ${at(-40 + k * 16, 22 - hash2(k, 3) * 12, d(k * 0.43))}></b>`;
    } else if (v.open && v.n === 5) {
      for (let k = 0; k < 4; k++) h += `<b class="paw" ${at(side * (52 + k * 22), 46 - k * 22, `transform:rotate(${side * 25}deg);` + `animation-delay:${(k * 0.5).toFixed(1)}s;`)}>🐾</b>`;
    }
    return `<div class="fx">${h}</div>`;
  }
  // оформление карточек глав – как раньше на старых карточках: глаза кошки, снег, огоньки…
  function sheetFx(n, open) {
    const P2 = (x, y, extra = '') => `style="left:${x}%;top:${y}%;${extra}"`, dl = k => `animation-delay:${(-k).toFixed(2)}s;`;
    let h = '';
    if (n === 4) {
      h += `<div class="lookA" ${P2(74, 16)}><div class="eyes2 big"><i></i><i></i></div></div>`;
      h += `<div class="lookB" ${P2(6, 44)}><div class="eyes2 s"><i style="${dl(1.7)}"></i><i style="${dl(1.7)}"></i></div></div>`;
      if (open) h += `<div class="lookA" ${P2(84, 62)}><div class="eyes2 g s"><i style="${dl(3.1)}"></i><i style="${dl(3.1)}"></i></div></div>`;
      for (let k = 0; k < 5; k++) h += `<b class="paw" ${P2(8 + k * 19, 88 - (k % 2) * 4, `transform:rotate(80deg);animation-delay:${(k * 0.45).toFixed(2)}s;`)}>🐾</b>`;
      if (open) h += '<b class="glitchLn"></b>';
    } else if (n === 6) {
      for (let k = 0; k < 18; k++) h += `<b class="sn sh" ${P2(Math.round(hash2(k, 61) * 98), 0, dl(hash2(61, k) * 4))}></b>`;
      h += '<b class="frost l"></b><b class="frost r"></b>';
    } else if (n === 7) { // пузыри поднимаются со дна
      for (let k = 0; k < 14; k++) h += `<b class="bub" ${P2(Math.round(hash2(k, 71) * 96), 92, dl(hash2(71, k) * 5))}></b>`;
    } else if (n === 5) {
      if (open) for (let k = 0; k < 5; k++) h += `<b class="paw" ${P2(6 + k * 20, 86 - (k % 2) * 5, `transform:rotate(70deg);animation-delay:${(k * 0.5).toFixed(2)}s;`)}>🐾</b>`;
      for (let k = 0; k < 4; k++) h += `<b class="q" ${P2([8, 86, 14, 80][k], [30, 26, 60, 58][k], dl(k * 0.9))}>?</b>`;
    } else if (!open) {
      return '';
    } else if (n === 1) {
      for (let k = 0; k < 9; k++) h += `<b class="ff" ${P2(Math.round(hash2(k, 11) * 94), Math.round(10 + hash2(11, k) * 75), dl(k * 0.6))}></b>`;
    } else if (n === 2) {
      ['rgba(255,110,220,.35)', 'rgba(110,230,255,.35)', 'rgba(255,230,110,.3)'].forEach((col, k) => {
        h += `<b class="swing" style="left:${[18, 50, 82][k]}%;background:linear-gradient(${col}, transparent);${dl(k * 1.1)}"></b>`;
      });
      for (let k = 0; k < 7; k++) h += `<b class="tw" ${P2(Math.round(hash2(k, 22) * 92), Math.round(8 + hash2(22, k) * 80), dl(k * 0.35))}>✦</b>`;
    } else if (n === 3 || n === 'rush') {
      for (let k = 0; k < 10; k++) h += `<b class="em tall${n === 'rush' ? ' red' : ''}" ${P2(Math.round(4 + k * 10 + hash2(k, 33) * 5), 96, dl(k * 0.37))}></b>`;
      if (n === 3) h += '<b class="shine"></b>';
    }
    return h;
  }
  let sheetCh = 0;
  function openChapterSheet(n) {
    const prof = loadProfile(), sh = $('chapSheet');
    sheetCh = n;
    const show = (id, on) => $(id).classList.toggle('hidden', !on);
    if (n === 'rush') {
      const rushOpen = DEBUG || prof.admin || prof.ch1Done, rb = prof.rushBest;
      sh.style.setProperty('--c1', '#ff8a6a'); sh.style.setProperty('--c2', '#8a1a1a'); sh.style.setProperty('--sc', '110,25,25');
      $('shIc').textContent = '⚔️'; $('shNum').textContent = 'Испытание'; $('shTitle').textContent = 'Босс-раш';
      $('shDesc').textContent = 'Все побеждённые боссы подряд, на время. У всех одинаковая героиня 24 уровня + твои таланты и реликвии';
      $('shStat').textContent = !rushOpen ? '🔒 Откроется после главы 1' : rb ? `🏆 Рекорд: ${rb.n}/${rb.total} боссов за ${fmtT(rb.time)}` : 'Рекорда пока нет';
      $('shPlay').textContent = rushOpen ? 'В бой!' : '🔒 Закрыто';
      const rhId = (prof.settings || {}).rushHero;
      $('rushHero').textContent = '🔄 ' + (HEROES[rhId] ? HEROES[rhId].name : 'Крилесса');
      show('shNew', false); show('shIntro', false); show('shMut', false); show('ch4Riddle', false); show('rushHero', rushOpen && !!(prof.ch3Done || DEBUG || prof.admin));
      $('shFx').innerHTML = sheetFx('rush', rushOpen);
    } else {
      const v = chapterView(n, prof);
      sh.style.setProperty('--c1', v.meta.c[0]); sh.style.setProperty('--c2', v.meta.c[1]); sh.style.setProperty('--sc', v.meta.sc);
      $('shIc').textContent = v.open ? v.meta.ic : (v.hidden ? '❔' : '🔒');
      $('shNum').textContent = 'Глава ' + n; $('shTitle').textContent = v.title; $('shDesc').textContent = v.desc; $('shStat').textContent = v.stat;
      $('shPlay').textContent = !v.open ? '🔒 Закрыто' : v.sv ? 'Продолжить' : 'Играть';
      show('shNew', v.open && !!v.sv); show('shIntro', v.done || DEBUG || !!prof.admin); show('shMut', v.done && !NET.on); show('ch4Riddle', n === 4 && !prof.ch4Done); show('rushHero', false);
      $('shFx').innerHTML = sheetFx(n, v.open);
    }
    setState('chapSheet');
  }
  function closeSheet() { setState('menu'); }
  // ---------- обновления через интернет (только в приложении на Android) ----------
  const kb = v => v >= 1048576 ? (v / 1048576).toFixed(1) + ' МБ' : Math.max(1, Math.round(v / 1024)) + ' КБ';
  function showUpdate() {
    const box = $('updBox'), u = G.update;
    if (!u || u.hiddenByUser || !['found', 'progress', 'ready', 'apk', 'loading', 'perm', 'installer', 'error'].includes(u.type)) { box.classList.add('hidden'); return; }
    const ic = $('updIc'), bar = $('updBar'), fill = $('updFill'), btns = box.querySelector('.updBtns');
    const quote = u.title ? `«${u.title}»` : '';
    let title = '', text = '', icon = '🔄', anim = 'spin', go = '', later = false, pct = -1;
    if (u.type === 'found' || u.type === 'progress') {
      title = `Обновление v${u.version}`;
      pct = u.total > 0 ? Math.min(100, Math.round(u.done / u.total * 100)) : -1;
      text = (quote ? quote + ' · ' : '') + (pct >= 0 ? `скачиваю ${pct}% · ${kb(u.done)} из ${kb(u.total)}` : 'скачиваю…');
    } else if (u.type === 'ready') {
      title = `Обновление v${u.version} готово!`; text = quote || 'Перезапусти – и играй в новой версии'; icon = '✨'; anim = 'bounce'; go = 'Перезапустить'; later = true; pct = 100;
    } else if (u.type === 'apk') {
      title = `Новая версия приложения v${u.version}`; text = (quote ? quote + ' · ' : '') + 'нужна переустановка, это быстро'; icon = '📦'; anim = 'bounce'; go = 'Скачать и установить'; later = true;
    } else if (u.type === 'loading') {
      title = 'Скачиваю приложение'; icon = '⬇️'; anim = 'bounce';
      pct = u.total > 0 ? Math.min(100, Math.round(u.done / u.total * 100)) : -1;
      text = pct >= 0 ? `${pct}% · ${kb(u.done)} из ${kb(u.total)}` : 'подожди немного…';
    } else if (u.type === 'perm') {
      title = 'Нужно разрешение'; text = 'Разреши установку приложений для Крилессы, вернись и нажми ещё раз'; icon = '🔐'; anim = ''; go = 'Установить';
    } else if (u.type === 'installer') {
      title = 'Почти готово'; text = 'Подтверди установку в окне Android'; icon = '📦'; anim = 'bounce'; go = 'Открыть ещё раз';
    } else {
      title = 'Не получилось скачать'; text = 'Проверь интернет и попробуй ещё раз'; icon = '⚠️'; anim = ''; go = 'Ещё раз'; later = true;
    }
    ic.textContent = icon; ic.className = anim;
    $('updTitle').textContent = title; $('updText').textContent = text;
    bar.classList.toggle('hidden', pct === -1 && !['found', 'progress', 'loading'].includes(u.type));
    bar.classList.toggle('indet', pct < 0);
    if (pct >= 0) fill.style.width = pct + '%';
    $('updGo').textContent = go; $('updGo').classList.toggle('hidden', !go); $('updLater').classList.toggle('hidden', !later);
    btns.classList.toggle('hidden', !go && !later);
    box.classList.remove('hidden');
  }
  window.krUpdate = u => {
    if (!u || !u.type) return;
    const prev = G.update;
    if (u.type === 'fail') { G.update = null; showUpdate(); if (prev) toast('⚠️ Обновление не скачалось – попробую в следующий раз'); return; }
    if (['found', 'progress', 'ready', 'apk', 'loading'].includes(u.type)) G.update = Object.assign({ base: u.type === 'loading' ? 'apk' : undefined }, prev && u.type === 'loading' ? { version: prev.version, title: prev.title } : {}, u);
    else if (prev) G.update = Object.assign({}, prev, { type: u.type, base: prev.base || prev.type });
    showUpdate();
    // в игре не мешаем – только короткая подсказка
    if (!['menu', 'chapSheet', 'splash', 'whatsnew'].includes(state)) {
      if (u.type === 'found' && !(prev && prev.type === 'found')) toast(`⬇️ Скачивается обновление v${u.version}…`);
      if (u.type === 'ready' && !(prev && prev.type === 'ready')) toast(`✨ Обновление v${u.version} готово – перезапусти в меню`);
      if (u.type === 'apk' && !(prev && prev.type === 'apk')) toast(`📦 Вышла новая версия приложения v${u.version}`);
    }
  };
  function updateSoundButtons() {
    const t = 'Звук: ' + (Sound.isEnabled() ? 'вкл' : 'выкл');
    $('btnSound').textContent = t; $('btnSound2').textContent = t;
  }
  const onTap = (id, fn) => $(id).addEventListener('click', () => { Sound.init(); Sound.sfx.click(); fn(); });
  const introOpen = n => { const pr = loadProfile(); return DEBUG || !!pr.admin || !!pr['ch' + n + 'Done']; };
  onTap('btnIntro', () => introOpen(1) ? Intro.start('ch1', openMenu) : toast('🔒 Интро 1 откроется после главы 1'));
  onTap('btnIntro2', () => introOpen(2) ? Intro.start('ch2', openMenu) : toast('🔒 Интро 2 откроется после главы 2'));
  onTap('btnIntro3', () => introOpen(3) ? Intro.start('ch3', openMenu) : toast('🔒 Интро 3 откроется после главы 3'));
  onTap('btnIntro4', () => introOpen(4) ? Intro.start('ch4', openMenu) : toast('🔒 Интро 4 откроется после главы 4'));
  onTap('btnIntro5', () => introOpen(5) ? Intro.start('ch5', openMenu) : toast('🔒 Интро 5 откроется после главы 5'));
  onTap('btnIntro6', () => introOpen(6) ? Intro.start('ch6', openMenu) : toast('🔒 Интро 6 откроется после главы 6'));
  onTap('btnIntro7', () => introOpen(7) ? Intro.start('ch7', openMenu) : toast('🔒 Интро 7 откроется после главы 7'));
  onTap('btnTalents', openTalents);
  // стартовый экран
  onTap('spMap', openMenu);
  $('splashCv').addEventListener('pointerdown', e => { // тап по героине – прыжок с сердечками
    Sound.init();
    const r = $('splashCv').getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top;
    for (const id of SP.heroes) {
      const p = SP.heroX && SP.heroX[id]; if (!p || Math.abs(x - p[0]) > 50 || Math.abs(y - p[1]) > 80) continue;
      if (SP.jump[id] > 0) continue;
      SP.jump[id] = 1; life('toss'); lifeSoon();
      for (let k = 0; k < 6; k++) SP.hearts.push({ x: p[0] + rnd(-24, 24), y: p[1] - 20, t: -k * 0.08, col: pick(['#ff5b8a', '#ff9ad8', '#ffd25a']) });
      if (id === 'tessa' && Sound.sfx.meow) Sound.sfx.meow(); else Sound.sfx.blink();
    }
  });
  onTap('updGo', () => {
    const A = window.KrilessaAndroid, u = G.update; if (!A || !u) return;
    const kind = u.base || u.type;
    if (kind === 'ready') {
      $('updOverlay').classList.remove('hidden'); Sound.sfx.superReady();
      setTimeout(() => { if (A.applyUpdate) A.applyUpdate(); }, 900);
      setTimeout(() => $('updOverlay').classList.add('hidden'), 6000);
    } else if (A.installApk) A.installApk();
  });
  onTap('updLater', () => { if (G.update) G.update.hiddenByUser = true; showUpdate(); toast('Хорошо! Обновление включится само при следующем запуске'); });
  // главный экран: карточка главы, панель, настройки
  onTap('shClose', closeSheet);
  $('shBack').addEventListener('click', closeSheet);
  onTap('shPlay', () => {
    if (sheetCh === 'rush') { const pr = loadProfile(); if (DEBUG || pr.admin || pr.ch1Done) startRush(); else toast('🔒 Босс-раш откроется после главы 1'); return; }
    if (!chapterOpen(sheetCh)) { toast(`🔒 Сначала пройди главу ${sheetCh - 1}`); return; }
    startChapter(sheetCh);
  });
  onTap('shNew', () => { const n = sheetCh; try { localStorage.removeItem(saveKey(n)); } catch (e) { /* ignore */ } startChapter(n); });
  onTap('shIntro', () => { const n = sheetCh; Intro.start('ch' + n, openMenu); });
  onTap('chapRush', () => openChapterSheet('rush'));
  onTap('mStars', openTalents);
  onTap('btnGear', () => setState('settings'));
  onTap('setBack', openMenu);
  const volLabel = () => { $('btnVol').textContent = '✨ Объёмная графика: ' + (volOn ? 'вкл' : 'выкл'); };
  // ---------- настройка джойстика: режим, размер, место (перетаскиванием) ----------
  const joyLabel = () => { const t = '🕹️ Джойстик: ' + (JOY.fixed ? 'закреплён' : 'плавающий'); $('btnJoy').textContent = t; $('btnJoy2').textContent = t; };
  let joyBack = 'settings';
  function saveJoy() { const pr = loadProfile(); pr.settings = pr.settings || {}; pr.settings.joy = { fixed: JOY.fixed, x: +JOY.x.toFixed(3), y: +JOY.y.toFixed(3), k: JOY.k }; saveProfile(pr); joyLabel(); }
  function joyEditPaint() {
    const el = $('jeStick'), r = JOY_R;
    el.style.width = el.style.height = r * 2 + 'px'; el.style.left = (JOY.x * VW - r) + 'px'; el.style.top = (JOY.y * VH - r) + 'px';
    el.querySelector('i').style.width = el.querySelector('i').style.height = 48 * JOY.k + 'px';
    el.classList.toggle('float', !JOY.fixed);
    for (const b of document.querySelectorAll('#jeMode button')) b.classList.toggle('on', (b.dataset.m === 'fixed') === JOY.fixed);
    for (const b of document.querySelectorAll('#jeSize button')) b.classList.toggle('on', +b.dataset.k === JOY.k);
    $('jeHint').textContent = JOY.fixed ? 'Перетащи круг туда, где удобно держать палец' : 'Плавающий – появляется там, где коснёшься. Круг показывает размер';
  }
  function openJoyEdit() { joyBack = state; setState('joyedit'); joyEditPaint(); }
  function closeJoyEdit() { saveJoy(); setState(joyBack); }
  (() => {
    const el = $('jeStick'); let drag = null;
    el.addEventListener('pointerdown', e => { e.preventDefault(); drag = { id: e.pointerId, dx: e.clientX - JOY.x * VW, dy: e.clientY - JOY.y * VH }; try { el.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ } el.classList.add('drag'); if (!JOY.fixed) { JOY.fixed = true; } joyEditPaint(); });
    el.addEventListener('pointermove', e => {
      if (!drag || e.pointerId !== drag.id) return;
      const r = JOY_R + 6;
      JOY.x = clamp(e.clientX - drag.dx, r, VW - r) / VW; JOY.y = clamp(e.clientY - drag.dy, VH * 0.3, VH - r) / VH; joyEditPaint();
    });
    const end = e => { if (drag && e.pointerId === drag.id) { drag = null; el.classList.remove('drag'); saveJoy(); } };
    el.addEventListener('pointerup', end); el.addEventListener('pointercancel', end);
    for (const b of document.querySelectorAll('#jeMode button')) b.addEventListener('click', () => { Sound.sfx.click(); JOY.fixed = b.dataset.m === 'fixed'; joyEditPaint(); saveJoy(); });
    for (const b of document.querySelectorAll('#jeSize button')) b.addEventListener('click', () => { Sound.sfx.click(); JOY.k = +b.dataset.k; JOY_R = 55 * JOY.k; joyEditPaint(); saveJoy(); });
  })();
  onTap('btnJoy', openJoyEdit); onTap('btnJoy2', openJoyEdit);
  onTap('jeDone', closeJoyEdit);
  onTap('jeReset', () => { applyJoy({ fixed: JOY.fixed }); joyEditPaint(); saveJoy(); });
  const miniLabel = () => { $('btnMini').textContent = '🗺️ Мини-карта: ' + (MM_STYLE === 'classic' ? 'классика' : MM_STYLE === 'paper' ? 'листок' : 'неон'); };
  onTap('btnMini', () => {
    MM_STYLE = MM_STYLE === 'paper' ? 'neon' : MM_STYLE === 'neon' ? 'classic' : 'paper'; const pr = loadProfile(); pr.settings = pr.settings || {}; pr.settings.mini = MM_STYLE; pr.settings.miniV = 2; saveProfile(pr); miniLabel();
    toast(MM_STYLE === 'classic' ? 'Классическая мини-карта – вся карта целиком' : MM_STYLE === 'paper' ? 'Мини-карта на листочке – местность вокруг и цели по краю 📜' : 'Неоновая мини-карта – местность вокруг и цели по краю ✨');
  });
  const styleLabel = () => { $('btnStyle').textContent = '🎨 Стиль: ' + (paperOn ? 'акварель' : 'классика'); };
  onTap('btnStyle', () => {
    const pr = loadProfile(); pr.settings = pr.settings || {}; pr.settings.style = paperOn ? 'classic' : 'paper';
    if (pr.settings.miniV !== 2) pr.settings.mini = pr.settings.style === 'paper' ? 'paper' : 'neon';
    saveProfile(pr); toast(pr.settings.style === 'paper' ? 'Книжная акварель – перезапускаю…' : 'Классический стиль – перезапускаю…');
    setTimeout(() => location.reload(), 700);
  });
  onTap('btnVol', () => {
    volOn = !volOn; const pr = loadProfile(); pr.settings = pr.settings || {}; pr.settings.vol = volOn; saveProfile(pr); volLabel();
    toast(volOn ? 'Объём включён ✨' : 'Объём выключен – так быстрее на слабых телефонах');
  });
  // ---------- режим админа: 5 касаний по номеру версии в меню ----------
  const ADMIN_HASH = 'xa5467';
  const passHash = str => { let x = 5381; for (const ch of str) x = ((x * 33) ^ ch.codePointAt(0)) >>> 0; return x.toString(36); };
  let verTaps = 0, verT = 0;
  $('menu').querySelector('.version').addEventListener('click', () => {
    const now = performance.now(); verTaps = now - verT < 1500 ? verTaps + 1 : 1; verT = now;
    if (verTaps >= 5) { verTaps = 0; openAdmin(); }
  });
  function openAdmin() {
    const on = !!loadProfile().admin;
    $('adminHint').className = 'hint';
    $('adminHint').textContent = on ? 'Режим админа включён ✅ Все главы, интро и босс-раш открыты' : 'Введи пароль – откроются все главы, интро и босс-раш';
    $('adminPass').classList.toggle('hidden', on); $('adminPass').value = '';
    $('adminOk').textContent = on ? 'Выключить' : 'Войти';
    setState('admin');
    if (!on) setTimeout(() => $('adminPass').focus(), 50);
  }
  function adminSubmit() {
    const pr = loadProfile();
    if (pr.admin) { delete pr.admin; LOOK_ALL = false; saveProfile(pr); toast('🔒 Режим админа выключен'); openMenu(); return; }
    if (passHash($('adminPass').value.trim().toLowerCase()) !== ADMIN_HASH) {
      $('adminHint').className = 'hint bad'; $('adminHint').textContent = 'Неверный пароль'; $('adminPass').value = ''; Sound.sfx.hurt(); return;
    }
    pr.admin = true; LOOK_ALL = true; saveProfile(pr); Sound.sfx.superReady();
    toast('🔓 Открыты все главы, интро и босс-раш'); openMenu();
  }
  onTap('adminOk', adminSubmit);
  onTap('adminBack', openMenu);
  $('adminPass').addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); adminSubmit(); } });
  onTap('talBack', openMenu);
  onTap('talReset', () => {
    const pr = loadProfile(); if (!talentSpent(pr.talents || {})) return;
    pr.talents = {};
    if ((pr.relics || []).length > 3) { pr.relics = pr.relics.slice(0, 3); toast('🎒 Четвёртый карман пуст – последняя реликвия убрана'); }
    saveProfile(pr); renderTalents();
  });
  onTap('rushHero', () => {
    const pr = loadProfile(); pr.settings = pr.settings || {};
    const list = ['krilessa', 'ryzhovaya'].concat(pr.ch4Done || DEBUG || pr.admin ? ['tessa'] : []);
    pr.settings.rushHero = list[(list.indexOf(pr.settings.rushHero || 'krilessa') + 1) % list.length]; saveProfile(pr); openChapterSheet('rush');
  });
  // ---------- ориентация экрана (в приложении 0.20+; в браузере экран и так поворачивается) ----------
  const ORIENT = { auto: '🔄 поворачивается', portrait: '📱 вертикально', landscape: '📺 горизонтально' };
  const orientBridge = () => { const A = window.KrilessaAndroid; return A && A.setOrientation ? A : null; };
  function orientMode() { const A = orientBridge(); try { return A ? A.orientation() || 'auto' : 'auto'; } catch (e) { return 'auto'; } }
  function orientLabel() { $('btnOrient').textContent = 'Экран: ' + ORIENT[orientMode()]; }
  onTap('btnOrient', () => {
    const A = orientBridge();
    if (!A) { toast(window.KrilessaAndroid ? '📲 Поворот экрана появится после обновления приложения (APK)' : '🔄 В браузере экран поворачивается сам'); return; }
    const order = ['auto', 'landscape', 'portrait'], next = order[(order.indexOf(orientMode()) + 1) % order.length];
    try { A.setOrientation(next); } catch (e) { /* ignore */ }
    setTimeout(orientLabel, 60); $('btnOrient').textContent = 'Экран: ' + ORIENT[next];
    toast(next === 'auto' ? '🔄 Экран поворачивается вместе с телефоном' : next === 'landscape' ? '📺 Всегда горизонтально' : '📱 Всегда вертикально');
  });
  // подсказка в начале главы: игру можно перевернуть (пока игрок сам ни разу не играл лёжа)
  let rotHintT = 0;
  function rotHintMaybe(tries = 0) {
    if (state !== 'play') { if (tries < 12 && (state === 'levelup' || state === 'relic' || state === 'pause')) setTimeout(() => rotHintMaybe(tries + 1), 1200); return; } // сначала выбор улучшения
    const pr = loadProfile();
    if (pr.rotSeen || VW > VH || orientMode() !== 'auto') return;
    if (window.KrilessaAndroid && !orientBridge()) return; // старое приложение – экран заперт вертикально
    const el = $('rotHint'); el.classList.remove('hidden', 'out');
    clearTimeout(rotHintT); rotHintT = setTimeout(rotHintHide, 4200);
  }
  function rotHintHide() { const el = $('rotHint'); if (el.classList.contains('hidden') || el.classList.contains('out')) return; el.classList.add('out'); clearTimeout(rotHintT); rotHintT = setTimeout(() => el.classList.add('hidden'), 420); }
  $('rotHint').addEventListener('pointerdown', ev => { ev.stopPropagation(); rotHintHide(); });
  window.addEventListener('resize', () => {
    if (VW <= VH || state !== 'play') return;
    rotHintHide();
    const pr = loadProfile(); if (!pr.rotSeen) { pr.rotSeen = true; saveProfile(pr); }
  });
  // ---------- уведомления «Вышла новая версия» (только в приложении 0.11+) ----------
  function notifyLabel(st) {
    const A = window.KrilessaAndroid, bt = $('btnNotify');
    if (!A || !A.notifyState) { bt.classList.add('hidden'); return; }
    try { st = st || A.notifyState(); } catch (e) { st = 'off'; }
    bt.classList.remove('hidden');
    bt.textContent = '🔔 Уведомления: ' + (st === 'on' ? 'вкл' : st === 'blocked' ? 'запрещены' : 'выкл');
  }
  window.krNotify = st => notifyLabel(st);
  onTap('btnNotify', () => {
    const A = window.KrilessaAndroid; if (!A || !A.setNotify) return;
    const st = A.notifyState();
    A.setNotify(st !== 'on');
    if (st === 'on') toast('🔕 Уведомления о новых версиях выключены');
    else if (st === 'blocked') toast('Разреши уведомления для Крилессы в настройках Android');
  });
  // ---------- кнопка сложности: у кринж-хардкора – налитые кровью «глаза» и кровь, которая капает на кнопки ниже ----------
  const DIFF_IC = { easy: '🍵', normal: '⚔️', hard: '😈' };
  function veinsSvg(w, h, base) { // красные прожилки, как на воспалённых белках глаз: от краёв к середине
    const out = [];
    const grow = (x, y, a, len, wd, depth, delay) => {
      let d = `M${x.toFixed(1)} ${y.toFixed(1)}`;
      for (let s = 0; s < len; s += 5) {
        a += rnd(-0.55, 0.55);
        x += Math.cos(a) * 5; y += Math.sin(a) * 5;
        if (y < 2 || y > h - 2) { a = -a; y = clamp(y, 2, h - 2); }
        d += ` L${x.toFixed(1)} ${y.toFixed(1)}`;
        if (depth < 2 && Math.random() < 0.17) grow(x, y, a + rnd(0.5, 1.1) * (Math.random() < 0.5 ? -1 : 1), len * rnd(0.3, 0.55), wd * 0.6, depth + 1, delay + (s / len) * 0.5);
      }
      out.push(`<path d="${d}" pathLength="1" stroke-width="${wd.toFixed(2)}" style="animation-delay:${(Math.max(0, base) + delay).toFixed(2)}s"/>`);
    };
    for (let i = 0; i < 4; i++) grow(0, rnd(6, h - 6), rnd(-0.5, 0.5), rnd(40, 85), 1.7, 0, rnd(0, 0.25));
    for (let i = 0; i < 4; i++) grow(w, rnd(6, h - 6), Math.PI + rnd(-0.5, 0.5), rnd(40, 85), 1.7, 0, rnd(0, 0.25));
    for (let i = 0; i < 3; i++) grow(rnd(w * 0.2, w * 0.8), h, -Math.PI / 2 + rnd(-0.6, 0.6), rnd(12, 24), 1.1, 1, rnd(0.2, 0.5));
    return `<svg class="veins${base >= 0 ? ' grow' : ''}" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none">${out.join('')}</svg>`;
  }
  function paintDiff(anim) {
    const id = (loadProfile().settings || {}).diff || 'normal', bt = $('btnDiff');
    bt.querySelector('.dfTx').textContent = `${DIFF_IC[id] || ''} Сложность: ${(DIFFS[id] || DIFFS.normal).name}`;
    bt.classList.remove('dEasy', 'dNormal', 'dHard', 'filling');
    bt.classList.add({ easy: 'dEasy', normal: 'dNormal', hard: 'dHard' }[id] || 'dNormal');
    clearTimeout(paintDiff.t);
    if (id === 'hard') {
      bt.querySelector('.dfVeins').innerHTML = veinsSvg(bt.offsetWidth || 300, bt.offsetHeight || 48, anim ? 0.55 : -1);
      if (anim) { void bt.offsetWidth; bt.classList.add('filling'); paintDiff.t = setTimeout(() => bt.classList.remove('filling'), 950); }
    } else bt.querySelector('.dfVeins').innerHTML = '';
    Blood.reset(id === 'hard' && state === 'settings', anim ? 0.8 : 0);
  }
  const Blood = (() => { // подтёки с низа кнопки, капли и пятна на кнопках ниже
    const BL = '#8e0612';
    let on = false, raf = 0, last = 0, t = 0, drips = [], drops = [], stains = [], bits = [], band = [];
    const clear = () => { const c = $('bloodCv'); c.getContext('2d').clearRect(0, 0, c.width, c.height); };
    function reset(enable, delay) {
      on = enable; drips = []; drops = []; stains = []; bits = []; t = -delay;
      clear();
      if (!on) { cancelAnimationFrame(raf); raf = 0; return; }
      const w = $('btnDiff').offsetWidth || 300, n = 8, longs = new Set();
      while (longs.size < 2) longs.add(Math.floor(rnd(0, n)));
      for (let i = 0; i < n; i++) drips.push({ x: 18 + (w - 36) * (i + rnd(0.15, 0.85)) / n, w: rnd(3.5, 7.5), len: longs.has(i) ? rnd(120, 230) : rnd(10, 70),
        cur: 0, d: rnd(0, 0.7), sp: rnd(0.6, 1.2), drop: rnd(0.8, 3), bulb: 1 });
      band = Array.from({ length: 16 }, (_, i) => ({ x: 12 + (w - 24) * i / 15, r: rnd(2.5, 6) }));
      if (!raf) { last = performance.now(); raf = requestAnimationFrame(loop); }
    }
    function drip(g, x, y0, w, len, bulb) {
      g.fillStyle = BL;
      g.beginPath(); g.moveTo(x - w / 2 - 3, y0); g.quadraticCurveTo(x - w / 2, y0 + 1, x - w / 2, y0 + 5);
      g.lineTo(x - w * 0.4, y0 + len); g.lineTo(x + w * 0.4, y0 + len); g.lineTo(x + w / 2, y0 + 5);
      g.quadraticCurveTo(x + w / 2, y0 + 1, x + w / 2 + 3, y0); g.closePath(); g.fill();
      const r = w * 0.62 * bulb;
      if (r > 0.5) { g.beginPath(); g.arc(x, y0 + len, r, 0, TAU); g.fill(); }
      g.fillStyle = 'rgba(255,120,130,.4)'; if (len > 8) g.fillRect(x - w * 0.28, y0 + 4, Math.max(1, w * 0.16), len - 6);
      if (r > 1.5) { g.fillStyle = 'rgba(255,255,255,.45)'; g.beginPath(); g.arc(x - r * 0.35, y0 + len - r * 0.3, r * 0.28, 0, TAU); g.fill(); }
    }
    function loop(now) {
      if (!on || state !== 'settings') { raf = 0; clear(); return; }
      raf = requestAnimationFrame(loop);
      const dt = Math.min(0.05, (now - last) / 1000); last = now; t += dt;
      const c = $('bloodCv'), g = c.getContext('2d'), dpr = Math.min(window.devicePixelRatio || 1, 2);
      const W = c.clientWidth, H = c.clientHeight;
      if (c.width !== Math.round(W * dpr) || c.height !== Math.round(H * dpr)) { c.width = Math.round(W * dpr); c.height = Math.round(H * dpr); }
      g.setTransform(dpr, 0, 0, dpr, 0, 0); g.clearRect(0, 0, W, H);
      if (t < 0) return; // кровь ещё заливает кнопку
      const cr = c.getBoundingClientRect(), br = $('btnDiff').getBoundingClientRect();
      const bx = br.left - cr.left, by = br.bottom - cr.top + 3; // низ «бортика» кнопки
      const tg = [...document.querySelectorAll('#settings .btn')].filter(b => b.id !== 'btnDiff').map(b => { const r = b.getBoundingClientRect(); return { l: r.left - cr.left, t: r.top - cr.top, r: r.right - cr.left }; });
      // кровь стекла через край
      g.fillStyle = BL; const k = Math.min(1, t * 2.5);
      g.fillRect(bx + 12, by - 5, (br.width - 24) * k, 5);
      for (const s of band) if (s.x <= (br.width - 12) * k + 12) { g.beginPath(); g.arc(bx + s.x, by - 1, s.r, 0, Math.PI); g.fill(); }
      for (const d of drips) {
        if (t < d.d) continue;
        d.cur = Math.min(d.len, d.cur + dt * d.sp * (14 + (d.len - d.cur) * 0.9));
        d.bulb = Math.min(1, d.bulb + dt * 0.8);
        if (d.cur >= d.len * 0.9 && (d.drop -= dt) <= 0) { // капля сорвалась
          drops.push({ x: bx + d.x, y: by + d.cur + d.w * 0.6, vy: 30, r: d.w * 0.6 });
          d.bulb = 0.25; d.drop = rnd(1.4, 4);
        }
        drip(g, bx + d.x, by, d.w, d.cur, d.bulb);
      }
      for (const p of drops) {
        const py = p.y; p.vy += 1100 * dt; p.y += p.vy * dt;
        for (let i = 0; i < tg.length; i++) {
          const T = tg[i];
          if (p.x > T.l + 6 && p.x < T.r - 6 && py < T.t + 3 && p.y >= T.t + 3) { // шлёп! пятно на кнопке
            const blobs = Array.from({ length: 3 + Math.floor(rnd(0, 4)) }, () => ({ ox: rnd(-7, 7), oy: rnd(-2, 4), r: rnd(1.5, 4.5) }));
            stains.push({ i, dx: p.x - T.l, dy: rnd(1, 7), blobs, len: 0, max: rnd(3, 20), w: rnd(2.5, 4.5) });
            if (stains.length > 36) stains.shift();
            for (let q = 0; q < 5; q++) bits.push({ x: p.x, y: T.t + 3, vx: rnd(-120, 120), vy: rnd(-170, -70), life: rnd(0.25, 0.45) });
            p.dead = true; break;
          }
        }
        if (p.y > H + 20) p.dead = true;
        if (!p.dead) { g.fillStyle = BL; g.beginPath(); g.ellipse(p.x, p.y, p.r, p.r * 1.35, 0, 0, TAU); g.fill(); }
      }
      drops = drops.filter(p => !p.dead);
      for (const s of stains) {
        const T = tg[s.i]; if (!T) continue;
        const x = T.l + s.dx, y = T.t + s.dy;
        s.len = Math.min(s.max, s.len + dt * 6);
        g.fillStyle = BL; for (const b of s.blobs) { g.beginPath(); g.arc(x + b.ox, y + b.oy, b.r, 0, TAU); g.fill(); }
        drip(g, x, y, s.w, s.len, 1);
      }
      for (const b of bits) { b.life -= dt; b.vy += 900 * dt; b.x += b.vx * dt; b.y += b.vy * dt; if (b.life > 0) { g.fillStyle = BL; g.beginPath(); g.arc(b.x, b.y, 1.6, 0, TAU); g.fill(); } }
      bits = bits.filter(b => b.life > 0);
    }
    function resume() { // те же подтёки и пятна, что были до ухода с экрана
      if (!on || !drips.length) return false;
      if (!raf) { last = performance.now(); raf = requestAnimationFrame(loop); }
      return true;
    }
    return { reset, resume };
  })();
  onTap('btnDiff', () => {
    const pr = loadProfile(); pr.settings = pr.settings || {};
    const order = ['easy', 'normal', 'hard'], cur = pr.settings.diff || 'normal';
    pr.settings.diff = order[(order.indexOf(cur) + 1) % 3]; saveProfile(pr);
    paintDiff(true);
    toast(pr.settings.diff === 'hard' ? 'Кринж-хардкор: враги злее, элита чаще 😈' : pr.settings.diff === 'easy' ? 'Лёгкий режим: можно расслабиться 🍵' : 'Нормальная сложность');
  });
  onTap('btnStats', openStats); onTap('btnStats2', openStats); onTap('btnStats3', openStats); onTap('btnStats4', openStats);
  onTap('statsShare', () => shareText(buildReport()));
  onTap('statsCopy', () => copyText(buildReport()));
  onTap('statsBack', () => { if (statsBack === 'menu') openMenu(); else setState(statsBack); });
  onTap('btnWhatsNew', () => openWhatsNew(null));
  onTap('wnClose', closeWhatsNew);
  onTap('ch4Riddle', openTeaser);
  onTap('relicMelt', () => { for (let i = 0; i < 12; i++) dropShard(P.x + rnd(-40, 40), P.y + rnd(-40, 40)); setState('play'); toast('💎 Реликвия переплавлена в 12 осколков'); });
  onTap('mapClose', () => setState('play'));
  initMapGestures();
  $('mapCanvas').addEventListener('click', () => setState('play'));
  onTap('btnIntros', () => setState('intros'));
  onTap('btnMP', openMP);
  onTap('btnModes', openModes); onTap('btnColl', openColl);
  onTap('modesBack', openMenu); onTap('collBack', openMenu);
  onTap('mdDefGo', () => startDefense());
  onTap('mdAbyssGo', () => startAbyss(abyssCkLoad())); onTap('mdAbyssNew', () => startAbyss()); onTap('mdDailyGo', startDaily);
  onTap('mdHero', () => { const pr = loadProfile(); pr.settings = pr.settings || {}; const list = ['krilessa', 'ryzhovaya'].concat(pr.ch4Done || DEBUG || pr.admin ? ['tessa'] : []);
    pr.settings.rushHero = list[(list.indexOf(rushHeroPick(pr)) + 1) % list.length]; saveProfile(pr); openModes(); });
  onTap('btnAch', () => { lifeFlush(); achCat = 'all'; renderAch(); setState('ach'); }); onTap('achBack', openColl);
  // слава: доска почёта и образ
  let lookBack = 'coll';
  function lookDone() { cancelAnimationFrame(lookRaf); if (lookBack === 'menu') openMenu(); else openColl(); }
  onTap('btnHall', () => openHall('rec'));
  onTap('btnRelics', () => { relicsFrom = 'coll'; openRelics(); }); onTap('relicsBack', () => relicsLeave());
  onTap('btnHome', () => openHome('coll')); onTap('mHome', () => openHome('menu'));
  onTap('homeBack', () => { cancelAnimationFrame(HOME.raf); if (HOME.back === 'menu') openMenu(); else openColl(); });
  onTap('homeEditBtn', () => { HOME.edit = !HOME.edit; $('homeEdit').classList.toggle('hidden', !HOME.edit); $('homeEditBtn').textContent = HOME.edit ? '✓ Готово' : '✏️ Обставить'; if (HOME.edit) renderHomeEdit(); });
  for (const k of ['furn', 'pets', 'wall']) onTap('heT_' + k, () => { HOME.tab = k; renderHomeEdit(); });
  $('homeCv').addEventListener('pointerdown', homeTap);
  onTap('seasonBar', () => { if (!SEASON_OFF) openSeason(); });
  onTap('seasonBack', openMenu);
  onTap('btnLook', () => { lookBack = 'coll'; openLook(); });
  onTap('mEmb', () => { lookBack = 'menu'; openLook(); });
  onTap('mRank', () => openHall('rec'));
  onTap('hallBack', openColl);
  onTap('lookBack', lookDone);
  onTap('hlTabR', () => { hallTab = 'rec'; Sound.sfx.click(); renderHall(); });
  onTap('hlTabF', () => { hallTab = 'fr'; Sound.sfx.click(); renderHall(); });
  for (const k of ['em', 'fr', 'ti', 'au']) onTap('lkT_' + k, () => { lookTab = k; Sound.sfx.click(); renderLook(); });
  $('lkName').addEventListener('change', () => {
    const pr = loadProfile(), v = ($('lkName').value || '').trim().slice(0, 14);
    pr.mp = Object.assign({ hero: 'krilessa' }, pr.mp || {}, { name: v || HEROES.krilessa.name }); saveProfile(pr); renderLook();
  });
  onTap('hlShare', () => {
    const code = cardCode(myCard());
    $('hlCode').value = code;
    try { if (window.KrilessaAndroid && window.KrilessaAndroid.share) { window.KrilessaAndroid.share('Моя карточка в Крилессе 🏅 Добавь меня на доску почёта:\n' + code); return; } } catch (e) { /* ignore */ }
    fallbackCopy(code); toast('📋 Код карточки скопирован – отправь подруге');
  });
  onTap('hlAdd', () => {
    const c = readCode($('hlCode').value);
    if (!c) { toast('Код не подошёл 🤔 Скопируй его целиком, начиная с KR1-'); Sound.sfx.block(); return; }
    if (c.id === loadProfile().pid) { toast('Это твоя карточка 😄'); return; }
    addFriends([c]); $('hlCode').value = ''; toast(`🎉 ${c.nm} теперь на доске почёта!`); Sound.sfx.superReady(); renderHall();
  });
  onTap('btnBook', () => openBook('e')); onTap('bookBack', () => bookLeave());
  onTap('bookTabE', () => { bookTab = 'e'; renderBook(); }); onTap('bookTabB', () => { bookTab = 'b'; renderBook(); }); onTap('bookTabV', () => { bookTab = 'v'; renderBook(); });
  onTap('bkClose', () => $('bkDetail').classList.add('hidden'));
  onTap('shMut', () => openMuts(sheetCh)); onTap('mutGo', mutGo); onTap('mutBack', () => { if (mutNet) { setState('mp'); mpRender(); } else openChapterSheet(mutCh); });
  onTap('btnVib', () => { const pr = loadProfile(); pr.settings = pr.settings || {}; vibOn = !((pr.settings.vib !== false)); pr.settings.vib = vibOn; saveProfile(pr); vibLabel(); if (vibOn) buzz(60); });
  onTap('mpHostBtn', mpHost);
  onTap('mpJoinBtn', mpScan);
  onTap('mpGo', mpGo);
  onTap('mpMut', () => { if (NET.host && !NET.started && typeof NET.ch === 'number') openMuts(NET.ch, true); });
  onTap('mpResume', () => { // продолжить сохранённую игру вместе (выбор, начинает «Готовы» / «Начать»)
    const sv = coopLoad(COOP_KEY); if (!NET.host || !sv || !CHAPTERS[sv.ch]) return;
    if (NET.resume) { NET.resume = null; } else { NET.resume = sv; NET.ch = sv.ch; toast('💾 Продолжим сохранённую игру – жмите «Готова»'); }
    for (const m of NET.peers.values()) m.rd = false; NET.rdy = false;
    mpRender(); mpLobbyBroadcast();
  });
  onTap('mpReady', mpToggleReady);
  onTap('mpBack', mpBack);
  onTap('mpIpGo', () => { const ip = ($('mpIp').value || '').trim(); if (!/^\d{1,3}(\.\d{1,3}){3}$/.test(ip)) { toast('Адрес вида 192.168.1.5'); return; } mpName(); mpJoin(ip, 0); });
  $('mpName').addEventListener('change', () => { mpName(); if (NET.client) { NET.card = myCard(); NetT.send(0, { t: 'me', name: NET.name, hero: NET.hero, cd: NET.card }); } if (NET.host) mpLobbyBroadcast(); });
  function mpBack() {
    if (NET.host || NET.client || NET.scanning) { mpLeave(); NET.scanning = false; mpRender(); if (state === 'mp') return; }
    openMenu();
  }
  onTap('introsBack', () => setState('menu'));
  onTap('choiceGood', () => finishCh4('good'));
  onTap('choiceKind', () => finishCh4('kind'));
  onTap('boardGo', () => { setState('play'); if (G.pendingLv > 0) openLevelUp(); });
  onTap('npcBtn', () => openNpc(G.nearNpc));
  onTap('btnWardrobe', openWardrobe);
  onTap('wardBack', () => { if (wardBack === 'menu') openMenu(); else setState(wardBack); });
  onTap('portalBtn', openPortals);
  onTap('portalBack', () => setState('play'));
  onTap('teaserBack', closeTeaser);
  onTap('krillBack', closeKrill);
  $('krillCanvas').addEventListener('pointerdown', e => {
    Sound.init();
    const r = $('krillCanvas').getBoundingClientRect(), x = (e.clientX - r.left) / r.width * 480, y = (e.clientY - r.top) / r.height * 640;
    KT.tap = { x, y, t: 0.35 }; life('krillTap'); lifeSoon();
    KT.pops.push({ x, y, t: 0, text: pick(KRILL_SAY) });
    for (let k = 0; k < 6; k++) KT.bubbles.push({ x: x + rnd(-20, 20), y: y + rnd(-10, 10), r: rnd(2, 5), v: rnd(60, 120) });
    Sound.sfx.shard();
  });
  $('teaserCanvas').addEventListener('pointerdown', () => { Sound.init(); Sound.sfx.meow(); teaserGlow = 1; });
  onTap('zmPlay', () => zmReact('Браво мне! БРАВО! Но спектакль ещё не окончен! 😈', true));
  onTap('zmLike', () => zmReact('Роза?! Мне?! ...Спасибо, зайка. Но тебя это не спасёт! 🌹😈', true));
  onTap('zmDonate', () => zmReact('ПОМИДОР?! В мою лучшую корону?! Ну всё!!! 🍅😤', true));
  $('zmExit').addEventListener('pointerdown', e => {
    e.preventDefault(); Sound.init(); Sound.sfx.click();
    if (!G.zm) return;
    G.zm.tries++;
    const el = $('zmExit');
    el.style.transform = `translate(${rnd(-110, 110)}px, ${rnd(-140, 60)}px) rotate(${rnd(-25, 25)}deg)`;
    el.textContent = ['✖ Выйти', 'Куда?! 😏', 'Не-не-не!', 'Выхода нет 😈'][Math.min(3, G.zm.tries)];
    if (G.zm.tries >= 3) { zmReact('Из театра не уходят посреди спектакля! Второй акт! 😈', true); lifeMax('escape', 1); }
  });
  // пасхалка: потыкай портрет в меню
  let portraitTaps = 0;
  $('menuPortrait').addEventListener('click', () => {
    portraitTaps++;
    if (portraitTaps % 7 === 0) {
      const c = $('menuPortrait').getContext('2d');
      if (IMG.zyama) c.drawImage(IMG.zyama.cartoon, 0, 0, 240, 320);
      Sound.init(); Sound.sfx.roar();
      toast('Зямочкккк: Эй! Не трогай её! Я ей, между прочим, стих посвятил! 😤');
      lifeMax('poke', 1); lifeSoon();
      setTimeout(drawMenuPortrait, 2200);
    }
  });
  onTap('btnSound', () => { Sound.setEnabled(!Sound.isEnabled()); updateSoundButtons(); });
  onTap('btnSound2', () => { Sound.setEnabled(!Sound.isEnabled()); updateSoundButtons(); });
  onTap('btnResume', resumeGame);
  onTap('btnToMenu', () => { saveGame(); openMenu(); });
  onTap('btnRetry', respawn);
  onTap('btnDeadMenu', () => { saveGame(); openMenu(); });
  onTap('btnVictoryMenu', openMenu);
  onTap('victoryNext', () => {
    if (NET.on && G.netRun) { if (NET.host && CHAPTERS[CHN + 1]) { NET.ch = CHN + 1; mpGo(); } else if (NET.client) toast('Следующую главу запустит хозяйка 🏠'); return; } // вместе: следующую главу запускает хозяйка
    startChapter(CHN + 1);
  });
  for (const el of document.querySelectorAll('.version')) el.textContent = 'v' + VERSION;

  window.krBack = () => {
    if (state === 'mp') { mpBack(); return 'handled'; }
    if (state === 'book' && !$('bkDetail').classList.contains('hidden')) { $('bkDetail').classList.add('hidden'); return 'handled'; }
    if (state === 'book' && bookBack === 'home') { bookLeave(); return 'handled'; }
    if (state === 'relics') { relicsLeave(); return 'handled'; }
    if (state === 'home') { if (HOME.edit) { $('homeEditBtn').click(); return 'handled'; } $('homeBack').click(); return 'handled'; }
    if (state === 'ach' || state === 'book' || state === 'hall') { openColl(); return 'handled'; }
    if (state === 'look') { lookDone(); return 'handled'; }
    if (state === 'season') { openMenu(); return 'handled'; }
    if (state === 'modes' || state === 'coll') { openMenu(); return 'handled'; }
    if (state === 'muts') { openChapterSheet(mutCh); return 'handled'; }
    if (state === 'stats') { if (statsBack === 'menu') openMenu(); else setState(statsBack); return 'handled'; }
    if (state === 'whatsnew') { closeWhatsNew(); return 'handled'; }
    if (state === 'teaser') { closeTeaser(); return 'handled'; }
    if (state === 'krill') { closeKrill(); return 'handled'; }
    if (state === 'choice' || state === 'relic') return 'handled';
    if (state === 'mapscr') { setState('play'); return 'handled'; }
    if (state === 'intros') { setState('menu'); return 'handled'; }
    if (state === 'talents' || state === 'admin') { openMenu(); return 'handled'; }
    if (state === 'joyedit') { closeJoyEdit(); return 'handled'; }
    if (state === 'chapSheet' || state === 'settings') { openMenu(); return 'handled'; }
    if (state === 'board') { if (G.accused) { setState('play'); if (G.pendingLv > 0) openLevelUp(); } return 'handled'; }
    if (state === 'npc') { setState('play'); return 'handled'; }
    if (state === 'wardrobe') { if (wardBack === 'menu') openMenu(); else setState(wardBack); return 'handled'; }
    if (state === 'portal') { setState('play'); return 'handled'; }
    if (state === 'zmenu') { zmReact('Кнопка «Назад» тоже моя! Сидеть и смотреть! 😈', true); lifeMax('escape', 1); return 'handled'; }
    if (state === 'victory' && $('victoryButtons').classList.contains('hidden')) return 'handled';
    if (state === 'play') { pauseGame(); return 'handled'; }
    if (state === 'pause') { resumeGame(); return 'handled'; }
    if (state === 'levelup') return 'handled';
    if (state === 'intro') { Intro.skip(); return 'handled'; }
    if (state === 'dead' || state === 'victory') { openMenu(); return 'handled'; }
    return 'exit';
  };
  window.krPause = () => { if (state === 'play') pauseGame(); Sound.suspend(); if (inRun()) liveWrite(true); };
  window.krResume = () => { Sound.resume(); if (inRun()) liveWrite(false); };
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) { if (state === 'play') pauseGame(); Sound.suspend(); if (inRun()) liveWrite(true); }
    else { Sound.resume(); if (inRun()) liveWrite(false); }
  });

  // ------------------------------------------------------------------
  //  Интро (две истории)
  // ------------------------------------------------------------------
  const Intro = (() => {
    const cv = $('introCanvas'), c = cv.getContext('2d');
    const STORIES = {
      ch1: {
        wipe: [2.9, 5.2], end: 14.6,
        scenes: [
          { at: 0, text: 'Это Рыжовая.<br>Самая обычная девушка…' },
          { at: 2.6, text: '…пока на неё не упала<br><b>волшебная искра</b>!', sfx: 'magic' },
          { at: 5.4, text: 'Теперь она – <b>мультяшная</b>!', sfx: 'level', flash: true },
          { at: 7.8, text: 'Но злой колдун <b>Мрак</b> похитил её<br>и запер в Тёмном замке!', sfx: 'roar' },
          { at: 11.0, text: 'Спасти её может только<br>отважная крылатая <b>Крилесса</b>!', music: 'menu' },
        ],
      },
      ch2: {
        wipe: [6.3, 8.4], end: 18.2,
        scenes: [
          { at: 0, text: 'Рыжовая спасена! Крилесса и Рыжовая<br>пьют какао и смотрят на звёзды…', music: 'menu' },
          { at: 3.0, text: '…как вдруг небо треснуло,<br>и из портала вылез <b>ОН</b>.', sfx: 'roar' },
          { at: 6.0, text: 'Мультяшная магия сделала его…<br><b>ещё кринжовее</b>!', sfx: 'magic' },
          { at: 8.6, text: '«Трепещите, зайки! Я – <b>ЗЯМОЧКККК</b>,<br>Император Кринжа!» 💅', sfx: 'level', flash: true, music: 'final' },
          { at: 11.8, text: '«Рыжовая будет слушать мои стихи.<br><b>ВЕЧНО!</b>»', sfx: 'gate' },
          { at: 14.8, text: '<b>Глава 2: Кринж-Цитадель</b><br>Крилесса, вперёд! Спаси её снова!' },
        ],
      },
      ch4: {
        end: 17,
        scenes: [
          { at: 0, text: 'Три часа ночи. Весь дом спит.<br>Тесса спит <b>двадцать часов в сутки</b>…', music: 'night4' },
          { at: 3.4, text: '…но этой ночью её разбудил<br><b>странный звук</b>.', sfx: 'staticNoise' },
          { at: 6.6, text: 'Лампочки мигают. Телевизор включился сам.<br>Из экрана смотрят <b>зелёные глаза</b>.', sfx: 'whisper' },
          { at: 10, text: '«Мяу. Я – <b>Мяу.exe</b>.<br>Теперь это <b>мой</b> дом.»', sfx: 'roar', flash: true, music: 'tv4' },
          { at: 13.4, text: '<b>Глава 4: Ночь глитчей</b><br>Тесса одна. Но она видит всё.', sfx: 'meow' },
        ],
      },
      ch5: {
        end: 16,
        scenes: [
          { at: 0, text: 'Утро. Солнце. Пахнет блинчиками…', music: 'morning5' },
          { at: 3.2, text: 'Тесса идёт к миске и видит…<br><b>ПУСТОТУ</b>.', sfx: 'roar' },
          { at: 6.4, text: 'Корм пропал. Из <b>всех</b> мисок в доме!', sfx: 'staticNoise' },
          { at: 9.4, text: 'Тесса надевает шапку детектива.<br>Это дело – для неё. 🕵️', sfx: 'magic', flash: true },
          { at: 12.6, text: '<b>Глава 5: Пропавший корм</b><br>Ищи улики. Допрашивай подозреваемых.', sfx: 'meow', music: 'detective5' },
        ],
      },
      ch6: {
        end: 16,
        scenes: [
          { at: 0, text: 'Лето. Банкет в честь Тессы.<br>Торт, музыка, все друзья вместе. 🎉', music: 'truewin' },
          { at: 3.2, text: 'И вдруг… пошёл снег.<br><b>В июле.</b>', sfx: 'whisper' },
          { at: 6.4, text: '«Новый сезон, – прошептал Мрак. –<br>Вечная <b>зима</b>.» 👑❄️', sfx: 'roar', flash: true, music: 'mrakboss' },
          { at: 9.6, text: 'Лёд сковал Тессу – и Мрак унёс её<br>в свой Ледяной замок!', sfx: 'shatter' },
          { at: 12.8, text: '<b>Глава 6: Мрак – новый сезон</b><br>Крилесса и Рыжовая – вместе! Меняйтесь кнопкой 🔄', sfx: 'magic', music: 'winter6' },
        ],
      },
      ch7: {
        end: 16,
        scenes: [
          { at: 0, text: 'Зима позади. Все трое – на море!<br>Тёплый песок, волны, мороженое. 🏖️', music: 'reef7' },
          { at: 3.2, text: 'И вдруг из-под воды раздалось:<br><b>«КРИЛЯТЬ!!!»</b> 🤬', sfx: 'roar', flash: true, music: 'krillboss' },
          { at: 6.4, text: 'Миллиарды розовых крилей утащили<br>на дно все <b>слова любви</b>. 💗', sfx: 'whisper' },
          { at: 9.6, text: 'Тесса надевает пузырь-шлем.<br>Ныряем! 🫧', sfx: 'magic' },
          { at: 12.8, text: '<b>Глава 7: Крилевая бездна</b><br>Течения, жемчужины – и кто-то очень ругучий на дне', sfx: 'level', flash: true, music: 'reef7' },
        ],
      },
      // финал главы 7: пляж на закате, Крильятин уплывает к солнцу
      end7: {
        end: 18,
        scenes: [
          { at: 0, text: 'Бездна затихла.<br>Все слова любви вернулись наверх… 💗', music: 'jelly7' },
          { at: 3.4, text: 'Подруги вынырнули у берега<br>как раз к <b>закату</b>. 🌅', sfx: 'magic' },
          { at: 6.8, text: '– Я просто хотел, чтобы меня<br><b>крилюбили</b>… – шмыгнул Крильятин.' },
          { at: 10.2, text: '– Мы тебя крилюбим! 💗<br>Крильятин покраснел – от смущения.', sfx: 'heart' },
          { at: 13.6, text: 'Король крилей уплыл в закат.<br>Впервые – без ругательств. 🌅', music: 'truewin' },
        ],
      },
      ch3: {
        wipe: [12.8, 14.8], end: 19,
        scenes: [
          { at: 0, text: 'Прошла неделя. Крилесса и Рыжовая –<br>теперь лучшие подруги.', music: 'menu' },
          { at: 3.0, text: 'Но вдруг из всех зеркал мира<br>раздалось: «<b>Трепещите, зайки!</b>»', sfx: 'roar' },
          { at: 6.2, text: '<b>Зямочкккк</b> сдержал слово и вернулся<br>в версии 0.03. Теперь он – <b>2.0</b>!', sfx: 'level', flash: true, music: 'final2' },
          { at: 9.2, text: 'Он затянул Крилессу в свой<br><b>Зеркальный Зямоверс</b>!', sfx: 'gate' },
          { at: 12.4, text: 'Но у Рыжовой есть секрет:<br>её волосы – <b>настоящий огонь</b>!', sfx: 'magic' },
          { at: 15.6, text: '<b>Глава 3: Рыжовая спешит на помощь</b><br>Теперь ты играешь за неё!', sfx: 'level', flash: true },
        ],
      },
    };
    let story = null, t = 0, last = 0, scene = -1, running = false, done = null, raf = 0, sparks = [], flash = 0, lightning = 0;
    function start(which, cb) {
      story = STORIES[which]; story.id = which; Dialog.clear(); $('introTap').classList.remove('ready');
      done = cb; t = 0; scene = -1; sparks = []; flash = 0; running = true;
      setState('intro');
      last = performance.now();
      cancelAnimationFrame(raf); raf = requestAnimationFrame(frame);
    }
    function skip() { if (running) finish(); }
    function finish() { running = false; cancelAnimationFrame(raf); if (done) done(); }
    // интро листается по касанию: сцена доигрывает анимацию и ждёт
    function boundary() { for (const s of story.scenes) if (s.at > t + 0.02) return s.at; return story.end; }
    function next() { t = boundary(); $('introTap').classList.remove('ready'); }
    cv.addEventListener('pointerdown', () => { Sound.init(); if (running) next(); });
    $('introSkip').addEventListener('click', () => { Sound.init(); skip(); });
    function setText(html) {
      const el = $('introText');
      el.style.opacity = 0;
      setTimeout(() => { el.innerHTML = html; el.style.opacity = 1; }, 200);
    }
    function frame(now) {
      if (!running) return;
      const dt = Math.min(0.05, (now - last) / 1000); last = now;
      if (t >= story.end) { finish(); return; }
      const lim = boundary() - 0.06;
      if (t + dt < lim) t += dt; else { t = Math.max(t, lim); $('introTap').classList.add('ready'); }
      let s = 0; for (let i = 0; i < story.scenes.length; i++) if (t >= story.scenes[i].at) s = i;
      if (s !== scene) {
        scene = s; const sc = story.scenes[s];
        setText(sc.text);
        if (sc.sfx) Sound.sfx[sc.sfx]();
        if (sc.flash) flash = 1;
        if (sc.music) Sound.music(sc.music);
        if (sc.sfx === 'roar') lightning = 0.6;
      }
      if (story.id === 'ch1') drawCh1(dt); else if (story.id === 'ch2') drawCh2(dt); else if (story.id === 'ch4') drawCh4(dt); else if (story.id === 'ch5') drawCh5(dt); else if (story.id === 'ch6') drawCh6(dt); else if (story.id === 'ch7') drawCh7(dt); else if (story.id === 'end7') drawEnd7(dt); else drawCh3(dt);
      if (paperOn) try { // интро – как иллюстрации в книге: зерно бумаги и тёплые края
        if (!PAPER.tex) PAPER.tex = paperTex();
        c.save(); c.setTransform(1, 0, 0, 1, 0, 0); c.globalCompositeOperation = 'multiply'; c.fillStyle = c.createPattern(PAPER.tex, 'repeat'); c.fillRect(0, 0, cv.width, cv.height);
        const vg = c.createRadialGradient(cv.width / 2, cv.height / 2, Math.min(cv.width, cv.height) * 0.38, cv.width / 2, cv.height / 2, Math.hypot(cv.width, cv.height) * 0.56);
        vg.addColorStop(0, 'rgba(255,255,255,1)'); vg.addColorStop(1, 'rgba(214,180,136,1)'); c.fillStyle = vg; c.fillRect(0, 0, cv.width, cv.height); c.restore();
      } catch (e) {}
      if (flash > 0) { c.setTransform(1, 0, 0, 1, 0, 0); c.fillStyle = `rgba(255,255,255,${flash})`; c.fillRect(0, 0, cv.width, cv.height); flash -= dt * 2; }
      raf = requestAnimationFrame(frame);
    }
    function setup() {
      const W = window.innerWidth, H = window.innerHeight, dpr = Math.min(window.devicePixelRatio || 1, 2);
      if (cv.width !== Math.round(W * dpr) || cv.height !== Math.round(H * dpr)) { cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr); }
      c.setTransform(dpr, 0, 0, dpr, 0, 0);
      return [W, H];
    }
    function bg(W, H, top, bottom) {
      const g = c.createLinearGradient(0, 0, 0, H);
      g.addColorStop(0, top); g.addColorStop(1, bottom);
      c.fillStyle = g; c.fillRect(0, 0, W, H);
      for (let i = 0; i < 60; i++) {
        const x = hash2(i, 1) * W, y = hash2(i, 2) * H, tw = 0.5 + 0.5 * Math.sin(t * 2 + i);
        c.fillStyle = `rgba(255,255,255,${0.15 + tw * 0.35})`; c.fillRect(x, y, 2, 2);
      }
    }
    // Полароид с фото; wipe 0..1 – превращение в мультик
    function card(img, cx, cy, cw, sc, rot, alpha, wipe, caption, cageK, sparkCols, dt) {
      const ch = cw * 4 / 3;
      c.save();
      c.translate(cx, cy); c.rotate(rot); c.scale(sc, sc);
      c.globalAlpha = alpha;
      c.fillStyle = 'rgba(0,0,0,0.4)'; c.fillRect(-cw / 2 - 4, -ch / 2 - 2, cw + 28, ch + 60);
      c.fillStyle = '#fff8ee'; c.fillRect(-cw / 2 - 12, -ch / 2 - 12, cw + 24, ch + 64);
      c.drawImage(wipe >= 1 ? img.cartoon : img.photo, -cw / 2, -ch / 2, cw, ch);
      const toX = u => -cw / 2 + u * cw, toY = v => -ch / 2 + v * ch;
      if (wipe > 0 && wipe < 1) {
        const dl = -0.12 + wipe * 1.24;
        c.save(); c.beginPath();
        c.moveTo(toX(2 * dl + 10), toY(-10)); c.lineTo(toX(-10), toY(2 * dl + 10)); c.lineTo(toX(-40), toY(-40)); c.closePath();
        c.clip(); c.drawImage(img.cartoon, -cw / 2, -ch / 2, cw, ch); c.restore();
        for (let k = 0; k < 4; k++) {
          const u = Math.random(), v = 2 * dl - u;
          if (v >= 0 && v <= 1) sparks.push({ x: toX(u), y: toY(v), vx: rnd(-40, 40), vy: rnd(-60, 20), life: rnd(0.4, 0.9), r: rnd(3, 8), rot: rnd(0, TAU), col: pick(sparkCols) });
        }
        c.save(); c.beginPath(); c.rect(-cw / 2, -ch / 2, cw, ch); c.clip();
        c.strokeStyle = 'rgba(255,240,180,0.9)'; c.lineWidth = 4;
        c.beginPath(); c.moveTo(toX(2 * dl), toY(0)); c.lineTo(toX(0), toY(2 * dl)); c.stroke();
        c.restore();
      }
      c.fillStyle = '#5a2a10'; c.textAlign = 'center';
      c.font = `bold ${Math.round(cw * 0.1)}px "Comic Sans MS", "Trebuchet MS", sans-serif`;
      c.fillText(caption, 0, ch / 2 + 36);
      if (cageK > 0) {
        const off = (1 - cageK) * -ch * 1.3;
        c.strokeStyle = '#3a3a48'; c.lineWidth = Math.max(5, cw * 0.03);
        for (let i = 0; i <= 6; i++) { const x = -cw / 2 - 6 + i * (cw + 12) / 6; c.beginPath(); c.moveTo(x, -ch / 2 - 16 + off); c.lineTo(x, ch / 2 + 50 + off); c.stroke(); }
        c.strokeStyle = '#ffd25a'; c.lineWidth = Math.max(7, cw * 0.04);
        c.beginPath(); c.moveTo(-cw / 2 - 16, -ch / 2 - 16 + off); c.lineTo(cw / 2 + 16, -ch / 2 - 16 + off); c.stroke();
        c.beginPath(); c.moveTo(-cw / 2 - 16, ch / 2 + 50 + off); c.lineTo(cw / 2 + 16, ch / 2 + 50 + off); c.stroke();
      }
      c.globalCompositeOperation = 'lighter';
      for (const s of sparks) {
        s.x += s.vx * dt; s.y += s.vy * dt; s.life -= dt; s.rot += dt * 4;
        c.globalAlpha = clamp(s.life, 0, 1); c.fillStyle = s.col;
        star(c, s.x, s.y, s.r, s.rot); c.fill();
      }
      sparks = sparks.filter(s => s.life > 0);
      c.globalCompositeOperation = 'source-over';
      c.restore();
    }
    function title(W, k, main, sub, col = '#ffd25a', glow = '#7a2a00') {
      c.globalAlpha = k; c.textAlign = 'center';
      const fs = Math.min(W * 0.12, 56);
      c.font = `900 ${fs}px "Trebuchet MS", sans-serif`;
      c.fillStyle = glow; c.fillText(main, W / 2, SAFE_TOP + fs + 50);
      c.fillStyle = col; c.fillText(main, W / 2, SAFE_TOP + fs + 46);
      if (sub) { c.font = `bold ${fs * 0.42}px "Trebuchet MS", sans-serif`; c.fillStyle = '#ffe8d0'; c.fillText(sub, W / 2, SAFE_TOP + fs * 1.6 + 50); }
      c.globalAlpha = 1;
    }
    function drawCh1(dt) {
      const [W, H] = setup();
      const dark = clamp((t - 7.6) / 0.8, 0, 1) * (1 - clamp((t - 11) / 1, 0, 1));
      bg(W, H, `rgb(${lerp(70, 15, dark) | 0},${lerp(30, 8, dark) | 0},${lerp(100, 30, dark) | 0})`, `rgb(${lerp(20, 5, dark) | 0},${lerp(8, 3, dark) | 0},${lerp(30, 10, dark) | 0})`);
      if (t > 7.8 && t < 11 && Math.random() < 0.02) lightning = 0.5;
      if (lightning > 0) { c.fillStyle = `rgba(200,170,255,${lightning * 0.6})`; c.fillRect(0, 0, W, H); lightning -= dt * 2; }
      const cw = Math.min(W * 0.7, H * 0.42 * 0.75), ch = cw * 4 / 3;
      let cx = W / 2, cy = H * 0.42, sc = 1;
      if (t < 0.9) sc = 0.85 + 0.15 * ease(t / 0.9);
      if (t >= 5.4 && t < 7.8) sc = 1 + 0.07 * Math.sin((t - 5.4) * 12) * Math.exp(-(t - 5.4) * 2.5);
      if (t > 8.6 && t < 9.4) cx += Math.sin(t * 60) * 6 * (9.4 - t);
      const titleK = ease((t - 11) / 1.0);
      cy -= titleK * H * 0.06; sc *= 1 - titleK * 0.22;
      const wipe = clamp((t - story.wipe[0]) / (story.wipe[1] - story.wipe[0]), 0, 1);
      card(IMG.ryzhova, cx, cy, cw, sc, -0.035, clamp(t / 0.8, 0, 1), wipe, t >= 5.4 ? '★ Рыжовая ★' : 'Рыжовая', ease((t - 8.1) / 0.5), ['#ffe066', '#ffb03a', '#fff3b0'], dt);
      if (t > 7.8 && t < 11.4) {
        const a = clamp((t - 7.8) / 0.6, 0, 1) * (1 - clamp((t - 10.8) / 0.6, 0, 1));
        c.fillStyle = `rgba(255,91,240,${a})`;
        const ey = H * 0.09 + SAFE_TOP;
        c.beginPath(); c.ellipse(W / 2 - 30, ey, 16, 7, 0.25, 0, TAU); c.ellipse(W / 2 + 30, ey, 16, 7, -0.25, 0, TAU); c.fill();
      }
      if (titleK > 0) {
        title(W, titleK, 'Крилесса', 'Спасение Рыжовой');
        const kx = lerp(-60, W * 0.78, ease((t - 11.2) / 1.4)), ky = cy + ch * sc * 0.66 + Math.sin(t * 3) * 8;
        drawKrilessa(c, kx, ky, t, 1, Math.min(4, W / 110), titleK, true);
      }
    }
    function drawCh2(dt) {
      const [W, H] = setup();
      const neon = clamp((t - 8.4) / 0.6, 0, 1);
      bg(W, H, neon > 0 ? `rgb(${lerp(42, 60, neon) | 0},${lerp(22, 10, neon) | 0},${lerp(64, 90, neon) | 0})` : '#2a1640', '#0a0614');
      if (lightning > 0) { c.fillStyle = `rgba(255,120,220,${lightning * 0.5})`; c.fillRect(0, 0, W, H); lightning -= dt * 2; }
      if (neon > 0) {
        for (let k = 0; k < 6; k++) {
          const a = t * 0.6 + k * TAU / 6;
          c.strokeStyle = k % 2 ? `rgba(255,62,165,${0.18 * neon})` : `rgba(63,240,255,${0.18 * neon})`; c.lineWidth = 30;
          c.beginPath(); c.moveTo(W / 2, H * 0.4); c.lineTo(W / 2 + Math.cos(a) * H, H * 0.4 + Math.sin(a) * H); c.stroke();
        }
      }
      const cw = Math.min(W * 0.62, H * 0.38 * 0.75);
      const ks = Math.min(4, W / 110);
      // Рыжовая (празднует, потом попадает в клетку)
      const move = ease((t - 11.8) / 1.2);
      const ryzX = lerp(W * 0.32, W * 0.5, move), ryzY = lerp(H * 0.62, H * 0.66, move);
      const ryzR = Math.min(W, H) * 0.13;
      if (t < 3.2 || t > 11.6) {
        const a = t < 3.2 ? 1 - clamp((t - 2.6) / 0.6, 0, 1) : clamp((t - 11.6) / 0.4, 0, 1);
        c.save(); c.globalAlpha = a;
        if (AVATAR.ryzhovaBig) { c.save(); c.beginPath(); c.arc(ryzX, ryzY, ryzR, 0, TAU); c.clip(); c.drawImage(AVATAR.ryzhovaBig, ryzX - ryzR, ryzY - ryzR, ryzR * 2, ryzR * 2); c.restore(); }
        c.strokeStyle = '#ff7a2f'; c.lineWidth = 5; c.beginPath(); c.arc(ryzX, ryzY, ryzR, 0, TAU); c.stroke();
        if (t > 12.6) {
          const k = ease((t - 12.6) / 0.5), off = (1 - k) * -H * 0.5;
          c.strokeStyle = '#ff3ea5'; c.lineWidth = 6;
          for (let i = 0; i <= 5; i++) { const x = ryzX - ryzR - 6 + i * (ryzR * 2 + 12) / 5; c.beginPath(); c.moveTo(x, ryzY - ryzR - 14 + off); c.lineTo(x, ryzY + ryzR + 10 + off); c.stroke(); }
          c.strokeStyle = '#3ff0ff'; c.lineWidth = 8; c.beginPath(); c.moveTo(ryzX - ryzR - 12, ryzY - ryzR - 14 + off); c.lineTo(ryzX + ryzR + 12, ryzY - ryzR - 14 + off); c.stroke();
        }
        c.restore();
      }
      if (t < 3.2) {
        const r0 = 1 - clamp((t - 2.6) / 0.6, 0, 1);
        drawKrilessa(c, W * 0.7, H * 0.64 + Math.sin(t * 3) * 6, t, -1, ks, r0, true);
        c.globalAlpha = r0;
        for (let i = 0; i < 6; i++) { c.fillStyle = '#ff5b8a'; heartPath(c, W * 0.5 + Math.sin(t * 2 + i) * 60, H * 0.55 - ((t * 40 + i * 30) % 140), 8); c.fill(); }
        c.globalAlpha = 1;
      }
      // портал
      const pk = clamp((t - 2.8) / 0.8, 0, 1) * (1 - clamp((t - 8.4) / 0.8, 0, 1));
      if (pk > 0) {
        const pr = Math.min(W, H) * 0.34 * pk;
        for (let k = 0; k < 5; k++) {
          c.strokeStyle = k % 2 ? 'rgba(255,62,165,0.8)' : 'rgba(63,240,255,0.8)'; c.lineWidth = 6;
          c.beginPath(); c.ellipse(W / 2, H * 0.38, pr * (1 - k * 0.15), pr * 0.75 * (1 - k * 0.15), t * (k % 2 ? 2 : -2), 0, TAU * 0.85); c.stroke();
        }
      }
      // карточка Зямочкккк
      if (t > 3.4 && t < 15.2) {
        const appear = ease((t - 3.4) / 1.4);
        let sc = 0.2 + 0.8 * appear;
        if (t >= 8.6 && t < 11) sc *= 1 + 0.08 * Math.sin((t - 8.6) * 12) * Math.exp(-(t - 8.6) * 2.5);
        let cy = H * 0.4;
        if (t > 11.8) { sc *= 1 - 0.3 * move; cy -= move * H * 0.12; }
        const fade = 1 - clamp((t - 14.6) / 0.6, 0, 1);
        const wipe = clamp((t - story.wipe[0]) / (story.wipe[1] - story.wipe[0]), 0, 1);
        card(IMG.zyama, W / 2, cy, cw, sc, 0.04 * Math.sin(t * 2), appear * fade, wipe, t >= 8.6 ? '★ ЗЯМОЧКККК ★' : '???', 0, ['#ff3ea5', '#3ff0ff', '#ffe04a'], dt);
        if (t >= 8.6) {
          c.save(); c.translate(W / 2, cy - cw * 4 / 3 * sc / 2 - 6); c.rotate(-0.15);
          const s = sc * cw / 140; c.scale(s, s); c.globalAlpha = fade;
          c.fillStyle = '#ffd25a'; c.strokeStyle = '#b8860b'; c.lineWidth = 3;
          c.beginPath(); c.moveTo(-36, 4); c.lineTo(-36, -28); c.lineTo(-18, -10); c.lineTo(0, -36); c.lineTo(18, -10); c.lineTo(36, -28); c.lineTo(36, 4); c.closePath(); c.fill(); c.stroke();
          c.fillStyle = '#ff3ea5'; c.beginPath(); c.arc(0, -8, 5, 0, TAU); c.fill();
          c.restore();
        }
      }
      if (t > 8.6 && t < 15) {
        for (let i = 0; i < 10; i++) {
          const spr = emojiSprite(ZYAMA_EMOJI[i % ZYAMA_EMOJI.length], 26);
          const a = t * 0.8 + i * TAU / 10, rr = Math.min(W, H) * 0.42;
          c.globalAlpha = 0.85; c.drawImage(spr, W / 2 + Math.cos(a) * rr - 20, H * 0.4 + Math.sin(a) * rr * 0.8 - 20, 40, 40); c.globalAlpha = 1;
        }
      }
      if (t >= 8.6 && t < 11.8) title(W, ease((t - 8.6) / 0.6), 'ЗЯМОЧКККК', 'Император Кринжа', '#ff3ea5', '#3a0a3a');
      if (t >= 14.8) {
        const k = ease((t - 14.8) / 0.8);
        title(W, k, 'Глава 2', 'Кринж-Цитадель', '#3ff0ff', '#0a2a4a');
        drawKrilessa(c, lerp(-60, W * 0.5, ease((t - 15) / 1.4)), H * 0.5 + Math.sin(t * 3) * 8, t, 1, Math.min(4.5, W / 100), k, true);
      }
    }
    let flames = [];

    // ---------- глава 4: ночь, телевизор сам включился ----------
    function drawCh4(dt) {
      const [W, H] = setup();
      bg(W, H, '#0a0a1e', '#020208');
      c.fillStyle = '#141432'; c.fillRect(W * 0.08, H * 0.12, W * 0.3, H * 0.2);
      c.fillStyle = '#e8e8ff'; c.beginPath(); c.arc(W * 0.23, H * 0.2, Math.min(W, H) * 0.035, 0, TAU); c.fill();
      c.strokeStyle = '#2a2a4a'; c.lineWidth = 4; c.strokeRect(W * 0.08, H * 0.12, W * 0.3, H * 0.2);
      c.beginPath(); c.moveTo(W * 0.23, H * 0.12); c.lineTo(W * 0.23, H * 0.32); c.stroke();
      const tvOn = t > 3.4, tx = W * 0.72, ty = H * 0.28, tw = Math.min(W * 0.4, 190), th = tw * 0.7;
      c.fillStyle = '#111'; roundRect(c, tx - tw / 2 - 8, ty - th / 2 - 8, tw + 16, th + 16, 10); c.fill();
      if (tvOn) {
        for (let i = 0; i < 240; i++) { const v = Math.random() * 255 | 0; c.fillStyle = `rgb(${v},${v},${v})`; c.fillRect(tx - tw / 2 + Math.random() * (tw - 5), ty - th / 2 + Math.random() * (th - 3), 5, 3); }
        c.fillStyle = 'rgba(255,255,255,0.06)'; c.beginPath(); c.moveTo(tx - tw / 2, ty + th / 2); c.lineTo(tx + tw / 2, ty + th / 2); c.lineTo(W, H); c.lineTo(0, H); c.closePath(); c.fill();
        if (t > 6.6) {
          const a = clamp((t - 6.6) / 1, 0, 1), bl = Math.sin(t * 3) > 0.95 ? 0.1 : 1;
          c.fillStyle = `rgba(63,240,160,${a})`; c.beginPath();
          c.ellipse(tx - tw * 0.17, ty, tw * 0.08, th * 0.15 * bl, 0, 0, TAU); c.ellipse(tx + tw * 0.17, ty, tw * 0.08, th * 0.15 * bl, 0, 0, TAU); c.fill();
          c.fillStyle = '#000'; c.fillRect(tx - tw * 0.18, ty - th * 0.13 * bl, 3, th * 0.26 * bl); c.fillRect(tx + tw * 0.16, ty - th * 0.13 * bl, 3, th * 0.26 * bl);
        }
      } else { c.fillStyle = '#06060c'; c.fillRect(tx - tw / 2, ty - th / 2, tw, th); }
      const bx = W * 0.5, by = H * 0.62, ks = Math.min(5, W / 70);
      c.fillStyle = '#4a2240'; c.beginPath(); c.ellipse(bx, by + ks * 3, ks * 16, ks * 6, 0, 0, TAU); c.fill();
      c.fillStyle = '#7a3a60'; c.beginPath(); c.ellipse(bx, by + ks * 2, ks * 12, ks * 4, 0, 0, TAU); c.fill();
      const awake = t > 3.4;
      drawTessa(c, bx, by, awake ? t : 0.4, awake && t > 6.6 ? 1 : -1, ks, 1, false);
      if (!awake) { c.fillStyle = '#bfd8ff'; c.font = `bold ${Math.round(14 + ks * 2)}px sans-serif`; c.textAlign = 'center'; c.fillText('z', bx + 30 + Math.sin(t * 2) * 6, by - 40 - (t * 20) % 40); c.fillText('Z', bx + 46, by - 64 - (t * 16) % 50); }
      if (t > 6.6 && Math.random() < 0.07) { c.fillStyle = 'rgba(0,0,0,0.65)'; c.fillRect(0, 0, W, H); }
      if (t > 10 && t < 13.4) {
        const a = clamp((t - 10) / 0.6, 0, 1) * clamp((13.4 - t) / 0.6, 0, 1), sz = Math.min(W, H) * 0.55;
        if (!AVATAR.glitchcat) AVATAR.glitchcat = bossPortrait('glitchcat');
        c.globalAlpha = a; c.drawImage(AVATAR.glitchcat, W / 2 - sz / 2 + (Math.random() < 0.2 ? rnd(-12, 12) : 0), H * 0.4 - sz / 2, sz, sz); c.globalAlpha = 1;
        for (let i = 0; i < 8; i++) { c.fillStyle = Math.random() < 0.5 ? 'rgba(63,240,160,0.25)' : 'rgba(255,62,165,0.25)'; c.fillRect(0, Math.random() * H, W, rnd(3, 18)); }
      }
      if (t > 13.4) { c.fillStyle = 'rgba(90,184,255,0.15)'; c.beginPath(); c.arc(bx + ks * 8, by - ks * 7, ks * 10 + Math.sin(t * 4) * 4, 0, TAU); c.fill(); }
    }
    // ---------- глава 5: утро, миски пусты ----------
    function drawCh5(dt) {
      const [W, H] = setup();
      const g = c.createLinearGradient(0, 0, 0, H); g.addColorStop(0, '#ffe9b8'); g.addColorStop(1, '#f2b880'); c.fillStyle = g; c.fillRect(0, 0, W, H);
      c.fillStyle = '#9ad8ff'; c.fillRect(W * 0.58, H * 0.1, W * 0.32, H * 0.2);
      c.fillStyle = '#ffe04a'; c.beginPath(); c.arc(W * 0.72, H * 0.18, Math.min(W, H) * 0.045 + Math.sin(t * 2) * 2, 0, TAU); c.fill();
      c.strokeStyle = '#ffffff'; c.lineWidth = 6; c.strokeRect(W * 0.58, H * 0.1, W * 0.32, H * 0.2);
      for (let i = 0; i < 12; i++) for (let j = 0; j < 6; j++) { c.fillStyle = (i + j) % 2 ? '#e8dcc8' : '#d0c4ae'; c.fillRect(i * W / 12, H * 0.62 + j * H * 0.07, W / 12 + 1, H * 0.07 + 1); }
      const ks = Math.min(5, W / 70), empty = t > 3.2;
      for (let k = 0; k < 3; k++) {
        const x = W * (0.22 + k * 0.28), y = H * 0.76;
        c.fillStyle = ['#ff6a8a', '#6ac8ff', '#ffd25a'][k]; c.beginPath(); c.ellipse(x, y, 34, 13, 0, 0, TAU); c.fill();
        c.fillStyle = empty ? '#3a2a20' : '#c87a3a'; c.beginPath(); c.ellipse(x, y - 3, 25, 8, 0, 0, TAU); c.fill();
        if (!empty) { c.fillStyle = '#a05a2a'; for (let m = 0; m < 6; m++) { c.beginPath(); c.arc(x - 12 + m * 5, y - 6 + (m % 2) * 2, 3, 0, TAU); c.fill(); } }
      }
      const det = t > 9.4;
      drawTessa(c, W * 0.5, H * 0.58, t, t > 6.4 && t < 9.4 ? (Math.sin(t * 2) > 0 ? 1 : -1) : 1, ks, 1, false, TESSA_PAL, det ? 'hat' : 'none');
      if (empty && !det) { c.fillStyle = '#5a2a10'; c.font = `900 ${Math.round(18 + ks * 4)}px sans-serif`; c.textAlign = 'center'; c.fillText('?!', W * 0.5 + 10, H * 0.58 - ks * 16); }
      if (t > 12.6) {
        const lx = W * 0.5 + Math.sin(t * 1.5) * W * 0.25, ly = H * 0.42 + Math.cos(t * 1.2) * 20;
        c.strokeStyle = '#6a4a2a'; c.lineWidth = 8; c.beginPath(); c.moveTo(lx + 26, ly + 26); c.lineTo(lx + 56, ly + 56); c.stroke();
        c.strokeStyle = '#d8a050'; c.lineWidth = 6; c.beginPath(); c.arc(lx, ly, 34, 0, TAU); c.stroke(); c.fillStyle = 'rgba(200,240,255,0.35)'; c.fill();
      }
    }
    function drawCh6(dt) {
      const [W, H] = setup();
      const ks = Math.min(4.2, W / 90), night = clamp((t - 3.2) / 3, 0, 1);
      const mix = (a, b) => `rgb(${a.map((v, i) => Math.round(lerp(v, b[i], night))).join(',')})`;
      const g = c.createLinearGradient(0, 0, 0, H); g.addColorStop(0, mix([255, 196, 140], [10, 20, 52])); g.addColorStop(1, mix([255, 150, 110], [30, 46, 90]));
      c.fillStyle = g; c.fillRect(0, 0, W, H);
      if (lightning > 0) { c.fillStyle = `rgba(190,234,255,${lightning * 0.5})`; c.fillRect(0, 0, W, H); lightning -= dt * 2; }
      // северное сияние
      if (night > 0.3) for (let k = 0; k < 3; k++) {
        c.strokeStyle = ['rgba(90,255,180,', 'rgba(120,200,255,', 'rgba(200,120,255,'][k] + (0.25 * night) + ')'; c.lineWidth = 26 - k * 6;
        c.beginPath(); for (let x = 0; x <= W; x += 20) { const y = H * (0.14 + k * 0.06) + Math.sin(x * 0.012 + t * 0.8 + k) * 22; if (x) c.lineTo(x, y); else c.moveTo(x, y); } c.stroke();
      }
      // земля: трава превращается в снег
      c.fillStyle = mix([110, 190, 90], [236, 244, 252]); c.fillRect(0, H * 0.7, W, H * 0.3);
      // банкет
      if (t < 9.6) {
        const tx = W * 0.5, ty = H * 0.66;
        c.fillStyle = '#c8945a'; c.fillRect(tx - W * 0.28, ty, W * 0.56, 10);
        c.fillStyle = '#ffffff'; c.fillRect(tx - 30, ty - 30, 60, 30); c.fillStyle = '#ff6fb5'; c.fillRect(tx - 30, ty - 30, 60, 8);
        c.fillStyle = '#ffd25a'; for (let k = -2; k <= 2; k++) c.fillRect(tx + k * 11 - 1, ty - 42, 3, 12);
        if (night < 0.5) for (let k = -2; k <= 2; k++) { c.fillStyle = '#ff8a2a'; c.beginPath(); c.arc(tx + k * 11, ty - 45 + Math.sin(t * 10 + k) * 1.5, 3, 0, TAU); c.fill(); }
      }
      const tY = t < 9.6 ? H * 0.6 : lerp(H * 0.6, H * 0.12, ease(clamp((t - 9.6) / 2.4, 0, 1)));
      if (t < 12.8) {
        drawTessa(c, W * 0.5, tY, t, 1, ks * 0.8, 1, false, TESSA_PAL, 'none');
        if (t >= 9.6) { c.fillStyle = 'rgba(170,220,255,0.5)'; c.strokeStyle = '#ffffff'; c.lineWidth = 2; roundRect(c, W * 0.5 - ks * 13, tY - ks * 26, ks * 26, ks * 30, 8); c.fill(); c.stroke(); }
      }
      // Мрак в ледяной короне
      if (t >= 6.4 && t < 12.8) {
        const a = clamp((t - 6.4) / 0.8, 0, 1) * (1 - clamp((t - 12) / 0.8, 0, 1));
        c.save(); c.globalAlpha = a; c.translate(W * 0.5, H * 0.24 + Math.sin(t * 2) * 6); c.scale(ks * 0.42, ks * 0.42);
        BSPR.mrak2(c, { kind: 'mrak2', flash: 0, stage: 2, look: 1.57, mode: 'idle', charging: false, anim: t, z: 0 }, t, 1);
        c.restore();
      }
      // героини
      const sep = t < 12.8 ? 0.3 : 0.2;
      drawHero('krilessa', c, W * (0.5 - sep), H * 0.66, t, 1, ks * 0.9, 1, t > 12.8);
      drawHero('ryzhovaya', c, W * (0.5 + sep), H * 0.66, t, -1, ks * 0.9, 1, t > 12.8);
      if (t < 3.2) for (let i = 0; i < 5; i++) { c.fillStyle = '#ff5b8a'; heartPath(c, W * 0.5 + Math.sin(t * 2 + i) * 70, H * 0.5 - ((t * 40 + i * 30) % 140), 7); c.fill(); }
      if (t >= 12.8) { c.font = `900 ${Math.round(24 + ks * 4)}px sans-serif`; c.textAlign = 'center'; c.fillStyle = '#ffffff'; c.fillText('🔄', W * 0.5, H * 0.6 + Math.sin(t * 4) * 4); }
      // снег
      if (t >= 3.2) {
        c.fillStyle = '#ffffff';
        for (let i = 0; i < 90; i++) {
          const x = (hash2(i, 1) * W + Math.sin(t + i) * 20 + t * 15) % W, y = (hash2(i, 2) * H + t * (40 + hash2(i, 3) * 60)) % H;
          c.globalAlpha = 0.5 + hash2(i, 4) * 0.5; c.beginPath(); c.arc(x, y, 1.5 + hash2(i, 5) * 2, 0, TAU); c.fill();
        }
        c.globalAlpha = 1;
      }
    }
    function drawCh7(dt) {
      const [W, H] = setup();
      const ks = Math.min(4.2, W / 90), dive = ease(clamp((t - 9.6) / 2.6, 0, 1)), dark = clamp((t - 3.2) / 1.2, 0, 1) * (1 - dive * 0.4);
      const shake = t >= 3.2 && t < 4.6 ? Math.sin(t * 60) * 5 * (4.6 - t) : 0;
      c.save(); c.translate(shake, 0);
      // небо и море; при нырке камера уходит под воду
      const sea = H * lerp(0.46, -0.1, dive);
      const g = c.createLinearGradient(0, 0, 0, H); g.addColorStop(0, `rgb(${lerp(255, 40, dark) | 0},${lerp(190, 60, dark) | 0},${lerp(140, 110, dark) | 0})`); g.addColorStop(1, `rgb(${lerp(255, 20, dark) | 0},${lerp(220, 40, dark) | 0},${lerp(180, 80, dark) | 0})`);
      c.fillStyle = g; c.fillRect(-10, 0, W + 20, H);
      if (lightning > 0) { c.fillStyle = `rgba(255,90,120,${lightning * 0.45})`; c.fillRect(-10, 0, W + 20, H); lightning -= dt * 2; }
      const wg = c.createLinearGradient(0, sea, 0, H); wg.addColorStop(0, '#1ab0d8'); wg.addColorStop(0.5, '#0a5a9a'); wg.addColorStop(1, '#03204a');
      c.fillStyle = wg; c.beginPath(); c.moveTo(-10, H); for (let x = -10; x <= W + 10; x += 10) c.lineTo(x, sea + Math.sin(x * 0.03 + t * 2) * 5); c.lineTo(W + 10, H); c.closePath(); c.fill();
      // лучи света под водой
      for (let k = 0; k < 4; k++) { const x0 = W * (0.15 + k * 0.25) + Math.sin(t * 0.5 + k) * 16; c.fillStyle = `rgba(180,240,255,${0.06 + dive * 0.06})`; c.beginPath(); c.moveTo(x0 - 10, Math.max(0, sea)); c.lineTo(x0 + 10, Math.max(0, sea)); c.lineTo(x0 + 70, H); c.lineTo(x0 - 50, H); c.closePath(); c.fill(); }
      // песок пляжа (уезжает вверх при нырке)
      const sandY = H * lerp(0.7, -0.3, dive);
      if (sandY > -40) { c.fillStyle = '#f0d49a'; c.beginPath(); c.moveTo(-10, sandY); c.quadraticCurveTo(W * 0.5, sandY - 30, W + 10, sandY + 10); c.lineTo(W + 10, sandY + 80); c.lineTo(-10, sandY + 80); c.closePath(); c.fill(); }
      // дно с кораллами – появляется при нырке
      if (dive > 0) {
        const fy = H * lerp(1.2, 0.8, dive);
        c.fillStyle = '#c8a46a'; c.beginPath(); c.moveTo(-10, H); c.lineTo(-10, fy); for (let x = 0; x <= W + 10; x += 20) c.lineTo(x, fy + Math.sin(x * 0.05) * 8); c.lineTo(W + 10, H); c.closePath(); c.fill();
        for (let k = 0; k < 6; k++) { const x = W * (0.08 + k * 0.17), h2 = 30 + hash2(k, 7) * 40; c.strokeStyle = ['#ff6f9a', '#ffa24a', '#c86aff'][k % 3]; c.lineWidth = 6; c.lineCap = 'round'; c.beginPath(); c.moveTo(x, fy + 6); c.quadraticCurveTo(x + Math.sin(t + k) * 10, fy - h2 / 2, x + 6, fy - h2); c.stroke(); }
      }
      // стая криля уносит сердечки-слова
      if (t >= 3.2) {
        const a = clamp((t - 3.2) / 1, 0, 1);
        for (let i = 0; i < 46; i++) {
          const ph = hash2(i, 21) * TAU, r = 30 + hash2(21, i) * 90, cx = W * 0.5 + Math.sin(t * 0.7) * W * 0.18, cy = Math.max(sea + 40, H * 0.62) + Math.cos(t * 0.5) * 30;
          const x = cx + Math.cos(ph + t * 1.1) * r, y = cy + Math.sin(ph * 1.7 + t * 1.3) * r * 0.5;
          c.globalAlpha = a; drawKrill(c, x, y, ph + t * 1.1 + Math.PI / 2, 0.9 + hash2(i, 22) * 0.5, t + ph); c.globalAlpha = 1;
        }
        if (t >= 6.4 && t < 9.6) for (let i = 0; i < 7; i++) { const k = clamp((t - 6.4 - i * 0.2) / 2.6, 0, 1); c.globalAlpha = 1 - k * 0.7; c.fillStyle = '#ff5b8a'; heartPath(c, W * (0.2 + i * 0.1), lerp(H * 0.4, H * 0.95, k), 8); c.fill(); c.globalAlpha = 1; }
      }
      // ругательство со дна
      if (t >= 3.2 && t < 6.4) {
        const a = Math.min(1, (t - 3.2) * 3) * (1 - clamp((t - 5.8) / 0.6, 0, 1));
        c.globalAlpha = a; c.font = `900 ${Math.round(22 + ks * 5)}px sans-serif`; c.textAlign = 'center'; c.fillStyle = '#ff3b5b'; c.strokeStyle = '#3a0010'; c.lineWidth = 5;
        c.strokeText('КРИЛЯТЬ!!!', W * 0.5, H * 0.3); c.fillText('КРИЛЯТЬ!!!', W * 0.5, H * 0.3); c.globalAlpha = 1;
      }
      // героини: на песке, потом плывут
      const hy = dive > 0 ? lerp(sandY - 10, H * 0.5, dive) : sandY - 10, bob = dive * Math.sin(t * 2) * 8;
      drawHero('krilessa', c, W * 0.28, hy + bob, t, 1, ks * 0.85, 1, t > 12.8);
      drawHero('ryzhovaya', c, W * 0.72, hy - bob, t, -1, ks * 0.85, 1, t > 12.8);
      drawTessa(c, W * 0.5, hy + 4 + Math.sin(t * 2.4) * 6 * dive, t, 1, ks * 0.7, 1, false, TESSA_PAL, 'none');
      if (t >= 9.6) { // пузырь-шлем
        const a = clamp((t - 9.6) / 0.5, 0, 1), R = ks * 13;
        c.globalAlpha = a; c.strokeStyle = 'rgba(220,250,255,0.9)'; c.lineWidth = 2.5; c.fillStyle = 'rgba(170,230,255,0.18)';
        c.beginPath(); c.arc(W * 0.5, hy - ks * 9, R, 0, TAU); c.fill(); c.stroke();
        c.fillStyle = 'rgba(255,255,255,0.7)'; c.beginPath(); c.ellipse(W * 0.5 - R * 0.45, hy - ks * 9 - R * 0.45, R * 0.18, R * 0.1, -0.7, 0, TAU); c.fill(); c.globalAlpha = 1;
      }
      // пузыри
      if (dive > 0) { c.strokeStyle = 'rgba(220,250,255,0.7)'; c.lineWidth = 1.4; for (let i = 0; i < 40; i++) { const k = (t * (0.12 + hash2(i, 31) * 0.15) + hash2(31, i)) % 1, x = hash2(i, 32) * W + Math.sin(t * 2 + i) * 6; c.beginPath(); c.arc(x, H * (1 - k), 1.5 + hash2(i, 33) * 4, 0, TAU); c.stroke(); } }
      c.restore();
    }
    function drawEnd7(dt) {
      const [W, H] = setup();
      const land = W > H, ks = Math.min(4.2, Math.min(W, H * 0.6) / 90), hor = H * (land ? 0.33 : 0.42), shore = H * (land ? 0.5 : 0.64), PW = Math.min(W, H * 0.62); // лёжа – всё выше, над текстом
      const R = Math.min(W, H) * 0.15, sunX = W * 0.5, sunY = hor - R * 0.35 + Math.min(t, 18) * R * 0.022; // солнце медленно садится
      // небо заката
      const g = c.createLinearGradient(0, 0, 0, hor);
      g.addColorStop(0, '#1c1046'); g.addColorStop(0.35, '#5a2470'); g.addColorStop(0.7, '#d8587a'); g.addColorStop(1, '#ffb46a');
      c.fillStyle = g; c.fillRect(0, 0, W, hor + 2);
      for (let i = 0; i < 26; i++) { c.fillStyle = `rgba(255,255,255,${(0.2 + 0.4 * Math.abs(Math.sin(t * 1.3 + i))) * (1 - hash2(i, 3) * 0.6)})`; c.fillRect(hash2(i, 1) * W, hash2(i, 2) * hor * 0.35, 1.6, 1.6); }
      // солнце и его сияние
      const sg = c.createRadialGradient(sunX, sunY, R * 0.6, sunX, sunY, R * 3.2); sg.addColorStop(0, 'rgba(255,210,120,0.55)'); sg.addColorStop(1, 'rgba(255,120,90,0)');
      c.fillStyle = sg; c.fillRect(0, 0, W, hor);
      const sd = c.createLinearGradient(0, sunY - R, 0, sunY + R); sd.addColorStop(0, '#fff6b0'); sd.addColorStop(1, '#ff7a4a');
      c.save(); c.beginPath(); c.rect(0, 0, W, hor); c.clip(); c.fillStyle = sd; c.beginPath(); c.arc(sunX, sunY, R, 0, TAU); c.fill(); c.restore();
      // облака, подсвеченные снизу
      for (let k = 0; k < 5; k++) {
        const cx = ((hash2(k, 5) * W * 1.4 + t * (6 + k * 2)) % (W * 1.4)) - W * 0.2, cy = hor * (0.25 + hash2(5, k) * 0.5), cw = W * (0.18 + hash2(k, 6) * 0.2);
        const cg = c.createLinearGradient(0, cy - 8, 0, cy + 8); cg.addColorStop(0, 'rgba(120,50,120,0.55)'); cg.addColorStop(1, 'rgba(255,150,140,0.75)');
        c.fillStyle = cg; c.beginPath(); c.ellipse(cx, cy, cw, 6 + hash2(k, 7) * 5, 0, 0, TAU); c.ellipse(cx + cw * 0.4, cy - 5, cw * 0.5, 5, 0, 0, TAU); c.fill();
      }
      // чайки
      c.strokeStyle = 'rgba(40,16,50,0.75)'; c.lineWidth = 2; c.lineCap = 'round';
      for (let k = 0; k < 4; k++) { const bx = ((t * (22 + k * 6) + hash2(k, 8) * W) % (W + 60)) - 30, by = hor * (0.2 + k * 0.12) + Math.sin(t * 2 + k) * 6, f = Math.sin(t * 7 + k) * 3, s2 = 5 + k; c.beginPath(); c.moveTo(bx - s2, by - f); c.quadraticCurveTo(bx - s2 * 0.4, by - 3, bx, by); c.quadraticCurveTo(bx + s2 * 0.4, by - 3, bx + s2, by - f); c.stroke(); }
      // море
      const sea = c.createLinearGradient(0, hor, 0, shore); sea.addColorStop(0, '#ff9a72'); sea.addColorStop(0.25, '#b05a8a'); sea.addColorStop(1, '#3a3a86');
      c.fillStyle = sea; c.fillRect(0, hor, W, shore - hor + 30);
      // солнечная дорожка и блики
      for (let y = hor + 2; y < shore; y += 4) {
        const k = (y - hor) / (shore - hor), half = R * (0.4 + k * 1.8), n = 3;
        for (let j = 0; j < n; j++) {
          const ph = hash2(Math.floor(y), j), x = sunX + (ph - 0.5) * 2 * half + Math.sin(t * 2 + y * 0.3 + j) * 6, a = (0.35 + 0.5 * Math.abs(Math.sin(t * 3 + y + j * 2))) * (1 - k * 0.5);
          c.fillStyle = `rgba(255,${220 - k * 60 | 0},${150 - k * 40 | 0},${a})`; c.fillRect(x - (4 + k * 10), y, 8 + k * 20, 1.6);
        }
      }
      c.strokeStyle = 'rgba(255,200,180,0.18)'; c.lineWidth = 1;
      for (let k = 0; k < 7; k++) { const y = hor + (shore - hor) * (0.15 + k * 0.12); c.beginPath(); for (let x = 0; x <= W; x += 12) { const yy = y + Math.sin(x * 0.04 + t * 1.5 + k) * 1.5; if (x) c.lineTo(x, yy); else c.moveTo(x, yy); } c.stroke(); }
      // Крильятин: у берега, потом уплывает к солнцу и тает вдали
      const away = ease(clamp((t - 13.6) / 4.2, 0, 1));
      const kx = lerp(W * 0.74, sunX - R * 0.1, away), ky = lerp(shore - 18, hor + 3, Math.pow(away, 0.8)) + Math.sin(t * 2.2) * 3 * (1 - away), ksc = ks * 0.3 * lerp(1, 0.12, away);
      const jumpK = clamp((away - 0.6) / 0.32, 0, 1), jump = Math.sin(jumpK * Math.PI); // напоследок – прыжок сквозь солнце
      if (jumpK > 0 && jumpK < 1) for (const k2 of [0, 1]) { const rk = Math.abs(jumpK - k2); if (rk < 0.25) { c.strokeStyle = `rgba(255,240,220,${0.8 * (1 - rk / 0.25)})`; c.lineWidth = 1.2; c.beginPath(); c.ellipse(kx + (k2 ? -6 : 6), ky + 2, 6 + (0.25 - rk) * 60, 2 + (0.25 - rk) * 6, 0, 0, TAU); c.stroke(); } }
      if (away > 0) { // след на воде
        c.strokeStyle = `rgba(255,230,200,${0.5 * (1 - away * 0.6)})`; c.lineWidth = 1.5;
        for (let k = 1; k <= 4; k++) { const d = (k * 14 + 6) * lerp(1, 0.15, away); c.beginPath(); c.moveTo(kx + d * 1.6, ky + d * 0.5); c.lineTo(kx, ky + 2); c.lineTo(kx + d * 0.4, ky + d * 0.9); c.stroke(); }
      }
      // стайка криля плывёт за королём
      for (let i = 0; i < 14; i++) { const a = t * 1.4 + i * 0.9, x = kx + ksc * 90 + Math.cos(a) * 20 * (1 - away * 0.8) + i * 3 * (1 - away), y = ky + 6 + Math.sin(a * 1.3) * 8 * (1 - away * 0.8); c.fillStyle = 'rgba(255,140,170,0.9)'; c.beginPath(); c.ellipse(x, y, 2.6 * (1 - away * 0.7), 1.2 * (1 - away * 0.7), a, 0, TAU); c.fill(); }
      c.save(); c.translate(kx, ky - jump * R * 1.05); c.scale(ksc, ksc);
      if (jump > 0) c.rotate((0.5 - jumpK) * 1.3); // нос вверх – нос вниз
      c.save();
      if (jump < 0.02) { c.beginPath(); c.rect(-140, -120, 280, 126); c.clip(); } // по пояс в воде
      const sil = clamp((away - 0.35) * 1.8, 0, 1); // у солнца – тёмный силуэт
      if (sil > 0) c.filter = `brightness(${lerp(1, 0.18, sil).toFixed(2)})`;
      BSPR.krillyatin(c, { kind: 'krillyatin', flash: 0, stage: 0, look: Math.PI, mode: 'idle', state: 'end', happy: t >= 10.2, anim: t, z: 0 }, t, 1);
      c.filter = 'none'; c.restore(); c.restore();
      if (jump < 0.02 && away < 1) { c.strokeStyle = 'rgba(255,240,220,0.7)'; c.lineWidth = 1.5; c.beginPath(); c.ellipse(kx, ky + 4, ksc * 70, 4 * (1 - away * 0.7), 0, 0, TAU); c.stroke(); }
      // берег: мокрый песок, пена, сухой песок
      const foam = shore + Math.sin(t * 0.9) * 7;
      const sand = c.createLinearGradient(0, shore, 0, H); sand.addColorStop(0, '#e8a872'); sand.addColorStop(0.3, '#f2c08a'); sand.addColorStop(1, '#b8785a');
      c.fillStyle = '#c8886a'; c.beginPath(); c.moveTo(0, foam + 4); for (let x = 0; x <= W; x += 10) c.lineTo(x, foam + 4 + Math.sin(x * 0.05 + t) * 3); c.lineTo(W, H); c.lineTo(0, H); c.closePath(); c.fill();
      c.fillStyle = sand; c.beginPath(); c.moveTo(0, shore + 16); c.quadraticCurveTo(W * 0.5, shore + 4, W, shore + 18); c.lineTo(W, H); c.lineTo(0, H); c.closePath(); c.fill();
      c.strokeStyle = 'rgba(255,255,255,0.85)'; c.lineWidth = 2.5; c.beginPath(); for (let x = 0; x <= W; x += 8) { const y = foam + Math.sin(x * 0.06 + t * 1.7) * 2.5; if (x) c.lineTo(x, y); else c.moveTo(x, y); } c.stroke();
      // ракушки и морская звезда
      for (const [fx, fy, e] of [[0.12, 0.86, '🐚'], [0.86, 0.8, '⭐'], [0.62, 0.93, '🐚']]) { c.font = `${Math.round(10 + ks * 3)}px sans-serif`; c.textAlign = 'center'; c.fillText(e, W * fx, H * fy); }
      // пальма-силуэт
      const px = land ? W * 0.12 : W * 0.08, py = H * 0.9, sw = Math.sin(t * 0.8) * 4, ph2 = land ? H * 0.5 : H * 0.34;
      c.strokeStyle = '#3a1634'; c.lineWidth = 7 + ks; c.lineCap = 'round'; c.beginPath(); c.moveTo(px, py); c.quadraticCurveTo(px + PW * 0.06, py - ph2 * 0.6, px + PW * 0.1 + sw, py - ph2); c.stroke();
      c.fillStyle = '#3a1634';
      for (let k = 0; k < 6; k++) { const a = -Math.PI / 2 + (k - 2.5) * 0.55 + Math.sin(t + k) * 0.04, tx = px + PW * 0.1 + sw, ty = py - ph2, L = PW * 0.16; c.beginPath(); c.moveTo(tx, ty); c.quadraticCurveTo(tx + Math.cos(a - 0.4) * L * 0.6, ty + Math.sin(a - 0.4) * L * 0.6 - 8, tx + Math.cos(a) * L, ty + Math.sin(a) * L + L * 0.25); c.quadraticCurveTo(tx + Math.cos(a + 0.3) * L * 0.5, ty + Math.sin(a + 0.3) * L * 0.5, tx, ty); c.fill(); }
      // подруги на песке машут вслед
      const hy = H * (land ? 0.6 : 0.71), hs = land ? H * 0.0046 : Math.min(ks * 0.58, H * 0.0034), wave = t >= 10.2 ? Math.sin(t * 6) * 3 : 0;
      for (const [id, fx2, face, ph] of [['krilessa', land ? 0.38 : 0.26, 1, 0], ['ryzhovaya', land ? 0.62 : 0.74, -1, 1.3]]) {
        c.fillStyle = 'rgba(60,20,40,0.28)'; c.beginPath(); c.ellipse(W * fx2, hy + 8, 20, 5, 0, 0, TAU); c.fill();
        drawHero(id, c, W * fx2, hy - Math.abs(t >= 10.2 ? Math.sin(t * 6 + ph) * 3 : 0), t, face, hs, 1, t >= 10.2);
      }
      c.fillStyle = 'rgba(60,20,40,0.28)'; c.beginPath(); c.ellipse(W * 0.5, hy + 14, 18, 4, 0, 0, TAU); c.fill();
      drawTessa(c, W * 0.5, hy + 6 - Math.abs(wave) * 0.5, t, 1, hs * 0.8, 1, false, TESSA_PAL, 'none');
      // сердечки летят к Крильятину
      if (t >= 10.2) for (let i = 0; i < 6; i++) { const k = ((t - 10.2) * 0.35 + i / 6) % 1; c.globalAlpha = Math.sin(k * Math.PI) * 0.9; c.fillStyle = i % 2 ? '#ff5b8a' : '#ff9ad0'; heartPath(c, lerp(W * (0.26 + (i % 3) * 0.24), kx, k) + Math.sin(t * 3 + i) * 10, lerp(hy - 50, ky - 20, k) - Math.sin(k * Math.PI) * 50, (6 + i % 3) * (1 - k * 0.5)); c.fill(); }
      c.globalAlpha = 1;
      // мягкая виньетка и проявление из темноты
      const vg = c.createRadialGradient(W / 2, H * 0.45, Math.min(W, H) * 0.3, W / 2, H / 2, Math.max(W, H) * 0.75); vg.addColorStop(0, 'rgba(0,0,0,0)'); vg.addColorStop(1, 'rgba(30,10,40,0.55)');
      c.fillStyle = vg; c.fillRect(0, 0, W, H);
      if (t < 1.2) { c.fillStyle = `rgba(6,20,40,${1 - t / 1.2})`; c.fillRect(0, 0, W, H); }
    }
    function drawCh3(dt) {
      const [W, H] = setup();
      const ks = Math.min(4, W / 110);
      const mir = clamp((t - 6) / 1, 0, 1) * (1 - clamp((t - 12.2) / 0.8, 0, 1));
      const fire = clamp((t - 12.2) / 0.8, 0, 1);
      const top = fire > 0 ? `rgb(${lerp(42, 110, fire) | 0},${lerp(30, 30, fire) | 0},${lerp(70, 20, fire) | 0})`
        : mir > 0 ? `rgb(${lerp(42, 70, mir) | 0},${lerp(22, 80, mir) | 0},${lerp(64, 120, mir) | 0})` : '#2a1640';
      bg(W, H, top, '#0a0614');
      if (lightning > 0) { c.fillStyle = `rgba(255,120,220,${lightning * 0.5})`; c.fillRect(0, 0, W, H); lightning -= dt * 2; }
      const cw = Math.min(W * 0.62, H * 0.38 * 0.75);
      // подруги вместе
      if (t < 3.4) {
        const a = 1 - clamp((t - 2.8) / 0.6, 0, 1), R = Math.min(W, H) * 0.12;
        c.globalAlpha = a;
        if (AVATAR.ryzhovaBig) { c.save(); c.beginPath(); c.arc(W * 0.32, H * 0.56, R, 0, TAU); c.clip(); c.drawImage(AVATAR.ryzhovaBig, W * 0.32 - R, H * 0.56 - R, R * 2, R * 2); c.restore(); }
        c.strokeStyle = '#ff7a2f'; c.lineWidth = 5; c.beginPath(); c.arc(W * 0.32, H * 0.56, R, 0, TAU); c.stroke();
        for (let i = 0; i < 6; i++) { c.fillStyle = '#ff5b8a'; heartPath(c, W * 0.5 + Math.sin(t * 2 + i) * 60, H * 0.5 - ((t * 40 + i * 30) % 140), 8); c.fill(); }
        c.globalAlpha = 1;
        drawKrilessa(c, W * 0.7, H * 0.6 + Math.sin(t * 3) * 6, t, -1, ks, a, true);
      }
      // зеркала
      if (t >= 3 && t < 6.4) {
        const k = ease((t - 3) / 0.6), out = 1 - clamp((t - 5.8) / 0.6, 0, 1);
        for (let i = 0; i < 6; i++) {
          const px = W * (0.2 + (i % 3) * 0.3), py = H * (0.24 + Math.floor(i / 3) * 0.3) + Math.sin(t * 6 + i) * 4;
          const pw = Math.min(W * 0.2, 90) * k, ph = pw * 1.8;
          c.save(); c.globalAlpha = out; c.translate(px, py); c.rotate(Math.sin(i * 2.1) * 0.2);
          c.fillStyle = '#d9a640'; c.beginPath(); c.ellipse(0, 0, pw / 2 + 5, ph / 2 + 5, 0, 0, TAU); c.fill();
          c.strokeStyle = '#7a4a10'; c.lineWidth = 2; c.stroke();
          if (pw > 4) {
            const g = Math.random() < 0.1 ? rnd(-4, 4) : 0;
            c.save(); c.beginPath(); c.ellipse(0, 0, pw / 2, ph / 2, 0, 0, TAU); c.clip();
            const mg = c.createLinearGradient(-pw / 2, -ph / 2, pw / 2, ph / 2); mg.addColorStop(0, '#bfe6ff'); mg.addColorStop(0.5, '#ff9ad8'); mg.addColorStop(1, '#6a4aa0');
            c.fillStyle = mg; c.fillRect(-pw / 2, -ph / 2, pw, ph);
            if (ART.zyamaFace) c.drawImage(ART.zyamaFace, -pw / 2 + 2 + g, -pw / 2 + ph * 0.18, pw - 4, pw - 4);
            c.fillStyle = 'rgba(255,255,255,0.35)'; c.beginPath(); c.ellipse(-pw * 0.18, -ph * 0.25, pw * 0.08, ph * 0.18, 0.4, 0, TAU); c.fill();
            c.restore();
          }
          c.restore();
        }
        c.globalAlpha = out; c.font = `900 ${Math.min(W * 0.09, 40)}px "Trebuchet MS", sans-serif`; c.textAlign = 'center';
        c.fillStyle = '#3a0a3a'; c.fillText('«Трепещите, зайки!»', W / 2 + 2, H * 0.84 + 2);
        c.fillStyle = '#ff3ea5'; c.fillText('«Трепещите, зайки!»', W / 2, H * 0.84);
        c.globalAlpha = 1;
      }
      // Зямочкккк 2.0
      if (t >= 6.2 && t < 12.6) {
        const ap = ease((t - 6.2) / 0.8), fade = 1 - clamp((t - 12) / 0.6, 0, 1);
        let sc = 0.3 + 0.7 * ap;
        if (t < 8) sc *= 1 + 0.08 * Math.sin((t - 6.2) * 12) * Math.exp(-(t - 6.2) * 2.5);
        const cy = t < 9.2 ? H * 0.42 : lerp(H * 0.42, H * 0.3, ease((t - 9.2) / 0.8));
        for (let k = 0; k < 8; k++) {
          const a = t * 1.2 + k * TAU / 8, rr = cw * 0.95;
          c.save(); c.globalAlpha = 0.8 * fade; c.translate(W / 2 + Math.cos(a) * rr, cy + Math.sin(a) * rr * 0.9); c.rotate(a);
          c.fillStyle = '#bfeaff'; c.beginPath(); c.moveTo(0, -14); c.lineTo(9, 0); c.lineTo(0, 14); c.lineTo(-9, 0); c.closePath(); c.fill();
          c.strokeStyle = '#fff'; c.lineWidth = 2; c.stroke(); c.restore();
        }
        card(IMG.zyama, W / 2, cy, cw * (t < 9.2 ? 1 : 0.8), sc, 0.04 * Math.sin(t * 2), ap * fade, 1, '★ ЗЯМОЧКККК 2.0 ★', 0, ['#bfeaff'], dt);
        if (t < 9.2) title(W, ease((t - 6.2) / 0.6), 'ЗЯМОЧКККК 2.0', 'Зеркальный Император', '#bfeaff', '#2a3a6a');
      }
      // Крилессу затягивает в зеркало
      if (t >= 9.2 && t < 12.6) {
        const k = ease((t - 9.6) / 2.2), out = 1 - clamp((t - 12) / 0.6, 0, 1);
        const mx = W / 2, my = H * 0.7, mr = Math.min(W, H) * 0.16;
        c.globalAlpha = out;
        c.fillStyle = '#ffd25a'; c.beginPath(); c.ellipse(mx, my, mr + 10, mr * 1.3 + 10, 0, 0, TAU); c.fill();
        const gr = c.createLinearGradient(mx - mr, my - mr, mx + mr, my + mr); gr.addColorStop(0, '#ffffff'); gr.addColorStop(0.5, '#9ad8f8'); gr.addColorStop(1, '#7a5aff');
        c.fillStyle = gr; c.beginPath(); c.ellipse(mx, my, mr, mr * 1.3, 0, 0, TAU); c.fill();
        for (let i = 0; i < 4; i++) { c.strokeStyle = `rgba(255,255,255,${0.5 - i * 0.1})`; c.lineWidth = 3; c.beginPath(); c.ellipse(mx, my, mr * (0.8 - i * 0.18), mr * 1.3 * (0.8 - i * 0.18), t * (i % 2 ? 2 : -2), 0, TAU * 0.8); c.stroke(); }
        c.globalAlpha = 1;
        c.save(); c.translate(lerp(W * 0.15, mx, k), lerp(my, my, k)); c.rotate(k * 6);
        drawKrilessa(c, 0, 0, t, 1, ks * (1 - k * 0.9), (1 - k * 0.8) * out, true);
        c.restore();
      }
      // огненное превращение Рыжовой
      if (t >= 12.2) {
        const ap = ease((t - 12.2) / 0.6);
        const tk = ease((t - 15.6) / 0.8);
        const cy = H * 0.42 - tk * H * 0.04, sc = (0.6 + 0.4 * ap) * (1 - tk * 0.2);
        if (Math.random() < 0.8) flames.push({ x: W / 2 + rnd(-cw * 0.6, cw * 0.6), y: cy + cw * 0.6, vy: rnd(-160, -60), r: rnd(6, 16), life: 1 });
        for (const f of flames) { f.y += f.vy * dt; f.life -= dt * 0.9; f.r *= 0.995; }
        flames = flames.filter(f => f.life > 0);
        c.globalCompositeOperation = 'lighter';
        for (const f of flames) { c.fillStyle = `rgba(255,${(120 + f.life * 100) | 0},40,${f.life * 0.5})`; c.beginPath(); c.arc(f.x, f.y, f.r, 0, TAU); c.fill(); }
        c.globalCompositeOperation = 'source-over';
        const wipe = clamp((t - story.wipe[0]) / (story.wipe[1] - story.wipe[0]), 0, 1);
        card(IMG.ryzhova, W / 2, cy, cw, sc, -0.03, ap, wipe, '🔥 Рыжовая 🔥', 0, ['#ff8a2a', '#ffd23a', '#ff4a1a'], dt);
        if (t >= 15.6) {
          title(W, tk, 'Глава 3', 'Рыжовая спешит на помощь', '#ff9a3a', '#5a1a00');
          drawRyzhovaya(c, lerp(-60, W * 0.76, ease((t - 15.8) / 1.4)), cy + cw * 4 / 3 * sc * 0.62 + Math.sin(t * 3) * 6, t, 1, ks * 1.1, tk, true);
        }
      }
    }
    return { start, skip };
  })();

  // ------------------------------------------------------------------
  //  Отладка (?debug)
  // ------------------------------------------------------------------
  const DEBUG = /[?&]debug/.test(location.search);
  function teleport(i) {
    const b = bosses[i];
    if (b.final) {
      for (let k = 0; k < bosses.length - 1; k++) { G.defeated[k] = true; bosses[k].state = 'dead'; }
      gateOpen = true; P.x = b.hx; P.y = b.hy + 220;
    } else { P.x = b.hx - 200; P.y = b.hy; }
  }
  function debugKey(code) {
    const m = code.match(/^Digit([1-5])$/);
    if (m && bosses[+m[1] - 1]) teleport(+m[1] - 1);
    if (code === 'KeyK' && G.activeBoss) { G.activeBoss.inv = false; damageBoss(G.activeBoss, { v: G.activeBoss.hp + 1, crit: false }); }
    if (code === 'KeyJ' && G.activeBoss) { const b = G.activeBoss; const st = b.def.stages[b.stage + 1]; if (st) b.hp = b.maxHp * st.at - 1; }
    if (code === 'KeyL') gainXp(P.xpNext);
    if (code === 'KeyG') P.inv = 9999;
  }

  // ------------------------------------------------------------------
  //  Главный цикл
  // ------------------------------------------------------------------
  let lastT = performance.now();
  function loop(now) {
    const dt = Math.min(0.05, (now - lastT) / 1000); lastT = now;
    try { netTick(dt); } catch (e) { console.error(e); }
    // вместе мир не замирает: пока одна выбирает улучшение, остальные играют
    const netLive = NET.on && G.netRun && state !== 'menu' && state !== 'victory' && state !== 'dead' && state !== 'intro' && state !== 'splash' && state !== 'mp';
    if (inRun()) liveTick(dt);
    if (NET.on && G.netRun && state === 'play' && now - (G.coopT || 0) > 15000) { G.coopT = now; coopSave(); } // вместе – сохраняемся раз в 15 секунд
    if (NET.on && NET.paused && state === 'play') pauseGame(false, NET.pauseBy); // вернулась с выбора улучшения посреди общей паузы
    if ((state === 'play' || state === 'dying' || netLive) && !(NET.on && NET.paused)) { try { pollKeys(); if (state === 'play' && Dialog.talking && !NET.on) Dialog.update(dt); else update(dt); } catch (e) { logErr(e, 'update'); } }
    if (state !== 'intro' && state !== 'teaser' && state !== 'splash' && state !== 'krill' && tiles) {
      // экраны поверх меню («Что нового», статистика) показывают тот же фон, без HUD
      const bg = G.inMenu && state !== 'play' && state !== 'dying', real = state;
      // под меню хватит 30 кадров в секунду – телефону легче, а движение плавное
      if (!bg || now - (G.bgT || 0) > 30) {
        try {
          if (bg) { G.bgT = now; state = 'menu'; updateCamera(); }
          ctx.setTransform(1, 0, 0, 1, 0, 0);
          renderWorld();
          paperPass();
        } catch (e) { logErr(e, 'render'); if (ctx.reset) ctx.reset(); } finally { state = real; }
        if (!bg) try { renderHUD(); } catch (e) { logErr(e, 'hud'); if (ctx.reset) ctx.reset(); }
      }
    }
    requestAnimationFrame(loop);
  }
  // журнал ошибок: последние 8 разных – попадают в «Статистику», чтобы их можно было прислать
  const ERR_KEY = 'krilessa_errlog', errSeen = new Set();
  function logErr(e, where) {
    try {
      if (where !== 'bg' && where !== 'crash' && where !== 'android') console.error(e); // записи чёрного ящика – не ошибки страницы
      const msg = String((e && e.message) || e).slice(0, 160), key = where + '|' + msg;
      if (errSeen.has(key)) return; errSeen.add(key);
      const stack = String((e && e.stack) || '').split('\n').slice(1, 3).map(x => x.trim().replace(/https?:\/\/[^/]+\/(assets\/game\/)?/g, '')).join(' < ');
      let L = []; try { L = JSON.parse(localStorage.getItem(ERR_KEY)) || []; } catch (x) { L = []; }
      L.unshift({ at: Date.now(), v: VERSION, w: where, st: state, ch: CHN, m: msg, s: stack.slice(0, 220) });
      localStorage.setItem(ERR_KEY, JSON.stringify(L.slice(0, 8)));
    } catch (x) { /* ignore */ }
  }
  // подсказка после запуска: ждёт, пока на экране меню и не висит другая подсказка
  function bootToast(msg, tries = 5) {
    setTimeout(() => {
      const calm = ['splash', 'menu', 'whatsnew'].includes(state), busy = !$('toast').classList.contains('hidden');
      if (calm && !busy) toast(msg); else if (tries > 0) bootToast(msg, tries - 1);
    }, tries === 5 ? 2500 : 2200);
  }
  const errLog = () => { try { return JSON.parse(localStorage.getItem(ERR_KEY)) || []; } catch (e) { return []; } };
  // чёрный ящик: пока идёт забег, раз в 5 с запоминаем, где мы и сколько всего вокруг.
  // Если приложение закроется посреди боя, при следующем запуске это попадёт в журнал сбоев
  const LIVE_KEY = 'krilessa_live';
  let liveT = 0;
  function liveWrite(bg) {
    try {
      const mem = performance.memory ? Math.round(performance.memory.usedJSHeapSize / 1048576) : 0;
      localStorage.setItem(LIVE_KEY, JSON.stringify({ at: Date.now(), v: VERSION, ch: G.td ? 'def' : CHN, st: state, w: G.abyss ? G.abyss.wave : 0, lv: P.level, en: G.enemies.length, pt: G.parts.length,
        b: G.activeBoss ? G.activeBoss.kind : '', mb: mem, t: Math.round((G.abyss && G.abyss.t) || (G.st && G.st.time) || 0), net: NET.on ? 1 : 0, bg: !!bg }));
    } catch (e) { /* ignore */ }
  }
  function liveTick(dt) { liveT -= dt; if (liveT <= 0) { liveT = 5; liveWrite(false); } }
  const liveClear = () => { try { localStorage.removeItem(LIVE_KEY); } catch (e) { /* ignore */ } };
  const inRun = () => !G.inMenu && !!G.st;
  // запуск: прошлый раз игра закрылась посреди забега?
  function liveCheck() {
    let m = null; try { m = JSON.parse(localStorage.getItem(LIVE_KEY)); } catch (e) { m = null; }
    liveClear();
    if (!m || !m.at) return null;
    const where = m.ch === 'def' ? `оборона, волна ${m.w}` : m.ch === 'abyss' ? `Бездна, волна ${m.w}` : m.ch === 'rush' ? 'босс-раш' : `глава ${m.ch}`;
    logErr(`${m.bg ? 'Игра закрыта, пока была свёрнута' : 'Игра закрылась посреди боя'}: ${where}${m.b ? ', бой с ' + m.b : ''} · экран ${m.st} · ур. ${m.lv} · врагов ${m.en} · частиц ${m.pt}` +
      `${m.mb ? ' · память ' + m.mb + ' МБ' : ''}${m.net ? ' · вместе' : ''} · ${fmtT(m.t)} от начала · v${m.v}`, m.bg ? 'bg' : 'crash');
    return m;
  }
  window.addEventListener('error', e => logErr(e.error || e.message, 'win'));
  window.addEventListener('unhandledrejection', e => logErr(e.reason, 'promise'));

  // ------------------------------------------------------------------
  //  0.30: вибрация, мутаторы, Бездна, испытание дня, достижения, Кринжопедия
  // ------------------------------------------------------------------
  // ---------- вибрация ----------
  let vibOn = null, buzzT = 0;
  function buzz(ms) {
    if (vibOn === null) vibOn = (loadProfile().settings || {}).vib !== false;
    if (!vibOn) return;
    const now = performance.now(); if (now - buzzT < 80) return; buzzT = now;
    const A = window.KrilessaAndroid;
    try { if (A && A.vibrate) A.vibrate(ms | 0); else if (navigator.vibrate) navigator.vibrate(ms | 0); } catch (e) { /* ignore */ }
  }
  function vibLabel() { if (vibOn === null) vibOn = (loadProfile().settings || {}).vib !== false; $('btnVib').textContent = '📳 Вибрация: ' + (vibOn ? 'вкл' : 'выкл'); }

  // ---------- мутаторы: пройденная глава заново, но с подвохом – за смелость звёзды ----------
  const MUTS = [
    { id: 'ng', ic: '💪', nm: 'Новая игра+', ds: 'Враги и боссы на 60% крепче и больнее бьют', pts: 2 },
    { id: 'fast', ic: '⚡', nm: 'Шустрые', ds: 'Враги бегают на 30% быстрее', pts: 1 },
    { id: 'boom', ic: '💥', nm: 'Взрывные', ds: 'Побеждённые враги взрываются – не стой рядом', pts: 1 },
    { id: 'dark', ic: '🌑', nm: 'Тьма', ds: 'Видно только вокруг героини', pts: 1 },
    { id: 'noheart', ic: '💔', nm: 'Без сердечек', ds: 'Сердечки не выпадают совсем', pts: 2 },
    { id: 'elite', ic: '👑', nm: 'Элита', ds: 'Элитных врагов втрое больше', pts: 1 },
    { id: 'glass', ic: '🩸', nm: 'Стеклянная пушка', ds: 'Урон ×1,5, но здоровье вдвое меньше', pts: 1 },
  ];
  const MUT_BY = Object.fromEntries(MUTS.map(m => [m.id, m]));
  const mutOn = id => !!(G.mut && G.mut[id]);
  const mutIds = () => G.mut ? Object.keys(G.mut).filter(k => G.mut[k]) : [];
  let mutCh = 1, mutSel = new Set();
  let mutNet = false;
  function openMuts(n, net) {
    mutCh = n; mutNet = !!net; const pr = loadProfile();
    mutSel = new Set((net ? NET.mut || [] : pr.mutSel || []).filter(id => MUT_BY[id]));
    renderMuts(); setState('muts');
  }
  function renderMuts() {
    const pr = loadProfile(), got = pr.starsGot || {};
    $('mutTitle').textContent = `🧪 Мутаторы · Глава ${mutCh}`;
    const box = $('mutList'); box.innerHTML = '';
    let pts = 0, newPts = 0;
    for (const m of MUTS) {
      const on = mutSel.has(m.id), earned = got[`m:${mutCh}:${m.id}:0`];
      if (on) { pts += m.pts; if (!earned) newPts += m.pts; }
      const el = document.createElement('button'); el.className = 'mutRow' + (on ? ' on' : '');
      el.innerHTML = `<i>${m.ic}</i><div><b>${m.nm}</b><span>${m.ds}</span></div><em>${earned ? '✓' : '+' + m.pts + '⭐'}</em>`;
      el.addEventListener('click', () => { if (mutSel.has(m.id)) mutSel.delete(m.id); else mutSel.add(m.id); Sound.sfx.click(); renderMuts(); });
      box.appendChild(el);
    }
    $('mutGo').textContent = mutNet ? (mutSel.size ? `✓ Играть вместе с мутаторами (${mutSel.size})` : '✓ Без мутаторов') : mutSel.size ? `▶ Играть с мутаторами (${mutSel.size})` : 'Выбери хотя бы один';
    $('mutGo').classList.toggle('gray', !mutSel.size && !mutNet);
    $('mutInfo').textContent = mutSel.size ? (newPts ? `Пройдёшь главу – получишь +${newPts} ⭐ для талантов` : 'За эти мутаторы звёзды уже получены – играй ради рекорда!') : 'Звёзды за каждый мутатор даются один раз за главу';
  }
  function mutGo() {
    if (mutNet) { NET.mut = [...mutSel]; const pr = loadProfile(); pr.mutSel = [...mutSel]; saveProfile(pr); for (const m of NET.peers.values()) m.rd = false; NET.rdy = false; setState('mp'); mpRender(); mpLobbyBroadcast(); return; }
    if (!mutSel.size) return;
    const pr = loadProfile(); pr.mutSel = [...mutSel]; saveProfile(pr);
    try { localStorage.removeItem(saveKey(mutCh)); } catch (e) { /* ignore */ }
    G.mutNext = [...mutSel];
    startChapter(mutCh);
  }
  // награда за пройденную с мутаторами главу
  function mutReward() {
    G.mutEarned = 0;
    const ids = mutIds(); if (!ids.length || typeof CHN !== 'number' || G.daily) return;
    const pr = loadProfile(); pr.starsGot = pr.starsGot || {};
    for (const id of ids) { const m = MUT_BY[id]; for (let k = 0; k < m.pts; k++) { const key = `m:${CHN}:${id}:${k}`; if (!pr.starsGot[key]) { pr.starsGot[key] = 1; G.mutEarned++; } } }
    pr.stars = Object.keys(pr.starsGot).length; saveProfile(pr);
    lifeMax('mutMax', ids.length);
  }

  // ---------- Бездна: волна за волной на арене ----------
  CHAPTERS.abyss = Object.assign({}, CHAPTERS.rush, { id: 'abyss', title: 'Бездна', name: 'Бездна', rush: false, abyss: true,
    bosses: [], bossTiles: [], bossLevels: [], spawnEvery: 9999, capBase: 0, music: 'abyss7' });
  const rushHeroPick = pr => { const rhs = (pr.settings || {}).rushHero; return rhs === 'tessa' && (pr.ch4Done || DEBUG || pr.admin) ? 'tessa' : rhs === 'ryzhovaya' && (pr.ch3Done || DEBUG || pr.admin) ? 'ryzhovaya' : 'krilessa'; };
  function abyssPool(pr) {
    const types = new Set(), kinds = [];
    for (const n of CH_NUMS) {
      const C = CHAPTERS[n], done = pr['ch' + n + 'Done'] || DEBUG || pr.admin;
      if (!done && !chapterOpen(n)) continue;
      for (const [b] of C.biomeSeeds) if (b !== C.castle.biome && SPAWNS[b]) for (const [t] of SPAWNS[b]) if (ENEMIES[t]) types.add(t);
      if (done) C.bosses.slice(0, -1).forEach(k => { if (BOSSES[k] && !BOSSES[k].immortal) kinds.push(k); });
    }
    if (!kinds.length) kinds.push(...CHAPTERS[1].bosses.slice(0, -1));
    return { types: [...types], kinds };
  }
  // Бездна сохраняется после каждой пройденной волны: после вылета или выхода в меню можно продолжить
  const ABYSS_CK = 'krilessa_abyss_ck';
  function abyssCkLoad() { try { const c = JSON.parse(localStorage.getItem(ABYSS_CK)); return c && c.v === 1 && c.wave > 0 && HEROES[c.hero] ? c : null; } catch (e) { return null; } }
  function abyssCkClear() { try { localStorage.removeItem(ABYSS_CK); } catch (e) { /* ignore */ } }
  function abyssCkSave() {
    const A = G.abyss; if (!A || A.done) return;
    const ck = { v: 1, wave: A.wave, t: Math.round(A.t), kills: G.kills, hero: P.hero, level: P.level, xp: P.xp, up: P.up, bonus: P.bonus, shards: P.shards,
      hpF: P.maxHp ? clamp(P.hp / P.maxHp, 0, 1) : 1, sp: P.sp || 0, pend: G.pendingLv || 0, ph: !!G.phoenixUsed, sw: !!G.secondUsed, combo: G.bestCombo || 0, better: !!A.better, at: Date.now() };
    try { localStorage.setItem(ABYSS_CK, JSON.stringify(ck)); } catch (e) { /* ignore */ }
  }
  // рекорд пишется сразу после волны – вылет его уже не сотрёт
  function abyssRecord(wave) {
    const A = G.abyss, pr = loadProfile(), best = pr.abyssBest;
    if (!best || wave > best.wave || (wave === best.wave && A.t < best.time)) { pr.abyssBest = { wave, time: Math.round(A.t), hero: P.hero, kills: G.kills }; saveProfile(pr); A.better = true; }
  }
  // музыка Бездны: спокойные треки всех открытых глав в перемешанном порядке, а у стражей – разные боевые темы
  const ABYSS_SKIP = new Set(['boss', 'menu', 'win', 'truewin', 'zyamashow', 'ultimate', 'final', 'final2', 'final5', 'meowboss', 'mrakboss', 'krillboss']);
  function abyssDecks(pr) {
    const amb = new Set(['abyss7']), boss = ['boss'];
    for (const n of CH_NUMS) {
      const C = CHAPTERS[n], done = pr['ch' + n + 'Done'] || DEBUG || pr.admin;
      if (!done && !chapterOpen(n)) continue;
      for (const id of [C.music, C.castle ? BIOME_MUSIC[C.castle.biome] : '', ...C.biomeSeeds.map(([bm]) => BIOME_MUSIC[bm])]) if (id && Sound.has(id) && !ABYSS_SKIP.has(id)) amb.add(id);
      if (!done) continue;
      const fin = BOSSES[C.bosses[C.bosses.length - 1]] || {}; // финальная тема главы – в награду тем, кто её прошёл
      const fm = fin.music || (n === 3 ? 'final2' : 'final');
      if (Sound.has(fm) && !boss.includes(fm)) boss.push(fm);
    }
    return { amb: [...amb], boss };
  }
  function abyssNextTrack() {
    const A = G.abyss; if (!A || !A.mus) return;
    if (!A.bag || !A.bag.length) { // мешок: каждый трек прозвучит, прежде чем какой-то повторится
      A.bag = A.mus.amb.slice();
      for (let i = A.bag.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [A.bag[i], A.bag[j]] = [A.bag[j], A.bag[i]]; }
      if (A.bag.length > 1 && A.bag[A.bag.length - 1] === A.track) A.bag.unshift(A.bag.pop());
    }
    A.track = A.bag.pop(); A.trackT = 0;
    if (!G.activeBoss) Sound.music(A.track);
  }
  function abyssBossTrack() {
    const A = G.abyss, d = A.mus.boss;
    let t = d[Math.floor(Math.random() * d.length)];
    if (d.length > 1 && t === A.bossTrack) t = d[(d.indexOf(t) + 1 + Math.floor(Math.random() * (d.length - 1))) % d.length];
    A.bossTrack = t; return t;
  }
  function startAbyss(ck) {
    const pr = loadProfile();
    if (!(pr.ch1Done || DEBUG || pr.admin)) { toast('🔒 Бездна откроется после главы 1'); return; }
    if (!ck) abyssCkClear(); // новый забег – старое сохранение больше не нужно
    const A = CHAPTERS.abyss; A.bosses = []; A.bossTiles = []; A.bossLevels = []; A.hero = ck ? ck.hero : rushHeroPick(pr);
    loadChapter('abyss'); resetRun();
    beginPlay();
    gateOpen = true;
    G.abyss = { wave: 0, rest: 2.5, t: 0, state: 'rest', pool: abyssPool(pr) };
    G.st = newRunStats();
    if (ck) {
      P.level = ck.level || 1; P.xp = ck.xp || 0; P.xpNext = xpFor(P.level); P.up = ck.up || {}; P.bonus = ck.bonus || {}; P.shards = ck.shards || 0;
      computeStats(); P.hp = Math.max(1, Math.round(P.maxHp * clamp(+ck.hpF || 1, 0.05, 1))); P.sp = ck.sp || 0;
      G.kills = ck.kills || 0; G.phoenixUsed = !!ck.ph; G.secondUsed = !!ck.sw; G.bestCombo = ck.combo || 0; G.pendingLv = ck.pend || 0;
      G.abyss.wave = ck.wave; G.abyss.t = ck.t || 0; G.abyss.rest = 3.5; G.abyss.better = !!ck.better;
      showBanner('🕳️ Бездна', `Продолжаем: впереди волна ${ck.wave + 1}`);
      if (G.pendingLv > 0) setTimeout(() => { if (state === 'play' && G.abyss) openLevelUp(); }, 700);
    } else showBanner('🕳️ Бездна', 'Волна за волной – как долго продержишься?');
    G.abyss.mus = abyssDecks(pr); abyssNextTrack();
  }
  function abyssSpot(minR, maxR) {
    for (let k = 0; k < 40; k++) {
      const a = rnd(0, TAU), r = rnd(minR, maxR), x = P.x + Math.cos(a) * r, y = P.y + Math.sin(a) * r;
      const tx = Math.floor(x / T), ty = Math.floor(y / T);
      if (Math.abs(tx - CASTLE.x) < CASTLE.half - 1 && Math.abs(ty - CASTLE.y) < CASTLE.half - 1 && walkable(x, y, false)) return { x, y };
    }
    return { x: tc(CASTLE.x) + rnd(-200, 200), y: tc(CASTLE.y) + rnd(-200, 200) };
  }
  function abyssWave() {
    const A = G.abyss; A.wave++; A.state = 'fight';
    const E = Math.round(3 + A.wave * 1.25), n = Math.min(44, 6 + A.wave * 2), boss = A.wave % 5 === 0;
    for (let i = 0; i < (boss ? Math.ceil(n / 3) : n); i++) {
      const type = pick(A.pool.types), s = abyssSpot(260, 520);
      spawnEnemy(type, s.x, s.y, CASTLE.biome, { E, elite: Math.random() < 0.04 + A.wave * 0.008 });
    }
    if (boss) {
      const kind = pick(A.pool.kinds), s = abyssSpot(220, 300);
      CFG.bosses = [kind]; CFG.bossLevels = [E + 2]; CFG.bossTiles = [{ x: Math.floor(s.x / T), y: Math.floor(s.y / T) }]; G.defeated = [false];
      makeBosses(); const b = bosses[0]; b.x = b.hx = s.x; b.y = b.hy = s.y;
      startBossFight(b);
      showBanner(`🕳️ Волна ${A.wave}`, `${b.name} поднимается из бездны!`);
    } else showBanner(`🕳️ Волна ${A.wave}`, A.wave === 1 ? 'Поехали!' : `Врагов: ${n}`);
    Sound.sfx.event(); buzz(40);
  }
  function abyssUpdate(dt) {
    const A = G.abyss; if (!A || G.cutscene) return;
    if (state === 'play') { A.t += dt; A.trackT = (A.trackT || 0) + dt; }
    if (A.state === 'rest') { if (state === 'play') { A.rest -= dt; if (A.rest <= 0) abyssWave(); } return; }
    if (!G.activeBoss && !G.enemies.some(e => !e.dead)) {
      A.state = 'rest'; A.rest = 3.5;
      P.hp = Math.min(P.maxHp, P.hp + P.maxHp * 0.15);
      showBanner(`Волна ${A.wave} пройдена!`, 'Передышка… +15% ❤️');
      lifeMax('abyss', A.wave);
      abyssRecord(A.wave); abyssCkSave(); life('abyssW'); life('spts', weekEv('abyss') ? 6 : 3);
      if (A.trackT > 50) abyssNextTrack(); // трек играл уже долго – на передышке ставим следующий
      try { lifeFlush(); } catch (e) { /* ignore */ }
    }
  }
  function abyssBossDown() {
    abyssNextTrack(); // страж повержен – после боевой темы новый трек
    const dcoin = defOn() ? 80 + G.abyss.wave * 4 : 0;
    showBanner(defOn() ? 'Страж повержен!' : 'Страж бездны повержен!', defOn() ? `Улучшение, +${dcoin} 🪙 и +2 💎 кристаллу` : 'Награда: улучшение и лечение');
    P.hp = Math.min(P.maxHp, P.hp + P.maxHp * 0.4);
    if (defOn()) { G.abyss.coins += dcoin; G.core.hp = Math.min(TD_LIVES, G.core.hp + 2); G.abyss.bossLn = undefined; if (NET.host && G.netRun) for (const m of NET.peers.values()) netEvent(m.id, ['rh']); }
    G.pendingLv++; openLevelUp();
  }
  function abyssFinish() {
    const A = G.abyss; if (!A || A.done) return; A.done = true;
    abyssCkClear(); // забег окончен – продолжать нечего
    const pr = loadProfile(), best = pr.abyssBest, wave = A.state === 'rest' ? A.wave : Math.max(0, A.wave - 1);
    const better = !best || wave > best.wave || (wave === best.wave && A.t < best.time);
    if (better) { pr.abyssBest = { wave, time: Math.round(A.t), hero: P.hero, kills: G.kills }; saveProfile(pr); }
    A.better = A.better || better;
    lifeMax('abyss', wave);
    recordRunEnd(`бездна: волна ${A.wave}`);
  }

  // ---------- оборона: дороги, площадки, башни с мастерствами, коты-заслон, бесконечные волны ----------
  let TD_HIT = false; // урон сейчас наносит башня или кот, а не героиня
  function defOn() { return !!(G.abyss && G.abyss.def && G.core && G.td); }
  function defPlayers() { return 1 + (NET.host && G.netRun ? netLiveMates() : 0); }
  const tdE = n => 2 + n + (Math.max(0, n - 12) + Math.max(0, n - 24) + Math.max(0, n - 36)) * 0.5; // уровень врагов на волне: чем дальше, тем круче растёт
  // в обороне сила врагов не подстраивается под героиню – иначе башни перестали бы справляться
  function tdScale(E) {
    const A = G.abyss, w = A ? A.wave : 1;
    return {
      // первые волны мягче: здоровье набирает полную силу к 25-й; после 18-й враги крепчают всё быстрее – бесконечная оборона должна когда-то закончиться
      // plK – сколько героинь: вместе враги крепче; 1.08 – подобрано ботами так, чтобы с дальнобойными башнями 0.35.4 было примерно на 10% легче, чем в 0.35.3
      hp: 1.08 * (1 + Math.min(0.5, w * 0.02)) * Math.pow(1.045, Math.max(0, w - 18)) * refMobDPS(E) / refMobDPS(4) * G.diff.hp * ((A && A.plK) || 1),
      dmg: BAL.mobDmgK * BAL.metaK * refEHP(E) / refEHP(4) * G.diff.dmg,
      // опыт привязан к номеру волны: героиня растёт примерно на уровень за волну и не обгоняет волну больше чем на несколько уровней
      xp: 0.5 * xpFor(E) / BAL.xpDiv * clamp(1 - 0.22 * (P.level - (w + 2)), 0, 1.5),
    };
  }
  // в обороне главная сила – башни: прокачка героини (таланты, реликвии, осколки) почти не добавляет ей урона по врагам на дорогах,
  // иначе одна героиня проходила бы волны сама. Множитель урона героини: 1 у обычной, меньше – у прокачанной
  function tdHeroK() {
    const R = estMobDPS(P) / refMobDPS(clamp(P.level, 1, REF.N));
    return Math.pow(clamp(R, 1, 4), -0.75);
  }
  const tdTypHp = () => 40 * tdScale(G.abyss.E).hp; // здоровье обычного врага этой волны – мерило для заклинаний
  const tdTwist = id => !!(G.abyss && G.abyss.twist === id);
  // у входа враги под защитой портала: героиня бьёт их вчетверо слабее – башни бьют как обычно
  function tdPortal(e) {
    if (!G.td || e.ln === undefined) return false;
    for (const L of G.td.lanes) if ((e.x - L.gate.x) ** 2 + (e.y - L.gate.y) ** 2 < 150 * 150) return true;
    return false;
  }
  function tdCat(type) {
    const d = ENEMIES[type];
    if (d.fly) return 'fly';
    if (d.ai === 'exploder') return 'boom';
    if (d.ai === 'healer' || d.ai === 'buffer') return 'sup';
    if (d.ai === 'shield' || d.hp >= 110) return 'tank';
    if (d.ai === 'swarm' || d.spd >= 140) return 'run';
    if (d.ai === 'ranged') return 'shoot';
    return 'grunt';
  }
  // враги открытых глав, разложенные по ролям; стоячие (турели, призыватели) в оборону не идут
  function defPool(pr) {
    const p = abyssPool(pr), by = { grunt: [], run: [], tank: [], fly: [], boom: [], shoot: [], sup: [] };
    for (const t of p.types) { const d = ENEMIES[t]; if (!d || d.ai === 'turret' || d.ai === 'summoner' || d.noDrop) continue; by[tdCat(t)].push(t); }
    if (!by.grunt.length) by.grunt = ['slime'];
    p.by = by;
    return p;
  }
  const tdMapOpen = (M, pr) => !M.need || DEBUG || pr.admin || (((pr.tdBest || {})[M.need] || {}).wave || 0) >= 10;
  function tdMapPick(pr) { const id = (pr.settings || {}).defMap, M = TD_MAP_BY[id]; return M && tdMapOpen(M, pr) ? M : TD_MAPS[0]; }

  // ---------- карта: трава, дороги, пруды и деревья ----------
  function tdBuildMap(M) {
    const bi = M.biome, x0 = TD_OX, y0 = TD_OY, x1 = TD_OX + TD_W, y1 = TD_OY + TD_H, rs = mulberry32(7000 + TD_MAPS.indexOf(M) * 131);
    trees = []; treeGrid.fill(0); chests = []; shrines = [];
    for (let ty = 0; ty < PLAY_H; ty++) for (let tx = 0; tx < MW; tx++) {
      const i = ty * MW + tx, qx = (tx + 0.5 - (x0 + x1) / 2) / (TD_W / 2), qy = (ty + 0.5 - (y0 + y1) / 2) / (TD_H / 2);
      biomeMap[i] = bi; tiles[i] = tx >= x0 && tx < x1 && ty >= y0 && ty < y1 && qx ** 8 + qy ** 8 <= 1.08 ? bi : ROCK;
    }
    const road = new Uint8Array(MW * MH);
    const pave = (gx, gy) => { for (let oy = -1; oy <= 0; oy++) for (let ox = -1; ox <= 0; ox++) { const tx = x0 + gx + ox, ty = y0 + gy + oy; if (tx > 1 && ty > 1 && tx < MW - 2 && ty < PLAY_H - 2) { tiles[ty * MW + tx] = PATH; road[ty * MW + tx] = 1; } } };
    const lanes = M.lanes.map(L => {
      const g = L.pts.slice(), a = g[0], b = g[1], sx = Math.sign(a[0] - b[0]), sy = Math.sign(a[1] - b[1]);
      g.unshift([a[0] + sx * 2, a[1] + sy * 2]); // дорога уходит за край поля – оттуда и приходят враги
      for (let i = 1; i < g.length; i++) {
        let [x, y] = g[i - 1]; const [ex, ey] = g[i];
        pave(x, y); while (x !== ex || y !== ey) { x += Math.sign(ex - x); y += Math.sign(ey - y); pave(x, y); }
      }
      const pts = L.pts.map(([gx, gy]) => ({ x: (x0 + gx) * T, y: (y0 + gy) * T }));
      pts.unshift({ x: pts[0].x + sx * 56, y: pts[0].y + sy * 56 });
      const cum = [0]; for (let i = 1; i < pts.length; i++) cum.push(cum[i - 1] + Math.hypot(pts[i].x - pts[i - 1].x, pts[i].y - pts[i - 1].y));
      return { pts, cum, total: cum[cum.length - 1], from: L.from || 1, side: !!L.side, gate: pts[1] };
    });
    const spots = M.spots.map(([sx, sy], i) => ({ i, x: tc(x0 + sx), y: tc(y0 + sy), tx: x0 + sx, ty: y0 + sy, tw: null }));
    const core = { x: (x0 + M.core[0]) * T, y: (y0 + M.core[1]) * T };
    const free = (tx, ty, m) => { // рядом нет ни дороги, ни площадки, ни кристалла
      for (let oy = -m; oy <= m; oy++) for (let ox = -m; ox <= m; ox++) if (road[(ty + oy) * MW + tx + ox]) return false;
      for (const s of spots) if (Math.abs(s.tx - tx) <= m + 1 && Math.abs(s.ty - ty) <= m + 1) return false;
      return Math.hypot(tc(tx) - core.x, tc(ty) - core.y) > 150;
    };
    for (const [px, py, rx, ry] of M.ponds || []) for (let ty = y0 + py - ry; ty <= y0 + py + ry; ty++) for (let tx = x0 + px - rx; tx <= x0 + px + rx; tx++) {
      if (tx < x0 || tx >= x1 || ty < y0 || ty >= y1 || tiles[ty * MW + tx] !== bi) continue;
      if (((tx - x0 - px) / (rx + 0.4)) ** 2 + ((ty - y0 - py) / (ry + 0.4)) ** 2 <= 1 && free(tx, ty, 1)) tiles[ty * MW + tx] = M.pond;
    }
    for (let ty = y0; ty < y1; ty++) for (let tx = x0; tx < x1; tx++) {
      if (tiles[ty * MW + tx] !== bi || !free(tx, ty, 1)) continue;
      if (rs() < Math.min(0.09, BIOMES[bi].treeP * 0.6 * (0.5 + vnoise(tx * 0.2 + 3, ty * 0.2 + 7)))) { trees.push({ x: tx * T + 10 + rs() * 20, y: ty * T + 14 + rs() * 20, kind: BIOMES[bi].tree, s: 0.8 + rs() * 0.3 }); treeGrid[ty * MW + tx] = trees.length; }
    }
    START = { x: x0 + M.core[0], y: y0 + M.core[1] + 2 };
    chunkCache.clear(); chunkJob = null; buildMinimap();
    fog.getContext('2d').clearRect(0, 0, MW, MH); // всё поле видно сразу
    return { M, lanes, spots, core, units: [], temp: [], stars: [], spcd: { star: 0, cats: 0 }, aim: '', shots: [], zaps: [], pools: [], sel: -1, selT: 0, pick: '', uid: 0, bounds: { x0: x0 * T, y0: y0 * T, x1: x1 * T, y1: y1 * T } };
  }
  const tdLaneOf = e => G.td.lanes[e.ln];
  // точка дороги на расстоянии d от входа; пишет px, py и номер отрезка прямо в переданный объект
  function tdLanePt(L, d, o) {
    d = clamp(d, 0, L.total); let i = o.seg || 1; const n = L.pts.length - 1;
    if (i > n) i = n;
    while (i < n && L.cum[i] < d) i++;
    while (i > 1 && L.cum[i - 1] > d) i--;
    const a = L.pts[i - 1], b = L.pts[i], k = (d - L.cum[i - 1]) / (L.cum[i] - L.cum[i - 1] || 1);
    o.seg = i; o.px = a.x + (b.x - a.x) * k; o.py = a.y + (b.y - a.y) * k;
    return o;
  }
  function startDefense(mapId) {
    const pr = loadProfile(), net = NET.on && G.netRun;
    if (!net && !(pr.ch1Done || DEBUG || pr.admin)) { toast('🔒 Оборона откроется после главы 1'); return; }
    const M = net ? (TD_MAP_BY[NET.dmap] || TD_MAPS[0]) : (TD_MAP_BY[mapId] && tdMapOpen(TD_MAP_BY[mapId], pr) ? TD_MAP_BY[mapId] : tdMapPick(pr));
    const A = CHAPTERS.abyss; A.bosses = []; A.bossTiles = []; A.bossLevels = []; A.hero = net ? NET.hero : rushHeroPick(pr);
    loadChapter('abyss');
    const td = tdBuildMap(M);
    resetRun();
    G.td = td; ZK = 0.75; resize();
    G.core = { x: td.core.x, y: td.core.y, r: 30, hp: TD_LIVES, vx: 0, vy: 0, flash: 0, t: 0 };
    G.abyss = { def: true, map: M.id, wave: 0, passed: 0, rest: 30, t: 0, coins: TD_START, q: [], wt: 0, E: tdE(1), bw: 0, pool: defPool(pr), seed: Math.floor(Math.random() * 1e6), leaks: 0, built: 0 };
    beginPlay();
    gateOpen = true;
    G.abyss.next = NET.client ? null : tdMakeWave(1);
    G.st = newRunStats(); G.st.ch = 'def';
    showBanner(`🛡️ ${M.nm}`, 'Нажми на площадку 🔨 – построим башню. Не пускай врагов к кристаллу');
    G.abyss.mus = abyssDecks(pr); abyssNextTrack();
    if (!pr.td2Seen) { pr.td2Seen = 1; saveProfile(pr); setTimeout(() => { if (defOn() && state === 'play') say('Нажми на каменную площадку 🔨 – вокруг неё появятся башни на выбор. Заклинания – справа!', 6); }, 2200); }
  }

  // ---------- волны ----------
  // [роль, сколько (доля от обычного отряда), дорога (номер, 'all' – по всем, 's' – боковая), задержка в секундах]
  const TD_FIRST = [
    [['grunt', 1, 0, 0]],
    [['grunt', 0.7, 0, 0], ['grunt', 0.7, 1, 2]],
    [['grunt', 0.8, 1, 0], ['run', 0.8, 0, 3]],
    [['fly', 0.8, 0, 0], ['grunt', 0.9, 1, 1]],
    [['champ', 1, 0, 0], ['grunt', 1, 'all', 2]],
    [['tank', 1, 0, 0], ['shoot', 0.8, 1, 2], ['run', 0.6, 's', 5]],
    [['run', 1, 'all', 0], ['grunt', 0.6, 0, 6]],
    [['boom', 0.8, 0, 0], ['grunt', 0.9, 1, 1], ['sup', 1, 1, 4], ['fly', 0.5, 2, 6]],
    [['fly', 1, 'all', 0], ['tank', 0.8, 0, 3], ['run', 0.6, 's', 5]],
    [['boss', 1, 0, 0], ['grunt', 0.8, 'all', 4], ['run', 0.5, 's', 8]],
  ];
  const TD_LOOP = [
    [['boss', 1, 0, 0], ['grunt', 1, 'all', 4], ['tank', 0.5, 1, 7], ['run', 0.6, 's', 9]],
    [['grunt', 1, 'all', 0], ['run', 0.7, 0, 4], ['shoot', 0.5, 1, 6]],
    [['fly', 0.9, 'all', 0], ['grunt', 0.9, 1, 2], ['run', 0.5, 's', 6]],
    [['tank', 1, 'all', 0], ['sup', 1, 0, 3], ['grunt', 0.6, 1, 6]],
    [['run', 1.2, 'all', 0], ['boom', 0.8, 0, 3], ['run', 0.6, 's', 5]],
    [['champ', 1, 0, 0], ['champ', 1, 1, 6], ['grunt', 1, 'all', 2], ['shoot', 0.6, 1, 5]],
    [['shoot', 1, 'all', 0], ['tank', 0.8, 0, 2], ['fly', 0.6, 1, 6]],
    [['fly', 1.4, 'all', 0], ['run', 0.6, 's', 4]],
    [['boom', 1, 'all', 0], ['run', 0.9, 1, 2], ['sup', 1, 0, 4], ['tank', 0.5, 0, 6]],
    [['grunt', 0.9, 'all', 0], ['tank', 0.6, 'all', 3], ['fly', 0.7, 'all', 5], ['run', 0.7, 's', 7], ['sup', 1, 1, 8]],
  ];
  const TD_SPAWN = { grunt: [0.85, 1], run: [0.38, 1.3], tank: [1.7, 0.4], fly: [0.65, 0.75], boom: [0.95, 0.5], shoot: [1.05, 0.6], sup: [2.4, 0.12] }; // [пауза между врагами, сколько их в отряде]
  function tdMakeWave(n) {
    const A = G.abyss, M = G.td, by = A.pool.by, mult = 1 + 0.5 * (defPlayers() - 1);
    const open = M.lanes.map((L, i) => i).filter(i => M.lanes[i].from <= n);
    const main = open.filter(i => !M.lanes[i].side), side = open.filter(i => M.lanes[i].side);
    if (!main.length) main.push(0);
    const rs = mulberry32(9100 + n * 77 + A.seed);
    const n0 = (7 + n * 1.35) * mult, gk = Math.max(0.55, 1 - n * 0.011), eliteP = Math.min(0.3, 0.02 + n * 0.006);
    const tw = n >= 7 && n % 7 === 0 ? TD_TWISTS[Math.floor(rs() * TD_TWISTS.length)].id : ''; // каждая седьмая – особая
    const q = [], sum = new Map();
    const note = (ln, tag, cnt) => { if (!sum.has(ln)) sum.set(ln, {}); const o = sum.get(ln); o[tag] = (o[tag] || 0) + cnt; };
    const group = (cat, k, ln, at) => {
      const list = by[cat] && by[cat].length ? by[cat] : by.grunt, type = list[Math.floor(rs() * list.length)], c = tdCat(type), [gap, share] = TD_SPAWN[c];
      const cnt = Math.max(c === 'sup' ? 1 : 2, Math.round(n0 * share * k));
      for (let i = 0; i < cnt; i++) q.push({ at: at + i * gap * gk, type, ln, elite: rs() < eliteP });
      note(ln, c, cnt);
    };
    let plan = n <= TD_FIRST.length ? TD_FIRST[n - 1] : TD_LOOP[n % 10];
    if (tw === 'raid' && by.fly.length) plan = plan.map(([cat, k, where, at]) => [cat === 'boss' || cat === 'champ' ? cat : 'fly', cat === 'boss' || cat === 'champ' ? k : k * 1.1, where, at]); // налёт: почти все летят
    for (const [cat, k, where, at] of plan) {
      if (cat === 'sup') continue; // лекарей в обороне нет: с ними поздние волны становились нечестными
      if (cat === 'boss') { const ln = main[Math.floor(rs() * main.length)]; q.push({ at, boss: true, ln }); note(ln, 'boss', 1); continue; }
      if (cat === 'champ') {
        if (where > 0 && (n < 25 || main.length < 2)) continue; // второй чемпион – только на поздних волнах
        const ln = main[where % main.length], list = by.tank.concat(by.grunt).filter(t => ENEMIES[t].ai !== 'swarm'), type = list[Math.floor(rs() * list.length)] || by.grunt[0];
        q.push({ at, champ: true, type, ln }); note(ln, 'champ', 1); continue;
      }
      if (where === 'all') main.forEach((ln, i) => group(cat, k / main.length * 1.15, ln, at + i * 1.3));
      else if (where === 's') group(cat, k, side.length ? side[Math.floor(rs() * side.length)] : main[(n + 1) % main.length], at);
      else group(cat, k, main[where % main.length], at);
    }
    q.sort((a, b) => a.at - b.at);
    return { n, q, tw, pl: defPlayers(), sum: [...sum.entries()].map(([ln, o]) => [ln, Object.entries(o).sort((a, b) => b[1] - a[1])]) };
  }
  function tdSpawn(type, ln, o = {}) {
    const A = G.abyss, d = ENEMIES[type], L = G.td.lanes[ln];
    const e = spawnEnemy(type, L.pts[0].x, L.pts[0].y, G.td.M.biome, { E: A.E, elite: !!o.elite, sc: tdScale(A.E), instant: true });
    e.ln = ln; e.dist = 0; e.seg = 1; e.ox = rnd(-15, 15); e.oy = rnd(-15, 15); e.cat = tdCat(type); e.run = e.cat === 'run'; e.agCd = 0; e.cd = rnd(1, 3);
    e.lspd = clamp(d.spd || 60, 44, 150) * 0.72 * rnd(0.94, 1.06) * (e.affix === 'fast' ? 1.35 : 1) * (1 + Math.min(0.3, A.wave * 0.006));
    e.hp = e.maxHp = 40 * Math.pow(d.hp / 40, 0.6) * e.maxHp / d.hp; // толстые и хлипкие враги ближе друг к другу: оборона одинаково честна с любым набором открытых глав
    if (o.champ) { e.champion = true; e.hp = e.maxHp = e.maxHp * 5; e.dmg *= 1.2; e.r *= 1.25; e.xp *= 3; e.name = d.name; e.lspd *= 0.85; }
    tdLanePt(L, 0, e); e.x = e.px + e.ox; e.y = e.py + e.oy; e.lpx = e.px; e.rem = L.total;
    return e;
  }
  function tdBossSpawn(ln) {
    const A = G.abyss, L = G.td.lanes[ln], kind = pick(A.pool.kinds), g = L.gate;
    CFG.bosses = [kind]; CFG.bossLevels = [Math.round(A.E) + 2]; CFG.bossTiles = [{ x: Math.floor(g.x / T), y: Math.floor(g.y / T) }]; G.defeated = [false];
    makeBosses(); const b = bosses[0]; b.x = b.hx = g.x; b.y = b.hy = g.y; A.bw = A.wave; A.bossLn = ln; A.bossD = L.cum[1] + 30; A.bossT = 0; A.bossP = {};
    startBossFight(b);
  }
  // страж идёт по дороге: его «дом» ползёт к кристаллу, а дойдя, страж начинает его крошить
  function tdBoss(dt) {
    const A = G.abyss, b = G.activeBoss; if (!b || b.state !== 'fight' || A.bossLn === undefined) return;
    const L = G.td.lanes[A.bossLn];
    A.bossD = Math.min(L.total - 80, A.bossD + 20 * dt); tdLanePt(L, A.bossD, A.bossP); b.hx = A.bossP.px; b.hy = A.bossP.py;
    A.silT = (A.silT === undefined ? 6 : A.silT) - dt;
    if (A.silT <= 0) { // волна сна: башни рядом со стражем засыпают на 2 секунды
      A.silT = 9; let n = 0;
      for (const sp of G.td.spots) if (sp.tw && (sp.x - b.x) ** 2 + (sp.y - b.y) ** 2 < 200 * 200) { sp.tw.silT = 2; n++; }
      shockRing(b.x, b.y, '#9a6aff', 200); if (n) { floatText(b.x, b.y - b.r - 30, '💤 Башни уснули!', '#c9b3ff', true); Sound.sfx.whisper(); }
    }
    if (A.bossD >= L.total - 81 && Math.hypot(b.x - G.core.x, b.y - G.core.y) < 260) { A.bossT += dt; if (A.bossT >= 1.6) { A.bossT = 0; tdCoreHit(1); } }
  }
  function defWave() {
    const A = G.abyss; if (A.wave > 0) tdSurvived(A.wave);
    A.wave++; A.E = tdE(A.wave); A.votes = new Set(); A.rest = TD_GAP - Math.min(8, A.wave * 0.4); A.wt = 0; // поначалу между волнами больше времени
    const W = A.next && A.next.n === A.wave && A.next.pl === defPlayers() ? A.next : tdMakeWave(A.wave); // подруга зашла или вышла – волну пересчитываем
    A.q = W.q; A.sum = W.sum; A.twist = W.tw || ''; A.heroK = tdHeroK(); A.plK = 1 + 0.25 * (defPlayers() - 1); A.next = tdMakeWave(A.wave + 1);
    const tags = new Set(); for (const [, list] of W.sum) for (const [t] of list) tags.add(t);
    const seen = A.seenTag || (A.seenTag = {});
    let sub = `Врагов: ${W.q.filter(x => !x.boss).length}`;
    if (A.twist) { const X = TD_TWIST_BY[A.twist]; netBan(`${X.ic} Волна ${A.wave}: ${X.nm}!`, X.ds); Sound.sfx.event(); buzz(60); return; }
    if (tags.has('boss')) sub = 'Страж идёт к кристаллу – остановите его!';
    else if (tags.has('champ')) sub = '👑 С ними чемпион – бейте все вместе';
    else if (tags.has('fly') && !seen.fly) sub = '🦇 Летят! Их достают Перьемёт, Диско-шар и Морозилка';
    else if (tags.has('tank') && !seen.tank) sub = '🛡️ Крепкие враги – им нужны сильные башни';
    else if (tags.has('run') && !seen.run) sub = '💨 Бегуны проскакивают мимо героини – ставь котов и Морозилку';
    for (const t of tags) seen[t] = 1;
    netBan(`🛡️ Волна ${A.wave}`, sub);
    Sound.sfx.event(); buzz(40);
  }
  function tdSpawnQ(it) {
    if (it.boss) tdBossSpawn(it.ln);
    else tdSpawn(it.type, it.ln, { elite: it.elite || it.champ, champ: it.champ });
  }
  function defUpdate(dt) {
    const A = G.abyss, C = G.core; if (!A || A.done || G.cutscene) return;
    A.t += dt; A.trackT = (A.trackT || 0) + dt;
    C.t += dt; if (C.flash > 0) C.flash -= dt;
    tdHeroTick(dt); tdSpellTick(dt);
    tdTowers(dt, true); tdUnits(dt); tdShots(dt); tdPools(dt); tdBoss(dt);
    if (C.hp <= 0) { defLose(); return; }
    if (A.q.length) { A.wt += dt; while (A.q.length && A.q[0].at <= A.wt) tdSpawnQ(A.q.shift()); }
    if (A.votes && A.votes.size) tdVoteCheck();
    const hold = !!G.activeBoss;
    if (A.wave > 0 && A.passed < A.wave && !A.q.length && !hold && !G.enemies.some(e => !e.dead && e.ln !== undefined)) tdSurvived(A.wave);
    if (!A.q.length && !hold && A.passed >= A.wave) { A.rest -= dt; if (A.rest <= 0) defWave(); } // 1.0.11: пока волну не добили – следующая не идёт
    if (A.trackT > 150 && !G.activeBoss) abyssNextTrack();
  }
  // волна отбита: поле чистое или уже пошла следующая
  function tdSurvived(w) {
    const A = G.abyss; if (w <= A.passed) return; A.passed = w;
    if (w === A.wave) A.rest = Math.min(A.rest, TD_CLEAR_REST); // поле чистое – короткая передышка на стройку
    A.coins += 12 + w * 2;
    defWaveDone(w);
    if (NET.host && G.netRun) for (const m of NET.peers.values()) netEvent(m.id, ['dw', w]);
  }
  // у каждой героини свой рекорд, свои звёзды и свои искры сезона
  function defWaveDone(w) {
    const A = G.abyss, id = A.map, M = TD_MAP_BY[id];
    lifeMax('defWave', w); life('spts', weekEv('abyss') ? 6 : 3);
    const pr = loadProfile(); pr.tdBest = pr.tdBest || {}; pr.starsGot = pr.starsGot || {};
    const best = pr.tdBest[id], n = NET.on && G.netRun ? Math.max(1, NET.roster.length) : 1;
    if (!best || w > best.wave) { pr.tdBest[id] = { wave: w, time: Math.round(A.t), hero: P.hero, n }; A.better = true; }
    for (const m of TD_MILE) if (w >= m && !pr.starsGot[`d:${id}:${m}`]) {
      pr.starsGot[`d:${id}:${m}`] = 1; if (G.st) G.st.stars = (G.st.stars || 0) + 1;
      setTimeout(() => { if (defOn()) { showBanner(`⭐ ${m} волн отбито!`, `${M.nm}: звезда для талантов`); Sound.sfx.win(); } }, 900);
      if (m === 10) { const nx = TD_MAPS.find(q => q.need === id); if (nx) setTimeout(() => toast(`${nx.ic} Открыта карта «${nx.nm}»`), 3200); }
    }
    pr.stars = Object.keys(pr.starsGot).length; saveProfile(pr);
    if (TD_MAPS.every(q => ((pr.tdBest[q.id] || {}).wave || 0) >= 10)) lifeMax('defMaps', 1);
    if (w >= 20 && n >= 4) lifeMax('defCoop4', 1);
    try { lifeFlush(); } catch (e) { /* ignore */ }
  }
  function tdCallBonus() { const A = G.abyss; return A.wave > 0 ? Math.round(Math.max(0, A.rest) * (1 + A.wave * 0.08)) : 0; }
  function tdCall() {
    const A = G.abyss; if (A.q.length || G.activeBoss || A.passed < A.wave || A.rest <= 0.4) return false;
    const b = tdCallBonus(); A.coins += b; A.rest = 0;
    if (b) netBan('⏩ Волна раньше срока', `+${b} 🪙 за смелость`);
    return true;
  }
  function tdLeak(e) {
    e.dead = true; if (e.haz) e.haz.cancel = true;
    tdCoreHit(e.champion ? 5 : e.elite ? 2 : 1);
  }
  function tdCoreHit(n) {
    const C = G.core, A = G.abyss; if (!A || A.done || C.hp <= 0) return;
    C.hp = Math.max(0, C.hp - n); A.leaks += n; tdCoreFx(n);
    if (C.hp > 0 && C.hp <= 5 && !A.warn5) { A.warn5 = true; netBan('💎 Кристалл на волоске!', `Осталось всего ${C.hp}`); }
  }
  function tdCoreFx(n) {
    const C = G.core; C.flash = 0.35;
    burst(C.x, C.y - 24, 16, '#ff5b8a', 200); floatText(C.x, C.y - 80, `−${n} 💎`, '#ff8ab0', true); G.shake = Math.max(G.shake, 7); Sound.sfx.glass(); buzz(70);
  }

  // ---------- враги на дороге ----------
  function tdNearHero(e, r) {
    let best = null, bd = r * r;
    if (!P.down) { const d = (P.x - e.x) ** 2 + (P.y - e.y) ** 2; if (d < bd) { bd = d; best = P; } }
    if (NET.host) for (const m of NET.peers.values()) { if (!m.live || m.down || m.away) continue; const d = (m.x - e.x) ** 2 + (m.y - e.y) ** 2; if (d < bd) { bd = d; best = m; } }
    return best;
  }
  function tdTouch(e) { if (!P.down && (P.x - e.x) ** 2 + (P.y - e.y) ** 2 < (e.r + P.r - 2) ** 2) hurtPlayer(e.dmg, e.x, e.y); }
  // true – враг идёт по дороге (или стоит в заслоне) и своим умом в этот кадр не пользуется
  function tdEnemyTick(e, dt) {
    if (e.ln === undefined) return false; // свита стража – обычным умом
    if (e.agCd > 0) e.agCd -= dt;
    if (e.frailT > 0) e.frailT -= dt;
    if (e.stunT > 0) { e.stunT -= dt; if (e.flash > 0) e.flash -= dt; return true; }
    if (e.ag) { // отвлеклась на героиню: гонится, пока та рядом, но не дольше пяти секунд
      const q = e.ag; e.agT -= dt;
      const busy = e.fuse > 0 || e.blink > 0 || e.jd > 0 || e.wind > 0;
      const leash = (e.x - e.px) ** 2 + (e.y - e.py) ** 2 < 140 * 140; // далеко от дороги не уходит
      if (busy || (leash && !q.down && (q === P || q.live) && !q.away && e.agT > 0 && (q.x - e.x) ** 2 + (q.y - e.y) ** 2 < 220 * 220)) { AIM = q.down ? P : q; return false; }
      e.ag = null; e.agCd = 5; e.back = true; e.charge = 0; e.burst = 0;
    }
    e.t += dt; e.kx = 0; e.ky = 0;
    if (e.flash > 0) e.flash -= dt;
    if (e.healing > 0) e.healing -= dt;
    if (e.buffT > 0) e.buffT -= dt;
    if (e.slowT > 0) { e.slowT -= dt; if (e.slowT <= 0) e.slowK = 0; }
    if (e.burnT > 0) {
      e.burnT -= dt; e.burnTick -= dt;
      if (e.burnTick <= 0) {
        e.burnTick = 0.4; e.hp -= e.burnDps * 0.4 * (1 - e.dr);
        if (Math.random() < 0.5) part(e.x + rnd(-6, 6), e.y - 6, rnd(-20, 20), rnd(-60, -30), 0.4, 3, '#ff8a2a');
        if (e.hp <= 0) { TD_HIT = true; killEnemy(e); TD_HIT = false; return true; }
      }
    }
    if (e.affix === 'vampiric' && e.hp < e.maxHp) e.hp = Math.min(e.maxHp, e.hp + e.maxHp * 0.02 * dt);
    const L = tdLaneOf(e);
    if (e.def.ai === 'shield') tdShieldTurn(e, dt);
    if (e.blk) { // упёрлась в кота: стоит и дерётся
      const u = e.blk;
      if (u.dead || u.tg !== e) e.blk = null;
      else {
        e.face = u.x > e.x ? 1 : -1;
        if (e.def.ai === 'exploder') {
          if (!(e.fuse > 0)) { e.fuse = 0.65; e.haz = hazardCircle(e.x, e.y, 88, 0.65, e.dmg, 'boom'); Sound.sfx.fuse(); }
          else { e.fuse -= dt; if (e.fuse <= 0) { for (const o of G.td.units) if (!o.dead && (o.x - e.x) ** 2 + (o.y - e.y) ** 2 < 90 * 90) tdUnitHurt(o, e.dmg * 1.6); e.exploded = true; TD_HIT = true; killEnemy(e); TD_HIT = false; } }
          return true;
        }
        e.blkT -= dt;
        if (e.blkT <= 0) { e.blkT = e.champion ? 0.8 : 1.1; tdUnitHurt(u, e.dmg * (e.champion ? 1.5 : 0.8)); }
        tdTouch(e);
        return true;
      }
    }
    if (e.cat === 'sup' && !G.td) { // лекари и кексы помогают своим на ходу (в обороне их нет)
      e.cd -= dt;
      if (e.cd <= 0) {
        e.cd = 3.4; e.healTargets = []; const heal = e.def.ai === 'healer';
        for (const o of G.enemies) {
          if (o === e || o.dead || (heal && (o.hp >= o.maxHp || o.def.ai === 'healer'))) continue;
          if ((o.x - e.x) ** 2 + (o.y - e.y) ** 2 > 190 * 190) continue;
          if (heal) { o.hp = Math.min(o.maxHp, o.hp + o.maxHp * 0.25); floatText(o.x, o.y - o.r - 8, '+', '#7dff9a'); } else o.buffT = 3;
          e.healTargets.push(o);
        }
        if (e.healTargets.length) e.healing = 0.5;
      }
    } else if (e.def.shot && e.def.ai === 'ranged') { // стрелки бьют по героине, не сходя с дороги
      if (e.charge > 0) {
        e.charge -= dt;
        if (e.charge <= 0 && e.shotAt && !e.shotAt.down) { AIM = e.shotAt; fireShot(e); AIM = P; }
        tdTouch(e);
        return true;
      }
      e.cd -= dt;
      if (e.cd <= 0) {
        const h = tdNearHero(e, 240);
        if (h && G.shooters < 4) { e.charge = 0.4; e.cd = e.def.shot.cd * 1.3 * e.cdMul; e.shotAt = h; G.shooters++; e.look = Math.atan2(h.y - e.y, h.x - e.x); } else e.cd = 0.5;
      }
    }
    // героиня совсем рядом – наземные бросают дорогу и идут на неё (бегуны и летуны не отвлекаются)
    if (!e.fly && !e.run && !e.back && e.agCd <= 0) { const h = tdNearHero(e, 80); if (h) { e.ag = h; e.agT = 3.5; AIM = h; return false; } }
    const spd = e.lspd * (e.slowT > 0 ? (e.slowK || 0.55) : 1) * (tdTwist('rush') ? 1.33 : 1);
    if (e.back) { // возвращается туда, где сошла с дороги
      tdLanePt(L, e.dist, e);
      const tx = e.px + e.ox, ty = e.py + e.oy, dx = tx - e.x, dy = ty - e.y, d = Math.hypot(dx, dy), st = spd * 1.7 * dt;
      e.backT = (e.backT || 0) + dt;
      if (d <= st + 30 || e.backT > 6) { e.ox = clamp(e.x - e.px, -20, 20); e.oy = clamp(e.y - e.py, -20, 20); e.back = false; e.backT = 0; e.lpx = e.px; } // почти на месте – встаёт в строй, где оказалась: соседи расталкивают, точка в точку не попасть
      else { e.x += dx / d * st; e.y += dy / d * st; e.face = dx > 0 ? 1 : -1; }
    } else {
      if (e.confT > 0) { e.confT -= dt; e.dist = Math.max(0, e.dist - spd * dt); } else e.dist += spd * dt;
      if (e.dist >= L.total - 26) { tdLeak(e); return true; }
      tdLanePt(L, e.dist, e);
      if (Math.abs(e.px - e.lpx) > 0.02) e.face = e.px > e.lpx ? 1 : -1;
      e.lpx = e.px; e.x = e.px + e.ox; e.y = e.py + e.oy;
    }
    e.rem = L.total - e.dist;
    tdTouch(e);
    return true;
  }

  // щитоносец поворачивает щит к угрозе: к героине рядом, иначе к башне, что по нему бьёт, иначе – вперёд по дороге
  function tdShieldTurn(e, dt) {
    let a = null;
    const h = tdNearHero(e, 280);
    if (h) a = Math.atan2(h.y - e.y, h.x - e.x);
    else if (e.hitBy && G.time - e.hitBy.t < 4) a = Math.atan2(e.hitBy.y - e.y, e.hitBy.x - e.x);
    else if (e.blk) a = Math.atan2(e.blk.y - e.y, e.blk.x - e.x);
    else { const L = tdLaneOf(e), o = tdLanePt(L, Math.min(L.total, e.dist + 40), { seg: e.seg }); a = Math.atan2(o.py - e.py, o.px - e.px); }
    e.look = a; e.shieldAng += clamp(angDiff(e.shieldAng, a), -2.4 * dt, 2.4 * dt);
  }
  // удар спереди в щит: стрелы и перья башен вязнут (−70%)
  function tdShieldHit(e, sx, sy) { return e.def && e.def.ai === 'shield' && !e.dead && Math.abs(angDiff(e.shieldAng, Math.atan2(sy - e.y, sx - e.x))) < 1.05; }

  // ---------- башни ----------
  const tdIsBoss = q => q && q.hx !== undefined && q.stage !== undefined;
  const TD_FRIEND = { r: 400, k: 0.15 }; // соседние площадки, даже через дорогу
  const tdK = tw => (1 + TD_BOOST.k * tw.boost) * (tw.fr ? 1 + TD_FRIEND.k : 1);
  function tdFriends() { // вместе: башня, рядом с которой стоит башня другой игроки, сильнее
    const M = G.td; if (!M) return;
    const on = NET.on && G.netRun, tws = M.spots.map(s => s.tw).filter(Boolean);
    for (const a of tws) { a.fr = false; a.frL = null; if (!on) continue;
      for (const b of tws) if (b !== a && (b.by || 1) !== (a.by || 1) && (a.x - b.x) ** 2 + (a.y - b.y) ** 2 < TD_FRIEND.r * TD_FRIEND.r) { a.fr = true; (a.frL = a.frL || []).push(b); } }
  }
  function tdSpent(tw) {
    let s = 0; for (let i = 0; i < Math.min(3, tw.lvl); i++) s += tw.def.lv[i].cost;
    if (tw.lvl >= 4) s += tw.def.sp[tw.sp].cost;
    for (let i = 0; i < tw.boost; i++) s += Math.round(TD_BOOST.cost * (tw.k === 'bank' ? 1.7 : 1) * Math.pow(TD_BOOST.grow, i) / 10) * 10;
    return s;
  }
  // цена следующего шага: уровень, мастерство (k = 0 или 1) или усиление; null – дальше некуда
  function tdUpCost(tw, k) {
    if (tw.lvl < 3) return tw.def.lv[tw.lvl].cost;
    if (tw.lvl === 3) return tw.def.sp[k === 1 ? 1 : 0].cost;
    return tw.boost >= TD_BOOST.max ? null : Math.round(TD_BOOST.cost * (tw.k === 'bank' ? 1.7 : 1) * Math.pow(TD_BOOST.grow, tw.boost) / 10) * 10; // копилку усиливать дороже
  }
  function tdDmg(e, v, crit, magic) {
    if (tdTwist('armor')) v *= 0.75;
    if (tdIsBoss(e)) { damageBoss(e, { v: v * 0.5, crit: !!crit }, true, true); return; }
    if (e.dead) return;
    if (e.frailT > 0) v *= e.frailK || 1.35;
    v *= (magic ? 1 : 1 - (e.dr || 0)) * (e.buffT > 0 ? 0.6 : 1);
    e.hp -= v; e.flash = 0.1;
    if (G.st) G.st.dmgDealt += Math.min(v, e.hp + v);
    if (crit || Math.random() < 0.22) dmgText(e.x + rnd(-6, 6), e.y - e.r - 6, v, '#e8e0ff', !!crit);
    if (e.hp <= 0) { TD_HIT = true; killEnemy(e); TD_HIT = false; }
  }
  // кого бить: того, кто ближе всех к кристаллу (снайпер – самого крепкого); real = false – гостья, там это просто картинка
  const tdRng = S => S.rng * (tdTwist('fog') ? 0.67 : 1);
  function tdTargets(tw, S, n) {
    const r2 = tdRng(S) ** 2, air = tw.def.air, out = [];
    for (const e of G.enemies) {
      if (e.dead || e.spawnT > 0 || (!air && e.fly)) continue;
      const d2 = (e.x - tw.x) ** 2 + (e.y - tw.y) ** 2; if (d2 > r2 || (S.minR && d2 < S.minR * S.minR)) continue;
      e._v = S.strong ? -e.hp : (e.rem !== undefined ? e.rem : 5000 + Math.sqrt(d2));
      out.push(e);
    }
    out.sort((a, b) => a._v - b._v);
    if (!out.length) { const b = G.activeBoss; if (b && b.state === 'fight' && (b.z || 0) < 30 && (b.alpha === undefined || b.alpha > 0.3) && (b.x - tw.x) ** 2 + (b.y - tw.y) ** 2 < r2) out.push(b); }
    return out.length > n ? out.slice(0, n) : out;
  }
  function tdTowers(dt, real) {
    const M = G.td;
    M.frT = (M.frT || 0) - dt; if (M.frT <= 0) { M.frT = 0.5; tdFriends(); }
    for (const sp of M.spots) {
      const tw = sp.tw; if (!tw) continue;
      const S = tdStat(tw.def, tw.lvl, tw.sp), k = tdK(tw);
      tw.t += dt; if (tw.shot > 0) tw.shot -= dt;
      if (tw.pop) { tw.pop.t -= dt; if (tw.pop.t <= 0) tw.pop = null; }
      if (tw.gust > 0) tw.gust -= dt;
      if (tw.silT > 0) { tw.silT -= dt; continue; } // страж усыпил
      if (tw.k === 'cats') continue;
      if (tw.k === 'frost') { tdFrost(tw, S, k, dt, real); continue; }
      if (tw.k === 'bank') { // копилка: платит один раз, когда начинается следующая волна; каждая следующая копилка – меньше
        const A = G.abyss; if (tw.paid === undefined) tw.paid = A.wave;
        if (A.wave > tw.paid) {
          tw.paid = A.wave;
          const banks = M.spots.filter(q => q.tw && q.tw.k === 'bank').map(q => q.tw), i = banks.indexOf(tw), share = Math.max(0.4, 1 - 0.25 * i);
          const v = Math.round(S.inc * share * k); tw.shot = 0.5; tw.pop = { v, t: 1.6 }; // k – усиления и дружба башен
          if (real) A.coins += v;
        }
        continue;
      }
      tw.cd -= dt; if (tw.cd > 0) continue;
      const list = tdTargets(tw, S, S.multi || 1), tg = list[0];
      if (!tg) { tw.cd = 0.15; continue; }
      tw.cd = S.cd; tw.shot = 0.18; tw.aim = Math.atan2(tg.y - tw.y, tg.x - tw.x);
      if (tw.k === 'feather') {
        for (const e of list) M.shots.push({ k: 'f', x: tw.x, y: tw.y - 44, tg: e, tx: e.x, ty: e.y, spd: S.strong ? 900 : 620, dmg: S.dmg * k, crit: S.crit || 0, big: !!S.strong, real, src: tw });
      } else if (tw.k === 'fire') {
        const dur = S.stun ? 0.8 : 0.6; let tx = tg.x, ty = tg.y;
        if (tg.ln !== undefined && !tg.ag && !tg.blk && !tg.back && !(tg.stunT > 0)) { const o = tdLanePt(M.lanes[tg.ln], tg.dist + tg.lspd * dur * (tg.slowT > 0 ? (tg.slowK || 0.55) : 1), { seg: tg.seg }); tx = o.px + tg.ox; ty = o.py + tg.oy; }
        M.shots.push({ k: 'b', sx: tw.x, sy: tw.y - 36, x: tw.x, y: tw.y - 36, z: 0, tx, ty, t: 0, dur, dmg: S.dmg * k, S, big: !!S.stun, real });
      } else if (tw.k === 'disco') tdChain(tw, S, k, tg, real);
      else if (tw.k === 'mortar') { // хлопушка – по дуге, взрыв по толпе
        const dur = 1.0, tx = tg.x, ty = tg.y;
        M.shots.push({ k: 'b', sx: tw.x, sy: tw.y - 30, x: tw.x, y: tw.y - 30, z: 0, tx, ty, t: 0, dur, dmg: S.dmg * k, S: Object.assign({ burn: 0 }, S), big: !!S.stun, real, pop: true });
      } else if (tw.k === 'wind') { // ветряк: отбрасывает назад по дороге
        const ls = tdTargets(tw, S, S.n || 3); tw.gust = 0.5;
        for (const e of ls) {
          if (tdIsBoss(e)) continue;
          if (real) { tdDmg(e, S.dmg * k, false, true); if (!e.dead && e.ln !== undefined && e.dist !== undefined) { e.dist = Math.max(0, e.dist - S.push * (e.elite ? 0.6 : 1)); e.ag = false; if (S.conf) e.confT = Math.max(e.confT || 0, S.conf); } }
          for (let i = 0; i < 4; i++) part(e.x + rnd(-10, 10), e.y + rnd(-10, 10), Math.cos(tw.aim) * 160, Math.sin(tw.aim) * 160, 0.35, 3, '#d8f0ff');
        }
      } else if (tw.k === 'vine') { // плющ: опутывает и ранит
        const ls = tdTargets(tw, S, S.n || 2);
        for (const e of ls) {
          if (real) { tdDmg(e, S.dmg * k, false, true); if (!e.dead) { if (tdIsBoss(e)) e.stunT = Math.max(e.stunT || 0, S.root * 0.25); else e.stunT = Math.max(e.stunT || 0, S.root); } }
          e.vineT = S.root;
          for (let i = 0; i < 5; i++) part(e.x + rnd(-12, 12), e.y + rnd(-4, 8), rnd(-20, 20), -rnd(30, 70), 0.6, 3, i % 2 ? '#6ab04a' : '#a8e07a');
        }
      }
    }
  }
  function tdFrost(tw, S, k, dt, real) {
    const r2 = tdRng(S) ** 2;
    tw.cd -= dt; const pulse = tw.cd <= 0; if (pulse) tw.cd = S.cd;
    if (S.freeze) tw.fz = (tw.fz === undefined ? 3 : tw.fz) - dt;
    const frz = !!S.freeze && tw.fz <= 0; let any = false;
    for (const e of G.enemies) {
      if (e.dead || e.spawnT > 0 || (e.x - tw.x) ** 2 + (e.y - tw.y) ** 2 > r2) continue;
      any = true; if (!real) continue;
      e.slowT = Math.max(e.slowT, 0.3); e.slowK = Math.min(e.slowK || 1, S.slow);
      if (S.frail) { e.frailT = 0.5; e.frailK = S.frail; }
      if (frz && !e.champion) { e.stunT = Math.max(e.stunT || 0, S.freeze); e.iceT = S.freeze; }
      if (pulse) tdDmg(e, S.dmg * k, false, true);
    }
    if (pulse && any) tw.shot = 0.3;
    if (frz) { if (any) { tw.fz = 6; shockRing(tw.x, tw.y, '#bfeaff', S.rng); Sound.sfx.glass(); tw.shot = 0.5; } else tw.fz = 0.3; }
  }
  function tdChain(tw, S, k, tg, real) {
    const M = G.td, hit = [tg]; let cur = tg, x = tw.x, y = tw.y - 50;
    for (let n = 0; n < S.chain && cur; n++) {
      const cy = cur.y - (cur.fly ? 8 : 0) - (cur.z || 0);
      M.zaps.push({ x0: x, y0: y, x1: cur.x, y1: cy, life: 0.16 });
      if (real) { tdDmg(cur, S.dmg * k * (n ? 0.8 : 1), false, true); if (S.conf && cur.ln !== undefined && !cur.champion && !cur.dead && !cur.blk && Math.random() < S.conf) cur.confT = 1.6; }
      x = cur.x; y = cy;
      let nx = null, bd = 115 * 115;
      for (const e of G.enemies) { if (e.dead || e.spawnT > 0 || hit.includes(e)) continue; const d2 = (e.x - x) ** 2 + (e.y - y) ** 2; if (d2 < bd) { bd = d2; nx = e; } }
      cur = nx; if (nx) hit.push(nx);
    }
  }
  function tdShots(dt) {
    const M = G.td;
    for (const s of M.shots) {
      if (s.k === 'f') {
        const tg = s.tg, live = tg && (tdIsBoss(tg) ? tg.state === 'fight' : !tg.dead);
        if (live) { s.tx = tg.x; s.ty = tg.y - (tg.fly ? 8 : 0) - (tg.z || 0); }
        const dx = s.tx - s.x, dy = s.ty - s.y, d = Math.hypot(dx, dy) || 1, st = s.spd * dt;
        s.a = Math.atan2(dy, dx);
        if (d <= st + 8) {
          s.dead = true;
          if (s.real && live) {
            const cr = Math.random() < s.crit, blk = !tdIsBoss(tg) && tdShieldHit(tg, s.src.x, s.src.y);
            if (!tdIsBoss(tg)) tg.hitBy = { x: s.src.x, y: s.src.y, t: G.time }; // щитоносец запомнит, откуда стреляют
            if (blk) { burst(s.x, s.y, 5, '#bfefff', 110); if (Math.random() < 0.25) floatText(tg.x, tg.y - tg.r - 8, 'блок', '#bfefff'); }
            tdDmg(tg, s.dmg * (cr ? 2.5 : 1) * (blk ? 0.3 : 1), cr && !blk);
          }
          if (s.big) burst(s.tx, s.ty, 8, '#ffd25a', 140);
        }
        else { s.x += dx / d * st; s.y += dy / d * st; }
      } else { // огненный шар летит по дуге
        s.t += dt; const k = Math.min(1, s.t / s.dur);
        s.x = s.sx + (s.tx - s.sx) * k; s.y = s.sy + (s.ty - s.sy) * k; s.z = Math.sin(k * Math.PI) * (s.big ? 110 : 70);
        if (k >= 1) { s.dead = true; tdBoom(s); }
      }
    }
    if (M.shots.some(s => s.dead)) M.shots = M.shots.filter(s => !s.dead);
    if (M.zaps.length) M.zaps = M.zaps.filter(z => (z.life -= dt) > 0);
  }
  function tdBoom(s) {
    const S = s.S, r = S.r;
    burst(s.tx, s.ty, s.big ? 30 : 12, '#ff8a2a', s.big ? 260 : 160); shockRing(s.tx, s.ty, '#ffb03a', r);
    if (s.big) { G.shake = Math.max(G.shake, 5); Sound.sfx.boom(); }
    if (S.pool) G.td.pools.push({ x: s.tx, y: s.ty, r: r * 0.85, t: S.pool, t0: S.pool, dps: s.dmg * 0.3, tick: 0.2, real: s.real });
    if (!s.real) return;
    for (const e of G.enemies) {
      if (e.dead || e.fly || e.spawnT > 0 || (e.x - s.tx) ** 2 + (e.y - s.ty) ** 2 > (r + e.r) ** 2) continue;
      if (S.burn) { e.burnT = 3; e.burnDps = Math.max(e.burnDps || 0, S.burn * s.dmg / S.dmg); if (!(e.burnTick > 0)) e.burnTick = 0.4; }
      if (S.stun && !e.champion) e.stunT = Math.max(e.stunT || 0, S.stun);
      tdDmg(e, s.dmg, false);
    }
    const b = G.activeBoss; if (b && b.state === 'fight' && Math.hypot(b.x - s.tx, b.y - s.ty) < r + b.r) tdDmg(b, s.dmg, false);
  }
  function tdPools(dt) {
    const M = G.td; if (!M.pools.length) return;
    for (const p of M.pools) {
      p.t -= dt; p.tick -= dt;
      if (p.tick <= 0) { p.tick = 0.5; if (p.real) for (const e of G.enemies) if (!e.dead && !e.fly && (e.x - p.x) ** 2 + (e.y - p.y) ** 2 < p.r * p.r) tdDmg(e, p.dps * 0.5, false); }
      if (Math.random() < dt * 8) part(p.x + rnd(-p.r, p.r) * 0.7, p.y + rnd(-p.r, p.r) * 0.45, 0, -45, 0.5, 3, Math.random() < 0.5 ? '#ff8a2a' : '#ffd23a');
    }
    M.pools = M.pools.filter(p => p.t > 0);
  }
  // ---------- коты-заслон ----------
  function tdRelist() {
    const M = G.td; M.units = [];
    for (const sp of M.spots) if (sp.tw && sp.tw.units) for (const u of sp.tw.units) M.units.push(u);
    for (const t of M.temp) for (const u of t.units) if (!u.gone) M.units.push(u);
  }
  const tdUS = tw => tw.stat || tdStat(tw.def, tw.lvl, tw.sp); // у котоподмоги свои числа
  // ближайшая к точке дорога (для котоподмоги); null – далеко
  function tdRoadAt(x, y, r = 170) {
    let best = null, bd = r * r;
    for (const L of G.td.lanes) for (let d = 60; d < L.total - 40; d += 12) { const o = tdLanePt(L, d, {}), dd = (o.px - x) ** 2 + (o.py - y) ** 2; if (dd < bd) { bd = dd; best = { x: o.px, y: o.py }; } }
    return best;
  }
  function tdStarfall(x, y) {
    const M = G.td, H = tdTypHp();
    for (let i = 0; i < 7; i++) {
      const a = rnd(0, TAU), r = i ? rnd(25, 95) : 0, sx = x + Math.cos(a) * r, sy = y + Math.sin(a) * r * 0.8, dl = 0.6 + i * 0.13;
      M.stars.push({ x: sx, y: sy, t: dl, dmg: H * 0.8 });
      const h = hazardCircle(sx, sy, 55, dl, 0, 'meteor'); h.star = true; h.td = true;
    }
    return true;
  }
  function tdReinforce(x, y) {
    const M = G.td, p = tdRoadAt(x, y); if (!p) return false;
    const H = tdTypHp(), tw = { def: TD_TW_BY.cats, lvl: 3, sp: -1, boost: 0, temp: true, s: -1, x: p.x, y: p.y - 40, post: p, stat: { n: 3, hp: H * 3, dmg: H * 0.14, cd: 0.8, rng: 140 }, units: [] };
    for (let i = 0; i < 3; i++) {
      const a = i * TAU / 3 + 0.6;
      tw.units.push({ id: ++M.uid, x: p.x + rnd(-24, 24), y: p.y - 34, dead: false, resp: 0, cd: 0, t: rnd(0, 5), face: 1, hp: tw.stat.hp, maxHp: tw.stat.hp, tw, px: p.x + Math.cos(a) * 15, py: p.y + Math.sin(a) * 11, temp: true, life: 16 });
    }
    M.temp.push(tw); tdRelist();
    burst(p.x, p.y, 24, '#ffb07a', 180); shockRing(p.x, p.y, '#ffd0a0', 80); Sound.sfx.meow();
    return true;
  }
  function tdSpellTick(dt) {
    const M = G.td;
    for (const k in M.spcd) if (M.spcd[k] > 0) M.spcd[k] -= dt;
    if (!M.stars.length || NET.client) return;
    for (const st of M.stars) {
      st.t -= dt; if (st.t > 0) continue;
      st.done = true;
      for (const e of G.enemies) if (!e.dead && (e.x - st.x) ** 2 + (e.y - st.y) ** 2 < (58 + e.r) ** 2) tdDmg(e, st.dmg, true, true);
      const b = G.activeBoss; if (b && b.state === 'fight' && Math.hypot(b.x - st.x, b.y - st.y) < 58 + b.r) tdDmg(b, st.dmg * 2, true);
    }
    M.stars = M.stars.filter(q => !q.done);
  }
  // нажали на заклинание, потом на карту
  function tdSpellBtn(id) {
    const M = G.td, D = TD_SPELLS[id]; if (!defOn() || !D || state !== 'play' || G.abyss.done) return;
    if (M.spcd[id] > 0) { toast(`${D.ic} ${D.nm}: ещё ${Math.ceil(M.spcd[id])} с`); Sound.sfx.block(); return; }
    if (M.aim === id) { M.aim = ''; Sound.sfx.click(); return; }
    M.aim = id; M.sel = -1; M.pick = ''; toast(D.hint); Sound.sfx.click();
  }
  function tdCast(id, x, y) {
    const M = G.td, D = TD_SPELLS[id];
    if (id === 'cats' && !tdRoadAt(x, y)) { toast('🐾 Нажми ближе к дороге'); Sound.sfx.block(); return; }
    M.aim = ''; M.spcd[id] = D.cd; life('defSpells');
    tdAct('m', 0, [id, Math.round(x), Math.round(y)]);
  }
  function tdFreeUnits(list) { for (const u of list) { if (u.tg) { u.tg.blk = null; u.tg = null; } u.dead = true; } }
  function tdMakeUnits(tw) {
    const M = G.td, S = tdUS(tw), old = tw.units || [];
    if (!tw.post) { // пост – ближайшая точка дороги
      let bd = 1e18;
      for (const L of M.lanes) for (let d = 70; d < L.total - 60; d += 14) { const o = tdLanePt(L, d, {}), dd = (o.px - tw.x) ** 2 + (o.py - tw.y) ** 2; if (dd < bd) { bd = dd; tw.post = { x: o.px, y: o.py }; } }
    }
    tw.units = [];
    for (let i = 0; i < S.n; i++) {
      const a = i * TAU / S.n + 0.6, u = old[i] || { id: ++M.uid, x: tw.x, y: tw.y + 14, dead: false, resp: 0, cd: 0, t: rnd(0, 5), face: 1, hp: 0, maxHp: 0 };
      const mh = S.hp * tdK(tw);
      u.tw = tw; u.px = tw.post.x + Math.cos(a) * 15; u.py = tw.post.y + Math.sin(a) * 11;
      u.hp = u.dead ? 0 : Math.min(mh, u.hp + (mh - u.maxHp)); u.maxHp = mh;
      tw.units.push(u);
    }
    tdFreeUnits(old.slice(S.n));
    tdRelist();
  }
  function tdUnitHurt(u, v) {
    if (u.dead) return;
    const S = tdUS(u.tw);
    if (S.dodge && Math.random() < S.dodge) { floatText(u.x, u.y - 22, 'мимо!', '#bfeaff'); return; }
    u.hp -= v * (1 - (S.armor || 0)); u.flash = 0.12;
    if (u.hp <= 0) { u.dead = true; u.resp = 9; if (u.temp) u.life = 0; if (u.tg) { u.tg.blk = null; u.tg = null; } burst(u.x, u.y, 10, '#ffb07a', 120); floatText(u.x, u.y - 22, '😿', '#fff'); }
  }
  function tdUnits(dt) {
    const M = G.td;
    let gone = false;
    for (const u of M.units) {
      const tw = u.tw, S = tdUS(tw);
      u.t += dt; if (u.flash > 0) u.flash -= dt; if (u.hit > 0) u.hit -= dt;
      if (u.temp) { u.life -= dt; if (u.life <= 0) { if (u.tg) { u.tg.blk = null; u.tg = null; } if (!u.dead) burst(u.x, u.y, 10, '#ffd0a0', 100); u.dead = true; u.gone = true; gone = true; continue; } }
      if (u.dead) { u.resp -= dt; if (u.resp <= 0) { u.dead = false; u.hp = u.maxHp; u.x = tw.x; u.y = tw.y + 14; burst(u.x, u.y, 8, '#ffd0a0', 90); } continue; }
      let e = u.tg; if (e && (e.dead || e.blk !== u)) u.tg = e = null;
      if (!e) {
        let bv = 1e18;
        for (const o of G.enemies) {
          if (o.dead || o.fly || o.ln === undefined || o.blk || o.ag || o.back || o.spawnT > 0) continue;
          if ((o.x - u.px) ** 2 + (o.y - u.py) ** 2 > 52 * 52) continue;
          if (o.rem < bv) { bv = o.rem; e = o; }
        }
        if (e) { u.tg = e; e.blk = u; e.blkT = 0.6; }
      }
      const tx = e ? e.x + (u.x < e.x ? -1 : 1) * (e.r + 8) : u.px, ty = e ? e.y + 2 : u.py;
      const dx = tx - u.x, dy = ty - u.y, d = Math.hypot(dx, dy);
      u.mv = d > 3;
      if (u.mv) { const st = Math.min(d, 150 * dt); u.x += dx / d * st; u.y += dy / d * st; u.face = dx > 0 ? 1 : -1; }
      if (e) {
        if (d < 16) {
          u.face = e.x > u.x ? 1 : -1; u.cd -= dt;
          if (u.cd <= 0) { u.cd = S.cd; u.hit = 0.15; const cr = !!S.dodge && Math.random() < 0.3; tdDmg(e, S.dmg * tdK(tw) * (cr ? 2 : 1), cr); }
        }
      } else if (u.hp < u.maxHp) u.hp = Math.min(u.maxHp, u.hp + u.maxHp * 0.06 * dt);
    }
    if (gone) { M.temp = M.temp.filter(t => t.units.some(u => !u.gone)); tdRelist(); }
  }

  // ---------- стройка ----------
  function tdFx(sp, col) { burst(sp.x, sp.y - 10, 18, col || '#ffd25a', 170); shockRing(sp.x, sp.y, col || '#ffd25a', 60); Sound.sfx.magic(); }
  // a: 'b' построить (k – башня), 'u' улучшить / выбрать мастерство (k = 0, 1) / усилить, 's' продать, 'c' позвать волну
  function tdAct(a, s, k) {
    if (!defOn() || G.abyss.done) return false;
    if (NET.client) {
      NetT.send(0, { t: 'bd', a, s, k });
      if (a === 'c') { const A = G.abyss; A.votes = A.votes || new Set(); if (A.votes.has(NET.id)) A.votes.delete(NET.id); else A.votes.add(NET.id); } // сразу видно своё «готова»
      return true;
    }
    return tdDo(a, s, k, 1);
  }
  // вместе волну раньше срока зовут, только когда нажали все; одна – сразу
  function tdVote(id) {
    const A = G.abyss; if (A.q.length || G.activeBoss || A.passed < A.wave || A.rest <= 0.4) return false;
    if (!(NET.host && G.netRun && netLiveMates() > 0)) return tdCall();
    A.votes = A.votes || new Set();
    if (A.votes.has(id)) A.votes.delete(id); else A.votes.add(id);
    tdVoteCheck();
    return true;
  }
  function tdVoteCheck() {
    const A = G.abyss; if (!A.votes || !A.votes.size) return;
    const ids = new Set([1, ...[...NET.peers.values()].filter(m => m.live).map(m => m.id)]); // кто вышел – того голос не ждём
    for (const v of [...A.votes]) if (!ids.has(v)) A.votes.delete(v);
    if (A.votes.size && A.votes.size >= ids.size) { A.votes.clear(); tdCall(); }
  }
  function tdDo(a, s, k, from) {
    const A = G.abyss, M = G.td; if (!defOn() || A.done) return false;
    if (a === 'c') return tdVote(from || 1);
    if (a === 'm') { const [id, x, y] = Array.isArray(k) ? k : []; if (!TD_SPELLS[id] || !isFinite(+x) || !isFinite(+y)) return false; return id === 'star' ? tdStarfall(+x, +y) : tdReinforce(+x, +y); }
    const sp = M.spots[s]; if (!sp) return false;
    if (a === 'b') {
      const def = TD_TW_BY[k]; if (!def || sp.tw || A.coins < def.lv[0].cost) return false;
      A.coins -= def.lv[0].cost; A.built++;
      sp.tw = { s: sp.i, k, def, lvl: 1, sp: -1, boost: 0, x: sp.x, y: sp.y, cd: 0.4, t: 0, aim: -Math.PI / 2, shot: 0, by: from || (NET.on ? NET.id || 1 : 1) };
      if (k === 'cats') tdMakeUnits(sp.tw);
      tdFx(sp, def.col);
      return true;
    }
    const tw = sp.tw; if (!tw) return false;
    if (a === 's') {
      A.coins += Math.round(tdSpent(tw) * TD_SELL);
      if (tw.units) tdFreeUnits(tw.units);
      sp.tw = null; tdRelist(); burst(sp.x, sp.y - 10, 16, '#ffd25a', 150); Sound.sfx.chest();
      return true;
    }
    if (a === 'u') {
      const cost = tdUpCost(tw, k); if (cost === null || A.coins < cost) return false;
      A.coins -= cost;
      if (tw.lvl < 3) tw.lvl++; else if (tw.lvl === 3) { tw.lvl = 4; tw.sp = k === 1 ? 1 : 0; lifeMax('defSpec', 1); } else tw.boost++;
      if (tw.k === 'cats') tdMakeUnits(tw);
      tdFx(sp, tw.def.col);
      return true;
    }
    return false;
  }
  // площадка под рукой – только та, по которой нажали (сама по себе, когда героиня подходит, не открывается)
  function tdCurSpot() {
    const M = G.td;
    if (M.sel >= 0) { if (G.time - M.selT < 30) return M.spots[M.sel]; M.sel = -1; M.pick = ''; }
    return null;
  }
  function tdTap(sx, sy) { // короткий тап по экрану: заклинание, выбор площадки или снятие выбора
    if (!defOn() || state !== 'play' || G.abyss.done) return;
    const M = G.td, wx = G.cam.x + (sx - VW / 2) / ZOOM, wy = G.cam.y + (sy - VH / 2) / ZOOM;
    if (M.aim) { tdCast(M.aim, wx, wy); return; }
    let best = -1, bd = 1e9;
    for (const sp of M.spots) { // по башне можно попасть и в саму башню, не только в площадку
      const dx = Math.abs(sp.x - wx), dy = wy - sp.y, hit = sp.tw ? dx < 34 && dy > -70 && dy < 26 : dx * dx + (dy - 5) ** 2 < 44 * 44;
      if (!hit) continue;
      const d = dx + Math.abs(dy - (sp.tw ? -20 : 5));
      if (d < bd) { bd = d; best = sp.i; }
    }
    if (best >= 0 && best !== M.sel) { M.sel = best; M.selT = G.time; M.pick = ''; Sound.sfx.click(); }
    else if (M.sel >= 0) { M.sel = -1; M.pick = ''; }
  }
  const tdStatLine = (def, S, k) => def.id === 'bank' ? `🪙 +${Math.round(S.inc * k)} за каждую отбитую волну` + (S.luck ? ` · 🍀 +${S.luck} за врага рядом` : '') + ' · 2-я копилка −25%, 3-я −50%'
    : def.id === 'wind' ? `⚔️ ${Math.round(S.dmg * k)} · ⏱ ${S.cd} с · 🎯 ${Math.round(S.rng / PX_PER_M)} м · 💨 назад ${Math.round(S.push / PX_PER_M)} м ×${S.n}` + (S.conf ? ' · 🌀' : '')
    : def.id === 'vine' ? `⚔️ ${Math.round(S.dmg * k)} · ⏱ ${S.cd} с · 🎯 ${Math.round(S.rng / PX_PER_M)} м · 🌿 держит ${S.root} с ×${S.n}`
    : def.id === 'mortar' ? `⚔️ ${Math.round(S.dmg * k)} · ⏱ ${S.cd} с · 🎯 ${Math.round(S.minR / PX_PER_M)}–${Math.round(S.rng / PX_PER_M)} м · 💥 ${Math.round(S.r / PX_PER_M)} м` + (S.stun ? ' · 💫' : '')
    : def.id === 'cats' ? `🐈 ${S.n} · ❤️ ${Math.round(S.hp * k)} · ⚔️ ${Math.round(S.dmg * k)}` : `⚔️ ${Math.round(S.dmg * k)} · ⏱ ${S.cd} с · 🎯 ${Math.round(S.rng / PX_PER_M)} м` + (S.slow ? ` · 🐌 −${Math.round((1 - S.slow) * 100)}%` : '') + (S.chain ? ` · ⚡×${S.chain}` : '');
  const TD_RING = 66;
  // каждый кадр: кнопка волны, заклинания и кольцо стройки вокруг выбранной площадки
  function tdPanelSync() {
    const on = defOn() && !G.abyss.done && state === 'play' && !G.cutscene, A = G.abyss, M = G.td;
    const ring = $('tdRing'), sk = $('defSkip'), spl = $('tdSpells');
    const sp = on ? tdCurSpot() : null;
    const canCall = on && !A.q.length && !G.activeBoss && A.passed >= A.wave && A.rest > 0.4;
    if (sk._on !== canCall) { sk._on = canCall; sk.classList.toggle('hidden', !canCall); sk._k = ''; }
    if (canCall) {
      const coop = NET.on && G.netRun && (NET.client || netLiveMates() > 0), need = NET.client ? A.need || 2 : 1 + netLiveMates(), myId = NET.host ? 1 : NET.id;
      const nv = A.votes ? A.votes.size : 0, mine = !!(A.votes && A.votes.has(myId));
      const b = tdCallBonus(), nt = A.next && A.next.tw, key = `${A.wave}:${Math.ceil(A.rest)}:${b}:${nt}:${coop ? nv + '/' + need + mine : ''}`;
      if (sk._k !== key) {
        sk._k = key;
        const tot = {}; if (A.next && A.next.sum) for (const [, list] of A.next.sum) for (const [tag, n] of list) tot[tag] = (tot[tag] || 0) + n;
        const who = Object.entries(tot).sort((x, y) => y[1] - x[1]).slice(0, 4).map(([tag, n]) => `${TD_TAG[tag] || '👣'}${n > 1 ? n : ''}`).join(' ');
        const X = nt ? TD_TWIST_BY[nt] : null;
        sk.innerHTML = (A.wave ? `⏩ Волна ${A.wave + 1} <small>через ${Math.ceil(A.rest)} с${b ? ` · +${b} 🪙` : ''}</small>` : `▶ Начать <small>волна 1 через ${Math.ceil(A.rest)} с</small>`) + (who ? `<small class="who">${who}</small>` : '') + (X ? `<small class="tw">${X.ic} ${X.nm}</small>` : '')
          + (coop ? `<small class="vt">${mine ? '✅ ты готова' : '✋ нажми, когда готова'} · ${nv}/${need}</small>` : '');
        sk.classList.toggle('voted', coop && mine);
      }
    }
    // заклинания
    if (spl._on !== on) { spl._on = on; spl.classList.toggle('hidden', !on); }
    if (on) for (const bt of spl.children) {
      const id = bt.dataset.s, D = TD_SPELLS[id], cd = Math.max(0, M.spcd[id] || 0), key = Math.ceil(cd) + (M.aim === id ? 'a' : '');
      if (bt._k === key) continue; bt._k = key;
      bt.style.setProperty('--cd', Math.round(cd / D.cd * 360) + 'deg');
      bt.classList.toggle('cool', cd > 0); bt.classList.toggle('aim', M.aim === id);
      bt.querySelector('b').textContent = cd > 0 ? Math.ceil(cd) : '';
    }
    if (ring._on !== !!sp) { ring._on = !!sp; ring.classList.toggle('hidden', !sp); ring._k = ''; ring._p = ''; }
    if (M) M.cur = sp ? sp.i : -1;
    if (!sp) return;
    // кольцо стоит прямо на площадке и едет вместе с картой
    const R = TD_RING, RO = sp.tw ? R : R + 44, cx = clamp((sp.x - G.cam.x) * ZOOM + VW / 2, RO + 30, VW - RO - 30), cy = clamp((sp.y - 14 - G.cam.y) * ZOOM + VH / 2, SAFE_TOP + RO + 36, VH - RO - 40);
    // подсказка над кольцом или под ним; в портретном экране не залезает на заклинания справа
    const upFits = cy - R - 150 > SAFE_TOP + 20, tipM = upFits ? 'up' : cy + R + 160 < VH ? 'down' : 'side'; // в горизонтальном экране места мало – тогда подсказка сбоку
    const off = clamp(cx + (tipM === 'side' ? (cx > VW / 2 ? -(R + 160) : R + 160) : 0), 125, VW - 125 - (VH > VW && cy - R - 150 < SAFE_TOP + 290 ? 66 : 0)) - cx, pk = `${Math.round(cx)},${Math.round(cy)},${tipM},${Math.round(off)}`;
    if (ring._p !== pk) { ring._p = pk; ring.style.transform = `translate(${Math.round(cx)}px, ${Math.round(cy)}px)`; }
    const tw = sp.tw, c = A.coins;
    const key = `${sp.i}|${tw ? tw.k + tw.lvl + tw.sp + ':' + tw.boost : ''}|${M.pick}|${tw ? (c >= (tdUpCost(tw, 0) || 1e9)) + ':' + (c >= (tdUpCost(tw, 1) || 1e9)) : TD_TOWERS.map(d => c >= d.lv[0].cost ? 1 : 0).join('')}|${tipM}|${Math.round(off)}`;
    if (ring._k === key) return; ring._k = key;
    const at = deg => [Math.round(Math.cos(deg * Math.PI / 180) * R), Math.round(Math.sin(deg * Math.PI / 180) * R)];
    const btn = (a, k, ic, tx, no, deg, cls) => { const [x, y] = cls === 'outer' ? [Math.round(Math.cos(deg * Math.PI / 180) * (R + 44)), Math.round(Math.sin(deg * Math.PI / 180) * (R + 44))] : at(deg); return `<button data-a="${a}" data-k="${k}" class="${no ? 'no ' : ''}${M.pick === a + ':' + k ? 'on ' : ''}${cls || ''}" style="left:${x}px;top:${y}px"><i>${ic}</i><b>${tx}</b></button>`; };
    let title, row = '', desc = '';
    if (!tw) {
      title = '🔨 Что построим?';
      TD_TOWERS.forEach((d, i) => { row += i < 5 ? btn('b', d.id, d.ic, d.lv[0].cost, c < d.lv[0].cost, -90 + i * 72) : btn('b', d.id, d.ic, d.lv[0].cost, c < d.lv[0].cost, -54 + (i - 5) * 72, 'outer'); });
      const pk = M.pick.startsWith('b:') ? TD_TW_BY[M.pick.slice(2)] : null;
      desc = pk ? `<b>${pk.ic} ${pk.nm}</b> – ${pk.ds}<br><span>${tdStatLine(pk, pk.lv[0], 1)}</span><u>Нажми ещё раз – построим</u>` : 'Нажми на башню – расскажу, что она умеет';
    } else {
      const d = tw.def, S = tdStat(d, tw.lvl, tw.sp), k = tdK(tw), sell = Math.round(tdSpent(tw) * TD_SELL);
      title = `${tw.lvl >= 4 ? S.ic : d.ic} ${tw.lvl >= 4 ? S.nm : d.nm} · ${tw.lvl >= 4 ? 'мастер' + (tw.boost ? ' +' + tw.boost : '') : 'ур. ' + tw.lvl}`;
      desc = `<span>${tdStatLine(d, S, k)}</span>` + (tw.fr ? '<br>🤝 +15% – рядом башня подруги' : NET.on && G.netRun ? '<br><small>🤝 Поставь рядом с башней подруги – обе станут сильнее</small>' : '');
      if (tw.lvl < 3) {
        const N = d.lv[tw.lvl]; row += btn('u', 0, '⬆️', N.cost, c < N.cost, -90);
        if (M.pick === 'u:0') desc = `Уровень ${tw.lvl + 1}:<br><span>${tdStatLine(d, N, 1)}</span><u>Нажми ещё раз – улучшим</u>`;
      } else if (tw.lvl === 3) {
        d.sp.forEach((N, i) => { row += btn('u', i, N.ic, N.cost, c < N.cost, i ? -40 : -140); });
        const i = M.pick === 'u:1' ? 1 : M.pick === 'u:0' ? 0 : -1;
        desc = i >= 0 ? `<b>${d.sp[i].ic} ${d.sp[i].nm}</b> – ${d.sp[i].ds}<br><span>${tdStatLine(d, d.sp[i], 1)}</span><u>Нажми ещё раз – выберем это мастерство</u>` : desc + '<br>Пора выбрать мастерство – одно из двух';
      } else {
        const cost = tdUpCost(tw, 0);
        if (cost !== null) { row += btn('u', 0, '💪', cost, c < cost, -90); if (M.pick === 'u:0') desc = `Усиление: +${Math.round(TD_BOOST.k * 100)}% ${tw.k === 'bank' ? 'к монеткам' : 'к силе'}<br><span>${tdStatLine(d, S, k + TD_BOOST.k)}</span><u>Нажми ещё раз – усилим</u>`; }
      }
      row += btn('s', 0, '💰', '+' + sell, false, 90, 'sell');
      if (M.pick === 's:0') desc = `Продать и вернуть ${sell} 🪙?<u>Нажми ещё раз – продадим</u>`;
    }
    ring.classList.toggle('wide', !tw);
    ring.innerHTML = `<div class="tdDisc"></div>${row}<div class="tdTip ${tipM}" style="left:${Math.round(off)}px"><div class="tdT">${title}</div><div class="tdD">${desc}</div></div>`;
  }
  function tdPanelTap(b) {
    if (!defOn() || !b) return;
    const M = G.td, A = G.abyss, sp = tdCurSpot(); if (!sp) return;
    const a = b.dataset.a, raw = b.dataset.k, k = a === 'b' ? raw : +raw, key = a + ':' + raw;
    M.selT = G.time; // пока с площадкой возятся, кольцо не гаснет
    if (M.pick !== key) { M.pick = key; Sound.sfx.click(); return; }
    const cost = a === 'b' ? TD_TW_BY[k].lv[0].cost : a === 'u' ? tdUpCost(sp.tw, k) : 0;
    if (a !== 's' && A.coins < cost) { toast(`Нужно ${cost} 🪙 – монетки дают за врагов`); Sound.sfx.block(); A.coinNoT = G.time; return; }
    M.pick = '';
    if (tdAct(a, sp.i, k) && NET.client) { burst(sp.x, sp.y - 10, 10, '#ffd25a', 120); Sound.sfx.magic(); }
  }
  // дальность: у выбранной башни – её, у выбранной покупки – будущая
  function tdRingOf(sp) {
    const M = G.td, tw = sp.tw, p = M.pick;
    if (!tw) return p.startsWith('b:') ? TD_TW_BY[p.slice(2)].lv[0].rng : 0;
    if (tw.lvl < 3 && p === 'u:0') return tw.def.lv[tw.lvl].rng;
    if (tw.lvl === 3 && p.startsWith('u:')) return tw.def.sp[+p.slice(2)].rng;
    return tdStat(tw.def, tw.lvl, tw.sp).rng;
  }

  // ---------- героиня без сил и конец обороны ----------
  function defDown() {
    if (P.down) return;
    buzz(220);
    P.down = true; P.hp = 0; P.revT = 0; P.stormT = 0; P.tdRev = 8; G.combo = 0;
    burst(P.x, P.y, 30, '#c9b3ff', 220); Sound.sfx.hurt();
    showBanner('Без сил!', NET.on && G.netRun ? 'Подруга поднимет – или кристалл вернёт силы через 8 с' : 'Кристалл вернёт силы через 8 секунд');
    if (G.st) G.st.deaths++;
  }
  function tdHeroTick(dt) {
    if (!P.down) return;
    P.inv = Math.max(P.inv, 0.3); P.tdRev = (P.tdRev === undefined ? 8 : P.tdRev) - dt;
    if (P.tdRev > 0) return;
    const C = G.core;
    P.down = false; P.revT = 0; P.x = C.x + rnd(-40, 40); P.y = C.y + 70; ensureWalkable(P); P.hp = Math.round(P.maxHp * 0.6); P.inv = 2.5; P.dashT = 0;
    burst(P.x, P.y, 26, '#ff8ad8', 220); Sound.sfx.heart(); showBanner('Снова в строю!', 'Кристалл поделился силой 💗');
  }
  function defLose() {
    const A = G.abyss, C = G.core; if (!A || A.done) return;
    burst(C.x, C.y - 20, 80, '#ff8ad8', 380); shockRing(C.x, C.y, '#ff8ad8', 360); G.shake = 18; Sound.sfx.shatter();
    defFinish(); defEndScreen();
  }
  function defFinish() {
    const A = G.abyss; if (!A || !A.def || A.done) return; A.done = true;
    const cleared = Math.max(A.passed, A.wave - 1, 0); A.cleared = cleared;
    if (cleared > A.passed) { A.passed = cleared; defWaveDone(cleared); }
    if (NET.host && G.netRun) NetT.send(-1, { t: 'dend', wave: cleared, time: Math.round(A.t), hp: G.core.hp });
    recordRunEnd(`оборона «${TD_MAP_BY[A.map].nm}»: отбито волн ${cleared}`);
    if (G.td) { G.td.sel = -1; G.td.pick = ''; }
  }
  function defEndScreen() {
    const A = G.abyss, M = TD_MAP_BY[A.map], w = A.cleared || 0, best = (loadProfile().tdBest || {})[A.map];
    state = 'dying'; P.down = false;
    setTimeout(() => {
      if (!G.abyss || G.abyss !== A) return;
      $('deadTitle').textContent = w >= 20 ? `🏆 Отбито волн: ${w}!` : w >= 10 ? `🛡️ Отбито волн: ${w}` : '💎 Кристалл разбит…';
      $('deadText').innerHTML = `${M.ic} ${M.nm} · волн отбито: <b>${w}</b> · ${fmtT(A.t)}<br>Башен построено: ${A.built} · врагов: ${G.kills}` +
        (A.better ? '<br>🏆 Новый рекорд!' : best ? `<br>Рекорд: ${best.wave} ${plural(best.wave, 'волна', 'волны', 'волн')}` : '') + (NET.on && G.netRun && NET.client ? '<br>Заново начнёт хозяйка' : '');
      setState('dead');
    }, 900);
  }
  function defInfo() {
    const A = G.abyss;
    return `🛡️ ${A.wave ? 'Волна ' + A.wave : 'Готовься'}` + (A.twist ? ' ' + TD_TWIST_BY[A.twist].ic : '') + (A.q.length ? ` · идут: ${A.q.length}` : A.wave && A.passed < A.wave ? ` · добей: ${G.enemies.filter(e => !e.dead && e.ln !== undefined).length}` : '');
  }

  // ---------- вместе: гостья ----------
  function defClientTick(dt) {
    const A = G.abyss, C = G.core, M = G.td; if (!A || A.done) return;
    A.t += dt; if (A.rest > 0 && !A.spawning) A.rest -= dt;
    if (A.hkW !== A.wave) { A.hkW = A.wave; A.heroK = tdHeroK(); }
    C.t += dt; if (C.flash > 0) C.flash -= dt;
    tdHeroTick(dt); tdSpellTick(dt);
    tdTowers(dt, false); tdShots(dt); tdPools(dt);
    const k = Math.min(1, dt * 14);
    for (const u of M.units) { u.t += dt; if (u.tx !== undefined) { u.mv = Math.abs(u.tx - u.x) + Math.abs(u.ty - u.y) > 2; u.x += (u.tx - u.x) * k; u.y += (u.ty - u.y) * k; } }
  }
  function defSnap() {
    const A = G.abyss, M = G.td, b = bosses[0];
    return [A.wave, G.core.hp, A.q.length || G.activeBoss || A.passed < A.wave ? -1 : Math.round(A.rest * 10), A.coins, A.passed,
      M.spots.filter(s => s.tw).map(s => [s.i, TD_TOWERS.indexOf(s.tw.def), s.tw.lvl, s.tw.sp, s.tw.boost, s.tw.silT > 0 ? 1 : 0, s.tw.by || 1]),
      M.units.map(u => [u.id, u.x | 0, u.y | 0, u.dead ? 0 : Math.max(1, Math.round(u.hp / u.maxHp * 100)), u.tw.temp ? -1 : u.tw.s, u.face > 0 ? 1 : 0]),
      A.next ? A.next.sum : 0, b && A.bw ? [b.kind, b.level, A.bw] : 0, A.q.length, A.twist || '', A.next ? A.next.tw || '' : '', A.votes ? [...A.votes] : [], 1 + netLiveMates()];
  }
  function defNetApply(dz) {
    const A = G.abyss, C = G.core, M = G.td; if (!A || !A.def || A.done || !C || !M) return;
    const [w, hp, rest, coins, passed, tws, uns, nx, bk, ql, twist, ntw, votes, need] = dz;
    A.votes = new Set(votes || []); A.need = need || 2;
    A.twist = twist || '';
    A.wave = w; A.spawning = rest < 0; if (rest >= 0) A.rest = rest / 10; A.coins = coins; A.passed = passed; A.q = { length: ql || 0 };
    if (hp < C.hp) tdCoreFx(C.hp - hp);
    C.hp = hp;
    A.next = nx ? { sum: nx, tw: ntw || '' } : null;
    if (bk && A.bw !== bk[2]) { // хозяйка выпустила стража – у гостьи он тоже должен появиться
      A.bw = bk[2]; CFG.bosses = [bk[0]]; CFG.bossLevels = [bk[1]]; CFG.bossTiles = [{ x: Math.floor(C.x / T), y: Math.floor(C.y / T) }]; G.defeated = [false];
      if (BOSSES[bk[0]]) makeBosses();
    }
    const seen = new Set();
    for (const [s, ti, lvl, spc, boost, sil, by] of tws || []) {
      const sp = M.spots[s], def = TD_TOWERS[ti]; if (!sp || !def) continue;
      seen.add(s);
      const tw = sp.tw;
      if (tw) { tw.silT = sil ? 0.6 : 0; tw.by = by || 1; }
      if (!tw || tw.def !== def) { sp.tw = { s, k: def.id, def, lvl, sp: spc, boost, x: sp.x, y: sp.y, cd: 0.4, t: 0, aim: -Math.PI / 2, shot: 0, by: by || 1 }; tdFx(sp, def.col); }
      else if (tw.lvl !== lvl || tw.sp !== spc || tw.boost !== boost) { tw.lvl = lvl; tw.sp = spc; tw.boost = boost; tdFx(sp, def.col); }
    }
    for (const sp of M.spots) if (sp.tw && !seen.has(sp.i)) { sp.tw = null; burst(sp.x, sp.y - 10, 14, '#ffd25a', 130); }
    const old = new Map(M.units.map(u => [u.id, u]));
    M.units = [];
    for (const [id, x, y, hpP, s, f] of uns || []) {
      const tw = s < 0 ? (M.tempTw || (M.tempTw = { def: TD_TW_BY.cats, lvl: 3, sp: -1, boost: 0, temp: true, stat: { n: 3, hp: 100, dmg: 0, cd: 1, rng: 140 } })) : M.spots[s] && M.spots[s].tw; if (!tw) continue;
      const u = old.get(id) || { id, x, y, t: 0 };
      u.tx = x; u.ty = y; u.dead = !hpP; u.hp = hpP; u.maxHp = 100; u.tw = tw; u.face = f ? 1 : -1;
      M.units.push(u);
    }
  }

  // ---------- рисование ----------
  function tdEll(c, x, y, rx, ry, col) { c.fillStyle = col; c.beginPath(); c.ellipse(x, y, rx, ry, 0, 0, TAU); c.fill(); }
  function tdEmoji(c, ch, x, y, size) { c.globalAlpha = 1; c.fillStyle = '#fff'; c.font = `${size}px sans-serif`; c.textAlign = 'center'; c.fillText(ch, x, y); }
  function drawDefGround(c, vis) {
    const A = G.abyss, M = G.td, C = G.core, t = G.time;
    for (const L of M.lanes) { // входы: воронки, откуда приходят враги
      const g = L.gate; if (!vis(g.x, g.y, 110)) continue;
      const on = L.from <= A.wave + 1;
      const gr = c.createRadialGradient(g.x, g.y, 4, g.x, g.y, 58); gr.addColorStop(0, on ? 'rgba(170,60,220,0.75)' : 'rgba(90,90,110,0.5)'); gr.addColorStop(1, 'rgba(60,0,90,0)');
      c.fillStyle = gr; c.beginPath(); c.ellipse(g.x, g.y, 58, 34, 0, 0, TAU); c.fill();
      if (!on) continue;
      c.strokeStyle = 'rgba(224,160,255,0.28)'; c.lineWidth = 2; c.setLineDash([6, 9]); c.beginPath(); c.arc(g.x, g.y, 150, 0, TAU); c.stroke(); c.setLineDash([]); // зона защиты портала
      c.save(); c.translate(g.x, g.y); c.scale(1, 0.58); c.rotate(t * 1.5); c.strokeStyle = 'rgba(240,170,255,0.85)'; c.lineWidth = 3; c.setLineDash([12, 10]);
      c.beginPath(); c.arc(0, 0, 40, 0, TAU); c.stroke(); c.rotate(-t * 2.6); c.strokeStyle = 'rgba(255,255,255,0.5)'; c.beginPath(); c.arc(0, 0, 24, 0, TAU); c.stroke(); c.restore();
    }
    for (const p of M.pools) { // горящие лужи
      const a = clamp(p.t / 0.6, 0, 1);
      c.fillStyle = `rgba(255,110,20,${0.3 * a})`; c.beginPath(); c.ellipse(p.x, p.y, p.r, p.r * 0.62, 0, 0, TAU); c.fill();
      c.fillStyle = `rgba(255,210,60,${0.28 * a})`; c.beginPath(); c.ellipse(p.x, p.y, p.r * 0.6, p.r * 0.36, 0, 0, TAU); c.fill();
    }
    for (const sp of M.spots) {
      if (!vis(sp.x, sp.y, 240)) continue;
      const tw = sp.tw, cur = M.cur === sp.i;
      if (tw && tw.k === 'frost') { // холодный круг
        const S = tdStat(tw.def, tw.lvl, tw.sp);
        c.fillStyle = `rgba(150,220,255,${0.07 + 0.03 * Math.sin(tw.t * 3) + (tw.shot > 0 ? 0.08 : 0)})`; c.beginPath(); c.arc(sp.x, sp.y, S.rng, 0, TAU); c.fill();
      }
      if (cur) { // дальность выбранной башни
        const r = tdRingOf(sp);
        if (r) { c.fillStyle = 'rgba(255,255,255,0.07)'; c.beginPath(); c.arc(sp.x, sp.y, r, 0, TAU); c.fill(); c.strokeStyle = 'rgba(255,255,255,0.55)'; c.lineWidth = 2; c.setLineDash([8, 7]); c.stroke(); c.setLineDash([]); }
      }
      tdEll(c, sp.x, sp.y + 12, 27, 12, 'rgba(0,0,0,0.28)');
      tdEll(c, sp.x, sp.y + 8, 25, 11, '#77728a'); tdEll(c, sp.x, sp.y + 5, 23, 10, cur ? '#e9e2ff' : '#aaa5bd');
      if (cur) { c.strokeStyle = '#ffd25a'; c.lineWidth = 2.5; c.beginPath(); c.ellipse(sp.x, sp.y + 5, 27, 12.5, 0, 0, TAU); c.stroke(); }
      if (!tw) { c.globalAlpha = 0.55 + 0.35 * Math.sin(t * 3 + sp.i); tdEmoji(c, '🔨', sp.x, sp.y + 11 + Math.sin(t * 3 + sp.i) * 1.5, 17); c.globalAlpha = 1; }
    }
    // круг кристалла: сколько ещё выдержит
    const hpF = clamp(C.hp / TD_LIVES, 0, 1);
    c.lineWidth = 5; c.strokeStyle = 'rgba(0,0,0,0.4)'; c.beginPath(); c.ellipse(C.x, C.y + 12, 44, 15, 0, 0, TAU); c.stroke();
    c.strokeStyle = hpF > 0.5 ? '#ff8ad8' : hpF > 0.25 ? '#ffd25a' : '#ff4d4d';
    c.beginPath(); c.ellipse(C.x, C.y + 12, 44, 15, 0, -Math.PI / 2, -Math.PI / 2 + TAU * hpF); c.stroke();
    if (NET.on && G.netRun && G.td) { // ниточки дружбы между башнями разных игроков
      c.save(); c.setLineDash([5, 6]); c.lineDashOffset = -G.time * 12; c.lineWidth = 2;
      for (const sp of G.td.spots) { const a = sp.tw; if (!a || !a.frL) continue; for (const b of a.frL) { if (b.s < a.s) continue; const g = c.createLinearGradient(a.x, a.y, b.x, b.y); g.addColorStop(0, mateCol(a.by || 1)); g.addColorStop(1, mateCol(b.by || 1)); c.strokeStyle = g; c.globalAlpha = 0.75; c.beginPath(); c.moveTo(a.x, a.y + 8); c.lineTo(b.x, b.y + 8); c.stroke(); } }
      c.restore();
    }
  }
  function drawDefCore(c) {
    const C = G.core, t = C.t, y = C.y - 30 + Math.sin(t * 2) * 4, hpF = clamp(C.hp / TD_LIVES, 0, 1);
    shadow(c, C.x, C.y + 10, 26, 8);
    const g = c.createRadialGradient(C.x, y, 4, C.x, y, 74); g.addColorStop(0, `rgba(255,140,220,${0.45 + 0.2 * Math.sin(t * 3)})`); g.addColorStop(1, 'rgba(255,140,220,0)');
    c.fillStyle = g; c.beginPath(); c.arc(C.x, y, 74, 0, TAU); c.fill();
    c.save(); c.translate(C.x, y);
    const w = 24, h = 40, fl = C.flash > 0;
    c.fillStyle = fl ? '#ffffff' : '#ff9ad8'; c.beginPath(); c.moveTo(0, -h); c.lineTo(w, -6); c.lineTo(0, h * 0.75); c.closePath(); c.fill();
    c.fillStyle = fl ? '#ffe0f0' : '#8ad8ff'; c.beginPath(); c.moveTo(0, -h); c.lineTo(-w, -6); c.lineTo(0, h * 0.75); c.closePath(); c.fill();
    c.fillStyle = 'rgba(255,255,255,0.55)'; c.beginPath(); c.moveTo(0, -h); c.lineTo(w * 0.45, -12); c.lineTo(0, -3); c.lineTo(-w * 0.45, -12); c.closePath(); c.fill();
    c.strokeStyle = 'rgba(255,255,255,0.85)'; c.lineWidth = 1.5; c.beginPath(); c.moveTo(0, -h); c.lineTo(w, -6); c.lineTo(0, h * 0.75); c.lineTo(-w, -6); c.closePath(); c.stroke();
    if (hpF < 0.5) { // трещины
      c.strokeStyle = 'rgba(60,10,40,0.75)'; c.lineWidth = 1.5; c.beginPath(); c.moveTo(-4, -26); c.lineTo(3, -14); c.lineTo(-2, -4); c.lineTo(6, 8);
      if (hpF < 0.25) { c.moveTo(10, -10); c.lineTo(4, 0); c.lineTo(12, 6); c.moveTo(-14, -6); c.lineTo(-6, 4); }
      c.stroke();
    }
    c.restore();
    for (let k = 0; k < 3; k++) { const a = t * 1.4 + k * TAU / 3; c.fillStyle = k === 1 ? '#8ad8ff' : '#ffd0f0'; c.beginPath(); c.arc(C.x + Math.cos(a) * 34, y + Math.sin(a) * 12 - 4, 2.6, 0, TAU); c.fill(); }
    c.font = 'bold 13px sans-serif'; c.textAlign = 'center'; c.fillStyle = '#000'; c.fillText(`💎 ${C.hp}`, C.x + 1, C.y + 43);
    c.fillStyle = '#fff'; c.fillText(`💎 ${C.hp}`, C.x, C.y + 42);
  }
  function drawDefTower(c, tw) {
    const x = tw.x, y = tw.y, d = tw.def, L = tw.lvl, S = tdStat(d, L, tw.sp), top = L >= 4 ? S.ic : d.ic, sz = 20 + Math.min(L, 4) * 2, fire = tw.shot > 0;
    if (paperOn) { // 1.0: каменная площадка с акварельной подкладкой цвета башни
      c.fillStyle = 'rgba(70,45,20,.22)'; c.beginPath(); c.ellipse(x + 3, y + 12, 25, 8.5, 0, 0, TAU); c.fill();
      c.fillStyle = '#d8ccb4'; c.beginPath(); c.ellipse(x, y + 9, 23, 8, 0, 0, TAU); c.fill();
      c.globalAlpha = 0.4; c.fillStyle = d.col; c.beginPath(); c.ellipse(x, y + 8, 19, 6, 0, 0, TAU); c.fill(); c.globalAlpha = 1;
      c.strokeStyle = INK; c.lineWidth = 1.3; c.beginPath(); c.ellipse(x, y + 9, 23, 8, 0, 0, TAU); c.stroke();
      c.strokeStyle = 'rgba(75,46,30,.35)'; c.lineWidth = 1; for (let k = 0; k < 6; k++) { const a = k * TAU / 6 + 0.3; c.beginPath(); c.moveTo(x + Math.cos(a) * 15, y + 9 + Math.sin(a) * 5); c.lineTo(x + Math.cos(a) * 23, y + 9 + Math.sin(a) * 8); c.stroke(); }
    }
    const body = (w, h, c1, c2) => { // сужающийся кверху корпус
      c.fillStyle = c2; c.beginPath(); c.moveTo(x - w, y + 8); c.lineTo(x + w, y + 8); c.lineTo(x + w * 0.72, y - h); c.lineTo(x - w * 0.72, y - h); c.closePath(); c.fill();
      if (paperOn) { c.strokeStyle = INK; c.lineWidth = 1.4; c.lineJoin = 'round'; c.stroke(); }
      c.fillStyle = c1; c.beginPath(); c.moveTo(x - w, y + 8); c.lineTo(x - w * 0.1, y + 8); c.lineTo(x - w * 0.1, y - h); c.lineTo(x - w * 0.72, y - h); c.closePath(); c.fill();
      if (paperOn) { c.strokeStyle = 'rgba(75,46,30,.45)'; c.lineWidth = 0.8; for (let yy = y - 4; yy > y - h + 4; yy -= 7) { c.beginPath(); c.moveTo(x - w * 0.95 + (y + 8 - yy) * (w * 0.28) / (h + 8), yy); c.lineTo(x + w * 0.95 - (y + 8 - yy) * (w * 0.28) / (h + 8), yy); c.stroke(); } }
    };
    if (tw.k === 'feather') {
      body(13, 26 + L * 2, '#9a6ad0', '#7a4fa8'); c.fillStyle = '#e0c8ff'; c.fillRect(x - 13, y - 30 - L * 2, 26, 6);
      c.save(); c.translate(x, y - 42 - L * 2); c.rotate(clamp(Math.cos(tw.aim) * 0.5, -0.5, 0.5)); if (fire) c.scale(1.2, 1.2); tdEmoji(c, top, 0, 8, sz); c.restore();
    } else if (tw.k === 'fire') {
      body(15, 16 + L, '#8a7a78', '#5f5250'); tdEll(c, x, y - 17 - L, 14, 5.5, '#2a1c1a');
      const fl = 1 + 0.08 * Math.sin(tw.t * 11) + (fire ? 0.25 : 0);
      c.save(); c.translate(x, y - 18 - L); c.scale(fl, fl); tdEmoji(c, top, 0, 0, sz + 2); c.restore();
    } else if (tw.k === 'frost') {
      body(11, 12, '#9ad8f0', '#5fa8c8');
      const g = c.createRadialGradient(x, y - 30, 2, x, y - 30, 24); g.addColorStop(0, `rgba(190,240,255,${fire ? 0.8 : 0.45})`); g.addColorStop(1, 'rgba(190,240,255,0)');
      c.fillStyle = g; c.beginPath(); c.arc(x, y - 30, 24, 0, TAU); c.fill();
      tdEmoji(c, top, x, y - 22 + Math.sin(tw.t * 2.2) * 3, sz);
    } else if (tw.k === 'disco') {
      c.fillStyle = '#4a3a6a'; c.fillRect(x - 3, y - 34, 6, 42); if (paperOn) { c.strokeStyle = INK; c.lineWidth = 1.2; c.strokeRect(x - 3, y - 34, 6, 42); } tdEll(c, x, y + 6, 11, 4.5, '#6a5a8a');
      c.save(); c.translate(x, y - 44); c.globalAlpha = fire ? 0.9 : 0.4; c.strokeStyle = '#fff3a0'; c.lineWidth = 2;
      for (let i = 0; i < 6; i++) { const a = tw.t * 1.8 + i * TAU / 6; c.beginPath(); c.moveTo(Math.cos(a) * 14, Math.sin(a) * 14); c.lineTo(Math.cos(a) * (fire ? 30 : 21), Math.sin(a) * (fire ? 30 : 21)); c.stroke(); }
      c.restore(); c.globalAlpha = 1;
      tdEmoji(c, top, x, y - 36, sz);
    } else if (tw.k === 'wind') { // ветряк: башенка и крутящиеся лопасти
      body(11, 26 + L * 2, '#e8dcc8', '#c8b8a0');
      c.save(); c.translate(x, y - 30 - L * 2); c.rotate(tw.t * (tw.gust > 0 ? 9 : 2.5));
      for (let i = 0; i < 4; i++) { c.rotate(TAU / 4); c.fillStyle = i % 2 ? '#a8d8e8' : '#f6f0e0'; c.beginPath(); c.moveTo(0, 0); c.lineTo(5, -4); c.lineTo(22 + L, -2); c.lineTo(22 + L, 4); c.closePath(); c.fill(); if (paperOn) { c.strokeStyle = INK; c.lineWidth = 1.1; c.stroke(); } }
      c.fillStyle = '#8a6a4a'; c.beginPath(); c.arc(0, 0, 3.5, 0, TAU); c.fill(); c.restore();
      if (L >= 4) tdEmoji(c, S.ic, x, y - 4, 13);
    } else if (tw.k === 'bank') { // копилка: свинка на подушке и выпрыгивающие монетки
      tdEll(c, x, y + 2, 15, 6, '#c86a8a'); if (paperOn) { c.strokeStyle = INK; c.lineWidth = 1.1; c.beginPath(); c.ellipse(x, y + 2, 15, 6, 0, 0, TAU); c.stroke(); }
      c.save(); c.translate(x, y - 14 + (tw.shot > 0 ? -4 : 0)); const bs = 1 + (tw.shot > 0 ? 0.12 : 0); c.scale(bs, bs); tdEmoji(c, L >= 4 ? S.ic : d.ic, 0, 8, sz + 4); c.restore();
      if (tw.pop) { const a = clamp(tw.pop.t / 0.6, 0, 1), up = (1 - tw.pop.t / 1.2) * 26; c.globalAlpha = a; if (paperOn) handText(c, '+' + tw.pop.v + ' 🪙', x, y - 40 - up, 15, '#b8802a', 'center', 'rgba(251,243,224,.9)'); else { c.font = 'bold 12px sans-serif'; c.fillStyle = '#ffd25a'; c.fillText('+' + tw.pop.v + ' 🪙', x, y - 40 - up); } c.globalAlpha = 1; }
    } else if (tw.k === 'vine') { // плющ: горшок и вьющиеся стебли
      body(12, 10, '#c86a3a', '#a84a2a');
      c.strokeStyle = '#4a8a3a'; c.lineWidth = 3; c.lineCap = 'round';
      for (let i = 0; i < 3; i++) { const sw = Math.sin(tw.t * 2 + i * 2) * 4; c.beginPath(); c.moveTo(x - 6 + i * 6, y - 10); c.quadraticCurveTo(x - 12 + i * 10 + sw, y - 24, x - 8 + i * 8 + sw, y - 36 - L * 2 - i * 3); c.stroke(); }
      c.lineCap = 'butt'; tdEmoji(c, L >= 4 ? S.ic : d.ic, x, y - 30 - L * 2, sz - 2);
    } else if (tw.k === 'mortar') { // хлопушка: короткая пушка, смотрит в сторону цели
      tdEll(c, x, y + 2, 14, 6, '#7a5a3a');
      c.save(); c.translate(x, y - 8); c.rotate(clamp(Math.cos(tw.aim) * 0.6, -0.6, 0.6) - 0.5);
      c.fillStyle = '#d84a5a'; c.beginPath(); c.roundRect(-7, -26, 14, 26, 4); c.fill(); c.fillStyle = '#f2c84a'; c.fillRect(-7, -20, 14, 4); c.fillRect(-7, -10, 14, 4);
      if (paperOn) { c.strokeStyle = INK; c.lineWidth = 1.3; c.beginPath(); c.roundRect(-7, -26, 14, 26, 4); c.stroke(); }
      if (fire) { c.fillStyle = 'rgba(255,230,120,.9)'; c.beginPath(); c.arc(0, -30, 7, 0, TAU); c.fill(); }
      c.restore(); tdEmoji(c, L >= 4 ? S.ic : d.ic, x + 14, y - 26, 13);
    } else { // кошкин дом
      c.fillStyle = '#e89a5a'; c.fillRect(x - 15, y - 16, 30, 24); c.fillStyle = '#ffb884'; c.fillRect(x - 15, y - 16, 12, 24);
      if (paperOn) { c.strokeStyle = INK; c.lineWidth = 1.4; c.strokeRect(x - 15, y - 16, 30, 24); }
      c.fillStyle = '#b84a3a'; c.beginPath(); c.moveTo(x - 20, y - 15); c.lineTo(x, y - 34 - L); c.lineTo(x + 20, y - 15); c.closePath(); c.fill();
      if (paperOn) { c.strokeStyle = INK; c.lineWidth = 1.4; c.lineJoin = 'round'; c.stroke(); c.strokeStyle = 'rgba(75,46,30,.4)'; c.lineWidth = 0.8; for (let k = 1; k < 4; k++) { c.beginPath(); c.moveTo(x - 20 + k * 4, y - 15 - k * 4.8 - k * L / 4); c.lineTo(x + 20 - k * 4, y - 15 - k * 4.8 - k * L / 4); c.stroke(); } }
      c.fillStyle = '#b84a3a'; c.beginPath(); c.moveTo(x - 12, y - 24); c.lineTo(x - 9, y - 36 - L); c.lineTo(x - 4, y - 28); c.closePath(); c.fill(); c.beginPath(); c.moveTo(x + 12, y - 24); c.lineTo(x + 9, y - 36 - L); c.lineTo(x + 4, y - 28); c.closePath(); c.fill();
      c.fillStyle = '#3a2218'; c.beginPath(); c.arc(x, y + 8, 7, Math.PI, 0); c.fill();
      tdEmoji(c, L >= 4 ? S.ic : '🐾', x, y - 14, 12);
    }
    if (tw.silT > 0) { c.globalAlpha = 0.65 + 0.35 * Math.sin(G.time * 6); tdEmoji(c, '💤', x + 14, y - 56 + Math.sin(G.time * 3) * 3, 16); c.globalAlpha = 1; }
    if (NET.on && G.netRun) { // флажок цвета той, кто построила
      const fx = x - 18, fy = y - 2, col = mateCol(tw.by || 1), wv = Math.sin(G.time * 4 + x) * 2;
      c.strokeStyle = paperOn ? INK : '#3a2a1a'; c.lineWidth = 1.5; c.beginPath(); c.moveTo(fx, fy + 8); c.lineTo(fx, fy - 22); c.stroke();
      c.fillStyle = col; c.beginPath(); c.moveTo(fx, fy - 22); c.quadraticCurveTo(fx + 8, fy - 20 + wv, fx + 15, fy - 17 + wv); c.lineTo(fx, fy - 12); c.closePath(); c.fill();
      if (paperOn) { c.lineWidth = 1; c.stroke(); }
      if (tw.fr) { c.globalAlpha = 0.8 + 0.2 * Math.sin(G.time * 3); tdEmoji(c, '🤝', x + 17, y - 4, 12); c.globalAlpha = 1; }
    }
    // уровень: точки, у мастера – звезда и число усилений
    c.textAlign = 'center';
    if (L < 4) { for (let i = 0; i < L; i++) { c.fillStyle = '#3a2a10'; c.beginPath(); c.arc(x - (L - 1) * 4 + i * 8, y + 16, 3.6, 0, TAU); c.fill(); c.fillStyle = '#ffd25a'; c.beginPath(); c.arc(x - (L - 1) * 4 + i * 8, y + 16, 2.6, 0, TAU); c.fill(); } }
    else { c.font = 'bold 11px sans-serif'; c.fillStyle = '#000'; c.fillText('★' + (tw.boost ? '+' + tw.boost : ''), x + 1, y + 21); c.fillStyle = '#ffd25a'; c.fillText('★' + (tw.boost ? '+' + tw.boost : ''), x, y + 20); }
  }
  function drawDefUnit(c, u) {
    if (u.dead) return;
    const S = tdUS(u.tw), by = u.mv ? Math.abs(Math.sin(u.t * 14)) * 3 : 0, lunge = u.hit > 0 ? u.face * 5 : 0;
    shadow(c, u.x, u.y + 6, 9, 3.5);
    if (u.temp || u.tw.temp) { c.strokeStyle = '#ff8ad8'; c.lineWidth = 2; c.beginPath(); c.ellipse(u.x, u.y + 6, 11, 4.5, 0, 0, TAU); c.stroke(); } // котоподмога – с розовым кольцом
    else if (S.armor) { c.strokeStyle = '#ffd25a'; c.lineWidth = 2; c.beginPath(); c.ellipse(u.x, u.y + 6, 11, 4.5, 0, 0, TAU); c.stroke(); }
    else if (S.dodge) { c.strokeStyle = '#b07aff'; c.lineWidth = 2; c.beginPath(); c.ellipse(u.x, u.y + 6, 11, 4.5, 0, 0, TAU); c.stroke(); }
    c.save(); c.translate(u.x + lunge, u.y + 5 - by); c.scale(-u.face, 1); // кот на картинке смотрит влево
    if (u.flash > 0) c.globalAlpha = 0.5;
    c.fillStyle = '#fff'; c.font = '19px sans-serif'; c.textAlign = 'center'; c.fillText('🐈', 0, 0);
    c.restore(); c.globalAlpha = 1;
    if (u.hp < u.maxHp) { c.fillStyle = 'rgba(0,0,0,0.6)'; c.fillRect(u.x - 11, u.y - 20, 22, 3.5); c.fillStyle = '#7dff7d'; c.fillRect(u.x - 11, u.y - 20, 22 * clamp(u.hp / u.maxHp, 0, 1), 3.5); }
  }
  // поверх всех: снаряды, молнии и подсказки у входов
  function drawDefOver(c, vis) {
    const A = G.abyss, M = G.td, t = G.time;
    for (const s of M.shots) {
      if (s.k === 'f') { drawFeather(c, s.x, s.y, s.a || 0, s.big ? 1.6 : 1.1); continue; }
      tdEll(c, s.x, s.y, 7, 3, 'rgba(0,0,0,0.3)');
      drawFireball(c, s.x, s.y - s.z, Math.atan2(s.ty - s.sy - Math.cos(Math.min(1, s.t / s.dur) * Math.PI) * Math.PI * (s.big ? 110 : 70), s.tx - s.sx), s.big ? 2 : 1.25);
    }
    c.lineCap = 'round'; c.lineJoin = 'round';
    for (const z of M.zaps) { // молния: ломаная из трёх колен
      const a = clamp(z.life / 0.16, 0, 1), dx = z.x1 - z.x0, dy = z.y1 - z.y0;
      if (!z.j) z.j = [rnd(-9, 9), rnd(-9, 9), rnd(-9, 9), rnd(-9, 9)];
      c.globalAlpha = a; c.beginPath(); c.moveTo(z.x0, z.y0); c.lineTo(z.x0 + dx * 0.33 + z.j[0], z.y0 + dy * 0.33 + z.j[1]); c.lineTo(z.x0 + dx * 0.66 + z.j[2], z.y0 + dy * 0.66 + z.j[3]); c.lineTo(z.x1, z.y1);
      c.strokeStyle = '#fff3a0'; c.lineWidth = 4.5; c.stroke(); c.strokeStyle = '#ffffff'; c.lineWidth = 1.5; c.stroke();
    }
    c.globalAlpha = 1; c.lineCap = 'butt'; c.lineJoin = 'miter';
    for (const e of G.enemies) { // лёд и растерянность
      if (e.dead || !vis(e.x, e.y, 40)) continue;
      if (e.ln !== undefined && tdPortal(e)) { c.strokeStyle = `rgba(224,160,255,${0.45 + 0.25 * Math.sin(t * 8 + e.x)})`; c.lineWidth = 2; c.beginPath(); c.arc(e.x, e.y - (e.fly ? 12 : 4), e.r + 6, 0, TAU); c.stroke(); }
      if (e.stunT > 0) { c.fillStyle = e.iceT > 0 ? 'rgba(170,230,255,0.5)' : 'rgba(255,240,150,0.35)'; c.beginPath(); c.arc(e.x, e.y - 4, e.r + 4, 0, TAU); c.fill(); if (!(e.iceT > 0)) tdEmoji(c, '💫', e.x, e.y - e.r - 8, 12); }
      else if (e.confT > 0) tdEmoji(c, '🌀', e.x, e.y - e.r - 8 + Math.sin(t * 9) * 2, 13);
    }
    // что идёт следующей волной – над каждым входом
    const sum = A.next && A.next.sum, wait = !A.q.length && !A.spawning && !G.activeBoss;
    if (sum && wait) for (const [ln, list] of sum) {
      const L = M.lanes[ln]; if (!L || !vis(L.gate.x, L.gate.y, 140)) continue;
      const g = L.gate, sx = Math.sign(L.pts[2].x - g.x), sy = Math.sign(L.pts[2].y - g.y);
      const bx = g.x + sx * 34, by = g.y + sy * 44 - 34 + Math.sin(t * 3) * 3, tx = list.slice(0, 4).map(([tag, n]) => `${TD_TAG[tag] || '👣'}${n > 1 ? n : ''}`).join(' ');
      c.font = 'bold 14px sans-serif'; c.textAlign = 'center';
      const w = Math.max(44, c.measureText(tx).width + 16);
      c.fillStyle = 'rgba(30,10,50,0.86)'; roundRect(c, bx - w / 2, by - 15, w, 24, 9); c.fill(); c.strokeStyle = list.some(([tg]) => tg === 'boss' || tg === 'champ') ? '#ff5b5b' : '#e0a0ff'; c.lineWidth = 2; c.stroke();
      c.fillStyle = '#fff'; c.fillText(tx, bx, by + 2);
    }
  }
  // под плашкой уровня – две крупные плашки: жизни кристалла и монетки на стройку
  function drawDefHud(c, x, y) {
    const C = G.core, A = G.abyss, hpF = clamp(C.hp / TD_LIVES, 0, 1), h = 26;
    if (A.coins !== A.coinSeen) { if (A.coinSeen !== undefined && A.coins > A.coinSeen) A.coinUpT = G.time; A.coinSeen = A.coins; }
    const up = clamp(1 - (G.time - (A.coinUpT === undefined ? -9 : A.coinUpT)) / 0.35, 0, 1), no = clamp(1 - (G.time - (A.coinNoT === undefined ? -9 : A.coinNoT)) / 0.6, 0, 1);
    // кристалл
    c.fillStyle = C.flash > 0 ? 'rgba(255,90,140,0.85)' : 'rgba(0,0,0,0.55)'; roundRect(c, x, y, 70, h, 10); c.fill();
    c.textAlign = 'left'; c.font = '14px sans-serif'; c.fillStyle = '#fff'; c.fillText('💎', x + 7, y + 18);
    c.font = '900 15px sans-serif'; c.fillStyle = hpF > 0.5 ? '#ffb0e4' : hpF > 0.25 ? '#ffd25a' : '#ff6a6a'; c.fillText(String(C.hp), x + 29, y + 19);
    c.fillStyle = 'rgba(255,255,255,0.18)'; c.fillRect(x + 8, y + h - 5, 54, 2.5); c.fillStyle = hpF > 0.5 ? '#ff8ad8' : hpF > 0.25 ? '#ffd25a' : '#ff4d4d'; c.fillRect(x + 8, y + h - 5, 54 * hpF, 2.5);
    // монетки: вспыхивают, когда прибавились, и краснеют, когда не хватило
    const tx = String(A.coins); c.font = `900 ${15 + up * 3}px sans-serif`;
    const w = Math.max(74, c.measureText(tx).width + 38), cx = x + 76;
    c.fillStyle = no > 0 ? `rgba(200,40,40,${0.55 + no * 0.35})` : `rgba(${Math.round(60 * up)},${Math.round(40 * up)},0,${0.55 + up * 0.25})`; roundRect(c, cx, y, w, h, 10); c.fill();
    c.strokeStyle = no > 0 ? '#ff8a8a' : '#ffd25a'; c.lineWidth = 1.5 + up; roundRect(c, cx, y, w, h, 10); c.stroke();
    c.font = '15px sans-serif'; c.fillStyle = '#fff'; c.fillText('🪙', cx + 7, y + 19);
    c.font = `900 ${15 + up * 3}px sans-serif`; c.fillStyle = no > 0 ? '#ffd0d0' : '#ffd25a'; c.fillText(tx, cx + 29, y + 19 + up);
  }

  // ---------- испытание дня: одна карта и одни правила на день ----------
  const DAILY_LEN = 300;
  function dayKey(d = new Date()) { return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; }
  function dailyInfo() {
    const key = dayKey();
    let h = 2166136261; for (const ch of key) { h ^= ch.charCodeAt(0); h = Math.imul(h, 16777619); } h >>>= 0;
    const open = CH_NUMS.filter(n => chapterOpen(n)), ch = open[h % open.length] || 1;
    const muts = []; let k = h;
    while (muts.length < 2) { k = Math.imul(k ^ (k >>> 13), 1274126177) >>> 0; const id = MUTS[(k >>> 7) % MUTS.length].id; if (!muts.includes(id)) muts.push(id); }
    return { key, seed: 1 + (h % 2000000000), ch, muts };
  }
  function startDaily() {
    const D = dailyInfo();
    G.mutNext = D.muts; G.dailyNext = { key: D.key, left: DAILY_LEN, score: 0, ch: D.ch };
    newChapter(D.ch, D.seed);
    showBanner('📅 Испытание дня', `5 минут · ${D.muts.map(m => MUT_BY[m].ic + ' ' + MUT_BY[m].nm).join(' · ')}`);
  }
  const dailyAdd = v => { if (G.daily && !G.daily.done) G.daily.score += v; };
  function dailyUpdate(dt) {
    const D = G.daily; if (!D || D.done || G.cutscene) return;
    if (state === 'play') { D.left -= dt; if (D.left <= 0) { D.left = 0; dailyFinish(true); } }
  }
  function dailyFinish(timeUp) {
    const D = G.daily; if (!D || D.done) return; D.done = true;
    D.score += P.level * 20;
    const pr = loadProfile(), dd = pr.daily || {};
    const yest = dayKey(new Date(Date.now() - 864e5));
    if (dd.key !== D.key) { dd.streak = dd.key === yest ? (dd.streak || 0) + 1 : 1; dd.best = 0; dd.plays = 0; dd.key = D.key; }
    dd.plays = (dd.plays || 0) + 1; D.better = D.score > (dd.best || 0); if (D.better) dd.best = D.score;
    dd.total = (dd.total || 0) + 1;
    pr.daily = dd; saveProfile(pr);
    D.best = dd.best; D.streak = dd.streak;
    lifeMax('dStreak', dd.streak); life('daily'); lifeMax('dBest', D.score); life('spts', 20);
    recordRunEnd(`испытание дня: ${D.score}`);
    if (timeUp) { Sound.music('win'); G.enemies.length = 0; G.ebullets.length = 0; setTimeout(() => showVictory('daily'), 900); }
  }

  // ---------- достижения 2.0: редкость, слава, звания, награды ----------
  // счётчики «за всё время» копятся в памяти и раз в несколько секунд уходят в профиль
  const LIFE = {}, LIFE_MAX = {}, DAYC = {}, DAYM = {}; // DAY* – то же, но для заданий дня и недели
  function life(k, v = 1) { LIFE[k] = (LIFE[k] || 0) + v; DAYC[k] = (DAYC[k] || 0) + v; }
  function lifeMax(k, v) { LIFE_MAX[k] = Math.max(LIFE_MAX[k] || 0, v); DAYM[k] = Math.max(DAYM[k] || 0, v); }
  let lifeSoonT = 0; // секреты в меню: сохранить чуть погодя, а не на каждый тап
  function lifeSoon() { clearTimeout(lifeSoonT); lifeSoonT = setTimeout(() => { try { lifeFlush(); } catch (e) { /* ignore */ } }, 700); }
  const ACH_CATS = [
    { id: 'all', ic: '🏆', nm: 'Все' },
    { id: 'adv', ic: '🗺️', nm: 'Приключение' },
    { id: 'fight', ic: '⚔️', nm: 'Бой' },
    { id: 'coll', ic: '📦', nm: 'Коллекция' },
    { id: 'modes', ic: '🎮', nm: 'Режимы' },
    { id: 'team', ic: '👥', nm: 'Вместе' },
    { id: 'mast', ic: '🎯', nm: 'Мастерство' },
    { id: 'sec', ic: '🤫', nm: 'Секреты' },
    { id: 'ultra', ic: '🌈', nm: 'Ультра' },
  ];
  const lf = k => p => (p.life || {})[k] || 0;
  const chDone = n => p => (p['ch' + n + 'Done'] ? 1 : 0);
  const chHid = n => () => !chapterOpen(n);
  const nDone = p => CH_NUMS.filter(n => p['ch' + n + 'Done']).length;
  const chCnt = k => p => CH_NUMS.filter(n => (p[k] || {})[n]).length;
  const allCh = () => CH_NUMS.length;
  const fastAny = p => { let b = 1e9; for (const n of CH_NUMS) { const f = (p.fast || {})[n]; if (n >= 2 && f && f.t < b) b = f.t; } return b; };
  // ступенчатая линия: одно достижение на каждую ступень, в списке показывается ближайшая
  const LINE = (line, cat, ic, val, steps) => steps.map(([goal, r, nm, ds], i) => ({ id: line + (i + 1), line, tier: i + 1, tiers: steps.length, cat, ic, nm, ds, r, val, goal }));
  const ACHS = [
    // 🗺️ приключение
    { id: 'ch1', cat: 'adv', r: 'c', ic: '🌲', nm: 'Первые шаги', ds: 'Пройди главу 1', val: chDone(1), goal: 1 },
    { id: 'ch2', cat: 'adv', r: 'c', ic: '🪩', nm: 'Диско окончено', ds: 'Пройди главу 2', val: chDone(2), goal: 1 },
    { id: 'ch3', cat: 'adv', r: 'r', ic: '🪞', nm: 'Сквозь зеркала', ds: 'Пройди главу 3', val: chDone(3), goal: 1 },
    { id: 'ch4', cat: 'adv', r: 'r', ic: '🌙', nm: 'Ночная стража', ds: 'Пройди главу 4', val: chDone(4), goal: 1, hid: chHid(4) },
    { id: 'ch5', cat: 'adv', r: 'r', ic: '🔎', nm: 'Дело раскрыто', ds: 'Пройди главу 5', val: chDone(5), goal: 1, hid: chHid(5) },
    { id: 'ch6', cat: 'adv', r: 'e', ic: '❄️', nm: 'Оттепель', ds: 'Пройди главу 6', val: chDone(6), goal: 1, hid: chHid(6) },
    { id: 'ch7', cat: 'adv', r: 'e', ic: '🦐', nm: 'Со дна', ds: 'Пройди главу 7', val: chDone(7), goal: 1, hid: chHid(7) },
    { id: 'season', cat: 'adv', r: 'l', ic: '👑', nm: 'Сезон пройден', ds: 'Пройди все главы', val: nDone, goal: allCh },
    { id: 'truewin', cat: 'adv', r: 'e', ic: '💫', nm: 'Настоящий финал', ds: 'Найди настоящий финал главы 3', val: p => (p.trueWin ? 1 : 0), goal: 1, secret: true },
    { id: 'ends4', cat: 'adv', r: 'e', ic: '🎭', nm: 'Обе стороны', ds: 'Увидь обе концовки главы 4', val: p => Object.keys(p.ch4Seen || {}).length, goal: 2, hid: p => !p.ch4Done },
    { id: 'pearls', cat: 'adv', r: 'e', ic: '💗', nm: 'Все слова на месте', ds: 'Собери все 12 жемчужин за одно прохождение', val: lf('pearls12'), goal: 1, hid: chHid(7) },
    // ⚔️ бой
    ...LINE('kills', 'fight', '⚔️', lf('kills'), [[500, 'c', 'Охотница', 'Победи 500 врагов'], [5000, 'r', 'Гроза монстров', 'Победи 5 000 врагов'], [25000, 'e', 'Перьевой ураган', 'Победи 25 000 врагов'], [100000, 'l', 'Конец света для мобов', 'Победи 100 000 врагов']]),
    ...LINE('elites', 'fight', '💥', lf('elites'), [[50, 'c', 'Элита? Не смешите', 'Победи 50 элитных врагов'], [300, 'r', 'Ломательница корон', 'Победи 300 элитных врагов'], [1000, 'e', 'Элиты больше нет', 'Победи 1 000 элитных врагов']]),
    ...LINE('bosses', 'fight', '🐉', lf('bosses'), [[10, 'c', 'Стражеборица', 'Победи 10 боссов'], [50, 'r', 'Охота на стражей', 'Победи 50 боссов'], [200, 'e', 'Кошмар стражей', 'Победи 200 боссов']]),
    ...LINE('champs', 'fight', '🏵️', lf('champs'), [[5, 'c', 'Чемпионка', 'Победи 5 чемпионов с короной'], [25, 'r', 'Корона за короной', 'Победи 25 чемпионов'], [75, 'e', 'Королева чемпионов', 'Победи 75 чемпионов']]),
    ...LINE('combo', 'fight', '🔥', lf('combo'), [[100, 'c', 'Комбо!', 'Набери комбо 100'], [250, 'r', 'Комбо-мастер', 'Набери комбо 250'], [500, 'e', 'Не остановить', 'Набери комбо 500'], [1000, 'l', 'Тысяча без передышки', 'Набери комбо 1 000']]),
    ...LINE('supers', 'fight', '⚡', lf('supers'), [[50, 'c', 'Супер-девочка', 'Используй супер-удар 50 раз'], [500, 'r', 'Суперсила', 'Используй супер-удар 500 раз']]),
    ...LINE('evos', 'fight', '🌈', p => Object.keys(p.evoSeen || {}).length, [[1, 'c', 'Эволюция!', 'Собери первую эволюцию улучшений'], [4, 'r', 'Алхимичка', 'Открой 4 разные эволюции'], [8, 'e', 'Все превращения', 'Открой все 8 эволюций']]),
    ...LINE('nohit', 'fight', '🛡️', lf('noHit'), [[1, 'r', 'Ни царапины', 'Победи босса, не получив урона'], [10, 'e', 'Неуловимая', 'Победи 10 боссов, не получив урона']]),
    // 📦 коллекция
    ...LINE('chests', 'coll', '📦', lf('chests'), [[50, 'c', 'Кладоискательница', 'Открой 50 сундуков'], [300, 'r', 'Сундучный магнат', 'Открой 300 сундуков'], [1000, 'e', 'Ни одного закрытого', 'Открой 1 000 сундуков']]),
    ...LINE('secrets', 'coll', '🗝️', lf('secrets'), [[1, 'c', 'Тайное место', 'Найди тайник за треснувшей стеной'], [10, 'r', 'Простукивательница', 'Найди 10 тайников'], [30, 'e', 'Ни камня без проверки', 'Найди 30 тайников']]),
    ...LINE('furn', 'coll', '🛋️', p => [...FURNITURE, ...WALLPAPERS, ...FLOORS].filter(f => !f.def && (p.furn || {})[f.id]).length, [[5, 'c', 'Новоселье', 'Найди 5 вещей для домика'], [20, 'r', 'Уютный уголок', 'Найди 20 вещей для домика'], [40, 'e', 'Дизайнерша', 'Найди 40 вещей для домика']]),
    ...LINE('pets', 'coll', '🐾', p => PETS.filter(pt => petOwned(pt, p)).length, [[1, 'c', 'Хвостик', 'Заведи первого питомца'], [5, 'r', 'Зоопарк', 'Собери 5 питомцев'], [12, 'l', 'Ноев ковчег', 'Собери 12 питомцев']]),
    { id: 'relic3', cat: 'coll', r: 'e', ic: '🏺', nm: 'Реликвия мастера', ds: 'Прокачай любую реликвию до 3-го уровня', val: p => (Object.values(p.relicLv || {}).some(v => v >= 3) ? 1 : 0), goal: 1 },
    ...LINE('mimics', 'coll', '😱', lf('mimics'), [[10, 'c', 'Мимикам тут не место', 'Победи 10 мимиков'], [50, 'r', 'Гроза мимиков', 'Победи 50 мимиков']]),
    ...LINE('trials', 'coll', '⛩️', lf('trials'), [[10, 'c', 'Испытанная', 'Пройди 10 испытаний у алтарей'], [50, 'r', 'Хозяйка алтарей', 'Пройди 50 испытаний']]),
    { id: 'relics', cat: 'coll', r: 'e', ic: '🗝️', nm: 'Музей реликвий', ds: 'Найди все реликвии', val: p => Object.keys(p.relicSeen || {}).filter(id => RELICS[id]).length, goal: () => Object.keys(RELICS).length },
    ...LINE('book', 'coll', '📖', () => bookCount().pct, [[50, 'r', 'Любопытная', 'Открой половину Кринжопедии'], [100, 'e', 'Кринжевед', 'Открой всю Кринжопедию']]),
    ...LINE('stars', 'coll', '⭐', p => p.stars || 0, [[50, 'r', 'Звёздный путь', 'Собери 50 звёзд'], [120, 'e', 'Созвездие', 'Собери 120 звёзд'], [200, 'l', 'Млечный путь', 'Собери 200 звёзд']]),
    { id: 'outfits', cat: 'coll', r: 'e', ic: '🎀', nm: 'Модница', ds: 'Собери все наряды Тессы', val: p => WARDROBE.filter(w => w.id !== 'none' && ((p.wardrobe || {}).own || {})[w.id]).length, goal: () => WARDROBE.length - 1, hid: p => !p.ch4Done },
    { id: 'talapex', cat: 'coll', r: 'e', ic: '🌠', nm: 'Вершина', ds: 'Прокачай до конца вершину любой ветви талантов', val: p => (TALENTS.some(d => d.apex && ((p.talents || {})[d.id] || 0) >= d.max) ? 1 : 0), goal: 1 },
    { id: 'talall', cat: 'coll', r: 'l', ic: '✨', nm: 'Звездочёт', ds: 'Прокачай все таланты до конца', val: p => TALENTS.filter(d => ((p.talents || {})[d.id] || 0) >= d.max).length, goal: () => TALENTS.length },
    // 🎮 режимы
    { id: 'rush1', cat: 'modes', r: 'r', ic: '⚔️', nm: 'Раш пройден', ds: 'Пройди босс-раш до конца', val: lf('rush'), goal: 1 },
    { id: 'rushfast', cat: 'modes', r: 'e', ic: '⏩', nm: 'Раш на скорости', ds: 'Пройди босс-раш, тратя в среднем не больше 35 с на босса', val: p => { const b = p.rushBest; return b && b.n >= b.total && b.time <= b.total * 35 ? 1 : 0; }, goal: 1 },
    ...LINE('abyss', 'modes', '🕳️', lf('abyss'), [[10, 'c', 'В бездну', 'Дойди до 10-й волны Бездны'], [25, 'r', 'На дне', 'Дойди до 25-й волны Бездны'], [40, 'e', 'Глубже дна', 'Дойди до 40-й волны Бездны'], [60, 'l', 'Покорительница Бездны', 'Дойди до 60-й волны Бездны']]),
    ...LINE('def', 'modes', '🛡️', lf('defWave'), [[5, 'c', 'Защитница', 'Отбей 5 волн в обороне'], [15, 'r', 'Крепость', 'Отбей 15 волн в обороне'], [30, 'e', 'Нерушимая', 'Отбей 30 волн в обороне'], [50, 'l', 'Легенда обороны', 'Отбей 50 волн в обороне']]),
    { id: 'defspell', cat: 'modes', r: 'r', ic: '🌠', nm: 'Повелительница неба', ds: 'Используй заклинания обороны 50 раз', val: lf('defSpells'), goal: 50 },
    { id: 'defmaps', cat: 'modes', r: 'r', ic: '🗺️', nm: 'Три рубежа', ds: 'Отбей по 10 волн на каждой карте обороны', val: lf('defMaps'), goal: 1 },
    { id: 'daily1', cat: 'modes', r: 'c', ic: '📅', nm: 'Каждый день – испытание', ds: 'Сыграй испытание дня', val: lf('daily'), goal: 1 },
    ...LINE('dstreak', 'modes', '🗓️', lf('dStreak'), [[7, 'r', 'Привычка', 'Испытание дня 7 дней подряд'], [30, 'l', 'Железная воля', 'Испытание дня 30 дней подряд']]),
    { id: 'dscore', cat: 'modes', r: 'e', ic: '🎰', nm: 'Рекорд дня', ds: 'Набери 4 000 очков в испытании дня', val: lf('dBest'), goal: 4000 },
    ...LINE('mut', 'modes', '🧪', lf('mutMax'), [[3, 'r', 'Смелая', 'Пройди главу с тремя мутаторами'], [MUTS.length, 'l', 'Безумие', 'Пройди главу со всеми мутаторами сразу']]),
    { id: 'season1', cat: 'modes', r: 'e', ic: '🛤️', nm: 'Дорога сезона', ds: 'Дойди до 20-го уровня сезона', val: lf('seasonLvl'), goal: SEASON_MAX },
    ...LINE('quests', 'modes', '📜', lf('questsDone'), [[10, 'c', 'Исполнительная', 'Выполни 10 заданий дня или недели'], [100, 'r', 'Трудяжка', 'Выполни 100 заданий'], [500, 'l', 'Мастер заданий', 'Выполни 500 заданий']]),
    ...LINE('gifts', 'modes', '🎁', p => (p.gift || {}).n || 0, [[7, 'c', 'Неделя с Крилессой', 'Забери подарки дня 7 раз'], [30, 'r', 'Месяц с Крилессой', 'Забери подарки дня 30 раз'], [100, 'e', 'Сто дней вместе', 'Забери подарки дня 100 раз']]),
    { id: 'mutstars', cat: 'modes', r: 'e', ic: '🧬', nm: 'Мутантка', ds: 'Собери 30 звёзд за мутаторы', val: p => Object.keys(p.starsGot || {}).filter(k => k.startsWith('m:')).length, goal: 30 },
    // 👥 вместе
    { id: 'coop1', cat: 'team', r: 'c', ic: '👥', nm: 'Вместе веселее', ds: 'Пройди главу вместе с подругами', val: lf('coop'), goal: 1 },
    { id: 'coop4', cat: 'team', r: 'r', ic: '🏠', nm: 'Полный дом', ds: 'Пройди главу вчетвером', val: lf('coop4'), goal: 1 },
    { id: 'coopall', cat: 'team', r: 'e', ic: '🤝', nm: 'Всё вместе', ds: 'Пройди вместе каждую главу', val: chCnt('coopCh'), goal: allCh },
    ...LINE('revive', 'team', '💫', lf('revives'), [[10, 'c', 'Своих не бросаем', 'Подними подруг 10 раз'], [100, 'r', 'Ангел-хранитель', 'Подними подруг 100 раз']]),
    { id: 'defcoop', cat: 'team', r: 'e', ic: '💎', nm: 'Стена дружбы', ds: 'Отбейте 20 волн обороны вчетвером', val: lf('defCoop4'), goal: 1 },
    { id: 'rushcoop', cat: 'team', r: 'r', ic: '⚔️', nm: 'Раш на всех', ds: 'Пройди босс-раш вместе с подругами', val: p => { const b = p.rushBestCoop; return b && b.n >= b.total ? 1 : 0; }, goal: 1 },
    // 🎯 мастерство
    { id: 'hc1', cat: 'mast', r: 'r', ic: '😈', nm: 'Кринж-хардкор', ds: 'Пройди главу на «Кринж-хардкоре», не меняя сложность', val: chCnt('hcCh'), goal: 1 },
    { id: 'hcall', cat: 'mast', r: 'l', ic: '🩸', nm: 'Хардкорщица', ds: 'Пройди все главы на «Кринж-хардкоре»', val: chCnt('hcCh'), goal: allCh },
    { id: 'clean1', cat: 'mast', r: 'r', ic: '🕊️', nm: 'Ни разу не упала', ds: 'Пройди главу, ни разу не проиграв', val: chCnt('cleanCh'), goal: 1 },
    { id: 'hcclean', cat: 'mast', r: 'e', ic: '🧊', nm: 'Стальные нервы', ds: 'Пройди главу на хардкоре, ни разу не проиграв', val: chCnt('hcClean'), goal: 1 },
    { id: 'noheal', cat: 'mast', r: 'e', ic: '💔', nm: 'Без аптечки', ds: 'Пройди главу, не подобрав ни одного сердечка', val: lf('noHeal'), goal: 1 },
    { id: 'speed1', cat: 'mast', r: 'r', ic: '⏱️', nm: 'Быстрые лапки', ds: 'Пройди любую главу, кроме первой, быстрее 20 минут', val: p => (fastAny(p) <= 1200 ? 1 : 0), goal: 1 },
    { id: 'speed2', cat: 'mast', r: 'l', ic: '⚡', nm: 'Молния', ds: 'Пройди любую главу, кроме первой, быстрее 12 минут', val: p => (fastAny(p) <= 720 ? 1 : 0), goal: 1 },
    // 🤫 секреты: условие видно только после открытия
    { id: 's_toss', cat: 'sec', r: 'c', ic: '💞', nm: 'Попрыгушки', ds: 'Подбрось героинь на стартовом экране 50 раз', val: lf('toss'), goal: 50, secret: true },
    { id: 's_poke', cat: 'sec', r: 'c', ic: '🤫', nm: 'Не трогай её!', ds: 'Потыкай портрет в меню, пока кто-то не обидится', val: lf('poke'), goal: 1, secret: true },
    { id: 's_oops', cat: 'sec', r: 'c', ic: '🙃', nm: 'Падать – это нормально', ds: 'Проиграй 25 раз', val: lf('deaths'), goal: 25, secret: true },
    { id: 's_escape', cat: 'sec', r: 'c', ic: '🚪', nm: 'Выхода нет', ds: 'Попробуй сбежать с представления', val: lf('escape'), goal: 1, secret: true },
    { id: 's_deco', cat: 'sec', r: 'r', ic: '🎯', nm: 'Сбивашка', ds: 'Сбей 100 украшений на карте приключений', val: lf('deco'), goal: 100, secret: true },
    { id: 's_night', cat: 'sec', r: 'r', ic: '🦉', nm: 'Ночная смена', ds: 'Пройди главу между полуночью и пятью утра', val: lf('night'), goal: 1, secret: true },
    { id: 's_krill', cat: 'sec', r: 'r', ic: '🫧', nm: 'Не буди криль', ds: 'Потревожь воду 100 раз в загадке глубин', val: lf('krillTap'), goal: 100, secret: true },
    { id: 's_sniper', cat: 'sec', r: 'e', ic: '🎯', nm: 'Снайперша', ds: 'Сбей 15 украшений подряд, не дав серии остыть', val: lf('decoCombo'), goal: 15, secret: true },
    { id: 's_clutch', cat: 'sec', r: 'e', ic: '❤️‍🩹', nm: 'На волоске', ds: 'Победи босса, когда у тебя меньше 5% здоровья', val: lf('clutch'), goal: 1, secret: true },
    // 🌈 ультра – для самых упорных
    { id: 'u_abyss', cat: 'ultra', r: 'u', ic: '👁️', nm: 'Бездна смотрит в тебя', ds: 'Дойди до 100-й волны Бездны', val: lf('abyss'), goal: 100 },
    { id: 'u_madness', cat: 'ultra', r: 'u', ic: '☠️', nm: 'Абсолютное безумие', ds: 'Пройди главу со всеми мутаторами на «Кринж-хардкоре», не меняя сложность', val: lf('mutHard'), goal: 1 },
    { id: 'u_untouch', cat: 'ultra', r: 'u', ic: '👻', nm: 'Неприкасаемая', ds: 'На хардкоре победи финального босса главы 5 или дальше, не получив ни капли урона', val: lf('untouch'), goal: 1 },
    { id: 'u_perfect', cat: 'ultra', r: 'u', ic: '💎', nm: 'Безупречный сезон', ds: 'Пройди каждую главу на хардкоре, ни разу не проиграв', val: chCnt('hcClean'), goal: allCh },
    { id: 'u_legend', cat: 'ultra', r: 'u', ic: '🌈', nm: 'Легенда Крилессы', ds: 'Получи все остальные достижения', val: p => ACHS.filter(a => a.id !== 'u_legend' && (p.ach || {})[a.id]).length, goal: () => ACHS.length - 1 },
  ];
  const ACH_BY = Object.fromEntries(ACHS.map(a => [a.id, a]));
  const achGoal = a => (typeof a.goal === 'function' ? a.goal() : a.goal);
  const achVal = (a, p) => { try { return a.val(p) || 0; } catch (e) { return 0; } };
  // награды-косметика по достижениям и званиям
  const LOOK_REW = {};
  for (const k in LOOK_SETS) for (const it of LOOK_SETS[k]) if (it.src) (LOOK_REW[it.src] = LOOK_REW[it.src] || []).push({ k, it });
  const LOOK_KIND = { em: 'эмблема', fr: 'рамка', ti: 'титул', au: 'аура' };
  const lookName = (k, it) => (k === 'em' ? it.ic : k === 'au' ? it.ic + ' ' + it.nm : `«${it.nm}»`);
  const rewText = src => (LOOK_REW[src] || []).map(({ k, it }) => `${LOOK_KIND[k]} ${lookName(k, it)}`).join(', ');
  function fameOf(pr) { let f = 0; const ach = pr.ach || {}; for (const a of ACHS) if (ach[a.id]) f += RARITY[a.r].fame; return f; }
  function gloryOf(pr) {
    const fame = fameOf(pr), rk = rankOf(fame), next = RANKS[rk + 1];
    return { fame, rk, rank: RANKS[rk], next, n: ACHS.filter(a => (pr.ach || {})[a.id]).length };
  }
  function myLook(pr) {
    const lk = Object.assign({}, LOOK_DEF, pr.look || {}), g = gloryOf(pr);
    for (const k in LOOK_DEF) if (!LOOK_SETS[k].some(x => x.id === lk[k]) || !lookOwned(lookItem(k, lk[k]), pr.ach, g.rk)) lk[k] = LOOK_DEF[k];
    return lk;
  }
  const titleText = (ti, rk) => (ti && ti !== 'rank' ? lookItem('ti', ti).nm : RANKS[rk || 0].nm);

  let lifeT = 0;
  function lifeFlush() {
    if (G.bestCombo) lifeMax('combo', G.bestCombo);
    const keys = Object.keys(LIFE), mk = Object.keys(LIFE_MAX), bk = Object.keys(BOOK.e).length + Object.keys(BOOK.b).length;
    const pr = loadProfile(); pr.life = pr.life || {}; pr.book = pr.book || { e: {}, b: {} };
    if (!keys.length && !mk.length && !bk) { const s1 = seasonFlush(pr), a1 = achCheck(pr); if (s1 || a1) saveProfile(pr); return; } // нового нет, но достижение могло уже выполниться (например, глава пройдена)
    for (const k of keys) { pr.life[k] = (pr.life[k] || 0) + LIFE[k]; delete LIFE[k]; }
    for (const k of mk) { pr.life[k] = Math.max(pr.life[k] || 0, LIFE_MAX[k]); delete LIFE_MAX[k]; }
    for (const g of ['e', 'b']) for (const t in BOOK[g]) { pr.book[g][t] = (pr.book[g][t] || 0) + BOOK[g][t]; } // 0 – видела, >0 – победила столько раз
    BOOK.e = {}; BOOK.b = {};
    bookCache = pr.book;
    seasonFlush(pr);
    achCheck(pr);
    saveProfile(pr);
  }
  const starCount = pr => Object.keys(pr.starsGot || {}).length;
  // проверить все достижения; silent – без всплывашек (пересчёт при обновлении)
  function achCheck(pr, silent) {
    pr.ach = pr.ach || {}; pr.starsGot = pr.starsGot || {};
    const rk0 = gloryOf(pr).rk, got = [];
    for (let pass = 0; pass < 4; pass++) { // звёзды и «все остальные» зависят от других достижений
      let any = false;
      for (const a of ACHS) {
        if (pr.ach[a.id] || achVal(a, pr) < achGoal(a)) continue;
        pr.ach[a.id] = Date.now();
        for (let k = 0; k < RARITY[a.r].st; k++) pr.starsGot[`g:${a.id}:${k}`] = 1;
        pr.stars = starCount(pr); got.push(a); any = true;
      }
      if (!any) break;
    }
    if (!got.length) return false;
    const rk1 = gloryOf(pr).rk;
    if (!silent) {
      got.sort((a, b) => RAR_ORDER.indexOf(a.r) - RAR_ORDER.indexOf(b.r));
      for (const a of got) achPop({ a });
      for (let k = rk0 + 1; k <= rk1; k++) achPop({ rank: k });
    }
    return true;
  }
  // всплывашка «достижение получено» – сверху экрана, по очереди
  const popQ = []; let popBusy = false;
  function achPop(item) { popQ.push(item); if (!popBusy) popNext(); }
  function popNext() {
    const it = popQ.shift(), box = $('achPop');
    if (!it) { popBusy = false; box.className = 'hidden'; return; }
    popBusy = true;
    let ic, rar, col, nm, rw, cls = '';
    if (it.custom) {
      const C = it.custom; ic = C.ic; rar = C.rar; col = C.col; nm = C.nm; rw = C.rw; cls = C.big ? 'rank' : '';
      if (C.big) { Sound.sfx.win(); buzz(120); } else { Sound.sfx.superReady(); buzz(50); }
    } else if (it.rank !== undefined) {
      const R = RANKS[it.rank]; ic = R.ic; rar = 'Новое звание'; col = '#ffd25a'; nm = R.nm; cls = 'rank';
      rw = rewText('k:' + it.rank); rw = rw ? '🎁 ' + rw : `слава ${R.at}+`;
      Sound.sfx.win(); buzz(120);
    } else {
      const a = it.a, R = RARITY[a.r]; ic = a.ic; rar = R.nm; col = R.col; nm = a.nm; cls = 'r-' + a.r;
      const cos = rewText('a:' + a.id);
      rw = `+${R.st}⭐ · +${R.fame} славы` + (cos ? ` · 🎁 ${cos}` : '');
      if (a.r === 'u' || a.r === 'l') { Sound.sfx.win(); buzz(140); } else { Sound.sfx.superReady(); buzz(60); }
    }
    $('apIc').textContent = ic; $('apRar').textContent = rar; $('apNm').textContent = nm; $('apRw').textContent = rw;
    box.style.setProperty('--rc', col);
    box.className = 'show ' + cls; void box.offsetWidth;
    const dur = it.a && (it.a.r === 'u' || it.a.r === 'l') || it.rank !== undefined || (it.custom && it.custom.big) ? 4200 : 3000;
    setTimeout(() => { box.className = 'out ' + cls; setTimeout(popNext, 350); }, dur);
  }
  // переход на 0.31: старые достижения и их звёзды пересчитываются по новым правилам, таланты сбрасываются
  function gloryMigrate(pr) {
    if (pr.glory1) return;
    pr.starsGot = pr.starsGot || {};
    for (const k of Object.keys(pr.starsGot)) if (k.startsWith('a:')) delete pr.starsGot[k];
    const old = pr.ach || {}; pr.ach = {};
    if (pr.ch4Choice) pr.ch4Seen = Object.assign({ [pr.ch4Choice]: 1 }, pr.ch4Seen || {});
    for (const id of (pr.relics || [])) (pr.relicSeen = pr.relicSeen || {})[id] = 1;
    pr.stars = starCount(pr);
    if (Object.keys(pr.talents || {}).length) { pr.talents = {}; pr.talReset031 = true; }
    achCheck(pr, true);
    for (const id in pr.ach) if (old[id]) pr.ach[id] = old[id]; // дата открытия – прежняя
    pr.glory1 = true;
  }
  // итоги пройденной главы – для мастерства, рекордов и секретов
  function gloryWin() {
    const s = G.st; if (!s || typeof CHN !== 'number' || G.daily) return;
    const pr = loadProfile(), diffs = String(s.diff).split('→'), pure = diffs.length === 1 ? diffs[0] : null;
    const t = Math.round(s.time), clean = !s.deaths && !s.livesLost, coop = NET.on && G.netRun;
    pr.fast = pr.fast || {};
    const f = pr.fast[CHN];
    if (t > 30 && (!f || t < f.t)) pr.fast[CHN] = { t, d: pure || diffs[diffs.length - 1], h: P.hero, co: coop ? NET.roster.length : 0 };
    const mark = k => { pr[k] = pr[k] || {}; pr[k][CHN] = 1; };
    if (pure === 'hard') mark('hcCh');
    if (clean) mark('cleanCh');
    if (clean && pure === 'hard') mark('hcClean');
    if (coop) { mark('coopCh'); if (NET.roster.length >= 4) life('coop4'); }
    if (!s.hearts) lifeMax('noHeal', 1);
    const h = new Date().getHours(); if (h < 5) lifeMax('night', 1);
    if (G.mut && mutIds().length >= MUTS.length && pure === 'hard') lifeMax('mutHard', 1);
    saveProfile(pr);
  }

  // ---------- экран достижений ----------
  let achCat = 'all';
  const ROM = ['', 'I', 'II', 'III', 'IV', 'V'];
  function renderAch() {
    const pr = loadProfile(); pr.ach = pr.ach || {};
    const g = gloryOf(pr);
    $('achHead').innerHTML = `Получено <b>${g.n}</b> из ${ACHS.length} · ✨ слава <b>${fmtN(g.fame)}</b> · ${g.rank.ic} ${g.rank.nm}`;
    const nx = g.next, pct = nx ? clamp((g.fame - g.rank.at) / (nx.at - g.rank.at), 0, 1) : 1;
    $('achRank').innerHTML = `<em class="bar"><u style="width:${Math.round(pct * 100)}%"></u></em><small>${nx ? `до звания ${nx.ic} ${nx.nm}: ещё ${fmtN(nx.at - g.fame)} славы` : 'Высшее звание! 🪐'}</small>`;
    const cats = $('achCats'); cats.innerHTML = '';
    for (const C of ACH_CATS) {
      const list = ACHS.filter(a => C.id === 'all' || a.cat === C.id), n = list.filter(a => pr.ach[a.id]).length;
      const b = document.createElement('button'); b.className = 'achCat' + (C.id === achCat ? ' on' : '') + (C.id === 'ultra' ? ' ultra' : '');
      b.innerHTML = `${C.ic}<small>${n}/${list.length}</small>`; b.title = C.nm;
      b.addEventListener('click', () => { achCat = C.id; Sound.sfx.click(); renderAch(); });
      cats.appendChild(b);
    }
    $('achCatName').textContent = ACH_CATS.find(c => c.id === achCat).nm;
    const box = $('achList'); box.innerHTML = '';
    // линии – одной строкой: ближайшая неполученная ступень
    const rows = [], seen = new Set();
    for (const a of ACHS) {
      if (achCat !== 'all' && a.cat !== achCat) continue;
      if (!a.line) { rows.push(a); continue; }
      if (seen.has(a.line)) continue; seen.add(a.line);
      const steps = ACHS.filter(x => x.line === a.line);
      rows.push(steps.find(x => !pr.ach[x.id]) || steps[steps.length - 1]);
    }
    const isDone = a => !!pr.ach[a.id];
    rows.sort((a, b) => (isDone(a) ? 1 : 0) - (isDone(b) ? 1 : 0) || (achCat === 'all' ? 0 : RAR_ORDER.indexOf(a.r) - RAR_ORDER.indexOf(b.r)));
    for (const a of rows) box.appendChild(achRow(a, pr));
  }
  function achRow(a, pr) {
    const done = !!pr.ach[a.id], R = RARITY[a.r], hid = a.hid && !done && a.hid(pr), sec = a.secret && !done;
    const el = document.createElement('div'); el.className = `achRow r-${a.r}` + (done ? ' done' : '') + (hid || sec ? ' sec' : '');
    el.style.setProperty('--rc', R.col);
    const goal = achGoal(a), v = achVal(a, pr);
    let nm = a.nm, ds = a.ds, ic = done ? a.ic : '🔒';
    if (hid) { nm = '???'; ds = 'Откроется позже'; ic = '❔'; }
    else if (sec) { nm = 'Секретное достижение'; ds = 'Условие – секрет. Ищи пасхалки! 🤫'; ic = '🤫'; }
    let pips = '';
    if (a.line) { pips = '<span class="pips">'; for (let k = 1; k <= a.tiers; k++) { const st = ACH_BY[a.line + k]; pips += `<u class="${pr.ach[st.id] ? 'on' : ''}" style="--pc:${RARITY[st.r].col}">${ROM[k]}</u>`; } pips += '</span>'; }
    const cos = hid || sec ? '' : rewText('a:' + a.id);
    const prog = !done && !hid && !sec && goal > 1 ? `<em class="bar"><u style="width:${Math.round(clamp(v / goal, 0, 1) * 100)}%"></u></em><small>${fmtN(Math.min(v, goal))} / ${fmtN(goal)}</small>` : '';
    const when = done && pr.ach[a.id] > 1 ? `<small>${new Date(pr.ach[a.id]).toLocaleDateString('ru-RU')}</small>` : '';
    el.innerHTML = `<i>${ic}</i><div><b>${escHtml(nm)}${pips}</b><span>${escHtml(ds)}</span>${prog}${when}` +
      `<span class="rw"><em style="color:${R.col}">${R.nm}</em> · +${R.st}⭐ · +${R.fame}✨${cos ? ' · 🎁 ' + escHtml(cos) : ''}</span></div><s>${done ? '✓' : ''}</s>`;
    return el;
  }

  // ---------- таланты-созвездия ----------
  let talBr = 'fury';
  function openTalents() { renderTalents(); setState('talents'); }
  function renderTalents() {
    const pr = loadProfile(), tl = pr.talents || {}, stars = pr.stars || 0, free = stars - talentSpent(tl);
    $('talStars').textContent = `⭐ Свободно звёзд: ${free} из ${stars}`;
    const tabs = $('talTabs'); tabs.innerHTML = '';
    for (const B of TAL_BRANCHES) {
      const sp = branchSpent(tl, B.id), mx = TALENTS.reduce((s, d) => s + (d.br === B.id ? d.max * d.cost : 0), 0);
      const b = document.createElement('button'); b.className = 'talTab' + (B.id === talBr ? ' on' : ''); b.style.setProperty('--bc', B.col);
      b.innerHTML = `${B.ic} ${B.nm}<small>${sp} / ${mx}</small>`;
      b.addEventListener('click', () => { talBr = B.id; Sound.sfx.click(); renderTalents(); });
      tabs.appendChild(b);
    }
    const B = TAL_BRANCHES.find(x => x.id === talBr), sp = branchSpent(tl, B.id);
    $('talBrHint').textContent = B.ds;
    const box = $('talList'); box.innerHTML = ''; box.style.setProperty('--bc', B.col);
    for (let tier = 0; tier < TAL_TIERS.length; tier++) {
      const need = TAL_TIERS[tier], open = sp >= need;
      const h = document.createElement('div'); h.className = 'talTier' + (open ? '' : ' locked') + (tier === 3 ? ' apex' : '');
      h.textContent = (tier === 3 ? '✦ Вершина' : `Ступень ${ROM[tier + 1]}`) + (open ? '' : ` · 🔒 вложи в ветвь ${need}⭐ (сейчас ${sp})`);
      box.appendChild(h);
      for (const d of TALENTS) {
        if (d.br !== B.id || d.tier !== tier) continue;
        const r = Math.min(tl[d.id] || 0, d.max), el = document.createElement('div');
        el.className = 'tal' + (r >= d.max ? ' max' : '') + (open ? '' : ' locked') + (d.apex ? ' apex' : '');
        el.dataset.id = d.id;
        el.innerHTML = `<div class="ic">${d.ic}</div><div class="tx"><b>${d.nm}</b><i>${d.ds}</i><div class="pips">${'★'.repeat(r)}${'☆'.repeat(d.max - r)}</div></div>`;
        const bt = document.createElement('button');
        bt.textContent = r >= d.max ? 'макс.' : !open ? '🔒' : `+ ${d.cost}⭐`;
        bt.disabled = !talentCan(tl, d, stars);
        bt.addEventListener('click', () => {
          const p2 = loadProfile(); p2.talents = p2.talents || {};
          if (!talentCan(p2.talents, d, p2.stars || 0)) return;
          p2.talents[d.id] = (p2.talents[d.id] || 0) + 1; achCheck(p2); saveProfile(p2);
          Sound.sfx.superReady(); buzz(25); renderTalents();
        });
        el.appendChild(bt); box.appendChild(el);
      }
    }
  }

  // ---------- образ: эмблема, рамка, титул, аура ----------
  let lookTab = 'em', lookRaf = 0;
  function openLook() { lookTab = 'em'; const pr = loadProfile(); $('lkName').value = cardName(pr); renderLook(); setState('look'); lookLoop(); }
  function cardName(pr) { return String((pr.mp && pr.mp.name) || HEROES.krilessa.name).slice(0, 14); }
  function renderLook() {
    const pr = loadProfile(), g = gloryOf(pr), lk = myLook(pr);
    $('lkAv').innerHTML = avatarHtml(lk, 64);
    $('lkWho').innerHTML = `<b>${escHtml(cardName(pr))}</b><span>${escHtml(titleText(lk.ti, g.rk))}</span><small>${g.rank.ic} ${g.rank.nm} · ✨ ${fmtN(g.fame)}</small>`;
    for (const k of ['em', 'fr', 'ti', 'au']) $('lkT_' + k).classList.toggle('on', k === lookTab);
    const set = LOOK_SETS[lookTab], box = $('lkGrid'); box.innerHTML = ''; box.className = 'lk-' + lookTab;
    let own = 0;
    for (const it of set) {
      const has = lookOwned(it, pr.ach, g.rk);
      if (it.season !== undefined && !has && it.season !== seasonMonth()) continue; // чужие сезоны не мелькают
      if (has) own++;
      const b = document.createElement('button'); b.className = 'lkItem' + (has ? '' : ' no') + (lk[lookTab] === it.id ? ' on' : '');
      if (lookTab === 'em') b.innerHTML = avatarHtml({ em: it.id, fr: lk.fr }, 44);
      else if (lookTab === 'fr') b.innerHTML = avatarHtml({ em: lk.em, fr: it.id }, 44) + `<small>${it.nm}</small>`;
      else if (lookTab === 'ti') b.innerHTML = `<b>${escHtml(it.id === 'rank' ? RANKS[g.rk].nm : it.nm)}</b><small>${it.id === 'rank' ? 'твоё звание' : ''}</small>`;
      else b.innerHTML = `<i>${it.ic}</i><small>${it.nm}</small>`;
      b.addEventListener('click', () => {
        if (!has) { toast('🔒 ' + lookHow(it)); return; }
        const p2 = loadProfile(); p2.look = Object.assign({}, LOOK_DEF, p2.look || {}); p2.look[lookTab] = it.id; saveProfile(p2);
        Sound.sfx.click(); renderLook();
      });
      box.appendChild(b);
    }
    $('lkHint').textContent = `Открыто ${own} из ${set.length} · новые – за достижения и звания`;
  }
  function lookHow(it) {
    const [t, v] = it.src.split(':');
    if (t === 'k') return `Нужно звание ${RANKS[v].ic} ${RANKS[v].nm} (${RANKS[v].at} славы)`;
    if (v.startsWith('ss_')) { const [, m, k] = v.split('_'); const L = Object.keys(SEASON_REWARDS).find(x => SEASON_REWARDS[x] === k); return `Награда сезона «${SEASON_THEMES[m].nm}» – уровень ${L} дороги сезона`; }
    const a = ACH_BY[v], pr = loadProfile(); if (!a) return 'Скоро';
    if (a.secret && !(pr.ach || {})[a.id]) return 'Награда за секретное достижение 🤫';
    if (a.hid && a.hid(pr)) return 'Награда за достижение, которое откроется позже';
    return `Достижение «${a.nm}» – ${a.ds}`;
  }
  // живое превью ауры с героиней
  function lookLoop() {
    cancelAnimationFrame(lookRaf);
    const step = now => {
      if (state !== 'look') return;
      const cv = $('lkCv'), c = cv.getContext('2d'), t = now / 1000, lk = myLook(loadProfileCached());
      c.clearRect(0, 0, cv.width, cv.height);
      c.save(); c.translate(cv.width / 2, cv.height / 2 + 14); c.scale(1.6, 1.6);
      shadow(c, 0, 10, 11, 4); drawAura(c, lk.au, 0, 0, t); drawHeroV(rushHeroPick(loadProfileCached()), c, 0, 0, t, 1, 1, 1, false);
      c.restore();
      lookRaf = requestAnimationFrame(step);
    };
    lookRaf = requestAnimationFrame(step);
  }
  let lpcT = 0, lpc = null;
  function loadProfileCached() { const n = performance.now(); if (!lpc || n - lpcT > 500) { lpc = loadProfile(); lpcT = n; } return lpc; }

  // ---------- доска почёта: рекорды и рейтинг подруг ----------
  let hallTab = 'rec';
  function myCard(pr) {
    pr = pr || loadProfile();
    if (!pr.pid) { pr.pid = Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4); saveProfile(pr); }
    const g = gloryOf(pr), lk = myLook(pr), ab = pr.abyssBest, rb = pr.rushBest;
    return { id: pr.pid, nm: cardName(pr), f: g.fame, n: g.n, s: pr.stars || 0, em: lk.em, fr: lk.fr, ti: lk.ti, au: lk.au,
      ab: ab ? ab.wave : 0, rs: rb && rb.n >= rb.total ? rb.time : 0, dl: (pr.life || {}).dBest || 0, ch: nDone(pr), at: Date.now() };
  }
  // карточку присылает чужой телефон – проверяем всё
  function cleanCard(c) {
    if (!c || typeof c !== 'object') return null;
    const id = String(c.id || '').replace(/[^a-z0-9]/g, '').slice(0, 16); if (id.length < 6) return null;
    const num = (v, mx) => clamp(Math.round(+v || 0), 0, mx);
    const pick2 = (k, v) => (LOOK_SETS[k].some(x => x.id === v) ? v : LOOK_DEF[k]);
    return { id, nm: String(c.nm || 'Подруга').replace(/[<>]/g, '').slice(0, 14), f: num(c.f, 99999), n: num(c.n, 999), s: num(c.s, 9999),
      em: pick2('em', c.em), fr: pick2('fr', c.fr), ti: pick2('ti', c.ti), au: pick2('au', c.au), ab: num(c.ab, 9999), rs: num(c.rs, 99999), dl: num(c.dl, 999999), ch: num(c.ch, 99), at: num(c.at, 9e12) };
  }
  function addFriends(cards) {
    const pr = loadProfile(), me = pr.pid; let ch = false;
    pr.friends = pr.friends || {};
    for (const raw of cards) {
      const c = cleanCard(raw); if (!c || c.id === me) continue;
      const old = pr.friends[c.id];
      if (!old || old.at < c.at) { pr.friends[c.id] = c; ch = true; }
    }
    const ids = Object.keys(pr.friends);
    if (ids.length > 40) { ids.sort((a, b) => pr.friends[a].at - pr.friends[b].at); for (const id of ids.slice(0, ids.length - 40)) delete pr.friends[id]; }
    if (ch) saveProfile(pr);
    return ch;
  }
  const fnv = s => { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return (h >>> 0).toString(36); };
  function cardCode(c) { const j = JSON.stringify(c), b = btoa(unescape(encodeURIComponent(j))).replace(/=+$/, ''); return `KR1-${b}-${fnv(j)}`; }
  function readCode(code) {
    const m = String(code || '').replace(/\s+/g, '').match(/KR1-([A-Za-z0-9+/]+)-([a-z0-9]+)/); if (!m) return null;
    try { const j = decodeURIComponent(escape(atob(m[1]))); if (fnv(j) !== m[2]) return null; return cleanCard(JSON.parse(j)); } catch (e) { return null; }
  }
  function openHall(tab) { lifeFlush(); hallTab = tab || 'rec'; renderHall(); setState('hall'); }
  function renderHall() {
    const pr = loadProfile(), g = gloryOf(pr), lk = myLook(pr);
    $('hlMe').innerHTML = `${avatarHtml(lk, 54)}<div><b>${escHtml(cardName(pr))}</b><span>${escHtml(titleText(lk.ti, g.rk))}</span><small>${g.rank.ic} ${g.rank.nm} · ✨ ${fmtN(g.fame)} · 🏆 ${g.n}/${ACHS.length} · ⭐ ${pr.stars || 0}</small></div>`;
    $('hlTabR').classList.toggle('on', hallTab === 'rec'); $('hlTabF').classList.toggle('on', hallTab === 'fr');
    $('hlFriendBox').classList.toggle('hidden', hallTab !== 'fr');
    const box = $('hlList'); box.innerHTML = '';
    if (hallTab === 'rec') {
      const L = pr.life || {}, rb = pr.rushBest, rc = pr.rushBestCoop, ab = pr.abyssBest, dd = pr.daily || {}, tot = loadTotals();
      const row = (ic, nm, v, sub) => { const d = document.createElement('div'); d.className = 'hlRec'; d.innerHTML = `<i>${ic}</i><div><b>${nm}</b>${sub ? `<span>${sub}</span>` : ''}</div><em>${v}</em>`; box.appendChild(d); };
      const sec = t => { const d = document.createElement('div'); d.className = 'hlSec'; d.textContent = t; box.appendChild(d); };
      sec('Режимы');
      row('🕳️', 'Бездна', ab ? `волна ${ab.wave}` : '–', ab ? `${fmtT(ab.time)} · ${HEROES[ab.hero] ? HEROES[ab.hero].name : ''}` : 'ещё не ныряла');
      row('⚔️', 'Босс-раш', rb ? `${rb.n}/${rb.total}` : '–', rb ? fmtT(rb.time) : 'ещё не было');
      row('👥', 'Раш вместе', rc ? `${rc.n}/${rc.total}` : '–', rc ? `${fmtT(rc.time)} · игроков ${rc.players || 2}` : '');
      row('📅', 'Испытание дня', L.dBest ? fmtN(L.dBest) : '–', `лучшая серия: ${L.dStreak || 0} дн. · сыграно ${L.daily || 0}`);
      sec('Быстрее всех');
      for (const n of CH_NUMS) {
        if (!pr['ch' + n + 'Done']) continue;
        const f = (pr.fast || {})[n], nm = (SECRET_CARDS[n] && SECRET_CARDS[n].title) || CHAPTERS[n].name;
        row(CH_META[n] ? CH_META[n].ic : '📍', `Глава ${n}`, f ? fmtT(f.t) : '–', f ? `${escHtml(nm)} · ${DIFFS[f.d] ? DIFFS[f.d].name : ''}${f.co ? ' · вместе' : ''}` : escHtml(nm));
      }
      sec('За всё время');
      row('⚔️', 'Побеждено врагов', fmtN(L.kills || 0), `элитных ${fmtN(L.elites || 0)} · чемпионов ${fmtN(L.champs || 0)}`);
      row('🐉', 'Побеждено боссов', fmtN(L.bosses || 0), `без урона: ${L.noHit || 0}`);
      row('🔥', 'Лучшее комбо', fmtN(L.combo || 0), '');
      row('📦', 'Сундуков открыто', fmtN(L.chests || 0), `мимиков побеждено: ${L.mimics || 0}`);
      row('💫', 'Подруг поднято', fmtN(L.revives || 0), `глав вместе: ${L.coop || 0}`);
      row('⏳', 'Время в игре', fmtT(tot.playTime || 0), `запусков: ${tot.sessions || 0}`);
    } else {
      const me = myCard(pr), list = [me].concat(Object.values(pr.friends || {}).map(cleanCard).filter(Boolean));
      list.sort((a, b) => b.f - a.f || b.n - a.n);
      list.forEach((c, i) => {
        const d = document.createElement('div'); d.className = 'hlFr' + (c.id === me.id ? ' me' : '') + (i < 3 ? ' top' + (i + 1) : '');
        const rk = rankOf(c.f);
        d.innerHTML = `<u>${['🥇', '🥈', '🥉'][i] || i + 1}</u>${avatarHtml(c, 42)}<div><b>${escHtml(c.nm)}${c.id === me.id ? ' (ты)' : ''}</b><span>${escHtml(titleText(c.ti, rk))}</span>` +
          `<small>🏆 ${c.n} · ⭐ ${c.s} · 🗺️ ${c.ch} гл.${c.ab ? ' · 🕳️ ' + c.ab : ''}${c.rs ? ' · ⚔️ ' + fmtT(c.rs) : ''}</small></div><em>✨ ${fmtN(c.f)}</em>`;
        if (c.id !== me.id) {
          const x = document.createElement('button'); x.className = 'hlDel'; x.textContent = '✖';
          x.addEventListener('click', () => { const p2 = loadProfile(); if (p2.friends) delete p2.friends[c.id]; saveProfile(p2); Sound.sfx.click(); renderHall(); });
          d.appendChild(x);
        }
        box.appendChild(d);
      });
      if (list.length === 1) { const d = document.createElement('div'); d.className = 'hint'; d.textContent = 'Пока тут только ты. Сыграйте вместе по Wi-Fi – карточки подруг появятся сами. Или обменяйтесь кодами карточек 👇'; box.appendChild(d); }
    }
  }

  // ---------- Сезоны: задания дня и недели, событие недели, подарки за дни, дорога наград ----------
  const dayNum = (d = new Date()) => Math.floor(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()) / 864e5);
  const weekKey = () => Math.floor((dayNum() + 3) / 7); // недели с понедельника
  const seasonKey = (d = new Date()) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
  const seasonMonth = () => new Date().getMonth();
  const seasonTheme = () => SEASON_THEMES[seasonMonth()];
  const weekEvent = () => WEEK_EVENTS[((weekKey() % WEEK_EVENTS.length) + WEEK_EVENTS.length) % WEEK_EVENTS.length];
  // сезоны (подарки за дни, задания, событие недели, дорога) пока убраны из игры: доделываются. Прогресс в профиле сохраняется
  const SEASON_OFF = true;
  const weekEv = id => !SEASON_OFF && weekEvent().id === id;
  const h32 = s => { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; };
  const rng32 = seed => () => { seed = (seed + 0x6D2B79F5) >>> 0; let t = seed; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  function seasonState(pr) {
    const sk = seasonKey(), dk = dayKey(), wk = weekKey();
    let S = pr.season;
    if (!S || S.id !== sk) { // новый месяц – новый сезон; прошлый – в историю
      if (S && S.id) { pr.seasonHist = pr.seasonHist || {}; pr.seasonHist[S.id] = { lvl: seasonLvl(S.pts).lvl, pts: S.pts }; }
      S = pr.season = { id: sk, pts: 0, lvl: 0, bonus: 0 };
    }
    if (!pr.sday || pr.sday.key !== dk) pr.sday = { key: dk, c: {}, m: {}, done: {}, rer: -1 };
    if (!pr.sweek || pr.sweek.key !== wk) pr.sweek = { key: wk, c: {}, m: {}, done: 0 };
    pr.gift = pr.gift || { n: 0, last: '' };
    return S;
  }
  function seasonLvl(pts) {
    const lvl = Math.min(SEASON_MAX, Math.floor(pts / SEASON_LVL)), over = pts - SEASON_MAX * SEASON_LVL;
    return { lvl, bonus: over > 0 ? Math.min(SEASON_BONUS, Math.floor(over / (SEASON_LVL * 2))) : 0, into: lvl >= SEASON_MAX ? Math.max(0, over) : pts % SEASON_LVL };
  }
  // задания дня: одинаковые у всех в этот день; одно можно заменить
  function shuffled(arr, rnd) { const a = arr.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }
  function dayQuests(pr) {
    const D = pr.sday, rnd = rng32(h32('kq' + D.key));
    const order = shuffled(QUEST_POOL.filter(q => !q.need || pr[q.need] || DEBUG || pr.admin), rnd);
    const picks = order.slice(0, 3);
    if (D.rer >= 0 && D.rer < picks.length && order.length > 3) picks[D.rer] = order[3];
    return picks.map((q, i) => {
      const goal = i === 2 ? q.n[q.n.length - 1] : q.n[Math.floor(rnd() * q.n.length)];
      return { slot: i, k: q.k, ic: q.ic, max: !!q.max, goal, pts: QUEST_PTS[i], text: q.t(goal) };
    });
  }
  function weekQuest(pr) {
    const pool = WEEK_POOL.filter(q => !q.need || pr[q.need] || DEBUG || pr.admin), q = pool[h32('kw' + pr.sweek.key) % pool.length];
    return { slot: 'w', k: q.k, ic: q.ic, max: !!q.max, goal: q.n, pts: WEEK_PTS, text: q.t(q.n) };
  }
  const questVal = (q, box) => (q.max ? box.m[q.k] : box.c[q.k]) || 0;
  // всё, что накопилось в игре, – в задания и искры сезона; выполненное – в награды
  function seasonFlush(pr, quiet) {
    if (SEASON_OFF) { for (const k of Object.keys(DAYC)) delete DAYC[k]; return false; }
    const S = seasonState(pr), D = pr.sday, Wk = pr.sweek;
    let ch = false;
    for (const k of Object.keys(DAYC)) { D.c[k] = (D.c[k] || 0) + DAYC[k]; Wk.c[k] = (Wk.c[k] || 0) + DAYC[k]; if (k === 'spts') S.pts += DAYC[k]; delete DAYC[k]; ch = true; }
    for (const k of Object.keys(DAYM)) { D.m[k] = Math.max(D.m[k] || 0, DAYM[k]); Wk.m[k] = Math.max(Wk.m[k] || 0, DAYM[k]); delete DAYM[k]; ch = true; }
    const got = [];
    for (const q of dayQuests(pr)) if (!D.done[q.slot] && questVal(q, D) >= q.goal) { D.done[q.slot] = 1; S.pts += q.pts; got.push(q); }
    const wq = weekQuest(pr);
    if (!Wk.done && questVal(wq, Wk) >= wq.goal) { Wk.done = 1; S.pts += wq.pts; got.push(wq); }
    if (got.length) { pr.life = pr.life || {}; pr.life.questsDone = (pr.life.questsDone || 0) + got.length; ch = true; }
    if (!S.fx34) { S.fx34 = 1; for (let L = 1; L <= (S.lvl || 0); L++) if (['furn', 'sfurn', 'pet'].includes(SEASON_REWARDS[L])) seasonReward(pr, S, L); } // 0.34: нечётные уровни стали наградами для домика
    const lv = seasonLvl(S.pts), ups = [];
    for (let L = (S.lvl || 0) + 1; L <= lv.lvl; L++) { const r = seasonReward(pr, S, L); if (r) ups.push(r); }
    for (let b = (S.bonus || 0) + 1; b <= lv.bonus; b++) { pr.starsGot = pr.starsGot || {}; pr.starsGot[`s:${S.id}:b${b}`] = 1; ups.push({ L: SEASON_MAX + b, ic: '⭐', nm: 'Бонусная звезда', rw: '+1⭐ для талантов' }); }
    if (lv.lvl !== (S.lvl || 0) || lv.bonus !== (S.bonus || 0)) { S.lvl = lv.lvl; S.bonus = lv.bonus; pr.stars = Object.keys(pr.starsGot || {}).length; ch = true; }
    pr.life = pr.life || {}; pr.life.seasonLvl = Math.max(pr.life.seasonLvl || 0, S.lvl);
    if (!quiet) {
      const T = seasonTheme();
      for (const q of got) achPop({ custom: { ic: q.ic, rar: q.slot === 'w' ? 'Задание недели выполнено' : 'Задание дня выполнено', nm: q.text, rw: `+${q.pts} ✦ искр сезона`, col: '#7dff9a' } });
      for (const u of ups) achPop({ custom: { ic: u.ic, rar: `${T.nm} · уровень ${u.L}`, nm: u.nm, rw: u.rw, col: T.fr.col, big: true } });
    }
    return ch;
  }
  function seasonReward(pr, S, L) {
    const kind = SEASON_REWARDS[L]; if (!kind) return null;
    const m = +S.id.slice(5) - 1, T = SEASON_THEMES[m];
    if (kind === 'furn') { const pool = furnPool(pr); if (!pool.length) { S.pts += 30; return { L, ic: '✦', nm: 'Всё для домика уже есть!', rw: '+30 ✦' }; } const it = pool[Math.floor(Math.random() * pool.length)]; furnGive(pr, it); return { L, ic: it.ic || '🎨', nm: 'Для домика: ' + it.nm, rw: '🏠 поставь в «Домике»' }; }
    if (kind === 'sfurn') { const it = FURN_BY['sz' + m]; furnGive(pr, it); return { L, ic: it.ic, nm: 'Сезонный декор: ' + it.nm, rw: '🏠 только в этом сезоне' }; }
    if (kind === 'pet') { pr.ach = pr.ach || {}; pr.ach[`ss_${m}_pet`] = Date.now(); const pt = PET_BY['sp' + m]; return { L, ic: pt.ic, nm: 'Питомец: ' + pt.nm, rw: '🐾 будет жить в «Домике»' }; }
    if (kind === 'star') { pr.starsGot = pr.starsGot || {}; pr.starsGot[`s:${S.id}:${L}`] = 1; return { L, ic: '⭐', nm: 'Звезда для талантов', rw: '+1⭐' }; }
    pr.ach = pr.ach || {}; pr.ach[`ss_${m}_${kind}`] = Date.now();
    const it = lookItem(kind, ({ em: 'se_', ti: 'st_', au: 'sa_', fr: 'sf_' })[kind] + m);
    const what = { em: 'эмблема', ti: 'титул', au: 'аура', fr: 'рамка' }[kind];
    return { L, ic: kind === 'em' ? T.ic : kind === 'au' ? T.au[0] : kind === 'fr' ? '🖼️' : '📜', nm: `Новая ${what} – только этого сезона!`, rw: kind === 'ti' ? `титул «${it.nm}»` : kind === 'fr' ? `рамка «${it.nm}»` : it.nm || T.ic };
  }
  // подарок дня – при первом заходе в меню
  function seasonDaily() {
    if (SEASON_OFF) return;
    const pr = loadProfile(); seasonState(pr);
    const today = dayKey();
    if (pr.gift.last !== today) {
      pr.gift.n = (pr.gift.n || 0) + 1; pr.gift.last = today;
      const d = (pr.gift.n - 1) % 7, pts = GIFT_PTS[d];
      pr.season.pts += pts;
      if (d === 6) { pr.starsGot = pr.starsGot || {}; pr.starsGot['gift:' + pr.gift.n] = 1; pr.stars = Object.keys(pr.starsGot).length; }
      setTimeout(() => achPop({ custom: { ic: '🎁', rar: `Подарок дня · день ${d + 1} из 7`, nm: d === 6 ? 'Большой подарок!' : 'Спасибо, что заглянула!', rw: `+${pts} ✦` + (d === 6 ? ' · +1⭐' : ''), col: '#ffd25a', big: d === 6 } }), 900);
    }
    seasonFlush(pr);
    achCheck(pr);
    saveProfile(pr);
    renderSeasonBar(pr);
  }
  const leftTxt = ms => { const m = Math.max(0, Math.floor(ms / 60000)), d = Math.floor(m / 1440), h = Math.floor(m % 1440 / 60), mm = m % 60; return d ? `${d} д ${h} ч` : h ? `${h} ч ${mm} мин` : `${mm} мин`; };
  const msToDay = () => { const n = new Date(), e = new Date(n.getFullYear(), n.getMonth(), n.getDate() + 1); return e - n; };
  const msToWeek = () => { const n = new Date(), dow = (n.getDay() + 6) % 7, e = new Date(n.getFullYear(), n.getMonth(), n.getDate() + 7 - dow); return e - n; };
  const msToSeason = () => { const n = new Date(), e = new Date(n.getFullYear(), n.getMonth() + 1, 1); return e - n; };
  function renderSeasonBar(pr) {
    if (SEASON_OFF) { $('seasonBar').classList.add('hidden'); return; }
    pr = pr || loadProfile(); const S = seasonState(pr), T = seasonTheme(), lv = seasonLvl(S.pts);
    const qs = dayQuests(pr), done = qs.filter(q => pr.sday.done[q.slot]).length;
    const bar = $('seasonBar'); bar.style.setProperty('--sa', T.c[0]); bar.style.setProperty('--sb', T.c[1]);
    $('sbIc').textContent = T.ic;
    $('sbTx').innerHTML = `<b>${T.nm}</b> · ур. ${lv.lvl}${lv.lvl >= SEASON_MAX ? ' ✓' : ''} · 📜 ${done}/3 · ${weekEvent().ic}`;
    $('sbFill').style.width = (lv.lvl >= SEASON_MAX ? 100 : Math.round(lv.into / SEASON_LVL * 100)) + '%';
    $('sbLeft').textContent = 'ещё ' + leftTxt(msToSeason());
    bar.classList.toggle('todo', done < 3);
  }
  // ---------- экран сезона ----------
  let seasonTick = 0;
  function openSeason() { lifeFlush(); renderSeason(); setState('season'); clearInterval(seasonTick); seasonTick = setInterval(() => { if (state !== 'season') { clearInterval(seasonTick); return; } seasonTimes(); }, 1000); }
  function seasonTimes() {
    $('snLeft').textContent = `до конца сезона: ${leftTxt(msToSeason())}`;
    $('snDayLeft').textContent = `новые через ${leftTxt(msToDay())}`;
    $('snWeekLeft').textContent = `ещё ${leftTxt(msToWeek())}`;
  }
  function renderSeason() {
    const pr = loadProfile(), S = seasonState(pr), T = seasonTheme(), lv = seasonLvl(S.pts), m = seasonMonth();
    const hd = $('snHead'); hd.style.setProperty('--sa', T.c[0]); hd.style.setProperty('--sb', T.c[1]);
    $('snIc').textContent = T.ic; $('snName').textContent = `Сезон «${T.nm}»`;
    $('snLvl').innerHTML = lv.lvl >= SEASON_MAX ? `Дорога пройдена! ✦ ${S.pts}` + (lv.bonus < SEASON_BONUS ? ` · бонусная звезда через ${SEASON_LVL * 2 - lv.into % (SEASON_LVL * 2)} ✦` : ' · все бонусы собраны') : `Уровень <b>${lv.lvl}</b> из ${SEASON_MAX} · ✦ ${lv.into} / ${SEASON_LVL}`;
    $('snFill').style.width = (lv.lvl >= SEASON_MAX ? 100 : Math.round(lv.into / SEASON_LVL * 100)) + '%';
    // подарки
    const gb = $('snGift'); gb.innerHTML = '';
    const today = (pr.gift.n - 1) % 7, gotToday = pr.gift.last === dayKey();
    for (let d = 0; d < 7; d++) {
      const el = document.createElement('div'); const past = gotToday ? d <= today : d < ((pr.gift.n) % 7);
      el.className = 'snG' + (past ? ' got' : '') + (gotToday && d === today ? ' now' : '') + (d === 6 ? ' big' : '');
      el.innerHTML = `<small>${d + 1}</small><i>${d === 6 ? '⭐' : '🎁'}</i><b>+${GIFT_PTS[d]}</b>`;
      gb.appendChild(el);
    }
    // задания дня
    const db = $('snDay'); db.innerHTML = '';
    for (const q of dayQuests(pr)) db.appendChild(questRow(q, pr.sday, pr.sday.rer < 0 && !pr.sday.done[q.slot]));
    // неделя
    const wb = $('snWeek'); wb.innerHTML = ''; wb.appendChild(questRow(weekQuest(pr), pr.sweek, false));
    const E = weekEvent();
    $('snEvent').innerHTML = `<i>${E.ic}</i><div><b>${E.nm}</b><span>${E.ds}</span><small id="snEvLeft"></small></div>`;
    // дорога
    const rb = $('snRoad'); rb.innerHTML = '';
    for (let L = 1; L <= SEASON_MAX; L++) {
      const k = SEASON_REWARDS[L], has = lv.lvl >= L, el = document.createElement('div');
      el.className = 'snR' + (has ? ' got' : '') + (L === lv.lvl + 1 ? ' next' : '') + (k && k !== 'star' && k !== 'furn' ? ' cos' : '') + (!k ? ' empty' : '');
      let ic = '·', lab = '';
      if (k === 'star') { ic = '⭐'; lab = '+1⭐'; }
      else if (k === 'furn') { ic = '🛋️'; lab = 'для домика'; }
      else if (k === 'sfurn') { ic = FURN_BY['sz' + m].ic; lab = 'декор'; }
      else if (k === 'pet') { ic = PET_BY['sp' + m].ic; lab = 'питомец'; }
      else if (k) {
        const id = ({ em: 'se_', ti: 'st_', au: 'sa_', fr: 'sf_' })[k] + m;
        if (k === 'em') { ic = avatarHtml({ em: id, fr: 'wood' }, 30); lab = 'эмблема'; }
        else if (k === 'fr') { ic = avatarHtml({ em: myLook(pr).em, fr: id }, 30); lab = 'рамка'; }
        else if (k === 'au') { ic = T.au[0]; lab = 'аура'; }
        else { ic = '📜'; lab = 'титул'; }
      }
      el.innerHTML = `<u>${L}</u><i>${ic}</i><small>${lab}</small>`;
      rb.appendChild(el);
    }
    $('snBonus').textContent = `После 20-го уровня – ещё звезда за каждые ${SEASON_LVL * 2} ✦ (до ${SEASON_BONUS}). Вещи сезона бывают только в ${['январе', 'феврале', 'марте', 'апреле', 'мае', 'июне', 'июле', 'августе', 'сентябре', 'октябре', 'ноябре', 'декабре'][m]}!`;
    seasonTimes();
  }
  function questRow(q, box, canSwap) {
    const v = Math.min(questVal(q, box), q.goal), done = !!(q.slot === 'w' ? box.done : box.done[q.slot]);
    const el = document.createElement('div'); el.className = 'snQ' + (done ? ' done' : '') + (q.slot === 'w' ? ' week' : '');
    el.innerHTML = `<i>${done ? '✅' : q.ic}</i><div><b>${escHtml(q.text)}</b>` + (q.goal > 1 ? `<em class="bar"><u style="width:${Math.round(v / q.goal * 100)}%"></u></em><small>${fmtN(v)} / ${fmtN(q.goal)}</small>` : '') + `</div><s>+${q.pts} ✦</s>`;
    if (canSwap) {
      const b = document.createElement('button'); b.className = 'snSwap'; b.textContent = '🔄'; b.title = 'Заменить задание (раз в день)';
      b.addEventListener('click', () => { const p2 = loadProfile(); seasonState(p2); if (p2.sday.rer >= 0 || p2.sday.done[q.slot]) return; p2.sday.rer = q.slot; saveProfile(p2); Sound.sfx.click(); toast('🔄 Задание заменено – следующая замена завтра'); renderSeason(); });
      el.appendChild(b);
    }
    return el;
  }

  // ---------- Домик героинь ----------
  const furnOwned = (it, pr) => !!(it.def || pr.admin || (pr.furn || {})[it.id]);
  function petOwned(pet, pr) {
    if (pr.admin) return true;
    const [t, v] = pet.src.split(':');
    if (t === 'w') return pr.ch4Choice === v || !!(pr.ch4Seen || {})[v];
    if (t === 'ch') return !!pr['ch' + v + 'Done'];
    return !!(pr.ach || {})[v];
  }
  function petHow(pet) {
    const [t, v] = pet.src.split(':');
    if (t === 'w') return 'Живёт у той, кто выбрала добрую концовку';
    if (t === 'ch') return `Пройди главу ${v}`;
    if (v.startsWith('ss_')) return `Сезон «${SEASON_THEMES[+v.split('_')[1]].nm}» – 15-й уровень дороги сезона`;
    const a = ACH_BY[v]; return a ? (a.secret ? 'Награда за секретное достижение 🤫' : `Достижение «${a.nm}»`) : 'Скоро';
  }
  function homeState(pr) {
    const H = pr.home = pr.home || {};
    H.wall = H.wall || 'stripes'; H.floor = H.floor || 'wood';
    H.slots = H.slots || { wallL: 'pic', wallR: '', sill: 'teddy', lamp: 'bulb', plant: 'potplant', floorL: 'sofa', center: 'yarn', floorR: '' };
    if (!H.pets) H.pets = PETS.filter(p => petOwned(p, pr)).slice(0, 1).map(p => p.id);
    H.pets = H.pets.filter(id => PET_BY[id] && petOwned(PET_BY[id], pr)).slice(0, HOME_PETS_MAX);
    return H;
  }
  // вещь для домика: случайная из ещё не найденных
  function furnPool(pr) { return [...FURNITURE.filter(f => f.m === undefined), ...WALLPAPERS, ...FLOORS].filter(f => !furnOwned(f, pr)); }
  function furnGive(pr, it) { pr.furn = pr.furn || {}; pr.furn[it.id] = Date.now(); }
  function furnDrop(x, y) {
    const pr = loadProfile(), pool = furnPool(pr); if (!pool.length) return;
    const it = pool[Math.floor(Math.random() * pool.length)]; furnGive(pr, it); saveProfile(pr);
    floatText(x, y - 50, '🏠 ' + (it.ic || '🎨') + ' ' + it.nm, '#ffd25a', true);
    achPop({ custom: { ic: it.ic || '🎨', rar: 'Для домика', nm: it.nm, rw: 'Поставить можно в «Коллекции» → «Домик»', col: '#ffb46a' } });
  }
  const HOME = { raf: 0, actors: [], t: 0, last: 0, bubbles: [], hearts: [], edit: false, tab: 'furn', slot: 'wallL', back: 'coll', thumbs: {} };
  function openHome(back) {
    HOME.back = back || 'coll';
    const pr = loadProfile(), H = homeState(pr); saveProfile(pr);
    const heroes = ['krilessa'].concat(pr.ch1Done || DEBUG || pr.admin ? ['ryzhovaya'] : []).concat(pr.ch3Done || DEBUG || pr.admin ? ['tessa'] : []);
    HOME.actors = heroes.map((id, i) => ({ hero: id, x: 0.25 + i * 0.25, y: 0.8 + (i % 2) * 0.06, tx: null, face: 1, wait: 1 + i, jump: 0, sayT: 4 + i * 3 }))
      .concat(H.pets.map((id, i) => ({ pet: id, x: 0.3 + i * 0.2, y: 0.88, tx: null, face: 1, wait: i, jump: 0, ph: Math.random() * 6 })));
    HOME.bubbles = []; HOME.hearts = []; HOME.edit = false; $('homeEdit').classList.add('hidden');
    setState('home'); Sound.music('menu');
    cancelAnimationFrame(HOME.raf); HOME.last = performance.now(); HOME.raf = requestAnimationFrame(homeLoop);
    $('homeInfo').textContent = homeCount(pr);
  }
  function homeCount(pr) {
    const all = [...FURNITURE, ...WALLPAPERS, ...FLOORS], own = all.filter(f => furnOwned(f, pr)).length, pets = PETS.filter(p => petOwned(p, pr)).length;
    return `🛋️ ${own}/${all.length} · 🐾 ${pets}/${PETS.length}`;
  }
  function homeLoop(now) {
    if (state !== 'home') { HOME.raf = 0; return; }
    const dt = Math.min(0.05, (now - HOME.last) / 1000); HOME.last = now; HOME.t += dt;
    const cv = $('homeCv'), r = cv.getBoundingClientRect(), dpr = Math.min(2, window.devicePixelRatio || 1);
    if (cv.width !== Math.round(r.width * dpr) || cv.height !== Math.round(r.height * dpr)) { cv.width = Math.round(r.width * dpr); cv.height = Math.round(r.height * dpr); }
    const c = cv.getContext('2d'); c.setTransform(dpr, 0, 0, dpr, 0, 0);
    homeUpdate(dt);
    try { drawHome(c, r.width, r.height, HOME.t); } catch (e) { logErr(e, 'home'); }
    if (paperOn) try { // комната – тоже акварель: светлее и с зерном бумаги
      if (!PAPER.tex) { PAPER.tex = paperTex(); }
      c.save(); c.globalCompositeOperation = 'screen'; c.fillStyle = 'rgba(255,236,206,.22)'; c.fillRect(0, 0, r.width, r.height);
      c.globalCompositeOperation = 'multiply'; c.fillStyle = c.createPattern(PAPER.tex, 'repeat'); c.fillRect(0, 0, r.width, r.height); c.restore();
    } catch (e) {}
    HOME.raf = requestAnimationFrame(homeLoop);
  }
  function homeUpdate(dt) {
    for (const a of HOME.actors) {
      if (a.jump > 0) a.jump = Math.max(0, a.jump - dt * 1.8);
      if (a.tx === null) { a.wait -= dt; if (a.wait <= 0) { a.tx = 0.08 + Math.random() * 0.84; a.ty = a.hero ? 0.76 + Math.random() * 0.14 : 0.82 + Math.random() * 0.12; } }
      else {
        const dx = a.tx - a.x, dy = a.ty - a.y, d = Math.hypot(dx, dy), sp = (a.hero ? 0.09 : 0.12) * dt;
        if (d < sp) { a.x = a.tx; a.y = a.ty; a.tx = null; a.wait = 1.5 + Math.random() * 4; } else { a.x += dx / d * sp; a.y += dy / d * sp; a.face = dx > 0 ? 1 : -1; }
      }
      if (a.hero) { a.sayT -= dt; if (a.sayT <= 0) { a.sayT = 9 + Math.random() * 10; homeSay(a); } }
    }
    HOME.bubbles = HOME.bubbles.filter(b => (b.t -= dt) > 0);
    HOME.hearts = HOME.hearts.filter(h => (h.t += dt) < 1.2);
  }
  function homeSay(a, txt) { HOME.bubbles = HOME.bubbles.filter(b => b.a !== a); HOME.bubbles.push({ a, txt: txt || pick(HOME_LINES[a.hero] || ['✨']), t: 3 }); }
  // раскладка комнаты в долях экрана
  const HL = { floorY: 0.56, win: [0.33, 0.05, 0.34, 0.2], shelf: [0.25, 0.43, 0.47], cab: [0.79, 0.31, 0.18, 0.26],
    spots: { wallL: [0.14, 0.3, 0.13], wallR: [0.86, 0.2, 0.1], lamp: [0.14, 0.1, 0.11], sill: [0.58, 0.245, 0.08], plant: [0.07, 0.66, 0.17], floorL: [0.25, 0.71, 0.2], center: [0.52, 0.8, 0.13], floorR: [0.8, 0.71, 0.2] } };
  function drawHome(c, W, H, t) {
    const pr = loadProfileCached(), S = homeState(pr), wp = WALLPAPERS.find(w => w.id === S.wall) || WALLPAPERS[0], fl = FLOORS.find(f => f.id === S.floor) || FLOORS[0];
    const fy = H * HL.floorY;
    // стена с обоями
    c.fillStyle = wp.c[0]; c.fillRect(0, 0, W, fy);
    c.save(); c.beginPath(); c.rect(0, 0, W, fy); c.clip(); c.fillStyle = wp.c[1]; c.strokeStyle = wp.c[1];
    const u = W / 12;
    if (wp.id === 'stripes') for (let x = 0; x < W; x += u * 2) c.fillRect(x, 0, u, fy);
    else if (wp.id === 'dots') { c.globalAlpha = 0.45; for (let y = u / 2; y < fy; y += u) for (let x = (Math.floor(y / u) % 2) * u / 2; x < W; x += u) { c.beginPath(); c.arc(x, y, u * 0.14, 0, TAU); c.fill(); } }
    else if (wp.id === 'stars' || wp.id === 'hearts') { c.globalAlpha = 0.4; c.font = `${u * 0.45}px sans-serif`; c.textAlign = 'center'; for (let y = u / 2; y < fy; y += u) for (let x = (Math.floor(y / u) % 2) * u / 2; x < W + u; x += u) c.fillText(wp.id === 'stars' ? '★' : '♥', x, y); }
    else if (wp.id === 'waves') { c.globalAlpha = 0.45; c.lineWidth = 3; for (let y = u / 2; y < fy; y += u * 0.8) { c.beginPath(); for (let x = 0; x <= W; x += 6) c.lineTo(x, y + Math.sin(x / u * 3) * u * 0.15); c.stroke(); } }
    else if (wp.id === 'bricks') { c.globalAlpha = 0.5; c.lineWidth = 2; for (let y = 0, row = 0; y < fy; y += u * 0.5, row++) { c.beginPath(); c.moveTo(0, y); c.lineTo(W, y); c.stroke(); for (let x = (row % 2) * u / 2; x < W; x += u) { c.beginPath(); c.moveTo(x, y); c.lineTo(x, y + u * 0.5); c.stroke(); } } }
    c.restore();
    // окно: время суток настоящее, за стеклом – сезон
    const [wx, wy, ww, wh] = [HL.win[0] * W, HL.win[1] * H, HL.win[2] * W, HL.win[3] * H], hr = new Date().getHours();
    const night = hr < 6 || hr >= 21, eve = !night && hr >= 17;
    const sky = c.createLinearGradient(0, wy, 0, wy + wh);
    if (night) { sky.addColorStop(0, '#060a24'); sky.addColorStop(1, '#1a2050'); } else if (eve) { sky.addColorStop(0, '#ff8a5a'); sky.addColorStop(1, '#ffd08a'); } else { sky.addColorStop(0, '#5ab8ff'); sky.addColorStop(1, '#bfeaff'); }
    c.fillStyle = sky; c.fillRect(wx, wy, ww, wh);
    c.save(); c.beginPath(); c.rect(wx, wy, ww, wh); c.clip();
    if (night) { c.fillStyle = '#fff'; for (let k = 0; k < 14; k++) { c.globalAlpha = 0.5 + 0.5 * Math.sin(t * 2 + k); c.fillRect(wx + ((k * 37) % 100) / 100 * ww, wy + ((k * 53) % 70) / 100 * wh, 2, 2); } c.globalAlpha = 1; c.font = `${wh * 0.32}px sans-serif`; c.fillText('🌙', wx + ww * 0.7, wy + wh * 0.4); }
    else { c.font = `${wh * 0.32}px sans-serif`; c.fillText(eve ? '🌇' : '☀️', wx + ww * 0.68, wy + wh * 0.42); c.globalAlpha = 0.85; c.fillText('☁️', wx + ((t * 6) % (ww + 60)) - 40, wy + wh * 0.62); c.globalAlpha = 1; }
    const m = seasonMonth(), fall = m === 11 || m <= 1 ? '❄️' : m === 9 || m === 10 ? '🍂' : m >= 2 && m <= 4 ? '🌸' : '';
    if (fall) { c.font = `${wh * 0.12}px sans-serif`; for (let k = 0; k < 6; k++) { const ph = (t * 0.25 + k / 6) % 1; c.fillText(fall, wx + ((k * 29) % 100) / 100 * ww + Math.sin(t + k) * 6, wy + ph * wh); } }
    c.restore();
    c.strokeStyle = '#6a3a1a'; c.lineWidth = 6; c.strokeRect(wx, wy, ww, wh); c.lineWidth = 3; c.beginPath(); c.moveTo(wx + ww / 2, wy); c.lineTo(wx + ww / 2, wy + wh); c.moveTo(wx, wy + wh / 2); c.lineTo(wx + ww, wy + wh / 2); c.stroke();
    c.fillStyle = 'rgba(255,140,190,0.85)'; c.fillRect(wx - 10, wy - 6, 14, wh + 10); c.fillRect(wx + ww - 4, wy - 6, 14, wh + 10); // шторки
    c.fillStyle = '#8a5a30'; c.fillRect(wx - 12, wy + wh, ww + 24, 8); // подоконник
    // плинтус и пол
    c.fillStyle = 'rgba(0,0,0,0.35)'; c.fillRect(0, fy - 6, W, 8);
    c.fillStyle = fl.c[0]; c.fillRect(0, fy, W, H - fy);
    c.save(); c.beginPath(); c.rect(0, fy, W, H - fy); c.clip(); c.strokeStyle = fl.c[1]; c.fillStyle = fl.c[1];
    if (fl.id === 'wood') { c.lineWidth = 2; for (let y = fy, row = 0; y < H; y += 22, row++) { c.beginPath(); c.moveTo(0, y); c.lineTo(W, y); c.stroke(); for (let x = (row % 2) * 40; x < W; x += 80) { c.beginPath(); c.moveTo(x, y); c.lineTo(x, y + 22); c.stroke(); } } }
    else if (fl.id === 'tiles') { const s2 = W / 9; for (let y = fy, r2 = 0; y < H; y += s2, r2++) for (let x = (r2 % 2) * s2, k = 0; x < W; x += s2 * 2, k++) c.fillRect(x, y, s2, s2); }
    else if (fl.id === 'carpet') { c.globalAlpha = 0.5; c.lineWidth = 6; c.strokeRect(10, fy + 10, W - 20, H - fy - 20); }
    else if (fl.id === 'grass') { c.lineWidth = 2; for (let k = 0; k < 90; k++) { const x = (k * 53) % W, y = fy + ((k * 97) % 1000) / 1000 * (H - fy); c.beginPath(); c.moveTo(x, y); c.lineTo(x + 3, y - 8); c.stroke(); } }
    c.restore();
    // ковёр под серединой
    const cs = HL.spots.center; c.fillStyle = 'rgba(255,120,170,0.35)'; c.beginPath(); c.ellipse(cs[0] * W, cs[1] * H + 10, W * 0.2, H * 0.045, 0, 0, TAU); c.fill();
    // полка с трофеями
    const [sx, sy, sw] = [HL.shelf[0] * W, HL.shelf[1] * H, HL.shelf[2] * W];
    c.fillStyle = '#8a5a30'; c.fillRect(sx, sy, sw, 9); c.fillStyle = 'rgba(0,0,0,0.3)'; c.fillRect(sx, sy + 9, sw, 4);
    const D = bookData(), L = bookList(), beat = L.bs.filter(k => (D.b[k] || 0) > 0), ts = Math.min(sw / 7, 44);
    beat.slice(0, 7).forEach((k, i) => { if (!HOME.thumbs[k]) HOME.thumbs[k] = bookThumb('b', k, 64, true); c.drawImage(HOME.thumbs[k], sx + i * (sw / 7) + (sw / 7 - ts) / 2, sy - ts + 4, ts, ts); });
    if (beat.length > 7) { c.fillStyle = '#ffe08a'; c.font = 'bold 11px sans-serif'; c.textAlign = 'right'; c.fillText(`+${beat.length - 7}`, sx + sw, sy + 24); }
    if (!beat.length) { c.fillStyle = 'rgba(255,255,255,0.5)'; c.font = '11px sans-serif'; c.textAlign = 'center'; c.fillText('здесь будут трофеи', sx + sw / 2, sy - 8); }
    // витрина реликвий
    const [cx0, cy0, cw, ch0] = [HL.cab[0] * W, HL.cab[1] * H, HL.cab[2] * W, HL.cab[3] * H];
    c.fillStyle = '#5a3a1a'; c.fillRect(cx0 - 4, cy0 - 4, cw + 8, ch0 + 8);
    c.fillStyle = 'rgba(190,230,255,0.25)'; c.fillRect(cx0, cy0, cw, ch0);
    c.fillStyle = '#5a3a1a'; for (let k = 1; k < 3; k++) c.fillRect(cx0, cy0 + ch0 * k / 3 - 2, cw, 3);
    const lvs = pr.relicLv || {}, own = Object.keys(RELICS).filter(id => lvs[id]);
    c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillStyle = '#fff';
    own.slice(0, 9).forEach((id, i) => {
      const col = i % 3, row = Math.floor(i / 3), x = cx0 + cw * (col + 0.5) / 3, y = cy0 + ch0 * (row + 0.45) / 3;
      c.font = `${Math.min(cw / 3.6, 22)}px sans-serif`; c.fillText(RELICS[id].ic, x, y);
      if (lvs[id] > 1) { c.font = 'bold 9px sans-serif'; c.fillStyle = '#ffd25a'; c.fillText('★'.repeat(lvs[id]), x, y + 13); c.fillStyle = '#fff'; }
    });
    c.fillStyle = 'rgba(255,255,255,0.25)'; c.fillRect(cx0 + 4, cy0 + 4, 4, ch0 - 8);
    // мебель на стенах и свет
    const drawItem = (slot, sz) => { const id = S.slots[slot], f = FURN_BY[id]; if (!f) return; const [x, y, s] = HL.spots[slot]; c.globalAlpha = 1; c.fillStyle = '#fff'; c.font = `${(sz || s) * W}px sans-serif`; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(f.ic, x * W, y * H); }; // цветные эмодзи берут прозрачность заливки – только непрозрачная
    const lamp = FURN_BY[S.slots.lamp];
    if (lamp) { const [lx, ly] = HL.spots.lamp; c.strokeStyle = 'rgba(0,0,0,0.5)'; c.lineWidth = 2; c.beginPath(); c.moveTo(lx * W, 0); c.lineTo(lx * W, ly * H - 14); c.stroke(); drawItem('lamp'); }
    drawItem('wallL'); drawItem('wallR'); drawItem('sill');
    // пол: мебель, героини и питомцы по глубине
    const items = ['plant', 'floorL', 'center', 'floorR'].map(s => ({ y: HL.spots[s][1], slot: s }));
    for (const a of HOME.actors) items.push({ y: a.y, a });
    items.sort((p, q) => p.y - q.y);
    for (const it of items) {
      if (it.slot) { drawItem(it.slot); continue; }
      const a = it.a, x = a.x * W, y = a.y * H - Math.sin(a.jump * Math.PI) * 40;
      if (a.hero) { shadow(c, x, a.y * H + 12, 14, 5); drawHeroV(a.hero, c, x, y, t, a.face, 1.35, 1, a.tx !== null); a.sx = x; a.sy = y; }
      else {
        const pet = PET_BY[a.pet]; if (!pet) continue;
        const bob = pet.fly ? Math.sin(t * 3 + a.ph) * 8 - 30 : Math.abs(Math.sin(t * 8 + a.ph)) * (a.tx !== null ? 5 : 0);
        shadow(c, x, a.y * H + 10, 11, 4);
        c.save(); c.translate(x, y - bob); c.scale(a.face < 0 ? -1 : 1, 1); c.globalAlpha = 1; c.fillStyle = '#fff'; c.font = `${W * 0.085}px sans-serif`; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(pet.ic, 0, 0); c.restore();
        a.sx = x; a.sy = y - bob;
      }
    }
    // ночью темнее, лампа светит
    if (night) {
      const [lx, ly] = HL.spots.lamp, g = c.createRadialGradient(lx * W, ly * H, 10, lx * W, ly * H, W * 0.9);
      g.addColorStop(0, 'rgba(255,220,140,0.05)'); g.addColorStop(0.5, 'rgba(10,8,30,0.25)'); g.addColorStop(1, 'rgba(5,4,20,0.5)'); c.fillStyle = g; c.fillRect(0, 0, W, H);
    }
    // реплики и сердечки
    c.textAlign = 'center'; c.textBaseline = 'middle';
    for (const b of HOME.bubbles) {
      const x = b.a.sx || 0, y = (b.a.sy || 0) - 70; c.font = 'bold 12px sans-serif'; const w2 = c.measureText(b.txt).width + 16;
      c.globalAlpha = Math.min(1, b.t * 2); c.fillStyle = 'rgba(255,255,255,0.95)'; roundRect(c, clamp(x - w2 / 2, 4, W - w2 - 4), y - 13, w2, 26, 10); c.fill();
      c.fillStyle = '#2a1a4a'; c.fillText(b.txt, clamp(x, w2 / 2 + 4, W - w2 / 2 - 4), y); c.globalAlpha = 1;
    }
    for (const h of HOME.hearts) { c.globalAlpha = 1 - h.t / 1.2; c.font = '16px sans-serif'; c.fillText(h.g || '💗', h.x + Math.sin(h.t * 6) * 6, h.y - h.t * 60); }
    c.globalAlpha = 1;
  }
  function homeTap(e) {
    if (HOME.edit) return;
    const r = $('homeCv').getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top, W = r.width, H = r.height;
    for (const a of HOME.actors) {
      if (a.sx === undefined || Math.abs(x - a.sx) > 34 || Math.abs(y - (a.sy - (a.hero ? 25 : 0))) > 45) continue;
      a.jump = 1; for (let k = 0; k < 5; k++) HOME.hearts.push({ x: a.sx + rnd(-16, 16), y: a.sy - 30, t: -k * 0.08, g: a.pet ? '💖' : '💗' });
      if (a.hero) { homeSay(a); if (a.hero === 'tessa' && Sound.sfx.meow) Sound.sfx.meow(); else Sound.sfx.blink(); } else Sound.sfx.heart();
      life('homeTap'); return;
    }
    const [sx, sy, sw] = [HL.shelf[0] * W, HL.shelf[1] * H, HL.shelf[2] * W];
    if (x > sx && x < sx + sw && y > sy - 50 && y < sy + 14) { openBook('b', 'home'); return; }
    const [cx0, cy0, cw, ch0] = [HL.cab[0] * W, HL.cab[1] * H, HL.cab[2] * W, HL.cab[3] * H];
    if (x > cx0 && x < cx0 + cw && y > cy0 && y < cy0 + ch0) { relicsFrom = 'home'; openRelics(); }
  }
  // редактор: мебель по местам, питомцы, обои и пол
  function renderHomeEdit() {
    const pr = loadProfile(), S = homeState(pr);
    for (const k of ['furn', 'pets', 'wall']) $('heT_' + k).classList.toggle('on', HOME.tab === k);
    const slots = $('heSlots'), grid = $('heGrid'); slots.innerHTML = ''; grid.innerHTML = '';
    slots.classList.toggle('hidden', HOME.tab !== 'furn');
    const cell = (ic, nm, on, has, fn, how) => {
      const b = document.createElement('button'); b.className = 'heItem' + (on ? ' on' : '') + (has ? '' : ' no');
      b.innerHTML = `<i>${ic}</i><small>${nm}</small>`;
      b.addEventListener('click', () => { if (!has) { toast('🔒 ' + how); return; } fn(); Sound.sfx.click(); const p3 = loadProfile(); saveProfile(p3); renderHomeEdit(); $('homeInfo').textContent = homeCount(loadProfile()); });
      grid.appendChild(b);
    };
    const save = fn => { const p2 = loadProfile(); const S2 = homeState(p2); fn(S2, p2); saveProfile(p2); lpc = null; };
    if (HOME.tab === 'furn') {
      for (const sl of HOME_SLOTS) {
        const b = document.createElement('button'); b.className = 'heSlot' + (HOME.slot === sl.id ? ' on' : ''); const f = FURN_BY[S.slots[sl.id]];
        b.innerHTML = `${f ? f.ic : '∅'}<small>${sl.nm}</small>`; b.addEventListener('click', () => { HOME.slot = sl.id; Sound.sfx.click(); renderHomeEdit(); }); slots.appendChild(b);
      }
      const sl = HOME_SLOTS.find(x => x.id === HOME.slot);
      cell('∅', 'Пусто', !S.slots[sl.id], true, () => save(S2 => { S2.slots[sl.id] = ''; }));
      for (const f of FURNITURE.filter(x => x.k === sl.k)) {
        if (f.m !== undefined && !furnOwned(f, pr) && f.m !== seasonMonth()) continue; // чужие сезоны не мелькают
        cell(f.ic, f.nm, S.slots[sl.id] === f.id, furnOwned(f, pr), () => save(S2 => { for (const k in S2.slots) if (S2.slots[k] === f.id && k !== sl.id) S2.slots[k] = ''; S2.slots[sl.id] = f.id; }),
          f.m !== undefined ? `Сезон «${SEASON_THEMES[f.m].nm}» – 3-й уровень дороги сезона` : 'Выпадает из сундуков и с дороги сезона');
      }
      $('heHint').textContent = 'Вещи для домика выпадают из серебряных и золотых сундуков, тайников и с дороги сезона';
    } else if (HOME.tab === 'pets') {
      for (const pt of PETS) {
        const has = petOwned(pt, pr); if (pt.src.includes('ss_') && !has && +pt.src.split('_')[1] !== seasonMonth()) continue;
        cell(pt.ic, pt.nm, S.pets.includes(pt.id), has, () => save(S2 => {
          if (S2.pets.includes(pt.id)) S2.pets = S2.pets.filter(x => x !== pt.id);
          else { if (S2.pets.length >= HOME_PETS_MAX) S2.pets.shift(); S2.pets.push(pt.id); }
          HOME.actors = HOME.actors.filter(a => !a.pet || S2.pets.includes(a.pet));
          for (const id of S2.pets) if (!HOME.actors.some(a => a.pet === id)) HOME.actors.push({ pet: id, x: 0.5, y: 0.9, tx: null, face: 1, wait: 0.5, jump: 1, ph: Math.random() * 6 });
        }), petHow(pt));
      }
      $('heHint').textContent = `Дома могут жить до ${HOME_PETS_MAX} питомцев сразу`;
    } else {
      for (const w of WALLPAPERS) cell('🎨', w.nm, S.wall === w.id, furnOwned(w, pr), () => save(S2 => { S2.wall = w.id; }), 'Выпадает из сундуков и с дороги сезона');
      for (const f of FLOORS) cell('🟫', f.nm, S.floor === f.id, furnOwned(f, pr), () => save(S2 => { S2.floor = f.id; }), 'Выпадает из сундуков и с дороги сезона');
      $('heHint').textContent = 'Обои и пол – тоже находки из сундуков';
    }
  }
  let relicsFrom = 'coll';

  // ---------- Кринжопедия: все встреченные мобы и боссы ----------
  const BOOK = { e: {}, b: {} };
  let bookCache = null, bookScanT = 0;
  const bookData = () => { if (!bookCache) { const pr = loadProfile(); bookCache = pr.book || { e: {}, b: {} }; } return bookCache; };
  const bookKnown = (g, k) => (bookData()[g][k] !== undefined) || BOOK[g][k] !== undefined;
  function bookSee(g, k) { if (!bookKnown(g, k)) BOOK[g][k] = 0; }
  function bookKill(g, k) { BOOK[g][k] = (BOOK[g][k] || 0) + 1; }
  let BOOK_LIST = null;
  function bookList() {
    if (BOOK_LIST) return BOOK_LIST;
    const eCh = {}, bCh = {};
    for (const n of CH_NUMS) {
      const C = CHAPTERS[n];
      for (const [b] of C.biomeSeeds) if (SPAWNS[b]) for (const [t] of SPAWNS[b]) if (eCh[t] === undefined) eCh[t] = n;
      for (const k of C.bosses) if (bCh[k] === undefined) bCh[k] = n;
    }
    const es = Object.keys(ENEMIES).filter(t => ESPR[ENEMIES[t].sprite || t]).sort((a, b) => (eCh[a] || 99) - (eCh[b] || 99));
    const bs = Object.keys(BOSSES).filter(k => bCh[k] !== undefined).sort((a, b) => bCh[a] - bCh[b]);
    BOOK_LIST = { es, bs, eCh, bCh };
    return BOOK_LIST;
  }
  function bookCount() {
    const L = bookList(), D = bookData();
    const known = L.es.filter(t => D.e[t] !== undefined || BOOK.e[t] !== undefined).length + L.bs.filter(k => D.b[k] !== undefined || BOOK.b[k] !== undefined).length;
    const total = L.es.length + L.bs.length;
    return { known, total, pct: total ? Math.round(known / total * 100) : 0 };
  }
  // раз в полсекунды: кто рядом – тот «встречен»
  function bookScan(dt) {
    bookScanT -= dt; if (bookScanT > 0) return; bookScanT = 0.5;
    for (const e of G.enemies) if (!e.dead && (e.x - P.x) ** 2 + (e.y - P.y) ** 2 < 430 * 430) bookSee('e', e.type);
    if (G.activeBoss) bookSee('b', G.activeBoss.kind);
  }
  const AI_TXT = { chase: 'Бежит за тобой и кусает', swarm: 'Нападает стаей', ranged: 'Стреляет издалека и держит дистанцию', turret: 'Стоит на месте и палит',
    exploder: 'Подбегает и взрывается', bat: 'Летает зигзагами', charger: 'Разгоняется и таранит', shield: 'Прикрывается щитом спереди', healer: 'Лечит соседей',
    buffer: 'Делает соседей крепче', summoner: 'Призывает помощников', jump: 'Прыгает прямо на тебя', hop: 'Скачет к тебе', bouncer: 'Отскакивает от стен', blinker: 'Телепортируется рядом' };
  function bookThumb(g, k, size, known) {
    const cv = document.createElement('canvas'); cv.width = cv.height = size; const c = cv.getContext('2d');
    try {
      if (g === 'e') {
        const d = ENEMIES[k], e = { type: k, def: d, sprite: d.sprite || k, x: 0, y: 0, r: d.r, t: 0.4, look: 0.3, face: 1, flash: 0, col: d.col, hp: 1, maxHp: 1, charge: 0, fuse: 0, wind: 0, jd: 0, blink: 0,
          shieldAng: 0, healing: 0, buffT: 0, spawnT: 0, slowT: 0, burnT: 0, seed: 1, chn: bookList().eCh[k] || 1, elite: false, vx: 0, vy: 0, kx: 0, ky: 0, fly: !!d.fly };
        c.translate(size / 2, size * 0.58); const s = size * 0.36 / Math.max(10, d.r); c.scale(s, s); ESPR[e.sprite](c, e);
      } else {
        const d = BOSSES[k], b = { kind: k, def: d, flash: 0, stage: 0, look: 0.3, mode: 'idle', charging: false, anim: 0.5, z: 0, state: 'idle', r: d.r, alpha: 1, shield: false, hp: 1, maxHp: 1, t: 0 };
        c.translate(size / 2, size * 0.6); const s = size * 0.33 / Math.max(14, d.r); c.scale(s, s); BSPR[d.sprite || k](c, b, 0.5, 1);
      }
    } catch (e) { c.setTransform(1, 0, 0, 1, 0, 0); c.font = `${size * 0.5}px sans-serif`; c.textAlign = 'center'; c.fillText(g === 'e' ? '👾' : '💀', size / 2, size * 0.68); }
    if (!known) { c.setTransform(1, 0, 0, 1, 0, 0); c.globalCompositeOperation = 'source-atop'; c.fillStyle = '#4a3d72'; c.fillRect(0, 0, size, size); }
    return cv;
  }
  let bookTab = 'e';
  let bookBack = 'coll';
  function openBook(tab, back) { bookTab = typeof tab === 'string' ? tab : 'e'; bookBack = back === 'home' ? 'home' : 'coll'; renderBook(); setState('book'); }
  const bookLeave = () => { if (bookBack === 'home') openHome(HOME.back); else openColl(); };
  const relicsLeave = () => { const f = relicsFrom; relicsFrom = 'coll'; if (f === 'home') openHome(HOME.back); else openColl(); };
  function renderBook() {
    lifeFlush();
    const L = bookList(), D = bookData(), cnt = bookCount();
    $('bookHead').textContent = `Открыто ${cnt.known} из ${cnt.total} (${cnt.pct}%)`;
    $('bookTabE').classList.toggle('on', bookTab === 'e'); $('bookTabB').classList.toggle('on', bookTab === 'b'); $('bookTabV').classList.toggle('on', bookTab === 'v');
    const grid = $('bookGrid'); grid.innerHTML = ''; grid.classList.toggle('evo', bookTab === 'v');
    if (bookTab === 'v') { // эволюции: рецепт виден сразу, название – когда соберёшь
      const seen = loadProfile().evoSeen || {}, un = k => { const u = UPGRADES.find(x => x.id === k); return u ? u.ic + ' ' + u.nm : k; };
      $('bookHead').textContent = `Эволюций открыто ${EVOS.filter(e => seen[e.id]).length} из ${EVOS.length} · два улучшения на нужном уровне сливаются в одно`;
      for (const e of EVOS) {
        const got = !!seen[e.id], el = document.createElement('div'); el.className = 'bkEvo' + (got ? ' got' : '');
        el.innerHTML = `<i>${got ? e.ic : '❔'}</i><div><b>${got ? e.nm : '???'}</b><span>${got ? e.ds : 'Собери рецепт – и узнаешь'}</span><small>${e.need.map(([k, n]) => `${un(k)} ${n}+`).join(' &nbsp;+&nbsp; ')}</small></div>`;
        grid.appendChild(el);
      }
      return;
    }
    for (const k of bookTab === 'e' ? L.es : L.bs) {
      const g = bookTab, v = D[g][k], known = v !== undefined;
      const el = document.createElement('button'); el.className = 'bkCard' + (known ? '' : ' unk');
      el.appendChild(bookThumb(g, k, 64, known));
      const nm = document.createElement('b'); nm.textContent = known ? (g === 'e' ? ENEMIES[k].name : BOSSES[k].name) : '???'; el.appendChild(nm);
      if (known && v > 0) { const s = document.createElement('small'); s.textContent = '✖ ' + fmtN(v); el.appendChild(s); }
      el.addEventListener('click', () => { if (known) bookCard(g, k); else toast('Ещё не встречалась 👀'); });
      grid.appendChild(el);
    }
  }
  function bookCard(g, k) {
    const L = bookList(), D = bookData(), v = D[g][k] || 0, box = $('bkDetail');
    const big = $('bkBig'); big.innerHTML = ''; big.appendChild(bookThumb(g, k, 150, true));
    if (g === 'e') {
      const d = ENEMIES[k], ch = L.eCh[k];
      $('bkName').textContent = d.name;
      $('bkSub').textContent = (ch ? `Глава ${ch}` : 'Особый') + (d.fly ? ' · летает' : '');
      const lines = [AI_TXT[d.ai] || 'Ведёт себя загадочно'];
      if (d.shot) lines.push(d.shot.ring ? 'Стреляет кольцом во все стороны' : d.shot.kind === 'bolt' ? 'Бьёт молнией с неба' : 'Пуляет снарядами');
      if (d.group) lines.push(`Ходит компанией по ${d.group[0]}–${d.group[1]}`);
      if (d.split) lines.push('Если победить – распадается на малышей');
      if (d.puddle) lines.push('Оставляет ядовитую лужу');
      lines.push(v ? `Побеждено: ${fmtN(v)}` : 'Ещё ни разу не побеждён');
      $('bkText').innerHTML = lines.map(t => '• ' + escHtml(t)).join('<br>');
    } else {
      const d = BOSSES[k], ch = L.bCh[k], ln = d.lines || {};
      $('bkName').textContent = d.name;
      $('bkSub').textContent = `${d.sub || 'Босс'} · Глава ${ch}`;
      const out = [];
      if (ln.intro) out.push(`<i>«${escHtml(ln.intro)}»</i>`);
      if (ln.death) out.push(`<i>«${escHtml(ln.death)}»</i>`);
      out.push(v ? `Побеждён: ${fmtN(v)} раз` : 'Ещё не побеждён');
      $('bkText').innerHTML = out.join('<br><br>');
    }
    box.classList.remove('hidden');
  }

  // ---------- хабы меню ----------
  // карточка обороны: выбор карты и рекорды
  function mdDefRender(pr, open) {
    const cur = tdMapPick(pr), best = (pr.tdBest || {})[cur.id], box = $('mdDefMaps');
    $('mdDefTx').textContent = !open ? '🔒 После главы 1' : `${cur.nm}: ${cur.ds.toLowerCase()}` + (best ? ` · рекорд: ${best.wave} ${plural(best.wave, 'волна', 'волны', 'волн')}` : '');
    box.innerHTML = '';
    if (!open) return;
    for (const M of TD_MAPS) {
      const ok = tdMapOpen(M, pr), b = document.createElement('button'), bw = ((pr.tdBest || {})[M.id] || {}).wave || 0;
      b.className = 'mdMap' + (M === cur ? ' on' : '') + (ok ? '' : ' no');
      b.innerHTML = `${ok ? M.ic : '🔒'}<small>${ok ? (bw ? bw : '–') : ''}</small>`;
      b.addEventListener('click', () => {
        if (!ok) { toast(`🔒 «${M.nm}» откроется, когда отобьёшь 10 волн на карте «${TD_MAP_BY[M.need].nm}»`); Sound.sfx.block(); return; }
        const p2 = loadProfile(); p2.settings = p2.settings || {}; p2.settings.defMap = M.id; saveProfile(p2); Sound.sfx.click(); mdDefRender(p2, true);
      });
      box.appendChild(b);
    }
  }
  function openModes() {
    const pr = loadProfile(), open = pr.ch1Done || DEBUG || pr.admin;
    const hero = rushHeroPick(pr); $('mdHero').textContent = '🔄 ' + HEROES[hero].name;
    const rb = pr.rushBest, ab = pr.abyssBest, D = dailyInfo(), dd = pr.daily || {};
    $('mdRushTx').textContent = !open ? '🔒 После главы 1' : rb ? `Рекорд: ${rb.n}/${rb.total} за ${fmtT(rb.time)}` : 'Все побеждённые боссы подряд, на время';
    const ck = open ? abyssCkLoad() : null;
    $('mdAbyssTx').textContent = !open ? '🔒 После главы 1' : ck ? `Сохранено: волна ${ck.wave}` + (ab ? ` · рекорд ${ab.wave}` : '') : ab ? `Рекорд: волна ${ab.wave} · ${fmtT(ab.time)}` : 'Волна за волной, каждая пятая – с боссом';
    mdDefRender(pr, open);
    $('mdAbyssGo').textContent = ck ? 'Дальше' : 'Нырнуть';
    $('mdAbyssNew').classList.toggle('hidden', !ck);
    $('mdDailyTx').textContent = `Глава ${D.ch} · ${D.muts.map(m => MUT_BY[m].ic + ' ' + MUT_BY[m].nm).join(' + ')}` +
      (dd.key === D.key ? ` · сегодня: ${dd.best} очк.` : ' · 5 минут на очки') + (dd.streak > 1 && (dd.key === D.key || dd.key === dayKey(new Date(Date.now() - 864e5))) ? ` · 🔥${dd.streak} дн.` : '');
    for (const id of ['chapRush', 'mdAbyssGo', 'mdDefGo']) $(id).classList.toggle('locked', !open);
    setState('modes');
  }
  // ---------- коллекция реликвий: надеть, снять, посмотреть уровни ----------
  const wearMax = pr => 3 + (((pr.talents || {}).relic || 0) ? 1 : 0);
  function openRelics() { renderRelics(); setState('relics'); }
  function renderRelics() {
    const pr = loadProfile(), lvs = pr.relicLv || {}, worn = (pr.relics || []).filter(id => RELICS[id]), mx = wearMax(pr);
    const own = Object.keys(RELICS).filter(id => lvs[id] || worn.includes(id));
    $('rlHead').textContent = `Найдено ${own.length} из ${Object.keys(RELICS).length} · надето ${worn.length} из ${mx} · новые и прокачка – в золотых сундуках`;
    const box = $('rlList'); box.innerHTML = '';
    for (const id of Object.keys(RELICS).sort((a, b) => (worn.includes(b) - worn.includes(a)) || ((lvs[b] || 0) - (lvs[a] || 0)))) {
      const r = RELICS[id], L = Math.min(3, lvs[id] || (worn.includes(id) ? 1 : 0)), on = worn.includes(id);
      const el = document.createElement('div'); el.className = 'rlRow' + (on ? ' on' : '') + (L ? '' : ' no');
      el.innerHTML = `<i>${L ? r.ic : '❔'}</i><div><b>${L ? r.name : '???'}${L ? ` <u>${'★'.repeat(L)}${'☆'.repeat(3 - L)}</u>` : ''}</b><span>${L ? relicDs(id, L) : 'Ещё не найдена – ищи в золотых сундуках'}</span>${L && L < 3 ? `<small>Ур. ${L + 1}: ${relicDs(id, L + 1)}</small>` : ''}</div>`;
      if (L) {
        const b = document.createElement('button'); b.className = 'btn ' + (on ? 'gray' : ''); b.textContent = on ? 'Снять' : 'Надеть';
        b.addEventListener('click', () => {
          const p2 = loadProfile(); let w = (p2.relics || []).filter(x => RELICS[x]);
          if (w.includes(id)) w = w.filter(x => x !== id);
          else { if (w.length >= wearMax(p2)) { toast(`Можно носить ${wearMax(p2)} – сначала сними одну`); Sound.sfx.block(); return; } w.push(id); }
          p2.relics = w; p2.relicLv = p2.relicLv || {}; if (!p2.relicLv[id]) p2.relicLv[id] = 1; saveProfile(p2); Sound.sfx.click(); renderRelics();
        });
        el.appendChild(b);
      }
      box.appendChild(el);
    }
  }
  function openColl() {
    lifeFlush();
    const pr = loadProfile(), n = ACHS.filter(a => (pr.ach || {})[a.id]).length, cnt = bookCount();
    $('clAchN').textContent = `${n} / ${ACHS.length}`; $('clBookN').textContent = `${cnt.known} / ${cnt.total}`;
    const g = gloryOf(pr); $('clHallN').textContent = `${g.rank.ic} ${g.rank.nm} · ✨ ${fmtN(g.fame)}`;
    let own = 0, all = 0; for (const k in LOOK_SETS) for (const it of LOOK_SETS[k]) { all++; if (lookOwned(it, pr.ach, g.rk)) own++; }
    $('clLookN').textContent = `наград ${own} / ${all}`;
    $('clRelicN').textContent = `${Object.keys(RELICS).filter(id => (pr.relicLv || {})[id] || (pr.relics || []).includes(id)).length} / ${Object.keys(RELICS).length}`;
    $('btnWardrobe').classList.toggle('hidden', !(pr.ch3Done || DEBUG || pr.admin));
    setState('coll');
  }
  // экраны итогов для Бездны и испытания дня
  function victoryExtras(mode) {
    if (mode === 'daily' && G.daily) {
      const D = G.daily;
      $('victoryTitle').textContent = '📅 Время вышло!';
      $('victoryStats').innerHTML = `Очков: <b>${fmtN(D.score)}</b>${D.better ? ' · 🏆 лучший результат дня!' : ''}<br>Лучший сегодня: <b>${fmtN(D.best)}</b> · подряд дней: <b>${D.streak}</b> 🔥<br>Уровень ${P.level} · Врагов: ${G.kills}`;
      $('victoryTeaser').innerHTML = 'Завтра – новая карта и новые правила!'; $('victoryTeaser').classList.remove('hidden');
      $('victoryNext').classList.add('hidden');
      const vc = $('victoryPortrait').getContext('2d'); vc.clearRect(0, 0, 300, 300); vc.drawImage(heroPortrait(P.hero, 300), 0, 0, 300, 300);
    } else if (G.mutEarned !== undefined && mutIds().length && typeof CHN === 'number' && !G.daily) {
      $('victoryStats').insertAdjacentHTML('beforeend', `<br>🧪 Мутаторы: ${mutIds().map(id => MUT_BY[id].ic).join('')}${G.mutEarned ? ` · <b>+${G.mutEarned} ⭐</b>` : ''}`);
    }
  }

  // ------------------------------------------------------------------
  //  Мультиплеер по Wi-Fi. Хозяин считает мир (мобы, боссы, опыт, подбор),
  //  каждый гость – только свою героиню: движение, выстрелы, попадания по себе.
  //  Попадания гостей по мобам уходят хозяину, хозяин рассылает снимки мира.
  // ------------------------------------------------------------------
  const NetT = (() => { // транспорт: Android (NetCore через мост) или BroadcastChannel – для проверок в браузере
    const A = () => { const a = window.KrilessaAndroid; return a && a.netPoll ? a : null; };
    let bc = null, role = null, q = [], hostKey = null, beaconT = 0, info = '', scanning = false, nextCid = 2;
    const myKey = Math.random().toString(36).slice(2, 10), peers = new Map(), keys = new Map();
    const post = m => { try { bc.postMessage(m); } catch (e) { /* ignore */ } };
    function bcInit() { if (bc || typeof BroadcastChannel === 'undefined') return; bc = new BroadcastChannel('krilessa-net'); bc.onmessage = ev => onBc(ev.data); }
    function onBc(m) {
      if (!m || (m.to && m.to !== myKey)) return;
      if (m.k === 'beacon') { if (scanning && role !== 'host') q.push(['found', 0, 'local-' + m.from + '\t0\t' + m.info]); }
      else if (m.k === 'join' && role === 'host') { const cid = nextCid++; peers.set(m.from, cid); keys.set(cid, m.from); post({ k: 'open', to: m.from, from: myKey }); q.push(['conn', cid, 'local']); }
      else if (m.k === 'open' && role === 'client') { hostKey = m.from; q.push(['open', 0, '']); }
      else if (m.k === 'msg') { if (role === 'host') { const cid = peers.get(m.from); if (cid) q.push(['msg', cid, m.d]); } else if (m.from === hostKey) q.push(['msg', 0, m.d]); }
      else if (m.k === 'bye') {
        if (role === 'host') { const cid = peers.get(m.from); if (cid) { peers.delete(m.from); keys.delete(cid); q.push(['drop', cid, '']); } }
        else if (m.from === hostKey) { hostKey = null; q.push(['closed', 0, '']); }
      }
    }
    return {
      get native() { return !!A(); },
      get oldApk() { return !!window.KrilessaAndroid && !A(); },
      host(inf) {
        const a = A(); if (a) { try { return JSON.parse(a.netHost(inf)); } catch (e) { return { ok: false }; } }
        bcInit(); if (!bc) return { ok: false }; role = 'host'; info = inf; clearInterval(beaconT);
        beaconT = setInterval(() => post({ k: 'beacon', from: myKey, info }), 600);
        return { ok: true, port: 0, ips: [] };
      },
      info(inf) { const a = A(); if (a) a.netInfo(inf); else info = inf; },
      scan(on) { const a = A(); if (a) a.netScan(!!on); else { bcInit(); scanning = !!on; } },
      join(ip, port) {
        const a = A(); if (a) { a.netJoin(String(ip), port | 0); return; }
        bcInit(); role = 'client'; post({ k: 'join', to: String(ip).replace('local-', ''), from: myKey });
      },
      send(cid, obj) {
        const s = typeof obj === 'string' ? obj : JSON.stringify(obj);
        const a = A(); if (a) { a.netSend(cid, s); return; }
        if (!bc) return;
        if (role === 'host') { if (cid === -1) { for (const k of peers.keys()) post({ k: 'msg', to: k, from: myKey, d: s }); } else { const k = keys.get(cid); if (k) post({ k: 'msg', to: k, from: myKey, d: s }); } }
        else if (hostKey) post({ k: 'msg', to: hostKey, from: myKey, d: s });
      },
      kick(cid) { const a = A(); if (a) { a.netKick(cid); return; } const k = keys.get(cid); if (k) { post({ k: 'bye', to: k, from: myKey }); peers.delete(k); keys.delete(cid); } },
      poll() {
        const a = A();
        if (a) {
          const s = a.netPoll(); if (!s) return [];
          return s.split('\n').map(l => { const i1 = l.indexOf('\t'), i2 = l.indexOf('\t', i1 + 1); return [l.slice(0, i1), +l.slice(i1 + 1, i2), l.slice(i2 + 1)]; });
        }
        const out = q; q = []; return out;
      },
      ips() { const a = A(); try { return a ? String(a.netIps() || '').split(',').filter(Boolean) : []; } catch (e) { return []; } },
      close() {
        const a = A(); if (a) { a.netClose(); return; }
        if (bc) { if (role === 'host') for (const k of peers.keys()) post({ k: 'bye', to: k, from: myKey }); else if (hostKey) post({ k: 'bye', to: hostKey, from: myKey }); }
        clearInterval(beaconT); role = null; hostKey = null; peers.clear(); keys.clear(); scanning = false;
      },
    };
  })();
  const NET_SNAP = 1 / 15, NET_ST = 1 / 20, NET_AOI = 1150, NET_MAX = 4;
  const MATE_COL = ['#ffd25a', '#7fd8ff', '#ff7ac8', '#7dff9a', '#ffa24a'], MATE_EMO = ['🟡', '🔵', '🟣', '🟢', '🟠'];
  const FK = ['feather', 'fire', 'claw', 'pixel'];
  const PK = ['xp', 'heart', 'star', 'key', 'magnet', 'shard'];
  const mateCol = id => MATE_COL[(id - 1) % MATE_COL.length];
  function netReset() {
    Object.assign(NET, { on: false, host: false, client: false, id: 0, started: false, ch: 1, seed: 0, roster: [], found: new Map(), hits: [], bhits: [], bcons: [], burns: [],
      ev: new Map(), killed: [], snapT: 0, stT: 0, lastSnap: 0, hzCancel: [], fxIn: [], eMap: new Map(), bMap: new Map(), hMap: new Map(), pMap: new Map(), wipeT: 0, info: null, joining: null, scanT: 0, meltOut: [], driftHits: [], c4: null, applyMelt: false, rdy: false, goAt: 0, setKey: undefined });
    NET.peers.clear(); NET.mates.clear(); NET.paused = false;
    G.rfeathers = []; G.netRun = false;
  }
  function netHeroes() {
    const pr = loadProfile();
    return ['krilessa', 'ryzhovaya'].concat(pr.ch4Done || DEBUG || pr.admin ? ['tessa'] : []);
  }
  function netEvent(cid, e) { if (!NET.ev.has(cid)) NET.ev.set(cid, []); NET.ev.get(cid).push(e); }
  // ---------- лобби ----------
  function openMP() {
    Sound.init();
    if (NetT.oldApk) { toast('📲 Игра вместе появится после обновления приложения (APK)'); return; }
    if (!NET.on) netReset();
    const pr = loadProfile(), mp = pr.mp || {};
    NET.name = mp.name || HEROES[mp.hero || 'krilessa'].name;
    NET.hero = netHeroes().includes(mp.hero) ? mp.hero : 'krilessa';
    $('mpName').value = NET.name;
    mpRender();
    setState('mp');
  }
  function mpSavePrefs() {
    const pr = loadProfile(); pr.mp = { name: NET.name, hero: NET.hero }; saveProfile(pr);
  }
  function mpRender() {
    const box = $('mpHero'); box.innerHTML = '';
    for (const id of netHeroes()) {
      const b = document.createElement('button'); b.className = 'mpHc' + (id === NET.hero ? ' on' : '');
      const img = heroAvatar(id); b.innerHTML = `<span class="av"></span><b>${HEROES[id].name}</b>`;
      if (img) { const cv = document.createElement('canvas'); cv.width = 64; cv.height = 64; cv.getContext('2d').drawImage(img, 0, 0, 64, 64); b.querySelector('.av').appendChild(cv); }
      b.addEventListener('click', () => {
        if (NET.started) return;
        if (NET.hero !== id) NET.rdy = false; // сменила героиню – готовность заново
        NET.hero = id; mpSavePrefs(); Sound.sfx.click(); mpRender();
        if (NET.client) NetT.send(0, { t: 'me', name: NET.name, hero: NET.hero });
        if (NET.host) mpLobbyBroadcast();
      });
      box.appendChild(b);
    }
    const inLobby = NET.host || NET.client;
    $('mpStart').classList.toggle('hidden', inLobby || !!NET.scanning);
    $('mpFound').classList.toggle('hidden', !NET.scanning || inLobby);
    $('mpLobby').classList.toggle('hidden', !inLobby);
    $('mpHint').classList.toggle('hidden', inLobby);
    if (NET.scanning && !inLobby) {
      const fl = $('mpList'); fl.innerHTML = '';
      const list = [...NET.found.values()].filter(g => performance.now() - g.at < 4500);
      if (!list.length) fl.innerHTML = '<div class="mpNone">Ищу игры рядом… 📡<br><small>Хозяин должен нажать «Создать игру» в той же сети Wi-Fi</small></div>';
      for (const g of list) {
        const b = document.createElement('button'); b.className = 'btn mpGame';
        b.innerHTML = `🏠 <b>${escHtml(g.name)}</b><small>${escHtml(g.desc)}</small>`;
        b.addEventListener('click', () => mpJoin(g.ip, g.port));
        fl.appendChild(b);
      }
    }
    if (inLobby) {
      const pl = $('mpPlayers'); pl.innerHTML = '';
      for (const r of NET.roster) {
        const d = document.createElement('div'); d.className = 'mpP';
        const cd = cleanCard(r.cd);
        d.innerHTML = `<i style="background:${mateCol(r.id)}"></i>${cd ? avatarHtml(cd, 30) : ''}<b>${escHtml(r.name)}</b><span>${cd ? escHtml(titleText(cd.ti, rankOf(cd.f))) + ' · ' : ''}${HEROES[r.hero] ? HEROES[r.hero].name : ''}${r.id === 1 ? ' · хозяин' : ''}${r.id === NET.id ? ' · ты' : ''}</span>${NET.roster.length > 1 ? `<em class="${r.rd ? 'rd' : ''}">${r.rd ? '✅' : '⏳'}</em>` : ''}`;
        if (NET.host && r.id !== 1) { const kb = document.createElement('button'); kb.className = 'mpKick'; kb.textContent = '✕'; kb.title = 'Исключить'; kickBtn(kb, r.id, '✕'); d.appendChild(kb); }
        pl.appendChild(d);
      }
      if (NET.roster.length < NET_MAX) { const d = document.createElement('div'); d.className = 'mpP empty'; const fr = NET_MAX - NET.roster.length; d.innerHTML = `${'<i class="slot"></i>'.repeat(fr)}<span>${fr === 1 ? 'ещё одно место' : `ещё ${fr} места`} – подруги найдут игру сами</span>`; pl.appendChild(d); }
      $('mpCount').textContent = `${NET.roster.length}/${NET_MAX}`;
      { const isCh = typeof NET.ch === 'number', pr0 = loadProfile(), can = NET.host && !NET.started && isCh && (pr0['ch' + NET.ch + 'Done'] || DEBUG || pr0.admin), ms = (NET.mut || []).filter(id => MUT_BY[id]);
        const mb = $('mpMut'); mb.classList.toggle('hidden', !isCh || (!can && !ms.length)); mb.disabled = !can;
        mb.innerHTML = `🧪 Мутаторы: ${ms.length ? ms.map(id => MUT_BY[id].ic).join(' ') + ` <small>(${ms.length})</small>` : '<small>нет</small>'}` + (can ? '' : ms.length ? ' <small>– выбрала хозяйка</small>' : '');
        mb.classList.toggle('on', ms.length > 0); }
      $('mpAddr').innerHTML = NET.host ? (NET.ips && NET.ips.length ? `Друзья найдут игру сами. Если нет – адрес: <b>${NET.ips.join(' / ')}</b>` : 'Друзья найдут игру в списке «Найти игру»') : `Ты в игре у <b>${escHtml((NET.roster[0] || {}).name || 'хозяина')}</b>`;
      $('mpChs').classList.toggle('hidden', !NET.host);
      { const sv = NET.host && !NET.started ? coopLoad(COOP_KEY) : null, rb = $('mpResume');
        rb.classList.toggle('hidden', !sv || !CHAPTERS[sv && sv.ch]);
        if (sv && CHAPTERS[sv.ch]) { const done = (sv.defeated || []).filter(Boolean).length, nb = CHAPTERS[sv.ch].bosses.length;
          rb.innerHTML = `💾 Продолжить: глава ${sv.ch} · стражи ${done}/${nb} · ур. ${sv.level}` + (sv.names && sv.names.length ? `<br><small>с ${escHtml(sv.names.join(', '))}</small>` : '');
          rb.classList.toggle('on', !!NET.resume); } }
      if (NET.host) {
        const cb = $('mpChs'); cb.innerHTML = '';
        for (const n of CH_NUMS) {
          if (!chapterOpen(n)) continue;
          const b = document.createElement('button'); b.className = 'mpCh' + (n === NET.ch ? ' on' : '');
          b.textContent = (CH_META[n] ? CH_META[n].ic + ' ' : '') + n;
          b.title = CHAPTERS[n].name;
          b.addEventListener('click', () => { NET.ch = n; NET.resume = null; Sound.sfx.click(); mpRender(); mpLobbyBroadcast(); });
          cb.appendChild(b);
        }
        const prR = loadProfile();
        if (prR.ch1Done || DEBUG || prR.admin) { // босс-раш вдвоём или вчетвером
          const b = document.createElement('button'); b.className = 'mpCh' + (NET.ch === 'rush' ? ' on' : ''); b.textContent = '⚔️ Раш';
          b.addEventListener('click', () => { NET.ch = 'rush'; Sound.sfx.click(); mpRender(); mpLobbyBroadcast(); });
          cb.appendChild(b);
          const bd = document.createElement('button'); bd.className = 'mpCh' + (NET.ch === 'defense' ? ' on' : ''); bd.textContent = '🛡️ Оборона'; // защищать кристалл вместе
          bd.addEventListener('click', () => { NET.ch = 'defense'; Sound.sfx.click(); mpRender(); mpLobbyBroadcast(); });
          cb.appendChild(bd);
          if (NET.ch === 'defense') { // карту обороны выбирает хозяйка
            if (!TD_MAP_BY[NET.dmap] || !tdMapOpen(TD_MAP_BY[NET.dmap], prR)) NET.dmap = tdMapPick(prR).id;
            for (const M of TD_MAPS) {
              if (!tdMapOpen(M, prR)) continue;
              const bm = document.createElement('button'); bm.className = 'mpCh' + (NET.dmap === M.id ? ' on' : ''); bm.textContent = M.ic; bm.title = M.nm;
              bm.addEventListener('click', () => { NET.dmap = M.id; Sound.sfx.click(); mpRender(); mpLobbyBroadcast(); });
              cb.appendChild(bm);
            }
          }
        }
      }
      const chName = (SECRET_CARDS[NET.ch] && SECRET_CARDS[NET.ch].title) || (CHAPTERS[NET.ch] || {}).name || '';
      $('mpChName').textContent = NET.ch === 'rush' ? '⚔️ Босс-раш вместе' : NET.ch === 'defense' ? `🛡️ Оборона вместе · ${(TD_MAP_BY[NET.dmap] || TD_MAPS[0]).ic} ${(TD_MAP_BY[NET.dmap] || TD_MAPS[0]).nm}` : `Глава ${NET.ch} · ${chName}`;
      const multi = NET.roster.length > 1 && !NET.started; // вдвоём и больше – старт, только когда готовы все
      $('mpGo').classList.toggle('hidden', !NET.host || multi);
      $('mpGo').textContent = '▶ Начать (подруги могут зайти позже)';
      const rb = $('mpReady'); rb.classList.toggle('hidden', !multi); rb.classList.toggle('on', !!NET.rdy);
      rb.textContent = NET.rdy ? '✅ Готова! (нажми, чтобы отменить)' : '✋ Я готова';
      $('mpWait').classList.toggle('hidden', !(NET.client || multi));
      mpWaitText();
    }
  }
  function mpWaitText() {
    const el = $('mpWait'), n = NET.roster.filter(r => r.rd).length, all = NET.roster.length;
    const tx = NET.goAt ? `🚀 Все готовы! Старт через ${Math.max(1, Math.ceil((NET.goAt - performance.now()) / 1000))}…`
      : all > 1 ? `Готовы ${n} из ${all} – игра начнётся, когда нажмут все` : '⏳ Ждём, когда хозяйка начнёт…';
    if (el.textContent !== tx) el.textContent = tx;
  }
  function mpToggleReady() {
    if (NET.started || !(NET.host || NET.client)) return;
    NET.rdy = !NET.rdy; Sound.sfx.click();
    const me = NET.roster.find(r => r.id === (NET.host ? 1 : NET.id)); if (me) me.rd = NET.rdy;
    if (NET.client) NetT.send(0, { t: 'rdy', v: NET.rdy ? 1 : 0 }); else mpLobbyBroadcast();
    mpRender();
  }
  const escHtml = s => String(s).replace(/[&<>"]/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[ch]));
  function mpName() { NET.name = ($('mpName').value || '').trim().slice(0, 14) || HEROES[NET.hero].name; mpSavePrefs(); return NET.name; }
  function mpHost() {
    mpName();
    const r = NetT.host(mpBeacon());
    if (!r || !r.ok) { toast('Не получилось создать игру 😿 Проверь Wi-Fi'); return; }
    NET.on = true; NET.host = true; NET.id = 1; NET.ips = r.ips || NetT.ips();
    if (!chapterOpen(NET.ch)) NET.ch = 1;
    { const pr = loadProfile(); if (pr.lastCh && chapterOpen(pr.lastCh)) NET.ch = pr.lastCh; }
    NET.card = myCard();
    NET.roster = [{ id: 1, name: NET.name, hero: NET.hero, cd: NET.card }]; netLooks();
    Sound.sfx.magic(); mpRender();
  }
  // имя и описание через «|»: Android-маячок заменяет табуляции пробелами
  function mpBeacon() { return `${String(NET.name).replace(/[|\t\n]/g, ' ')}|${NET.ch === 'rush' ? 'босс-раш' : NET.ch === 'defense' ? 'оборона' : 'глава ' + NET.ch} · игроков ${Math.max(1, NET.roster.length)}/${NET_MAX}`; }
  function mpLobbyBroadcast() {
    if (!NET.host) return;
    NET.card = Object.assign(NET.card || myCard(), { nm: NET.name, at: Date.now() });
    const setKey = `${NET.ch}|${NET.dmap || ''}|${(NET.mut || []).join(',')}`; // хозяйка поменяла главу или карту – все заново жмут «Готова»
    if (NET.setKey !== undefined && NET.setKey !== setKey) { NET.rdy = false; for (const m of NET.peers.values()) m.rd = false; }
    NET.setKey = setKey;
    NET.roster = [{ id: 1, name: NET.name, hero: NET.hero, cd: NET.card, rd: !!NET.rdy }].concat([...NET.peers.values()].map(m => ({ id: m.id, name: m.name, hero: m.hero, cd: m.cd || null, rd: !!m.rd })));
    // все готовы – через 3 секунды старт; кто-то передумал или зашла новая подруга – отсчёт сбрасывается
    const all = !NET.started && NET.roster.length > 1 && NET.roster.every(r => r.rd);
    if (all && !NET.goAt) { NET.goAt = performance.now() + 3000; Sound.sfx.superReady(); }
    else if (!all) NET.goAt = 0;
    netLooks();
    NetT.info(mpBeacon());
    NetT.send(-1, { t: 'lobby', roster: NET.roster, ch: NET.ch, dm: NET.dmap || '', mut: typeof NET.ch === 'number' ? NET.mut || [] : [], started: NET.started, go: NET.goAt ? Math.max(0.1, (NET.goAt - performance.now()) / 1000) : 0 });
    if (state === 'mp') mpRender();
  }
  function mpScan() {
    mpName();
    NET.scanning = true; NET.found.clear();
    NetT.scan(true); Sound.sfx.click(); mpRender();
  }
  function mpJoin(ip, port) {
    NetT.scan(false); NET.scanning = false;
    NET.on = true; NET.client = true; NET.id = 0; NET.joining = { ip, port, t: performance.now() };
    NetT.join(ip, port);
    toast('Подключаюсь…'); mpRender();
  }
  function mpLeave(silent) {
    if (NET.host && NET.on) NetT.send(-1, { t: 'end' });
    if (NET.client && NET.on) NetT.send(0, { t: 'bye' });
    NetT.scan(false);
    setTimeout(() => NetT.close(), 120);
    const wasRun = G.netRun;
    netReset();
    if (!silent && state === 'mp') mpRender();
    return wasRun;
  }
  function mpGo() {
    if (!NET.host) return;
    NET.goAt = 0; NET.rdy = false; for (const m of NET.peers.values()) m.rd = false; // к следующему разу – готовность заново
    NET.started = true; NET.seed = 1 + Math.floor(Math.random() * 2e9);
    const RS = NET.resume && typeof NET.ch === 'number' && NET.resume.ch === NET.ch ? NET.resume : null;
    NET.coopId = RS ? RS.id : 'c' + Date.now().toString(36); NET.resumeRun = RS;
    if (RS) { NET.seed = RS.seed; NET.res = { df: RS.defeated, ml: RS.ml, cp: RS.cp, ch: RS.chests }; } else NET.res = null;
    NET.rush = NET.ch === 'rush' ? rushPool() : null;
    if (NET.ch === 'defense' && !TD_MAP_BY[NET.dmap]) NET.dmap = tdMapPick(loadProfile()).id;
    const diff = (loadProfile().settings || {}).diff || 'normal';
    NET.diff = RS && RS.diff ? RS.diff : diff;
    mpLobbyBroadcast();
    NetT.send(-1, netStartMsg());
    netBegin();
    if (RS) { coopApplyWorld(NET.res); coopApplyMine(RS); G.kills = RS.kills || 0; G.time = RS.time || 0; G.keys = RS.keys || 0; showBanner('💾 Продолжаем вместе!', `Стражей побеждено: ${guardiansDone()}/${guardiansCount()}`); }
    NET.resume = null;
  }
  function netStartMsg() { return { t: 'start', mut: typeof NET.ch === 'number' ? NET.mut || [] : [], cid: NET.coopId, res: NET.res || null, dm: NET.dmap || '', ch: NET.ch, seed: NET.seed, diff: NET.diff, roster: NET.roster, df: G.netRun ? G.defeated : null, gate: G.netRun ? gateOpen : false, ml: G.netRun ? G.melted : [], rk: NET.rush ? NET.rush.kinds : null, rl: NET.rush ? NET.rush.levels : null }; }
  // ---------- начало главы вместе ----------
  function netBegin() {
    G.netRun = true;
    const idx = Math.max(0, NET.roster.findIndex(r => r.id === NET.id));
    G.mutNext = typeof NET.ch === 'number' && NET.mut && NET.mut.length ? NET.mut.slice() : null; G.dailyNext = null; // мутаторы выбирает хозяйка
    if (NET.ch === 'rush') startRush(NET.rush); else if (NET.ch === 'defense') startDefense(); else newChapter(NET.ch, NET.seed);
    G.diffId = NET.diff || G.diffId; G.diff = DIFFS[G.diffId] || DIFFS.normal;
    // стартуем кружком, чтобы не стоять друг в друге
    const a = idx * TAU / NET_MAX; P.x += Math.cos(a) * 26 * (idx ? 1 : 0); P.y += Math.sin(a) * 26 * (idx ? 1 : 0); ensureWalkable(P);
    showBanner(NET.ch === 'rush' ? '⚔️ Раш · вместе' : NET.ch === 'defense' ? '🛡️ Оборона · вместе' : `Глава ${NET.ch} · вместе`, NET.roster.map(r => r.name).join(' · '));
    if (NET.client) { G.tessaAlly = null; G.enemies = []; }
  }
  // ---------- приём сообщений ----------
  function netRecv() {
    for (const [type, cid, data] of NetT.poll()) {
      if (type === 'found') {
        const [ip, port, ...rest] = data.split('\t'), info = rest.join(' '), bar = info.indexOf('|');
        const name = bar >= 0 ? info.slice(0, bar) : info, desc = bar >= 0 ? info.slice(bar + 1) : '';
        NET.found.set(ip, { ip, port: +port || 0, name: name || 'Игра', desc, at: performance.now() });
        continue;
      }
      if (type === 'open') { NET.card = myCard(); NetT.send(0, { t: 'hello', v: VERSION, name: NET.name, hero: NET.hero, cd: NET.card }); continue; }
      if (type === 'fail') { if (NET.client) { toast('Не получилось подключиться 😿'); netReset(); if (state === 'mp') mpRender(); } continue; }
      if (type === 'closed') { netLost('Связь с хозяином пропала'); continue; }
      if (type === 'conn') continue; // ждём «hello»
      if (type === 'drop') { netDrop(cid); continue; }
      if (type !== 'msg') continue;
      let m; try { m = JSON.parse(data); } catch (e) { continue; }
      if (NET.host) netHostMsg(cid, m); else if (NET.client) netClientMsg(m);
    }
  }
  function netLost(msg) {
    const run = G.netRun;
    netReset(); NetT.close();
    toast('📡 ' + msg);
    if (run) openMenu(); else if (state === 'mp') mpRender();
  }
  // хозяин может исключить игрока: в лобби (✕ у имени) и в игре (на паузе); до конца сессии он не вернётся
  function mpKick(cid) {
    const m = NET.peers.get(cid); if (!NET.host || !m) return;
    m.kicked = true; NET.kickedNames = NET.kickedNames || new Set(); NET.kickedNames.add(m.name);
    NetT.send(cid, { t: 'kick' }); setTimeout(() => NetT.kick(cid), 300);
    netDrop(cid); toast(`🚪 ${m.name} исключена из игры`);
    if (state === 'pause') kickListSync();
  }
  function kickBtn(b, cid, label) { // первое нажатие спрашивает «Точно?», второе – исключает
    b.addEventListener('click', e => {
      e.stopPropagation(); Sound.sfx.click();
      if (b._sure) { mpKick(cid); return; }
      b._sure = true; b.textContent = 'Точно?'; b.classList.add('sure');
      setTimeout(() => { b._sure = false; b.textContent = label; b.classList.remove('sure'); }, 2500);
    });
  }
  function kickListSync() {
    const box = $('pauseKick'); if (!box) return; box.innerHTML = '';
    const on = NET.host && G.netRun && NET.peers.size > 0; box.classList.toggle('hidden', !on); if (!on) return;
    const t = document.createElement('div'); t.className = 'pkT'; t.textContent = 'Игроки'; box.appendChild(t);
    for (const [cid, m] of NET.peers) { const b = document.createElement('button'); b.className = 'btn gray pkB'; const lb = `🚪 Исключить ${m.name}`; b.textContent = lb; kickBtn(b, cid, lb); box.appendChild(b); }
  }
  function netDrop(cid) {
    const m = NET.peers.get(cid); if (!m) return;
    NET.peers.delete(cid); NET.mates.delete(cid);
    if (G.netRun && !m.kicked) toast(`👋 ${m.name} вышла из игры`);
    mpLobbyBroadcast();
  }
  function netHostMsg(cid, m) {
    if (m.t === 'hello') {
      if (m.v !== VERSION) { NetT.send(cid, { t: 'no', why: 'ver', v: VERSION }); setTimeout(() => NetT.kick(cid), 300); return; }
      if (NET.kickedNames && NET.kickedNames.has(String(m.name || 'Гость').slice(0, 14))) { NetT.send(cid, { t: 'no', why: 'kick' }); setTimeout(() => NetT.kick(cid), 300); return; }
      if (NET.peers.size >= NET_MAX - 1) { NetT.send(cid, { t: 'no', why: 'full' }); setTimeout(() => NetT.kick(cid), 300); return; }
      const mate = { id: cid, cd: cleanCard(m.cd), name: String(m.name || 'Гость').slice(0, 14), hero: HEROES[m.hero] ? m.hero : 'krilessa', x: P.x, y: P.y, tx: P.x, ty: P.y, face: 1, t: 0, r: 14, hp: 1, mh: 1, live: false, down: false, inv: false, mag: 110 };
      NET.peers.set(cid, mate); NET.mates.set(cid, mate);
      NetT.send(cid, { t: 'hi', id: cid, v: VERSION });
      mpLobbyBroadcast();
      if (NET.started) { NetT.send(cid, netStartMsg()); if (G.netRun) toast(`🎉 ${mate.name} присоединилась!`); }
      return;
    }
    const mate = NET.peers.get(cid); if (!mate) return;
    if (m.t === 'rdy') { mate.rd = !!m.v; mpLobbyBroadcast(); return; } // подруга нажала «Готова»
    if (m.t === 'me') { mate.name = String(m.name || mate.name).slice(0, 14); if (HEROES[m.hero] && m.hero !== mate.hero) mate.rd = false; if (HEROES[m.hero]) mate.hero = m.hero; if (m.cd) mate.cd = cleanCard(m.cd); mpLobbyBroadcast(); return; }
    if (m.t === 'bye') { NetT.kick(cid); netDrop(cid); return; }
    if (m.t === 'pz') { const by = mate.name || 'Игрок'; netPauseApply(m.v, by); NetT.send(-1, { t: 'pz', v: m.v ? 1 : 0, by }); return; }
    if (m.t === 'bd') { if (defOn() && 'buscm'.includes(String(m.a))) tdDo(String(m.a), +m.s || 0, m.a === 'b' ? String(m.k) : m.a === 'm' ? m.k : +m.k || 0, cid); return; } // подруга строит, улучшает или зовёт волну
    if (m.t === 'st') {
      mate.tx = m.x; mate.ty = m.y; if (!mate.live) { mate.x = m.x; mate.y = m.y; mate.live = true; }
      mate.face = m.f; mate.mv = !!m.m; mate.dash = !!m.d; mate.inv = !!m.i; mate.down = !!m.dn; mate.hp = m.hp; mate.mh = m.mh || 1; mate.mag = m.mg || 110; mate.z = m.z || 0;
      if (HEROES[m.h]) mate.hero = m.h;
      mate.away = !!m.aw; mate.seen = performance.now(); mate.rp = +m.rp || 0; mate.ar = +m.ar || 0;
      if (m.fe && m.fe.length) NET.fxIn.push([cid, m.fe]);
      if (m.hi && m.hi.length) {
        const byId = new Map(); for (const e of G.enemies) byId.set(e.nid, e);
        for (const [nid, v, crit, kx, ky, slow] of m.hi) {
          const e = byId.get(nid); if (!e || e.dead) continue;
          NET.hitBy = cid; damageEnemy(e, { v: +v || 0, crit: !!crit }, +kx || 0, +ky || 0, false); NET.hitBy = 0;
          if (slow && !e.dead) e.slowT = Math.max(e.slowT, +slow);
        }
      }
      if (m.bu && m.bu.length) { const byId = new Map(); for (const e of G.enemies) byId.set(e.nid, e); for (const [nid, dps] of m.bu) { const e = byId.get(nid); if (e && !e.dead) { e.burnT = 2; e.burnDps = Math.max(e.burnDps || 0, +dps || 0); e.burnTick = e.burnTick || 0.4; } } }
      if (m.bh && m.bh.length) for (const [bi, v, crit, dot] of m.bh) { const b = bosses[bi]; if (b) { NET.hitBy = cid; damageBoss(b, { v: +v || 0, crit: !!crit }, !!dot, true); NET.hitBy = 0; } }
      if (m.bc && m.bc.length) { const s = new Set(m.bc); for (const b of G.ebullets) if (s.has(b.nid)) b.life = 0; }
      if (m.pl !== undefined && pearls[m.pl] && !pearls[m.pl].got) netPearl(m.pl, cid);
      if (m.ml && m.ml.length) for (const i of m.ml) meltTile(i, true); // растопила подруга
      if (m.dh && m.dh.length) for (const [k, v] of m.dh) { const dr = drifts[k]; if (dr && !dr.done) { dr.hp -= +v || 0; burst(dr.x, dr.y, 10, '#ffffff', 120); if (dr.hp <= 0) openDrift(dr); } }
      mate.hidden = !!m.hd;
      if (m.rv) { if (m.rv === 1) life('revives'); else netEvent(m.rv, ['rv']); }
      return;
    }
  }
  function netClientMsg(m) {
    if (m.t === 'hi') { NET.id = m.id; NET.joining = null; toast('✅ Подключено!'); Sound.sfx.superReady(); if (state === 'mp') mpRender(); return; }
    if (m.t === 'no') {
      toast(m.why === 'ver' ? `У хозяина другая версия игры (v${m.v}). Обновитесь до одной версии` : m.why === 'full' ? 'В игре уже 4 игрока 😿' : m.why === 'kick' ? 'Хозяин исключил тебя из этой игры 🚪' : 'Хозяин не пустил');
      netReset(); NetT.close(); if (state === 'mp') mpRender(); return;
    }
    if (m.t === 'lobby') {
      NET.roster = m.roster || []; NET.ch = m.ch || 1; NET.dmap = m.dm || NET.dmap; NET.mut = (m.mut || []).filter(id => MUT_BY[id]); netLooks();
      const me = NET.roster.find(r => r.id === NET.id); if (me) NET.rdy = !!me.rd; // хозяйка могла сбросить готовность
      const was = NET.goAt; NET.goAt = m.go ? performance.now() + m.go * 1000 : 0; if (NET.goAt && !was) Sound.sfx.superReady();
      if (state === 'mp') mpRender(); return;
    }
    if (m.t === 'start') {
      NET.ch = m.ch; NET.dmap = m.dm || NET.dmap; NET.seed = m.seed; NET.diff = m.diff; NET.mut = (m.mut || []).filter(id => MUT_BY[id]); NET.roster = m.roster || NET.roster; NET.started = true; netLooks();
      NET.rush = m.rk ? { kinds: m.rk, levels: m.rl } : null;
      NET.coopId = m.cid || null;
      netBegin();
      if (m.df) G.defeated = m.df.slice();
      if (m.res) { coopApplyWorld(m.res); const me = coopLoad(COOP_ME); if (me && me.id === m.cid) coopApplyMine(me); showBanner('💾 Продолжаем вместе!', `Стражей побеждено: ${guardiansDone()}/${guardiansCount()}`); }
      if (m.ml && m.ml.length) { NET.applyMelt = true; for (const i of m.ml) meltTile(i, false); NET.applyMelt = false; }
      return;
    }
    if (m.t === 'end') { netLost('Хозяин закончил игру'); return; }
    if (m.t === 'kick') { netLost('Хозяин исключил тебя из игры'); return; }
    if (m.t === 'pz') { netPauseApply(m.v, String(m.by || 'Игрок').slice(0, 14)); return; }
    if (!G.netRun) return;
    if (m.t === 's') { netApply(m); return; }
    if (m.t === 'x') { for (const ev of m.x || []) netMyEvent(ev); return; }
    if (m.t === 'ml') { NET.applyMelt = true; for (const i of m.ml || []) meltTile(i, true); NET.applyMelt = false; return; }
    if (m.t === 'hc') { for (const id of m.hc || []) { const h = NET.hMap.get(id); if (h) h.cancel = true; } return; }
    if (m.t === 'rs') { netRespawnMe(m.x, m.y); return; }
    if (m.t === 'vic') { if (!G.cutscene) startVictoryCutscene(); return; }
    if (m.t === 'say') { say(m.text, m.d || 4); return; }
    if (m.t === 'spk') { speak(m.k, m.text, m.d || undefined, false); return; }
    if (m.t === 'tr') { // хозяйка (или подруга) начала испытание – все на арену
      const sh = shrines[m.si]; if (sh) { sh.state = 'active'; G.activeShrine = sh; }
      NET.trialRet = { x: m.rx, y: m.ry }; NET.trialT = 0;
      const i = Math.max(1, NET.roster.findIndex(r => r.id === NET.id)), a = i * TAU / NET_MAX;
      burst(P.x, P.y, 30, '#ffffff', 240);
      P.x = m.x + Math.cos(a) * 44; P.y = m.y + Math.sin(a) * 44; ensureWalkable(P); P.inv = Math.max(P.inv, 1.2); P.dashT = 0; P.vx = 0; P.vy = 0;
      G.ebullets = []; G.hazards = []; NET.bMap.clear();
      showBanner('⛩ ' + (m.a || 'Испытание'), 'Все на арену! Победите всех – и вернётесь с наградой');
      Sound.sfx.blink(); Sound.music('boss'); G.shake = 10;
      return;
    }
    if (m.t === 'trx') { netTrialBack(m.x, m.y, !!m.ok); return; }
    if (m.t === 'dend') { const A = G.abyss; if (!A || !A.def || A.done) return; A.wave = (m.wave || 0) + 1; A.t = m.time || A.t; if (G.core) G.core.hp = +m.hp || 0; defFinish(); defEndScreen(); return; }
    if (m.t === 'rend') { if (!G.rush) return; Object.assign(G.rush, { idx: m.n, total: m.total, t: m.time }); rushFinish(!!m.win); if (!m.win) playerDied(); return; }
    if (m.t === 'c4') { NET.c4 = m.ch; if (G.cutscene && G.victoryShown && state !== 'victory') finishCh4(m.ch); return; }
    if (m.t === 'ban') { showBanner(m.a, m.b || ''); return; }
  }
  // ---------- хозяин: снимки мира ----------
  function netHostTick(dt) {
    for (const m of NET.peers.values()) {
      if (!m.live) continue;
      const k = Math.min(1, dt * 16); m.x += (m.tx - m.x) * k; m.y += (m.ty - m.y) * k; m.t += dt;
      if (performance.now() - m.seen > 6000 && !m.lost) { m.lost = true; toast(`📡 ${m.name}: плохая связь…`); }
      if (performance.now() - m.seen < 2000) m.lost = false;
    }
    netTeamWipe(dt);
    for (const m of NET.peers.values()) { // костры зажигает и подруга – тут все и возродятся
      if (!m.live || m.down) continue;
      for (const f of fires) if (Math.hypot(f.x - m.x, f.y - m.y) < 95 && !G.activeBoss && (G.cp.x !== f.x || G.cp.y !== f.y + 34)) { G.cp = { x: f.x, y: f.y + 34 }; if (!f.lit) { f.lit = true; floatText(f.x, f.y - 40, '🔥 Костёр зажжён', '#ffd25a', true); } }
    }
    NET.snapT -= dt;
    if (NET.snapT > 0 || !G.netRun) return;
    NET.snapT = NET_SNAP;
    for (const e of G.enemies) if (!e.nid) e.nid = ++NET.uid;
    for (const b of G.ebullets) if (!b.nid) b.nid = ++NET.uid;
    for (const p of G.pickups) if (!p.nid) p.nid = ++NET.uid;
    for (const h of G.hazards) if (!h.nid) h.nid = ++NET.uid;
    // новые выстрелы хозяйки и Тессы-помощницы
    const myFx = [];
    for (const f of G.feathers) if (!f._n) { f._n = 1; myFx.push([f.x | 0, f.y | 0, f.vx | 0, f.vy | 0, Math.max(0, FK.indexOf(f.kind)), Math.round((f.life || 0.6) * 100)]); }
    const mates = [[1, P.x | 0, P.y | 0, P.face, (P.moving ? 1 : 0) | (P.dashT > 0 ? 2 : 0) | (P.inv > 0 ? 4 : 0) | (P.down ? 8 : 0) | (state !== 'play' ? 16 : 0), P.hero, Math.round(P.hp / P.maxHp * 100), (P.z || 0) | 0, P.down ? Math.round(clamp(P.revT / 2.6, 0, 1) * 100) : 0, P.down && G.td ? Math.ceil(P.tdRev || 0) : 0]];
    for (const m of NET.peers.values()) if (m.live) mates.push([m.id, m.tx | 0, m.ty | 0, m.face, (m.mv ? 1 : 0) | (m.dash ? 2 : 0) | (m.inv ? 4 : 0) | (m.down ? 8 : 0) | (m.away ? 16 : 0), m.hero, Math.round(m.hp / Math.max(1, m.mh) * 100), m.z | 0, m.rp || 0, m.ar || 0]);
    const bo = bosses.map(b => [b.state === 'fight' ? 1 : b.state === 'dead' ? 2 : 0, b.x | 0, b.y | 0, (b.z || 0) | 0, Math.max(0, Math.round(b.hp / b.maxHp * 1000)), b.stage || 0, b.mode || '', Math.round((b.look || 0) * 100), Math.round((b.alpha === undefined ? 1 : b.alpha) * 100),
      (b.inv ? 1 : 0) | (b.shield ? 2 : 0) | (b.charging ? 4 : 0) | (b.stunT > 0 ? 8 : 0) | (b.flash > 0 ? 16 : 0), b.mpX || 1, Math.round(b.maxHp)]);
    // разовые события – отдельными надёжными сообщениями (снимки мира могут заменять друг друга)
    for (const [cid, list] of NET.ev) if (list.length && NET.peers.has(cid)) NetT.send(cid, { t: 'x', x: list });
    if (NET.meltOut.length) NetT.send(-1, { t: 'ml', ml: NET.meltOut });
    if (NET.hzCancel.length) NetT.send(-1, { t: 'hc', hc: NET.hzCancel });
    const common = { t: 's', sd: SEED, cn: CHN, tm: Math.round(G.time * 10), lv: [P.level, Math.round(P.xp), P.xpNext], bo, ab: G.activeBoss ? bosses.indexOf(G.activeBoss) : -1,
      df: G.defeated.map(v => v ? 1 : 0), g: gateOpen ? 1 : 0, al: G.tessaAlly ? [G.tessaAlly.x | 0, G.tessaAlly.y | 0, G.tessaAlly.face || 1] : 0,
      kl: NET.killed, ev: G.ev ? [G.ev.def.id, Math.round(G.ev.t * 10), (G.ev.tx || 0) | 0, (G.ev.ty || 0) | 0, G.ev.goal || 0, G.ev.kills || 0, G.ev.thief ? G.ev.thief.nid || 0 : 0] : 0, ch: chests.map(c => c.open ? 1 : 0).join(''), pr: pearls.map(q => q.got ? 1 : 0).join(''),
      bm: G.beams.map(bm => [bosses.indexOf(bm.b), Math.round(bm.ang * 1000), Math.round((bm.rot || 0) * 1000), Math.round(bm.t * 100), Math.round(bm.warm * 100), Math.round(bm.dur * 100), bm.w, Math.round(bm.dmg), bm.mouth ? 1 : 0]),
      nv: G.nextEv ? G.nextEv.id : 0, et: Math.round((G.evT || 0) * 10),
      cf: clues.map(q => q.found ? 1 : 0).join(''), c5: G.clues5, fl: fires.map(q => q.lit ? 1 : 0).join(''), dr: drifts.map(q => q.done ? 1 : 0).join(''),
      sh: shrines.map(q => q.state === 'done' ? 'd' : q.state === 'active' ? 'a' : 'i').join(''), wx: [G.wxId || '', Math.round((G.blizzardT || 0) * 10), Math.round((G.wxT || 0) * 10)], ac: G.accused ? 1 : 0, ko: G.keys || 0, ru: G.rush ? [G.rush.idx, G.rush.total, Math.round(G.rush.t * 10)] : 0, dz: defOn() ? defSnap() : 0 };
    for (const m of NET.peers.values()) {
      const R2 = NET_AOI * NET_AOI, near = (x, y) => (x - m.tx) ** 2 + (y - m.ty) ** 2 < R2;
      const e = [], b = [], p = [], h = [];
      for (const en of G.enemies) if (!en.dead && near(en.x, en.y)) e.push([en.nid, en.type, en.x | 0, en.y | 0, Math.max(1, Math.round(en.hp / en.maxHp * 100)),
        (en.elite ? 1 : 0) | (en.spawnT > 0 ? 2 : 0) | (en.burnT > 0 ? 4 : 0) | (en.slowT > 0 ? 8 : 0) | (en.champion ? 16 : 0) | (en.charge > 0 || en.wind > 0 || en.fuse > 0 ? 32 : 0) | (en.face < 0 ? 64 : 0) | (en.thief ? 128 : 0) | (en.healing > 0 ? 256 : 0) | (en.buffT > 0 ? 512 : 0),
        Math.round((en.look || 0) * 100), en.affix || 0, Math.round(en.r)]);
      for (const bl of G.ebullets) if (bl.life > 0 && near(bl.x, bl.y)) b.push([bl.nid, bl.x | 0, bl.y | 0, bl.vx | 0, bl.vy | 0, bl.r, bl.col || '#fff', bl.emoji || 0,
        (bl.square ? 1 : 0) | (bl.saw ? 2 : 0) | (bl.bounce ? 4 : 0) | (bl.missile ? 8 : 0) | (bl.slow ? 16 : 0), Math.round(bl.life * 100), Math.round(bl.dmg), bl.hx | 0, bl.hy | 0]);
      for (const pk of G.pickups) if (near(pk.x, pk.y)) p.push([pk.nid, Math.max(0, PK.indexOf(pk.kind)), pk.x | 0, pk.y | 0, pk.sid === undefined ? -1 : pk.sid]);
      for (const hz of G.hazards) if (near(hz.x, hz.y) && !hz.cancel) { const o = {}; for (const k in hz) { const v = hz[k]; if (v !== null && typeof v === 'object' && !Array.isArray(v)) continue; if (typeof v === 'function') continue; o[k] = typeof v === 'number' ? Math.round(v * 100) / 100 : v; } h.push(o); }
      const fe = myFx.slice(); for (const [from, list] of NET.fxIn) if (from !== m.id) for (const f of list) fe.push(f);
      const msg = Object.assign({}, common, { e, b, p, h, fe, m: mates.filter(r => r[0] !== m.id) });
      NetT.send(m.id, msg);
    }
    NET.ev.clear(); NET.killed = []; NET.hzCancel = []; NET.fxIn = []; NET.meltOut = [];
  }
  // ---------- гость: применить снимок ----------
  function netProxy(r) {
    const [nid, type, x, y] = r;
    if (!ENEMIES[type]) return null;
    const bi = biomeMap[clamp(Math.floor(y / T), 0, MH - 1) * MW + clamp(Math.floor(x / T), 0, MW - 1)];
    const e = spawnEnemy(type, x, y, bi, { instant: true, minion: true });
    e.nid = nid; e.tx = x; e.ty = y; e.proxy = true;
    return e;
  }
  function netApply(s) {
    if (s.sd !== undefined && (s.sd !== SEED || s.cn !== CHN)) return; // снимок другой главы (пришёл раньше «start») – не наш
    NET.lastSnap = performance.now();
    if (s.dz && defOn()) defNetApply(s.dz); // оборона: волна, кристалл, постройки, страж
    // общий уровень команды
    const [lv, xp, xn] = s.lv;
    if (lv > P.level) { const d = lv - P.level; P.level = lv; G.pendingLv += d; computeStats(); if (state === 'play' && !G.cutscene) openLevelUp(); }
    P.xp = xp; P.xpNext = xn;
    // подруги
    const seenM = new Set();
    for (const [id, x, y, face, fl, hero, hp, z, rp, ar] of s.m) {
      seenM.add(id);
      let m = NET.mates.get(id);
      if (!m) { m = { id, x, y, t: 0, r: 14 }; NET.mates.set(id, m); }
      m.rp = rp || 0; m.ar = ar || 0; m.tx = x; m.ty = y; m.face = face; m.mv = !!(fl & 1); m.dash = !!(fl & 2); m.inv = !!(fl & 4); m.down = !!(fl & 8); m.away = !!(fl & 16); m.hero = hero; m.hpF = hp; m.z = z || 0;
      const rr = NET.roster.find(q => q.id === id); m.name = rr ? rr.name : (id === 1 ? 'Хозяйка' : 'Подруга');
    }
    for (const id of [...NET.mates.keys()]) if (!seenM.has(id)) NET.mates.delete(id);
    // мобы
    const killed = new Set((s.kl || []).map(k => k[0]));
    const seenE = new Set();
    for (const r of s.e) {
      let e = NET.eMap.get(r[0]);
      if (!e || e.dead || e.type !== r[1]) { if (e) e.dead = true; e = netProxy(r); if (!e) continue; NET.eMap.set(r[0], e); }
      seenE.add(r[0]);
      e.tx = r[2]; e.ty = r[3]; e.hp = r[4] / 100 * e.maxHp; e.netF = r[5]; e.look = r[6] / 100; e.affix = r[7] || null; e.elite = !!(r[5] & 1); e.champion = !!(r[5] & 16); e.thief = !!(r[5] & 128);
      e.spawnT = r[5] & 2 ? 0.2 : 0; e.burnT = r[5] & 4 ? 0.5 : 0; e.slowT = r[5] & 8 ? 0.5 : 0; e.healing = r[5] & 256 ? 0.3 : 0; e.buffT = r[5] & 512 ? 0.3 : 0;
      e.face = r[5] & 64 ? -1 : 1; e.r = r[8] || e.r;
      if (e.def.ai === 'exploder') e.fuse = r[5] & 32 ? 0.5 : 0; else e.charge = r[5] & 32 ? 0.3 : 0;
    }
    for (const [nid, e] of NET.eMap) {
      if (seenE.has(nid)) continue;
      if (killed.has(nid)) { burst(e.x, e.y, e.elite ? 30 : 12, e.col && e.col.startsWith('#') ? e.col : '#c77dff', 170); Sound.sfx.die(); }
      e.dead = true; NET.eMap.delete(nid);
    }
    G.enemies = G.enemies.filter(e => !e.dead);
    // вражеские снаряды
    const nb = [];
    if (NET.goneB.size > 600) NET.goneB.clear();
    for (const r of s.b) {
      if (NET.goneB.has(r[0])) continue;
      let b = NET.bMap.get(r[0]);
      if (!b) { b = { nid: r[0], rot: 0, homing: 0 }; }
      Object.assign(b, { x: r[1], y: r[2], vx: r[3], vy: r[4], spd: Math.hypot(r[3], r[4]), r: r[5], col: r[6], emoji: r[7] || null, square: !!(r[8] & 1), saw: !!(r[8] & 2), bounce: !!(r[8] & 4), missile: !!(r[8] & 8), slow: !!(r[8] & 16), life: r[9] / 100, dmg: r[10], hx: r[11], hy: r[12] });
      if (!b.gone) nb.push(b);
    }
    NET.bMap = new Map(nb.map(b => [b.nid, b])); G.ebullets = nb;
    // подбирашки – только показать (подбирает хозяин)
    const np = [];
    for (const r of s.p) { let p = NET.pMap.get(r[0]); if (!p) p = { nid: r[0], t: 0 }; p.kind = PK[r[1]] || 'xp'; p.x = r[2]; p.y = r[3]; if (r[4] >= 0) p.sid = r[4]; if (p.kind === 'xp' && !p.v) p.v = 1; np.push(p); }
    NET.pMap = new Map(np.map(p => [p.nid, p])); G.pickups = np;
    // опасные зоны: новые добавляем, свои часы у каждой зоны идут сами
    for (const o of s.h) if (!NET.hMap.has(o.nid)) { const h = Object.assign({}, o); NET.hMap.set(o.nid, h); G.hazards.push(h); }
    for (const id of s.hc || []) { const h = NET.hMap.get(id); if (h) h.cancel = true; }
    if (NET.hMap.size > 400) { const live = new Set(G.hazards.map(h => h.nid)); for (const id of [...NET.hMap.keys()]) if (!live.has(id)) NET.hMap.delete(id); }
    // боссы
    s.bo.forEach((r, i) => {
      const b = bosses[i]; if (!b) return;
      const st = r[0] === 1 ? 'fight' : r[0] === 2 ? 'dead' : 'sleep';
      if (st === 'dead' && b.state !== 'dead') { burst(b.x, b.y, 40, '#ffd25a', 260); }
      b.state = st; b.tx = r[1]; b.ty = r[2]; if (b.netSeen === undefined) { b.x = r[1]; b.y = r[2]; } b.netSeen = 1;
      if (r[11] > 1) b.maxHp = r[11]; b.mpX = r[10] || 1;
      b.z = r[3]; b.hp = r[4] / 1000 * b.maxHp; b.stage = r[5]; b.mode = r[6]; b.look = r[7] / 100; b.alpha = r[8] / 100;
      b.inv = !!(r[9] & 1); b.shield = !!(r[9] & 2); b.charging = !!(r[9] & 4); b.stunT = r[9] & 8 ? 0.3 : 0; if (r[9] & 16) b.flash = Math.max(b.flash || 0, 0.06);
    });
    G.activeBoss = s.ab >= 0 ? bosses[s.ab] : null;
    // стражи, ворота, звёзды
    s.df.forEach((v, i) => {
      if (v && !G.defeated[i]) { G.defeated[i] = true; const b = bosses[i]; if (b) { awardStar(b); b.state = 'dead'; showBanner('ПОБЕДА!', b.def.name + ' повержен'); life('bosses'); bookKill('b', b.kind); buzz(160); } }
    });
    if (s.g && !gateOpen) { gateOpen = true; say('Ворота открыты! Скорее в замок!'); }
    if (s.al) { if (!G.tessaAlly) G.tessaAlly = { x: s.al[0], y: s.al[1], face: 1, fireT: 9 }; G.tessaAlly.tx = s.al[0]; G.tessaAlly.ty = s.al[1]; G.tessaAlly.face = s.al[2]; } else G.tessaAlly = null;
    if (s.ch) for (let i = 0; i < chests.length && i < s.ch.length; i++) if (s.ch[i] === '1' && !chests[i].open) { chests[i].open = true; burst(chests[i].x, chests[i].y, 12, '#ffd25a', 140); }
    if (s.pr) for (let i = 0; i < pearls.length && i < s.pr.length; i++) if (s.pr[i] === '1' && !pearls[i].got) pearls[i].got = true;
    if (s.sh) for (let i = 0; i < shrines.length && i < s.sh.length; i++) { const v = s.sh[i] === 'd' ? 'done' : s.sh[i] === 'a' ? 'active' : 'idle'; shrines[i].state = v; if (v !== 'active' && G.activeShrine === shrines[i] && P.y <= PLAY_H * T) G.activeShrine = null; }
    // чужие выстрелы – просто картинка
    for (const f of s.fe || []) G.rfeathers.push({ x: f[0], y: f[1], vx: f[2], vy: f[3], kind: FK[f[4]] || 'feather', life: f[5] / 100 });
    if (G.rfeathers.length > 300) G.rfeathers.splice(0, G.rfeathers.length - 300);
    // лучи боссов – урон по себе считаем сами
    G.beams = (s.bm || []).map(r => ({ b: bosses[r[0]], ang: r[1] / 1000, rot: r[2] / 1000, t: r[3] / 100, warm: r[4] / 100, dur: r[5] / 100, w: r[6], dmg: r[7], mouth: !!r[8], len: 0, x: 0, y: 0 })).filter(bm => bm.b);
    // события карты
    if (s.ev) {
      const def = EVENTS.find(e => e.id === s.ev[0]);
      if (def) {
        if (!G.ev || G.ev.def !== def) { G.ev = { def, t: 0, k: 0, kills: 0 }; if (def.id === 'song') { $('songText').textContent = SONG_TEXTS[0]; $('songBanner').classList.remove('hidden'); } }
        Object.assign(G.ev, { t: s.ev[1] / 10, tx: s.ev[2], ty: s.ev[3], goal: s.ev[4], kills: s.ev[5], thief: s.ev[6] ? NET.eMap.get(s.ev[6]) || null : null });
      }
    } else if (G.ev) { if (G.ev.def.id === 'song') $('songBanner').classList.add('hidden'); G.ev = null; }
    G.nextEv = s.nv ? EVENTS.find(e => e.id === s.nv) || null : null; G.evT = (s.et || 0) / 10;
    // улики, костры, сугробы, лёд, погода
    if (s.cf) for (let i = 0; i < clues.length && i < s.cf.length; i++) clues[i].found = s.cf[i] === '1';
    if (s.c5) G.clues5 = s.c5.slice();
    if (s.fl) for (let i = 0; i < fires.length && i < s.fl.length; i++) fires[i].lit = s.fl[i] === '1';
    if (s.dr) for (let i = 0; i < drifts.length && i < s.dr.length; i++) if (s.dr[i] === '1' && !drifts[i].done) { drifts[i].done = true; burst(drifts[i].x, drifts[i].y, 30, '#ffffff', 200); Sound.sfx.glass(); }
    if (s.ml && s.ml.length) { NET.applyMelt = true; for (const i of s.ml) meltTile(i, true); NET.applyMelt = false; }
    if (s.wx) { G.wxId = s.wx[0] || null; G.blizzardT = s.wx[1] / 10; G.wxT = s.wx[2] / 10; }
    G.accused = !!s.ac; G.keys = s.ko || 0;
    if (s.ru && G.rush) { G.rush.idx = s.ru[0]; G.rush.total = s.ru[1]; G.rush.t = s.ru[2] / 10; }
    // события для меня
    if (s.x) for (const ev of s.x) netMyEvent(ev);
  }
  function netMyEvent(ev) {
    const [k, v] = ev;
    if (k === 'k') { // моя добыча
      G.kills++; addSuper(v ? 8 : 2.2); life('kills'); if (v) life('elites'); if (ev[2]) bookKill('e', ev[2]);
      if (G.st) { G.st.kills++; if (v) G.st.elites++; if (ev[2]) G.st.byType[ev[2]] = (G.st.byType[ev[2]] || 0) + 1; } // 1.0.11: у гостьи тоже считаются
      if (P.vamp && P.hp < P.maxHp) P.hp = Math.min(P.maxHp, P.hp + P.vamp);
      if (hasRelic('fang') && P.hp < P.maxHp) P.hp = Math.min(P.maxHp, P.hp + P.maxHp * 0.005 * (1 + relicLv('fang')));
    } else if (k === 'hl') {
      const h = Math.round(P.maxHp * 0.25 * (hasRelic('heartstone') ? 1.25 + 0.25 * relicLv('heartstone') : 1) * (1 + 0.2 * lv('c5snack')));
      P.hp = Math.min(P.maxHp, P.hp + h); floatText(P.x, P.y - 34, '+' + h, '#7dff7d'); Sound.sfx.heart();
    } else if (k === 'sp') { addSuper(v); floatText(P.x, P.y - 34, '⭐ +' + v + '% супера', '#ffe08a'); Sound.sfx.shard(); }
    else if (k === 'key') { floatText(P.x, P.y - 34, '🔑 +1 (общий)', '#ffd25a', true); Sound.sfx.clue(); }
    else if (k === 'gem') Sound.sfx.gem();
    else if (k === 'sh') {
      const s = SHARDS[v]; if (!s) return;
      const pb = biomeMap[clamp(Math.floor(P.y / T), 0, MH - 1) * MW + clamp(Math.floor(P.x / T), 0, MW - 1)];
      const val = s.id === 'hp' ? Math.max(3, Math.round(refEHP(zoneE(pb)) * 0.012)) : s.val;
      P.bonus[s.id] = (P.bonus[s.id] || 0) + val; P.shards++; computeStats();
      if (s.id === 'hp') P.hp = Math.min(P.maxHp, P.hp + val);
      floatText(P.x + rnd(-10, 10), P.y - 40, s.txt(val), s.col); Sound.sfx.shard();
    } else if (k === 'lvl') { G.pendingLv += v || 1; if (state === 'play') openLevelUp(); }
    else if (k === 'relic') { if (state === 'play') openRelicChoice(); }
    else if (k === 'txt') floatText(P.x, P.y - 40, v, '#ffd25a', true);
    else if (k === 'rv') life('revives');
    else if (k === 'dw') { if (defOn()) defWaveDone(v); }
    else if (k === 'rh') { P.hp = Math.min(P.maxHp, P.hp + P.maxHp * 0.5); G.pendingLv++; if (state === 'play') openLevelUp(); }
    else if (k === 'inv') { G.invertT = v; showBanner('🔄 ПЕРЕВЁРНУТО', 'Управление шиворот-навыворот!'); }
    else if (k === 'stat') G.staticT = v;
  }
  // ---------- гость: своя героиня ----------
  function netClientTick(dt) {
    if (performance.now() - NET.lastSnap > 7000 && NET.lastSnap) { netLost('Связь с хозяином пропала'); return; }
    NET.stT -= dt;
    if (NET.stT > 0) return;
    NET.stT = NET_ST;
    const fe = [];
    for (const f of G.feathers) if (!f._n) { f._n = 1; fe.push([f.x | 0, f.y | 0, f.vx | 0, f.vy | 0, Math.max(0, FK.indexOf(f.kind)), Math.round((f.life || 0.6) * 100)]); }
    for (const e of G.enemies) if (e.burnT > 1.9 && e.burnDps && !e._bs) { e._bs = 1; NET.burns.push([e.nid, Math.round(e.burnDps)]); }
    const msg = { t: 'st', x: Math.round(P.x), y: Math.round(P.y), f: P.face, m: P.moving ? 1 : 0, d: P.dashT > 0 ? 1 : 0, i: P.inv > 0 || P.dashT > 0 ? 1 : 0, h: P.hero, hp: Math.round(P.hp), mh: P.maxHp,
      dn: P.down ? 1 : 0, mg: Math.round(P.magnet || 110), z: Math.round(P.z || 0), aw: state !== 'play' ? 1 : 0,
      rp: P.down ? Math.round(clamp(P.revT / 2.6, 0, 1) * 100) : 0, ar: P.down && G.td ? Math.ceil(P.tdRev || 0) : 0 }; // как идёт подъём – видно подругам
    if (fe.length) msg.fe = fe;
    if (NET.hits.length) { msg.hi = NET.hits; NET.hits = []; }
    if (NET.bhits.length) { msg.bh = NET.bhits; NET.bhits = []; }
    if (NET.bcons.length) { msg.bc = NET.bcons; NET.bcons = []; }
    if (NET.burns.length) { msg.bu = NET.burns; NET.burns = []; }
    if (NET.pearlReq !== undefined) { msg.pl = NET.pearlReq; NET.pearlReq = undefined; }
    if (NET.meltOut.length) { msg.ml = NET.meltOut; NET.meltOut = []; }
    if (NET.driftHits.length) { msg.dh = NET.driftHits; NET.driftHits = []; }
    if (G.hidden) msg.hd = 1;
    if (NET.revBy) { msg.rv = NET.revBy; NET.revBy = 0; }
    NetT.send(0, msg);
  }
  function netProxies(dt) {
    const k = Math.min(1, dt * 14);
    for (const e of G.enemies) {
      e.t += dt; if (e.flash > 0) e.flash -= dt;
      if (e.tx === undefined) continue;
      e.x += (e.tx - e.x) * k; e.y += (e.ty - e.y) * k;
      if (e.def.ai === 'shield') e.shieldAng += clamp(angDiff(e.shieldAng, e.look || 0), -2.4 * dt, 2.4 * dt); // щит поворачивается вслед за взглядом
      if (e.spawnT > 0 || e.thief || e.fuse > 0 || P.down) continue;
      if ((P.x - e.x) ** 2 + (P.y - e.y) ** 2 < (e.r + P.r - 2) ** 2) hurtPlayer(e.dmg, e.x, e.y);
    }
    for (const b of bosses) if (b.tx !== undefined && b.state !== 'dead') { b.x += (b.tx - b.x) * k; b.y += (b.ty - b.y) * k; b.anim = (b.anim || 0) + dt; if (b.flash > 0) b.flash -= dt; }
    const A = G.tessaAlly; if (A && A.tx !== undefined) { A.x += (A.tx - A.x) * k; A.y += (A.ty - A.y) * k; }
    for (const p of G.pickups) p.t += dt;
    const ab = G.activeBoss; // касание босса
    if (ab && ab.state === 'fight' && (ab.z || 0) < 10 && (ab.alpha === undefined || ab.alpha > 0.5) && !P.down && Math.hypot(P.x - ab.x, P.y - ab.y) < ab.r + P.r - 4) hurtPlayer(ab.charging ? ab.cdmg * 1.6 : ab.cdmg, ab.x, ab.y);
    for (const c of chests) if (!c.open && !c.seen && Math.hypot(P.x - c.x, P.y - c.y) < 320) c.seen = true;
    // гостья может уйти с арены сама – через выход
    if (G.activeShrine && ARENA && P.y > PLAY_H * T) {
      NET.trialT = (NET.trialT || 0) + dt;
      if (NET.trialT > 1.5 && !P.down && Math.hypot(P.x - ARENA.exit.x, P.y - ARENA.exit.y) < 24 && NET.trialRet) {
        G.activeShrine = null; netLeaveArena(NET.trialRet.x, NET.trialRet.y);
        floatText(P.x, P.y - 40, 'Ты ушла с испытания', '#ffe9a0', true);
      }
    }
  }
  // гостья в главе 6: костры греют, метель холодит – по-своему, но погоду решает хозяйка
  function netWinterLocal(dt) {
    if (!(beds.length || shelves.length || boxes.length || clues.length || CFG.dark)) { if (G.invertT > 0) G.invertT -= dt; if (G.staticT > 0) G.staticT -= dt; }
    G.nearFire = null;
    for (const f of fires) {
      if (Math.abs(f.x - P.x) > 120 || Math.abs(f.y - P.y) > 120 || Math.hypot(f.x - P.x, f.y - P.y) > 95) continue;
      G.nearFire = f;
      if (P.hp < P.maxHp && !P.down) P.hp = Math.min(P.maxHp, P.hp + P.maxHp * 0.05 * (1 + 0.5 * lv('c6warm')) * dt);
    }
    if (CFG.weathers || fires.length) G.blizA = lerp(G.blizA || 0, G.blizzardT > 0 ? 1 : 0, Math.min(1, dt * 1.6));
  }
  // вспомогательное
  function netLiveMates() { let n = 0; for (const m of NET.peers.values()) if (m.live) n++; return n; }
  const netCoop = () => NET.host && G.netRun && netLiveMates() > 0; // хозяйка и хотя бы одна подруга в игре
  const netXpDiv = () => netCoop() ? 1 + 0.65 * netLiveMates() : 1;
  function netLeaveArena(x, y) {
    burst(P.x, P.y, 24, '#ffffff', 200);
    P.x = x + rnd(-30, 30); P.y = y + rnd(0, 30); ensureWalkable(P); P.inv = Math.max(P.inv, 1);
    G.ebullets = []; G.hazards = []; NET.bMap.clear(); revealFog(P.x, P.y, 12); Sound.sfx.blink(); biomeMusic(true);
  }
  function netTrialBack(x, y, ok) {
    const inArena = P.y > PLAY_H * T; // награда – только тем, кто дошёл до конца
    if (G.activeShrine && G.activeShrine.state === 'active' && !ok) G.activeShrine.state = 'idle';
    G.activeShrine = null;
    if (!inArena) return;
    netLeaveArena(x, y);
    if (ok) { life('trials'); showBanner('Испытание пройдено!', 'Награда: улучшение и осколки'); addSuper(30); G.pendingLv++; if (state === 'play') openLevelUp(); Sound.sfx.win(); }
    else floatText(P.x, P.y - 40, 'Испытание провалено', '#ff8a8a', true);
  }
  function netBan(a, b) { showBanner(a, b); if (NET.host && G.netRun) NetT.send(-1, { t: 'ban', a, b: b || '' }); }
  function netNear(x, y, r) {
    if (!P.down && Math.hypot(P.x - x, P.y - y) < r) return true;
    if (NET.host) for (const m of NET.peers.values()) if (m.live && !m.down && Math.hypot(m.x - x, m.y - y) < r) return true;
    return false;
  }
  function netAnchor() {
    if (!NET.host || !NET.peers.size) return P;
    const L = [P].concat([...NET.peers.values()].filter(m => m.live && !m.down && !m.away)).filter(q => !q.down);
    return L[Math.floor(Math.random() * L.length)] || P;
  }
  function netMateInCastle() {
    if (!NET.host) return false;
    for (const m of NET.peers.values()) { if (!m.live || m.down) continue; const tx = Math.floor(m.x / T), ty = Math.floor(m.y / T); if (Math.abs(tx - CASTLE.x) < CASTLE.half && Math.abs(ty - CASTLE.y) < CASTLE.half) return true; }
    return false;
  }
  // подруги на экране – под плашкой уровня
  function netHud(c, x, y) {
    let k = 0;
    for (const m of NET.mates.values()) {
      if (m.tx === undefined) continue;
      const yy = y + k * 20, hpF = m.down ? 0 : (m.hpF !== undefined ? m.hpF / 100 : (m.hp || 0) / Math.max(1, m.mh || 1));
      c.fillStyle = 'rgba(0,0,0,0.45)'; roundRect(c, x, yy, 128, 17, 7); c.fill();
      c.fillStyle = mateCol(m.id); c.beginPath(); c.arc(x + 9, yy + 8.5, 4.5, 0, TAU); c.fill();
      c.font = 'bold 10px sans-serif'; c.textAlign = 'left'; c.fillStyle = '#ffffff';
      c.fillText((m.down ? '💫 ' : '') + (m.name || '').slice(0, 10), x + 17, yy + 12);
      c.fillStyle = 'rgba(255,255,255,0.18)'; c.fillRect(x + 82, yy + 6, 40, 5);
      c.fillStyle = hpF > 0.5 ? '#7dff7d' : hpF > 0.25 ? '#ffd25a' : '#ff5b5b'; c.fillRect(x + 82, yy + 6, 40 * clamp(hpF, 0, 1), 5);
      k++;
    }
  }
  function netMates(dt) {
    const k = Math.min(1, dt * 15);
    for (const m of NET.mates.values()) { if (m.tx === undefined) continue; m.x += (m.tx - m.x) * k; m.y += (m.ty - m.y) * k; m.t += dt; }
    for (const f of G.rfeathers) { f.x += f.vx * dt; f.y += f.vy * dt; f.life -= dt; if (blocksShots(f.x, f.y)) f.life = 0; }
    G.rfeathers = G.rfeathers.filter(f => f.life > 0);
  }
  // ---------- без сил и подъём ----------
  function netDown() {
    if (P.down) return;
    buzz(220);
    P.down = true; P.hp = 0; P.revT = 0; P.stormT = 0;
    burst(P.x, P.y, 30, '#c9b3ff', 220); Sound.sfx.hurt();
    showBanner('Без сил!', 'Подруга поднимет – пусть постоит рядом');
    G.combo = 0;
    if (G.st) { G.st.deaths++; if (G.st.cur) G.st.cur.d++; }
  }
  function netReviveTick(dt) {
    if (!P.down) return;
    P.inv = Math.max(P.inv, 0.3);
    let helper = null;
    for (const m of NET.mates.values()) if (!m.down && !m.away && (m.x - P.x) ** 2 + (m.y - P.y) ** 2 < 70 * 70) { helper = m; break; }
    if (helper) { P.revT += dt; if (Math.random() < 0.3) part(P.x + rnd(-14, 14), P.y + rnd(-10, 6), 0, -40, 0.6, 4, '#7dff9a'); }
    else P.revT = Math.max(0, P.revT - dt * 0.5);
    if (P.revT >= 2.6) {
      P.down = false; P.hp = Math.round(P.maxHp * 0.4); P.inv = 2.2; P.revT = 0;
      if (helper) { if (NET.client) NET.revBy = helper.id; else if (NET.host) netEvent(helper.id, ['rv']); } // спасибо подруге – в достижения
      burst(P.x, P.y, 26, '#7dff9a', 220); Sound.sfx.heart();
      showBanner('Снова в строю!', helper ? `${helper.name} подняла тебя 💗` : '');
    }
  }
  function netTeamWipe(dt) {
    if (!G.netRun || G.cutscene) return;
    const live = [...NET.peers.values()].filter(m => m.live && !m.away);
    const all = P.down && live.every(m => m.down);
    NET.wipeT = all ? NET.wipeT + dt : 0;
    if (NET.wipeT > 1.8) {
      NET.wipeT = 0;
      if (G.rush) { rushFinish(false); playerDied(); return; } // в раше упали все – забег окончен
      if (defOn()) return; // в обороне все отдохнут у кристалла и вернутся сами
      showBanner('Все без сил…', 'Начинаем с последней точки');
      P.down = false; P.revT = 0;
      respawn();
      [...NET.peers.values()].forEach((m, i) => { const a = (i + 1) * TAU / NET_MAX; NetT.send(m.id, { t: 'rs', x: Math.round(G.cp.x + Math.cos(a) * 30), y: Math.round(G.cp.y + Math.sin(a) * 30) }); });
    }
  }
  function netRespawnMe(x, y) {
    P.down = false; P.revT = 0; P.x = x; P.y = y; ensureWalkable(P);
    P.hp = P.maxHp; P.inv = 2; P.dashT = 0; P.slowT = 0; P.lives = HEROES[P.hero].lives || 0;
    G.ebullets = []; G.hazards = []; NET.bMap.clear();
    showBanner('Ещё раз – вместе!', ''); setState('play');
  }
  function netPearl(k, cid) { // жемчужину подобрала гостья – слово для всех
    const q = pearls[k]; if (!q || q.got) return;
    collectPearl(k, true);
    netEvent(cid, ['hl']);
  }
  // каждый кадр – и в меню (поиск игр), и в игре
  function netTick(dt) {
    if (!NET.on && !NET.scanning) return;
    netRecv();
    if (!NET.on) { // ищем: обновляем список раз в полсекунды
      NET.scanT -= dt; if (NET.scanT <= 0) { NET.scanT = 0.5; if (state === 'mp') mpRender(); }
      return;
    }
    if (NET.client && NET.joining && performance.now() - NET.joining.t > 7000 && !NET.id) { toast('Хозяин не отвечает 😿'); netReset(); NetT.close(); if (state === 'mp') mpRender(); return; }
    if (NET.goAt && !NET.started) { // отсчёт перед стартом: все нажали «Готова»
      if (state === 'mp') mpWaitText();
      if (NET.host && performance.now() >= NET.goAt) mpGo();
    }
    if (!G.netRun) return;
    if (state !== 'play' && state !== 'dying') P.inv = Math.max(P.inv, 0.25); // выбираешь улучшение – тебя не трогают
    netMates(dt);
    netReviveTick(dt);
    if (NET.host) netHostTick(dt); else netClientTick(dt);
  }
  // ближайшая к мобу героиня (хозяйка или подруга) – за ней он и гонится
  function netAim(x, y) {
    if (!NET.host || !NET.peers.size) return P;
    let best = P.down ? null : P, bd = P.down ? 1e18 : (P.x - x) ** 2 + (P.y - y) ** 2;
    for (const m of NET.peers.values()) { if (!m.live || m.down || m.away || m.hidden) continue; const d = (m.x - x) ** 2 + (m.y - y) ** 2; if (d < bd) { bd = d; best = m; } }
    return best || P;
  }
  // образы игроков из лобби: аура, эмблема и рамка видны подругам
  function netLooks() {
    NET.looks = new Map();
    const cards = [];
    for (const r of NET.roster || []) { const cd = cleanCard(r.cd); if (cd) { NET.looks.set(r.id, cd); cards.push(cd); } }
    if (cards.length) try { addFriends(cards); } catch (e) { /* ignore */ }
  }
  function drawMate(c, m) {
    const col = mateCol(m.id), y = m.y - (m.z || 0), lk = NET.looks && NET.looks.get(m.id);
    shadow(c, m.x, m.y + 10, 11, 4);
    if (lk && !m.down && !m.hidden) drawAura(c, lk.au, m.x, y, m.t || 0);
    c.strokeStyle = col; c.globalAlpha = 0.75; c.lineWidth = 2.5; c.beginPath(); c.ellipse(m.x, m.y + 10, 15, 6, 0, 0, TAU); c.stroke(); c.globalAlpha = 1;
    if (m.down) {
      c.save(); c.translate(m.x, m.y + 4); c.rotate(Math.PI / 2 * (m.face || 1)); c.globalAlpha = 0.65; drawHeroV(m.hero, c, 0, 0, m.t, 1, 0.9, 0.65, false); c.restore(); c.globalAlpha = 1;
      c.font = '16px sans-serif'; c.textAlign = 'center'; c.fillText('💫', m.x, m.y - 26 + Math.sin(m.t * 3) * 3);
      c.font = 'bold 10px sans-serif'; c.fillStyle = '#ffffff'; c.fillText(m.rp > 0 ? 'поднимаем…' : 'подними!', m.x, m.y - 40);
      // полоска подъёма видна и той, кто поднимает
      c.lineWidth = 5; c.strokeStyle = 'rgba(0,0,0,0.45)'; c.beginPath(); c.arc(m.x, m.y - 4, 24, 0, TAU); c.stroke();
      if (m.rp > 0) { c.strokeStyle = '#7dff9a'; c.lineWidth = 4; c.beginPath(); c.arc(m.x, m.y - 4, 24, -Math.PI / 2, -Math.PI / 2 + TAU * clamp(m.rp / 100, 0, 1)); c.stroke(); }
      if (m.ar > 0) { c.font = 'bold 11px sans-serif'; c.fillStyle = '#ff8ad8'; c.fillText(`💗 ${m.ar} с`, m.x, m.y + 34); }
    } else drawHeroV(m.hero, c, m.x, y, m.t, m.face || 1, 1, m.away ? 0.55 : m.inv && Math.floor(m.t * 20) % 2 === 0 ? 0.5 : 1, m.mv || m.dash);
    // имя и здоровье
    const hpF = m.hpF !== undefined ? m.hpF / 100 : (m.hp || 0) / Math.max(1, m.mh || 1), nm = m.name || '';
    c.font = 'bold 10px sans-serif'; c.textAlign = 'center';
    const emb = lk ? lookItem('em', lk.em) : null, fr = lk ? lookItem('fr', lk.fr) : null;
    const w = Math.max(34, c.measureText(nm).width + 10 + (emb ? 14 : 0)), ty = y - 46;
    c.fillStyle = 'rgba(10,6,20,0.7)'; roundRect(c, m.x - w / 2, ty - 10, w, 19, 6); c.fill();
    if (fr && fr.id !== 'wood') { c.strokeStyle = fr.col; c.lineWidth = 1.5; c.stroke(); }
    if (emb) { c.font = '10px sans-serif'; c.fillText(emb.ic, m.x - w / 2 + 9, ty + 1); c.font = 'bold 10px sans-serif'; }
    c.fillStyle = col; c.fillText(nm, m.x + (emb ? 7 : 0), ty + 1);
    c.fillStyle = 'rgba(0,0,0,0.5)'; c.fillRect(m.x - w / 2 + 4, ty + 4, w - 8, 3);
    c.fillStyle = hpF > 0.5 ? '#7dff7d' : hpF > 0.25 ? '#ffd25a' : '#ff5b5b'; c.fillRect(m.x - w / 2 + 4, ty + 4, (w - 8) * clamp(hpF, 0, 1), 3);
    if (m.away && !m.down) { c.font = '12px sans-serif'; c.fillText('⏸', m.x + w / 2 + 6, ty + 2); }
  }

  window.KR = {
    get state() { return state; }, P, G, get bosses() { return bosses; }, get chests() { return chests; }, get shrines() { return shrines; },
    get CHN() { return CHN; }, newChapter, continueChapter, openMenu, update, damageBoss, gainXp, teleport, spawnEnemy, startChapter,
    mobScale, zoneE, trySuper, tryDash, computeStats,
    get gateOpen() { return gateOpen; }, get MW() { return MW; }, loadProfile, saveProfile, startChapter2,
    debugKey, isSolidTile, walkable, tileAt: (x, y) => tileAt(x, y),
    startRush, startEvent, endEvent, killEnemy, setMm: v => { MM_STYLE = v; },  get nextEv() { return G.nextEv; }, openStats, buildReport, openWhatsNew, openTeaser, showVictory, startTrick, startFinalFinal,
    loadSave, migrateProfile, hurtPlayer, openBoard, openWardrobe, openRelicChoice, playStory: id => Intro.start(id, openMenu), openLevelUp, openMap, openKrillTeaser, pauseGame, rotHintMaybe, get ebullets() { return G.ebullets; }, ebullet,
    NET, netAim, get melted() { return G.melted; }, startAbyss, startDefense, defWave, tdAct, tdDo, tdTap, tdSpellBtn, tdCast, tdHeroK, tdPortal, tdCurSpot, tdMakeWave, tdSpawn, tdUpCost, tdSpent, tdCall, defFinish, tdTargets, tdMapOpen, tdSurvived, tdCoreHit, get zoom() { return ZOOM; }, startDaily, openModes, openColl, openBook, openMuts, lifeFlush, ACHS, MUTS, ACH_BY, achCheck, gloryOf, myLook, myCard, cardCode, readCode, addFriends, cleanCard, openHall, openLook, gloryMigrate, achPop, life, lifeMax, starfall, rh: rollHit, startBossFight, openChest, gloryWin, openHome, furnDrop, homeState, petOwned, HOME, renderHomeEdit, get secrets() { return secrets; }, tryCrack, damageEnemy, openRelics, openRelicChoice, pickRelic, relicLv, evoTick, EVOS, abyssCkLoad, logErr, errLog, liveWrite, recordRunEnd, abyssDecks, seasonState, seasonFlush, seasonDaily, dayQuests, weekQuest, weekEvent, seasonLvl, openSeason, gainXp, dailyInfo, buzz, mutGo, abyssWave, renderAch, bookCount,     get beds() { return beds; }, get clues() { return clues; }, get npcs() { return npcs; }, get qitems() { return qitems; },
    get arena() { return ARENA; }, get playH() { return PLAY_H; },
    get shelves() { return shelves; }, get boxes() { return boxes; }, get lamps() { return lamps; },
    input, setVol: v => { volOn = v; }, get volCache() { return VOL.size; }, get trees() { return trees; }, get miniBase() { return miniBase; }, get fires() { return fires; }, get holes() { return holes; }, get ovens() { return ovens; }, get drifts() { return drifts; }, get glades() { return glades; }, get pearls() { return pearls; }, get curPts() { return curPts; }, collectPearl, startWeather, switchHero, freeTessa, meltTile, openTalents, saveGame, talent, iceTarget, openLevelUp,
  };

  // ------------------------------------------------------------------
  //  Запуск
  // ------------------------------------------------------------------
  function fallbackPortrait() {
    const W = 480, H = 640, cv = makeCanvas(W, H), c = cv.getContext('2d');
    c.fillStyle = '#2a1238'; c.fillRect(0, 0, W, H);
    c.fillStyle = '#ff6a1f'; c.beginPath(); c.ellipse(240, 330, 190, 260, 0, 0, TAU); c.fill();
    c.fillStyle = '#ffe0cc'; c.beginPath(); c.ellipse(240, 290, 120, 150, 0, 0, TAU); c.fill();
    c.fillStyle = '#111'; c.fillRect(0, 500, W, 140);
    return { photo: cv, cartoon: cv, face: { x: 0.5, y: 0.45, r: 0.36 } };
  }
  async function boot() {
    Sound.init();
    loadChapter(1); resetRun(); makeBosses(); computeStats();
    { const s0 = (loadProfile().settings || {}); paperOn = s0.style === 'paper'; PAPER_ART = paperOn; document.body.classList.toggle('paper', paperOn); } // 1.0.13: по умолчанию – классика
    for (const name of PAPER_ART ? ['zyama'] : ['ryzhova', 'zyama']) {
      try { IMG[name] = await Cartoon.make(name); }
      catch (e) { console.warn('Не удалось обработать фото', name, e); IMG[name] = fallbackPortrait(); }
    }
    if (PAPER_ART) { // 1.0: Рыжовая нарисована, как и остальные героини
      const rz = ryzFacePortrait(400); IMG.ryzhova = { photo: rz, cartoon: rz, face: { x: 0.5, y: 0.47, r: 0.36 } };
      ART.ryzhovaSmall = null; AVATAR.ryzhova = ryzFacePortrait(116); AVATAR.ryzhovaBig = ryzFacePortrait(300);
    } else {
    ART.ryzhovaSmall = Cartoon.avatar(IMG.ryzhova.cartoon, 128, IMG.ryzhova.face);
    AVATAR.ryzhova = Cartoon.avatar(IMG.ryzhova.cartoon, 116, IMG.ryzhova.face);
    AVATAR.ryzhovaBig = Cartoon.avatar(IMG.ryzhova.cartoon, 300, IMG.ryzhova.face);
    }
    ART.zyamaFace = Cartoon.avatar(IMG.zyama.cartoon, 160, IMG.zyama.face);
    ART.zyamaSmall = Cartoon.avatar(IMG.zyama.cartoon, 48, IMG.zyama.face);
    AVATAR.zyama = ART.zyamaFace;
    AVATAR.krilessa = heroPortrait('krilessa');
    for (const k of Object.keys(BOSSES)) if (!AVATAR[k]) AVATAR[k] = BOSSES[k].avatar ? AVATAR[BOSSES[k].avatar] : bossPortrait(k);
    AVATAR.tessa = heroPortrait('tessa'); AVATAR.tessaBig = heroPortrait('tessa', 300);
    Cartoon.make('tessa').then(img => {
      IMG.tessa = img;
      AVATAR.tessa = Cartoon.avatar(img.cartoon, 116, img.face); AVATAR.tessaBig = Cartoon.avatar(img.cartoon, 300, img.face);
    }).catch(e => console.warn('Не удалось обработать фото Тессы', e));
    const pre = [1, 2, 3].map(n => !!loadSave(n)); // до переноса: старые сохранения он может убрать
    const prof = migrateProfile();
    volOn = !(prof.settings && prof.settings.vol === false); volLabel();
    document.body.classList.toggle('paper', paperOn); PAPER_ART = paperOn; LOOK_ALL = !!prof.admin;
    if (document.fonts && document.fonts.load) for (const fnt of [HAND(16), '700 16px Philosopher', '800 16px Nunito']) document.fonts.load(fnt, 'Яя12').catch(() => {});
    if (!MM_URL) { const ms = prof.settings || {}; MM_STYLE = ms.miniV === 2 && ['classic', 'neon', 'paper'].includes(ms.mini) ? ms.mini : ms.mini === 'classic' ? 'classic' : paperOn ? 'paper' : 'neon'; } miniLabel(); styleLabel();
    applyJoy(prof.settings && prof.settings.joy); joyLabel();
    MM2.sizeF = 0;
    TESSA_OUTFIT = (prof.wardrobe && prof.wardrobe.on) || 'none';
    const hasData = prof.ch1Done || prof.carry || pre[0] || pre[1] || pre[2];
    if (prof.lastVersion === '0.37 stable') { prof.lastVersion = '0.35 stable'; saveProfile(prof); } // оборона ненадолго выходила под номером 0.37
    if (prof.lastVersion !== VERSION) {
      // версии до 0.04 не запоминали себя – угадываем по сохранениям
      const guess = prof.ch3Done || pre[2] ? '0.03 beta' : (prof.ch2Done || pre[1] || prof.carry) ? '0.02 beta' : true;
      if (prof.lastVersion || hasData) G.pendingWhatsNew = prof.lastVersion || guess;
      else { prof.lastVersion = VERSION; saveProfile(prof); }
    }
    const tot = loadTotals(); tot.sessions = (tot.sessions || 0) + 1; saveTotals(tot);
    setInterval(() => { if (state === 'play') { const t2 = loadTotals(); t2.playTime = (t2.playTime || 0) + 10; saveTotals(t2); } }, 10000);
    requestAnimationFrame(loop);
    const lastRun = liveCheck(), rgone = /[?&]rgone=1/.test(location.search);
    if (rgone) logErr('Android: процесс отрисовки упал, игра перезапущена', 'android'); // Android перезапустил игру после сбоя отрисовки
    if (rgone || lastRun) {
      const tail = abyssCkLoad() ? 'Бездну можно продолжить в «Режимах»' : 'Прогресс глав сохранён';
      bootToast(rgone ? `😵 Игра перезапустилась после сбоя. ${tail}` : lastRun.bg ? `💤 Игра закрылась, пока была свёрнута. ${tail}` : `😵 Похоже, игра закрылась посреди боя. ${tail}`);
    }
    // игра успешно запустилась – скачанное обновление рабочее, откатывать не нужно
    try { if (window.KrilessaAndroid && KrilessaAndroid.booted) KrilessaAndroid.booted(); } catch (e) { /* ignore */ }
    const pr0 = loadProfile();
    const returning = pr0.ch1Done || pr0.lastCh || CH_NUMS.some(n => loadSave(n));
    if (returning) {
      openSplash();
      if (G.pendingWhatsNew) { const from = G.pendingWhatsNew; G.pendingWhatsNew = null; openWhatsNew(from === true ? null : from); }
    } else Intro.start('ch1', openMenu);
  }
  boot();
})();
